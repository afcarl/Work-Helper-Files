using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;
using Drive.Collections;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for AssetDetailForm.
	/// </summary>
	public class AssetDetailForm : System.Windows.Forms.Form
	{
		ComponentAsset		m_asset = null;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBoxAssetID;
		private System.Windows.Forms.TextBox textBoxDescription;
		private System.Windows.Forms.ComboBox comboBoxConditionRank;
		private System.Windows.Forms.TextBox textBoxReplacementCost;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		protected AssetDetailForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AssetDetailForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.textBoxAssetID = new System.Windows.Forms.TextBox();
			this.textBoxDescription = new System.Windows.Forms.TextBox();
			this.comboBoxConditionRank = new System.Windows.Forms.ComboBox();
			this.textBoxReplacementCost = new System.Windows.Forms.TextBox();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "&Asset ID Number:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(8, 44);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "&Description:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(8, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "&Condition Ranking:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Location = new System.Drawing.Point(8, 102);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "&Replacement Cost:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAssetID
			// 
			this.textBoxAssetID.Location = new System.Drawing.Point(108, 12);
			this.textBoxAssetID.MaxLength = 255;
			this.textBoxAssetID.Name = "textBoxAssetID";
			this.textBoxAssetID.Size = new System.Drawing.Size(172, 20);
			this.textBoxAssetID.TabIndex = 1;
			this.textBoxAssetID.Text = "";
			// 
			// textBoxDescription
			// 
			this.textBoxDescription.Location = new System.Drawing.Point(108, 40);
			this.textBoxDescription.MaxLength = 255;
			this.textBoxDescription.Name = "textBoxDescription";
			this.textBoxDescription.Size = new System.Drawing.Size(280, 20);
			this.textBoxDescription.TabIndex = 3;
			this.textBoxDescription.Text = "";
			// 
			// comboBoxConditionRank
			// 
			this.comboBoxConditionRank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxConditionRank.Location = new System.Drawing.Point(108, 68);
			this.comboBoxConditionRank.Name = "comboBoxConditionRank";
			this.comboBoxConditionRank.Size = new System.Drawing.Size(280, 21);
			this.comboBoxConditionRank.TabIndex = 5;
			// 
			// textBoxReplacementCost
			// 
			this.textBoxReplacementCost.Location = new System.Drawing.Point(108, 100);
			this.textBoxReplacementCost.MaxLength = 15;
			this.textBoxReplacementCost.Name = "textBoxReplacementCost";
			this.textBoxReplacementCost.TabIndex = 7;
			this.textBoxReplacementCost.Text = "";
			this.textBoxReplacementCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxReplacementCost.Leave += new System.EventHandler(this.textBoxReplacementCost_Leave);
			this.textBoxReplacementCost.Enter += new System.EventHandler(this.textBoxReplacementCost_Enter);
			// 
			// buttonSave
			// 
			this.buttonSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(225, 128);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 8;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(309, 128);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 9;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// AssetDetailForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(392, 158);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.textBoxReplacementCost);
			this.Controls.Add(this.textBoxAssetID);
			this.Controls.Add(this.textBoxDescription);
			this.Controls.Add(this.comboBoxConditionRank);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.buttonCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AssetDetailForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Asset";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AssetDetailForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.AssetDetailForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(ComponentAsset asset, Form owner)
		{
			AssetDetailForm form = new AssetDetailForm();

			form.m_asset = asset;
			return (form.ShowDialog(owner) == DialogResult.OK);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			if (m_asset.ID == 0)
				this.Text = "Add Asset";
			else
				this.Text = "Edit Asset";

			// Load condition rankings
			LoadConditionRankBox();

			textBoxAssetID.Text = m_asset.Name;
			textBoxDescription.Text = m_asset.Description;
			textBoxReplacementCost.Text = m_asset.ReplacementCost.ToString("$#,##0");

			base.OnLoad(e);
		}

		private void		LoadConditionRankBox()
		{
			comboBoxConditionRank.BeginUpdate();
			comboBoxConditionRank.DisplayMember = "DisplayMember";
			comboBoxConditionRank.Items.Clear();
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C0),
				CondRank.C0));
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C1),
				CondRank.C1));
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C2),
				CondRank.C2));
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C3),
				CondRank.C3));
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C4),
				CondRank.C4));
			comboBoxConditionRank.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C5),
				CondRank.C5));
			comboBoxConditionRank.EndUpdate();
			SelectConditionRank();
		}

		private void		SelectConditionRank()
		{
			for (int pos = 0; pos < comboBoxConditionRank.Items.Count; pos++)
			{
				if (m_asset.ConditionRanking == 
					((CondRank)((ListItem)comboBoxConditionRank.Items[pos]).Value))
				{
					comboBoxConditionRank.SelectedIndex = pos;
					return;
				}
			}

			comboBoxConditionRank.SelectedIndex = 0;
		}

		private CondRank	GetSelectedConditionRanking()
		{
			ListItem		listItem = comboBoxConditionRank.SelectedItem as ListItem;

			if (listItem == null)
				return CondRank.No;

			return (CondRank)listItem.Value;
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to save data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			m_asset.Name = textBoxAssetID.Text;
			m_asset.Description = textBoxDescription.Text;
			m_asset.ConditionRanking = GetSelectedConditionRanking();
			m_asset.ReplacementCost = 
				Drive.Convert.DollarStringToDecimal(textBoxReplacementCost.Text);
			m_asset.InfoSetID = InfoSet.CurrentID;
			m_asset.Save();

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void textBoxReplacementCost_Enter(object sender, System.EventArgs e)
		{
			string			val = textBoxReplacementCost.Text.Replace("$", "");

			val = val.Replace(",", "");
			textBoxReplacementCost.Text = val;
			textBoxReplacementCost.SelectAll();
		}

		private void textBoxReplacementCost_Leave(object sender, System.EventArgs e)
		{
			decimal			val = 0;

			val = Drive.Convert.DollarStringToDecimal(textBoxReplacementCost.Text);
			textBoxReplacementCost.Text = val.ToString("$#,##0");
		}

		private void AssetDetailForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void AssetDetailForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}
