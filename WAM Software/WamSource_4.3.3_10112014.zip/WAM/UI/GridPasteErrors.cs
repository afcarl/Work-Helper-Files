using System;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Data;
using C1.Win.C1FlexGrid;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for GridPasteErrors.
	/// </summary>
	public class GridPasteErrors : System.Windows.Forms.Form
	{
		#region /***** Enumerations *****/

		enum MessageResponse
		{
			MessageResponseButton1 = 1,
			MessageResponseButton2 = 2,
		}

		#endregion /***** Enumerations *****/

		#region /***** Variables *****/

		public delegate void NotifyParentOnClosing(string testString, ArrayList arraySelectedRows);
		public int msgBoxReturnValue = 0;
		public bool optionIsSelected = false;
		public bool userConfirmedDelete = false;

		private Timer timerShowMessage = new Timer();
		private Form parentForm = null;
		private ToolTip toolTip = new ToolTip();
		private DataTable dataTableSaveData = new DataTable();
		private TreeNode thisNode = new TreeNode();
		private C1FlexGrid gridClip = new C1FlexGrid();

		private ArrayList selectedArray = new ArrayList();
		private ArrayList arrayMCIDsToDelete = new ArrayList();
		private DataTable dataTableMajorComponentIDsUsedInProjects = new DataTable();
		private DataTable dataTableMajorComponentIDsUsedInTreatmentProcesses = new DataTable();

		private int gridRowCount = 0;
		private int gridColCount = 0;
		private string gridClipString = string.Empty;
		
		//****************************************************
		private System.Windows.Forms.Panel panelGrid;
		private System.Windows.Forms.Label labelMessage;
		private System.Windows.Forms.Label labelDataCopied;
		private System.Windows.Forms.Button buttonCopyAllData;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.Panel panelSeparator;
		//****************************************************

		private System.ComponentModel.Container components = null;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public GridPasteErrors(Form parentForm, C1FlexGrid gridClip, string gridClipString, int gridRowCount, int gridColCount)
		{
			InitializeComponent();

			this.parentForm = parentForm;
			this.gridClip = gridClip;
			this.gridClipString = gridClipString;
			this.gridRowCount = gridRowCount;
			this.gridColCount = gridColCount;
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		protected override void OnClosing(CancelEventArgs e)
		{
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GridPasteErrors));
			this.panelGrid = new System.Windows.Forms.Panel();
			this.labelMessage = new System.Windows.Forms.Label();
			this.labelDataCopied = new System.Windows.Forms.Label();
			this.buttonCopyAllData = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// panelGrid
			// 
			this.panelGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelGrid.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelGrid.Cursor = System.Windows.Forms.Cursors.Default;
			this.panelGrid.Location = new System.Drawing.Point(11, 134);
			this.panelGrid.Name = "panelGrid";
			this.panelGrid.Size = new System.Drawing.Size(472, 154);
			this.panelGrid.TabIndex = 489;
			// 
			// labelMessage
			// 
			this.labelMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelMessage.BackColor = System.Drawing.Color.Transparent;
			this.labelMessage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelMessage.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelMessage.Location = new System.Drawing.Point(13, 49);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.Size = new System.Drawing.Size(467, 71);
			this.labelMessage.TabIndex = 629;
			// 
			// labelDataCopied
			// 
			this.labelDataCopied.BackColor = System.Drawing.Color.Transparent;
			this.labelDataCopied.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDataCopied.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelDataCopied.Location = new System.Drawing.Point(164, 305);
			this.labelDataCopied.Name = "labelDataCopied";
			this.labelDataCopied.Size = new System.Drawing.Size(152, 16);
			this.labelDataCopied.TabIndex = 662;
			this.labelDataCopied.Text = "The grid data was copied";
			// 
			// buttonCopyAllData
			// 
			this.buttonCopyAllData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCopyAllData.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCopyAllData.Location = new System.Drawing.Point(309, 301);
			this.buttonCopyAllData.Name = "buttonCopyAllData";
			this.buttonCopyAllData.Size = new System.Drawing.Size(84, 23);
			this.buttonCopyAllData.TabIndex = 663;
			this.buttonCopyAllData.Text = "Copy All Data";
			this.buttonCopyAllData.Click += new System.EventHandler(this.buttonCopyAllData_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(400, 301);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(84, 23);
			this.buttonClose.TabIndex = 664;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(0, 0);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(492, 32);
			this.labelReportTemplateName.TabIndex = 666;
			this.labelReportTemplateName.Text = " Copy Data into Grid";
			this.labelReportTemplateName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(492, 2);
			this.panelSeparator.TabIndex = 667;
			// 
			// GridPasteErrors
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(492, 334);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelReportTemplateName);
			this.Controls.Add(this.buttonCopyAllData);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.labelDataCopied);
			this.Controls.Add(this.panelGrid);
			this.Controls.Add(this.labelMessage);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(500, 300);
			this.Name = "GridPasteErrors";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Grid Paste Errors";
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			try
			{
				InitializeGrid();
				InitializeControls();
				PopulateGrid();

				this.CenterToParent();
			}
			catch(Exception ex)
			{
				//MPM.Common.CommonTasks.ShowMessageBoxError(this, this.Name + ".OnLoad", ex.Message.ToString(), "Error");
				MessageBox.Show(this, "Error in " + this.Name + ".OnLoad:  " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private bool InitializeControls()
		{
			try
			{
				this.CenterToParent();
				this.Text = "Error Pasting Data into Grid";

				//this.Paint += new System.Windows.Forms.PaintEventHandler(mmCommonTools.CommonTools.Form_Paint);
				this.gridClip.OwnerDrawCell += new OwnerDrawCellEventHandler(grid_OwnerDrawCell);

				labelDataCopied.Visible = false;

				this.gridClip.AllowDragging = AllowDraggingEnum.None;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append("The data cannot be copied into the grid because some of the data is not in the proper format.");
				stringBuilder.Append("  The improperly formatted data is shown in red in the grid below.");
				stringBuilder.Append("\r\n\r\nTo retry pasting the data, edit the data below to properly format it,");
				stringBuilder.Append(" press the 'Copy All Data' button, close this window, and paste the data.");

				labelMessage.Text = stringBuilder.ToString();

				return true;
			}
			catch(Exception ex)
			{
				//MPM.Common.CommonTasks.ShowMessageBoxError(this, this.Name + ".InitializeControls", ex.Message.ToString(), "Error");
				MessageBox.Show(this, "Error in " + this.Name + ".InitializeControls:  " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

				return false;
			}
		}

		private bool InitializeGrid()
		{
			try
			{
				this.panelGrid.Controls.Add(gridClip);

				gridClip.DrawMode = C1.Win.C1FlexGrid.DrawModeEnum.OwnerDraw;
				gridClip.Location = new Point(1, 1);
				gridClip.Size = new System.Drawing.Size(panelGrid.Size.Width - 2, panelGrid.Size.Height - 2);
				gridClip.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
					| System.Windows.Forms.AnchorStyles.Left) 
					| System.Windows.Forms.AnchorStyles.Right)));
				gridClip.AutoClipboard = true;
				gridClip.ExtendLastCol = true;

				gridClip.BackColor = SystemColors.ControlDark;
				gridClip.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
				gridClip.Styles.EmptyArea.BackColor = SystemColors.ControlDark;
				gridClip.Styles.EmptyArea.Border.Style = C1.Win.C1FlexGrid.BorderStyleEnum.None;

				//************
				gridClip.Styles.Normal.BackColor = Color.White;
				gridClip.Styles.Alternate.BackColor = Color.White;

				gridClip.Styles.Normal.ForeColor = Color.Black;
				gridClip.Styles.Alternate.ForeColor = Color.Black;

				gridClip.Styles.Normal.Border.Color = SystemColors.ControlDark;
				gridClip.Styles.Alternate.Border.Color = SystemColors.ControlDark;

				gridClip.Styles.Fixed.BackColor = SystemColors.Control;
				gridClip.Styles.Fixed.ForeColor = Color.Black;

				//************

				if (gridClip.Rows.Fixed == 0)
				{
					gridClip.Rows.Insert(0);
					gridClip.Rows.Fixed = 1;
				}
				foreach (C1.Win.C1FlexGrid.Column gridColumn in gridClip.Cols)
				{
					try
					{
						gridClip[0, gridColumn.Index] = gridColumn.Name.ToString();
					}
					catch
					{
					}
				}

				gridClip.Styles.Fixed.Font = new Font(gridClip.Font, FontStyle.Regular);
				gridClip.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
				gridClip.Styles.Fixed.Trimming = StringTrimming.Word;
				gridClip.Styles.Fixed.WordWrap = true;
				gridClip.AutoSizeRow(0);

				gridClip.HighLight = HighLightEnum.WithFocus;
				gridClip.Visible = true;
				gridClip.BringToFront();

				return true;
			}
			catch(Exception ex)
			{
				//MPM.Common.CommonTasks.ShowMessageBoxError(this, this.Name + ".InitializeGrid", ex.Message.ToString(), "Error");
				MessageBox.Show(this, "Error in " + this.Name + ".InitializeGrid:  " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

				return false;
			}
		}

		public bool PopulateGrid()
		{
			try
			{
				//copy gridClipString data into grid

				CellStyle cellStyleNotValid;
				cellStyleNotValid = gridClip.Styles.Add("NotValid");
				cellStyleNotValid.ForeColor = Color.Crimson;
				gridClip.Styles.Highlight.BackColor = Color.FromArgb(255, 230, 196);
				gridClip.Styles.Highlight.ForeColor = cellStyleNotValid.ForeColor;
				gridClip.Styles.Focus.BackColor = Color.FromArgb(255, 230, 196);
				gridClip.Styles.Focus.ForeColor = cellStyleNotValid.ForeColor;
				cellStyleNotValid.Font = new Font(cellStyleNotValid.Font.FontFamily.ToString(), cellStyleNotValid.Font.Size, 
					System.Drawing.FontStyle.Italic);
				cellStyleNotValid.Border.Color = Color.FromArgb(132, 167, 196);

				//grid cell style for cells with valid data
				CellStyle cellStyleValid;
				cellStyleValid = gridClip.Styles.Add("Valid");
				cellStyleValid.Border.Color = Color.FromArgb(132, 167, 196);
				
				cellStyleValid.ForeColor = gridClip.Styles.Normal.ForeColor;

				gridClip.Styles.Highlight.BackColor = Color.FromArgb(255, 230, 196);

				gridClip.Styles.Highlight.ForeColor = cellStyleNotValid.ForeColor;

				gridClip.Styles.Focus.ForeColor = gridClip.Styles.Normal.ForeColor;
				gridClip.Styles.Focus.BackColor = Color.FromArgb(255, 230, 196);

				//grid cell style for highlighted cells with valid data
				CellStyle cellStyleValidHighlight;
				cellStyleValidHighlight = gridClip.Styles.Add("ValidHighlight");
				cellStyleValidHighlight.Border.Color = Color.FromArgb(132, 167, 196);
				cellStyleValidHighlight.ForeColor = gridClip.Styles.Normal.ForeColor;
				cellStyleValidHighlight.BackColor = Color.FromArgb(255, 230, 196);

				//grid cell style for highlighted cells with invalid data
				CellStyle cellStyleNotValidHighlight;
				cellStyleNotValidHighlight = gridClip.Styles.Add("NotValidHighlight");
				cellStyleNotValidHighlight.ForeColor = Color.Crimson;
				cellStyleNotValidHighlight.BackColor = Color.FromArgb(255, 230, 196);
				cellStyleNotValidHighlight.Border.Color = Color.FromArgb(132, 167, 196);

				for (int i = 0; i < gridClip.Rows.Count; i++)
				{
					////subract 1 from gridClip.Cols.Count so that the last col (TempID) will not be displayed
					for (int j = 0; j < gridClip.Cols.Count; j++)
					{
						//MessageBox.Show(gridClip.Cols[j].Name);
						//if the UserData for the cell is not zero, then the data in that cell is not valid
						CellRange cellRangeNotValid = gridClip.GetCellRange(i, j);
						
						if (cellRangeNotValid.UserData != null && cellRangeNotValid.UserData.ToString() != "0")
						{
							cellRangeNotValid.Style = gridClip.Styles["NotValid"];
						}
						else
						{
							//if the grid column has a DataMap, show the DataMap value, rather than the key (ID)
							if (gridClip.Cols[j].DataMap != null)
							{
								if (cellRangeNotValid.UserData != null)
								{
									gridClip[i, j] = gridClip.Cols[j].DataMap[gridClip[i, j]].ToString();
								}
							}
							cellRangeNotValid.Style = gridClip.Styles["Valid"];
						}
					}
				}

				gridClip.Cols[gridClip.Cols.Count - 1].WidthDisplay = 0;

				//gridClip.Styles.Fixed.BackColor = Color.FromArgb(208, 221, 234);
				//gridClip.Styles.Fixed.Border.Color = Color.FromArgb(132, 167, 196);
				gridClip.Styles.Fixed.BackColor = SystemColors.Control;
				gridClip.Styles.Fixed.Border.Color = SystemColors.ControlDark;
				gridClip.Styles.Normal.Border.Color = SystemColors.ControlDark;
				gridClip.Styles.Alternate.Border.Color = SystemColors.ControlDark;

				return true;
			}
			catch(Exception ex)
			{
				//MPM.Common.CommonTasks.ShowMessageBoxError(this, this.Name.ToString() + ".PopulateGrid", ex.Message.ToString(), "Error");
				MessageBox.Show(this, "Error in " + this.Name + ".PopulateGrid:  " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

				return false;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Data Operations *****/

		#endregion /***** Data Operations *****/
		
		#region /***** Event Handlers *****/

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void grid_OwnerDrawCell(object sender, C1.Win.C1FlexGrid.OwnerDrawCellEventArgs e)
		{
			//if the cell is highlighted and its normal style is red
			CellRange cellRange = gridClip.GetCellRange(e.Row, e.Col);
			if (e.Style.BackColor == gridClip.Styles.Highlight.BackColor 
				&& cellRange.StyleDisplay.ForeColor == gridClip.Styles["Valid"].ForeColor)
			{
				//select the highlighted red style
				e.Style = gridClip.Styles["ValidHighlight"];
			}
			else if (e.Style.BackColor == gridClip.Styles.Highlight.BackColor 
				&& cellRange.StyleDisplay.ForeColor == gridClip.Styles["NotValid"].ForeColor)
			{
				e.Style = gridClip.Styles["NotValidHighlight"];
			}
		}

		#endregion /***** Event Handlers *****/

		private void buttonCopyAllData_Click(object sender, System.EventArgs e)
		{
			try
			{
				//take the grid out of editor mode
				if (gridClip.Editor != null)
				{
					gridClip[gridClip.Row, gridClip.Col] = gridClip.Editor.Text;
				}
			}
			catch
			{
			}

			try
			{
				//copy the data from the entire grid (except for headers)
				WAM.Common.GridEventsCopyPaste gridEventsCopyPaste = new WAM.Common.GridEventsCopyPaste();
				string returnString = gridEventsCopyPaste.CopySelector(gridClip, true, false, false, true, true, false, false);

				if (returnString == null || returnString.Length == 0)
				{
					MessageBox.Show("No data was copied", "Copy Text", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					labelDataCopied.Visible = true;
					timerShowMessage.Tick += new EventHandler(timerShowMessage_Tick);
					timerShowMessage.Interval = 3500;
					timerShowMessage.Enabled = true;

					//labelDataCopied
				}
			}
			catch(Exception ex)
			{
				//MPM.Common.CommonTasks.ShowMessageBoxError(this, "Copy data from Error Grid", ex.Message, "Error");
				MessageBox.Show(this, "Error copying data from Error Grid:  " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void timerShowMessage_Tick(object sender, System.EventArgs e)
		{
			try
			{
				timerShowMessage.Enabled = false;
				labelDataCopied.Visible = false;
			}
			catch
			{
			}
		}
	}
}
