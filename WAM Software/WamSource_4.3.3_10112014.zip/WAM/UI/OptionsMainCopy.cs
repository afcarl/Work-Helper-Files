using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for OptionsMain.
	/// </summary>
	public class OptionsMain : System.Windows.Forms.Form
	{
		//public delegate void Message(int autoSave);
		public delegate void Message(string optionsMain);
		//public event Message OnMessage;
		//public int autoSaveOption = 1;
		//public string optionsMainList = "";

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label labelRound;
		private System.Windows.Forms.Label labelComma1;
		private System.Windows.Forms.Label labelComma2;

		private int roundDigit = 0;
		private MainForm parentForm = null;
		private System.Windows.Forms.Label labelDigit8;
		private System.Windows.Forms.Label labelDigit7;
		private System.Windows.Forms.Label labelDigit6;
		private System.Windows.Forms.Label labelDigit3;
		private System.Windows.Forms.Label labelDigit4;
		private System.Windows.Forms.Label labelDigit5;
		private System.Windows.Forms.Label labelDigit0;
		private System.Windows.Forms.Label labelDigit1;
		private System.Windows.Forms.Label labelDigit2;
		private System.Windows.Forms.CheckBox checkBoxRound;
		private System.Windows.Forms.CheckBox checkBoxGraph;
		private System.Windows.Forms.Label labelGraph;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox checkBoxCostTabs;
		private System.Windows.Forms.Label labelCostTabs;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox checkBoxFacilityValuation;
		private System.Windows.Forms.Label labelFacilityValuation;
		private System.Windows.Forms.TextBox textBoxReadOnlyContainer;
		private System.Windows.Forms.TextBox textBoxReadOnly;
		private System.Windows.Forms.Label labelFormSize;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.CheckBox checkBoxReadOnlyColor;
		private System.Windows.Forms.Label labelReadOnlyColor;
		private System.Windows.Forms.CheckBox checkBoxRetired;
		private System.Windows.Forms.Label labelRetired;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button buttonReadOnlyColorPicker;
		private System.Windows.Forms.Button buttonReadOnlyColorReset;
		private System.Windows.Forms.Label labelReadOnlyRgb;
		private System.Windows.Forms.Label labelReadOnly;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox checkBoxFacilityCrit;
		private System.Windows.Forms.Label labelFacilityCrit;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.CheckBox checkBoxPhotoFileName;
		private System.Windows.Forms.Label labelPhotoFileName;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OptionsMain(MainForm form)
		{
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);

			labelDigit0.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit1.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit2.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit3.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit4.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit5.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit6.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit7.Click += new System.EventHandler(labelDigitHandler_Click);
			labelDigit8.Click += new System.EventHandler(labelDigitHandler_Click);

			//***************************
			// Help button image
//			System.Reflection.Assembly thisExe;
//			thisExe = System.Reflection.Assembly.GetExecutingAssembly();
//			System.IO.Stream file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonHelpOn8.bmp");
//
//			Image image = (Bitmap)Bitmap.FromStream(file);
//			this.pictureBoxHelp.Image = image;

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			parentForm = form;
			//***************************
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OptionsMain));
			this.label1 = new System.Windows.Forms.Label();
			this.labelRound = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.labelDigit8 = new System.Windows.Forms.Label();
			this.labelDigit7 = new System.Windows.Forms.Label();
			this.labelDigit6 = new System.Windows.Forms.Label();
			this.labelDigit3 = new System.Windows.Forms.Label();
			this.labelDigit4 = new System.Windows.Forms.Label();
			this.labelDigit5 = new System.Windows.Forms.Label();
			this.labelDigit0 = new System.Windows.Forms.Label();
			this.labelDigit1 = new System.Windows.Forms.Label();
			this.labelDigit2 = new System.Windows.Forms.Label();
			this.labelComma1 = new System.Windows.Forms.Label();
			this.labelComma2 = new System.Windows.Forms.Label();
			this.checkBoxRound = new System.Windows.Forms.CheckBox();
			this.checkBoxGraph = new System.Windows.Forms.CheckBox();
			this.labelGraph = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.checkBoxCostTabs = new System.Windows.Forms.CheckBox();
			this.labelCostTabs = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.checkBoxFacilityValuation = new System.Windows.Forms.CheckBox();
			this.labelFacilityValuation = new System.Windows.Forms.Label();
			this.buttonReadOnlyColorPicker = new System.Windows.Forms.Button();
			this.textBoxReadOnlyContainer = new System.Windows.Forms.TextBox();
			this.textBoxReadOnly = new System.Windows.Forms.TextBox();
			this.buttonReadOnlyColorReset = new System.Windows.Forms.Button();
			this.labelFormSize = new System.Windows.Forms.Label();
			this.checkBoxReadOnlyColor = new System.Windows.Forms.CheckBox();
			this.labelReadOnlyColor = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.checkBoxRetired = new System.Windows.Forms.CheckBox();
			this.labelRetired = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.labelReadOnlyRgb = new System.Windows.Forms.Label();
			this.labelReadOnly = new System.Windows.Forms.Label();
			this.checkBoxFacilityCrit = new System.Windows.Forms.CheckBox();
			this.labelFacilityCrit = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.checkBoxPhotoFileName = new System.Windows.Forms.CheckBox();
			this.labelPhotoFileName = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label1.Location = new System.Drawing.Point(10, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(198, 24);
			this.label1.TabIndex = 75;
			this.label1.Text = "Rounding 10, 11";
			// 
			// labelRound
			// 
			this.labelRound.BackColor = System.Drawing.Color.Transparent;
			this.labelRound.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelRound.Location = new System.Drawing.Point(48, 37);
			this.labelRound.Name = "labelRound";
			this.labelRound.Size = new System.Drawing.Size(88, 16);
			this.labelRound.TabIndex = 0;
			this.labelRound.Text = "Use rounding";
			this.labelRound.Click += new System.EventHandler(this.labelRound_Click);
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(544, 522);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&Save";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(625, 522);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(677, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 93;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// labelDigit8
			// 
			this.labelDigit8.BackColor = System.Drawing.Color.White;
			this.labelDigit8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit8.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit8.Enabled = false;
			this.labelDigit8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit8.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit8.Location = new System.Drawing.Point(141, 36);
			this.labelDigit8.Name = "labelDigit8";
			this.labelDigit8.Size = new System.Drawing.Size(14, 20);
			this.labelDigit8.TabIndex = 129;
			this.labelDigit8.Tag = "8";
			this.labelDigit8.Text = "1";
			this.labelDigit8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit7
			// 
			this.labelDigit7.BackColor = System.Drawing.Color.White;
			this.labelDigit7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit7.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit7.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit7.Location = new System.Drawing.Point(154, 36);
			this.labelDigit7.Name = "labelDigit7";
			this.labelDigit7.Size = new System.Drawing.Size(14, 20);
			this.labelDigit7.TabIndex = 130;
			this.labelDigit7.Tag = "7";
			this.labelDigit7.Text = "2";
			this.labelDigit7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit6
			// 
			this.labelDigit6.BackColor = System.Drawing.Color.White;
			this.labelDigit6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit6.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit6.Location = new System.Drawing.Point(167, 36);
			this.labelDigit6.Name = "labelDigit6";
			this.labelDigit6.Size = new System.Drawing.Size(14, 20);
			this.labelDigit6.TabIndex = 131;
			this.labelDigit6.Tag = "6";
			this.labelDigit6.Text = "3";
			this.labelDigit6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit3
			// 
			this.labelDigit3.BackColor = System.Drawing.Color.White;
			this.labelDigit3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit3.Location = new System.Drawing.Point(215, 36);
			this.labelDigit3.Name = "labelDigit3";
			this.labelDigit3.Size = new System.Drawing.Size(14, 20);
			this.labelDigit3.TabIndex = 134;
			this.labelDigit3.Tag = "3";
			this.labelDigit3.Text = "3";
			this.labelDigit3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit4
			// 
			this.labelDigit4.BackColor = System.Drawing.Color.White;
			this.labelDigit4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit4.Location = new System.Drawing.Point(202, 36);
			this.labelDigit4.Name = "labelDigit4";
			this.labelDigit4.Size = new System.Drawing.Size(14, 20);
			this.labelDigit4.TabIndex = 133;
			this.labelDigit4.Tag = "4";
			this.labelDigit4.Text = "2";
			this.labelDigit4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit5
			// 
			this.labelDigit5.BackColor = System.Drawing.Color.White;
			this.labelDigit5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit5.Location = new System.Drawing.Point(189, 36);
			this.labelDigit5.Name = "labelDigit5";
			this.labelDigit5.Size = new System.Drawing.Size(14, 20);
			this.labelDigit5.TabIndex = 132;
			this.labelDigit5.Tag = "5";
			this.labelDigit5.Text = "1";
			this.labelDigit5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit0
			// 
			this.labelDigit0.BackColor = System.Drawing.Color.White;
			this.labelDigit0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit0.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit0.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit0.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit0.Location = new System.Drawing.Point(263, 36);
			this.labelDigit0.Name = "labelDigit0";
			this.labelDigit0.Size = new System.Drawing.Size(14, 20);
			this.labelDigit0.TabIndex = 137;
			this.labelDigit0.Tag = "0";
			this.labelDigit0.Text = "3";
			this.labelDigit0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit1
			// 
			this.labelDigit1.BackColor = System.Drawing.Color.White;
			this.labelDigit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit1.Location = new System.Drawing.Point(250, 36);
			this.labelDigit1.Name = "labelDigit1";
			this.labelDigit1.Size = new System.Drawing.Size(14, 20);
			this.labelDigit1.TabIndex = 136;
			this.labelDigit1.Tag = "1";
			this.labelDigit1.Text = "2";
			this.labelDigit1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelDigit2
			// 
			this.labelDigit2.BackColor = System.Drawing.Color.White;
			this.labelDigit2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelDigit2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.labelDigit2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDigit2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelDigit2.Location = new System.Drawing.Point(237, 36);
			this.labelDigit2.Name = "labelDigit2";
			this.labelDigit2.Size = new System.Drawing.Size(14, 20);
			this.labelDigit2.TabIndex = 135;
			this.labelDigit2.Tag = "2";
			this.labelDigit2.Text = "1";
			this.labelDigit2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelComma1
			// 
			this.labelComma1.BackColor = System.Drawing.Color.Transparent;
			this.labelComma1.Cursor = System.Windows.Forms.Cursors.Default;
			this.labelComma1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelComma1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelComma1.Location = new System.Drawing.Point(181, 36);
			this.labelComma1.Name = "labelComma1";
			this.labelComma1.Size = new System.Drawing.Size(8, 20);
			this.labelComma1.TabIndex = 138;
			this.labelComma1.Tag = "7";
			this.labelComma1.Text = ",";
			this.labelComma1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelComma2
			// 
			this.labelComma2.BackColor = System.Drawing.Color.Transparent;
			this.labelComma2.Cursor = System.Windows.Forms.Cursors.Default;
			this.labelComma2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelComma2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelComma2.Location = new System.Drawing.Point(229, 36);
			this.labelComma2.Name = "labelComma2";
			this.labelComma2.Size = new System.Drawing.Size(8, 20);
			this.labelComma2.TabIndex = 139;
			this.labelComma2.Tag = "7";
			this.labelComma2.Text = ",";
			this.labelComma2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// checkBoxRound
			// 
			this.checkBoxRound.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxRound.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxRound.Location = new System.Drawing.Point(32, 39);
			this.checkBoxRound.Name = "checkBoxRound";
			this.checkBoxRound.Size = new System.Drawing.Size(14, 14);
			this.checkBoxRound.TabIndex = 140;
			this.checkBoxRound.CheckedChanged += new System.EventHandler(this.checkBoxRound_CheckedChanged);
			// 
			// checkBoxGraph
			// 
			this.checkBoxGraph.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxGraph.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxGraph.Location = new System.Drawing.Point(32, 99);
			this.checkBoxGraph.Name = "checkBoxGraph";
			this.checkBoxGraph.Size = new System.Drawing.Size(14, 14);
			this.checkBoxGraph.TabIndex = 143;
			// 
			// labelGraph
			// 
			this.labelGraph.BackColor = System.Drawing.Color.Transparent;
			this.labelGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelGraph.Location = new System.Drawing.Point(48, 97);
			this.labelGraph.Name = "labelGraph";
			this.labelGraph.Size = new System.Drawing.Size(192, 16);
			this.labelGraph.TabIndex = 141;
			this.labelGraph.Text = "Relate assets with same name";
			this.labelGraph.Click += new System.EventHandler(this.labelGraph_Click);
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label3.Location = new System.Drawing.Point(10, 71);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(198, 24);
			this.label3.TabIndex = 142;
			this.label3.Text = "Graphing 10, 71";
			// 
			// checkBoxCostTabs
			// 
			this.checkBoxCostTabs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.checkBoxCostTabs.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxCostTabs.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxCostTabs.Location = new System.Drawing.Point(32, 492);
			this.checkBoxCostTabs.Name = "checkBoxCostTabs";
			this.checkBoxCostTabs.Size = new System.Drawing.Size(14, 14);
			this.checkBoxCostTabs.TabIndex = 146;
			// 
			// labelCostTabs
			// 
			this.labelCostTabs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCostTabs.BackColor = System.Drawing.Color.Transparent;
			this.labelCostTabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelCostTabs.Location = new System.Drawing.Point(48, 490);
			this.labelCostTabs.Name = "labelCostTabs";
			this.labelCostTabs.Size = new System.Drawing.Size(168, 16);
			this.labelCostTabs.TabIndex = 144;
			this.labelCostTabs.Text = "Show Cost Allocation tabs";
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label4.Location = new System.Drawing.Point(10, 464);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(198, 24);
			this.label4.TabIndex = 145;
			this.label4.Text = "Display";
			// 
			// checkBoxFacilityValuation
			// 
			this.checkBoxFacilityValuation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.checkBoxFacilityValuation.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxFacilityValuation.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxFacilityValuation.Location = new System.Drawing.Point(32, 512);
			this.checkBoxFacilityValuation.Name = "checkBoxFacilityValuation";
			this.checkBoxFacilityValuation.Size = new System.Drawing.Size(14, 14);
			this.checkBoxFacilityValuation.TabIndex = 148;
			// 
			// labelFacilityValuation
			// 
			this.labelFacilityValuation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelFacilityValuation.BackColor = System.Drawing.Color.Transparent;
			this.labelFacilityValuation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelFacilityValuation.Location = new System.Drawing.Point(48, 510);
			this.labelFacilityValuation.Name = "labelFacilityValuation";
			this.labelFacilityValuation.Size = new System.Drawing.Size(232, 16);
			this.labelFacilityValuation.TabIndex = 147;
			this.labelFacilityValuation.Text = "Show Facility Valuation Options data";
			// 
			// buttonReadOnlyColorPicker
			// 
			this.buttonReadOnlyColorPicker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonReadOnlyColorPicker.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonReadOnlyColorPicker.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonReadOnlyColorPicker.Location = new System.Drawing.Point(293, 389);
			this.buttonReadOnlyColorPicker.Name = "buttonReadOnlyColorPicker";
			this.buttonReadOnlyColorPicker.Size = new System.Drawing.Size(72, 23);
			this.buttonReadOnlyColorPicker.TabIndex = 155;
			this.buttonReadOnlyColorPicker.Text = "Select Color";
			this.buttonReadOnlyColorPicker.Click += new System.EventHandler(this.buttonReadOnlyColorPicker_Click);
			// 
			// textBoxReadOnlyContainer
			// 
			this.textBoxReadOnlyContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxReadOnlyContainer.Enabled = false;
			this.textBoxReadOnlyContainer.Location = new System.Drawing.Point(164, 382);
			this.textBoxReadOnlyContainer.Multiline = true;
			this.textBoxReadOnlyContainer.Name = "textBoxReadOnlyContainer";
			this.textBoxReadOnlyContainer.ReadOnly = true;
			this.textBoxReadOnlyContainer.Size = new System.Drawing.Size(120, 64);
			this.textBoxReadOnlyContainer.TabIndex = 158;
			this.textBoxReadOnlyContainer.TabStop = false;
			this.textBoxReadOnlyContainer.Text = "";
			// 
			// textBoxReadOnly
			// 
			this.textBoxReadOnly.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxReadOnly.BackColor = System.Drawing.SystemColors.Control;
			this.textBoxReadOnly.Location = new System.Drawing.Point(188, 404);
			this.textBoxReadOnly.Name = "textBoxReadOnly";
			this.textBoxReadOnly.ReadOnly = true;
			this.textBoxReadOnly.Size = new System.Drawing.Size(72, 20);
			this.textBoxReadOnly.TabIndex = 159;
			this.textBoxReadOnly.TabStop = false;
			this.textBoxReadOnly.Text = "";
			this.textBoxReadOnly.DoubleClick += new System.EventHandler(this.buttonReadOnlyColorPicker_Click);
			// 
			// buttonReadOnlyColorReset
			// 
			this.buttonReadOnlyColorReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonReadOnlyColorReset.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonReadOnlyColorReset.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonReadOnlyColorReset.Location = new System.Drawing.Point(293, 416);
			this.buttonReadOnlyColorReset.Name = "buttonReadOnlyColorReset";
			this.buttonReadOnlyColorReset.Size = new System.Drawing.Size(72, 23);
			this.buttonReadOnlyColorReset.TabIndex = 160;
			this.buttonReadOnlyColorReset.Text = "Reset Color";
			this.buttonReadOnlyColorReset.Click += new System.EventHandler(this.buttonReadOnlyColorReset_Click);
			// 
			// labelFormSize
			// 
			this.labelFormSize.Location = new System.Drawing.Point(392, 32);
			this.labelFormSize.Name = "labelFormSize";
			this.labelFormSize.TabIndex = 161;
			this.labelFormSize.Text = "form size: 408, 288";
			this.labelFormSize.Visible = false;
			// 
			// checkBoxReadOnlyColor
			// 
			this.checkBoxReadOnlyColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.checkBoxReadOnlyColor.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxReadOnlyColor.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxReadOnlyColor.Location = new System.Drawing.Point(32, 383);
			this.checkBoxReadOnlyColor.Name = "checkBoxReadOnlyColor";
			this.checkBoxReadOnlyColor.Size = new System.Drawing.Size(14, 14);
			this.checkBoxReadOnlyColor.TabIndex = 163;
			this.checkBoxReadOnlyColor.CheckedChanged += new System.EventHandler(this.checkBoxReadOnlyColor_CheckedChanged);
			// 
			// labelReadOnlyColor
			// 
			this.labelReadOnlyColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelReadOnlyColor.BackColor = System.Drawing.Color.Transparent;
			this.labelReadOnlyColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReadOnlyColor.Location = new System.Drawing.Point(48, 381);
			this.labelReadOnlyColor.Name = "labelReadOnlyColor";
			this.labelReadOnlyColor.Size = new System.Drawing.Size(160, 16);
			this.labelReadOnlyColor.TabIndex = 162;
			this.labelReadOnlyColor.Text = "Use custom color";
			this.labelReadOnlyColor.Click += new System.EventHandler(this.labelReadOnlyColor_Click);
			// 
			// label5
			// 
			this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label5.Location = new System.Drawing.Point(10, 355);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(248, 24);
			this.label5.TabIndex = 164;
			this.label5.Text = "Read-only Text Box  Color";
			// 
			// checkBoxRetired
			// 
			this.checkBoxRetired.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxRetired.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxRetired.Location = new System.Drawing.Point(32, 159);
			this.checkBoxRetired.Name = "checkBoxRetired";
			this.checkBoxRetired.Size = new System.Drawing.Size(14, 14);
			this.checkBoxRetired.TabIndex = 167;
			// 
			// labelRetired
			// 
			this.labelRetired.BackColor = System.Drawing.Color.Transparent;
			this.labelRetired.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelRetired.Location = new System.Drawing.Point(48, 157);
			this.labelRetired.Name = "labelRetired";
			this.labelRetired.Size = new System.Drawing.Size(432, 16);
			this.labelRetired.TabIndex = 165;
			this.labelRetired.Text = "Include Retired Asset Replacement and Rehabilitation Costs in Reports";
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label6.Location = new System.Drawing.Point(10, 131);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(600, 24);
			this.label6.TabIndex = 166;
			this.label6.Text = "Reports: Retired Assets";
			// 
			// labelReadOnlyRgb
			// 
			this.labelReadOnlyRgb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelReadOnlyRgb.BackColor = System.Drawing.Color.Transparent;
			this.labelReadOnlyRgb.Location = new System.Drawing.Point(424, 384);
			this.labelReadOnlyRgb.Name = "labelReadOnlyRgb";
			this.labelReadOnlyRgb.TabIndex = 168;
			this.labelReadOnlyRgb.Visible = false;
			// 
			// labelReadOnly
			// 
			this.labelReadOnly.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelReadOnly.BackColor = System.Drawing.Color.White;
			this.labelReadOnly.Location = new System.Drawing.Point(190, 406);
			this.labelReadOnly.Name = "labelReadOnly";
			this.labelReadOnly.Size = new System.Drawing.Size(68, 16);
			this.labelReadOnly.TabIndex = 172;
			this.labelReadOnly.Text = "Read only";
			this.labelReadOnly.Click += new System.EventHandler(this.labelReadOnly_Click);
			// 
			// checkBoxFacilityCrit
			// 
			this.checkBoxFacilityCrit.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxFacilityCrit.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxFacilityCrit.Location = new System.Drawing.Point(32, 219);
			this.checkBoxFacilityCrit.Name = "checkBoxFacilityCrit";
			this.checkBoxFacilityCrit.Size = new System.Drawing.Size(14, 14);
			this.checkBoxFacilityCrit.TabIndex = 175;
			// 
			// labelFacilityCrit
			// 
			this.labelFacilityCrit.BackColor = System.Drawing.Color.Transparent;
			this.labelFacilityCrit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelFacilityCrit.Location = new System.Drawing.Point(48, 217);
			this.labelFacilityCrit.Name = "labelFacilityCrit";
			this.labelFacilityCrit.Size = new System.Drawing.Size(560, 16);
			this.labelFacilityCrit.TabIndex = 173;
			this.labelFacilityCrit.Text = "Utilize user-entered Facility Criticality Weighting Factors in asset Criticality " +
				"calculations";
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label8.Location = new System.Drawing.Point(10, 191);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(600, 24);
			this.label8.TabIndex = 174;
			this.label8.Text = "Facility Criticality Weighting Factor";
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(64, 238);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(424, 48);
			this.label7.TabIndex = 177;
			this.label7.Text = "If unselected, or upon initial WAM installation, a default value of 1 is used for" +
				" all facilities. User-entered values are stored so that the factor can be toggle" +
				"d on and off without loss of input data.";
			// 
			// checkBoxPhotoFileName
			// 
			this.checkBoxPhotoFileName.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxPhotoFileName.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxPhotoFileName.Location = new System.Drawing.Point(32, 322);
			this.checkBoxPhotoFileName.Name = "checkBoxPhotoFileName";
			this.checkBoxPhotoFileName.Size = new System.Drawing.Size(14, 14);
			this.checkBoxPhotoFileName.TabIndex = 180;
			// 
			// labelPhotoFileName
			// 
			this.labelPhotoFileName.BackColor = System.Drawing.Color.Transparent;
			this.labelPhotoFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelPhotoFileName.Location = new System.Drawing.Point(48, 320);
			this.labelPhotoFileName.Name = "labelPhotoFileName";
			this.labelPhotoFileName.Size = new System.Drawing.Size(432, 16);
			this.labelPhotoFileName.TabIndex = 178;
			this.labelPhotoFileName.Text = "Let WAM automatically create photo file names";
			// 
			// label9
			// 
			this.label9.BackColor = System.Drawing.Color.Transparent;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(46)), ((System.Byte)(46)), ((System.Byte)(46)));
			this.label9.Location = new System.Drawing.Point(10, 296);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(600, 24);
			this.label9.TabIndex = 179;
			this.label9.Text = "Photos";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel1.Location = new System.Drawing.Point(8, 63);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(688, 1);
			this.panel1.TabIndex = 183;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel2.Location = new System.Drawing.Point(8, 123);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(688, 1);
			this.panel2.TabIndex = 184;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel3.Location = new System.Drawing.Point(8, 180);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(688, 1);
			this.panel3.TabIndex = 185;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel4.Location = new System.Drawing.Point(8, 288);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(688, 1);
			this.panel4.TabIndex = 186;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel5.Location = new System.Drawing.Point(8, 347);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(688, 1);
			this.panel5.TabIndex = 187;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(196)), ((System.Byte)(211)), ((System.Byte)(221)));
			this.panel6.Location = new System.Drawing.Point(8, 456);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(688, 1);
			this.panel6.TabIndex = 188;
			// 
			// OptionsMain
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(706, 552);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.checkBoxPhotoFileName);
			this.Controls.Add(this.labelPhotoFileName);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.checkBoxFacilityCrit);
			this.Controls.Add(this.labelFacilityCrit);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.labelReadOnly);
			this.Controls.Add(this.labelReadOnlyRgb);
			this.Controls.Add(this.checkBoxRetired);
			this.Controls.Add(this.labelRetired);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.buttonReadOnlyColorPicker);
			this.Controls.Add(this.buttonReadOnlyColorReset);
			this.Controls.Add(this.textBoxReadOnly);
			this.Controls.Add(this.textBoxReadOnlyContainer);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.checkBoxReadOnlyColor);
			this.Controls.Add(this.labelFormSize);
			this.Controls.Add(this.checkBoxFacilityValuation);
			this.Controls.Add(this.labelFacilityValuation);
			this.Controls.Add(this.checkBoxCostTabs);
			this.Controls.Add(this.labelCostTabs);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.checkBoxGraph);
			this.Controls.Add(this.labelGraph);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.checkBoxRound);
			this.Controls.Add(this.labelComma2);
			this.Controls.Add(this.labelComma1);
			this.Controls.Add(this.labelDigit0);
			this.Controls.Add(this.labelDigit1);
			this.Controls.Add(this.labelDigit2);
			this.Controls.Add(this.labelDigit3);
			this.Controls.Add(this.labelDigit4);
			this.Controls.Add(this.labelDigit5);
			this.Controls.Add(this.labelDigit6);
			this.Controls.Add(this.labelDigit7);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.labelDigit8);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelRound);
			this.Controls.Add(this.labelReadOnlyColor);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "Preferences.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "OptionsMain";
			this.helpProvider1.SetShowHelp(this, true);
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Preferences";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReportTemplateOptions_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			this.Text = "Preferences";

			//mam 050806
			InitializeControls();

			LoadPreferences();

			base.OnLoad(e);
		}

		private void InitializeControls()
		{
			this.labelCostTabs.Click += new System.EventHandler(this.labelCostTabs_Click);
			this.labelFacilityValuation.Click += new System.EventHandler(this.labelFacilityValuation_Click);

			//mam 01222012
			this.labelRetired.Click += new System.EventHandler(this.labelRetired_Click);
			this.labelFacilityCrit.Click += new System.EventHandler(this.labelFacilityCrit_Click);

			//mam 03202012
			this.labelPhotoFileName.Click += new System.EventHandler(this.labelPhotoFileName_Click);
		}

		private void LoadPreferences()
		{
			checkBoxRound.Checked = WAM.Common.Globals.AllowRounding;
			roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			checkBoxRound_CheckedChanged(null, null);
			SetLabelProperties();

			checkBoxGraph.Checked = WAM.Common.Globals.AllowGraphNameMatching;
			checkBoxCostTabs.Checked = WAM.Common.Globals.ShowCostTab;
			checkBoxFacilityValuation.Checked = WAM.Common.Globals.ShowFacilityValuationTab;

			//mam 01042012
			checkBoxRetired.Checked = !WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets;

			//mam 01042012
			checkBoxReadOnlyColor.Checked = WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric;
			buttonReadOnlyColorPicker.Enabled = checkBoxReadOnlyColor.Checked;
			buttonReadOnlyColorReset.Enabled = checkBoxReadOnlyColor.Checked;
			//if (checkBoxReadOnlyColor.Checked)
			//{
				textBoxReadOnly.BackColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
				labelReadOnly.BackColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			//}

			//mam 01222012
			checkBoxFacilityCrit.Checked = WAM.Common.Globals.ApplyFacilityCriticalityFactor;

			//mam 03202012
			checkBoxPhotoFileName.Checked = WAM.Common.Globals.AllowWamToCreatePhotoFileNames;
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			WAM.Common.Globals.AllowRounding = checkBoxRound.Checked;
			WAM.Common.Globals.AllowRoundingDigit = roundDigit;

			WAM.Common.Globals.AllowGraphNameMatching = checkBoxGraph.Checked;
			WAM.Common.Globals.ShowCostTab = checkBoxCostTabs.Checked;
			WAM.Common.Globals.ShowFacilityValuationTab = checkBoxFacilityValuation.Checked;

			//********************************
			//mam 01042012

			//retired assets
			WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets = !checkBoxRetired.Checked;

			//read-only text box color
			WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames = checkBoxReadOnlyColor.Checked;
			WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric = checkBoxReadOnlyColor.Checked;
			WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen = checkBoxReadOnlyColor.Checked;

			//if (checkBoxReadOnlyColor.Checked)
			{
				//WAM.Common.Globals.ReadOnlyBackgroundColorNumeric = textBoxReadOnly.BackColor;
				//WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames = textBoxReadOnly.BackColor;
				WAM.Common.Globals.ReadOnlyBackgroundColorNumeric = labelReadOnly.BackColor;
				WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames = labelReadOnly.BackColor;
			}
			
			//mam 01222012
			//facility criticality
			WAM.Common.Globals.ApplyFacilityCriticalityFactor = checkBoxFacilityCrit.Checked;

			//mam 03202012
			WAM.Common.Globals.AllowWamToCreatePhotoFileNames = checkBoxPhotoFileName.Checked;

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);

			//System.Drawing.Drawing2D.GraphicsPath grPath = new System.Drawing.Drawing2D.GraphicsPath();
			//grPath.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);
			//this.Region = new System.Drawing.Region(grPath);
			//base.OnPaint(e);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "PreferencesHeader.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "PreferencesHeader.htm");
		}

		private void ReportTemplateOptions_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void labelRound_Click(object sender, System.EventArgs e)
		{
			checkBoxRound.Checked = !checkBoxRound.Checked;
		}

		private void labelGraph_Click(object sender, System.EventArgs e)
		{
			checkBoxGraph.Checked = !checkBoxGraph.Checked;
		}

		private void labelCostTabs_Click(object sender, System.EventArgs e)
		{
			checkBoxCostTabs.Checked = !checkBoxCostTabs.Checked;
		}

		private void labelFacilityValuation_Click(object sender, System.EventArgs e)
		{
			checkBoxFacilityValuation.Checked = !checkBoxFacilityValuation.Checked;
		}

		private void checkBoxRound_CheckedChanged(object sender, System.EventArgs e)
		{
			bool setEnabled = checkBoxRound.Checked;

			labelDigit0.Enabled = setEnabled;
			labelDigit1.Enabled = setEnabled;
			labelDigit2.Enabled = setEnabled;
			labelDigit3.Enabled = setEnabled;
			labelDigit4.Enabled = setEnabled;
			labelDigit5.Enabled = setEnabled;
			labelDigit6.Enabled = setEnabled;
			labelDigit7.Enabled = setEnabled;
			labelDigit8.Enabled = setEnabled;
		}

		private void labelDigitHandler_Click(object sender, System.EventArgs e)
		{
			roundDigit = Convert.ToInt32(((System.Windows.Forms.Label) sender).Tag.ToString());
			SetLabelProperties();
		}

		private void SetLabelProperties()
		{
			labelDigit0.BackColor = System.Drawing.Color.White;
			labelDigit1.BackColor = System.Drawing.Color.White;
			labelDigit2.BackColor = System.Drawing.Color.White;
			labelDigit3.BackColor = System.Drawing.Color.White;
			labelDigit4.BackColor = System.Drawing.Color.White;
			labelDigit5.BackColor = System.Drawing.Color.White;
			labelDigit6.BackColor = System.Drawing.Color.White;
			labelDigit7.BackColor = System.Drawing.Color.White;
			labelDigit8.BackColor = System.Drawing.Color.White;

			labelDigit0.Text = "8";
			labelDigit1.Text = "7";
			labelDigit2.Text = "6";
			labelDigit3.Text = "8";
			labelDigit4.Text = "7";
			labelDigit5.Text = "6";
			labelDigit6.Text = "8";
			labelDigit7.Text = "7";
			labelDigit8.Text = "6";
			
			//if (roundDigit == 1)
			//	return;

			string countLower = "";
			string countUpper = "";

			for (int i = 0; i < roundDigit; i++)
			{
				countLower += i.ToString();
			}
			for (int i = roundDigit; i <= 8; i++)
			{
				countUpper += i.ToString();
			}
			//MessageBox.Show("countLower = " + countLower.ToString());
			//MessageBox.Show("countUpper = " + countUpper.ToString());

			foreach (Control control in this.Controls)
			{
				if (control.Name.StartsWith("labelDigit"))
				{
					string charLast = control.Name.Substring(control.Name.Length - 1, 1);
					
					//mam 050806 = change the backcolor when the roundDigit is zero
					//if (control.Name.Equals("labelDigit" + roundDigit.ToString()) && roundDigit > 0)
					if (control.Name.Equals("labelDigit" + roundDigit.ToString()))
					{
						control.BackColor = System.Drawing.Color.FromArgb(191, 217, 244);

						if (roundDigit > 0)
						{
							control.Text = Convert.ToString(Convert.ToInt32(control.Text) + 1);
						}
					}

					if (countLower.IndexOf(charLast) > -1)
					{
						control.Text = "0";
					}
					else
					{
					}
				}
			}
		}

		//mam 01042012
		private void buttonReadOnlyColorPicker_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.ColorDialog colorDialog = new ColorDialog();
		
			// disables custom color button
			//colorDialog.AllowFullOpen = false;
		
			// allows the user to get help (the default is false)
			//colorDialog.ShowHelp = true ;
		
			// sets the initial color to the current text color.
			//colorDialog.Color = textBoxReadOnly.BackColor;
			colorDialog.Color = labelReadOnly.BackColor;
		
			if (colorDialog.ShowDialog() == DialogResult.OK)
			{
				textBoxReadOnly.BackColor =  colorDialog.Color;
				labelReadOnly.BackColor = colorDialog.Color;
				string colorRgb = WAM.Common.CommonTasks.ColorConvertToRgb(colorDialog.Color);
				labelReadOnlyRgb.Text = colorRgb;
			}
		}

		//mam 01042012
		private void buttonReadOnlyColorReset_Click(object sender, System.EventArgs e)
		{
			textBoxReadOnly.BackColor = System.Drawing.SystemColors.Control;
			labelReadOnly.BackColor = System.Drawing.SystemColors.Control;
		}

		//mam 01042012
		private void checkBoxReadOnlyColor_CheckedChanged(object sender, System.EventArgs e)
		{
			//mam 01042012
			buttonReadOnlyColorPicker.Enabled = checkBoxReadOnlyColor.Checked;
			buttonReadOnlyColorReset.Enabled = checkBoxReadOnlyColor.Checked;
			//if (checkBoxReadOnlyColor.Checked)
			//{
			//	textBoxReadOnly.BackColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			//}
			//else
			//{
			//	textBoxReadOnly.BackColor = System.Drawing.SystemColors.Control;
			//}
		}

		//mam 01042012
		private void labelRetired_Click(object sender, System.EventArgs e)
		{
			checkBoxRetired.Checked = !checkBoxRetired.Checked;
		}

		//mam 01042012
		private void labelReadOnlyColor_Click(object sender, System.EventArgs e)
		{
			checkBoxReadOnlyColor.Checked = !checkBoxReadOnlyColor.Checked;
		}

		//mam 01042012
		private void labelReadOnly_Click(object sender, System.EventArgs e)
		{
			buttonReadOnlyColorPicker_Click(null, null);
		}

		//mam 01222012
		private void labelFacilityCrit_Click(object sender, System.EventArgs e)
		{
			checkBoxFacilityCrit.Checked = !checkBoxFacilityCrit.Checked;
		}

		//mam 03202012
		private void labelPhotoFileName_Click(object sender, System.EventArgs e)
		{
			checkBoxPhotoFileName.Checked = !checkBoxPhotoFileName.Checked;
		}
	}
}
