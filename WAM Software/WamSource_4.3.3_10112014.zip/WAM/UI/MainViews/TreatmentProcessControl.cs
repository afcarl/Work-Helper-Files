using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI.MainViews
{
	/// <summary>
	/// Summary description for TreatmentProcessControl.
	/// </summary>
	public class TreatmentProcessControl : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/

		private	TreatmentProcess m_process = null;

		//mam 050806
		string tabPageSelectedName = string.Empty;
		private TabPage tabPageMainHold = new TabPage();
		private TabPage tabPageAssessmentHold = new TabPage();
		private TabPage tabPageCostAllocationHold = new TabPage();
		private TabPage tabPagePhotoHold = new TabPage();

		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private WAM.UI.PhotoControl pictureBox;
		private System.Windows.Forms.Button buttonBrowsePhoto;
		private System.Windows.Forms.TextBox textBoxPhotoCaption;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private WAM.UI.Grids.ComponentGrid componentGrid1;
		private System.Windows.Forms.TabPage tabPageAssessment;
		private System.Windows.Forms.TextBox textBoxAssessmentComments;
		private System.Windows.Forms.Label label7;
		private WAM.UI.Grids.ComponentAssessmentGrid gridAssessment;
		private System.Windows.Forms.TabPage tabPageAllocation;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxAllocComments;
		private WAM.UI.Grids.CostAllocationGrid gridAllocation;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBoxPhotoFileName;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion ***** Member Variables *****/

		public TreatmentProcessControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.componentGrid1 = new WAM.UI.Grids.ComponentGrid();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tabPageAssessment = new System.Windows.Forms.TabPage();
			this.textBoxAssessmentComments = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.gridAssessment = new WAM.UI.Grids.ComponentAssessmentGrid();
			this.tabPageAllocation = new System.Windows.Forms.TabPage();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxAllocComments = new System.Windows.Forms.TextBox();
			this.gridAllocation = new WAM.UI.Grids.CostAllocationGrid();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.label8 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.textBoxPhotoFileName = new System.Windows.Forms.TextBox();
			this.pictureBox = new WAM.UI.PhotoControl();
			this.buttonBrowsePhoto = new System.Windows.Forms.Button();
			this.textBoxPhotoCaption = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.labelLocked = new System.Windows.Forms.Label();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			this.tabPageAssessment.SuspendLayout();
			this.tabPageAllocation.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.panelLocked.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageAssessment);
			this.tabControl.Controls.Add(this.tabPageAllocation);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.helpProvider1.SetHelpKeyword(this.tabControl, "ProcessTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabControl, System.Windows.Forms.HelpNavigator.Topic);
			this.tabControl.ItemSize = new System.Drawing.Size(110, 18);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.helpProvider1.SetShowHelp(this.tabControl, true);
			this.tabControl.Size = new System.Drawing.Size(608, 332);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl.TabIndex = 6;
			this.tabControl.Leave += new System.EventHandler(this.textBoxComments_Leave);
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.componentGrid1);
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.label4);
			this.helpProvider1.SetHelpKeyword(this.tabPageMain, "ProcessTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageMain, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.helpProvider1.SetShowHelp(this.tabPageMain, true);
			this.tabPageMain.Size = new System.Drawing.Size(600, 306);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// componentGrid1
			// 
			this.componentGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.componentGrid1.GridStyle = WAM.UI.Grids.ComponentGrid.GridType.MajorComponents;
			this.helpProvider1.SetHelpKeyword(this.componentGrid1, "ProcessTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.componentGrid1, System.Windows.Forms.HelpNavigator.Topic);
			this.componentGrid1.Location = new System.Drawing.Point(4, 4);
			this.componentGrid1.Name = "componentGrid1";
			this.helpProvider1.SetShowHelp(this.componentGrid1, true);
			this.componentGrid1.Size = new System.Drawing.Size(592, 180);
			this.componentGrid1.TabIndex = 7;
			// 
			// textBoxComments
			// 
			this.textBoxComments.AcceptsReturn = true;
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxComments.TabIndex = 8;
			this.textBoxComments.Text = "";
			this.textBoxComments.TextChanged += new System.EventHandler(this.textBoxComments_TextChanged);
			this.textBoxComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.Location = new System.Drawing.Point(4, 188);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Comments:";
			// 
			// tabPageAssessment
			// 
			this.tabPageAssessment.Controls.Add(this.textBoxAssessmentComments);
			this.tabPageAssessment.Controls.Add(this.label7);
			this.tabPageAssessment.Controls.Add(this.gridAssessment);
			this.helpProvider1.SetHelpKeyword(this.tabPageAssessment, "ProcessTabAssessment.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageAssessment, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageAssessment.Location = new System.Drawing.Point(4, 22);
			this.tabPageAssessment.Name = "tabPageAssessment";
			this.helpProvider1.SetShowHelp(this.tabPageAssessment, true);
			this.tabPageAssessment.Size = new System.Drawing.Size(600, 306);
			this.tabPageAssessment.TabIndex = 2;
			this.tabPageAssessment.Text = "Assessment";
			// 
			// textBoxAssessmentComments
			// 
			this.textBoxAssessmentComments.AcceptsReturn = true;
			this.textBoxAssessmentComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAssessmentComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxAssessmentComments.Multiline = true;
			this.textBoxAssessmentComments.Name = "textBoxAssessmentComments";
			this.textBoxAssessmentComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAssessmentComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxAssessmentComments.TabIndex = 5;
			this.textBoxAssessmentComments.Text = "";
			this.textBoxAssessmentComments.TextChanged += new System.EventHandler(this.textBoxAssessmentComments_TextChanged);
			this.textBoxAssessmentComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label7
			// 
			this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label7.Location = new System.Drawing.Point(4, 188);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 16);
			this.label7.TabIndex = 4;
			this.label7.Text = "Comments:";
			// 
			// gridAssessment
			// 
			this.gridAssessment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.helpProvider1.SetHelpKeyword(this.gridAssessment, "ProcessTabAssessment.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAssessment, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAssessment.Location = new System.Drawing.Point(4, 4);
			this.gridAssessment.Name = "gridAssessment";
			this.helpProvider1.SetShowHelp(this.gridAssessment, true);
			this.gridAssessment.Size = new System.Drawing.Size(592, 180);
			this.gridAssessment.TabIndex = 3;
			// 
			// tabPageAllocation
			// 
			this.tabPageAllocation.Controls.Add(this.label16);
			this.tabPageAllocation.Controls.Add(this.textBoxAllocComments);
			this.tabPageAllocation.Controls.Add(this.gridAllocation);
			this.helpProvider1.SetHelpKeyword(this.tabPageAllocation, "ProcessTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageAllocation.Location = new System.Drawing.Point(4, 22);
			this.tabPageAllocation.Name = "tabPageAllocation";
			this.helpProvider1.SetShowHelp(this.tabPageAllocation, true);
			this.tabPageAllocation.Size = new System.Drawing.Size(600, 306);
			this.tabPageAllocation.TabIndex = 3;
			this.tabPageAllocation.Text = "Cost Allocation by %";
			// 
			// label16
			// 
			this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label16.Location = new System.Drawing.Point(4, 188);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(100, 16);
			this.label16.TabIndex = 8;
			this.label16.Text = "Comments:";
			// 
			// textBoxAllocComments
			// 
			this.textBoxAllocComments.AcceptsReturn = true;
			this.textBoxAllocComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAllocComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxAllocComments.Multiline = true;
			this.textBoxAllocComments.Name = "textBoxAllocComments";
			this.textBoxAllocComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAllocComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxAllocComments.TabIndex = 7;
			this.textBoxAllocComments.Text = "";
			this.textBoxAllocComments.TextChanged += new System.EventHandler(this.textBoxAllocComments_TextChanged);
			this.textBoxAllocComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// gridAllocation
			// 
			this.gridAllocation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAllocation.GridStyle = WAM.UI.Grids.CostAllocationGrid.GridType.MajorComponents;
			this.helpProvider1.SetHelpKeyword(this.gridAllocation, "ProcessTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAllocation.Location = new System.Drawing.Point(4, 4);
			this.gridAllocation.Name = "gridAllocation";
			this.helpProvider1.SetShowHelp(this.gridAllocation, true);
			this.gridAllocation.Size = new System.Drawing.Size(592, 180);
			this.gridAllocation.TabIndex = 6;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.label8);
			this.tabPagePhoto.Controls.Add(this.label6);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoFileName);
			this.tabPagePhoto.Controls.Add(this.pictureBox);
			this.tabPagePhoto.Controls.Add(this.buttonBrowsePhoto);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption);
			this.helpProvider1.SetHelpKeyword(this.tabPagePhoto, "ProcessTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPagePhoto, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.helpProvider1.SetShowHelp(this.tabPagePhoto, true);
			this.tabPagePhoto.Size = new System.Drawing.Size(600, 306);
			this.tabPagePhoto.TabIndex = 1;
			this.tabPagePhoto.Text = "Photo";
			this.tabPagePhoto.Visible = false;
			// 
			// label8
			// 
			this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Location = new System.Drawing.Point(4, 235);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(60, 20);
			this.label8.TabIndex = 20;
			this.label8.Text = "Caption:";
			// 
			// label6
			// 
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Location = new System.Drawing.Point(4, 254);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(60, 20);
			this.label6.TabIndex = 19;
			this.label6.Text = "File Name:";
			// 
			// textBoxPhotoFileName
			// 
			this.textBoxPhotoFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoFileName.Location = new System.Drawing.Point(64, 251);
			this.textBoxPhotoFileName.MaxLength = 255;
			this.textBoxPhotoFileName.Name = "textBoxPhotoFileName";
			this.textBoxPhotoFileName.Size = new System.Drawing.Size(532, 20);
			this.textBoxPhotoFileName.TabIndex = 18;
			this.textBoxPhotoFileName.Text = "";
			// 
			// pictureBox
			// 
			this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.pictureBox, "ProcessTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.pictureBox, System.Windows.Forms.HelpNavigator.Topic);
			this.pictureBox.Image = null;
			this.pictureBox.Location = new System.Drawing.Point(4, 4);
			this.pictureBox.Name = "pictureBox";
			this.helpProvider1.SetShowHelp(this.pictureBox, true);
			this.pictureBox.Size = new System.Drawing.Size(592, 224);
			this.pictureBox.TabIndex = 17;
			// 
			// buttonBrowsePhoto
			// 
			this.buttonBrowsePhoto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonBrowsePhoto.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowsePhoto.Location = new System.Drawing.Point(263, 276);
			this.buttonBrowsePhoto.Name = "buttonBrowsePhoto";
			this.buttonBrowsePhoto.TabIndex = 16;
			this.buttonBrowsePhoto.Text = "Browse...";
			this.buttonBrowsePhoto.Click += new System.EventHandler(this.buttonBrowsePhoto_Click);
			// 
			// textBoxPhotoCaption
			// 
			this.textBoxPhotoCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption.Location = new System.Drawing.Point(64, 232);
			this.textBoxPhotoCaption.MaxLength = 255;
			this.textBoxPhotoCaption.Name = "textBoxPhotoCaption";
			this.textBoxPhotoCaption.Size = new System.Drawing.Size(532, 20);
			this.textBoxPhotoCaption.TabIndex = 15;
			this.textBoxPhotoCaption.Text = "";
			this.textBoxPhotoCaption.TextChanged += new System.EventHandler(this.textBoxPhotoCaption_TextChanged);
			this.textBoxPhotoCaption.Leave += new System.EventHandler(this.textBoxPhotoCaption_Leave);
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.TabStop = false;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 23;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.Text = "";
			this.textBoxProcessName.TextChanged += new System.EventHandler(this.textBoxProcessName_TextChanged);
			this.textBoxProcessName.Leave += new System.EventHandler(this.textBoxProcessName_Leave);
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 5;
			this.textBoxCurrentYear.TabStop = false;
			this.textBoxCurrentYear.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(456, 6);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Current Year:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelLocked
			// 
			this.labelLocked.Location = new System.Drawing.Point(0, 0);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.TabIndex = 0;
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.label5);
			this.panelLocked.Location = new System.Drawing.Point(145, 90);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 24;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.White;
			this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.label5.Location = new System.Drawing.Point(1, 1);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(213, 18);
			this.label5.TabIndex = 16;
			this.label5.Text = "All Data is Locked";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// TreatmentProcessControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(616, 452);
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.textBoxCurrentYear);
			this.helpProvider1.SetHelpKeyword(this, "ProcessScreen.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.TableOfContents);
			this.Name = "TreatmentProcessControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(616, 452);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			this.tabPageAssessment.ResumeLayout(false);
			this.tabPageAllocation.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.panelLocked.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		//mam 03202012
		public void SetProcessNameTextBox(string processName)
		{
			textBoxProcessName.Text = processName;
		}

		public void			SetProcess(TreatmentProcess process)
		{
			//this.componentGrid1.SuspendLayout();
			if (m_process != null)
			{
				// Make sure that the focus is taken off any control that has it
				// so that changed data may be saved
				textBoxProcessName.Focus();
			}

			m_process = process;
			this.componentGrid1.SuspendLayout();

			//mam 01222012 - added argument
			//RefreshData();
			RefreshData(false);

			this.componentGrid1.ResumeLayout();
		}

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			//mam 01222012
			textBoxProcessName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);

			//mam 050806
			tabControl.SuspendLayout();
			tabPageMainHold = tabControl.TabPages[0];
			tabPageAssessmentHold = tabControl.TabPages[1];
			tabPageCostAllocationHold = tabControl.TabPages[2];
			tabPagePhotoHold = tabControl.TabPages[3];
			tabControl.ResumeLayout();

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();

			//mam 03202012
			textBoxPhotoFileName.ReadOnly = true;

			base.OnLoad(e);
		}

		//mam 01222012 - added parameter setToCurrentlySelectedTab
		//public void			RefreshData()
		public void			RefreshData(bool restoreTabSelection)
		{
			//mam 01222012
			int curTab = tabControl.SelectedIndex;

			componentGrid1.SetRootObject(m_process);
			gridAssessment.SetRootObject(m_process);
			gridAllocation.SetRootObject(m_process);

			if (m_process == null)
				return;

			Facility facility = 
				CacheManager.GetFacility(InfoSet.CurrentID, m_process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();
			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = m_process.Name;
			textBoxComments.Text = m_process.Comments;
			textBoxAllocComments.Text = m_process.Comments;
			textBoxAssessmentComments.Text = m_process.Comments;

			//mam 01222012
			//tabControl.SelectedIndex = 0;
			tabControl.SelectedIndex = restoreTabSelection ? curTab : 0;

			//mam - disable controls if infoset is fixed
			SetControls();
			//</mam>

			//mam 050806
			SetTabVisibility();

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();
		}

		//mam 01042012
		public void SetReadOnlyTextBoxBackgroundColorBulk()
		{
			//mam 12192011
			//text boxes that are always read only - numeric
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			Color backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			}

			//mam 12192011
			//text boxes that are always read only - asset names
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames;
			}
			textBoxFacilityName.BackColor = backgroundColor;
			textBoxCurrentYear.BackColor = backgroundColor;

			//mam 0122201 - let's not change the color of the screen - the result varies depending on the selected theme
			//mam 12192011
			//screen background
			//mam 01222012 - always set background color of the screen so we can switch back to Control color if custom color is not being used
			//backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			//if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen)
			//{
			//	backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorScreen;
			//}
			//this.BackColor = backgroundColor;
			//this.tabPageMain.BackColor = backgroundColor;
			//this.tabPageAssessment.BackColor = backgroundColor;
			//this.tabPagePhoto.BackColor = backgroundColor;
			//this.tabPageAllocation.BackColor = backgroundColor;
		}

		private void textBoxProcessName_Leave(object sender, System.EventArgs e)
		{
			if (m_process != null && textBoxProcessName.Text.Length > 0)
			{
				if (string.Compare(m_process.Name, textBoxProcessName.Text) != 0)
				{
					//mam 07072011 - store pre-saved value in case save doesn't work
					string tempVal = m_process.Name;

					// Update the name
					m_process.Name = textBoxProcessName.Text;

					//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
					//m_process.Save();
					if (!SaveData())
					{
						m_process.Name = tempVal;
					}
				}
			}
		}

		private void textBoxComments_Leave(object sender, System.EventArgs e)
		{
			if (m_process == null)
				return;

			bool changed = false;

			//mam 07072011
			string tempVal = string.Empty;
 
			if (sender is TextBox)
			{
				//mam 07072011 - store pre-saved value in case save doesn't work
				tempVal = m_process.Comments;

				if (((TextBox)sender).Text != m_process.Comments)
				{
					m_process.Comments = ((TextBox)sender).Text;
					changed = true;
				}
			}

			if (changed)
			{
				//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_process.Save();
				if (!SaveData())
				{
					m_process.Comments = tempVal;
				}

				// Update all of the comments fields that are NOT 
				// the comments field that sent the notification
				if (!object.ReferenceEquals(sender, textBoxComments))
					textBoxComments.Text = m_process.Comments;
				if (!object.ReferenceEquals(sender, textBoxAllocComments))
					textBoxAllocComments.Text = m_process.Comments;
				if (!object.ReferenceEquals(sender, textBoxAssessmentComments))
					textBoxAssessmentComments.Text = m_process.Comments;
			}
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_process != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption.Text = m_process.CaptionPhoto;

					//mam 03202012
					string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_process.InfoSetID);

					//mam 03202012
					textBoxPhotoFileName.Text = m_process.PhotoFileName == "" ? m_process.PhotoFileName : targetPath + "\\" + m_process.PhotoFileName;

					pictureBox.Image = m_process.GetPhoto();
					if (pictureBox.Image == null)
						buttonBrowsePhoto.Text = "Browse";
					else
						buttonBrowsePhoto.Text = "Delete";
				}

				//mam 03202012
				else
				{
					textBoxPhotoCaption.Text = "";
				
					//mam 03202012
					textBoxPhotoFileName.Text = "";
				
					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";
				}
			}

			//mam - add other tab selections to update data after grid edits
			else if (tabControl.SelectedTab == tabPageMain)
				componentGrid1.SetRootObject(m_process);
			else if (tabControl.SelectedTab == tabPageAllocation)
				gridAllocation.SetRootObject(m_process);
			else if (tabControl.SelectedTab == tabPageAssessment)
				gridAssessment.SetRootObject(m_process);
			//</mam>
		}

		//mam 01222012
		private void textBox_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)13)
			{
				e.Handled = true;
				this.ActiveControl = label3;
			}
		}

		private void buttonBrowsePhoto_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to update photo data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam 03202012 - this entire method was reworked, and all old code was deleted

			string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_process.InfoSetID);

			/*
			fileNameWithoutPath			original file name without path; this may be modified in the save routine (to get a distinct file name)
			sourceFileWithPath			source path + original file name
			selectedFileNameWithPath	target path + final file name		no longer used
			targetPathWithFileName		target + 
			*/

			if (pictureBox.Image == null)
			{
				//put an image into the picture box

				//******************

				//make sure photo path exists

				//mam 102309 - get the infoset image path - if the string is "", the path does not exist in the WAM.xml file
				//	the user must set the path Edit > WAM Image Folder
				//string infoSetPhotoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_process.InfoSetID);
				string msg = "";
				if (targetPath == "")
				{
					//mam 03222012 - revised message
					//msg = "Please set the base images folder in the <PhotoPaths><BaseImagePath> section of the WAM.xml file before selecting a photo.";
					msg = "Please select the image folder location by clicking Edit > WAM Image Folder in the menu.";
					MessageBox.Show(this, msg, "Set Image Folder Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				//mam 07072011 - check for the existence of targetPath and let the user know if it doesn't exist
				if (!Common.CommonTasks.DoesImagesFolderExist(targetPath))
				{
					return;
				}

				//******************

				//show the open file dialog so the user can select a photo to display in this treatment process

				string fileNameWithoutPath = "";
				OpenFileDialog fileDialog = WAM.Common.CommonTasks.GetPhotoOpenDialog();

				if (fileDialog.ShowDialog(this) == DialogResult.OK)
				{
					//the user has selected a photo

					//******************

					//save the file to the infoset images folder

					Image image = null;
					bool sourcePathSameAsDestinationPath = false;
					string sourceFileWithPath = fileDialog.FileName;

					if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
					{
						//let WAM create the name the photo file using the IDs of the facility and process
						string targetPathIdStyle = m_process.GetImagePathIdStyle();
						fileNameWithoutPath = System.IO.Path.GetFileName(targetPathIdStyle);
						if (WAM.Common.CommonTasks.CopyImageFile(sourceFileWithPath, targetPathIdStyle))
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(targetPathIdStyle, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
					}
					else
					{
						//if the user has selected a file that is already in the infoset image path, don't copy that file and rename it, 
						//	just add the file name to the database for this treatment process
						fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
						sourcePathSameAsDestinationPath = string.Compare(System.IO.Path.GetDirectoryName(sourceFileWithPath), targetPath, true) == 0;
						if (sourcePathSameAsDestinationPath)
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(sourceFileWithPath, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
						else
						{
							//copy the file from the source folder to the infoset image folder

							//fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
							if (!WAM.UI.PhotoFileSave.ShowForm(sourceFileWithPath, targetPath, ref fileNameWithoutPath, ref image))
							{
								//if the user cancels the save, return
								return;
							}
						}
					}

					//try to put the image into the picture box - if it fails, delete the photo file from the infoset images folder
					//	(as long as it is not being used by any other asset)

					try
					{
						pictureBox.Image = image;

						if (pictureBox.Image == null)
						{
							//the image was not inserted into the picturebox; remove the file that was copied into the images folder

							try
							{
								//mam 3202012 - don't delete the image if it is used by another asset
								//sourcePathSameAsDestinationPath = true indicates that the image was already in the infoset image folder, 
								//	which should mean that it is used by another asset
								if (!sourcePathSameAsDestinationPath)
								{
									System.IO.File.Delete(targetPath + "\\" + fileNameWithoutPath);
								}
							}
							catch
							{
							}

							//mam 03202012 - change this message to say that the image cannot be displayed
							//MessageBox.Show(this, "The file is not a valid image file or the Infoset image folder cannot be found.", "Photo File", 
							//	MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							MessageBox.Show(this, "The image cannot be displayed.  The image may not be a valid image file.", "Photo File", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						else
						{
							//the image was successfully inserted into the picture box, so save the data

							string tempVal = m_process.CaptionPhoto;
							string tempVal2 = m_process.PhotoFileName;

							//string selectedFileNameWithPath = targetPath + "\\" + fileNameWithoutPath;
							//m_process.CaptionPhoto = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, false);
							//m_process.PhotoFileName = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, true);
							if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
							{
								m_process.CaptionPhoto = System.IO.Path.GetFileNameWithoutExtension(sourceFileWithPath);
								m_process.PhotoFileName = fileNameWithoutPath;
							}
							else
							{
								m_process.CaptionPhoto = System.IO.Path.GetFileNameWithoutExtension(fileNameWithoutPath);
								m_process.PhotoFileName = fileNameWithoutPath;
							}

							if (!SaveData())
							{
								//the save failed, so set the caption and file name back to their original values
								m_process.CaptionPhoto = tempVal;
								m_process.PhotoFileName = tempVal2;
							}

							textBoxPhotoCaption.Text = m_process.CaptionPhoto;
							textBoxPhotoFileName.Text = targetPath + "\\" + m_process.PhotoFileName;

							buttonBrowsePhoto.Text = "Delete";
						}
					}
					catch(Exception ex)
					{
						MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			else
			{
				//remove the photo from the treatment process

				//mam 03202012
				//string		targetPath = m_process.GetImagePath();
				string targetPathWithFileName = targetPath + "\\" + m_process.PhotoFileName;

				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_process.CaptionPhoto;
				string tempVal2 = m_process.PhotoFileName;

				m_process.CaptionPhoto = "";
				m_process.PhotoFileName = "";
				
				//******************

				//if the save is successful, remove the photo file from the infoset images folder
				//	(as long as it is not used by any other asset)

				if (SaveData())
				{
					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";

					//mam 03202012 - if the file is being used by other assets, don't delete it
					//if IsImageFileUsedByOtherAssets returns -1, an error has occurred while checking the data in the database,
					//	so we don't know whether the file is used by another asset - don't delete the file
					bool fileInUse = Common.CommonTasks.GetPhotoCount(this.m_process.InfoSetID, tempVal2) > 0;

					//mam 03202012 - added check for fileInUse - don't delete file if file is used by other assets
					if (!fileInUse)
					{
						try
						{
							//set the file to be not read only, just in case the user has pulled a fast one and
							//	has copied a read-only image into the images folder
							if (System.IO.File.Exists(targetPathWithFileName))
							{
								System.IO.File.SetAttributes(targetPathWithFileName, System.IO.FileAttributes.Normal);
								System.IO.File.Delete(targetPathWithFileName);
							}
						}
						catch(Exception ex)
						{
							MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
				}
				else
				{
					//the save was not successful - set the caption and file name to their original values

					m_process.CaptionPhoto = tempVal;
					m_process.PhotoFileName = tempVal2;
				}

				textBoxPhotoCaption.Text = m_process.CaptionPhoto;
				textBoxPhotoFileName.Text = m_process.PhotoFileName == "" ? m_process.PhotoFileName : targetPath + "\\" + m_process.PhotoFileName;
			}
		}

		private void textBoxPhotoCaption_Leave(object sender, System.EventArgs e)
		{
			if (m_process.CaptionPhoto != textBoxPhotoCaption.Text)
			{
				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_process.CaptionPhoto;

				m_process.CaptionPhoto = textBoxPhotoCaption.Text;

				//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_process.Save();
				if (!SaveData())
				{
					m_process.CaptionPhoto = tempVal;
				}
			}
		}

		//mam
		public int TabControlIndex
		{
			get {return tabControl.SelectedIndex;}
			set {tabControl.SelectedIndex = value;}
		}
		//</mam>

		//mam
		//mam 07072011 - changed to return a bool
		//public void SaveData()
		public bool SaveData()
		{
			try
			{
				//mam 07072011 - added bool success
				bool success = m_process.Save();
				if (!success)
				{
					//mam 03202012 - if the user doesn't have write permission, don't show the save error
					if (!WAM.Common.Globals.UserHasWritePermission)
					{
						return true;
					}

					Common.CommonTasks.ShowErrorMessage("TreatmentProcess.SaveData", "An error occurred while saving the Treatment Process data.");
					return false;
				}
			}
			catch(Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage(this.Name + ".SaveData", ex.Message);
				return false;
			}

			return true;
		}
		//</mam>

		//mam - disable controls if infoset is fixed
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;
			textBoxProcessName.ReadOnly = isFixedInfoset;
			textBoxComments.ReadOnly = isFixedInfoset;
			textBoxAssessmentComments.ReadOnly = isFixedInfoset;
			textBoxAllocComments.ReadOnly = isFixedInfoset;

			textBoxPhotoCaption.ReadOnly = isFixedInfoset;
			buttonBrowsePhoto.Enabled = !isFixedInfoset;

			panelLocked.Visible = isFixedInfoset;
		}
		//</mam>

		//mam
		public void SetEquationControls()
		{
			componentGrid1.SetEquationControls();
			gridAssessment.SetEquationControls();
		}
		//</mam>

		//mam 03202012 - this method is no longer being used
//		//mam 102309 - no longer deleting photos
//		//mam 102309 - yes, we are
//		//mam
//		public void DeletePhotos(int facilityID, int processID, int infosetID)
//		{
//			if (m_process == null)
//				return;
//
//			//string photoPath = m_process.GetImagePath(facilityID, processID, infosetID);
//
//			//delete photo file
//			try
//			{
//				if (System.IO.File.Exists(photoPath))
//					System.IO.File.Delete(photoPath);
//			}
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine("Error.  Process photo not deleted." + ex.Message.ToString());
//			}
//		}
//		//</mam>

		//mam - added code so that if user types into only one field, say the process name field,
		//	and then clicks on another process node in the tree, the process name will be saved
		private void textBoxProcessName_TextChanged(object sender, System.EventArgs e)
		{
			m_process.Name = textBoxProcessName.Text;
		}

		private void textBoxComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_process.Comments = textBoxComments.Text;
		}

		private void textBoxAssessmentComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_process.Comments = textBoxAssessmentComments.Text;
		}

		private void textBoxAllocComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_process.Comments = textBoxAllocComments.Text;
		}

		private void textBoxPhotoCaption_TextChanged(object sender, System.EventArgs e)
		{
			m_process.CaptionPhoto = textBoxPhotoCaption.Text;
		}
		//</mam>

		//mam 050806
		public void SetTabVisibility()
		{
			try
			{
				tabControl.SuspendLayout();

				//note the currently selected tab
				tabPageSelectedName = tabControl.TabPages[tabControl.SelectedIndex].Name;

				//remove all tabs from the tab control
				tabControl.TabPages.Clear();

				//add tabs back to the tab control
				tabControl.TabPages.Add(tabPageMainHold);
				tabControl.TabPages.Add(tabPageAssessmentHold);

				//show the Cost Allocation tab, if necessary
				if (WAM.Common.Globals.ShowCostTab)
				{
					tabControl.TabPages.Add(tabPageCostAllocationHold);
				}

				tabControl.TabPages.Add(tabPagePhotoHold);
			
				//restore the tab selection
				for (int i = 0; i < tabControl.TabPages.Count; i++)
				{
					if (tabControl.TabPages[i].Name.Equals(tabPageSelectedName))
					{
						tabControl.SelectedIndex = i;
						break;
					}
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
			}
			finally
			{
				tabControl.ResumeLayout();
			}
		}
	}
}
