using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.IO;
using WAM.Data;
using Drive.Configuration;

namespace WAM.UI.MainViews
{
	/// <summary>
	/// Summary description for FacilityControl.
	/// </summary>
	public class FacilityControl : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/

		private	Facility	m_facility = null;

		//mam 050806
		string tabPageSelectedName = string.Empty;
		private TabPage tabPageMainHold = new TabPage();
		private TabPage tabPageValuationHold = new TabPage();
		private TabPage tabPageCostAllocationHold = new TabPage();
		private TabPage tabPagePhotoHold = new TabPage();

		//mam
		private int gridSortCol = 1;
		private int gridSortDirection = 0;
		private int gridColWidth = 150;
		private int maxGridDropDownItems = 16;
		private bool justResizedColumn = false;
		private bool m_initialized = false;
		//</mam>

		//mam 01222012
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();

		private enum StorageFileAttributes
		{
			Archive = FileAttributes.Archive,
			Compressed = FileAttributes.Compressed,
			Encrypted = FileAttributes.Encrypted,
			Hidden = FileAttributes.Hidden,
			Normal = FileAttributes.Normal,
			NotContentIndexed = FileAttributes.NotContentIndexed,
			ReadOnly = FileAttributes.ReadOnly,
			System = FileAttributes.System
		}

		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPageValuation;
		private System.Windows.Forms.TabPage tabPagePhotos;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBoxCurrentENR;
		private WAM.UI.TreatmentProcessGrid treatmentProcessGrid1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label11;
		private WAM.UI.PhotoControl pictureBoxSouth;
		private WAM.UI.FundedTreatmentProcessGrid fundedTreatmentProcessGrid1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.TextBox textBoxCaptionNorth;
		private System.Windows.Forms.TextBox textBoxCaptionSouth;
		private System.Windows.Forms.Button buttonPictureNorth;
		private System.Windows.Forms.Button buttonPictureSouth;
		private WAM.UI.PhotoControl pictureBoxNorth;
		private System.Windows.Forms.Label labelAcquisitionCost;
		private System.Windows.Forms.Label labelCurrentValue;
		private System.Windows.Forms.Label labelAcqCostLessCumDepr;
		private System.Windows.Forms.Label labelCurValLessRepairCost;
		private System.Windows.Forms.Label labelReplaceVal;
		private System.Windows.Forms.TabPage tabPageAllocation;
		private WAM.UI.Grids.CostAllocationGrid gridAllocation;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.TextBox textBoxValuationComments;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox textBoxAllocComments;
		private System.Windows.Forms.Label labelFundedAcquisitionCost;
		private System.Windows.Forms.Label labelFundedCurrentValue;
		private System.Windows.Forms.Label labelFundedCostLessCumDepr;
		private System.Windows.Forms.Label labelFundedCurValueLessRepairCost;
		private System.Windows.Forms.Label labelFundedReplacementValue;
		private System.Windows.Forms.CheckBox checkBoxCustomENR;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.PictureBox pictureBoxEdit;
		private System.Windows.Forms.Panel panelgridCustomENRTables;
		private C1.Win.C1FlexGrid.C1FlexGrid gridCustomENRTables;
		private System.Windows.Forms.PictureBox pictureBoxShowGrid;
		private System.Windows.Forms.TextBox textBoxSelectedCustomENRTable;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label27;
		private NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals textBoxFacilityCriticality;
		private System.Windows.Forms.PictureBox pictureBoxConstraints;
		private System.Windows.Forms.TextBox textBoxPhotoFileNameNorth;
		private System.Windows.Forms.Label labelCaptionPhotoSouth;
		private System.Windows.Forms.Label labelCaptionPhotoNorth;
		private System.Windows.Forms.Label labelFileNamePhotoNorth;
		private System.Windows.Forms.TextBox textBoxPhotoFileNameSouth;
		private System.Windows.Forms.Label labelFileNamePhotoSouth;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public FacilityControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FacilityControl));
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxCurrentENR = new System.Windows.Forms.TextBox();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.label24 = new System.Windows.Forms.Label();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.labelAcquisitionCost = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.labelCurrentValue = new System.Windows.Forms.Label();
			this.labelAcqCostLessCumDepr = new System.Windows.Forms.Label();
			this.labelCurValLessRepairCost = new System.Windows.Forms.Label();
			this.labelReplaceVal = new System.Windows.Forms.Label();
			this.treatmentProcessGrid1 = new WAM.UI.TreatmentProcessGrid();
			this.tabPageValuation = new System.Windows.Forms.TabPage();
			this.label25 = new System.Windows.Forms.Label();
			this.textBoxValuationComments = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.labelFundedAcquisitionCost = new System.Windows.Forms.Label();
			this.labelFundedCurrentValue = new System.Windows.Forms.Label();
			this.labelFundedCostLessCumDepr = new System.Windows.Forms.Label();
			this.labelFundedCurValueLessRepairCost = new System.Windows.Forms.Label();
			this.labelFundedReplacementValue = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.fundedTreatmentProcessGrid1 = new WAM.UI.FundedTreatmentProcessGrid();
			this.tabPageAllocation = new System.Windows.Forms.TabPage();
			this.label26 = new System.Windows.Forms.Label();
			this.textBoxAllocComments = new System.Windows.Forms.TextBox();
			this.gridAllocation = new WAM.UI.Grids.CostAllocationGrid();
			this.tabPagePhotos = new System.Windows.Forms.TabPage();
			this.textBoxPhotoFileNameSouth = new System.Windows.Forms.TextBox();
			this.textBoxCaptionSouth = new System.Windows.Forms.TextBox();
			this.labelCaptionPhotoSouth = new System.Windows.Forms.Label();
			this.labelFileNamePhotoSouth = new System.Windows.Forms.Label();
			this.textBoxPhotoFileNameNorth = new System.Windows.Forms.TextBox();
			this.textBoxCaptionNorth = new System.Windows.Forms.TextBox();
			this.labelCaptionPhotoNorth = new System.Windows.Forms.Label();
			this.labelFileNamePhotoNorth = new System.Windows.Forms.Label();
			this.pictureBoxNorth = new WAM.UI.PhotoControl();
			this.buttonPictureNorth = new System.Windows.Forms.Button();
			this.pictureBoxSouth = new WAM.UI.PhotoControl();
			this.buttonPictureSouth = new System.Windows.Forms.Button();
			this.checkBoxCustomENR = new System.Windows.Forms.CheckBox();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.labelLocked = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.pictureBoxEdit = new System.Windows.Forms.PictureBox();
			this.panelgridCustomENRTables = new System.Windows.Forms.Panel();
			this.gridCustomENRTables = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.pictureBoxShowGrid = new System.Windows.Forms.PictureBox();
			this.textBoxSelectedCustomENRTable = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.textBoxFacilityCriticality = new NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals();
			this.label27 = new System.Windows.Forms.Label();
			this.pictureBoxConstraints = new System.Windows.Forms.PictureBox();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tabPageValuation.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tabPageAllocation.SuspendLayout();
			this.tabPagePhotos.SuspendLayout();
			this.panelLocked.SuspendLayout();
			this.panelgridCustomENRTables.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCustomENRTables)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 3;
			this.pictureBoxLogo.TabStop = false;
			this.pictureBoxLogo.Click += new System.EventHandler(this.pictureBoxLogo_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(88, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Fa&cility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.Text = "";
			this.textBoxFacilityName.TextChanged += new System.EventHandler(this.textBoxFacilityName_TextChanged);
			this.textBoxFacilityName.Leave += new System.EventHandler(this.textBoxFacilityName_Leave);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(456, 6);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(76, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Current &Year:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.MaxLength = 4;
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 3;
			this.textBoxCurrentYear.Text = "";
			this.textBoxCurrentYear.TextChanged += new System.EventHandler(this.textBoxCurrentYear_TextChanged);
			this.textBoxCurrentYear.Leave += new System.EventHandler(this.textBoxCurrentYear_Leave);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(456, 34);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Current ENR:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentENR
			// 
			this.textBoxCurrentENR.Location = new System.Drawing.Point(532, 32);
			this.textBoxCurrentENR.MaxLength = 4;
			this.textBoxCurrentENR.Name = "textBoxCurrentENR";
			this.textBoxCurrentENR.ReadOnly = true;
			this.textBoxCurrentENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentENR.TabIndex = 7;
			this.textBoxCurrentENR.TabStop = false;
			this.textBoxCurrentENR.Text = "";
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageValuation);
			this.tabControl.Controls.Add(this.tabPageAllocation);
			this.tabControl.Controls.Add(this.tabPagePhotos);
			this.helpProvider1.SetHelpKeyword(this.tabControl, "FacilityTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabControl, System.Windows.Forms.HelpNavigator.Topic);
			this.tabControl.ItemSize = new System.Drawing.Size(110, 18);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.helpProvider1.SetShowHelp(this.tabControl, true);
			this.tabControl.Size = new System.Drawing.Size(608, 332);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl.TabIndex = 7;
			this.tabControl.Click += new System.EventHandler(this.tabControl_Click);
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.label24);
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.groupBox1);
			this.tabPageMain.Controls.Add(this.treatmentProcessGrid1);
			this.helpProvider1.SetHelpKeyword(this.tabPageMain, "FacilityTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageMain, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.helpProvider1.SetShowHelp(this.tabPageMain, true);
			this.tabPageMain.Size = new System.Drawing.Size(600, 306);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			this.tabPageMain.Click += new System.EventHandler(this.tabPageMain_Click);
			// 
			// label24
			// 
			this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label24.Location = new System.Drawing.Point(260, 160);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(68, 16);
			this.label24.TabIndex = 2;
			this.label24.Text = "Comments:";
			// 
			// textBoxComments
			// 
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(260, 176);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(336, 128);
			this.textBoxComments.TabIndex = 9;
			this.textBoxComments.Text = "";
			this.textBoxComments.TextChanged += new System.EventHandler(this.textBoxComments_TextChanged);
			this.textBoxComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox1.Controls.Add(this.labelAcquisitionCost);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.label9);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label10);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Controls.Add(this.label15);
			this.groupBox1.Controls.Add(this.label11);
			this.groupBox1.Controls.Add(this.labelCurrentValue);
			this.groupBox1.Controls.Add(this.labelAcqCostLessCumDepr);
			this.groupBox1.Controls.Add(this.labelCurValLessRepairCost);
			this.groupBox1.Controls.Add(this.labelReplaceVal);
			this.groupBox1.Location = new System.Drawing.Point(4, 156);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(252, 148);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Summary of Facility / System Valuation Basis";
			// 
			// labelAcquisitionCost
			// 
			this.labelAcquisitionCost.Location = new System.Drawing.Point(160, 20);
			this.labelAcquisitionCost.Name = "labelAcquisitionCost";
			this.labelAcquisitionCost.Size = new System.Drawing.Size(88, 16);
			this.labelAcquisitionCost.TabIndex = 2;
			this.labelAcquisitionCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 60);
			this.label6.Name = "label6";
			this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label6.Size = new System.Drawing.Size(16, 16);
			this.label6.TabIndex = 6;
			this.label6.Text = "3.";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(24, 20);
			this.label7.Name = "label7";
			this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label7.Size = new System.Drawing.Size(132, 16);
			this.label7.TabIndex = 1;
			this.label7.Text = "Acquisition Cost";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(24, 40);
			this.label9.Name = "label9";
			this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label9.Size = new System.Drawing.Size(132, 16);
			this.label9.TabIndex = 4;
			this.label9.Text = "Current Value";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(24, 60);
			this.label4.Name = "label4";
			this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label4.Size = new System.Drawing.Size(132, 16);
			this.label4.TabIndex = 7;
			this.label4.Text = "Book Value";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(8, 20);
			this.label8.Name = "label8";
			this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label8.Size = new System.Drawing.Size(16, 16);
			this.label8.TabIndex = 0;
			this.label8.Text = "1.";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(8, 40);
			this.label10.Name = "label10";
			this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label10.Size = new System.Drawing.Size(16, 16);
			this.label10.TabIndex = 3;
			this.label10.Text = "2.";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(8, 80);
			this.label13.Name = "label13";
			this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label13.Size = new System.Drawing.Size(16, 16);
			this.label13.TabIndex = 9;
			this.label13.Text = "4.";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(24, 80);
			this.label14.Name = "label14";
			this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label14.Size = new System.Drawing.Size(132, 28);
			this.label14.TabIndex = 10;
			this.label14.Text = "Current Value less Repair Cost";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(24, 112);
			this.label15.Name = "label15";
			this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label15.Size = new System.Drawing.Size(132, 16);
			this.label15.TabIndex = 13;
			this.label15.Text = "Replacement Value";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(8, 112);
			this.label11.Name = "label11";
			this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label11.Size = new System.Drawing.Size(16, 16);
			this.label11.TabIndex = 12;
			this.label11.Text = "5.";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelCurrentValue
			// 
			this.labelCurrentValue.Location = new System.Drawing.Point(160, 40);
			this.labelCurrentValue.Name = "labelCurrentValue";
			this.labelCurrentValue.Size = new System.Drawing.Size(88, 16);
			this.labelCurrentValue.TabIndex = 5;
			this.labelCurrentValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelAcqCostLessCumDepr
			// 
			this.labelAcqCostLessCumDepr.Location = new System.Drawing.Point(160, 60);
			this.labelAcqCostLessCumDepr.Name = "labelAcqCostLessCumDepr";
			this.labelAcqCostLessCumDepr.Size = new System.Drawing.Size(88, 16);
			this.labelAcqCostLessCumDepr.TabIndex = 8;
			this.labelAcqCostLessCumDepr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelCurValLessRepairCost
			// 
			this.labelCurValLessRepairCost.Location = new System.Drawing.Point(160, 80);
			this.labelCurValLessRepairCost.Name = "labelCurValLessRepairCost";
			this.labelCurValLessRepairCost.Size = new System.Drawing.Size(88, 16);
			this.labelCurValLessRepairCost.TabIndex = 11;
			this.labelCurValLessRepairCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelReplaceVal
			// 
			this.labelReplaceVal.Location = new System.Drawing.Point(160, 112);
			this.labelReplaceVal.Name = "labelReplaceVal";
			this.labelReplaceVal.Size = new System.Drawing.Size(88, 16);
			this.labelReplaceVal.TabIndex = 14;
			this.labelReplaceVal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// treatmentProcessGrid1
			// 
			this.treatmentProcessGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.helpProvider1.SetHelpKeyword(this.treatmentProcessGrid1, "FacilityTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.treatmentProcessGrid1, System.Windows.Forms.HelpNavigator.Topic);
			this.treatmentProcessGrid1.Location = new System.Drawing.Point(4, 4);
			this.treatmentProcessGrid1.Name = "treatmentProcessGrid1";
			this.helpProvider1.SetShowHelp(this.treatmentProcessGrid1, true);
			this.treatmentProcessGrid1.Size = new System.Drawing.Size(592, 148);
			this.treatmentProcessGrid1.TabIndex = 8;
			// 
			// tabPageValuation
			// 
			this.tabPageValuation.Controls.Add(this.label25);
			this.tabPageValuation.Controls.Add(this.textBoxValuationComments);
			this.tabPageValuation.Controls.Add(this.groupBox2);
			this.tabPageValuation.Controls.Add(this.fundedTreatmentProcessGrid1);
			this.helpProvider1.SetHelpKeyword(this.tabPageValuation, "FacilityTabValuationOptions.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageValuation, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageValuation.Location = new System.Drawing.Point(4, 22);
			this.tabPageValuation.Name = "tabPageValuation";
			this.helpProvider1.SetShowHelp(this.tabPageValuation, true);
			this.tabPageValuation.Size = new System.Drawing.Size(600, 306);
			this.tabPageValuation.TabIndex = 1;
			this.tabPageValuation.Text = "Valuation Options";
			// 
			// label25
			// 
			this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label25.Location = new System.Drawing.Point(260, 160);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(68, 16);
			this.label25.TabIndex = 4;
			this.label25.Text = "Comments:";
			// 
			// textBoxValuationComments
			// 
			this.textBoxValuationComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxValuationComments.Location = new System.Drawing.Point(260, 176);
			this.textBoxValuationComments.Multiline = true;
			this.textBoxValuationComments.Name = "textBoxValuationComments";
			this.textBoxValuationComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxValuationComments.Size = new System.Drawing.Size(336, 128);
			this.textBoxValuationComments.TabIndex = 5;
			this.textBoxValuationComments.Text = "";
			this.textBoxValuationComments.TextChanged += new System.EventHandler(this.textBoxValuationComments_TextChanged);
			this.textBoxValuationComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox2.Controls.Add(this.labelFundedAcquisitionCost);
			this.groupBox2.Controls.Add(this.labelFundedCurrentValue);
			this.groupBox2.Controls.Add(this.labelFundedCostLessCumDepr);
			this.groupBox2.Controls.Add(this.labelFundedCurValueLessRepairCost);
			this.groupBox2.Controls.Add(this.labelFundedReplacementValue);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.label12);
			this.groupBox2.Controls.Add(this.label16);
			this.groupBox2.Controls.Add(this.label17);
			this.groupBox2.Controls.Add(this.label18);
			this.groupBox2.Controls.Add(this.label19);
			this.groupBox2.Controls.Add(this.label20);
			this.groupBox2.Controls.Add(this.label21);
			this.groupBox2.Controls.Add(this.label22);
			this.groupBox2.Controls.Add(this.label23);
			this.groupBox2.Location = new System.Drawing.Point(4, 156);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(252, 148);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Summary of Valuation Option Basis";
			// 
			// labelFundedAcquisitionCost
			// 
			this.labelFundedAcquisitionCost.Location = new System.Drawing.Point(160, 20);
			this.labelFundedAcquisitionCost.Name = "labelFundedAcquisitionCost";
			this.labelFundedAcquisitionCost.Size = new System.Drawing.Size(88, 16);
			this.labelFundedAcquisitionCost.TabIndex = 15;
			this.labelFundedAcquisitionCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelFundedCurrentValue
			// 
			this.labelFundedCurrentValue.Location = new System.Drawing.Point(160, 40);
			this.labelFundedCurrentValue.Name = "labelFundedCurrentValue";
			this.labelFundedCurrentValue.Size = new System.Drawing.Size(88, 16);
			this.labelFundedCurrentValue.TabIndex = 16;
			this.labelFundedCurrentValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelFundedCostLessCumDepr
			// 
			this.labelFundedCostLessCumDepr.Location = new System.Drawing.Point(160, 60);
			this.labelFundedCostLessCumDepr.Name = "labelFundedCostLessCumDepr";
			this.labelFundedCostLessCumDepr.Size = new System.Drawing.Size(88, 16);
			this.labelFundedCostLessCumDepr.TabIndex = 17;
			this.labelFundedCostLessCumDepr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelFundedCurValueLessRepairCost
			// 
			this.labelFundedCurValueLessRepairCost.Location = new System.Drawing.Point(160, 80);
			this.labelFundedCurValueLessRepairCost.Name = "labelFundedCurValueLessRepairCost";
			this.labelFundedCurValueLessRepairCost.Size = new System.Drawing.Size(88, 16);
			this.labelFundedCurValueLessRepairCost.TabIndex = 18;
			this.labelFundedCurValueLessRepairCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelFundedReplacementValue
			// 
			this.labelFundedReplacementValue.Location = new System.Drawing.Point(160, 112);
			this.labelFundedReplacementValue.Name = "labelFundedReplacementValue";
			this.labelFundedReplacementValue.Size = new System.Drawing.Size(88, 16);
			this.labelFundedReplacementValue.TabIndex = 19;
			this.labelFundedReplacementValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 60);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(16, 16);
			this.label5.TabIndex = 6;
			this.label5.Text = "3.";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(24, 20);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(132, 16);
			this.label12.TabIndex = 1;
			this.label12.Text = "Acquisition Cost";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(24, 40);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(132, 16);
			this.label16.TabIndex = 4;
			this.label16.Text = "Current Value";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(24, 60);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(132, 16);
			this.label17.TabIndex = 7;
			this.label17.Text = "Book Value";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(8, 20);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(16, 16);
			this.label18.TabIndex = 0;
			this.label18.Text = "1.";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(8, 40);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(16, 16);
			this.label19.TabIndex = 3;
			this.label19.Text = "2.";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(8, 80);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(16, 16);
			this.label20.TabIndex = 9;
			this.label20.Text = "4.";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(24, 80);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(132, 28);
			this.label21.TabIndex = 10;
			this.label21.Text = "Current Value less Repair Cost";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(24, 112);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(132, 16);
			this.label22.TabIndex = 14;
			this.label22.Text = "Replacement Value";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(8, 112);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(16, 16);
			this.label23.TabIndex = 13;
			this.label23.Text = "5.";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// fundedTreatmentProcessGrid1
			// 
			this.fundedTreatmentProcessGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.helpProvider1.SetHelpKeyword(this.fundedTreatmentProcessGrid1, "FacilityTabValuationOptions.htm");
			this.helpProvider1.SetHelpNavigator(this.fundedTreatmentProcessGrid1, System.Windows.Forms.HelpNavigator.Topic);
			this.fundedTreatmentProcessGrid1.Location = new System.Drawing.Point(4, 4);
			this.fundedTreatmentProcessGrid1.Name = "fundedTreatmentProcessGrid1";
			this.helpProvider1.SetShowHelp(this.fundedTreatmentProcessGrid1, true);
			this.fundedTreatmentProcessGrid1.Size = new System.Drawing.Size(592, 148);
			this.fundedTreatmentProcessGrid1.TabIndex = 0;
			// 
			// tabPageAllocation
			// 
			this.tabPageAllocation.Controls.Add(this.label26);
			this.tabPageAllocation.Controls.Add(this.textBoxAllocComments);
			this.tabPageAllocation.Controls.Add(this.gridAllocation);
			this.helpProvider1.SetHelpKeyword(this.tabPageAllocation, "FacilityTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageAllocation.Location = new System.Drawing.Point(4, 22);
			this.tabPageAllocation.Name = "tabPageAllocation";
			this.helpProvider1.SetShowHelp(this.tabPageAllocation, true);
			this.tabPageAllocation.Size = new System.Drawing.Size(600, 306);
			this.tabPageAllocation.TabIndex = 3;
			this.tabPageAllocation.Text = "Cost Allocation by %";
			// 
			// label26
			// 
			this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label26.Location = new System.Drawing.Point(4, 160);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(84, 16);
			this.label26.TabIndex = 8;
			this.label26.Text = "Comments:";
			// 
			// textBoxAllocComments
			// 
			this.textBoxAllocComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAllocComments.Location = new System.Drawing.Point(4, 176);
			this.textBoxAllocComments.Multiline = true;
			this.textBoxAllocComments.Name = "textBoxAllocComments";
			this.textBoxAllocComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAllocComments.Size = new System.Drawing.Size(592, 128);
			this.textBoxAllocComments.TabIndex = 9;
			this.textBoxAllocComments.Text = "";
			this.textBoxAllocComments.TextChanged += new System.EventHandler(this.textBoxAllocComments_TextChanged);
			this.textBoxAllocComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// gridAllocation
			// 
			this.gridAllocation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAllocation.GridStyle = WAM.UI.Grids.CostAllocationGrid.GridType.MajorComponents;
			this.helpProvider1.SetHelpKeyword(this.gridAllocation, "FacilityTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAllocation.Location = new System.Drawing.Point(4, 4);
			this.gridAllocation.Name = "gridAllocation";
			this.helpProvider1.SetShowHelp(this.gridAllocation, true);
			this.gridAllocation.Size = new System.Drawing.Size(592, 152);
			this.gridAllocation.TabIndex = 7;
			// 
			// tabPagePhotos
			// 
			this.tabPagePhotos.Controls.Add(this.textBoxPhotoFileNameSouth);
			this.tabPagePhotos.Controls.Add(this.textBoxCaptionSouth);
			this.tabPagePhotos.Controls.Add(this.labelCaptionPhotoSouth);
			this.tabPagePhotos.Controls.Add(this.labelFileNamePhotoSouth);
			this.tabPagePhotos.Controls.Add(this.textBoxPhotoFileNameNorth);
			this.tabPagePhotos.Controls.Add(this.textBoxCaptionNorth);
			this.tabPagePhotos.Controls.Add(this.labelCaptionPhotoNorth);
			this.tabPagePhotos.Controls.Add(this.labelFileNamePhotoNorth);
			this.tabPagePhotos.Controls.Add(this.pictureBoxNorth);
			this.tabPagePhotos.Controls.Add(this.buttonPictureNorth);
			this.tabPagePhotos.Controls.Add(this.pictureBoxSouth);
			this.tabPagePhotos.Controls.Add(this.buttonPictureSouth);
			this.helpProvider1.SetHelpKeyword(this.tabPagePhotos, "FacilityTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPagePhotos, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPagePhotos.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhotos.Name = "tabPagePhotos";
			this.helpProvider1.SetShowHelp(this.tabPagePhotos, true);
			this.tabPagePhotos.Size = new System.Drawing.Size(600, 306);
			this.tabPagePhotos.TabIndex = 2;
			this.tabPagePhotos.Text = "Photos";
			this.tabPagePhotos.Resize += new System.EventHandler(this.tabPagePhotos_Resize);
			// 
			// textBoxPhotoFileNameSouth
			// 
			this.textBoxPhotoFileNameSouth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoFileNameSouth.Location = new System.Drawing.Point(360, 251);
			this.textBoxPhotoFileNameSouth.MaxLength = 255;
			this.textBoxPhotoFileNameSouth.Name = "textBoxPhotoFileNameSouth";
			this.textBoxPhotoFileNameSouth.Size = new System.Drawing.Size(236, 20);
			this.textBoxPhotoFileNameSouth.TabIndex = 26;
			this.textBoxPhotoFileNameSouth.Text = "";
			// 
			// textBoxCaptionSouth
			// 
			this.textBoxCaptionSouth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxCaptionSouth.Location = new System.Drawing.Point(360, 232);
			this.textBoxCaptionSouth.MaxLength = 255;
			this.textBoxCaptionSouth.Name = "textBoxCaptionSouth";
			this.textBoxCaptionSouth.Size = new System.Drawing.Size(236, 20);
			this.textBoxCaptionSouth.TabIndex = 1;
			this.textBoxCaptionSouth.Text = "";
			this.textBoxCaptionSouth.TextChanged += new System.EventHandler(this.textBoxCaptionSouth_TextChanged);
			this.textBoxCaptionSouth.Leave += new System.EventHandler(this.textBoxCaptionSouth_Leave);
			// 
			// labelCaptionPhotoSouth
			// 
			this.labelCaptionPhotoSouth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.labelCaptionPhotoSouth.BackColor = System.Drawing.Color.Transparent;
			this.labelCaptionPhotoSouth.Location = new System.Drawing.Point(302, 235);
			this.labelCaptionPhotoSouth.Name = "labelCaptionPhotoSouth";
			this.labelCaptionPhotoSouth.Size = new System.Drawing.Size(60, 20);
			this.labelCaptionPhotoSouth.TabIndex = 25;
			this.labelCaptionPhotoSouth.Text = "Caption:";
			// 
			// labelFileNamePhotoSouth
			// 
			this.labelFileNamePhotoSouth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.labelFileNamePhotoSouth.BackColor = System.Drawing.Color.Transparent;
			this.labelFileNamePhotoSouth.Location = new System.Drawing.Point(302, 254);
			this.labelFileNamePhotoSouth.Name = "labelFileNamePhotoSouth";
			this.labelFileNamePhotoSouth.Size = new System.Drawing.Size(60, 20);
			this.labelFileNamePhotoSouth.TabIndex = 24;
			this.labelFileNamePhotoSouth.Text = "File Name:";
			// 
			// textBoxPhotoFileNameNorth
			// 
			this.textBoxPhotoFileNameNorth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxPhotoFileNameNorth.Location = new System.Drawing.Point(64, 251);
			this.textBoxPhotoFileNameNorth.MaxLength = 255;
			this.textBoxPhotoFileNameNorth.Name = "textBoxPhotoFileNameNorth";
			this.textBoxPhotoFileNameNorth.Size = new System.Drawing.Size(236, 20);
			this.textBoxPhotoFileNameNorth.TabIndex = 23;
			this.textBoxPhotoFileNameNorth.Text = "";
			// 
			// textBoxCaptionNorth
			// 
			this.textBoxCaptionNorth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxCaptionNorth.Location = new System.Drawing.Point(64, 232);
			this.textBoxCaptionNorth.MaxLength = 255;
			this.textBoxCaptionNorth.Name = "textBoxCaptionNorth";
			this.textBoxCaptionNorth.Size = new System.Drawing.Size(236, 20);
			this.textBoxCaptionNorth.TabIndex = 1;
			this.textBoxCaptionNorth.Text = "";
			this.textBoxCaptionNorth.TextChanged += new System.EventHandler(this.textBoxCaptionNorth_TextChanged);
			this.textBoxCaptionNorth.Leave += new System.EventHandler(this.textBoxCaptionNorth_Leave);
			// 
			// labelCaptionPhotoNorth
			// 
			this.labelCaptionPhotoNorth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCaptionPhotoNorth.BackColor = System.Drawing.Color.Transparent;
			this.labelCaptionPhotoNorth.Location = new System.Drawing.Point(6, 235);
			this.labelCaptionPhotoNorth.Name = "labelCaptionPhotoNorth";
			this.labelCaptionPhotoNorth.Size = new System.Drawing.Size(60, 20);
			this.labelCaptionPhotoNorth.TabIndex = 22;
			this.labelCaptionPhotoNorth.Text = "Caption:";
			// 
			// labelFileNamePhotoNorth
			// 
			this.labelFileNamePhotoNorth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelFileNamePhotoNorth.BackColor = System.Drawing.Color.Transparent;
			this.labelFileNamePhotoNorth.Location = new System.Drawing.Point(6, 254);
			this.labelFileNamePhotoNorth.Name = "labelFileNamePhotoNorth";
			this.labelFileNamePhotoNorth.Size = new System.Drawing.Size(60, 20);
			this.labelFileNamePhotoNorth.TabIndex = 21;
			this.labelFileNamePhotoNorth.Text = "File Name:";
			// 
			// pictureBoxNorth
			// 
			this.pictureBoxNorth.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.pictureBoxNorth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.pictureBoxNorth, "FacilityTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.pictureBoxNorth, System.Windows.Forms.HelpNavigator.Topic);
			this.pictureBoxNorth.Image = null;
			this.pictureBoxNorth.Location = new System.Drawing.Point(8, 8);
			this.pictureBoxNorth.Name = "pictureBoxNorth";
			this.helpProvider1.SetShowHelp(this.pictureBoxNorth, true);
			this.pictureBoxNorth.Size = new System.Drawing.Size(292, 224);
			this.pictureBoxNorth.TabIndex = 3;
			// 
			// buttonPictureNorth
			// 
			this.buttonPictureNorth.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonPictureNorth.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPictureNorth.Location = new System.Drawing.Point(117, 276);
			this.buttonPictureNorth.Name = "buttonPictureNorth";
			this.buttonPictureNorth.TabIndex = 2;
			this.buttonPictureNorth.Text = "Browse...";
			this.buttonPictureNorth.Click += new System.EventHandler(this.buttonPictureNorth_Click);
			// 
			// pictureBoxSouth
			// 
			this.pictureBoxSouth.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxSouth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.pictureBoxSouth, "FacilityTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.pictureBoxSouth, System.Windows.Forms.HelpNavigator.Topic);
			this.pictureBoxSouth.Image = null;
			this.pictureBoxSouth.Location = new System.Drawing.Point(304, 8);
			this.pictureBoxSouth.Name = "pictureBoxSouth";
			this.helpProvider1.SetShowHelp(this.pictureBoxSouth, true);
			this.pictureBoxSouth.Size = new System.Drawing.Size(292, 224);
			this.pictureBoxSouth.TabIndex = 0;
			this.pictureBoxSouth.TabStop = false;
			// 
			// buttonPictureSouth
			// 
			this.buttonPictureSouth.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonPictureSouth.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPictureSouth.Location = new System.Drawing.Point(413, 276);
			this.buttonPictureSouth.Name = "buttonPictureSouth";
			this.buttonPictureSouth.TabIndex = 2;
			this.buttonPictureSouth.Text = "Browse...";
			this.buttonPictureSouth.Click += new System.EventHandler(this.buttonPictureSouth_Click);
			// 
			// checkBoxCustomENR
			// 
			this.checkBoxCustomENR.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBoxCustomENR.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxCustomENR.Location = new System.Drawing.Point(436, 60);
			this.checkBoxCustomENR.Name = "checkBoxCustomENR";
			this.checkBoxCustomENR.Size = new System.Drawing.Size(144, 16);
			this.checkBoxCustomENR.TabIndex = 8;
			this.checkBoxCustomENR.Text = "Use Custom ENR Table?";
			this.checkBoxCustomENR.CheckedChanged += new System.EventHandler(this.checkBoxCustomENR_CheckedChanged);
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.labelLocked);
			this.panelLocked.Location = new System.Drawing.Point(145, 90);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 18;
			this.panelLocked.Visible = false;
			// 
			// labelLocked
			// 
			this.labelLocked.BackColor = System.Drawing.Color.White;
			this.labelLocked.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelLocked.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.labelLocked.Location = new System.Drawing.Point(1, 1);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.Size = new System.Drawing.Size(213, 18);
			this.labelLocked.TabIndex = 16;
			this.labelLocked.Text = "All Data is Locked";
			this.labelLocked.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// pictureBoxEdit
			// 
			this.pictureBoxEdit.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxEdit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEdit.Image")));
			this.pictureBoxEdit.Location = new System.Drawing.Point(586, 57);
			this.pictureBoxEdit.Name = "pictureBoxEdit";
			this.pictureBoxEdit.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxEdit.TabIndex = 149;
			this.pictureBoxEdit.TabStop = false;
			this.pictureBoxEdit.Click += new System.EventHandler(this.pictureBoxEdit_Click);
			// 
			// panelgridCustomENRTables
			// 
			this.panelgridCustomENRTables.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelgridCustomENRTables.Controls.Add(this.gridCustomENRTables);
			this.panelgridCustomENRTables.Location = new System.Drawing.Point(236, 56);
			this.panelgridCustomENRTables.Name = "panelgridCustomENRTables";
			this.panelgridCustomENRTables.Size = new System.Drawing.Size(68, 60);
			this.panelgridCustomENRTables.TabIndex = 168;
			this.panelgridCustomENRTables.Visible = false;
			// 
			// gridCustomENRTables
			// 
			this.gridCustomENRTables.AllowEditing = false;
			this.gridCustomENRTables.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
			this.gridCustomENRTables.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.gridCustomENRTables.ColumnInfo = @"3,1,0,0,0,85,Columns:0{Width:25;Visible:False;}	1{Width:150;Caption:""InfoSet"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	2{Width:150;Caption:""Custom ENR Table"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	";
			this.gridCustomENRTables.ExtendLastCol = true;
			this.gridCustomENRTables.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridCustomENRTables.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.gridCustomENRTables.Location = new System.Drawing.Point(1, 1);
			this.gridCustomENRTables.Name = "gridCustomENRTables";
			this.gridCustomENRTables.Rows.Count = 1;
			this.gridCustomENRTables.Rows.MaxSize = 20;
			this.gridCustomENRTables.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.gridCustomENRTables.Size = new System.Drawing.Size(55, 47);
			this.gridCustomENRTables.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Margins:5, 5, 1, 1;Border:Flat,1,Control,Vertical;}	Alternate{BackColor:Window;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridCustomENRTables.TabIndex = 166;
			this.gridCustomENRTables.AfterResizeColumn += new C1.Win.C1FlexGrid.RowColEventHandler(this.gridCustomENRTables_AfterResizeColumn);
			this.gridCustomENRTables.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridCustomENRTables_MouseUp);
			this.gridCustomENRTables.AfterSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.gridCustomENRTables_AfterSort);
			// 
			// pictureBoxShowGrid
			// 
			this.pictureBoxShowGrid.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxShowGrid.Image")));
			this.pictureBoxShowGrid.Location = new System.Drawing.Point(562, 80);
			this.pictureBoxShowGrid.Name = "pictureBoxShowGrid";
			this.pictureBoxShowGrid.Size = new System.Drawing.Size(17, 16);
			this.pictureBoxShowGrid.TabIndex = 170;
			this.pictureBoxShowGrid.TabStop = false;
			this.pictureBoxShowGrid.Click += new System.EventHandler(this.pictureBoxShowGrid_Click);
			// 
			// textBoxSelectedCustomENRTable
			// 
			this.textBoxSelectedCustomENRTable.AutoSize = false;
			this.textBoxSelectedCustomENRTable.BackColor = System.Drawing.Color.White;
			this.textBoxSelectedCustomENRTable.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.textBoxSelectedCustomENRTable.Location = new System.Drawing.Point(396, 78);
			this.textBoxSelectedCustomENRTable.Name = "textBoxSelectedCustomENRTable";
			this.textBoxSelectedCustomENRTable.ReadOnly = true;
			this.textBoxSelectedCustomENRTable.Size = new System.Drawing.Size(184, 20);
			this.textBoxSelectedCustomENRTable.TabIndex = 9;
			this.textBoxSelectedCustomENRTable.Text = "";
			this.textBoxSelectedCustomENRTable.MouseDown += new System.Windows.Forms.MouseEventHandler(this.textBoxSelectedCustomENRTable_MouseDown);
			this.textBoxSelectedCustomENRTable.TextChanged += new System.EventHandler(this.textBoxSelectedCustomENRTable_TextChanged);
			this.textBoxSelectedCustomENRTable.MouseUp += new System.Windows.Forms.MouseEventHandler(this.textBoxSelectedCustomENRTable_MouseUp);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(96, 60);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(92, 20);
			this.button1.TabIndex = 171;
			this.button1.Text = "button1";
			this.button1.Visible = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBoxFacilityCriticality
			// 
			this.textBoxFacilityCriticality.Location = new System.Drawing.Point(341, 32);
			this.textBoxFacilityCriticality.Name = "textBoxFacilityCriticality";
			this.textBoxFacilityCriticality.Size = new System.Drawing.Size(48, 20);
			this.textBoxFacilityCriticality.TabIndex = 5;
			this.textBoxFacilityCriticality.Tag = "FACCRIT";
			this.textBoxFacilityCriticality.Text = "1.00";
			this.textBoxFacilityCriticality.Value = new System.Decimal(new int[] {
																					 100,
																					 0,
																					 0,
																					 131072});
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(88, 34);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(260, 16);
			this.label27.TabIndex = 4;
			this.label27.Text = "Facility Criticality Weighting Factor (0.01 to 100):";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pictureBoxConstraints
			// 
			this.pictureBoxConstraints.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxConstraints.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxConstraints.Image")));
			this.pictureBoxConstraints.Location = new System.Drawing.Point(586, 4);
			this.pictureBoxConstraints.Name = "pictureBoxConstraints";
			this.pictureBoxConstraints.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxConstraints.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxConstraints.TabIndex = 172;
			this.pictureBoxConstraints.TabStop = false;
			this.pictureBoxConstraints.Click += new System.EventHandler(this.pictureBoxConstraints_Click);
			// 
			// FacilityControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(616, 450);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.textBoxFacilityCriticality);
			this.Controls.Add(this.pictureBoxConstraints);
			this.Controls.Add(this.label27);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.pictureBoxShowGrid);
			this.Controls.Add(this.textBoxSelectedCustomENRTable);
			this.Controls.Add(this.panelgridCustomENRTables);
			this.Controls.Add(this.pictureBoxEdit);
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.checkBoxCustomENR);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBoxCurrentENR);
			this.helpProvider1.SetHelpKeyword(this, "FacilityScreen.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.TableOfContents);
			this.Name = "FacilityControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(616, 452);
			this.Click += new System.EventHandler(this.FacilityControl_Click);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.FacilityControl_Paint);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.tabPageValuation.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.tabPageAllocation.ResumeLayout(false);
			this.tabPagePhotos.ResumeLayout(false);
			this.panelLocked.ResumeLayout(false);
			this.panelgridCustomENRTables.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridCustomENRTables)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		protected override void OnLoad(EventArgs e)
		{
			//mam
			m_initialized = false;
			//</mam>

			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			//mam 01222012
			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonPencils.bmp");
			pictureBoxEdit.Image = Bitmap.FromStream(file);
			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonResetOn8.bmp");
			pictureBoxConstraints.Image = Bitmap.FromStream(file);

			//mam
			//position and size grid
			panelgridCustomENRTables.Size = new System.Drawing.Size(332, 273);
			gridCustomENRTables.Size = new System.Drawing.Size(330, 271);

			//int posX = textBoxSelectedCustomENRTable.Location.X;
			int posX = textBoxSelectedCustomENRTable.Location.X + textBoxSelectedCustomENRTable.Width - panelgridCustomENRTables.Width;
			int posY = textBoxSelectedCustomENRTable.Location.Y + textBoxSelectedCustomENRTable.Height - 1;
			panelgridCustomENRTables.Location = new System.Drawing.Point(posX, posY);

			GetOptions();
			SetBitmaps();
			//</mam>

			//mam 050806
			tabPageMainHold = tabControl.TabPages[0];
			tabPageValuationHold = tabControl.TabPages[1];
			tabPageCostAllocationHold = tabControl.TabPages[2];
			tabPagePhotoHold = tabControl.TabPages[3];

			//mam
			m_initialized = true;
			//</mam>

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();

			//mam 01222012
			SetEquationControls();

			//mam 01222012
			textBoxFacilityName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
			textBoxCurrentYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
			textBoxFacilityCriticality.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
			textBoxFacilityCriticality.Leave += new System.EventHandler(this.textBoxFacilityCriticality_Leave);

			//mam 01222012 - make visible for testing only
			//this.button1.Visible = true;

			//mam 03202012
			textBoxPhotoFileNameNorth.ReadOnly = true;
			textBoxPhotoFileNameSouth.ReadOnly = true;

			base.OnLoad(e);
		}

		//mam 01222012
		private void SetReadOnlyTextBoxBackgroundColor(TextBox sender)
		{
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				sender.BackColor = sender.ReadOnly ? WAM.Common.Globals.ReadOnlyBackgroundColorNumeric : Color.FromKnownColor(System.Drawing.KnownColor.Window);
			}
			//mam 01222012
			else
			{
				sender.BackColor = sender.ReadOnly ? Color.FromKnownColor(System.Drawing.KnownColor.Control) : Color.FromKnownColor(System.Drawing.KnownColor.Window);
			}
		}

		//mam 01042012
		public void SetReadOnlyTextBoxBackgroundColorBulk()
		{
			//mam 12192011
			//text boxes that are always read only - numeric
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			Color backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			}

			//mam 12192011
			//text boxes that are always read only - asset names
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames;
			}
			textBoxCurrentENR.BackColor = backgroundColor;

			//mam 0122201 - let's not change the color of the screen - the result varies depending on the selected theme
			//mam 12192011
			//screen background
			//mam 01222012 - always set background color of th screen so we can switch back to Control color if custom color is not being used
			//backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			//if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen)
			//{
			//	backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorScreen;
			//}
			//this.BackColor = backgroundColor;
			//this.tabPageMain.BackColor = backgroundColor;
			//this.tabPagePhotos.BackColor = backgroundColor;
			//this.tabPageAllocation.BackColor = backgroundColor;
			//this.tabPageValuation.BackColor = backgroundColor;
		}

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/

		//mam 03202012
		public void SetFacilityNameTextBox(string facilityName)
		{
			textBoxFacilityName.Text = facilityName;
		}

		public void			SetFacility(Facility facility)
		{
			if (m_facility != null)
			{
				// Make sure that the focus is taken off any control that has it
				// so that changed data may be saved
				treatmentProcessGrid1.Focus();
			}

			m_facility = facility;

			//mam 01222012 - added argument
			//RefreshData();
			RefreshData(false);
		}

		//mam - refresh funded grid after user sets rounding criteria
		public void SetFacilityFunded(Facility facility)
		{
			if (m_facility != null)
			{
				// Make sure that the focus is taken off any control that has it
				// so that changed data may be saved
				fundedTreatmentProcessGrid1.Focus();
			}

			m_facility = facility;

			if (m_facility == null)
				return;

			fundedTreatmentProcessGrid1.SetFacility(m_facility);
		}
		//</mam>

		//mam 01222012 - added parameter setToCurrentlySelectedTab
		//public void			RefreshData()
		public void			RefreshData(bool restoreTabSelection)
		{
			//mam 01222012
			int curTab = tabControl.SelectedIndex;

			treatmentProcessGrid1.SetFacility(m_facility);

			if (m_facility == null)
				return;

			m_facility.InfoSetID = InfoSet.CurrentID;
			textBoxFacilityName.Text = m_facility.Name;
			textBoxCurrentYear.Text = m_facility.CurrentYear.ToString();
			textBoxCurrentENR.Text = m_facility.CurrentENR.ToString();
			textBoxComments.Text = m_facility.Comments;
			textBoxAllocComments.Text = m_facility.Comments;
			textBoxValuationComments.Text = m_facility.Comments;

			//mam
			PopulateCustomENRGrid();
			//</mam>

			checkBoxCustomENR.Checked = m_facility.UsesCustomENRTable;

			//mam 01222012
			//tabControl.SelectedIndex = 0;
			tabControl.SelectedIndex = restoreTabSelection ? curTab : 0;

			UpdateTotals();

			//mam - disable controls if infoset is fixed
			SetControls();
			//</mam>
			
			//mam
			SetToolTips();
			//</mam>

			//mam 050806
			SetTabVisibility();

			//mam 01222012
			//set text box value to 1.00 if fac crit is not being used
			textBoxFacilityCriticality.Value = WAM.Common.Globals.ApplyFacilityCriticalityFactor ? m_facility.FacilityCriticality : 1.00M;
			textBoxFacilityCriticality.ReadOnly = !WAM.Common.Globals.ApplyFacilityCriticalityFactor;
			SetReadOnlyTextBoxBackgroundColor(textBoxFacilityCriticality);

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();
		}

		private void SetToolTips()
		{
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			toolTip.AutoPopDelay = 2500;
			toolTip.InitialDelay = 500;
			toolTip.ReshowDelay = 0;

			//toolTip.AutoPopDelay = 0;
			//toolTip.InitialDelay = 0;
			//toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			//toolTip.SetToolTip(this.checkBoxCustomENR, "");
			toolTip.SetToolTip(this.pictureBoxEdit, "Edit Custom ENR data");

			//mam 01222012
			toolTip.SetToolTip(this.pictureBoxConstraints, "View constraint data for this Facility");
		}

		//mam
		private void PopulateCustomENRGrid()
		{
			//  load the grid with a list of the ENR tables
			int selRow = 0;
			string queryValue = "";
			WAM.Common.GridMethods gridMethods;

			//if (checkBoxShowENRThisInfosetOnly.Checked)
			//	gridMethods = new WAM.Common.GridMethods(InfoSet.CurrentID);
			//else
				gridMethods = new WAM.Common.GridMethods();

			queryValue = gridMethods.QueryValueCustomENR;
			selRow = gridMethods.PopulateGrid(ref gridCustomENRTables, m_facility.CustomENRListID, queryValue);
			gridMethods = null;

			if (gridSortDirection == (int)C1.Win.C1FlexGrid.SortFlags.Descending)
			{
				gridCustomENRTables.Sort(C1.Win.C1FlexGrid.SortFlags.Descending, gridSortCol);
			}
			else
			{
				gridCustomENRTables.Sort(C1.Win.C1FlexGrid.SortFlags.Ascending, gridSortCol);
			}

			gridCustomENRTables.Cols[1].Width = gridColWidth;
			gridCustomENRTables.TopRow = selRow;

			WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid();
			
			if (gridItemDropDown == null)
			{
				textBoxSelectedCustomENRTable.Text = "";
			}
			else
			{
				textBoxSelectedCustomENRTable.Text = gridItemDropDown.ItemDescription;
			}

			//m_customENRListID = gridItemDropDown.ItemID;
			
		}
		//</mam>

		//mam
		public void HideGrid()
		{
			panelgridCustomENRTables.Visible = false;
		}
		//</mam>

		//mam
		private void ShowHideGrid()
		{
			PopulateCustomENRGrid();

			if (gridCustomENRTables.Rows.Count <= maxGridDropDownItems)
			{
				panelgridCustomENRTables.Height = (gridCustomENRTables.Rows[0].HeightDisplay * gridCustomENRTables.Rows.Count) + 2;
			}
			else
			{
				panelgridCustomENRTables.Height = (gridCustomENRTables.Rows[0].HeightDisplay * maxGridDropDownItems) + 2;
			}
			gridCustomENRTables.Height = panelgridCustomENRTables.Height - 2;

			panelgridCustomENRTables.Visible = !panelgridCustomENRTables.Visible;
		}
		//</mam>

		//mam
		private void textBoxSelectedCustomENRTable_TextChanged(object sender, System.EventArgs e)
		{
			HideGrid();
		}
		//</mam>

		//mam
		private void textBoxSelectedCustomENRTable_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			textBoxSelectedCustomENRTable.SelectionStart = 0;
			textBoxSelectedCustomENRTable.SelectionLength = textBoxSelectedCustomENRTable.Text.Length;
			ShowHideGrid();
		}
		//</mam>

		//mam
		private void textBoxSelectedCustomENRTable_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			//textBoxSelectedCustomENRTable.SelectionStart = 0;
			//textBoxSelectedCustomENRTable.SelectionLength = textBoxSelectedCustomENRTable.Text.Length;
		}
		//</mam>

		private void textBoxFacilityName_Leave(object sender, System.EventArgs e)
		{
			if (m_facility != null && textBoxFacilityName.Text.Length > 0)
			{
				if (string.Compare(m_facility.Name, textBoxFacilityName.Text) != 0)
				{
					//mam 07072011 - store pre-saved value in case save doesn't work
					string tempVal = m_facility.Name;

					// Update the name
					m_facility.Name = textBoxFacilityName.Text;

					//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
					//m_facility.Save();
					if (!SaveData())
					{
						m_facility.Name = tempVal;
					}
				}
			}
		}

		private void textBoxCurrentYear_Leave(object sender, System.EventArgs e)
		{		
			if (m_facility == null)
				return;

			short		year = Drive.Convert.StringToShort(textBoxCurrentYear.Text);

			//mam 01222012
			//if (m_facility.CurrentYear != year)
			if (m_facility.CurrentYear == year)
			{
				return;
			}

			//mam 07072011 - store pre-saved value in case save doesn't work
			short tempVal = m_facility.CurrentYear;
			bool UpdateOverriddenYears = false;

			//******************
			//mam 01222012
			//constraints:
			//	installation year <= last rehab year <= inspection year <= current year <= next rehab year or next replacement year
			//check database for constraint violation
			int proposedCurrentYear = year;
			int minCurrentYear = proposedCurrentYear;
			int maxCurrentYear = proposedCurrentYear;
			bool allowProposedCurrentYear = true;

			try
			{
				Facility.CheckFacilityYearConstraints(m_facility.ID, proposedCurrentYear
					, out minCurrentYear, out maxCurrentYear, out allowProposedCurrentYear);
			}
			catch(Exception ex)
			{
				textBoxCurrentYear.Text = tempVal.ToString();
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			//if minCurrentYear = -1, there is no lower boundary for facility current year
			//if maxCurrentYear = 99999, there is no upper boundary for facility current year
			//if both are -1, the stored procedure will return true for allowProposedCurrentYear
			//if minCurrentYear > maxCurrentYear, constraints have already been violated and the user must address that problem first
			//if proposed year is > maxCurrentYear, allow user to update all offending overridden next rehab/replacement years
			//if proposed year is < minCurrentYear, tell user that the proposed year cannot be set to that value
			
			string msg = string.Empty;
			if (!allowProposedCurrentYear)
			{
				if (minCurrentYear > maxCurrentYear || minCurrentYear > m_facility.CurrentYear)
				{
					msg += "The Facility Current Year cannot be set to  " + proposedCurrentYear.ToString() + ".";
					msg += "\r\n\r\nThe following timing constraints have been violated:";
					msg += "\r\n\r\nInstallation Year <= Last Rehabilitation Year <= Inspection Year <= Facility Current Year";
					msg += "\r\n\r\nThese values must be brought into compliance with the timing constraints before the Facility Current Year can be changed.";
					msg += "\r\n\r\nTo get a list of constraint violations, click the Constraint button next to the Facility Current Year.";

					textBoxCurrentYear.Text = tempVal.ToString();
					MessageBox.Show(this, msg, "Invalid Value for Facility Current Year", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				else if (proposedCurrentYear < minCurrentYear)
				{
					msg += "The Facility Current Year cannot be set to  " + proposedCurrentYear.ToString() + ".";
					msg += "\r\n\r\nFacility Current Year must be  >=  " + minCurrentYear.ToString() + ".";
					msg += "\r\n\r\n" + minCurrentYear.ToString() + " is the maximum value of";
					msg += " all the Installation Years, Last Rehabilitation Years, and Inspection Years in the Facility.";

					textBoxCurrentYear.Text = tempVal.ToString();
					MessageBox.Show(this, msg, "Invalid Value for Facility Current Year", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				else if (proposedCurrentYear > maxCurrentYear)
				{
					msg += "The value  " + proposedCurrentYear.ToString() + "  violates the following timing constraint:";
					msg += "\r\n\r\nFacility Current Year must be <= Next Replacement Year and Next Rehabilitation Year.";
					msg += "\r\n\r\n" + proposedCurrentYear.ToString() + " is > existing Next Replacement and Next Rehabilitation years.";
					msg += "\r\n\r\nIf you continue, Facility Current Year will be set to " + proposedCurrentYear.ToString();
					msg += ", and all Next Replacement and Next Rehabilitation years";
					msg += " that are less than " + proposedCurrentYear.ToString() + " (including overridden values) will be set to " + proposedCurrentYear.ToString() + ".";

					msg += "\r\n\r\nNote: To preview a list of assets which would be affected by this change first, select 'No' below";
					msg += " and click the button to the right of the Current Year field."; 

					msg += "\r\n\r\nWould you like to continue?";

					DialogResult dialogResult = MessageBox.Show(this, msg, "Facility Current Year", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

					if (dialogResult != DialogResult.Yes)
					{
						textBoxCurrentYear.Text = tempVal.ToString();
						return;
					}

					UpdateOverriddenYears = true;
				}
				else
				{
					//we don't know why the proposed facility current year is not allowed
					//this should never happen

					msg += "The Facility Current Year cannot be set to  " + proposedCurrentYear.ToString() + ".";
					msg += "\r\n\r\nThe reason is unknown.";

					textBoxCurrentYear.Text = tempVal.ToString();
					MessageBox.Show(this, msg, "Invalid Value for Facility Current Year", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
			}

			//******************

			m_facility.CurrentYear = year;

			//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
			//m_facility.Save();
			if (!SaveData())
			{
				m_facility.CurrentYear = tempVal;
			}

			//mam 01222012
			try
			{
				if (UpdateOverriddenYears)
				{
					Facility.UpdateOverriddenYears(m_facility.ID, year);
					Facility.UpdateDisciplineCacheOverriddenYears(m_facility.InfoSetID, m_facility.ID, year);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			treatmentProcessGrid1.SetFacility(m_facility);
			fundedTreatmentProcessGrid1.SetFacility(m_facility);
			textBoxCurrentYear.Text = year.ToString();

			textBoxCurrentENR.Text = m_facility.CurrentENR.ToString();
		}

		private void textBoxComments_Leave(object sender, System.EventArgs e)
		{
			if (m_facility == null)
				return;

			bool			changed = false;

			//mam 07072011
			string tempVal = string.Empty;

			if (sender is TextBox)
			{
				if (((TextBox)sender).Text != m_facility.Comments)
				{
					//mam 07072011 - store pre-saved value in case save doesn't work
					tempVal = m_facility.Comments;

					m_facility.Comments = ((TextBox)sender).Text;
					changed = true;
				}
			}

			if (changed)
			{
				//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_facility.Save();
				if (!SaveData())
				{
					m_facility.Comments = tempVal;
				}

				// Update all of the comments fields that are NOT 
				// the comments field that sent the notification
				if (!object.ReferenceEquals(sender, textBoxComments))
					textBoxComments.Text = m_facility.Comments;
				if (!object.ReferenceEquals(sender, textBoxAllocComments))
					textBoxAllocComments.Text = m_facility.Comments;
				if (!object.ReferenceEquals(sender, textBoxValuationComments))
					textBoxValuationComments.Text = m_facility.Comments;
			}
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPageMain)
			{
				treatmentProcessGrid1.SetFacility(m_facility);
				UpdateTotals();
			}
			else if (tabControl.SelectedTab == tabPageValuation)
			{
				fundedTreatmentProcessGrid1.SetFacility(m_facility);
				UpdateFundedTotals();
			}
			else if (tabControl.SelectedTab == tabPageAllocation)
				gridAllocation.SetRootObject(m_facility);
			else if (tabControl.SelectedTab == tabPagePhotos)
			{
				if (m_facility != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxCaptionNorth.Text = m_facility.CaptionNorth;
					textBoxCaptionSouth.Text = m_facility.CaptionSouth;

					//mam 03202012
					string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);
					textBoxPhotoFileNameNorth.Text = m_facility.PhotoFileNameNorth == "" ? m_facility.PhotoFileNameNorth 
						: targetPath + "\\" + m_facility.PhotoFileNameNorth;
					textBoxPhotoFileNameSouth.Text = m_facility.PhotoFileNameSouth == "" ? m_facility.PhotoFileNameSouth 
						: targetPath + "\\" + m_facility.PhotoFileNameSouth;


					pictureBoxNorth.Image = m_facility.GetPhoto1();
					if (pictureBoxNorth.Image == null)
						buttonPictureNorth.Text = "Browse";
					else
						buttonPictureNorth.Text = "Delete";

					pictureBoxSouth.Image = m_facility.GetPhoto2();
					if (pictureBoxSouth.Image == null)
						buttonPictureSouth.Text = "Browse";
					else
						buttonPictureSouth.Text = "Delete";
				}
				else
				{
					textBoxCaptionNorth.Text = "";
					textBoxCaptionSouth.Text = "";

					//mam 03202012
					textBoxPhotoFileNameNorth.Text = "";
					textBoxPhotoFileNameSouth.Text = "";
					buttonPictureNorth.Text = "Browse";
					buttonPictureSouth.Text = "Browse";

					pictureBoxNorth.Image = null;
					pictureBoxSouth.Image = null;
				}
			}
		}

		private void tabPagePhotos_Resize(object sender, System.EventArgs e)
		{
			// Need to move the photos around
			// Make the photos take about half the tab each
			int				tabWidth = (tabPagePhotos.ClientSize.Width - 12);
			int				photoWidth = tabWidth / 2;
			int				buttonOffset = (photoWidth / 2) - (buttonPictureNorth.Width / 2);

			pictureBoxNorth.Width = photoWidth;
			buttonPictureNorth.Left = pictureBoxNorth.Left + buttonOffset;

			pictureBoxSouth.SuspendLayout();
			pictureBoxSouth.Left = (pictureBoxNorth.Right + 2);
			pictureBoxSouth.Width = photoWidth;
			pictureBoxSouth.ResumeLayout(true);

			//mam 03202012
			//textBoxCaptionNorth.Width = photoWidth;
			textBoxCaptionNorth.Width = pictureBoxNorth.Width - textBoxCaptionNorth.Left;
			textBoxPhotoFileNameNorth.Width = textBoxCaptionNorth.Width;

			buttonPictureSouth.Left = pictureBoxSouth.Left + buttonOffset;

			//mam 03202012
			//textBoxCaptionSouth.SuspendLayout();
			labelCaptionPhotoSouth.Left = pictureBoxSouth.Left - 2;
			labelFileNamePhotoSouth.Left = labelCaptionPhotoSouth.Left;
			textBoxCaptionSouth.Left = pictureBoxSouth.Left + 56;
			textBoxPhotoFileNameSouth.Left = textBoxCaptionSouth.Left;
			textBoxCaptionSouth.Width = pictureBoxSouth.Width - 56;
			textBoxPhotoFileNameSouth.Width = textBoxCaptionSouth.Width;
			//textBoxCaptionSouth.ResumeLayout(true);

			//062407 - resize pictureboxes so they don't cover up the text box and Browse button by 
			//	extending beyond the bottom of the tab page
			pictureBoxNorth.Height = textBoxCaptionNorth.Top - pictureBoxNorth.Top - 4;
			pictureBoxSouth.Height = textBoxCaptionSouth.Top - pictureBoxSouth.Top - 4;
		}

		private void buttonPictureNorth_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - this entire method was reworked, and all old code was deleted

			string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);

			/*
			fileNameWithoutPath			original file name without path; this may be modified in the save routine (to get a distinct file name)
			sourceFileWithPath			source path + original file name
			selectedFileNameWithPath	target path + final file name		no longer used
			targetPathWithFileName		target + 
			*/

			if (pictureBoxNorth.Image == null)
			{
				//put an image into the picture box

				//******************

				//make sure photo path exists

				//mam 102309 - get the infoset image path - if the string is "", the path does not exist in the WAM.xml file
				//	the user must set the path Edit > WAM Image Folder
				//string infoSetPhotoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);
				string msg = "";
				if (targetPath == "")
				{
					//mam 03222012 - revised message
					//msg = "Please set the base images folder in the <PhotoPaths><BaseImagePath> section of the WAM.xml file before selecting a photo.";
					msg = "Please select the image folder location by clicking Edit > WAM Image Folder in the menu.";
					MessageBox.Show(this, msg, "Set Image Folder Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				//mam 07072011 - check for the existence of targetPath and let the user know if it doesn't exist
				if (!Common.CommonTasks.DoesImagesFolderExist(targetPath))
				{
					return;
				}

				//******************

				//show the open file dialog so the user can select a photo to display in this facility

				string fileNameWithoutPath = "";
				OpenFileDialog	fileDialog = new OpenFileDialog();

				fileDialog.Filter = "JPG Images (*.jpg)|*.jpg|Portable Network Graphics png (*.png)|*.png";
				fileDialog.CheckFileExists = true;
				fileDialog.Multiselect = false;

				if (fileDialog.ShowDialog(this) == DialogResult.OK)
				{
					//the user has selected a photo

					//******************

					//save the file to the infoset images folder

					Image image = null;
					bool sourcePathSameAsDestinationPath = false;
					string sourceFileWithPath = fileDialog.FileName;

					if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
					{
						//let WAM create the name the photo file using the facility Id
						string targetPathIdStyle = m_facility.GetImage1PathIdStyle();
						fileNameWithoutPath = System.IO.Path.GetFileName(targetPathIdStyle);
						if (WAM.Common.CommonTasks.CopyImageFile(sourceFileWithPath, targetPathIdStyle))
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(targetPathIdStyle, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
					}
					else
					{
						//if the user has selected a file that is already in the infoset image path, don't copy that file and rename it, 
						//	just add the file name to the database for this facility
						fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
						sourcePathSameAsDestinationPath = string.Compare(System.IO.Path.GetDirectoryName(sourceFileWithPath), targetPath, true) == 0;
						if (sourcePathSameAsDestinationPath)
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(sourceFileWithPath, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
						else
						{
							//copy the file from the source folder to the infoset image folder

							//fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
							if (!WAM.UI.PhotoFileSave.ShowForm(sourceFileWithPath, targetPath, ref fileNameWithoutPath, ref image))
							{
								//if the user cancels the save, return
								return;
							}
						}
					}

					//try to put the image into the picture box - if it fails, delete the photo file from the infoset images folder
					//	(as long as it is not being used by any other asset)

					try
					{
						pictureBoxNorth.Image = image;

						if (pictureBoxNorth.Image == null)
						{
							//the image was not inserted into the picturebox; remove the file that was copied into the images folder

							try
							{
								//mam 3202012 - don't delete the image if it is used by another asset
								//sourcePathSameAsDestinationPath = true indicates that the image was already in the infoset image folder, 
								//	which should mean that it is used by another asset
								if (!sourcePathSameAsDestinationPath)
								{
									System.IO.File.Delete(targetPath + "\\" + fileNameWithoutPath);
								}
							}
							catch
							{
							}

							//mam 03202012 - change this message to say that the image cannot be displayed
							//MessageBox.Show(this, "The file is not a valid image file or the Infoset image folder cannot be found.", "Photo File", 
							//	MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							MessageBox.Show(this, "The image cannot be displayed.  The image may not be a valid image file.", "Photo File", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						else
						{
							//the image was successfully inserted into the picture box, so save the data

							string tempVal = m_facility.CaptionNorth;
							string tempVal2 = m_facility.PhotoFileNameNorth;

							//string selectedFileNameWithPath = targetPath + "\\" + fileNameWithoutPath;
							//m_facility.CaptionNorth = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, false);
							//m_facility.PhotoFileNameNorth = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, true);
							if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
							{
								m_facility.CaptionNorth = System.IO.Path.GetFileNameWithoutExtension(sourceFileWithPath);
								m_facility.PhotoFileNameNorth = fileNameWithoutPath;
							}
							else
							{
								m_facility.CaptionNorth = System.IO.Path.GetFileNameWithoutExtension(fileNameWithoutPath);
								m_facility.PhotoFileNameNorth = fileNameWithoutPath;
							}

							if (!SaveData())
							{
								//the save failed, so set the caption and file name back to their original values
								m_facility.CaptionNorth = tempVal;
								m_facility.PhotoFileNameNorth = tempVal2;
							}

							textBoxCaptionNorth.Text = m_facility.CaptionNorth;
							textBoxPhotoFileNameNorth.Text = targetPath + "\\" + m_facility.PhotoFileNameNorth;

							buttonPictureNorth.Text = "Delete";
						}
					}
					catch(Exception ex)
					{
						MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			else
			{
				//remove the photo from the facility

				//mam 03202012
				//string		targetPath = m_facility.GetImagePath();
				string targetPathWithFileName = targetPath + "\\" + m_facility.PhotoFileNameNorth;

				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_facility.CaptionNorth;
				string tempVal2 = m_facility.PhotoFileNameNorth;

				m_facility.CaptionNorth = "";
				m_facility.PhotoFileNameNorth = "";
				
				//******************

				//if the save is successful, remove the photo file from the infoset images folder
				//	(as long as it is not used by any other asset)

				if (SaveData())
				{
					pictureBoxNorth.Image = null;
					buttonPictureNorth.Text = "Browse";

					//mam 03202012 - if the file is being used by other assets, don't delete it
					//if IsImageFileUsedByOtherAssets returns -1, an error has occurred while checking the data in the database,
					//	so we don't know whether the file is used by another asset - don't delete the file
					bool fileInUse = Common.CommonTasks.GetPhotoCount(this.m_facility.InfoSetID, tempVal2) > 0;

					//mam 03202012 - added check for fileInUse - don't delete file if file is used by other assets
					if (!fileInUse)
					{
						try
						{
							//set the file to be not read only, just in case the user has pulled a fast one and
							//	has copied a read-only image into the images folder
							if (System.IO.File.Exists(targetPathWithFileName))
							{
								System.IO.File.SetAttributes(targetPathWithFileName, System.IO.FileAttributes.Normal);
								System.IO.File.Delete(targetPathWithFileName);
							}
						}
						catch(Exception ex)
						{
							MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
				}
				else
				{
					//the save was not successful - set the caption and file name to their original values

					m_facility.CaptionNorth = tempVal;
					m_facility.PhotoFileNameNorth = tempVal2;
				}

				textBoxCaptionNorth.Text = m_facility.CaptionNorth;
				textBoxPhotoFileNameNorth.Text = m_facility.PhotoFileNameNorth == "" ? m_facility.PhotoFileNameNorth : targetPath + "\\" + m_facility.PhotoFileNameNorth;
			}
		}

		//mam 102309 - modified
		private void buttonPictureSouth_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - this entire method was reworked, and all old code was deleted

			string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);

			/*
			fileNameWithoutPath			original file name without path; this may be modified in the save routine (to get a distinct file name)
			sourceFileWithPath			source path + original file name
			selectedFileNameWithPath	target path + final file name		no longer used
			targetPathWithFileName		target + 
			*/

			if (pictureBoxSouth.Image == null)
			{
				//put an image into the picture box

				//******************

				//make sure photo path exists

				//mam 102309 - get the infoset image path - if the string is "", the path does not exist in the WAM.xml file
				//	the user must set the path Edit > WAM Image Folder
				//string infoSetPhotoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);
				string msg = "";
				if (targetPath == "")
				{
					//mam 03222012 - revised message
					//msg = "Please set the base images folder in the <PhotoPaths><BaseImagePath> section of the WAM.xml file before selecting a photo.";
					msg = "Please select the image folder location by clicking Edit > WAM Image Folder in the menu.";
					MessageBox.Show(this, msg, "Set Image Folder Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				//mam 07072011 - check for the existence of targetPath and let the user know if it doesn't exist
				if (!Common.CommonTasks.DoesImagesFolderExist(targetPath))
				{
					return;
				}

				//******************

				//show the open file dialog so the user can select a photo to display in this facility

				string fileNameWithoutPath = "";
				OpenFileDialog	fileDialog = new OpenFileDialog();

				fileDialog.Filter = "JPG Images (*.jpg)|*.jpg|Portable Network Graphics png (*.png)|*.png";
				fileDialog.CheckFileExists = true;
				fileDialog.Multiselect = false;

				if (fileDialog.ShowDialog(this) == DialogResult.OK)
				{
					//the user has selected a photo

					//******************

					//save the file to the infoset images folder

					Image image = null;
					bool sourcePathSameAsDestinationPath = false;
					string sourceFileWithPath = fileDialog.FileName;

					if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
					{
						//let WAM create the name the photo file using the facility Id
						string targetPathIdStyle = m_facility.GetImage2PathIdStyle();
						fileNameWithoutPath = System.IO.Path.GetFileName(targetPathIdStyle);
						if (WAM.Common.CommonTasks.CopyImageFile(sourceFileWithPath, targetPathIdStyle))
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(targetPathIdStyle, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
					}
					else
					{
						//if the user has selected a file that is already in the infoset image path, don't copy that file and rename it, 
						//	just add the file name to the database for this facility
						fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
						sourcePathSameAsDestinationPath = string.Compare(System.IO.Path.GetDirectoryName(sourceFileWithPath), targetPath) == 0;
						if (sourcePathSameAsDestinationPath)
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(sourceFileWithPath, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
						else
						{
							//copy the file from the source folder to the infoset image folder

							//fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
							if (!WAM.UI.PhotoFileSave.ShowForm(sourceFileWithPath, targetPath, ref fileNameWithoutPath, ref image))
							{
								//if the user cancels the save, return
								return;
							}
						}
					}

					//try to put the image into the picture box - if it fails, delete the photo file from the infoset images folder
					//	(as long as it is not being used by any other asset)

					try
					{
						pictureBoxSouth.Image = image;

						if (pictureBoxSouth.Image == null)
						{
							//the image was not inserted into the picturebox; remove the file that was copied into the images folder

							try
							{
								//mam 3202012 - don't delete the image if it is used by another asset
								//sourcePathSameAsDestinationPath = true indicates that the image was already in the infoset image folder, 
								//	which should mean that it is used by another asset
								if (!sourcePathSameAsDestinationPath)
								{
									System.IO.File.Delete(targetPath + "\\" + fileNameWithoutPath);
								}
							}
							catch
							{
							}

							//mam 03202012 - change this message to say that the image cannot be displayed
							//MessageBox.Show(this, "The file is not a valid image file or the Infoset image folder cannot be found.", "Photo File", 
							//	MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							MessageBox.Show(this, "The image cannot be displayed.  The image may not be a valid image file.", "Photo File", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						else
						{
							//the image was successfully inserted into the picture box, so save the data

							string tempVal = m_facility.CaptionSouth;
							string tempVal2 = m_facility.PhotoFileNameSouth;

							//string selectedFileNameWithPath = targetPath + "\\" + fileNameWithoutPath;
							//m_facility.CaptionSouth = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, false);
							//m_facility.PhotoFileNameSouth = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, true);
							if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
							{
								m_facility.CaptionSouth = System.IO.Path.GetFileNameWithoutExtension(sourceFileWithPath);
								m_facility.PhotoFileNameSouth = fileNameWithoutPath;
							}
							else
							{
								m_facility.CaptionSouth = System.IO.Path.GetFileNameWithoutExtension(fileNameWithoutPath);
								m_facility.PhotoFileNameSouth = fileNameWithoutPath;
							}

							if (!SaveData())
							{
								//the save failed, so set the caption and file name back to their original values
								m_facility.CaptionSouth = tempVal;
								m_facility.PhotoFileNameSouth = tempVal2;
							}

							textBoxCaptionSouth.Text = m_facility.CaptionSouth;
							textBoxPhotoFileNameSouth.Text = targetPath + "\\" + m_facility.PhotoFileNameSouth;

							buttonPictureSouth.Text = "Delete";
						}
					}
					catch(Exception ex)
					{
						MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			else
			{
				//remove the photo from the facility

				//mam 03202012
				//string		targetPath = m_facility.GetImagePath();
				string targetPathWithFileName = targetPath + "\\" + m_facility.PhotoFileNameSouth;

				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_facility.CaptionSouth;
				string tempVal2 = m_facility.PhotoFileNameSouth;

				m_facility.CaptionSouth = "";
				m_facility.PhotoFileNameSouth = "";
				
				//******************

				//if the save is successful, remove the photo file from the infoset images folder
				//	(as long as it is not used by any other asset)

				if (SaveData())
				{
					pictureBoxSouth.Image = null;
					buttonPictureSouth.Text = "Browse";

					//mam 03202012 - if the file is being used by other assets, don't delete it
					//if IsImageFileUsedByOtherAssets returns -1, an error has occurred while checking the data in the database,
					//	so we don't know whether the file is used by another asset - don't delete the file
					bool fileInUse = Common.CommonTasks.GetPhotoCount(this.m_facility.InfoSetID, tempVal2) > 0;

					//mam 03202012 - added check for fileInUse - don't delete file if file is used by other assets
					if (!fileInUse)
					{
						try
						{
							//set the file to be not read only, just in case the user has pulled a fast one and
							//	has copied a read-only image into the images folder
							if (System.IO.File.Exists(targetPathWithFileName))
							{
								System.IO.File.SetAttributes(targetPathWithFileName, System.IO.FileAttributes.Normal);
								System.IO.File.Delete(targetPathWithFileName);
							}
						}
						catch(Exception ex)
						{
							MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
				}
				else
				{
					//the save was not successful - set the caption and file name to their original values

					m_facility.CaptionSouth = tempVal;
					m_facility.PhotoFileNameSouth = tempVal2;
				}

				textBoxCaptionSouth.Text = m_facility.CaptionSouth;
				textBoxPhotoFileNameSouth.Text = m_facility.PhotoFileNameSouth == "" ? m_facility.PhotoFileNameSouth : targetPath + "\\" + m_facility.PhotoFileNameSouth;
			}
		}

		//mam 102309
		//mam 102309 - don't use this
//		private void AssignImage(bool isNorth)
//		{
//			string infoSetPhotoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_facility.InfoSetID);
//			string msg = "";
//			if (infoSetPhotoPath == "")
//			{
//				msg = "Please set the InfoSet Image Folder Location on the Infoset screen before selecting a photo.";
//				MessageBox.Show(this, msg, "Set InfoSet Image Folder Location", MessageBoxButtons.OK, MessageBoxIcon.Information);
//				return;
//			}
//
//			OpenFileDialog	fileDialog = new OpenFileDialog();
//			fileDialog.Filter = "JPG Images (*.jpg)|*.jpg";
//			fileDialog.CheckFileExists = true;
//			fileDialog.Multiselect = false;
//			fileDialog.RestoreDirectory = true;
//			fileDialog.InitialDirectory = infoSetPhotoPath;
//
//			if (fileDialog.ShowDialog(this) == DialogResult.OK)
//			{
//				string fileNameWithPath = fileDialog.FileName;
//				string fileNameWithExt = Drive.IO.Directory.GetFileNameFromPath(fileNameWithPath, true);
//				string fileNameWithoutExt = Drive.IO.Directory.GetFileNameFromPath(fileNameWithPath, false);
//				string userSelectedPhotoPath = fileNameWithPath.Substring(0, fileNameWithPath.LastIndexOf("\\"));
//
//				if (!infoSetPhotoPath.Equals(userSelectedPhotoPath))
//				{
//					msg = "You must select a photo from the Infoset's image directory  ("
//						+ infoSetPhotoPath + ")";
//					MessageBox.Show(this, msg, "Select From InfoSet's Image Directory", MessageBoxButtons.OK, MessageBoxIcon.Information);
//					return;
//				}
//
//				try
//				{
//					//mam 102309 - don't copy the selected image into a local (or server) folder - just point to it
//					//mam 102309 - no, restore original method
//					if (isNorth)
//					{
//						m_facility.CaptionNorth = fileNameWithoutExt;
//						//m_facility.PhotoNorth = fileNameWithExt;
//						m_facility.Save();
//						textBoxCaptionNorth.Text = m_facility.CaptionNorth;
//					}
//					else
//					{
//						m_facility.CaptionSouth = fileNameWithoutExt;
//						//m_facility.PhotoSouth = fileNameWithExt;
//						m_facility.Save();
//						textBoxCaptionSouth.Text = m_facility.CaptionSouth;
//						//pictureBoxSouth.Image = m_facility.GetPhoto2();
//					}
//
//					Image image = null;
//					using (System.IO.FileStream fileStream = new System.IO.FileStream(fileNameWithPath, System.IO.FileMode.Open))
//					{
//						image = Image.FromStream(fileStream);
//						fileStream.Close();
//					}
//
//					if (isNorth)
//					{
//						pictureBoxNorth.Image = image;
//						buttonPictureNorth.Text = "Delete";
//					}
//					else
//					{
//						pictureBoxSouth.Image = image;
//						buttonPictureSouth.Text = "Delete";
//					}
//				}
//				catch(Exception ex)
//				{
//					MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
//						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//				}
//			}
//		}

		private void textBoxCaptionNorth_Leave(object sender, System.EventArgs e)
		{
			if (m_facility.CaptionNorth != textBoxCaptionNorth.Text)
			{
				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_facility.CaptionNorth;

				m_facility.CaptionNorth = textBoxCaptionNorth.Text;

				//mam 07072011 - call   instead of .Save() so we can show an error message if necessary
				//m_facility.Save();
				if (!SaveData())
				{
					m_facility.CaptionNorth = tempVal;
				}
			}
		}

		private void		textBoxCaptionSouth_Leave(object sender, System.EventArgs e)
		{
			if (m_facility.CaptionSouth != textBoxCaptionSouth.Text)
			{
				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_facility.CaptionSouth;

				m_facility.CaptionSouth = textBoxCaptionSouth.Text;

				//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_facility.Save();
				if (!SaveData())
				{
					m_facility.CaptionSouth = tempVal;
				}
			}
		}

		private void		UpdateTotals()
		{
			decimal			acquisitionCost = m_facility.GetAcquisitionCost();
			decimal			currentValue = m_facility.GetCurrentValue();

			//mam - comment because rounding is used below
			//labelAcquisitionCost.Text = acquisitionCost.ToString("$#,##0");
			//labelCurrentValue.Text = currentValue.ToString("$#,##0");
			//labelAcqCostLessCumDepr.Text = (acquisitionCost - m_facility.GetCumulativeDepreciation()).ToString("$#,##0");
			//labelCurValLessRepairCost.Text = (currentValue - m_facility.GetRepairCost()).ToString("$#,##0");
			//labelReplaceVal.Text = m_facility.GetReplacementValue().ToString("$#,##0");
			//</mam>

			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			labelAcquisitionCost.Text = WAMRounding.RoundNumber(acquisitionCost, roundDigit).ToString("$#,##0");
			labelCurrentValue.Text = WAMRounding.RoundNumber(currentValue, roundDigit).ToString("$#,##0");
			labelAcqCostLessCumDepr.Text = WAMRounding.RoundNumber((acquisitionCost - m_facility.GetCumulativeDepreciation()), roundDigit).ToString("$#,##0");
			labelCurValLessRepairCost.Text = WAMRounding.RoundNumber((currentValue - m_facility.GetRepairCost()), roundDigit).ToString("$#,##0");
			labelReplaceVal.Text = WAMRounding.RoundNumber(m_facility.GetReplacementValue(), roundDigit).ToString("$#,##0");
			WAMRounding = null;
			//</mam>
		}

		private void		UpdateFundedTotals()
		{
			decimal			fundedAcquisitionCost = m_facility.GetFundedAcquisitionCost();
			decimal			fundedCurrentValue = m_facility.GetFundedCurrentValue();

			//mam - comment because rounding is used below
			//labelFundedAcquisitionCost.Text = fundedAcquisitionCost.ToString("$#,##0");
			//labelFundedCurrentValue.Text = fundedCurrentValue.ToString("$#,##0");
			//labelFundedCostLessCumDepr.Text = (fundedAcquisitionCost - m_facility.GetFundedCumulativeDepreciation()).ToString("$#,##0");
			//labelFundedCurValueLessRepairCost.Text = (fundedCurrentValue - m_facility.GetFundedRepairCost()).ToString("$#,##0");
			//labelFundedReplacementValue.Text = m_facility.GetFundedReplacementValue().ToString("$#,##0");
			//</mam>

			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			labelFundedAcquisitionCost.Text = WAMRounding.RoundNumber(fundedAcquisitionCost, roundDigit).ToString("$#,##0");
			labelFundedCurrentValue.Text = WAMRounding.RoundNumber(fundedCurrentValue, roundDigit).ToString("$#,##0");
			labelFundedCostLessCumDepr.Text = WAMRounding.RoundNumber((fundedAcquisitionCost - m_facility.GetFundedCumulativeDepreciation()), roundDigit).ToString("$#,##0");
			labelFundedCurValueLessRepairCost.Text = WAMRounding.RoundNumber((fundedCurrentValue - m_facility.GetFundedRepairCost()), roundDigit).ToString("$#,##0");
			labelFundedReplacementValue.Text = WAMRounding.RoundNumber(m_facility.GetFundedReplacementValue(), roundDigit).ToString("$#,##0");
			WAMRounding = null;
			//</mam>
		}

		private void		UpdateGridAndTotals()
		{
			treatmentProcessGrid1.SetFacility(m_facility);
			
			//mam - added this line so that Valuation Options grid will be updated if the user clicks
			//	the custom ENR checkbox while viewing the Valuation Options grid
			fundedTreatmentProcessGrid1.SetFacility(m_facility);
			//</mam>

			UpdateTotals();			
		}

		private void		checkBoxCustomENR_CheckedChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			//mam 07072011 - store pre-saved value in case save doesn't work
			bool tempVal = m_facility.UsesCustomENRTable;

			m_facility.UsesCustomENRTable = checkBoxCustomENR.Checked;

			//mam
			if (checkBoxCustomENR.Checked)
			{
				gridCustomENRTables_MouseUp(null, null);
				WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid();
				if (gridItemDropDown != null)
				{
					textBoxSelectedCustomENRTable.Text = gridItemDropDown.ItemDescription;
					int listID = gridItemDropDown.ItemID;
					m_facility.LoadCustomENRValues(listID);
					SetFacility(m_facility);
				}
			}
			else
			{
				m_facility.CustomENRListID = 0;
			}
			//</mam>

			//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
			//m_facility.Save();
			if (!SaveData())
			{
				m_facility.UsesCustomENRTable = tempVal;
			}

			//mam
			SetEnabled();
			//</mam>

			textBoxCurrentENR.Text = m_facility.CurrentENR.ToString();
			UpdateGridAndTotals();
		}

		private void FacilityControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		//mam
		public int TabControlIndex
		{
			get {return tabControl.SelectedIndex;}
			set {tabControl.SelectedIndex = value;}
		}
		//</mam>

		//mam
		//mam 07072011 - changed to return bool
		//public void SaveData()
		public bool SaveData()
		{
			try
			{
				//mam 07072011 - added bool success
				bool success = m_facility.Save();
				if (!success)
				{
					//mam 03202012 - if the user doesn't have write permission, don't show the save error
					if (!WAM.Common.Globals.UserHasWritePermission)
					{
						return true;
					}

					Common.CommonTasks.ShowErrorMessage("Facility.SaveData", "An error occurred while saving the Facility data.");
					return false;
				}
			}
			catch(Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage(this.Name + ".SaveData", ex.Message);
				return false;
			}

			return true;
		}
		//</mam>

		//mam - disable controls if infoset is fixed
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;
			checkBoxCustomENR.Enabled = !isFixedInfoset;
			textBoxFacilityName.ReadOnly = isFixedInfoset;
			textBoxCurrentYear.ReadOnly = isFixedInfoset;
			textBoxComments.ReadOnly = isFixedInfoset;
			textBoxValuationComments.ReadOnly = isFixedInfoset;
			textBoxAllocComments.ReadOnly = isFixedInfoset;

			textBoxCaptionNorth.ReadOnly = isFixedInfoset;
			buttonPictureNorth.Enabled = !isFixedInfoset;
			textBoxCaptionSouth.ReadOnly = isFixedInfoset;
			buttonPictureSouth.Enabled = !isFixedInfoset;

			//mam 01222012
			textBoxFacilityCriticality.ReadOnly = isFixedInfoset;

			SetEnabled();

			panelLocked.Visible = isFixedInfoset;
		}
		//</mam>

		private void SetEnabled()
		{
			if (InfoSet.IsFixed)
			{
				textBoxSelectedCustomENRTable.Enabled = false;
				pictureBoxShowGrid.Visible = false;
				
				//always visible so user can see the ENR values for the locked infoset
				//pictureBoxEdit.Visible = false;
				pictureBoxEdit.Visible = true;

				gridCustomENRTables.Enabled = false;
			}
			else
			{
				if (gridCustomENRTables.Rows.Count > 1)
				{
					textBoxSelectedCustomENRTable.Visible = true;
					textBoxSelectedCustomENRTable.Enabled = checkBoxCustomENR.Checked;
				}
				else
				{
					textBoxSelectedCustomENRTable.Visible = checkBoxCustomENR.Checked;
				}
				pictureBoxShowGrid.Visible = checkBoxCustomENR.Checked;
				pictureBoxEdit.Visible = true;
				gridCustomENRTables.Enabled = checkBoxCustomENR.Checked;
			}
		}

		//mam
		public void SetEquationControls()
		{
			treatmentProcessGrid1.SetEquationControls();

			//mam 01222012
			equationViewerHandler.AssignMouseHandler(this);
			equationViewerHandler.AssignCursor(this);
		}
		//</mam>

		//mam 01222012
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
			//MessageBox.Show(this.ParentForm.Name);
		}

		//mam 01222012
		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
			//MessageBox.Show(this.ParentForm.Name);
		}

		//mam 01222012
		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
			//MessageBox.Show(this.ParentForm.Name);
		}

		//mam 03202012 - this method is no longer being used
//		//mam 102309 - no longer deleting photos
//		//mam 102309 - yes, we are
//		//mam
//		public void DeletePhotos(int facilityID, int infosetID)
//		{
//			if (m_facility == null)
//				return;
//
//			string photoPath1 = m_facility.GetImage1Path(facilityID, infosetID);
//			string photoPath2 = m_facility.GetImage2Path(facilityID, infosetID);
//
//			//delete photo files
//			try
//			{
//				if (System.IO.File.Exists(photoPath1))
//					System.IO.File.Delete(photoPath1);
//
//				if (System.IO.File.Exists(photoPath2))
//					System.IO.File.Delete(photoPath2);
//			}
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine("Error.  Facility photo not deleted." + ex.Message.ToString());
//				//MessageBox.Show("Unable to delete Facility photo file(s).", "Delete Facility Photo File", 
//				//	MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//			}
//		}
//		//</mam>

		//mam - added code so that if user types into only one field, say the facility name field,
		//	and then clicks on another facility node in the tree, the process name will be saved
		private void textBoxFacilityName_TextChanged(object sender, System.EventArgs e)
		{
			m_facility.Name = textBoxFacilityName.Text;
		}

		private void textBoxCurrentYear_TextChanged(object sender, System.EventArgs e)
		{
			//this is not necessary because the CurrentYear gets saved whenever it is changed
			//m_facility.CurrentYear = Drive.Convert.StringToShort(textBoxCurrentYear.Text);
		}

		private void textBoxComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_facility.Comments = textBoxComments.Text;
		}

		private void textBoxValuationComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_facility.Comments = textBoxValuationComments.Text;
		}

		private void textBoxAllocComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_facility.Comments = textBoxAllocComments.Text;
		}

		private void textBoxCaptionNorth_TextChanged(object sender, System.EventArgs e)
		{
			m_facility.CaptionNorth = textBoxCaptionNorth.Text;
		}

		private void textBoxCaptionSouth_TextChanged(object sender, System.EventArgs e)
		{
			m_facility.CaptionSouth = textBoxCaptionSouth.Text;
		}

		//mam
		private void gridCustomENRTables_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (!m_initialized)
				return;

			if (gridCustomENRTables.MouseRow > 0 && !justResizedColumn)
			{
				WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid();
				////m_customENRListID = gridItemDropDown.ItemID;
				//m_facility.CustomENRListID = gridItemDropDown.ItemID;
				textBoxSelectedCustomENRTable.Text = gridItemDropDown.ItemDescription;
				HideGrid();

				int listID = gridItemDropDown.ItemID;
				m_facility.LoadCustomENRValues(listID);
				SetFacility(m_facility);
			}

			justResizedColumn = false;
		}
		//</mam>

		//mam
		private WAM.Common.ComboBoxItem GetSelectedRecordENRTableGrid()
		{
			WAM.Common.ComboBoxItem gridItemDropDown = null;

			if (gridCustomENRTables.Row >= gridCustomENRTables.Rows.Fixed)
				gridItemDropDown = gridCustomENRTables.Rows[gridCustomENRTables.Row].UserData as WAM.Common.ComboBoxItem;

			return gridItemDropDown;
		}
		//</mam>

		//mam
		private void gridCustomENRTables_AfterResizeColumn(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			justResizedColumn = true;
			gridColWidth = gridCustomENRTables.Cols[1].Width;
		}
		//</mam>

		//mam
		private void gridCustomENRTables_AfterSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
		{
			gridSortCol = e.Col;
			gridSortDirection = (int)e.Order;
		}
		//</mam>

		//mam
		private void pictureBoxEdit_Click(object sender, System.EventArgs e)
		{	
			//RefreshData();

			//mam 07072011 - call SaveData instead of .Save() so we can show an error message if necessary
			//m_facility.Save();
			SaveData();

			HideGrid();
			ManageCustomENRForm.ShowForm(m_facility, null);

			// update facility with possible new ENR values
			if (m_facility.UsesCustomENRTable)
			{
				m_facility.LoadCustomENRValues(m_facility.CustomENRListID);
			}

			//MessageBox.Show(gridCustomENRTables.Rows.Count.ToString());

			// refresh the current view
			//mam 01222012 - added argument
			//RefreshData();
			RefreshData(false);
		}
		//</mam>

		//mam 01222012
		private void pictureBoxConstraints_Click(object sender, System.EventArgs e)
		{
			ConstraintViewer cv = new ConstraintViewer(m_facility.ID, m_facility.CurrentYear, m_facility.Name);
			cv.Show();		
		}

		//mam
		private void pictureBoxShowGrid_Click(object sender, System.EventArgs e)
		{
			ShowHideGrid();
		}

		private void FacilityControl_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void tabControl_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void tabPageMain_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void pictureBoxLogo_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}
		//</mam>

		//mam
		public void SaveOptions()
		{
			AppSettings.Settings.SetSetting(@"FacilityControl", "CustomENRSortCol", gridSortCol.ToString());
			AppSettings.Settings.SetSetting(@"FacilityControl", "CustomENRSortDir", gridSortDirection.ToString());
			AppSettings.Settings.SetSetting(@"FacilityControl", "CustomENRColWidth", gridCustomENRTables.Cols[1].Width.ToString());

			//mam 050806
			int valuationTabVisible = 0;
			//int costAllocTabVisible = 0;
			for (int i = 0; i < tabControl.TabPages.Count; i++)
			{
				if (tabControl.TabPages[i].Name.Equals(tabPageValuationHold.Name))
				{
					valuationTabVisible = 1;
				}
				//if (tabControl.TabPages[i].Name.Equals(tabPageCostAllocationHold.Name))
				//{
				//	costAllocTabVisible = 1;
				//}
			}
			AppSettings.Settings.SetSetting(@"FacilityControl", "ValuationTabVisible", valuationTabVisible.ToString());
			//AppSettings.Settings.SetSetting(@"FacilityControl", "CostAllocTabVisible", costAllocTabVisible.ToString());
			//
			
			AppSettings.Settings.Save();
		}
		//</mam>

		//mam
		private void GetOptions()
		{
			int sortCol = 0;
			int sortDir = 0;
			int colWidth = 0;

			//mam 050806
			int valuationTabVisible = 1;
			//int costAllocTabVisible = 1;
			//

			int sortDirAsc = (int)C1.Win.C1FlexGrid.SortFlags.Ascending;
			try
			{
				sortCol = Drive.Configuration.AppSettings.Settings.GetSettingInt("FacilityControl", "CustomENRSortCol", 1);
				sortDir = Drive.Configuration.AppSettings.Settings.GetSettingInt("FacilityControl", "CustomENRSortDir", sortDirAsc);
				colWidth = Drive.Configuration.AppSettings.Settings.GetSettingInt("FacilityControl", "CustomENRColWidth", 150);

				//mam 050806
				valuationTabVisible = Drive.Configuration.AppSettings.Settings.GetSettingInt("FacilityControl", "ValuationTabVisible", 1);
				//costAllocTabVisible = Drive.Configuration.AppSettings.Settings.GetSettingInt("FacilityControl", "CostAllocTabVisible", 1);
			}
			catch
			{
				sortCol = 1;
				sortDir = sortDirAsc;
				colWidth = 150;
			}
			
			if (sortCol != 1 && sortCol != 2)
				sortCol = 1;
			if (sortDir != sortDirAsc && sortDir != (int)C1.Win.C1FlexGrid.SortFlags.Descending)
				sortDir = sortDirAsc;

			//mam 050806
			//if (valuationTabVisible != 0 && valuationTabVisible != 1)
			//{
			//	costAllocTabVisible = 1;
			//}
			//

			if (WAM.Common.CommonTasks.IsNumericInteger(colWidth.ToString()))
			{
				if (colWidth < 0 || colWidth > 300)
				{
					colWidth = 150;
				}
			}
			else
			{
				colWidth = 150;
			}

			gridSortCol = sortCol;
			gridSortDirection = sortDir;
			gridColWidth = colWidth;


		}
		//</mam>

		//mam
		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)pictureBoxEdit.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxEdit.Image = b;

			b = (Bitmap)pictureBoxConstraints.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxConstraints.Image = b;

		}

		//mam 050806
		public void SetTabVisibility()
		{
			try
			{
				//note the currently selected tab
				tabPageSelectedName = tabControl.TabPages[tabControl.SelectedIndex].Name;

				//remove all tabs from the tab control
				tabControl.TabPages.Clear();

				//add tabs back to the tab control
				tabControl.TabPages.Add(tabPageMainHold);

				//show the Valuation tab, if necessary
				if (WAM.Common.Globals.ShowFacilityValuationTab)
				{
					tabControl.TabPages.Add(tabPageValuationHold);
				}
				treatmentProcessGrid1.ShowHideFundedColumn(WAM.Common.Globals.ShowFacilityValuationTab);

				//show the Cost Allocation tab, if necessary
				if (WAM.Common.Globals.ShowCostTab)
				{
					tabControl.TabPages.Add(tabPageCostAllocationHold);
				}

				tabControl.TabPages.Add(tabPagePhotoHold);
			
				//restore the tab selection
				for (int i = 0; i < tabControl.TabPages.Count; i++)
				{
					if (tabControl.TabPages[i].Name.Equals(tabPageSelectedName))
					{
						tabControl.SelectedIndex = i;
						break;
					}
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
			}
		}

		//mam 01222012
		private void textBoxFacilityCriticality_Leave(object sender, System.EventArgs e)
		{
			if (m_facility == null)
			{
				return;
			}

			//mam 03202012 - change max fac crit allowed from 1.00 to 100.00
			//if (textBoxFacilityCriticality.Value > 1.00M)
			//{
			//	textBoxFacilityCriticality.Value = 1.00M;
			//}
			if (textBoxFacilityCriticality.Value > 100.00M)
			{
				textBoxFacilityCriticality.Value = 100.00M;
			}

			//mam 03202012 - change min fac crit allowed from 0.1 to 0.01
			//if (textBoxFacilityCriticality.Value < 0.10M)
			//{
			//	textBoxFacilityCriticality.Value = 0.10M;
			//}
			if (textBoxFacilityCriticality.Value < 0.01M)
			{
				textBoxFacilityCriticality.Value = 0.01M;
			}

			m_facility.FacilityCriticality = textBoxFacilityCriticality.Value;

			SaveData();
		}

		//mam 01222012
		private void textBox_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)13)
			{
				e.Handled = true;
				this.ActiveControl = label3;
			}
		}

		#endregion /***** Methods *****/

		//mam 07072011 - for testing only
		private void button1_Click(object sender, System.EventArgs e)
		{
//			ConstraintViewer cv = new ConstraintViewer(m_facility.ID, m_facility.CurrentYear, m_facility.Name);
//			cv.Show();
//
//			return;
//
//			Facility.UpdateDisciplineCacheOverriddenYears(198, 1826, 2500);
//			return;
//
//			MajorComponent component = CacheManager.GetMajorComponent(105, 38305);
//			MessageBox.Show(component == null ? "component 1 is null" : "component 1 = " + component.Name);
//			return;
//
//			//C1.Win.C1FlexGrid.C1FlexGrid grid = new C1.Win.C1FlexGrid.C1FlexGrid();
//			//grid.Cols.Add();
//			////C1.Win.C1FlexGrid.Column column;
//			//grid.Cols[0].Name = "ErrorDescription";
//			//grid.Cols[0].Caption = "Error Description Test";
//
//			C1.Win.C1FlexGrid.C1FlexGrid grid = Common.CommonTasks.GetErrorGrid();
//			Common.CommonTasks.PopulateErrorGridRow(ref grid, "This is error 1");
//			Common.CommonTasks.PopulateErrorGridRow(ref grid, "This is error 2");
//			Common.CommonTasks.PopulateErrorGridRow(ref grid, "This is error 3");
//
//			ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(grid, "hello", "earthling");
//			errorDisplay.Show();

//			return;
//
//			TEMP tempForm = new TEMP();
//			tempForm.Show();
//
//			return;
//
//			Facility facility = CacheManager.GetFacility(105, 605);
//			MessageBox.Show(facility == null ? "facility is null" : "facility = " + facility.Name);
//
//			TreatmentProcess process = CacheManager.GetTreatmentProcess(105, 3717);
//			MessageBox.Show(process == null ? "process is null" : "process = " + process.Name);
//
//			MajorComponent component = CacheManager.GetMajorComponent(105, 38305);
//			MessageBox.Show(component == null ? "component 1 is null" : "component 1 = " + component.Name);
//
//			component = CacheManager.GetMajorComponent(105, 38306);
//			MessageBox.Show(component == null ? "component 2 is null" : "component 2 = " + component.Name);
//
//			Discipline discipline = CacheManager.GetDiscipline(105, 34610, DisciplineType.Mechanical);
//			MessageBox.Show(discipline == null ? "discipline mech is null" : "discipline mech = " + discipline.Name);
//
//			discipline = CacheManager.GetDiscipline(105, 32020, DisciplineType.Structural);
//			MessageBox.Show(discipline == null ? "discipline struct is null" : "discipline struct = " + discipline.Name);
//
//			discipline = CacheManager.GetDiscipline(105, 29735, DisciplineType.Land);
//			MessageBox.Show(discipline == null ? "discipline land is null" : "discipline land = " + discipline.Name);
//
//			discipline = CacheManager.GetDiscipline(105, 97, DisciplineType.Pipes);
//			MessageBox.Show(discipline == null ? "discipline pipes is null" : "discipline pipes = " + discipline.Name);
//
//			discipline = CacheManager.GetDiscipline(105, 105, DisciplineType.Nodes);
//			MessageBox.Show(discipline == null ? "discipline nodes is null" : "discipline nodes = " + discipline.Name);
		}
	}
}