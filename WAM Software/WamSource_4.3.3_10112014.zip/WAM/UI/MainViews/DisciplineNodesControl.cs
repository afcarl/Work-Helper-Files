using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Data;

namespace WAM.UI.MainViews
{
	/// <summary>
	/// Summary description for DisciplineNodesControl.
	/// </summary>
	public class DisciplineNodesControl : System.Windows.Forms.UserControl
	{
		private DisciplineNode m_discipline = null;
		private Drive.Windows.Forms.DataChangeMonitor
							m_dataMonitor = null;
		private bool		m_suppressUpdate = false;

		//mam
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		//</mam>

		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPageComponentInfo;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBoxOriginalUL;
		private System.Windows.Forms.TextBox textBoxRepairCostCurVal;
		private System.Windows.Forms.TextBox textBoxOrgCostCurVal;
		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxDisciplineName;
		private System.Windows.Forms.TextBox textBoxRemainingUL;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBoxEvaluatedRemainingUL;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBoxAssessedBy;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxInstallYear;
		private C1.Win.C1Input.C1DateEdit dateInspect;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.TextBox textBoxBookValue;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox textBoxAnnualDepreciation;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox textBoxEvaluatedValue;
		private System.Windows.Forms.TextBox textBoxCumulativeDepreciation;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox textBoxCurrentENR;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.TextBox textBoxLOS;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBoxAverageCondition;
		private System.Windows.Forms.TextBox textBoxAverageCriticality;
		private System.Windows.Forms.TextBox textBoxAverageVulnerability;
		private System.Windows.Forms.TextBox textBoxTotalAnnualMaintenanceCost;
		private System.Windows.Forms.TextBox textBoxTotalSalvageValue;
		private System.Windows.Forms.TextBox textBoxTotalReplacementValue;
		private System.Windows.Forms.TextBox textBoxTotalAcquisitionCost;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox textBoxAverageRisk;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.Label labelComments;
		private WAM.UI.Grids.NodeAppurtenanceGrid nodeAppurtenanceGrid;
		private System.Windows.Forms.Button buttonAddNode;
		private System.Windows.Forms.Button buttonDeleteNode;
		private System.Windows.Forms.Button buttonEditNode;
		private System.Windows.Forms.Button buttonDeleteNode2;
		private System.Windows.Forms.Button buttonEditNode2;
		private System.Windows.Forms.Button buttonAddNode2;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.TextBox textBoxEconomicUL;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.TextBox textBoxTotalRehabCost;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox textBoxTotalAcquisitionCostEscalated;
		private System.Windows.Forms.TextBox textBoxReplacementValueYear;
		private System.Windows.Forms.Label label32;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DisciplineNodesControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//mam
			SetEquationControls();
			//</mam>
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxDisciplineName = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.textBoxReplacementValueYear = new System.Windows.Forms.TextBox();
			this.label32 = new System.Windows.Forms.Label();
			this.textBoxTotalAcquisitionCostEscalated = new System.Windows.Forms.TextBox();
			this.textBoxTotalRehabCost = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.textBoxEconomicUL = new System.Windows.Forms.TextBox();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.labelComments = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.textBoxInstallYear = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxEvaluatedRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxOriginalUL = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.textBoxRepairCostCurVal = new System.Windows.Forms.TextBox();
			this.textBoxOrgCostCurVal = new System.Windows.Forms.TextBox();
			this.textBoxAssessedBy = new System.Windows.Forms.TextBox();
			this.textBoxBookValue = new System.Windows.Forms.TextBox();
			this.dateInspect = new C1.Win.C1Input.C1DateEdit();
			this.label11 = new System.Windows.Forms.Label();
			this.textBoxAnnualDepreciation = new System.Windows.Forms.TextBox();
			this.textBoxEvaluatedValue = new System.Windows.Forms.TextBox();
			this.textBoxCumulativeDepreciation = new System.Windows.Forms.TextBox();
			this.label24 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.textBoxLOS = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.textBoxAverageCondition = new System.Windows.Forms.TextBox();
			this.textBoxAverageCriticality = new System.Windows.Forms.TextBox();
			this.textBoxAverageVulnerability = new System.Windows.Forms.TextBox();
			this.textBoxTotalAnnualMaintenanceCost = new System.Windows.Forms.TextBox();
			this.textBoxTotalSalvageValue = new System.Windows.Forms.TextBox();
			this.textBoxTotalReplacementValue = new System.Windows.Forms.TextBox();
			this.textBoxTotalAcquisitionCost = new System.Windows.Forms.TextBox();
			this.textBoxAverageRisk = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.tabPageComponentInfo = new System.Windows.Forms.TabPage();
			this.buttonAddNode = new System.Windows.Forms.Button();
			this.nodeAppurtenanceGrid = new WAM.UI.Grids.NodeAppurtenanceGrid();
			this.buttonDeleteNode = new System.Windows.Forms.Button();
			this.buttonEditNode = new System.Windows.Forms.Button();
			this.label26 = new System.Windows.Forms.Label();
			this.textBoxCurrentENR = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.buttonDeleteNode2 = new System.Windows.Forms.Button();
			this.buttonEditNode2 = new System.Windows.Forms.Button();
			this.buttonAddNode2 = new System.Windows.Forms.Button();
			this.labelLocked = new System.Windows.Forms.Label();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.label23 = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).BeginInit();
			this.tabPageComponentInfo.SuspendLayout();
			this.panelLocked.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 6;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.TabStop = false;
			this.textBoxProcessName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 4;
			this.label3.Text = "Component / Subbasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.ReadOnly = true;
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 5;
			this.textBoxComponentName.TabStop = false;
			this.textBoxComponentName.Text = "";
			// 
			// textBoxDisciplineName
			// 
			this.textBoxDisciplineName.Location = new System.Drawing.Point(216, 88);
			this.textBoxDisciplineName.Name = "textBoxDisciplineName";
			this.textBoxDisciplineName.ReadOnly = true;
			this.textBoxDisciplineName.Size = new System.Drawing.Size(228, 20);
			this.textBoxDisciplineName.TabIndex = 7;
			this.textBoxDisciplineName.TabStop = false;
			this.textBoxDisciplineName.Text = "Nodes / Appurtenances";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(84, 90);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Discipline:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageComponentInfo);
			this.helpProvider1.SetHelpKeyword(this.tabControl, "DisciplineTabMainPipes.htm");
			this.helpProvider1.SetHelpNavigator(this.tabControl, System.Windows.Forms.HelpNavigator.Topic);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.helpProvider1.SetShowHelp(this.tabControl, true);
			this.tabControl.Size = new System.Drawing.Size(592, 400);
			this.tabControl.TabIndex = 12;
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.textBoxReplacementValueYear);
			this.tabPageMain.Controls.Add(this.label32);
			this.tabPageMain.Controls.Add(this.textBoxTotalAcquisitionCostEscalated);
			this.tabPageMain.Controls.Add(this.textBoxTotalRehabCost);
			this.tabPageMain.Controls.Add(this.label31);
			this.tabPageMain.Controls.Add(this.label30);
			this.tabPageMain.Controls.Add(this.textBoxEconomicUL);
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.labelComments);
			this.tabPageMain.Controls.Add(this.label28);
			this.tabPageMain.Controls.Add(this.label17);
			this.tabPageMain.Controls.Add(this.label5);
			this.tabPageMain.Controls.Add(this.label18);
			this.tabPageMain.Controls.Add(this.textBoxInstallYear);
			this.tabPageMain.Controls.Add(this.label16);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxOriginalUL);
			this.tabPageMain.Controls.Add(this.label8);
			this.tabPageMain.Controls.Add(this.textBoxRepairCostCurVal);
			this.tabPageMain.Controls.Add(this.textBoxOrgCostCurVal);
			this.tabPageMain.Controls.Add(this.textBoxAssessedBy);
			this.tabPageMain.Controls.Add(this.textBoxBookValue);
			this.tabPageMain.Controls.Add(this.dateInspect);
			this.tabPageMain.Controls.Add(this.label11);
			this.tabPageMain.Controls.Add(this.textBoxAnnualDepreciation);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedValue);
			this.tabPageMain.Controls.Add(this.textBoxCumulativeDepreciation);
			this.tabPageMain.Controls.Add(this.label24);
			this.tabPageMain.Controls.Add(this.label25);
			this.tabPageMain.Controls.Add(this.textBoxLOS);
			this.tabPageMain.Controls.Add(this.label13);
			this.tabPageMain.Controls.Add(this.label14);
			this.tabPageMain.Controls.Add(this.textBoxAverageCondition);
			this.tabPageMain.Controls.Add(this.textBoxAverageCriticality);
			this.tabPageMain.Controls.Add(this.textBoxAverageVulnerability);
			this.tabPageMain.Controls.Add(this.textBoxTotalAnnualMaintenanceCost);
			this.tabPageMain.Controls.Add(this.textBoxTotalSalvageValue);
			this.tabPageMain.Controls.Add(this.textBoxTotalReplacementValue);
			this.tabPageMain.Controls.Add(this.textBoxTotalAcquisitionCost);
			this.tabPageMain.Controls.Add(this.textBoxAverageRisk);
			this.tabPageMain.Controls.Add(this.label9);
			this.tabPageMain.Controls.Add(this.label7);
			this.tabPageMain.Controls.Add(this.label6);
			this.tabPageMain.Controls.Add(this.label12);
			this.tabPageMain.Controls.Add(this.label19);
			this.tabPageMain.Controls.Add(this.label20);
			this.tabPageMain.Controls.Add(this.label21);
			this.tabPageMain.Controls.Add(this.label22);
			this.tabPageMain.Controls.Add(this.label15);
			this.tabPageMain.Controls.Add(this.label29);
			this.tabPageMain.Controls.Add(this.label10);
			this.helpProvider1.SetHelpKeyword(this.tabPageMain, "DisciplineTabMainPipes.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageMain, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.helpProvider1.SetShowHelp(this.tabPageMain, true);
			this.tabPageMain.Size = new System.Drawing.Size(584, 374);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// textBoxReplacementValueYear
			// 
			this.textBoxReplacementValueYear.Location = new System.Drawing.Point(176, 128);
			this.textBoxReplacementValueYear.MaxLength = 4;
			this.textBoxReplacementValueYear.Name = "textBoxReplacementValueYear";
			this.textBoxReplacementValueYear.ReadOnly = true;
			this.textBoxReplacementValueYear.Size = new System.Drawing.Size(72, 20);
			this.textBoxReplacementValueYear.TabIndex = 11;
			this.textBoxReplacementValueYear.TabStop = false;
			this.textBoxReplacementValueYear.Tag = "ARVY";
			this.textBoxReplacementValueYear.Text = "";
			this.textBoxReplacementValueYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label32
			// 
			this.label32.Location = new System.Drawing.Point(-8, 130);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(184, 16);
			this.label32.TabIndex = 10;
			this.label32.Text = "Average Replacement Value Year:";
			this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxTotalAcquisitionCostEscalated
			// 
			this.textBoxTotalAcquisitionCostEscalated.Location = new System.Drawing.Point(176, 32);
			this.textBoxTotalAcquisitionCostEscalated.MaxLength = 4;
			this.textBoxTotalAcquisitionCostEscalated.Name = "textBoxTotalAcquisitionCostEscalated";
			this.textBoxTotalAcquisitionCostEscalated.ReadOnly = true;
			this.textBoxTotalAcquisitionCostEscalated.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalAcquisitionCostEscalated.TabIndex = 3;
			this.textBoxTotalAcquisitionCostEscalated.TabStop = false;
			this.textBoxTotalAcquisitionCostEscalated.Tag = "TEAC";
			this.textBoxTotalAcquisitionCostEscalated.Text = "";
			this.textBoxTotalAcquisitionCostEscalated.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxTotalRehabCost
			// 
			this.textBoxTotalRehabCost.Location = new System.Drawing.Point(476, 32);
			this.textBoxTotalRehabCost.Name = "textBoxTotalRehabCost";
			this.textBoxTotalRehabCost.ReadOnly = true;
			this.textBoxTotalRehabCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalRehabCost.TabIndex = 29;
			this.textBoxTotalRehabCost.TabStop = false;
			this.textBoxTotalRehabCost.Tag = "TREHAB";
			this.textBoxTotalRehabCost.Text = "";
			this.textBoxTotalRehabCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label31
			// 
			this.label31.Location = new System.Drawing.Point(332, 34);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(144, 16);
			this.label31.TabIndex = 28;
			this.label31.Text = "Total Rehabilitation Cost:";
			this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label30
			// 
			this.label30.Location = new System.Drawing.Point(4, 34);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(172, 16);
			this.label30.TabIndex = 2;
			this.label30.Text = "Total Escalated Acquisition Cost:";
			this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEconomicUL
			// 
			this.textBoxEconomicUL.Location = new System.Drawing.Point(476, 224);
			this.textBoxEconomicUL.Name = "textBoxEconomicUL";
			this.textBoxEconomicUL.ReadOnly = true;
			this.textBoxEconomicUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxEconomicUL.TabIndex = 45;
			this.textBoxEconomicUL.TabStop = false;
			this.textBoxEconomicUL.Tag = "AECUL";
			this.textBoxEconomicUL.Text = "";
			this.textBoxEconomicUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxComments
			// 
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 344);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(576, 28);
			this.textBoxComments.TabIndex = 51;
			this.textBoxComments.Text = "";
			// 
			// labelComments
			// 
			this.labelComments.Location = new System.Drawing.Point(4, 328);
			this.labelComments.Name = "labelComments";
			this.labelComments.Size = new System.Drawing.Size(100, 16);
			this.labelComments.TabIndex = 50;
			this.labelComments.Text = "&Comments:";
			// 
			// label28
			// 
			this.label28.Location = new System.Drawing.Point(36, 202);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(140, 16);
			this.label28.TabIndex = 16;
			this.label28.Text = "Average Level of Service:";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(24, 58);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(152, 16);
			this.label17.TabIndex = 4;
			this.label17.Text = "Total Replacement Value:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(72, 226);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 18;
			this.label5.Text = "Average Condition:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(24, 10);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(152, 16);
			this.label18.TabIndex = 0;
			this.label18.Text = "Total Acquisition Cost:";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInstallYear
			// 
			this.textBoxInstallYear.Location = new System.Drawing.Point(176, 152);
			this.textBoxInstallYear.MaxLength = 4;
			this.textBoxInstallYear.Name = "textBoxInstallYear";
			this.textBoxInstallYear.ReadOnly = true;
			this.textBoxInstallYear.Size = new System.Drawing.Size(72, 20);
			this.textBoxInstallYear.TabIndex = 13;
			this.textBoxInstallYear.TabStop = false;
			this.textBoxInstallYear.Tag = "AIY";
			this.textBoxInstallYear.Text = "";
			this.textBoxInstallYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(28, 154);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(148, 16);
			this.label16.TabIndex = 12;
			this.label16.Text = "Average Installation Year:";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEvaluatedRemainingUL
			// 
			this.textBoxEvaluatedRemainingUL.Location = new System.Drawing.Point(476, 200);
			this.textBoxEvaluatedRemainingUL.Name = "textBoxEvaluatedRemainingUL";
			this.textBoxEvaluatedRemainingUL.ReadOnly = true;
			this.textBoxEvaluatedRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedRemainingUL.TabIndex = 43;
			this.textBoxEvaluatedRemainingUL.TabStop = false;
			this.textBoxEvaluatedRemainingUL.Tag = "AERUL";
			this.textBoxEvaluatedRemainingUL.Text = "";
			this.textBoxEvaluatedRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxRemainingUL
			// 
			this.textBoxRemainingUL.Location = new System.Drawing.Point(476, 176);
			this.textBoxRemainingUL.Name = "textBoxRemainingUL";
			this.textBoxRemainingUL.ReadOnly = true;
			this.textBoxRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxRemainingUL.TabIndex = 41;
			this.textBoxRemainingUL.TabStop = false;
			this.textBoxRemainingUL.Tag = "ARUL";
			this.textBoxRemainingUL.Text = "";
			this.textBoxRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOriginalUL
			// 
			this.textBoxOriginalUL.Location = new System.Drawing.Point(176, 176);
			this.textBoxOriginalUL.MaxLength = 4;
			this.textBoxOriginalUL.Name = "textBoxOriginalUL";
			this.textBoxOriginalUL.ReadOnly = true;
			this.textBoxOriginalUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxOriginalUL.TabIndex = 15;
			this.textBoxOriginalUL.TabStop = false;
			this.textBoxOriginalUL.Tag = "AOUL";
			this.textBoxOriginalUL.Text = "";
			this.textBoxOriginalUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(16, 178);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(160, 16);
			this.label8.TabIndex = 14;
			this.label8.Text = "Average Original Useful Life:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRepairCostCurVal
			// 
			this.textBoxRepairCostCurVal.Location = new System.Drawing.Point(476, 152);
			this.textBoxRepairCostCurVal.Name = "textBoxRepairCostCurVal";
			this.textBoxRepairCostCurVal.ReadOnly = true;
			this.textBoxRepairCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxRepairCostCurVal.TabIndex = 39;
			this.textBoxRepairCostCurVal.TabStop = false;
			this.textBoxRepairCostCurVal.Tag = "TRC";
			this.textBoxRepairCostCurVal.Text = "";
			this.textBoxRepairCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOrgCostCurVal
			// 
			this.textBoxOrgCostCurVal.Location = new System.Drawing.Point(476, 8);
			this.textBoxOrgCostCurVal.Name = "textBoxOrgCostCurVal";
			this.textBoxOrgCostCurVal.ReadOnly = true;
			this.textBoxOrgCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxOrgCostCurVal.TabIndex = 27;
			this.textBoxOrgCostCurVal.TabStop = false;
			this.textBoxOrgCostCurVal.Tag = "TCV";
			this.textBoxOrgCostCurVal.Text = "";
			this.textBoxOrgCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxAssessedBy
			// 
			this.textBoxAssessedBy.Location = new System.Drawing.Point(476, 272);
			this.textBoxAssessedBy.Name = "textBoxAssessedBy";
			this.textBoxAssessedBy.Size = new System.Drawing.Size(104, 20);
			this.textBoxAssessedBy.TabIndex = 49;
			this.textBoxAssessedBy.Text = "";
			// 
			// textBoxBookValue
			// 
			this.textBoxBookValue.Location = new System.Drawing.Point(476, 56);
			this.textBoxBookValue.Name = "textBoxBookValue";
			this.textBoxBookValue.ReadOnly = true;
			this.textBoxBookValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxBookValue.TabIndex = 31;
			this.textBoxBookValue.TabStop = false;
			this.textBoxBookValue.Tag = "TBV";
			this.textBoxBookValue.Text = "";
			this.textBoxBookValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// dateInspect
			// 
			this.dateInspect.AllowDbNull = false;
			this.dateInspect.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate;
			this.dateInspect.Location = new System.Drawing.Point(176, 296);
			this.dateInspect.Name = "dateInspect";
			this.dateInspect.Size = new System.Drawing.Size(104, 20);
			this.dateInspect.TabIndex = 25;
			this.dateInspect.Tag = null;
			this.dateInspect.Value = new System.DateTime(2003, 7, 31, 0, 0, 0, 0);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(76, 300);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(100, 16);
			this.label11.TabIndex = 24;
			this.label11.Text = "&Date of Inspection:";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAnnualDepreciation
			// 
			this.textBoxAnnualDepreciation.Location = new System.Drawing.Point(476, 80);
			this.textBoxAnnualDepreciation.Name = "textBoxAnnualDepreciation";
			this.textBoxAnnualDepreciation.ReadOnly = true;
			this.textBoxAnnualDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxAnnualDepreciation.TabIndex = 33;
			this.textBoxAnnualDepreciation.TabStop = false;
			this.textBoxAnnualDepreciation.Tag = "TAD";
			this.textBoxAnnualDepreciation.Text = "";
			this.textBoxAnnualDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxEvaluatedValue
			// 
			this.textBoxEvaluatedValue.Location = new System.Drawing.Point(476, 128);
			this.textBoxEvaluatedValue.Name = "textBoxEvaluatedValue";
			this.textBoxEvaluatedValue.ReadOnly = true;
			this.textBoxEvaluatedValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedValue.TabIndex = 37;
			this.textBoxEvaluatedValue.TabStop = false;
			this.textBoxEvaluatedValue.Tag = "TEV";
			this.textBoxEvaluatedValue.Text = "";
			this.textBoxEvaluatedValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxCumulativeDepreciation
			// 
			this.textBoxCumulativeDepreciation.Location = new System.Drawing.Point(476, 104);
			this.textBoxCumulativeDepreciation.Name = "textBoxCumulativeDepreciation";
			this.textBoxCumulativeDepreciation.ReadOnly = true;
			this.textBoxCumulativeDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxCumulativeDepreciation.TabIndex = 35;
			this.textBoxCumulativeDepreciation.TabStop = false;
			this.textBoxCumulativeDepreciation.Tag = "TCD";
			this.textBoxCumulativeDepreciation.Text = "";
			this.textBoxCumulativeDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(32, 82);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(144, 16);
			this.label24.TabIndex = 6;
			this.label24.Text = "Total Salvage Value:";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(4, 106);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(172, 16);
			this.label25.TabIndex = 8;
			this.label25.Text = "Total Annual Maintenance Cost:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxLOS
			// 
			this.textBoxLOS.Location = new System.Drawing.Point(176, 200);
			this.textBoxLOS.MaxLength = 4;
			this.textBoxLOS.Name = "textBoxLOS";
			this.textBoxLOS.ReadOnly = true;
			this.textBoxLOS.Size = new System.Drawing.Size(72, 20);
			this.textBoxLOS.TabIndex = 17;
			this.textBoxLOS.TabStop = false;
			this.textBoxLOS.Tag = "ALOS";
			this.textBoxLOS.Text = "";
			this.textBoxLOS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(72, 250);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(104, 16);
			this.label13.TabIndex = 20;
			this.label13.Text = "Average Criticality:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(52, 274);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(124, 16);
			this.label14.TabIndex = 22;
			this.label14.Text = "Average Vulnerability:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAverageCondition
			// 
			this.textBoxAverageCondition.Location = new System.Drawing.Point(176, 224);
			this.textBoxAverageCondition.MaxLength = 4;
			this.textBoxAverageCondition.Name = "textBoxAverageCondition";
			this.textBoxAverageCondition.ReadOnly = true;
			this.textBoxAverageCondition.Size = new System.Drawing.Size(72, 20);
			this.textBoxAverageCondition.TabIndex = 19;
			this.textBoxAverageCondition.TabStop = false;
			this.textBoxAverageCondition.Tag = "ACOND";
			this.textBoxAverageCondition.Text = "";
			this.textBoxAverageCondition.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxAverageCriticality
			// 
			this.textBoxAverageCriticality.Location = new System.Drawing.Point(176, 248);
			this.textBoxAverageCriticality.MaxLength = 4;
			this.textBoxAverageCriticality.Name = "textBoxAverageCriticality";
			this.textBoxAverageCriticality.ReadOnly = true;
			this.textBoxAverageCriticality.Size = new System.Drawing.Size(72, 20);
			this.textBoxAverageCriticality.TabIndex = 21;
			this.textBoxAverageCriticality.TabStop = false;
			this.textBoxAverageCriticality.Tag = "ACRIT";
			this.textBoxAverageCriticality.Text = "";
			this.textBoxAverageCriticality.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxAverageVulnerability
			// 
			this.textBoxAverageVulnerability.Location = new System.Drawing.Point(176, 272);
			this.textBoxAverageVulnerability.MaxLength = 4;
			this.textBoxAverageVulnerability.Name = "textBoxAverageVulnerability";
			this.textBoxAverageVulnerability.ReadOnly = true;
			this.textBoxAverageVulnerability.Size = new System.Drawing.Size(72, 20);
			this.textBoxAverageVulnerability.TabIndex = 23;
			this.textBoxAverageVulnerability.TabStop = false;
			this.textBoxAverageVulnerability.Tag = "AVULN";
			this.textBoxAverageVulnerability.Text = "";
			this.textBoxAverageVulnerability.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxTotalAnnualMaintenanceCost
			// 
			this.textBoxTotalAnnualMaintenanceCost.Location = new System.Drawing.Point(176, 104);
			this.textBoxTotalAnnualMaintenanceCost.MaxLength = 4;
			this.textBoxTotalAnnualMaintenanceCost.Name = "textBoxTotalAnnualMaintenanceCost";
			this.textBoxTotalAnnualMaintenanceCost.ReadOnly = true;
			this.textBoxTotalAnnualMaintenanceCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalAnnualMaintenanceCost.TabIndex = 9;
			this.textBoxTotalAnnualMaintenanceCost.TabStop = false;
			this.textBoxTotalAnnualMaintenanceCost.Tag = "TAM";
			this.textBoxTotalAnnualMaintenanceCost.Text = "";
			this.textBoxTotalAnnualMaintenanceCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxTotalSalvageValue
			// 
			this.textBoxTotalSalvageValue.Location = new System.Drawing.Point(176, 80);
			this.textBoxTotalSalvageValue.MaxLength = 4;
			this.textBoxTotalSalvageValue.Name = "textBoxTotalSalvageValue";
			this.textBoxTotalSalvageValue.ReadOnly = true;
			this.textBoxTotalSalvageValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalSalvageValue.TabIndex = 7;
			this.textBoxTotalSalvageValue.TabStop = false;
			this.textBoxTotalSalvageValue.Tag = "TSV";
			this.textBoxTotalSalvageValue.Text = "";
			this.textBoxTotalSalvageValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxTotalReplacementValue
			// 
			this.textBoxTotalReplacementValue.Location = new System.Drawing.Point(176, 56);
			this.textBoxTotalReplacementValue.MaxLength = 4;
			this.textBoxTotalReplacementValue.Name = "textBoxTotalReplacementValue";
			this.textBoxTotalReplacementValue.ReadOnly = true;
			this.textBoxTotalReplacementValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalReplacementValue.TabIndex = 5;
			this.textBoxTotalReplacementValue.TabStop = false;
			this.textBoxTotalReplacementValue.Tag = "TRV";
			this.textBoxTotalReplacementValue.Text = "";
			this.textBoxTotalReplacementValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxTotalAcquisitionCost
			// 
			this.textBoxTotalAcquisitionCost.Location = new System.Drawing.Point(176, 8);
			this.textBoxTotalAcquisitionCost.MaxLength = 4;
			this.textBoxTotalAcquisitionCost.Name = "textBoxTotalAcquisitionCost";
			this.textBoxTotalAcquisitionCost.ReadOnly = true;
			this.textBoxTotalAcquisitionCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxTotalAcquisitionCost.TabIndex = 1;
			this.textBoxTotalAcquisitionCost.TabStop = false;
			this.textBoxTotalAcquisitionCost.Tag = "TAC";
			this.textBoxTotalAcquisitionCost.Text = "";
			this.textBoxTotalAcquisitionCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxAverageRisk
			// 
			this.textBoxAverageRisk.Location = new System.Drawing.Point(476, 248);
			this.textBoxAverageRisk.MaxLength = 4;
			this.textBoxAverageRisk.Name = "textBoxAverageRisk";
			this.textBoxAverageRisk.ReadOnly = true;
			this.textBoxAverageRisk.Size = new System.Drawing.Size(72, 20);
			this.textBoxAverageRisk.TabIndex = 47;
			this.textBoxAverageRisk.TabStop = false;
			this.textBoxAverageRisk.Tag = "ARISK";
			this.textBoxAverageRisk.Text = "";
			this.textBoxAverageRisk.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(306, 178);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(168, 16);
			this.label9.TabIndex = 40;
			this.label9.Text = "Average Remaining Useful Life:";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(356, 154);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(120, 16);
			this.label7.TabIndex = 38;
			this.label7.Text = "Total Repair Cost:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(348, 10);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(128, 16);
			this.label6.TabIndex = 26;
			this.label6.Text = "Total Current Value:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(379, 274);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(96, 16);
			this.label12.TabIndex = 48;
			this.label12.Text = "Assessed &By:";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(348, 58);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(128, 16);
			this.label19.TabIndex = 30;
			this.label19.Text = "Total Book Value:";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(315, 82);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(160, 16);
			this.label20.TabIndex = 32;
			this.label20.Text = "Total Annual Depreciation:";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(324, 130);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(152, 16);
			this.label21.TabIndex = 36;
			this.label21.Text = "Total Evaluated Value:";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(290, 106);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(184, 16);
			this.label22.TabIndex = 34;
			this.label22.Text = "Total Cumulative Depreciation:";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(350, 250);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(124, 16);
			this.label15.TabIndex = 46;
			this.label15.Text = "Average Risk:";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label29
			// 
			this.label29.Location = new System.Drawing.Point(250, 228);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(224, 16);
			this.label29.TabIndex = 44;
			this.label29.Text = "Average Economic Remaining Useful Life:";
			this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(254, 202);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(220, 16);
			this.label10.TabIndex = 42;
			this.label10.Text = "Average Evaluated Remaining Useful Life:";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabPageComponentInfo
			// 
			this.tabPageComponentInfo.Controls.Add(this.buttonAddNode);
			this.tabPageComponentInfo.Controls.Add(this.nodeAppurtenanceGrid);
			this.tabPageComponentInfo.Controls.Add(this.buttonDeleteNode);
			this.tabPageComponentInfo.Controls.Add(this.buttonEditNode);
			this.helpProvider1.SetHelpKeyword(this.tabPageComponentInfo, "DisciplineTabComponentInfoPipes.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageComponentInfo, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageComponentInfo.Location = new System.Drawing.Point(4, 22);
			this.tabPageComponentInfo.Name = "tabPageComponentInfo";
			this.helpProvider1.SetShowHelp(this.tabPageComponentInfo, true);
			this.tabPageComponentInfo.Size = new System.Drawing.Size(584, 374);
			this.tabPageComponentInfo.TabIndex = 1;
			this.tabPageComponentInfo.Text = "Component Information";
			// 
			// buttonAddNode
			// 
			this.buttonAddNode.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonAddNode.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddNode.Location = new System.Drawing.Point(98, 344);
			this.buttonAddNode.Name = "buttonAddNode";
			this.buttonAddNode.Size = new System.Drawing.Size(100, 23);
			this.buttonAddNode.TabIndex = 1;
			this.buttonAddNode.TabStop = false;
			this.buttonAddNode.Text = "Add Node";
			this.buttonAddNode.Visible = false;
			this.buttonAddNode.Click += new System.EventHandler(this.buttonAddNode_Click);
			// 
			// nodeAppurtenanceGrid
			// 
			this.nodeAppurtenanceGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.helpProvider1.SetHelpKeyword(this.nodeAppurtenanceGrid, "DisciplineTabComponentInfoPipes.htm");
			this.helpProvider1.SetHelpNavigator(this.nodeAppurtenanceGrid, System.Windows.Forms.HelpNavigator.Topic);
			this.nodeAppurtenanceGrid.Location = new System.Drawing.Point(4, 4);
			this.nodeAppurtenanceGrid.Name = "nodeAppurtenanceGrid";
			this.helpProvider1.SetShowHelp(this.nodeAppurtenanceGrid, true);
			this.nodeAppurtenanceGrid.Size = new System.Drawing.Size(576, 332);
			this.nodeAppurtenanceGrid.TabIndex = 0;
			// 
			// buttonDeleteNode
			// 
			this.buttonDeleteNode.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonDeleteNode.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonDeleteNode.Location = new System.Drawing.Point(386, 344);
			this.buttonDeleteNode.Name = "buttonDeleteNode";
			this.buttonDeleteNode.Size = new System.Drawing.Size(100, 23);
			this.buttonDeleteNode.TabIndex = 3;
			this.buttonDeleteNode.TabStop = false;
			this.buttonDeleteNode.Text = "Remove Node";
			this.buttonDeleteNode.Visible = false;
			this.buttonDeleteNode.Click += new System.EventHandler(this.buttonDeleteNode_Click);
			// 
			// buttonEditNode
			// 
			this.buttonEditNode.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonEditNode.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditNode.Location = new System.Drawing.Point(242, 344);
			this.buttonEditNode.Name = "buttonEditNode";
			this.buttonEditNode.Size = new System.Drawing.Size(100, 23);
			this.buttonEditNode.TabIndex = 2;
			this.buttonEditNode.TabStop = false;
			this.buttonEditNode.Text = "Edit Node";
			this.buttonEditNode.Visible = false;
			this.buttonEditNode.Click += new System.EventHandler(this.buttonEditNode_Click);
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(460, 34);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(72, 16);
			this.label26.TabIndex = 10;
			this.label26.Text = "Current ENR:";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentENR
			// 
			this.textBoxCurrentENR.Location = new System.Drawing.Point(532, 32);
			this.textBoxCurrentENR.Name = "textBoxCurrentENR";
			this.textBoxCurrentENR.ReadOnly = true;
			this.textBoxCurrentENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentENR.TabIndex = 11;
			this.textBoxCurrentENR.TabStop = false;
			this.textBoxCurrentENR.Text = "";
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(460, 6);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(72, 16);
			this.label27.TabIndex = 8;
			this.label27.Text = "Current Year:";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 9;
			this.textBoxCurrentYear.TabStop = false;
			this.textBoxCurrentYear.Text = "";
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.TabStop = false;
			this.textBoxFacilityName.Text = "";
			// 
			// buttonDeleteNode2
			// 
			this.buttonDeleteNode2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonDeleteNode2.Location = new System.Drawing.Point(459, 105);
			this.buttonDeleteNode2.Name = "buttonDeleteNode2";
			this.buttonDeleteNode2.Size = new System.Drawing.Size(80, 20);
			this.buttonDeleteNode2.TabIndex = 3;
			this.buttonDeleteNode2.Text = "Delete Node";
			// 
			// buttonEditNode2
			// 
			this.buttonEditNode2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditNode2.Location = new System.Drawing.Point(459, 82);
			this.buttonEditNode2.Name = "buttonEditNode2";
			this.buttonEditNode2.Size = new System.Drawing.Size(80, 20);
			this.buttonEditNode2.TabIndex = 2;
			this.buttonEditNode2.Text = "Edit Node";
			// 
			// buttonAddNode2
			// 
			this.buttonAddNode2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddNode2.Location = new System.Drawing.Point(459, 59);
			this.buttonAddNode2.Name = "buttonAddNode2";
			this.buttonAddNode2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonAddNode2.Size = new System.Drawing.Size(80, 20);
			this.buttonAddNode2.TabIndex = 1;
			this.buttonAddNode2.Text = "Add Node";
			this.buttonAddNode2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// labelLocked
			// 
			this.labelLocked.Location = new System.Drawing.Point(0, 0);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.TabIndex = 0;
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.label23);
			this.panelLocked.Location = new System.Drawing.Point(223, 115);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 19;
			// 
			// label23
			// 
			this.label23.BackColor = System.Drawing.Color.White;
			this.label23.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label23.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.label23.Location = new System.Drawing.Point(1, 1);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(213, 18);
			this.label23.TabIndex = 16;
			this.label23.Text = "All Data is Locked";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// DisciplineNodesControl
			// 
			this.AutoScroll = true;
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.buttonDeleteNode2);
			this.Controls.Add(this.buttonEditNode2);
			this.Controls.Add(this.buttonAddNode2);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.label27);
			this.Controls.Add(this.textBoxCurrentENR);
			this.Controls.Add(this.label26);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBoxDisciplineName);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.textBoxFacilityName);
			this.helpProvider1.SetHelpKeyword(this, "DisciplineScreenPipes.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Name = "DisciplineNodesControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(600, 520);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).EndInit();
			this.tabPageComponentInfo.ResumeLayout(false);
			this.panelLocked.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			this.nodeAppurtenanceGrid.AddGridDoubleClick(new System.EventHandler(this.buttonEditNode_Click));

			m_dataMonitor = new Drive.Windows.Forms.DataChangeMonitor(this.Controls);

			//mam
			this.buttonAddNode2.Click += new System.EventHandler(this.buttonAddNode_Click);
			this.buttonEditNode2.Click += new System.EventHandler(this.buttonEditNode_Click);
			this.buttonDeleteNode2.Click += new System.EventHandler(this.buttonDeleteNode_Click);
			//</mam>

			// These are all handled immediately
			m_dataMonitor.RemoveHandlerForControl(buttonAddNode);
			m_dataMonitor.RemoveHandlerForControl(buttonDeleteNode);
			m_dataMonitor.RemoveHandlerForControl(buttonEditNode);

			//mam
			SetButtons();
			//</mam>

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();

			base.OnLoad(e);
		}

		//mam 01042012
		public void SetReadOnlyTextBoxBackgroundColorBulk()
		{
			//mam 12192011
			//text boxes that are always read only - numeric
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			Color backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			}
			textBoxTotalAcquisitionCost.BackColor = backgroundColor;
			textBoxTotalAcquisitionCostEscalated.BackColor = backgroundColor;
			textBoxTotalReplacementValue.BackColor = backgroundColor;
			textBoxTotalSalvageValue.BackColor = backgroundColor;
			textBoxTotalAnnualMaintenanceCost.BackColor = backgroundColor;
			textBoxReplacementValueYear.BackColor = backgroundColor;
			textBoxInstallYear.BackColor = backgroundColor;
			textBoxOriginalUL.BackColor = backgroundColor;
			textBoxLOS.BackColor = backgroundColor;
			textBoxAverageCondition.BackColor = backgroundColor;
			textBoxAverageCriticality.BackColor = backgroundColor;
			textBoxAverageVulnerability.BackColor = backgroundColor;
			textBoxOrgCostCurVal.BackColor = backgroundColor;
			textBoxTotalRehabCost.BackColor = backgroundColor;
			textBoxBookValue.BackColor = backgroundColor;
			textBoxAnnualDepreciation.BackColor = backgroundColor;
			textBoxCumulativeDepreciation.BackColor = backgroundColor;
			textBoxEvaluatedValue.BackColor = backgroundColor;
			textBoxRepairCostCurVal.BackColor = backgroundColor;
			textBoxRemainingUL.BackColor = backgroundColor;
			textBoxEvaluatedRemainingUL.BackColor = backgroundColor;
			textBoxEconomicUL.BackColor = backgroundColor;
			textBoxAverageRisk.BackColor = backgroundColor;

			//mam 12192011
			//text boxes that are always read only - asset names
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames;
			}
			textBoxFacilityName.BackColor = backgroundColor;
			textBoxProcessName.BackColor = backgroundColor;
			textBoxComponentName.BackColor = backgroundColor;
			textBoxDisciplineName.BackColor = backgroundColor;
			textBoxCurrentYear.BackColor = backgroundColor;
			textBoxCurrentENR.BackColor = backgroundColor;

			//mam 0122201 - let's not change the color of the screen - the result varies depending on the selected theme
			//mam 12192011
			//screen background
			//mam 01222012 - always set background color of the screen so we can switch back to Control color if custom color is not being used
			//backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			//if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen)
			//{
			//	backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorScreen;
			//}
			//this.BackColor = backgroundColor;
			//this.tabPageMain.BackColor = backgroundColor;
			//this.tabPageComponentInfo.BackColor = backgroundColor;
		}

		public void			SetDiscipline(DisciplineNode disc)
		{
			if (m_discipline != null &&
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				SaveFormData();
			}
			m_discipline = disc;

			//mam 01222012 - added argument
			//RefreshData();
			RefreshData(false);
		}

		protected override void OnVisibleChanged(EventArgs e)
		{
			if (this.Visible == false && m_discipline != null && 
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				// Save outstanding data
				SaveFormData();
			}

			base.OnVisibleChanged(e);
		}

		private bool		SaveFormData()
		{
			if (m_discipline == null)
				return true;

			// Main Tab

			// miscellaneous information
			m_discipline.DateInspected = ((DateTime)dateInspect.Value).Date;
			m_discipline.AssessedBy = textBoxAssessedBy.Text;

			// Component Info tab
			m_discipline.Comments = textBoxComments.Text;

			m_discipline.Save();
			m_dataMonitor.Dirty = false;
			return true;
		}

		//mam 01222012 - added parameter setToCurrentlySelectedTab
		//public void			RefreshData()
		public void			RefreshData(bool restoreTabSelection)
		{
			//mam 01222012
			int curTab = tabControl.SelectedIndex;

			nodeAppurtenanceGrid.SetDiscipline(m_discipline);

			if (m_discipline == null)
				return;

			m_discipline.InfoSetID = InfoSet.CurrentID;
			m_suppressUpdate = true;
			// Ignore UI change events
			m_dataMonitor.IgnoreChanges = true;

			//mam 01222012
			//tabControl.SelectedIndex = 0;
			tabControl.SelectedIndex = restoreTabSelection ? curTab : 0;

			MajorComponent component = CacheManager.GetMajorComponent(InfoSet.CurrentID, m_discipline.ComponentID);
			TreatmentProcess process = CacheManager.GetTreatmentProcess(InfoSet.CurrentID, component.ProcessID);
			Facility facility = CacheManager.GetFacility(InfoSet.CurrentID, process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();
			textBoxCurrentENR.Text = facility.CurrentENR.ToString();

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = component.Name;

			// Main Tab
			UpdateCalculatedProperties();

			dateInspect.Value = m_discipline.DateInspected;
			textBoxAssessedBy.Text = m_discipline.AssessedBy;

			textBoxComments.Text = m_discipline.Comments;

			m_dataMonitor.IgnoreChanges = false;
			m_dataMonitor.Dirty = false;
			m_suppressUpdate = false;

			//mam - disable controls if infoset is fixed
			SetControls();
			//</mam>

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();
		}

		private void		UpdateCalculatedProperties()
		{
			textBoxTotalAcquisitionCost.Text = m_discipline.AcquisitionCost.ToString("$#,##0");
			textBoxTotalReplacementValue.Text = m_discipline.ReplacementValue.ToString("$#,##0");
			textBoxTotalSalvageValue.Text = m_discipline.SalvageValue.ToString("$#,##0");
			textBoxTotalAnnualMaintenanceCost.Text = m_discipline.AnnualMaintCost.ToString("$#,##0");

			//mam 050806
			textBoxReplacementValueYear.Text = m_discipline.ReplacementValueYear.ToString();

			textBoxInstallYear.Text = m_discipline.InstallationYear.ToString();

			//mam 112806
			//textBoxOrgCostCurVal.Text = m_discipline.GetCurrentValue().ToString("$#,##0");

			textBoxBookValue.Text = m_discipline.GetBookValue().ToString("$#,##0");
			textBoxAnnualDepreciation.Text = m_discipline.GetAnnualDepreciation().ToString("$#,##0");
			textBoxCumulativeDepreciation.Text = m_discipline.GetCumulativeDepreciation().ToString("$#,##0");

			//mam 050806
			textBoxTotalAcquisitionCostEscalated.Text = m_discipline.AcquisitionCostEscalated.ToString("$#,##0");
			textBoxTotalRehabCost.Text = m_discipline.RehabCost.ToString("$#,##0");

			//mam 112806
			if (m_discipline.GetAllConditionNA())
			{
				textBoxOrgCostCurVal.Text = "N/A";

				if (m_discipline.GetAnyCurrentValueOverridden())
				{
					textBoxOrgCostCurVal.Text = m_discipline.GetCurrentValue().ToString("$#,##0");
				}
				else
				{
					textBoxOrgCostCurVal.Text = "N/A";
				}
			}
			else
			{
				textBoxOrgCostCurVal.Text = m_discipline.GetCurrentValue().ToString("$#,##0");
			}

			//mam - check Current Value and Condition
			//if Current Value = zero, all averaged values = N/A
			//mam 112806 - added check for CV = N/A
			if (textBoxOrgCostCurVal.Text == "N/A"
				|| Decimal.Parse(textBoxOrgCostCurVal.Text, System.Globalization.NumberStyles.Currency) == 0)
			{
				textBoxOriginalUL.Text = "N/A";
				textBoxLOS.Text = "N/A";
				textBoxAverageCriticality.Text = "N/A";
				textBoxAverageVulnerability.Text = "N/A";
				textBoxAverageCondition.Text = "N/A";
				textBoxEvaluatedRemainingUL.Text = "N/A";
				textBoxEconomicUL.Text = "N/A";
				textBoxRemainingUL.Text = "N/A";
				textBoxAverageRisk.Text = "N/A";
			}
			else
			{
				textBoxOriginalUL.Text = m_discipline.OrgUsefulLife.ToString();
				textBoxLOS.Text = m_discipline.GetAverageLOS().ToString("0.0");
				textBoxAverageCriticality.Text = m_discipline.GetAverageCriticality().ToString("F1");
				textBoxRemainingUL.Text = m_discipline.GetRemainingUsefulLife().ToString("F1");

				//if all ERUL values are zero and no Vulnerabilities are overridden, Vuln and Risk = N/A
				if (m_discipline.GetAllERULZero() && !m_discipline.GetAnyVulnerabilityOverridden())
				{
					textBoxAverageVulnerability.Text = "N/A";
					textBoxAverageRisk.Text = "N/A";
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//textBoxAverageVulnerability.Text = m_discipline.GetAverageVulnerability().ToString();
					textBoxAverageVulnerability.Text = m_discipline.GetAverageVulnerability().ToString("F4");

					textBoxAverageRisk.Text = m_discipline.GetAverageRisk().ToString("F2");
				}

				if (m_discipline.GetAllConditionNA())
				{
					textBoxAverageCondition.Text = "N/A";
					textBoxEvaluatedRemainingUL.Text = "N/A";
					textBoxEconomicUL.Text = "N/A";
				}
				else
				{
					textBoxAverageCondition.Text = m_discipline.GetAverageCondition().ToString("F1");
					textBoxEvaluatedRemainingUL.Text = m_discipline.GetEvaluatedRemainingUsefulLife().ToString("F1");
					textBoxEconomicUL.Text = m_discipline.GetEconomicUsefulLife().ToString("F1");
				}
			}

			if (m_discipline.GetAllConditionNA())
			{
				textBoxEvaluatedValue.Text = "N/A";

				//mam 050806
				if (m_discipline.GetAnyRepairCostOverridden())
				{
					textBoxRepairCostCurVal.Text = m_discipline.GetRepairCost().ToString("$#,##0");
				}
				else
				{
					textBoxRepairCostCurVal.Text = "N/A";
				}
			}
			else
			{
				textBoxEvaluatedValue.Text = m_discipline.GetEvaluatedValue().ToString("$#,##0");
				textBoxRepairCostCurVal.Text = m_discipline.GetRepairCost().ToString("$#,##0");
			}
			//</mam>
		}

		private void OnDependentCalcField_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			UpdateCalculatedProperties();
		}

		private void buttonAddNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			NodeData		node = new NodeData(0);

			// Make sure that the discipline record exists
			if (m_discipline.ID == 0)
			{
				m_discipline.Save();
			}

			node.DiscNodeID = m_discipline.ID;

			//mam 112806 - commented setting ReplacementValueYear to current year
			//mam 050806
			//node.ReplacementValueYear = DateTime.Now.Year;

			if (NodeAppurtenanceDetailForm.ShowForm(node, MainForm.AppForm))
			{
				node.InfoSetID = InfoSet.CurrentID;

				//mam 07072011 - added bool success
				bool success = node.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.ShowErrorMessage("AddNode", "An error occurred while saving the Node data.");
					return;
				}

				//mam 07072011 - save the selected criticality values to the database
				node.SaveCriticalityValuesAll();

				// Need to refresh the entire grid because totals will have changed
				nodeAppurtenanceGrid.SetDiscipline(m_discipline);
				UpdateCalculatedProperties();

				//mam - set the selected grid row to the new row
				nodeAppurtenanceGrid.SetSelectedRowNewRow();
				//</mam>
			}
		}

		private void buttonEditNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			int				row;
			NodeData		node = null;

			nodeAppurtenanceGrid.GetSelectedRow(out row, out node);

			if (node != null && 
				NodeAppurtenanceDetailForm.ShowForm(node, MainForm.AppForm))
			{
				node.InfoSetID = InfoSet.CurrentID;
				node.Save();

				//mam 07072011 - save all criticality values
				node.SaveCriticalityValuesAll();

				// Need to refresh the entire grid because totals will have changed
				nodeAppurtenanceGrid.SetDiscipline(m_discipline);
				UpdateCalculatedProperties();
			}

			//mam - make sure the selected row remains the same
			nodeAppurtenanceGrid.SetSelectedRow(row);
			//</mam>
		}

		private void buttonDeleteNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

//			int				row;
//			NodeData		node = null;
//
//			nodeAppurtenanceGrid.GetSelectedRow(out row, out node);
//			if (node != null)
//			{
//				DialogResult result = MessageBox.Show(this, 
//					"Are you sure you want to delete the selected node / appurtenance?",
//					"Delete Node / Appurtenance?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
//				if (result == DialogResult.Yes)
//				{
//					node.Delete();
//					// Need to refresh the entire grid because totals will have changed
//					nodeAppurtenanceGrid.SetDiscipline(m_discipline);
//					UpdateCalculatedProperties();
//				}
//			}

			//mam 050806 - allow user to delete multiple, contiguous rows at once
			int row;
			ArrayList nodeRows = new ArrayList();

			nodeAppurtenanceGrid.GetSelectedRows(out row, ref nodeRows);
			string msgText = "Are you sure you want to delete the selected node / appurtenance?";
			if (nodeRows.Count > 0)
			{
				if (nodeRows.Count > 1)
				{
					msgText = string.Format("Are you sure you want to delete the {0} selected nodes / appurtenances?", nodeRows.Count);
				}
				
				DialogResult result = MessageBox.Show(this, msgText, "Delete Nodes / Appurtenances?", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
				if (result == DialogResult.Yes)
				{
					//mam 07072011 - added try/catch block
					try
					{
						for (int i = 0; i < nodeRows.Count; i++)
						{
							((NodeData)nodeRows[i]).Delete();
						}
						// Need to refresh the entire grid because totals will have changed
						nodeAppurtenanceGrid.SetDiscipline(m_discipline);
						UpdateCalculatedProperties();
					}
					catch (Exception ex)
					{
						WAM.Common.CommonTasks.ShowErrorMessage("MainForm", "An error has occurred: " + ex.Message);
					}
				}
			}

			//mam - make sure the selected row remains the same
			nodeAppurtenanceGrid.SetSelectedRow(row);
			//</mam>
		}

		//mam
		public int TabControlIndex
		{
			get {return tabControl.SelectedIndex;}
			set {tabControl.SelectedIndex = value;}
		}
		//</mam>

		//mam
		public void SaveData()
		{
			try
			{
				m_discipline.Save();
			}
			catch(Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage(this.Name + ".SaveData", ex.Message);
			}
		}
		//</mam>

		//mam - disable controls if infoset is fixed
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;
			dateInspect.ReadOnly = isFixedInfoset;
			textBoxAssessedBy.ReadOnly = isFixedInfoset;
			textBoxComments.ReadOnly = isFixedInfoset;

			buttonAddNode.Enabled = !isFixedInfoset;
			buttonEditNode.Enabled = !isFixedInfoset;
			buttonDeleteNode.Enabled = !isFixedInfoset;

			buttonAddNode2.Enabled = !isFixedInfoset;
			buttonEditNode2.Enabled = !isFixedInfoset;
			buttonDeleteNode2.Enabled = !isFixedInfoset;

			panelLocked.Visible = isFixedInfoset;
		}
		//</mam>

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
			//MessageBox.Show(this.ParentForm.Name);
		}

		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
			//MessageBox.Show(this.ParentForm.Name);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
			//MessageBox.Show(this.ParentForm.Name);
		}

		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandler(this);
			equationViewerHandler.AssignCursor(this);
			nodeAppurtenanceGrid.SetEquationControls();
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetButtons();
		}
		//</mam>

		//mam
		private void SetButtons()
		{
			if (tabControl.SelectedIndex== 1)
			{
				this.buttonEditNode2.Visible = true;
				this.buttonDeleteNode2.Visible = true;
			}
			else
			{
				this.buttonEditNode2.Visible = false;
				this.buttonDeleteNode2.Visible = false;
			}
		}
		//</mam>

		#endregion /***** Methods *****/
	}
}