using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Data;

namespace WAM.UI.MainViews
{
	/// <summary>
	/// Summary description for MajorComponentControl.
	/// </summary>
	public class MajorComponentControl : System.Windows.Forms.UserControl
	{
		private bool		m_suppressUpdates = false;
		private	MajorComponent m_component = null;

		//mam 050806
		string tabPageSelectedName = string.Empty;
		private TabPage tabPageMainHold = new TabPage();
		private TabPage tabPageAssessmentHold = new TabPage();
		private TabPage tabPageCostAllocationHold = new TabPage();
		private TabPage tabPagePhotoHold = new TabPage();

		//mam
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		int selectedVulnerability;
		string allowedChar = "0123456789";
		string existingText = "";
		int currentPos = 0;
		//</mam>

		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private WAM.UI.Grids.ComponentGrid componentGrid1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBoxComments;
		private WAM.UI.PhotoControl pictureBox;
		private System.Windows.Forms.Button buttonBrowsePhoto;
		private System.Windows.Forms.TextBox textBoxPhotoCaption;
		private System.Windows.Forms.TabPage tabPageAssessment;
		private System.Windows.Forms.TabPage tabPageCostAllocation;
		private WAM.UI.Grids.DisciplineAssessmentGrid gridAssessment;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBoxAssessmentComments;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox comboBoxLOS;
		private System.Windows.Forms.TextBox textBoxCritTotal;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBoxRisk;
		private System.Windows.Forms.TextBox textBoxAllocComments;
		private System.Windows.Forms.Label label15;
		private WAM.UI.Grids.CostAllocationGrid gridAllocation;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.CheckBox checkBoxRetired;
		private System.Windows.Forms.TextBox textBoxVulnerability;
		private System.Windows.Forms.TextBox textBoxVulnerabilityBackground;
		private System.Windows.Forms.Button buttonVulnerabilitySelect;
		private System.Windows.Forms.CheckBox checkBoxOverrideVulnerability;
		private System.Windows.Forms.PictureBox pictureBoxVulnerabilitySelect;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.TextBox textBoxID;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBoxRedundantAssetCount;
		private System.Windows.Forms.Label labelRedundantAssetCount;
		private System.Windows.Forms.Label labelCriticalityWeight5;
		private System.Windows.Forms.Label labelCriticalityWeight4;
		private System.Windows.Forms.Label labelCriticalityWeight3;
		private System.Windows.Forms.Label labelCriticalityWeight2;
		private System.Windows.Forms.Label labelCriticalityWeight1;
		private System.Windows.Forms.ComboBox comboBoxCriticality5;
		private System.Windows.Forms.Label labelCriticality5;
		private System.Windows.Forms.ComboBox comboBoxCriticality4;
		private System.Windows.Forms.Label labelCriticality4;
		private System.Windows.Forms.ComboBox comboBoxCriticality3;
		private System.Windows.Forms.Label labelCriticality3;
		private System.Windows.Forms.ComboBox comboBoxCriticality2;
		private System.Windows.Forms.Label labelCriticality2;
		private System.Windows.Forms.ComboBox comboBoxCriticality1;
		private System.Windows.Forms.Label labelCriticality1;
		private System.Windows.Forms.Label labelCriticalityWeight6;
		private System.Windows.Forms.ComboBox comboBoxCriticality6;
		private System.Windows.Forms.Label labelCriticality6;
		private System.Windows.Forms.GroupBox groupBoxCriticality;
		private System.Windows.Forms.Label labelCritTotal;
		private System.Windows.Forms.GroupBox groupBoxVulnRisk;
		private System.Windows.Forms.Panel panelAssetClassContainer;
		private System.Windows.Forms.Panel panelAssetClass;
		private System.Windows.Forms.Label labelAssetClassClose;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label labelAssetClassTitle2;
		private System.Windows.Forms.Label labelAssetClassTitle1;
		private System.Windows.Forms.ListBox listBoxAssetClass;
		private System.Windows.Forms.GroupBox groupBoxCip;
		private System.Windows.Forms.Label labelCip;
		private System.Windows.Forms.ComboBox comboBoxCip;
		private System.Windows.Forms.Label labelAssetClass;
		private System.Windows.Forms.TextBox textBoxAssetClass;
		private System.Windows.Forms.PictureBox pictureBoxAssetClass;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox textBoxPhotoFileName;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MajorComponentControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			//mam
			SetEquationControls();
			//</mam>
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MajorComponentControl));
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.componentGrid1 = new WAM.UI.Grids.ComponentGrid();
			this.tabPageAssessment = new System.Windows.Forms.TabPage();
			this.groupBoxCip = new System.Windows.Forms.GroupBox();
			this.comboBoxCip = new System.Windows.Forms.ComboBox();
			this.textBoxAssetClass = new System.Windows.Forms.TextBox();
			this.pictureBoxAssetClass = new System.Windows.Forms.PictureBox();
			this.labelCip = new System.Windows.Forms.Label();
			this.labelAssetClass = new System.Windows.Forms.Label();
			this.panelAssetClassContainer = new System.Windows.Forms.Panel();
			this.panelAssetClass = new System.Windows.Forms.Panel();
			this.labelAssetClassClose = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.labelAssetClassTitle2 = new System.Windows.Forms.Label();
			this.labelAssetClassTitle1 = new System.Windows.Forms.Label();
			this.listBoxAssetClass = new System.Windows.Forms.ListBox();
			this.groupBoxVulnRisk = new System.Windows.Forms.GroupBox();
			this.pictureBoxVulnerabilitySelect = new System.Windows.Forms.PictureBox();
			this.textBoxRisk = new System.Windows.Forms.TextBox();
			this.textBoxVulnerability = new System.Windows.Forms.TextBox();
			this.textBoxVulnerabilityBackground = new System.Windows.Forms.TextBox();
			this.buttonVulnerabilitySelect = new System.Windows.Forms.Button();
			this.checkBoxOverrideVulnerability = new System.Windows.Forms.CheckBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.textBoxRedundantAssetCount = new System.Windows.Forms.TextBox();
			this.comboBoxLOS = new System.Windows.Forms.ComboBox();
			this.textBoxAssessmentComments = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.gridAssessment = new WAM.UI.Grids.DisciplineAssessmentGrid();
			this.labelRedundantAssetCount = new System.Windows.Forms.Label();
			this.groupBoxCriticality = new System.Windows.Forms.GroupBox();
			this.labelCriticalityWeight6 = new System.Windows.Forms.Label();
			this.comboBoxCriticality6 = new System.Windows.Forms.ComboBox();
			this.labelCriticality6 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight5 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight4 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight3 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight2 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight1 = new System.Windows.Forms.Label();
			this.comboBoxCriticality5 = new System.Windows.Forms.ComboBox();
			this.labelCriticality5 = new System.Windows.Forms.Label();
			this.comboBoxCriticality4 = new System.Windows.Forms.ComboBox();
			this.labelCriticality4 = new System.Windows.Forms.Label();
			this.comboBoxCriticality3 = new System.Windows.Forms.ComboBox();
			this.labelCriticality3 = new System.Windows.Forms.Label();
			this.comboBoxCriticality2 = new System.Windows.Forms.ComboBox();
			this.labelCriticality2 = new System.Windows.Forms.Label();
			this.comboBoxCriticality1 = new System.Windows.Forms.ComboBox();
			this.labelCriticality1 = new System.Windows.Forms.Label();
			this.textBoxCritTotal = new System.Windows.Forms.TextBox();
			this.labelCritTotal = new System.Windows.Forms.Label();
			this.tabPageCostAllocation = new System.Windows.Forms.TabPage();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxAllocComments = new System.Windows.Forms.TextBox();
			this.gridAllocation = new WAM.UI.Grids.CostAllocationGrid();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.pictureBox = new WAM.UI.PhotoControl();
			this.buttonBrowsePhoto = new System.Windows.Forms.Button();
			this.textBoxPhotoCaption = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.checkBoxRetired = new System.Windows.Forms.CheckBox();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.labelLocked = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.textBoxID = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.textBoxPhotoFileName = new System.Windows.Forms.TextBox();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			this.tabPageAssessment.SuspendLayout();
			this.groupBoxCip.SuspendLayout();
			this.panelAssetClassContainer.SuspendLayout();
			this.panelAssetClass.SuspendLayout();
			this.groupBoxVulnRisk.SuspendLayout();
			this.groupBoxCriticality.SuspendLayout();
			this.tabPageCostAllocation.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.panelLocked.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.MaxLength = 255;
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 5;
			this.textBoxComponentName.Text = "";
			this.textBoxComponentName.TextChanged += new System.EventHandler(this.textBoxComponentName_TextChanged);
			this.textBoxComponentName.Leave += new System.EventHandler(this.textBoxComponentName_Leave);
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.TabStop = false;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 13;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.TabStop = false;
			this.textBoxProcessName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 4;
			this.label3.Text = "Component / Subbasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageAssessment);
			this.tabControl.Controls.Add(this.tabPageCostAllocation);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.helpProvider1.SetHelpKeyword(this.tabControl, "ComponentTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabControl, System.Windows.Forms.HelpNavigator.Topic);
			this.tabControl.ItemSize = new System.Drawing.Size(110, 18);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.helpProvider1.SetShowHelp(this.tabControl, true);
			this.tabControl.Size = new System.Drawing.Size(787, 580);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl.TabIndex = 11;
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.label4);
			this.tabPageMain.Controls.Add(this.componentGrid1);
			this.helpProvider1.SetHelpKeyword(this.tabPageMain, "ComponentTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageMain, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.helpProvider1.SetShowHelp(this.tabPageMain, true);
			this.tabPageMain.Size = new System.Drawing.Size(779, 554);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// textBoxComments
			// 
			this.textBoxComments.AcceptsReturn = true;
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(771, 384);
			this.textBoxComments.TabIndex = 11;
			this.textBoxComments.Text = "";
			this.textBoxComments.TextChanged += new System.EventHandler(this.textBoxComments_TextChanged);
			this.textBoxComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(4, 152);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Comments:";
			// 
			// componentGrid1
			// 
			this.componentGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.componentGrid1.GridStyle = WAM.UI.Grids.ComponentGrid.GridType.MajorComponents;
			this.helpProvider1.SetHelpKeyword(this.componentGrid1, "ComponentTabMain.htm");
			this.helpProvider1.SetHelpNavigator(this.componentGrid1, System.Windows.Forms.HelpNavigator.Topic);
			this.componentGrid1.Location = new System.Drawing.Point(4, 4);
			this.componentGrid1.Name = "componentGrid1";
			this.helpProvider1.SetShowHelp(this.componentGrid1, true);
			this.componentGrid1.Size = new System.Drawing.Size(771, 144);
			this.componentGrid1.TabIndex = 10;
			// 
			// tabPageAssessment
			// 
			this.tabPageAssessment.Controls.Add(this.groupBoxCip);
			this.tabPageAssessment.Controls.Add(this.panelAssetClassContainer);
			this.tabPageAssessment.Controls.Add(this.groupBoxVulnRisk);
			this.tabPageAssessment.Controls.Add(this.textBoxRedundantAssetCount);
			this.tabPageAssessment.Controls.Add(this.comboBoxLOS);
			this.tabPageAssessment.Controls.Add(this.textBoxAssessmentComments);
			this.tabPageAssessment.Controls.Add(this.label7);
			this.tabPageAssessment.Controls.Add(this.label6);
			this.tabPageAssessment.Controls.Add(this.gridAssessment);
			this.tabPageAssessment.Controls.Add(this.labelRedundantAssetCount);
			this.tabPageAssessment.Controls.Add(this.groupBoxCriticality);
			this.helpProvider1.SetHelpKeyword(this.tabPageAssessment, "ComponentTabAssessment.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageAssessment, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageAssessment.Location = new System.Drawing.Point(4, 22);
			this.tabPageAssessment.Name = "tabPageAssessment";
			this.helpProvider1.SetShowHelp(this.tabPageAssessment, true);
			this.tabPageAssessment.Size = new System.Drawing.Size(779, 554);
			this.tabPageAssessment.TabIndex = 2;
			this.tabPageAssessment.Text = "Assessment";
			// 
			// groupBoxCip
			// 
			this.groupBoxCip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxCip.Controls.Add(this.comboBoxCip);
			this.groupBoxCip.Controls.Add(this.textBoxAssetClass);
			this.groupBoxCip.Controls.Add(this.pictureBoxAssetClass);
			this.groupBoxCip.Controls.Add(this.labelCip);
			this.groupBoxCip.Controls.Add(this.labelAssetClass);
			this.groupBoxCip.Location = new System.Drawing.Point(297, 317);
			this.groupBoxCip.Name = "groupBoxCip";
			this.groupBoxCip.Size = new System.Drawing.Size(244, 91);
			this.groupBoxCip.TabIndex = 107;
			this.groupBoxCip.TabStop = false;
			this.groupBoxCip.Visible = false;
			// 
			// comboBoxCip
			// 
			this.comboBoxCip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxCip.BackColor = System.Drawing.Color.White;
			this.comboBoxCip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCip.Location = new System.Drawing.Point(86, 17);
			this.comboBoxCip.Name = "comboBoxCip";
			this.comboBoxCip.Size = new System.Drawing.Size(154, 21);
			this.comboBoxCip.TabIndex = 100;
			// 
			// textBoxAssetClass
			// 
			this.textBoxAssetClass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAssetClass.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxAssetClass.Location = new System.Drawing.Point(6, 61);
			this.textBoxAssetClass.MaxLength = 50;
			this.textBoxAssetClass.Name = "textBoxAssetClass";
			this.textBoxAssetClass.Size = new System.Drawing.Size(212, 20);
			this.textBoxAssetClass.TabIndex = 98;
			this.textBoxAssetClass.TabStop = false;
			this.textBoxAssetClass.Text = "";
			// 
			// pictureBoxAssetClass
			// 
			this.pictureBoxAssetClass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxAssetClass.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxAssetClass.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAssetClass.Image")));
			this.pictureBoxAssetClass.Location = new System.Drawing.Point(222, 63);
			this.pictureBoxAssetClass.Name = "pictureBoxAssetClass";
			this.pictureBoxAssetClass.Size = new System.Drawing.Size(16, 16);
			this.pictureBoxAssetClass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxAssetClass.TabIndex = 99;
			this.pictureBoxAssetClass.TabStop = false;
			// 
			// labelCip
			// 
			this.labelCip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.labelCip.Location = new System.Drawing.Point(3, 20);
			this.labelCip.Name = "labelCip";
			this.labelCip.Size = new System.Drawing.Size(83, 16);
			this.labelCip.TabIndex = 101;
			this.labelCip.Text = "Planning Mode:";
			this.labelCip.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelAssetClass
			// 
			this.labelAssetClass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.labelAssetClass.Location = new System.Drawing.Point(7, 46);
			this.labelAssetClass.Name = "labelAssetClass";
			this.labelAssetClass.Size = new System.Drawing.Size(83, 16);
			this.labelAssetClass.TabIndex = 96;
			this.labelAssetClass.Text = "Asset Class:";
			this.labelAssetClass.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelAssetClassContainer
			// 
			this.panelAssetClassContainer.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelAssetClassContainer.Controls.Add(this.panelAssetClass);
			this.panelAssetClassContainer.Location = new System.Drawing.Point(237, 165);
			this.panelAssetClassContainer.Name = "panelAssetClassContainer";
			this.panelAssetClassContainer.Size = new System.Drawing.Size(239, 140);
			this.panelAssetClassContainer.TabIndex = 106;
			this.panelAssetClassContainer.Visible = false;
			// 
			// panelAssetClass
			// 
			this.panelAssetClass.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelAssetClass.BackColor = System.Drawing.SystemColors.Control;
			this.panelAssetClass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panelAssetClass.Controls.Add(this.labelAssetClassClose);
			this.panelAssetClass.Controls.Add(this.panel2);
			this.panelAssetClass.Controls.Add(this.labelAssetClassTitle2);
			this.panelAssetClass.Controls.Add(this.labelAssetClassTitle1);
			this.panelAssetClass.Controls.Add(this.listBoxAssetClass);
			this.panelAssetClass.Location = new System.Drawing.Point(8, 11);
			this.panelAssetClass.Name = "panelAssetClass";
			this.panelAssetClass.Size = new System.Drawing.Size(223, 121);
			this.panelAssetClass.TabIndex = 105;
			// 
			// labelAssetClassClose
			// 
			this.labelAssetClassClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.labelAssetClassClose.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAssetClassClose.Location = new System.Drawing.Point(200, 0);
			this.labelAssetClassClose.Name = "labelAssetClassClose";
			this.labelAssetClassClose.Size = new System.Drawing.Size(22, 21);
			this.labelAssetClassClose.TabIndex = 17;
			this.labelAssetClassClose.Text = "X";
			this.labelAssetClassClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel2.Location = new System.Drawing.Point(0, 39);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(223, 1);
			this.panel2.TabIndex = 16;
			// 
			// labelAssetClassTitle2
			// 
			this.labelAssetClassTitle2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelAssetClassTitle2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAssetClassTitle2.Location = new System.Drawing.Point(6, 20);
			this.labelAssetClassTitle2.Name = "labelAssetClassTitle2";
			this.labelAssetClassTitle2.Size = new System.Drawing.Size(185, 18);
			this.labelAssetClassTitle2.TabIndex = 14;
			this.labelAssetClassTitle2.Text = "from Other Components";
			// 
			// labelAssetClassTitle1
			// 
			this.labelAssetClassTitle1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelAssetClassTitle1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAssetClassTitle1.Location = new System.Drawing.Point(6, 4);
			this.labelAssetClassTitle1.Name = "labelAssetClassTitle1";
			this.labelAssetClassTitle1.Size = new System.Drawing.Size(185, 19);
			this.labelAssetClassTitle1.TabIndex = 13;
			this.labelAssetClassTitle1.Text = "Asset Class Values";
			// 
			// listBoxAssetClass
			// 
			this.listBoxAssetClass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.listBoxAssetClass.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.listBoxAssetClass.Location = new System.Drawing.Point(1, 40);
			this.listBoxAssetClass.Name = "listBoxAssetClass";
			this.listBoxAssetClass.Size = new System.Drawing.Size(220, 78);
			this.listBoxAssetClass.TabIndex = 8;
			// 
			// groupBoxVulnRisk
			// 
			this.groupBoxVulnRisk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxVulnRisk.Controls.Add(this.pictureBoxVulnerabilitySelect);
			this.groupBoxVulnRisk.Controls.Add(this.textBoxRisk);
			this.groupBoxVulnRisk.Controls.Add(this.textBoxVulnerability);
			this.groupBoxVulnRisk.Controls.Add(this.textBoxVulnerabilityBackground);
			this.groupBoxVulnRisk.Controls.Add(this.buttonVulnerabilitySelect);
			this.groupBoxVulnRisk.Controls.Add(this.checkBoxOverrideVulnerability);
			this.groupBoxVulnRisk.Controls.Add(this.label14);
			this.groupBoxVulnRisk.Controls.Add(this.label13);
			this.groupBoxVulnRisk.Location = new System.Drawing.Point(533, 408);
			this.groupBoxVulnRisk.Name = "groupBoxVulnRisk";
			this.groupBoxVulnRisk.Size = new System.Drawing.Size(244, 76);
			this.groupBoxVulnRisk.TabIndex = 95;
			this.groupBoxVulnRisk.TabStop = false;
			// 
			// pictureBoxVulnerabilitySelect
			// 
			this.pictureBoxVulnerabilitySelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxVulnerabilitySelect.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxVulnerabilitySelect.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxVulnerabilitySelect.Image")));
			this.pictureBoxVulnerabilitySelect.Location = new System.Drawing.Point(150, 18);
			this.pictureBoxVulnerabilitySelect.Name = "pictureBoxVulnerabilitySelect";
			this.pictureBoxVulnerabilitySelect.Size = new System.Drawing.Size(16, 16);
			this.pictureBoxVulnerabilitySelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxVulnerabilitySelect.TabIndex = 94;
			this.pictureBoxVulnerabilitySelect.TabStop = false;
			this.pictureBoxVulnerabilitySelect.Click += new System.EventHandler(this.buttonVulnerabilitySelect_Click);
			// 
			// textBoxRisk
			// 
			this.textBoxRisk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxRisk.Location = new System.Drawing.Point(102, 48);
			this.textBoxRisk.Name = "textBoxRisk";
			this.textBoxRisk.ReadOnly = true;
			this.textBoxRisk.Size = new System.Drawing.Size(44, 20);
			this.textBoxRisk.TabIndex = 13;
			this.textBoxRisk.Tag = "RISK";
			this.textBoxRisk.Text = "";
			// 
			// textBoxVulnerability
			// 
			this.textBoxVulnerability.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxVulnerability.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxVulnerability.Location = new System.Drawing.Point(114, 19);
			this.textBoxVulnerability.MaxLength = 4;
			this.textBoxVulnerability.Name = "textBoxVulnerability";
			this.textBoxVulnerability.Size = new System.Drawing.Size(28, 13);
			this.textBoxVulnerability.TabIndex = 10;
			this.textBoxVulnerability.Tag = "VULN";
			this.textBoxVulnerability.Text = "";
			this.textBoxVulnerability.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxVulnerability_KeyPress);
			this.textBoxVulnerability.TextChanged += new System.EventHandler(this.textBoxVulnerability_TextChanged);
			this.textBoxVulnerability.Leave += new System.EventHandler(this.textBoxVulnerability_Leave);
			// 
			// textBoxVulnerabilityBackground
			// 
			this.textBoxVulnerabilityBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxVulnerabilityBackground.Location = new System.Drawing.Point(102, 16);
			this.textBoxVulnerabilityBackground.MaxLength = 4;
			this.textBoxVulnerabilityBackground.Name = "textBoxVulnerabilityBackground";
			this.textBoxVulnerabilityBackground.ReadOnly = true;
			this.textBoxVulnerabilityBackground.Size = new System.Drawing.Size(44, 20);
			this.textBoxVulnerabilityBackground.TabIndex = 9;
			this.textBoxVulnerabilityBackground.TabStop = false;
			this.textBoxVulnerabilityBackground.Text = "0.";
			this.textBoxVulnerabilityBackground.Enter += new System.EventHandler(this.textBoxVulnerabilityBackground_Enter);
			// 
			// buttonVulnerabilitySelect
			// 
			this.buttonVulnerabilitySelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonVulnerabilitySelect.BackColor = System.Drawing.SystemColors.Control;
			this.buttonVulnerabilitySelect.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.buttonVulnerabilitySelect.Location = new System.Drawing.Point(150, 18);
			this.buttonVulnerabilitySelect.Name = "buttonVulnerabilitySelect";
			this.buttonVulnerabilitySelect.Size = new System.Drawing.Size(16, 16);
			this.buttonVulnerabilitySelect.TabIndex = 47;
			this.buttonVulnerabilitySelect.Text = "n";
			this.buttonVulnerabilitySelect.Visible = false;
			this.buttonVulnerabilitySelect.Click += new System.EventHandler(this.buttonVulnerabilitySelect_Click);
			// 
			// checkBoxOverrideVulnerability
			// 
			this.checkBoxOverrideVulnerability.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.checkBoxOverrideVulnerability.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBoxOverrideVulnerability.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOverrideVulnerability.Location = new System.Drawing.Point(174, 19);
			this.checkBoxOverrideVulnerability.Name = "checkBoxOverrideVulnerability";
			this.checkBoxOverrideVulnerability.Size = new System.Drawing.Size(61, 16);
			this.checkBoxOverrideVulnerability.TabIndex = 11;
			this.checkBoxOverrideVulnerability.Text = "Override";
			this.checkBoxOverrideVulnerability.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBoxOverrideVulnerability.CheckedChanged += new System.EventHandler(this.checkBoxOverrideVulnerability_CheckedChanged);
			// 
			// label14
			// 
			this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label14.Location = new System.Drawing.Point(21, 51);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(80, 16);
			this.label14.TabIndex = 12;
			this.label14.Text = "Risk:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label13
			// 
			this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label13.Location = new System.Drawing.Point(22, 19);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(80, 16);
			this.label13.TabIndex = 8;
			this.label13.Text = "Vulnerability:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRedundantAssetCount
			// 
			this.textBoxRedundantAssetCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxRedundantAssetCount.Location = new System.Drawing.Point(690, 13);
			this.textBoxRedundantAssetCount.MaxLength = 4;
			this.textBoxRedundantAssetCount.Name = "textBoxRedundantAssetCount";
			this.textBoxRedundantAssetCount.Size = new System.Drawing.Size(30, 20);
			this.textBoxRedundantAssetCount.TabIndex = 4;
			this.textBoxRedundantAssetCount.Text = "";
			this.textBoxRedundantAssetCount.Leave += new System.EventHandler(this.textBoxRedundantAssetCount_Leave);
			// 
			// comboBoxLOS
			// 
			this.comboBoxLOS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxLOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxLOS.Location = new System.Drawing.Point(537, 61);
			this.comboBoxLOS.Name = "comboBoxLOS";
			this.comboBoxLOS.Size = new System.Drawing.Size(236, 20);
			this.comboBoxLOS.TabIndex = 6;
			this.comboBoxLOS.SelectedIndexChanged += new System.EventHandler(this.OnChangeLOS);
			// 
			// textBoxAssessmentComments
			// 
			this.textBoxAssessmentComments.AcceptsReturn = true;
			this.textBoxAssessmentComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAssessmentComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxAssessmentComments.Multiline = true;
			this.textBoxAssessmentComments.Name = "textBoxAssessmentComments";
			this.textBoxAssessmentComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAssessmentComments.Size = new System.Drawing.Size(525, 384);
			this.textBoxAssessmentComments.TabIndex = 2;
			this.textBoxAssessmentComments.Text = "";
			this.textBoxAssessmentComments.TextChanged += new System.EventHandler(this.textBoxAssessmentComments_TextChanged);
			this.textBoxAssessmentComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(4, 152);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 16);
			this.label7.TabIndex = 1;
			this.label7.Text = "Comments:";
			// 
			// label6
			// 
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label6.Location = new System.Drawing.Point(536, 46);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(132, 16);
			this.label6.TabIndex = 5;
			this.label6.Text = "Level of Service:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// gridAssessment
			// 
			this.gridAssessment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.helpProvider1.SetHelpKeyword(this.gridAssessment, "ComponentTabAssessment.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAssessment, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAssessment.Location = new System.Drawing.Point(4, 4);
			this.gridAssessment.Name = "gridAssessment";
			this.helpProvider1.SetShowHelp(this.gridAssessment, true);
			this.gridAssessment.Size = new System.Drawing.Size(525, 144);
			this.gridAssessment.TabIndex = 0;
			// 
			// labelRedundantAssetCount
			// 
			this.labelRedundantAssetCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.labelRedundantAssetCount.Location = new System.Drawing.Point(576, 8);
			this.labelRedundantAssetCount.Name = "labelRedundantAssetCount";
			this.labelRedundantAssetCount.Size = new System.Drawing.Size(121, 30);
			this.labelRedundantAssetCount.TabIndex = 3;
			this.labelRedundantAssetCount.Text = "Number of Assets with Similar Functionality";
			this.labelRedundantAssetCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBoxCriticality
			// 
			this.groupBoxCriticality.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight6);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality6);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality6);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight5);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight4);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight3);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight2);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight1);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality5);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality5);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality4);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality4);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality3);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality3);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality2);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality2);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality1);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality1);
			this.groupBoxCriticality.Controls.Add(this.textBoxCritTotal);
			this.groupBoxCriticality.Controls.Add(this.labelCritTotal);
			this.groupBoxCriticality.Location = new System.Drawing.Point(533, 86);
			this.groupBoxCriticality.Name = "groupBoxCriticality";
			this.groupBoxCriticality.Size = new System.Drawing.Size(244, 314);
			this.groupBoxCriticality.TabIndex = 7;
			this.groupBoxCriticality.TabStop = false;
			this.groupBoxCriticality.Text = "Criticality";
			// 
			// labelCriticalityWeight6
			// 
			this.labelCriticalityWeight6.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight6.Location = new System.Drawing.Point(208, 241);
			this.labelCriticalityWeight6.Name = "labelCriticalityWeight6";
			this.labelCriticalityWeight6.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight6.TabIndex = 54;
			this.labelCriticalityWeight6.Text = "0%";
			this.labelCriticalityWeight6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight6.Visible = false;
			// 
			// comboBoxCriticality6
			// 
			this.comboBoxCriticality6.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality6.Location = new System.Drawing.Point(4, 257);
			this.comboBoxCriticality6.Name = "comboBoxCriticality6";
			this.comboBoxCriticality6.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality6.TabIndex = 52;
			this.comboBoxCriticality6.Visible = false;
			// 
			// labelCriticality6
			// 
			this.labelCriticality6.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality6.Location = new System.Drawing.Point(4, 241);
			this.labelCriticality6.Name = "labelCriticality6";
			this.labelCriticality6.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality6.TabIndex = 53;
			this.labelCriticality6.Text = "Criticality 6";
			this.labelCriticality6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality6.Visible = false;
			// 
			// labelCriticalityWeight5
			// 
			this.labelCriticalityWeight5.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight5.Location = new System.Drawing.Point(208, 197);
			this.labelCriticalityWeight5.Name = "labelCriticalityWeight5";
			this.labelCriticalityWeight5.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight5.TabIndex = 51;
			this.labelCriticalityWeight5.Text = "0%";
			this.labelCriticalityWeight5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight5.Visible = false;
			// 
			// labelCriticalityWeight4
			// 
			this.labelCriticalityWeight4.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight4.Location = new System.Drawing.Point(208, 153);
			this.labelCriticalityWeight4.Name = "labelCriticalityWeight4";
			this.labelCriticalityWeight4.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight4.TabIndex = 50;
			this.labelCriticalityWeight4.Text = "0%";
			this.labelCriticalityWeight4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight4.Visible = false;
			// 
			// labelCriticalityWeight3
			// 
			this.labelCriticalityWeight3.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight3.Location = new System.Drawing.Point(208, 109);
			this.labelCriticalityWeight3.Name = "labelCriticalityWeight3";
			this.labelCriticalityWeight3.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight3.TabIndex = 49;
			this.labelCriticalityWeight3.Text = "0%";
			this.labelCriticalityWeight3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight3.Visible = false;
			// 
			// labelCriticalityWeight2
			// 
			this.labelCriticalityWeight2.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight2.Location = new System.Drawing.Point(208, 65);
			this.labelCriticalityWeight2.Name = "labelCriticalityWeight2";
			this.labelCriticalityWeight2.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight2.TabIndex = 48;
			this.labelCriticalityWeight2.Text = "0%";
			this.labelCriticalityWeight2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelCriticalityWeight1
			// 
			this.labelCriticalityWeight1.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticalityWeight1.Location = new System.Drawing.Point(208, 21);
			this.labelCriticalityWeight1.Name = "labelCriticalityWeight1";
			this.labelCriticalityWeight1.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight1.TabIndex = 47;
			this.labelCriticalityWeight1.Text = "0%";
			this.labelCriticalityWeight1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// comboBoxCriticality5
			// 
			this.comboBoxCriticality5.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality5.Location = new System.Drawing.Point(4, 213);
			this.comboBoxCriticality5.Name = "comboBoxCriticality5";
			this.comboBoxCriticality5.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality5.TabIndex = 44;
			this.comboBoxCriticality5.Visible = false;
			// 
			// labelCriticality5
			// 
			this.labelCriticality5.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality5.Location = new System.Drawing.Point(4, 197);
			this.labelCriticality5.Name = "labelCriticality5";
			this.labelCriticality5.Size = new System.Drawing.Size(192, 16);
			this.labelCriticality5.TabIndex = 46;
			this.labelCriticality5.Text = "Criticality 5";
			this.labelCriticality5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality5.Visible = false;
			// 
			// comboBoxCriticality4
			// 
			this.comboBoxCriticality4.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality4.Location = new System.Drawing.Point(4, 169);
			this.comboBoxCriticality4.Name = "comboBoxCriticality4";
			this.comboBoxCriticality4.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality4.TabIndex = 43;
			this.comboBoxCriticality4.Visible = false;
			// 
			// labelCriticality4
			// 
			this.labelCriticality4.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality4.Location = new System.Drawing.Point(4, 153);
			this.labelCriticality4.Name = "labelCriticality4";
			this.labelCriticality4.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality4.TabIndex = 45;
			this.labelCriticality4.Text = "Criticality 4";
			this.labelCriticality4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality4.Visible = false;
			// 
			// comboBoxCriticality3
			// 
			this.comboBoxCriticality3.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality3.Location = new System.Drawing.Point(4, 125);
			this.comboBoxCriticality3.Name = "comboBoxCriticality3";
			this.comboBoxCriticality3.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality3.TabIndex = 41;
			this.comboBoxCriticality3.Visible = false;
			// 
			// labelCriticality3
			// 
			this.labelCriticality3.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality3.Location = new System.Drawing.Point(4, 109);
			this.labelCriticality3.Name = "labelCriticality3";
			this.labelCriticality3.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality3.TabIndex = 42;
			this.labelCriticality3.Text = "Criticality 3";
			this.labelCriticality3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality3.Visible = false;
			// 
			// comboBoxCriticality2
			// 
			this.comboBoxCriticality2.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality2.Location = new System.Drawing.Point(4, 81);
			this.comboBoxCriticality2.Name = "comboBoxCriticality2";
			this.comboBoxCriticality2.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality2.TabIndex = 38;
			// 
			// labelCriticality2
			// 
			this.labelCriticality2.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality2.Location = new System.Drawing.Point(4, 65);
			this.labelCriticality2.Name = "labelCriticality2";
			this.labelCriticality2.Size = new System.Drawing.Size(192, 16);
			this.labelCriticality2.TabIndex = 40;
			this.labelCriticality2.Text = "Criticality 2";
			this.labelCriticality2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxCriticality1
			// 
			this.comboBoxCriticality1.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality1.Location = new System.Drawing.Point(4, 37);
			this.comboBoxCriticality1.Name = "comboBoxCriticality1";
			this.comboBoxCriticality1.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality1.TabIndex = 37;
			// 
			// labelCriticality1
			// 
			this.labelCriticality1.BackColor = System.Drawing.SystemColors.Control;
			this.labelCriticality1.Location = new System.Drawing.Point(4, 21);
			this.labelCriticality1.Name = "labelCriticality1";
			this.labelCriticality1.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality1.TabIndex = 39;
			this.labelCriticality1.Text = "Criticality 1";
			this.labelCriticality1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBoxCritTotal
			// 
			this.textBoxCritTotal.Location = new System.Drawing.Point(102, 287);
			this.textBoxCritTotal.Name = "textBoxCritTotal";
			this.textBoxCritTotal.ReadOnly = true;
			this.textBoxCritTotal.Size = new System.Drawing.Size(44, 20);
			this.textBoxCritTotal.TabIndex = 9;
			this.textBoxCritTotal.Tag = "OCRIT";
			this.textBoxCritTotal.Text = "";
			// 
			// labelCritTotal
			// 
			this.labelCritTotal.Location = new System.Drawing.Point(5, 289);
			this.labelCritTotal.Name = "labelCritTotal";
			this.labelCritTotal.Size = new System.Drawing.Size(96, 16);
			this.labelCritTotal.TabIndex = 8;
			this.labelCritTotal.Text = "Overall Criticality:";
			this.labelCritTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabPageCostAllocation
			// 
			this.tabPageCostAllocation.Controls.Add(this.label16);
			this.tabPageCostAllocation.Controls.Add(this.textBoxAllocComments);
			this.tabPageCostAllocation.Controls.Add(this.gridAllocation);
			this.helpProvider1.SetHelpKeyword(this.tabPageCostAllocation, "ComponentTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPageCostAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPageCostAllocation.Location = new System.Drawing.Point(4, 22);
			this.tabPageCostAllocation.Name = "tabPageCostAllocation";
			this.helpProvider1.SetShowHelp(this.tabPageCostAllocation, true);
			this.tabPageCostAllocation.Size = new System.Drawing.Size(779, 554);
			this.tabPageCostAllocation.TabIndex = 3;
			this.tabPageCostAllocation.Text = "Cost Allocation by %";
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(4, 152);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(100, 16);
			this.label16.TabIndex = 5;
			this.label16.Text = "Comments:";
			// 
			// textBoxAllocComments
			// 
			this.textBoxAllocComments.AcceptsReturn = true;
			this.textBoxAllocComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAllocComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxAllocComments.Multiline = true;
			this.textBoxAllocComments.Name = "textBoxAllocComments";
			this.textBoxAllocComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAllocComments.Size = new System.Drawing.Size(771, 384);
			this.textBoxAllocComments.TabIndex = 4;
			this.textBoxAllocComments.Text = "";
			this.textBoxAllocComments.TextChanged += new System.EventHandler(this.textBoxAllocComments_TextChanged);
			this.textBoxAllocComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// gridAllocation
			// 
			this.gridAllocation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAllocation.GridStyle = WAM.UI.Grids.CostAllocationGrid.GridType.MajorComponents;
			this.helpProvider1.SetHelpKeyword(this.gridAllocation, "ComponentTabCostAllocation.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAllocation, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAllocation.Location = new System.Drawing.Point(4, 4);
			this.gridAllocation.Name = "gridAllocation";
			this.helpProvider1.SetShowHelp(this.gridAllocation, true);
			this.gridAllocation.Size = new System.Drawing.Size(771, 144);
			this.gridAllocation.TabIndex = 0;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.label8);
			this.tabPagePhoto.Controls.Add(this.label9);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoFileName);
			this.tabPagePhoto.Controls.Add(this.pictureBox);
			this.tabPagePhoto.Controls.Add(this.buttonBrowsePhoto);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption);
			this.helpProvider1.SetHelpKeyword(this.tabPagePhoto, "ComponentTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.tabPagePhoto, System.Windows.Forms.HelpNavigator.Topic);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.helpProvider1.SetShowHelp(this.tabPagePhoto, true);
			this.tabPagePhoto.Size = new System.Drawing.Size(779, 554);
			this.tabPagePhoto.TabIndex = 1;
			this.tabPagePhoto.Text = "Photo";
			// 
			// pictureBox
			// 
			this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.pictureBox, "ComponentTabPhoto.htm");
			this.helpProvider1.SetHelpNavigator(this.pictureBox, System.Windows.Forms.HelpNavigator.Topic);
			this.pictureBox.Image = null;
			this.pictureBox.Location = new System.Drawing.Point(4, 4);
			this.pictureBox.Name = "pictureBox";
			this.helpProvider1.SetShowHelp(this.pictureBox, true);
			this.pictureBox.Size = new System.Drawing.Size(771, 473);
			this.pictureBox.TabIndex = 17;
			// 
			// buttonBrowsePhoto
			// 
			this.buttonBrowsePhoto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonBrowsePhoto.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowsePhoto.Location = new System.Drawing.Point(352, 524);
			this.buttonBrowsePhoto.Name = "buttonBrowsePhoto";
			this.buttonBrowsePhoto.TabIndex = 16;
			this.buttonBrowsePhoto.Text = "Browse...";
			this.buttonBrowsePhoto.Click += new System.EventHandler(this.buttonBrowsePhoto_Click);
			// 
			// textBoxPhotoCaption
			// 
			this.textBoxPhotoCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption.Location = new System.Drawing.Point(64, 481);
			this.textBoxPhotoCaption.MaxLength = 255;
			this.textBoxPhotoCaption.Name = "textBoxPhotoCaption";
			this.textBoxPhotoCaption.Size = new System.Drawing.Size(711, 20);
			this.textBoxPhotoCaption.TabIndex = 15;
			this.textBoxPhotoCaption.Text = "";
			this.textBoxPhotoCaption.TextChanged += new System.EventHandler(this.textBoxPhotoCaption_TextChanged);
			this.textBoxPhotoCaption.Leave += new System.EventHandler(this.textBoxPhotoCaption_Leave);
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(0, 0);
			this.label15.Name = "label15";
			this.label15.TabIndex = 0;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 7;
			this.textBoxCurrentYear.TabStop = false;
			this.textBoxCurrentYear.Text = "";
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(448, 6);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(84, 16);
			this.label17.TabIndex = 6;
			this.label17.Text = "Current Year:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxRetired
			// 
			this.checkBoxRetired.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxRetired.Location = new System.Drawing.Point(532, 28);
			this.checkBoxRetired.Name = "checkBoxRetired";
			this.checkBoxRetired.Size = new System.Drawing.Size(68, 16);
			this.checkBoxRetired.TabIndex = 8;
			this.checkBoxRetired.Text = "Retired?";
			this.checkBoxRetired.CheckedChanged += new System.EventHandler(this.checkBoxRetired_CheckedChanged);
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.labelLocked);
			this.panelLocked.Location = new System.Drawing.Point(145, 90);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 17;
			// 
			// labelLocked
			// 
			this.labelLocked.BackColor = System.Drawing.Color.White;
			this.labelLocked.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelLocked.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.labelLocked.Location = new System.Drawing.Point(1, 1);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.Size = new System.Drawing.Size(213, 18);
			this.labelLocked.TabIndex = 16;
			this.labelLocked.Text = "All Data is Locked";
			this.labelLocked.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// textBoxID
			// 
			this.textBoxID.Location = new System.Drawing.Point(584, 88);
			this.textBoxID.MaxLength = 255;
			this.textBoxID.Name = "textBoxID";
			this.textBoxID.Size = new System.Drawing.Size(108, 20);
			this.textBoxID.TabIndex = 19;
			this.textBoxID.TabStop = false;
			this.textBoxID.Text = "";
			this.textBoxID.Visible = false;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(560, 84);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(20, 28);
			this.label5.TabIndex = 18;
			this.label5.Text = "ID:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label5.Visible = false;
			// 
			// label8
			// 
			this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Location = new System.Drawing.Point(4, 484);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(60, 20);
			this.label8.TabIndex = 23;
			this.label8.Text = "Caption:";
			// 
			// label9
			// 
			this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label9.BackColor = System.Drawing.Color.Transparent;
			this.label9.Location = new System.Drawing.Point(4, 503);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(60, 20);
			this.label9.TabIndex = 22;
			this.label9.Text = "File Name:";
			// 
			// textBoxPhotoFileName
			// 
			this.textBoxPhotoFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoFileName.Location = new System.Drawing.Point(64, 500);
			this.textBoxPhotoFileName.MaxLength = 255;
			this.textBoxPhotoFileName.Name = "textBoxPhotoFileName";
			this.textBoxPhotoFileName.Size = new System.Drawing.Size(711, 20);
			this.textBoxPhotoFileName.TabIndex = 21;
			this.textBoxPhotoFileName.Text = "";
			// 
			// MajorComponentControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(698, 700);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.textBoxID);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.checkBoxRetired);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label3);
			this.helpProvider1.SetHelpKeyword(this, "ComponentScreen.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Name = "MajorComponentControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(795, 696);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			this.tabPageAssessment.ResumeLayout(false);
			this.groupBoxCip.ResumeLayout(false);
			this.panelAssetClassContainer.ResumeLayout(false);
			this.panelAssetClass.ResumeLayout(false);
			this.groupBoxVulnRisk.ResumeLayout(false);
			this.groupBoxCriticality.ResumeLayout(false);
			this.tabPageCostAllocation.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.panelLocked.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		//mam 03202012
		public void SetComponentNameTextBox(string componentName)
		{
			textBoxComponentName.Text = componentName;
		}

		public void			SetComponent(MajorComponent component)
		{
			if (m_component != null)
			{
				// Make sure that the focus is taken off any control that has it
				// so that changed data may be saved
				textBoxComponentName.Focus();
			}

			m_component = component;

			//mam 01222012 - added argument
			//RefreshData();
			RefreshData(false);
		}

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			//mam 07072011 - set the handler for the SelectedIndexChanged event for all crit dropdowns
			this.comboBoxCriticality1.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
			this.comboBoxCriticality2.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
			this.comboBoxCriticality3.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
			this.comboBoxCriticality4.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
			this.comboBoxCriticality5.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
			this.comboBoxCriticality6.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);

			//mam 07072011
			this.textBoxAssetClass.Leave += new System.EventHandler(this.textBoxAssetClass_Leave);
			this.comboBoxCip.SelectedIndexChanged += new EventHandler(this.OnChangeCipPlanning);

			//mam 07072011
			this.labelAssetClassClose.Click += new System.EventHandler(this.labelAssetClassClose_Click);
			this.listBoxAssetClass.DoubleClick += new System.EventHandler(this.listBoxAssetClass_DoubleClick);
			this.pictureBoxAssetClass.Click += new System.EventHandler(this.pictureBoxAssetClass_Click);

			//mam 01222012
			textBoxComponentName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);

			LoadLOS();
			LoadCriticalityBoxes();

			//mam 07072011
			LoadCipComboBox();

			//mam - removed Vulnerability combo box from form
			//LoadVulnerability();
			//</mam>

			SetToolTips();
			SetBitmaps();

//			//mam 050806
//			tabPageMainHold = tabControl.TabPages[0];
//			tabPageAssessmentHold = tabControl.TabPages[1];
//
//			if (m_component.MechStructDisciplines)
//			{
//				tabPageCostAllocationHold = tabControl.TabPages[2];
//				tabPagePhotoHold = tabControl.TabPages[3];
//			}
//			else
//			{
//				tabPagePhotoHold = tabControl.TabPages[2];
//			}

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();

			//mam 03202012
			textBoxPhotoFileName.ReadOnly = true;

			base.OnLoad(e);
		}

		public void SetReadOnlyTextBoxBackgroundColorBulk()
		{
			//mam 12192011
			//text boxes that are always read only - numeric
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			Color backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
			}
			textBoxCritTotal.BackColor = backgroundColor;
			textBoxRisk.BackColor = backgroundColor;

			//mam 12192011
			//text boxes that are always read only - asset names
			//mam 01222012 - always set background color of text boxes so we can switch back to Control color if custom color is not being used
			backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames)
			{
				backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames;
			}
			textBoxFacilityName.BackColor = backgroundColor;
			textBoxProcessName.BackColor = backgroundColor;
			textBoxCurrentYear.BackColor = backgroundColor;

			//mam 0122201 - let's not change the color of the screen - the result varies depending on the selected theme
			//mam 12192011
			//screen background
			//mam 01222012 - always set background color of the screen so we can switch back to Control color if custom color is not being used
			//backgroundColor = Color.FromKnownColor(System.Drawing.KnownColor.Control);
			//if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen)
			//{
			//	backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorScreen;
			//}
			//this.BackColor = backgroundColor;
			//this.tabPageMain.BackColor = backgroundColor;
			//this.tabPageAssessment.BackColor = backgroundColor;
			//this.tabPagePhoto.BackColor = backgroundColor;
			//this.tabPageCostAllocation.BackColor = backgroundColor;

			//mam 12192011
			SetReadOnlyTextBoxBackgroundColor(textBoxVulnerability);
		}

		//mam 07072011
		public void SetAssetClass()
		{
			panelAssetClass.Visible = true;
			panelAssetClassContainer.Visible = false;
			pictureBoxAssetClass.Visible = true;

			//position the "pop-up" panel slightly above the asset class text box group box
			//panelAssetClassContainer.Location = new System.Drawing.Point(
			//	(int)groupBoxCip.Location.X, (int)groupBoxCip.Location.Y - panelAssetClassContainer.Height);

			//load asset class values
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = Common.CommonTasks.GetAssetClassValues(m_component.ID);
			}
			catch(Exception ex)
			{
				Common.CommonTasks.ShowErrorMessage("SetAssetClass", ex.Message);
			}

			listBoxAssetClass.DataSource = dataTable;
			listBoxAssetClass.DisplayMember = "AssetClass";
		}

		private void		LoadLOS()
		{
			//mam 050806
			WAM.Common.CommonTasks.LoadLOS(ref comboBoxLOS);

//			int				pos;
//			LevelOfService[] losValues = (LevelOfService[])Enum.GetValues(typeof(LevelOfService));
//
//			comboBoxLOS.BeginUpdate();
//			comboBoxLOS.DisplayMember = "DisplayMember";
//			comboBoxLOS.Items.Clear();
//			for (pos = 0; pos < losValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxLOS.Items.Add(new ListItem(
//				//	EnumHandlers.GetLOSShort(losValues[pos]),
//				//	losValues[pos]));
//				comboBoxLOS.Items.Add(new ListItem(
//					EnumHandlers.GetLOSString(losValues[pos]),
//					losValues[pos]));
//				//</mam>
//			}
//			comboBoxLOS.EndUpdate();
		}

		//mam 07072011
		private void LoadCipComboBox()
		{
			try
			{
				Common.CommonTasks.LoadCipPlanningComboBox(comboBoxCip);
			}
			catch(Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage(this.Name + ".LoadCipComboBox", ex.Message);
			}
		}

		private void LoadCriticalityBoxes()
		{
			//mam 07072011 - no longer using the four fixed crits
			//mam 050806
			//WAM.Common.CommonTasks.LoadCriticalityBoxPublicHealth(ref comboBoxCritHealth);
			//WAM.Common.CommonTasks.LoadCriticalityBoxEnvironmental(ref comboBoxCritEnv);
			//WAM.Common.CommonTasks.LoadCriticalityBoxRepair(ref comboBoxCritRepairCost);
			//WAM.Common.CommonTasks.LoadCriticalityBoxCustomerEffect(ref comboBoxCritCustEffect);

			//mam 07072011
			WAM.Common.CommonTasks.LoadCriticalityComboBoxes(comboBoxCriticality1, comboBoxCriticality2
				, comboBoxCriticality3, comboBoxCriticality4, comboBoxCriticality5, comboBoxCriticality6
				, labelCriticality1, labelCriticality2, labelCriticality3
				, labelCriticality4, labelCriticality5, labelCriticality6
				, labelCriticalityWeight1, labelCriticalityWeight2, labelCriticalityWeight3
				, labelCriticalityWeight4, labelCriticalityWeight5, labelCriticalityWeight6);

//			int				pos;
//
//			// Public Health and Safety
//			CriticalityPublicHealth[] critHealthValues = 
//				(CriticalityPublicHealth[])Enum.GetValues(
//				typeof(CriticalityPublicHealth));
//			comboBoxCritHealth.BeginUpdate();
//			comboBoxCritHealth.DisplayMember = "DisplayMember";
//			comboBoxCritHealth.Items.Clear();
//			for (pos = 0; pos < critHealthValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxCritHealth.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritPublicHealthString(
//				//	critHealthValues[pos]),
//				//	critHealthValues[pos]));
//				//new code:
//				comboBoxCritHealth.Items.Add(new ListItem(
//					EnumHandlers.GetCritPublicHealthStringAssocValue(
//					critHealthValues[pos]),
//					critHealthValues[pos]));
//				//</mam>
//			}
//			comboBoxCritHealth.EndUpdate();
//
//			// Environmental
//			CriticalityEnvironmental[] critEnvValues = 
//				(CriticalityEnvironmental[])Enum.GetValues(
//				typeof(CriticalityEnvironmental));
//			comboBoxCritEnv.BeginUpdate();
//			comboBoxCritEnv.DisplayMember = "DisplayMember";
//			comboBoxCritEnv.Items.Clear();
//			for (pos = 0; pos < critEnvValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxCritEnv.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritEnvironmentalString(
//				//	critEnvValues[pos]),
//				//	critEnvValues[pos]));
//				//new code:
//				comboBoxCritEnv.Items.Add(new ListItem(
//					EnumHandlers.GetCritEnvironmentalStringAssocValue(
//					critEnvValues[pos]),
//					critEnvValues[pos]));
//				//</mam>
//			}
//			comboBoxCritEnv.EndUpdate();
//
//			// Cost of Repair
//			CriticalityRepairCost[] critRepairValues = 
//				(CriticalityRepairCost[])Enum.GetValues(
//				typeof(CriticalityRepairCost));
//			comboBoxCritRepairCost.BeginUpdate();
//			comboBoxCritRepairCost.DisplayMember = "DisplayMember";
//			comboBoxCritRepairCost.Items.Clear();
//			for (pos = 0; pos < critRepairValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxCritRepairCost.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritRepairCostString(
//				//	critRepairValues[pos]),
//				//	critRepairValues[pos]));
//				//new code:
//				comboBoxCritRepairCost.Items.Add(new ListItem(
//					EnumHandlers.GetCritRepairCostStringAssocValue(
//					critRepairValues[pos]),
//					critRepairValues[pos]));
//				//</mam>
//			}
//			comboBoxCritRepairCost.EndUpdate();
//
//			// Customer Effect
//			CriticalityCustomerEffect[] critCustEffectValues = 
//				(CriticalityCustomerEffect[])Enum.GetValues(
//				typeof(CriticalityCustomerEffect));
//			comboBoxCritCustEffect.BeginUpdate();
//			comboBoxCritCustEffect.DisplayMember = "DisplayMember";
//			comboBoxCritCustEffect.Items.Clear();
//			for (pos = 0; pos < critCustEffectValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxCritCustEffect.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritCustomerEffectString(
//				//	critCustEffectValues[pos]),
//				//	critCustEffectValues[pos]));
//				//new code:
//				comboBoxCritCustEffect.Items.Add(new ListItem(
//					EnumHandlers.GetCritCustomerEffectStringAssocValue(
//					critCustEffectValues[pos]),
//					critCustEffectValues[pos]));
//				//</mam>
//			}
//			comboBoxCritCustEffect.EndUpdate();
		}

		//mam - removed Vulnerability combo box from form
//		private void		LoadVulnerability()
//		{
//			int				pos;
//			Vulnerability[] vulnerabilityValues = 
//				(Vulnerability[])Enum.GetValues(typeof(Vulnerability));
//
//			// Add vulnerabilities
//			comboBoxVulnerability.BeginUpdate();
//			comboBoxVulnerability.DisplayMember = "DisplayMember";
//			comboBoxVulnerability.Items.Clear();
//			for (pos = 0; pos < vulnerabilityValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxVulnerability.Items.Add(new ListItem(
//				//	EnumHandlers.GetVulnerabilityString(vulnerabilityValues[pos]),
//				//	vulnerabilityValues[pos]));
//				//new code:
//				comboBoxVulnerability.Items.Add(new ListItem(
//					EnumHandlers.GetVulnerabilityStringAssocValue(vulnerabilityValues[pos]),
//					vulnerabilityValues[pos]));
//				//</mam>
//			}
//			comboBoxVulnerability.EndUpdate();
//		}
		//</mam>

		//mam 01222012 - added parameter setToCurrentlySelectedTab
		public void			RefreshData(bool restoreTabSelection)
		{
			//mam 01222012
			TabPage curTab = tabControl.SelectedTab;

			componentGrid1.SetRootObject(m_component);
			gridAssessment.SetRootObject(m_component);
			gridAllocation.SetRootObject(m_component);

			if (m_component == null)
				return;

			m_component.InfoSetID = InfoSet.CurrentID;
			m_suppressUpdates = true;
			TreatmentProcess process = 
				CacheManager.GetTreatmentProcess(InfoSet.CurrentID, m_component.ProcessID);
			Facility facility = 
				CacheManager.GetFacility(InfoSet.CurrentID, process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();
			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = m_component.Name;
			textBoxComments.Text = m_component.Comments;
			textBoxAllocComments.Text = m_component.Comments;
			textBoxAssessmentComments.Text = m_component.Comments;
			checkBoxRetired.Checked = m_component.Retired;

			//mam 050806
			textBoxRedundantAssetCount.Text = m_component.RedundantAssetCount.ToString("0");

			//mam 07072011
			textBoxAssetClass.Text = m_component.AssetClass;

			tabControl.TabPages.Remove(tabPageCostAllocation);
			tabControl.TabPages.Remove(tabPagePhoto);

			if (m_component.MechStructDisciplines)
				tabControl.TabPages.Add(tabPageCostAllocation);

			tabControl.TabPages.Add(tabPagePhoto);

			//mam 01222012
			//tabControl.SelectedTab = tabPageMain;
			tabControl.SelectedTab = restoreTabSelection ? curTab : tabPageMain;

			//mam 050806
			tabPageMainHold = tabControl.TabPages[0];
			tabPageAssessmentHold = tabControl.TabPages[1];
			if (m_component.MechStructDisciplines)
			{
				tabPageCostAllocationHold = tabControl.TabPages[2];
				tabPagePhotoHold = tabControl.TabPages[3];
			}
			else
			{
				tabPagePhotoHold = tabControl.TabPages[2];
			}

			SelectLOS();
			SelectCriticality();

			//mam 07072011
			SelectCip();

			//mam - removed Vulnerability combo box from form
			//SelectVulnerability();
			//</mam>

			m_suppressUpdates = false;

			UpdateCriticality();

			//mam
			textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_component.GetVulnerability().ToString());
			checkBoxOverrideVulnerability.Checked = m_component.OverrideVulnerability;
			if (checkBoxOverrideVulnerability.Checked)
			{
				textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_component.GetVulnerability().ToString());
			}
			m_suppressUpdates = true;
			UpdateVulnerability();
			UpdateRisk();
			m_suppressUpdates = false;

			SetVisibility();

			if (this.checkBoxOverrideVulnerability.Checked)
			{
				this.textBoxVulnerability.ReadOnly = false;
				this.buttonVulnerabilitySelect.Enabled = true;
				this.pictureBoxVulnerabilitySelect.Visible = true;

				//have to manually set the background color of the text box because
				//	the background color was set to 'Window' on the form, which is
				//	the default, but now the text box won't turn grey when it is read only
				textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
				textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;
			}
			else
			{
				this.textBoxVulnerability.ReadOnly = true;
				this.buttonVulnerabilitySelect.Enabled = false;
				this.pictureBoxVulnerabilitySelect.Visible = false;

				//have to manually set the background color of the text box because
				//	the background color was set to 'Window' on the form, which is
				//	the default, but now the text box won't turn grey when it is read only
				textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
				textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;
			}
			//</mam>

			//mam - disable controls if infoset is fixed
			//if (InfoSet.IsFixed)
			//{
				SetControls();
				DisableControls();
			//}
			//</mam>

			//mam 050806
			SetTabVisibility();

			//mam 01042012
			SetReadOnlyTextBoxBackgroundColorBulk();
		}

		//mam - make controls invisible for the Pipe discipline, rather than disabled,
		//	and visible for the Component node level
		private void SetVisibility()
		{
			bool isVisible = m_component.MechStructDisciplines;

			comboBoxLOS.Visible = isVisible;
			label6.Visible = isVisible;
			groupBoxCriticality.Visible = isVisible;

			//mam 07072011
			groupBoxVulnRisk.Visible = isVisible;
			groupBoxCip.Visible = isVisible;

			//comboBoxVulnerability.Visible = isVisible;
			label13.Visible = isVisible;
			textBoxRisk.Visible = isVisible;
			label14.Visible = isVisible;

			textBoxVulnerability.Visible = isVisible;
			textBoxVulnerabilityBackground.Visible = isVisible;
			//buttonVulnerabilitySelect.Visible = isVisible;
			pictureBoxVulnerabilitySelect.Visible = isVisible;
			checkBoxOverrideVulnerability.Visible = isVisible;

			//mam 050806
			labelRedundantAssetCount.Visible = isVisible;
			textBoxRedundantAssetCount.Visible = isVisible;

			//mam 07072011
			textBoxAssetClass.Visible = isVisible;
			comboBoxCip.Visible = isVisible;

			if (isVisible)
			{
				gridAssessment.Width = groupBoxCriticality.Left - 10;
				textBoxAssessmentComments.Width = groupBoxCriticality.Left - 10;
			}
			else
			{
				gridAssessment.Width = tabControl.Width - 16;
				textBoxAssessmentComments.Width = tabControl.Width - 16;
			}

			gridAssessment.SetVisibilityColumns(!isVisible);

			//mam - disable controls if infoset is fixed
			//if (InfoSet.IsFixed)
				DisableControls();
			//</mam>

			//mam 11142011 - don't use m_component.ComponentSelectedCriticalityFactorsCollection.Count
			//	in case factors are not selected for some crits - they won't be in that collection; 
			//	instead, use the actual count from Criticalities
			//mam 07072011
			//int critCount = m_component.ComponentSelectedCriticalityFactorsCollection.Count;
			int critCount = Common.CommonTasks.Criticalities.Count;
			int comboTop = ((critCount - 1) * 44) + 37;
			groupBoxCriticality.Height = comboTop + 57;
			labelCritTotal.Top = comboTop + 31;
			textBoxCritTotal.Top = comboTop + 29;
			groupBoxVulnRisk.Top = groupBoxCriticality.Bottom + 2;
			groupBoxCip.Left = groupBoxVulnRisk.Left;
			groupBoxCip.Top = groupBoxVulnRisk.Bottom + 3;
		}
		//</mam>

		private void		SelectLOS()
		{
			int				pos = 0;
			ListItem		item;

			comboBoxLOS.Enabled = m_component.MechStructDisciplines;

			for (pos = 0; pos < comboBoxLOS.Items.Count; pos++)
			{
				item = comboBoxLOS.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((LevelOfService)item.Value == m_component.LOS)
				{
					comboBoxLOS.SelectedIndex = pos;
					return;
				}
			}
		}

		//mam 07072011
		private void SelectCip()
		{
			if (!m_component.MechStructDisciplines)
			{
				return;
			}

			int pos = 0;
			ListItem item;

			comboBoxCip.Enabled = m_component.MechStructDisciplines;

			for (pos = 0; pos < comboBoxCip.Items.Count; pos++)
			{
				item = comboBoxCip.Items[pos] as ListItem;
				if (item == null)
					continue;

				if (((Common.CommonTasks.Cip)item.Value).CipPlanningId == m_component.CipPlanningId)
				{
					comboBoxCip.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectCriticality()
		{
			//mam 07072011 - use a different method to set combo box values
			//SelectCritPublicHealthAndSafety();
			//SelectCritEnvironmental();
			//SelectCritCostOfRepair();
			//SelectCritEffectOnCustomers();

			//mam 07072011 - all code below is new to this method

			if (!m_component.MechStructDisciplines)
			{
				return;
			}

			if (m_component.ComponentSelectedCriticalityFactorsCollection.Count == 0)
			{
				//something went wrong when writing the criticalities to the database
				//this shouldn't ever happen, but let's pretend it might, and we'll create the crits here
				m_component.InsertCriticalityValuesAllDefault();
			}

			ListItem item;
			int critId = 0;
			Common.MajorComponentSelectedCriticalityFactors selCritFactor = new Common.MajorComponentSelectedCriticalityFactors();
			if (comboBoxCriticality1.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality1.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality1.Items.Count; i++)
					{
						item = comboBoxCriticality1.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality1.SelectedIndex = i;
							break;
						}
					}
				}
			}

			if (comboBoxCriticality2.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality2.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality2.Items.Count; i++)
					{
						item = comboBoxCriticality2.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality2.SelectedIndex = i;
							break;
						}
					}
				}
			}

			if (comboBoxCriticality3.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality3.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality3.Items.Count; i++)
					{
						item = comboBoxCriticality3.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality3.SelectedIndex = i;
							break;
						}
					}
				}
			}

			if (comboBoxCriticality4.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality4.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality4.Items.Count; i++)
					{
						item = comboBoxCriticality4.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality4.SelectedIndex = i;
							break;
						}
					}
				}
			}

			if (comboBoxCriticality5.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality5.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality5.Items.Count; i++)
					{
						item = comboBoxCriticality5.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality5.SelectedIndex = i;
							break;
						}
					}
				}
			}

			if (comboBoxCriticality6.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality6.Tag).CriticalityId;
				selCritFactor = m_component.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				if (selCritFactor != null)
				{
					for (int i = 0; i < comboBoxCriticality6.Items.Count; i++)
					{
						item = comboBoxCriticality6.Items[i] as ListItem;
						if (item == null)
							continue;

						if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
						{
							comboBoxCriticality6.SelectedIndex = i;
							break;
						}
					}
				}
			}
		}

		//mam 07072011 - no longer using this method
//		private void		SelectCritPublicHealthAndSafety()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			comboBoxCritHealth.Enabled = m_component.MechStructDisciplines;
//
//			for (pos = 0; pos < comboBoxCritHealth.Items.Count; pos++)
//			{
//				item = comboBoxCritHealth.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityPublicHealth)item.Value == m_component.CritPublicHealth)
//				{
//					comboBoxCritHealth.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using this method
//		private void		SelectCritEnvironmental()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			comboBoxCritEnv.Enabled = m_component.MechStructDisciplines;
//
//			for (pos = 0; pos < comboBoxCritEnv.Items.Count; pos++)
//			{
//				item = comboBoxCritEnv.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityEnvironmental)item.Value == m_component.CritEnvironmental)
//				{
//					comboBoxCritEnv.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using this method
//		private void		SelectCritCostOfRepair()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			comboBoxCritRepairCost.Enabled = m_component.MechStructDisciplines;
//
//			for (pos = 0; pos < comboBoxCritRepairCost.Items.Count; pos++)
//			{
//				item = comboBoxCritRepairCost.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityRepairCost)item.Value == m_component.CritRepair)
//				{
//					comboBoxCritRepairCost.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using this method
//		private void		SelectCritEffectOnCustomers()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			comboBoxCritCustEffect.Enabled = m_component.MechStructDisciplines;
//
//			for (pos = 0; pos < comboBoxCritCustEffect.Items.Count; pos++)
//			{
//				item = comboBoxCritCustEffect.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityCustomerEffect)item.Value == m_component.CritCustEffect)
//				{
//					comboBoxCritCustEffect.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		private void		UpdateCriticality()
		{
			if (m_component == null)
				return;

			textBoxCritTotal.Text = m_component.GetOverallCriticality().ToString();

			UpdateRisk();
		}

		//mam - adjusted this method to account for N/A
		private void		UpdateRisk()
		{
			//if (m_component.OverrideVulnerability)
			//	return;

			if (m_component.GetEvaluatedRemainingUsefulLife() == 0  && !m_component.OverrideVulnerability)
				textBoxRisk.Text = "N/A";
			else
				textBoxRisk.Text = string.Format("{0:F2}", m_component.GetRisk());
		}

		private void textBoxComponentName_Leave(object sender, System.EventArgs e)
		{
			if (m_component != null && textBoxComponentName.Text.Length > 0)
			{
				if (string.Compare(m_component.Name, textBoxComponentName.Text) != 0)
				{
					// Update the name
					m_component.Name = textBoxComponentName.Text;

					//mam 03202012 - call SaveData instead of .Save() so we can show an error message if necessary
					//m_component.Save();
					SaveData();
				}
			}
		}

		//</mam>

		//mam
		private void		UpdateVulnerability()
		{
			if (m_component.OverrideVulnerability)
			{
//				//mam - the text box is not being populated correctly
//				textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_component.GetVulnerability().ToString());
//				SetReadOnlyProps(false);
//				//return;
			}
			else
			{
				if (m_component.GetEvaluatedRemainingUsefulLife() == 0)
				{
					textBoxVulnerability.Text = "N/A";
					m_component.Vulnerability = 0.0;
				}
				else
				{
					textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_component.GetVulnerability().ToString());
				}
				SetReadOnlyProps(true);
			}
			UpdateRisk();
		}
		//</mam>

//		//mam
//		private void UpdateVulnerabilityText()
//		{
//			if (m_component.GetEvaluatedRemainingUsefulLife() == 0  && !m_component.OverrideVulnerability)
//			{
//				this.textBoxVulnerability.Text = "N/A";
//				m_component.Vulnerability = 0.0;
//				SetReadOnlyProps(true);
//			}
//			else
//			{
//				string tempString = Convert.ToString(m_component.GetVulnerability());
//				this.textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(tempString);
//				m_component.Vulnerability = Convert.ToDouble("0." + textBoxVulnerability.Text);
//				SetReadOnlyProps(false);
//			}
//
//			UpdateRisk();
//		}
//		//</mam>

		private void textBoxComments_Leave(object sender, System.EventArgs e)
		{
			if (m_component == null)
				return;

			bool			changed = false;

			if (sender is TextBox)
			{
				if (((TextBox)sender).Text != m_component.Comments)
				{
					m_component.Comments = ((TextBox)sender).Text;
					changed = true;
				}
			}

			if (changed)
			{
				//mam 03202012 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_component.Save();
				SaveData();

				// Update all of the comments fields that are NOT 
				// the comments field that sent the notification
				if (!object.ReferenceEquals(sender, textBoxComments))
					textBoxComments.Text = m_component.Comments;
				if (!object.ReferenceEquals(sender, textBoxAllocComments))
					textBoxAllocComments.Text = m_component.Comments;
				if (!object.ReferenceEquals(sender, textBoxAssessmentComments))
					textBoxAssessmentComments.Text = m_component.Comments;
			}
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_component != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption.Text = m_component.CaptionPhoto;

					//mam 03202012
					string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_component.InfoSetID);

					//mam 03202012

					textBoxPhotoFileName.Text = m_component.PhotoFileName == "" ? m_component.PhotoFileName : targetPath + "\\" + m_component.PhotoFileName;

					pictureBox.Image = m_component.GetPhoto();
					if (pictureBox.Image == null)
						buttonBrowsePhoto.Text = "Browse";
					else
						buttonBrowsePhoto.Text = "Delete";
				}
				else
				{
					textBoxPhotoCaption.Text = "";

					//mam 03202012
					textBoxPhotoFileName.Text = "";

					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";
				}
			}

			//mam - add other tab selections to update data after grid edits
			else if (tabControl.SelectedTab == tabPageMain)
				componentGrid1.SetRootObject(m_component);
			else if (tabControl.SelectedTab == tabPageCostAllocation)
				gridAllocation.SetRootObject(m_component);
			else if (tabControl.SelectedTab == tabPageAssessment)
				gridAssessment.SetRootObject(m_component);
			//</mam>
		}

		//mam 01222012
		private void textBox_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)13)
			{
				e.Handled = true;
				this.ActiveControl = label3;
			}
		}

		private void buttonBrowsePhoto_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to update photo data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam 03202012 - this entire method was reworked, and all old code was deleted

			string targetPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_component.InfoSetID);

			/*
			fileNameWithoutPath			original file name without path; this may be modified in the save routine (to get a distinct file name)
			sourceFileWithPath			source path + original file name
			selectedFileNameWithPath	target path + final file name		no longer used
			targetPathWithFileName		target + 
			*/

			if (pictureBox.Image == null)
			{
				//put an image into the picture box

				//******************

				//make sure photo path exists

				//mam 102309 - get the infoset image path - if the string is "", the path does not exist in the WAM.xml file
				//	the user must set the path Edit > WAM Image Folder
				//string infoSetPhotoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_component.InfoSetID);
				string msg = "";
				if (targetPath == "")
				{
					//mam 03222012 - revised message
					//msg = "Please set the base images folder in the <PhotoPaths><BaseImagePath> section of the WAM.xml file before selecting a photo.";
					msg = "Please select the image folder location by clicking Edit > WAM Image Folder in the menu.";
					MessageBox.Show(this, msg, "Set Image Folder Path", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				//mam 07072011 - check for the existence of infoSetPhotoPath and let the user know if it doesn't exist
				if (!Common.CommonTasks.DoesImagesFolderExist(targetPath))
				{
					return;
				}

				//******************

				//show the open file dialog so the user can select a photo to display in this component

				string fileNameWithoutPath = "";
				OpenFileDialog fileDialog = WAM.Common.CommonTasks.GetPhotoOpenDialog();

				if (fileDialog.ShowDialog(this) == DialogResult.OK)
				{
					//the user has selected a photo

					//******************

					//save the file to the infoset images folder

					Image image = null;
					bool sourcePathSameAsDestinationPath = false;
					string sourceFileWithPath = fileDialog.FileName;

					if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
					{
						//let WAM create the name the photo file using the IDs of the facility, process and component, and the discipline type
						string targetPathIdStyle = m_component.GetImagePathIdStyle();
						fileNameWithoutPath = System.IO.Path.GetFileName(targetPathIdStyle);
						if (WAM.Common.CommonTasks.CopyImageFile(sourceFileWithPath, targetPathIdStyle))
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(targetPathIdStyle, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
					}
					else
					{
						//if the user has selected a file that is already in the infoset image path, don't copy that file and rename it, 
						//	just add the file name to the database for this component
						fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
						sourcePathSameAsDestinationPath = string.Compare(System.IO.Path.GetDirectoryName(sourceFileWithPath), targetPath) == 0;
						if (sourcePathSameAsDestinationPath)
						{
							using (System.IO.FileStream fileStream = new System.IO.FileStream(sourceFileWithPath, System.IO.FileMode.Open))
							{
								image = Image.FromStream(fileStream);
								fileStream.Close();
							}
						}
						else
						{
							//copy the file from the source folder to the infoset image folder

							//fileNameWithoutPath = System.IO.Path.GetFileName(sourceFileWithPath);
							if (!WAM.UI.PhotoFileSave.ShowForm(sourceFileWithPath, targetPath, ref fileNameWithoutPath, ref image))
							{
								//if the user cancels the save, return
								return;
							}
						}
					}

					//try to put the image into the picture box - if it fails, delete the photo file from the infoset images folder
					//	(as long as it is not being used by any other asset)

					try
					{
						pictureBox.Image = image;

						if (pictureBox.Image == null)
						{
							//the image was not inserted into the picturebox; remove the file that was copied into the images folder

							try
							{
								//mam 3202012 - don't delete the image if it is used by another asset
								//sourcePathSameAsDestinationPath = true indicates that the image was already in the infoset image folder, 
								//	which should mean that it is used by another asset
								if (!sourcePathSameAsDestinationPath)
								{
									System.IO.File.Delete(targetPath + "\\" + fileNameWithoutPath);
								}
							}
							catch
							{
							}

							//mam 03202012 - change this message to say that the image cannot be displayed
							//MessageBox.Show(this, "The file is not a valid image file or the Infoset image folder cannot be found.", "Photo File", 
							//	MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							MessageBox.Show(this, "The image cannot be displayed.  The image may not be a valid image file.", "Photo File", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						else
						{
							//the image was successfully inserted into the picture box, so save the data

							string tempVal = m_component.CaptionPhoto;
							string tempVal2 = m_component.PhotoFileName;

							//string selectedFileNameWithPath = targetPath + "\\" + fileNameWithoutPath;
							//m_component.CaptionPhoto = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, false);
							//m_component.PhotoFileName = Drive.IO.Directory.GetFileNameFromPath(selectedFileNameWithPath, true);
							if (WAM.Common.Globals.AllowWamToCreatePhotoFileNames)
							{
								m_component.CaptionPhoto = System.IO.Path.GetFileNameWithoutExtension(sourceFileWithPath);
								m_component.PhotoFileName = fileNameWithoutPath;
							}
							else
							{
								m_component.CaptionPhoto = System.IO.Path.GetFileNameWithoutExtension(fileNameWithoutPath);
								m_component.PhotoFileName = fileNameWithoutPath;
							}

							if (!SaveData())
							{
								//the save failed, so set the caption and file name back to their original values
								m_component.CaptionPhoto = tempVal;
								m_component.PhotoFileName = tempVal2;
							}

							textBoxPhotoCaption.Text = m_component.CaptionPhoto;
							textBoxPhotoFileName.Text = targetPath + "\\" + m_component.PhotoFileName;

							buttonBrowsePhoto.Text = "Delete";
						}
					}
					catch(Exception ex)
					{
						MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			else
			{
				//remove the photo from the component

				//mam 03202012
				//string		targetPath = m_component.GetImagePath();
				string targetPathWithFileName = targetPath + "\\" + m_component.PhotoFileName;

				//mam 07072011 - store pre-saved value in case save doesn't work
				string tempVal = m_component.CaptionPhoto;
				string tempVal2 = m_component.PhotoFileName;

				m_component.CaptionPhoto = "";
				m_component.PhotoFileName = "";
				
				//******************

				//if the save is successful, remove the photo file from the infoset images folder
				//	(as long as it is not used by any other asset)

				if (SaveData())
				{
					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";

					//mam 03202012 - if the file is being used by other assets, don't delete it
					//if IsImageFileUsedByOtherAssets returns -1, an error has occurred while checking the data in the database,
					//	so we don't know whether the file is used by another asset - don't delete the file
					bool fileInUse = Common.CommonTasks.GetPhotoCount(this.m_component.InfoSetID, tempVal2) > 0;

					//mam 03202012 - added check for fileInUse - don't delete file if file is used by other assets
					if (!fileInUse)
					{
						try
						{
							//set the file to be not read only, just in case the user has pulled a fast one and
							//	has copied a read-only image into the images folder
							if (System.IO.File.Exists(targetPathWithFileName))
							{
								System.IO.File.SetAttributes(targetPathWithFileName, System.IO.FileAttributes.Normal);
								System.IO.File.Delete(targetPathWithFileName);
							}
						}
						catch(Exception ex)
						{
							MessageBox.Show(this, "Error.  " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
				}
				else
				{
					//the save was not successful - set the caption and file name to their original values

					m_component.CaptionPhoto = tempVal;
					m_component.PhotoFileName = tempVal2;
				}

				textBoxPhotoCaption.Text = m_component.CaptionPhoto;
				textBoxPhotoFileName.Text = m_component.PhotoFileName == "" ? m_component.PhotoFileName : targetPath + "\\" + m_component.PhotoFileName;
			}
		}

		private void textBoxPhotoCaption_Leave(object sender, System.EventArgs e)
		{
			if (m_component.CaptionPhoto != textBoxPhotoCaption.Text)
			{
				m_component.CaptionPhoto = textBoxPhotoCaption.Text;

				//mam 03202012 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_component.Save();
				SaveData();
			}
		}

		private void OnChangeCriticality(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			//mam 07072011 - no longer using these criticality combo boxes
//			// Update public health
//			CriticalityPublicHealth	health = (CriticalityPublicHealth)
//				((ListItem)comboBoxCritHealth.SelectedItem).Value;
//			m_component.CritPublicHealth = health;
//
//			// Update environmental
//			CriticalityEnvironmental env = (CriticalityEnvironmental)
//				((ListItem)comboBoxCritEnv.SelectedItem).Value;
//			m_component.CritEnvironmental = env;
//
//			// Update cost of Repairs
//			CriticalityRepairCost repair = (CriticalityRepairCost)
//				((ListItem)comboBoxCritRepairCost.SelectedItem).Value;
//			m_component.CritRepair = repair;
//
//			// Update Effect on Customers
//			CriticalityCustomerEffect custEffect = (CriticalityCustomerEffect)
//				((ListItem)comboBoxCritCustEffect.SelectedItem).Value;
//			m_component.CritCustEffect = custEffect;

			//mam 07072011 - new way to set crit values in component based on changes in combo box
			ComboBox curComboBox = (ComboBox)sender;
			ListItem listItem = (ListItem)curComboBox.SelectedItem;
			Common.Criticality curCrit = (Common.Criticality)curComboBox.Tag;
			Common.CriticalityFactor curCritFactor = (Common.CriticalityFactor)listItem.Value;
			//string comboBoxName = curComboBox.Name;
			//get the last character of the combo box name
			//int comboBoxNumber = int.Parse(comboBoxName.Substring(comboBoxName.Length - 1, 1));

			for (int i = 0; i < m_component.ComponentSelectedCriticalityFactorsCollection.Count; i++)
			{
				//if (curCritFactor.ScoreId == m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.ScoreId)
				if (curCrit.CriticalityId == m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CriticalityId)
				{
					m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorId = curCritFactor.FactorId;
					m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorName = curCritFactor.FactorName;
					m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorOrderBy = curCritFactor.FactorOrderBy;
					m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.ScoreId = curCritFactor.ScoreId;
					m_component.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.Score = curCritFactor.Score;

					break;
				}
			}

			// Save the component

			//mam 07072011 - don't save data for the entire major component - just save the specific criticality value
			//m_component.Save();
			m_component.SaveCriticalityValue(curCrit.CriticalityId, curCritFactor.ScoreId);
			UpdateCriticality();
		}

//		//mam 07072011
//		private string CreateCipChangeMessage()
//		{
//			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, m_component.ID);
//
//					//cip mode is set to replacement
//
//					//set some of the rehab values in the cache to zero	
//					//(rehab cost and last rehab year will always remain editable and their values will never be set automatically)
//					foreach (Discipline disc in disciplines)
//					{
//						//disc.RehabCost = 0;
//						//disc.CurrentValue = disc.GetCurrentValue();
//						disc.RehabInterval = 0m;
//						disc.RehabNext = 0m;
//						disc.RehabYearNext = 0;
//
//		}

		//mam 07072011
		private bool changing = false;
		private void OnChangeCipPlanning(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			if (changing)
			{
				changing = false;
				return;
			}

			//get cips to get the name of each one
			Common.CommonTasks.Cip cip;

			//if the user selected the cip that is already selected, get out
			cip = (Common.CommonTasks.Cip)((ListItem)comboBoxCip.SelectedItem).Value;
			if (m_component.CipPlanningId == cip.CipPlanningId)
			{
				return;
			}

			string curCipName = string.Empty;
			string newCipName = string.Empty;
			//this assumes that there are only two cip choices
			for (int i = 0; i < comboBoxCip.Items.Count; i++)
			{
				cip = (Common.CommonTasks.Cip)((ListItem)comboBoxCip.Items[i]).Value;
				if (cip.CipPlanningId == m_component.CipPlanningId)
				{
					curCipName = cip.CipPlanningText;
				}
				else
				{
					newCipName = cip.CipPlanningText;
				}
			}
			
			//alert the user to the consequences of changing the planning mode
			string msg = string.Empty;

			//mam 01222012 - new message
			msg = "Changing the Planning Mode to " + newCipName + " will:"
				+ Environment.NewLine + Environment.NewLine + "1.  Set the " + curCipName + " timing values to zero."

				//+ Environment.NewLine + Environment.NewLine + "The " + curCipName + " timing values will be restored to their current"
				//+ " values if the Planning Mode is set back to " + curCipName + "."
				+ Environment.NewLine + Environment.NewLine + "Note:  If the Planning Mode is set back to " + curCipName + ", the " + curCipName 
				+ " timing values will be restored to their current values."

				+ Environment.NewLine + "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"

				//+ Environment.NewLine + Environment.NewLine + "2.  Set the " + newCipName + " timing values to their default, calculated, or user-entered values."
				+ Environment.NewLine + Environment.NewLine + "2.  Set the " + newCipName + " timing values to their default, calculated, or"
				+ " previously user-entered values. (The user should confirm these values if this change is made.)"

				//+ Environment.NewLine + Environment.NewLine + "Note:  Next " + newCipName + " Years that are less than Facility Current Year"
				//+ " will be set equal to Facility Current Year."
				+ Environment.NewLine + Environment.NewLine + "Note:  If Next " + newCipName + " Year is less than Facility Current Year"
				+ " it will be set equal to Facility Current Year."

				+ Environment.NewLine + "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"

				+ Environment.NewLine + Environment.NewLine + "Refer to the help menu or equation viewer for further detail."

				+ Environment.NewLine + Environment.NewLine + "Would you like to continue?";

			DialogResult dialogResult = MessageBox.Show(this, msg, "Planning Mode Change", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			if (dialogResult == DialogResult.No)
			{
				//the user has decided not to change the planning mode
				changing = true;

				//set the combo box back to what it was
				SelectCip();

				return;
			}

			//the user is going ahead with the change to planning mode

			//mam 01222012
			try
			{
				MajorComponent.UpdateOverriddenYearsByComponent(m_component.ID);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			cip = (Common.CommonTasks.Cip)((ListItem)comboBoxCip.SelectedItem).Value;
			m_component.CipPlanningId = cip.CipPlanningId;
			m_component.Save();

			//set the rehab interval, rehab next, and rehab year next values to zero for this mech/struct/land component's disciplines,
			//but don't update the database - this will alow the rehab values to be resurrected if cip is changed to Rehabilitation
			if (m_component.MechStructDisciplines)
			{
				Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, m_component.ID);

				if (m_component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is set to replacement

					//set some of the rehab values in the cache to zero	
					//(rehab cost and last rehab year will always remain editable and their values will never be set automatically)
					//	-is this still true? - yes it is
					foreach (Discipline disc in disciplines)
					{
						//disc.RehabCost = 0;
						//disc.CurrentValue = disc.GetCurrentValue();
						disc.RehabInterval = 0m;
						disc.RehabNext = 0m;
						disc.RehabYearNext = 0;
						disc.ComponentCipId = m_component.CipPlanningId;
						//if (!disc.OverrideNextReplacementYear)
						//{
						//	disc.NextReplacementYear = disc.NextReplacementYear;
						//}
					}

					DataTable dataTable;
					try
					{
						dataTable = Common.CommonTasks.GetRehabCostByComponent(m_component.ID);
					}
					catch(Exception ex)
					{
						Common.CommonTasks.ShowErrorMessage("Changing Planning Mode", ex.Message);
						return;
					}

					//resurrect the rehab costs from the database and put them in the cache
					foreach (Discipline disc in disciplines)
					{
						//disc.RehabCost = Convert.ToDecimal(sortedList[disc.ID]);
						//disc.CurrentValue = disc.GetCurrentValue();
						foreach (DataRow dataRow in dataTable.Rows)
						{
							if (Convert.ToInt32(dataRow["disc_id"]) == disc.ID)
							{
								disc.NextReplacementYear = dataRow["NextReplacementYear"] == DBNull.Value ? disc.NextReplacementYear : Convert.ToInt32(dataRow["NextReplacementYear"]);
								disc.ComponentCipId = m_component.CipPlanningId;
							}
						}
					}
				}
				else
				{
					//cip mode is set to rehabilitation

					//mam 01222012
					//set next replacement year in the cache to zero
					foreach (Discipline disc in disciplines)
					{
						disc.NextReplacementYear = 0;
						disc.ComponentCipId = m_component.CipPlanningId;
					}

					//SortedList sortedList = Common.CommonTasks.GetRehabCostByComponent(m_component.ID);
					DataTable dataTable;
					try
					{
						dataTable = Common.CommonTasks.GetRehabCostByComponent(m_component.ID);
					}
					catch(Exception ex)
					{
						Common.CommonTasks.ShowErrorMessage("Changing Planning Mode", ex.Message);
						return;
					}

					//resurrect the rehab costs from the database and put them in the cache
					foreach (Discipline disc in disciplines)
					{
						//disc.RehabCost = Convert.ToDecimal(sortedList[disc.ID]);
						//disc.CurrentValue = disc.GetCurrentValue();
						foreach (DataRow dataRow in dataTable.Rows)
						{
							if (Convert.ToInt32(dataRow["disc_id"]) == disc.ID)
							{
								disc.RehabInterval = Convert.ToDecimal(dataRow["RehabInterval"]);
								disc.RehabNext = dataRow["RehabNext"] == DBNull.Value ? disc.RehabNext : Convert.ToDecimal(dataRow["RehabNext"]);

								//mam 01222012
								//disc.RehabYearNext = disc.RehabYearNext;
								disc.RehabYearNext = dataRow["RehabYearNext"] == DBNull.Value ? disc.RehabYearNext : Convert.ToInt32(dataRow["RehabYearNext"]);

								disc.ComponentCipId = m_component.CipPlanningId;
							}
						}
						
						//if (!disc.OverrideNextReplacementYear)
						//{
						//	disc.NextReplacementYear = 0;
						//}
					}
				}

				gridAssessment.SetRootObject(m_component);
			}
		}

		private void OnChangeLOS(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			LevelOfService	los = (LevelOfService)((ListItem)comboBoxLOS.SelectedItem).Value;
			m_component.LOS = los;
			m_component.Save();

			// Refresh the grid (some display items change based on LOS)
			componentGrid1.SetRootObject(m_component);
		}

		private void checkBoxRetired_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			m_component.Retired = checkBoxRetired.Checked;
			m_component.Save();
			System.Text.StringBuilder builder = new System.Text.StringBuilder();

			//mam 050806 - change message because data in "Cost Allocation by %" tab is no longer used in calculations
			builder.AppendFormat("This component will now be ");
			//builder.Append("The Cost Weighted Percentage of Asset Value on the ");
			//builder.Append("Cost Allocation by % Tab of the Process Screen will ");
			//builder.Append("need to be adjusted so that the total ");
			//builder.Append("Cost Weighted Percentage equals 100, because this ");
			//builder.Append("component will now be ");
			
			if (m_component.Retired)
				builder.Append("excluded from ");
			else
				builder.Append("included in ");
			builder.Append("all calculations.");

			MessageBox.Show(this, builder.ToString(), "Retired Warning", 
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		//mam
		public int TabControlIndex
		{
			get {return tabControl.SelectedIndex;}
			set {tabControl.SelectedIndex = value;}
		}
		//</mam>

		//mam
		private void textBoxVulnerability_TextChanged(object sender, System.EventArgs e)
		{
			if (m_suppressUpdates)
				return;

			//******************************
			bool changedText = false;
			//string currentText = this.Text;
			string currentText = textBoxVulnerability.Text;
			string correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (allowedChar.IndexOf(currentText.Substring(i, 1)) == -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				//this.Text = correctedText;
				textBoxVulnerability.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxVulnerability.SelectionStart = currentPos;
			}
			//******************************

			try    
			{
				m_component.Vulnerability = Convert.ToDouble("0." + textBoxVulnerability.Text);
			}
			catch (FormatException)    
			{
				m_component.Vulnerability = 0.0;
			}

			UpdateRisk();
		}
		//</mam>

		//mam
		private void textBoxVulnerability_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxVulnerability.SelectionStart;
			existingText = textBoxVulnerability.Text;

//			if (allowedChar.IndexOf(e.KeyChar) < 0)
//			{
//				e.Handled = true;
//			}
		}
		//</mam>

		//mam
		private void txtMessage(int selIndex)
		{
			selectedVulnerability = selIndex;
			//MessageBox.Show(selectedVulnerability.ToString());
		}

		private void SetReadOnlyProps(bool isReadOnly)
		{
			if (isReadOnly)
			{
				this.textBoxVulnerability.ReadOnly = true;
				this.buttonVulnerabilitySelect.Enabled = false;
				this.pictureBoxVulnerabilitySelect.Visible = false;
				this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
				this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;
				//this.textBoxVulnerability.Location = new System.Drawing.Point(493, 284);
				if (textBoxVulnerability.Text == "N/A")
				{
					this.textBoxVulnerability.Location = new System.Drawing.Point(
						(int)textBoxVulnerabilityBackground.Location.X + 3, (int)textBoxVulnerabilityBackground.Location.Y + 3);
				}
				else
				{
					this.textBoxVulnerability.Location = new System.Drawing.Point(
						(int)textBoxVulnerabilityBackground.Location.X + 12, (int)textBoxVulnerabilityBackground.Location.Y + 3);
				}
			}
			else
			{
				this.textBoxVulnerability.ReadOnly = false;
				this.buttonVulnerabilitySelect.Enabled = true;
				this.pictureBoxVulnerabilitySelect.Visible = true;
				this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
				this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;
				//this.textBoxVulnerability.Location = new System.Drawing.Point(502, 284);
				this.textBoxVulnerability.Location = new System.Drawing.Point(
					(int)textBoxVulnerabilityBackground.Location.X + 12, (int)textBoxVulnerabilityBackground.Location.Y + 3);
			}

			//mam - disable controls if infoset is fixed
			//if (InfoSet.IsFixed)
				DisableControls();
			//</mam>
		}

		//mam 12192011
		private void SetReadOnlyTextBoxBackgroundColor(TextBox sender)
		{
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				sender.BackColor = sender.ReadOnly ? WAM.Common.Globals.ReadOnlyBackgroundColorNumeric : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				if (sender.Name == this.textBoxVulnerability.Name)
				{
					textBoxVulnerabilityBackground.BackColor = sender.ReadOnly ? WAM.Common.Globals.ReadOnlyBackgroundColorNumeric : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				}
			}
			//mam 01222012
			else
			{
				sender.BackColor = sender.ReadOnly ? Color.FromKnownColor(System.Drawing.KnownColor.Control) : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				if (sender.Name == this.textBoxVulnerability.Name)
				{
					textBoxVulnerabilityBackground.BackColor = sender.ReadOnly ? Color.FromKnownColor(System.Drawing.KnownColor.Control) : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				}
			}
		}

		private void checkBoxOverrideVulnerability_CheckedChanged(object sender, System.EventArgs e)
		{
			m_component.OverrideVulnerability = checkBoxOverrideVulnerability.Checked;

			if (checkBoxOverrideVulnerability.Checked)
			{
				SetReadOnlyProps(false);

				if (textBoxVulnerability.Text == "N/A")
				{
					this.textBoxVulnerability.Text = "0";
					m_component.Vulnerability = 0.0;
				}

				this.textBoxVulnerability.Focus();
			}
			else
			{
				try
				{
					if (m_component.GetEvaluatedRemainingUsefulLife() == 0)
					{
						//System.Diagnostics.Debug.WriteLine(textBoxVulnerability.Visible.ToString());
						textBoxVulnerability.Text = "N/A";
						m_component.Vulnerability = 0.0;
					}
					else
					{
						//string tempString = Convert.ToString(Math.Round(1 / Convert.ToDouble(m_component.GetEvaluatedRemainingUsefulLife()), 4));
						UpdateVulnerability();
						//string tempString = Convert.ToString(m_component.GetVulnerability());
						//this.textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(tempString);
						//m_component.Vulnerability = Convert.ToDouble("0." + textBoxVulnerability.Text);
					}
				}
				catch
				{
					this.textBoxVulnerability.Text = "N/A";
					m_component.Vulnerability = 0.0;
				}

				m_suppressUpdates = true;
				UpdateVulnerability();
				//UpdateRisk();
				m_suppressUpdates = false;

				SetReadOnlyProps(true);
			}

			//m_suppressUpdates = true;
			//UpdateVulnerability();
			UpdateRisk();
			//m_suppressUpdates = false;

			//mam 12192011
			SetReadOnlyTextBoxBackgroundColor(textBoxVulnerability);
		}

		private void buttonVulnerabilitySelect_Click(object sender, System.EventArgs e)
		{
			selectedVulnerability = -1;
			PipeDetailVulnerability pipeDetailVulnerability = new PipeDetailVulnerability();
			pipeDetailVulnerability.OnMessage += new PipeDetailVulnerability.Message(this.txtMessage);
			pipeDetailVulnerability.ShowDialog();

			if (pipeDetailVulnerability.DialogResult == DialogResult.OK)
			{
				//if (m_suppressUpdates)
				//	return;

				checkBoxOverrideVulnerability.Checked = true;
				//textBoxVulnerability.Text = (EnumHandlers.GetVulnerabilityValue((Vulnerability)selectedVulnerability)).ToString();
				string tempString = (EnumHandlers.GetVulnerabilityValue((Vulnerability)selectedVulnerability)).ToString();
				textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(tempString);
			}
		}
		//</mam>

		private void textBoxVulnerabilityBackground_Enter(object sender, System.EventArgs e)
		{
			textBoxVulnerability.Focus();
		}

		private void textBoxVulnerability_Leave(object sender, System.EventArgs e)
		{
			//mam - added N/A condition
			if (textBoxVulnerability.Text == "N/A")
				return;
			//</mam>

			if (textBoxVulnerability.Text == "" || Double.Parse(textBoxVulnerability.Text) == 0)
				m_component.Vulnerability = 0.0;

			textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_component.GetVulnerability().ToString());
		}

		private void SetToolTips()
		{
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			toolTip.AutoPopDelay = 2500;
			toolTip.InitialDelay = 500;
			toolTip.ReshowDelay = 0;

			//toolTip.AutoPopDelay = 0;
			//toolTip.InitialDelay = 0;
			//toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.checkBoxOverrideVulnerability, "Override calculated Vulnerability");
			//toolTip.SetToolTip(this.buttonVulnerabilitySelect, "Select Vulnerability");
			toolTip.SetToolTip(this.pictureBoxVulnerabilitySelect, "Select Vulnerability");

			//mam 07072011
			toolTip.SetToolTip(labelAssetClassClose, "Close");
			toolTip.SetToolTip(pictureBoxAssetClass, "Show Asset Class values for other Components");
		}

		//</mam>

		//mam
		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)pictureBoxVulnerabilitySelect.Image;
			//b.MakeTransparent(System.Drawing.Color.FromArgb(239, 237, 222));
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxVulnerabilitySelect.Image = b;
			pictureBoxAssetClass.Image = b;
		}
		//</mam>

		//mam
		//mam 03202012 - changed to return a bool
		//public void SaveData()
		public bool SaveData()
		{
			try
			{
				//mam 03202012
				//m_component.Save();
				bool success = m_component.Save();
				if (!success)
				{
					//mam 03202012 - if the user doesn't have write permission, don't show the save error
					if (!WAM.Common.Globals.UserHasWritePermission)
					{
						return true;
					}

					Common.CommonTasks.ShowErrorMessage("MajorComponent.SaveData", "An error occurred while saving the Major Component data.");
					return false;
				}
			}
			catch(Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage(this.Name + ".SaveData", ex.Message);

				//mam 03202012
				return false;
			}

			//mam 0320212
			return true;
		}
		//</mam>

		//mam - disable controls if infoset is fixed
		private void DisableControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;
			this.comboBoxLOS.Enabled = !isFixedInfoset;

			//mam - comment these two lines because ReadOnly property is set elsewhere
			//this.textBoxVulnerability.ReadOnly = isFixedInfoset;
			//this.textBoxVulnerabilityBackground.ReadOnly = isFixedInfoset;

			this.pictureBoxVulnerabilitySelect.Visible = !isFixedInfoset;
			this.groupBoxCriticality.Enabled = !isFixedInfoset;

			//mam 07072011
			this.groupBoxVulnRisk.Enabled = !isFixedInfoset;

			this.checkBoxOverrideVulnerability.Enabled = !isFixedInfoset;

			if (!m_component.MechStructDisciplines)
				this.pictureBoxVulnerabilitySelect.Visible = false;

			if (isFixedInfoset)
			{
				this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
				this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;
			}
		}
		//</mam>

		//mam - disable controls if infoset is fixed
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;
			checkBoxRetired.Enabled = !isFixedInfoset;
			textBoxComponentName.ReadOnly = isFixedInfoset;
			textBoxComments.ReadOnly = isFixedInfoset;
			textBoxAssessmentComments.ReadOnly = isFixedInfoset;
			textBoxAllocComments.ReadOnly = isFixedInfoset;

			textBoxPhotoCaption.ReadOnly = isFixedInfoset;
			buttonBrowsePhoto.Enabled = !isFixedInfoset;

			panelLocked.Visible = isFixedInfoset;
		}
		//</mam>

		//mam
		public void ShowEquation(string eqn)
		{
			//((MainForm)parentForm).ShowEquation(eqn);
			((MainForm)MainForm.AppForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			//((MainForm)parentForm).PinEquation(eqn);
			((MainForm)MainForm.AppForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			//((MainForm)parentForm).ClearEquationTextBox();
			((MainForm)MainForm.AppForm).ClearEquationTextBox();
		}
		//</mam>

		//mam
		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandler(this);
			equationViewerHandler.AssignCursor(this);
			componentGrid1.SetEquationControls();
			gridAssessment.SetEquationControls();
		}
		//</mam>

		//mam 03202012 - this method is no longer being used
//		//mam 102309 - no longer deleting photos
//		//mam 102309 - yes, we are
//		//mam
//		public void DeletePhotos(int facilityID, int processID, int componentID, int infosetID)
//		{
//			if (m_component == null)
//				return;
//
//			string photoPath = m_component.GetImagePath(facilityID, processID, componentID, infosetID);
//
//			//delete photo file
//			try
//			{
//				if (System.IO.File.Exists(photoPath))
//					System.IO.File.Delete(photoPath);
//			}
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine("Error.  Component photo not deleted." + ex.Message.ToString());
//			}
//		}
//		//</mam>

		//mam - added code so that if user types into only one field, say the process name field,
		//	and then clicks on another process node in the tree, the process name will be saved
		private void textBoxComponentName_TextChanged(object sender, System.EventArgs e)
		{
			m_component.Name = textBoxComponentName.Text;
		}

		private void textBoxComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_component.Comments = textBoxComments.Text;
		}

		private void textBoxAssessmentComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_component.Comments = textBoxAssessmentComments.Text;
		}

		private void textBoxAllocComments_TextChanged(object sender, System.EventArgs e)
		{
			//m_component.Comments = textBoxAllocComments.Text;
		}

		private void textBoxPhotoCaption_TextChanged(object sender, System.EventArgs e)
		{
			m_component.CaptionPhoto = textBoxPhotoCaption.Text;
		}
		//</mam>

		//mam 050806
		public void SetTabVisibility()
		{
			try
			{
				//note the currently selected tab
				tabPageSelectedName = tabControl.TabPages[tabControl.SelectedIndex].Name;

				//remove all tabs from the tab control
				tabControl.TabPages.Clear();

				//add tabs back to the tab control
				tabControl.TabPages.Add(tabPageMainHold);
				tabControl.TabPages.Add(tabPageAssessmentHold);

				//show the Cost Allocation tab, if necessary
				if (WAM.Common.Globals.ShowCostTab && m_component.MechStructDisciplines)
				{
					tabControl.TabPages.Add(tabPageCostAllocationHold);
				}

				tabControl.TabPages.Add(tabPagePhotoHold);
			
				//restore the tab selection
				for (int i = 0; i < tabControl.TabPages.Count; i++)
				{
					if (tabControl.TabPages[i].Name.Equals(tabPageSelectedName))
					{
						tabControl.SelectedIndex = i;
						break;
					}
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
			}
		}

		//mam 050806
		private void textBoxRedundantAssetCount_Leave(object sender, System.EventArgs e)
		{
			int newValue = 1;
			try
			{
				newValue = Int32.Parse(textBoxRedundantAssetCount.Text, System.Globalization.NumberStyles.Integer);
			}
			catch
			{
			}

			if (newValue < 1)
			{
				newValue = 1;
			}

			textBoxRedundantAssetCount.Text = newValue.ToString("0");
			m_component.RedundantAssetCount = newValue;

			//mam 03202012 - call SaveData instead of .Save() so we can show an error message if necessary
			//m_component.Save();
			SaveData();

			UpdateCriticality();
		}

		//mam 050806
		private void textBoxAssetClass_Leave(object sender, System.EventArgs e)
		{
			if (m_component.AssetClass != textBoxAssetClass.Text)
			{
				m_component.AssetClass = textBoxAssetClass.Text;

				//mam 03202012 - call SaveData instead of .Save() so we can show an error message if necessary
				//m_component.Save();
				SaveData();
			}
		}

		//mam 07072011
		private void labelAssetClassClose_Click(object sender, System.EventArgs e)
		{
			//panelAssetClass.Visible = false;
			panelAssetClassContainer.Visible = false;
		}

		//mam 07072011
		private void listBoxAssetClass_DoubleClick(object sender, System.EventArgs e)
		{
			DataRowView dr = listBoxAssetClass.Items[listBoxAssetClass.SelectedIndex] as DataRowView;
			if (dr != null && dr["AssetClass"] != null)
			{
				textBoxAssetClass.Text = dr["AssetClass"].ToString();
			}

			if (m_component.AssetClass != textBoxAssetClass.Text)
			{
				m_component.AssetClass = textBoxAssetClass.Text;
				m_component.Save();
			}

			panelAssetClassContainer.Visible = false;
		}

		private void pictureBoxAssetClass_Click(object sender, System.EventArgs e)
		{
			panelAssetClassContainer.Location = new System.Drawing.Point(
				(int)groupBoxCip.Location.X + 2, (int)groupBoxCip.Location.Y - panelAssetClassContainer.Height + 40);
			panelAssetClassContainer.BringToFront();
			panelAssetClassContainer.Visible = !panelAssetClassContainer.Visible;
		}
	}
}
