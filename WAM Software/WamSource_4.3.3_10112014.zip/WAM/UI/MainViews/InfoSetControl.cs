using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Text;
using WAM.Data;

namespace WAM.UI.MainViews
{
	/// <summary>
	/// Summary description for InfoSetControl.
	/// </summary>
	public class InfoSetControl : System.Windows.Forms.UserControl
	{
		private InfoSet		m_infoSet = null;

		private System.Windows.Forms.Label labelInfoSet;
		private System.Windows.Forms.Button buttonAddFacility;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxDatabaseFolder;
		private System.Windows.Forms.TextBox textBoxImagesFolder;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private System.Windows.Forms.Button buttonImageFolderPath;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public InfoSetControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(InfoSetControl));
			this.labelInfoSet = new System.Windows.Forms.Label();
			this.buttonAddFacility = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.labelLocked = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxDatabaseFolder = new System.Windows.Forms.TextBox();
			this.textBoxImagesFolder = new System.Windows.Forms.TextBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.buttonImageFolderPath = new System.Windows.Forms.Button();
			this.panelLocked.SuspendLayout();
			this.SuspendLayout();
			// 
			// labelInfoSet
			// 
			this.labelInfoSet.BackColor = System.Drawing.Color.Transparent;
			this.labelInfoSet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelInfoSet.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelInfoSet.Location = new System.Drawing.Point(13, 18);
			this.labelInfoSet.Name = "labelInfoSet";
			this.labelInfoSet.Size = new System.Drawing.Size(423, 166);
			this.labelInfoSet.TabIndex = 0;
			// 
			// buttonAddFacility
			// 
			this.buttonAddFacility.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddFacility.Location = new System.Drawing.Point(280, 160);
			this.buttonAddFacility.Name = "buttonAddFacility";
			this.buttonAddFacility.Size = new System.Drawing.Size(147, 23);
			this.buttonAddFacility.TabIndex = 1;
			this.buttonAddFacility.Text = "Add Facility / System";
			this.buttonAddFacility.Visible = false;
			this.buttonAddFacility.Click += new System.EventHandler(this.buttonAddFacility_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(4, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(440, 200);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.labelLocked);
			this.panelLocked.Location = new System.Drawing.Point(115, 170);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 19;
			this.panelLocked.Visible = false;
			// 
			// labelLocked
			// 
			this.labelLocked.BackColor = System.Drawing.Color.White;
			this.labelLocked.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelLocked.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.labelLocked.Location = new System.Drawing.Point(1, 1);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.Size = new System.Drawing.Size(213, 18);
			this.labelLocked.TabIndex = 16;
			this.labelLocked.Text = "All Data is Locked";
			this.labelLocked.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(145)), ((System.Byte)(185)));
			this.label1.Location = new System.Drawing.Point(18, 285);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(500, 18);
			this.label1.TabIndex = 22;
			this.label1.Text = "Database Location:";
			this.label1.Visible = false;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(145)), ((System.Byte)(185)));
			this.label2.Location = new System.Drawing.Point(18, 218);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(500, 18);
			this.label2.TabIndex = 23;
			this.label2.Text = "Image Folder Location:";
			// 
			// textBoxDatabaseFolder
			// 
			this.textBoxDatabaseFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxDatabaseFolder.AutoSize = false;
			this.textBoxDatabaseFolder.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxDatabaseFolder.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBoxDatabaseFolder.Location = new System.Drawing.Point(20, 305);
			this.textBoxDatabaseFolder.Multiline = true;
			this.textBoxDatabaseFolder.Name = "textBoxDatabaseFolder";
			this.textBoxDatabaseFolder.ReadOnly = true;
			this.textBoxDatabaseFolder.Size = new System.Drawing.Size(500, 36);
			this.textBoxDatabaseFolder.TabIndex = 24;
			this.textBoxDatabaseFolder.Text = "";
			this.textBoxDatabaseFolder.Visible = false;
			// 
			// textBoxImagesFolder
			// 
			this.textBoxImagesFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxImagesFolder.AutoSize = false;
			this.textBoxImagesFolder.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxImagesFolder.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBoxImagesFolder.Location = new System.Drawing.Point(20, 238);
			this.textBoxImagesFolder.Multiline = true;
			this.textBoxImagesFolder.Name = "textBoxImagesFolder";
			this.textBoxImagesFolder.ReadOnly = true;
			this.textBoxImagesFolder.Size = new System.Drawing.Size(500, 36);
			this.textBoxImagesFolder.TabIndex = 25;
			this.textBoxImagesFolder.Text = "";
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(376, 140);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 144;
			this.pictureBoxToolbarAdd.TabStop = false;
			this.pictureBoxToolbarAdd.Visible = false;
			// 
			// buttonImageFolderPath
			// 
			this.buttonImageFolderPath.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonImageFolderPath.Location = new System.Drawing.Point(20, 281);
			this.buttonImageFolderPath.Name = "buttonImageFolderPath";
			this.buttonImageFolderPath.TabIndex = 145;
			this.buttonImageFolderPath.Text = "Change...";
			this.buttonImageFolderPath.Visible = false;
			this.buttonImageFolderPath.Click += new System.EventHandler(this.buttonImageFolderPath_Click);
			// 
			// InfoSetControl
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.buttonImageFolderPath);
			this.Controls.Add(this.pictureBoxToolbarAdd);
			this.Controls.Add(this.textBoxImagesFolder);
			this.Controls.Add(this.textBoxDatabaseFolder);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.buttonAddFacility);
			this.Controls.Add(this.labelInfoSet);
			this.Controls.Add(this.groupBox1);
			this.helpProvider1.SetHelpKeyword(this, "InfoSet.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Name = "InfoSetControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(648, 436);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.InfoSetControl_Paint);
			this.panelLocked.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			buttonAddFacility.Visible = false;
			base.OnLoad(e);
		}

		public void			SetInfoSet(InfoSet infoSet)
		{
			m_infoSet = infoSet;
			UpdateScreen();
		}

		private void		UpdateScreen()
		{
			if (m_infoSet != null)
			{
				StringBuilder builder = new StringBuilder(150);
				
				builder.AppendFormat("You are currently working with the \"{0}\" Information Set. ", m_infoSet.Name);

				if (m_infoSet.GetFixed())
				{
					builder.Append("\r\n\r\nThis Information Set cannot be edited, but you may copy this data to a new, editable Information Set."); 
					builder.Append("\r\n\r\nTo make a copy of this Information Set, select\r\n\"InfoSet Management\" from the File menu.");
					panelLocked.Visible = true;
				}
				else
				{
					int facLength = CacheManager.GetFacilityCount(m_infoSet.ID);
					if (facLength == 0)
					{
						builder.Append("\r\n\r\nYou may add a Facility/System by selecting 'Add New Facility/System' from the Edit menu.");
					}
					else
					{
						builder.Append("\r\n\r\nYou may add a Facility/System, or select an item beneath the InfoSet to see its details.");
					}
					panelLocked.Visible = false;
				}

				labelInfoSet.Text = builder.ToString();

				//mam - make invisible
				//buttonAddFacility.Visible = true;
				//</mam>

				//-------------------------------
				//database path
				//mam 102309 - no longer using Access databases
//				string dbPath = string.Format("{0}", Drive.IO.Directory.GetApplicationPath());
//				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
//				string currentDB = commonTasks.GetCurrentDatabaseName(true);
//				if (currentDB == "")
//					textBoxDatabaseFolder.Text = dbPath;
//				else
//					textBoxDatabaseFolder.Text = dbPath + "\\" + currentDB;

				//-------------------------------

				//images path
				//InfoSet infoSet = new InfoSet(InfoSet.CurrentID);
				//string imagePath = m_infoSet.GetImagePath();

				//mam 102309 - get photo path from app settings
				//mam 102309 - no
				textBoxImagesFolder.Text = m_infoSet.GetImagePath();
				//string photoPath = Drive.Configuration.AppSettings.Settings.GetSetting("PhotoPaths", "Infoset" + m_infoSet.ID);
				//textBoxImagesFolder.Text = photoPath;
			}
			else
			{
				labelInfoSet.Text = "You do not have a data set selected. You will need to select a data set in order to continue.";
				buttonAddFacility.Visible = false;
			}
		}

		private void buttonAddFacility_Click(object sender, System.EventArgs e)
		{
			MainForm form = this.TopLevelControl as MainForm;

			if (form != null)
			{
				form.AddFacility(string.Empty, false);
			}
		}

		private void InfoSetControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		//mam 102309
		//mam 102309 - not using this - set image path in UI\SetImageBasePath form
		private void buttonImageFolderPath_Click(object sender, System.EventArgs e)
		{
//			System.Windows.Forms.FolderBrowserDialog folderDialog = new FolderBrowserDialog();
//			folderDialog.ShowNewFolderButton = true;
//			string curPath = textBoxImagesFolder.Text.Trim();
//			if (System.IO.Directory.Exists(curPath))
//			{
//				folderDialog.SelectedPath = curPath;
//			}
//			else
//			{
//				folderDialog.SelectedPath = Application.StartupPath;
//			}
//			if (folderDialog.ShowDialog(this) == DialogResult.OK)
//			{
//				string setPath = folderDialog.SelectedPath;
//				this.textBoxImagesFolder.Text = setPath;
//
//				WAM.Common.CommonTasks.SetInfosetImagePath(m_infoSet.ID, setPath);
//				//Drive.Configuration.AppSettings.Settings.SetSetting("PhotoPaths", "Infoset" + m_infoSet.ID, setPath);
//				//Drive.Configuration.AppSettings.Settings.Save();
//			}
		}
	}
}
