using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ENRDetailForm.
	/// </summary>
	public class ENRDetailForm : System.Windows.Forms.Form
	{
		private int			m_year = 0;
		private int			m_enrValue = 0;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private WAM.UI.NumberTextBox textBoxYear;
		private WAM.UI.NumberTextBox textBoxENRValue;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;

		//mam
		int currentPos = 0;
		bool changedText = false;
		string existingText = "";
		string allowedChar = "0123456789";
		string currentText = "";
		string correctedText = "";

		//</mam>

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ENRDetailForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ENRDetailForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxYear = new WAM.UI.NumberTextBox();
			this.textBoxENRValue = new WAM.UI.NumberTextBox();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(8, 10);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(44, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "&Year:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(124, 10);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(76, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "ENR &Value:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxYear
			// 
			this.textBoxYear.Location = new System.Drawing.Point(52, 8);
			this.textBoxYear.MaxLength = 4;
			this.textBoxYear.Name = "textBoxYear";
			this.textBoxYear.Size = new System.Drawing.Size(60, 20);
			this.textBoxYear.TabIndex = 1;
			this.textBoxYear.Text = "0";
			this.textBoxYear.Value = ((long)(0));
			this.textBoxYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxYear_KeyPress);
			this.textBoxYear.TextChanged += new System.EventHandler(this.textBoxYear_TextChanged);
			// 
			// textBoxENRValue
			// 
			this.textBoxENRValue.Location = new System.Drawing.Point(200, 8);
			this.textBoxENRValue.MaxLength = 9;
			this.textBoxENRValue.Name = "textBoxENRValue";
			this.textBoxENRValue.Size = new System.Drawing.Size(60, 20);
			this.textBoxENRValue.TabIndex = 3;
			this.textBoxENRValue.Text = "0";
			this.textBoxENRValue.Value = ((long)(0));
			this.textBoxENRValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxENRValue_KeyPress);
			this.textBoxENRValue.TextChanged += new System.EventHandler(this.textBoxENRValue_TextChanged);
			// 
			// buttonSave
			// 
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(104, 51);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 4;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(189, 51);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 5;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// ENRDetailForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(270, 80);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.textBoxENRValue);
			this.Controls.Add(this.textBoxYear);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ENRDetailForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ENR Table Record";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ENRDetailForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ENRDetailForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(ref int year, ref int enrValue, Form owner)
		{
			ENRDetailForm	form = new ENRDetailForm();
			bool			success;

			form.m_year = year;
			form.m_enrValue = enrValue;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			if (success)
			{
				year = form.m_year;
				enrValue = form.m_enrValue;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			//mam - accept only integers - no chars other than numbers
			//textBoxENRValue.NumbersOnly = true;
			//</mam>

			if (m_year != 0)
			{
				textBoxYear.Value = m_year;
				textBoxYear.ReadOnly = true;
				textBoxYear.TabStop = false;
			}

			if (m_enrValue != 0)
				textBoxENRValue.Value = m_enrValue;

			base.OnLoad(e);
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			if (!textBoxYear.ReadOnly)
				m_year = (int)textBoxYear.Value;

			m_enrValue = (int)textBoxENRValue.Value;

			//mam - allow only non-negative ENR values
			if (m_enrValue < 0)
			{
				MessageBox.Show(this, "The ENR value must be greater than zero.", "ENR Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxENRValue.Focus();
				return;
			}
			//</mam>

			if (m_year <= 0)
			{
				MessageBox.Show(this, 
					"Please enter a valid year.", "Enter Year", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxYear.Focus();
				return;
			}

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ENRDetailForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void ENRDetailForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void textBoxENRValue_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxENRValue.SelectionStart;
			existingText = textBoxENRValue.Text;

			//if (allowedChar.IndexOf(e.KeyChar) < 0)
			//{
			//	e.Handled = true;
			//}
		}

		private void textBoxENRValue_TextChanged(object sender, System.EventArgs e)
		{
			changedText = false;
			currentText = textBoxENRValue.Text;
			correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (allowedChar.IndexOf(currentText.Substring(i, 1)) == -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				textBoxENRValue.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxENRValue.SelectionStart = currentPos;
			}
		}

		private void textBoxYear_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxYear.SelectionStart;
			existingText = textBoxYear.Text;
		}

		private void textBoxYear_TextChanged(object sender, System.EventArgs e)
		{
			changedText = false;
			currentText = textBoxYear.Text;
			correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (allowedChar.IndexOf(currentText.Substring(i, 1)) == -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				textBoxYear.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxYear.SelectionStart = currentPos;
			}
		}
	}
}