using System;
using System.Drawing;

namespace WAM.UI.FX
{
	/// <summary>
	/// Summary description for FX.
	/// </summary>
	public class FX
	{
		public FX()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public static void PaintGradient(Object sender, System.Windows.Forms.PaintEventArgs e,
							int objHeight, int objWidth)
		{
			Rectangle baseRectangle = new Rectangle(0, 0, objWidth - 1, objHeight - 1);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.White, SystemColors.Control, 45);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(236, 233, 216), Color.FromArgb(184, 179, 151), 45);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(236, 233, 216), Color.FromArgb(200, 195, 169), 45);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(245, 243, 233), Color.FromArgb(200, 195, 169), 45);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(245, 243, 233), Color.FromArgb(209, 205, 181), 45);
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(236, 233, 216), Color.FromArgb(209, 205, 181), 45);

			//yellow to orange
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(254, 249, 188), Color.FromArgb(255, 181, 126), 45);

			//white to light orange
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(255, 215, 186), 45);

			//light yellow to light orange
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 245, 189), Color.FromArgb(255, 215, 186), 45);

			//lighter yellow to light orange
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(255, 215, 186), 45);

			//lighter yellow to orange
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(253, 184, 133), 45);

			//lighter yellow to orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(252, 210, 150), 45);

			//lighter yellow to lighter orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(253, 218, 168), 45);

			//lighter yellow to lightest orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(251, 229, 197), 45);

			//lightest yellow1 to lightest orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(254, 253, 240), Color.FromArgb(251, 229, 197), 45);

			//USING THIS ONE
			//lightest yellow2 to lightest orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(249, 248, 235), Color.FromArgb(251, 229, 197), 45);

			//white to XP default control color
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(236, 233, 216), 45);
			System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), System.Drawing.SystemColors.Control, 45);

			//white to light purple/pink
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(235, 220, 229), 45);

			//white to light blue
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(234, 240, 246), 45);

			//white to light pink
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(230, 216, 228), 45);

			//white to light light steel blue
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(219, 227, 235), 45);

			//light blue to light yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(245, 247, 250), Color.FromArgb(250, 252, 219), 45);

			//white to steel blue
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(108, 145, 185), 45);

			//white to lighter orange-yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(253, 218, 168), 45);

			//white to lighter yellow
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(250, 248, 225), 45);

			//lighter yellow to light pink (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(240, 203, 201), 45);

			//white to light pink (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(240, 203, 201), 45);

			//lighter yellow to pink (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(240, 175, 173), 45);

			//lightest yellow2 to mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(249, 248, 235), Color.FromArgb(230, 198, 217), 45);

			//white to mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(230, 198, 217), 45);

			//white to light mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(255, 255, 255), Color.FromArgb(239, 213, 228), 45);

			//light purple to light mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(217, 210, 246), Color.FromArgb(239, 213, 228), 45);

			//lighter purple to light mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(238, 234, 252), Color.FromArgb(239, 213, 228), 45);

			//lightest purple to light mauve (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(246, 244, 253), Color.FromArgb(239, 213, 228), 45);

			//lighter yellow to purple (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(192, 184, 196), 45);

			//lighter yellow to blue (to match logo)
			//System.Drawing.Drawing2D.LinearGradientBrush gradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(baseRectangle, Color.FromArgb(250, 248, 225), Color.FromArgb(145, 145, 238), 45);

			e.Graphics.FillRectangle(gradientBrush, baseRectangle);
		}
	}
}
