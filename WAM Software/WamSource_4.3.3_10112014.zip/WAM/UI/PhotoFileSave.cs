using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for PhotoFileSave.
	/// </summary>
	public class PhotoFileSave : System.Windows.Forms.Form
	{
		//private string nameTemplate = "";
		//private string labelText = "";
		private string infosetImagePath = "";
		private string fileName = "";
		//private string fileNameWithoutExtension = "";
		//private string targetPath = "";
		string sourceFileWithPath = "";
		private Image image = null;

		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;

		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label labelPhotoFileSave;
		private System.Windows.Forms.ListBox listBoxFiles;
		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labelImagePath;
		private System.Windows.Forms.TextBox textBoxImagePath;
		private System.Windows.Forms.TextBox textBoxFileName;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		//public PhotoFileSave(string infosetImagePath, string fileName)
		public PhotoFileSave()
		{
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);

			//if (!infosetImagePath.EndsWith("\\"))
			//{
			//	infosetImagePath += "\\";
			//}

			//this.infosetImagePath = infosetImagePath;
			//this.fileName = fileName;
			////this.fileNameWithoutExtension = fileNameWithoutExtension;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PhotoFileSave));
			this.textBoxFileName = new System.Windows.Forms.TextBox();
			this.labelPhotoFileSave = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.listBoxFiles = new System.Windows.Forms.ListBox();
			this.buttonTest = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.labelImagePath = new System.Windows.Forms.Label();
			this.textBoxImagePath = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// textBoxFileName
			// 
			this.textBoxFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxFileName.Location = new System.Drawing.Point(13, 37);
			this.textBoxFileName.MaxLength = 100;
			this.textBoxFileName.Name = "textBoxFileName";
			this.textBoxFileName.Size = new System.Drawing.Size(483, 20);
			this.textBoxFileName.TabIndex = 2;
			this.textBoxFileName.Text = "";
			// 
			// labelPhotoFileSave
			// 
			this.labelPhotoFileSave.BackColor = System.Drawing.Color.Transparent;
			this.labelPhotoFileSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelPhotoFileSave.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelPhotoFileSave.Location = new System.Drawing.Point(10, 11);
			this.labelPhotoFileSave.Name = "labelPhotoFileSave";
			this.labelPhotoFileSave.Size = new System.Drawing.Size(238, 21);
			this.labelPhotoFileSave.TabIndex = 0;
			this.labelPhotoFileSave.Text = "Save photo as:";
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(342, 320);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.TabIndex = 0;
			this.buttonOK.Text = "&OK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(423, 320);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 1;
			this.buttonCancel.Text = "Cancel";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(476, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 92;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// listBoxFiles
			// 
			this.listBoxFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.listBoxFiles.Location = new System.Drawing.Point(13, 105);
			this.listBoxFiles.Name = "listBoxFiles";
			this.listBoxFiles.Size = new System.Drawing.Size(483, 199);
			this.listBoxFiles.TabIndex = 3;
			this.listBoxFiles.DoubleClick += new System.EventHandler(this.listBoxFiles_DoubleClick);
			// 
			// buttonTest
			// 
			this.buttonTest.Location = new System.Drawing.Point(272, 8);
			this.buttonTest.Name = "buttonTest";
			this.buttonTest.Size = new System.Drawing.Size(72, 24);
			this.buttonTest.TabIndex = 94;
			this.buttonTest.Text = "Test";
			this.buttonTest.Visible = false;
			this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(184, 328);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 16);
			this.label1.TabIndex = 95;
			this.label1.Text = "298, 176";
			this.label1.Visible = false;
			// 
			// labelImagePath
			// 
			this.labelImagePath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelImagePath.BackColor = System.Drawing.Color.Transparent;
			this.labelImagePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelImagePath.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelImagePath.Location = new System.Drawing.Point(13, 65);
			this.labelImagePath.Name = "labelImagePath";
			this.labelImagePath.Size = new System.Drawing.Size(483, 32);
			this.labelImagePath.TabIndex = 96;
			this.labelImagePath.Text = "Files in  13, 72; 483, 21";
			this.labelImagePath.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// textBoxImagePath
			// 
			this.textBoxImagePath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxImagePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBoxImagePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBoxImagePath.Location = new System.Drawing.Point(13, 300);
			this.textBoxImagePath.MaxLength = 100;
			this.textBoxImagePath.Multiline = true;
			this.textBoxImagePath.Name = "textBoxImagePath";
			this.textBoxImagePath.ReadOnly = true;
			this.textBoxImagePath.Size = new System.Drawing.Size(483, 20);
			this.textBoxImagePath.TabIndex = 97;
			this.textBoxImagePath.Text = "";
			this.textBoxImagePath.Visible = false;
			// 
			// PhotoFileSave
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(504, 350);
			this.Controls.Add(this.textBoxImagePath);
			this.Controls.Add(this.labelImagePath);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonTest);
			this.Controls.Add(this.listBoxFiles);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelPhotoFileSave);
			this.Controls.Add(this.textBoxFileName);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.Name = "PhotoFileSave";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Save Photo";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhotoFileSave_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.PhotoFileSave_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool ShowForm(string sourceFileWithPath, string infosetImagePath, ref string fileName, ref Image image)
		{
			PhotoFileSave form = new PhotoFileSave();
			bool success;

			//form.templateID = templateID;
			//form.nameTemplate = nameTemplate;
			//form.labelText = labelText;

			if (!infosetImagePath.EndsWith("\\"))
			{
				infosetImagePath += "\\";
			}

			form.sourceFileWithPath = sourceFileWithPath;
			//form.targetPath = targetPath;
			form.infosetImagePath = infosetImagePath;
			form.fileName = fileName;
			//form.fileNameWithoutExtension = fileNameWithoutExtension;

			success = (form.ShowDialog() == DialogResult.OK);

			if (success)
			{
				image = form.image;
				fileName = form.fileName;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			this.Text = "Save Photo";

			//labelPhotoFileSave.Text = labelText;
			labelImagePath.Text = "Files in " + infosetImagePath + ":";
			textBoxImagePath.Text = infosetImagePath;
			//textBoxFileName.Text = fileName;

			string fileWithPath = infosetImagePath + fileName;
			fileWithPath = GetDistinctFileName(fileWithPath);

			textBoxFileName.Text = Path.GetFileName(fileWithPath);

			GetFilesInImageFolder();

			//if (fileName.Length > 255)
			//{
			//	textBoxFileName.Text = fileName.Substring(255);
			//}

//			Path.GetExtension
//			string splitTest = fileName.Split('.');
//			//rename the file if it already exists
//			string checkFileName = labelImagePath + "\\" + textBoxImagePath.Text;
//			int i = 0;
//			if (string.Compare(fileName, fileNameWithoutExtension, true) != 0)
//			{
//			}
//
//			string fileExtension = fileName. fileNameWithoutExtension
//			while (CheckFileExists())
//			{
//				i++;
//				MessageBox.Show("file exists");
//				return;
//			}
//				}

			//textBoxFileName.Focus();
			//textBoxFileName.SelectionStart = 0;
			//textBoxFileName.SelectionLength = textBoxFileName.Text.Length;

			buttonOK.Focus();

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		private string GetDistinctFileName(string fileWithPath)
		{
			string filePathToCheck = Path.GetDirectoryName(fileWithPath);
			string fileNameToCheck = Path.GetFileName(fileWithPath);
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileNameToCheck);
			string extension = Path.GetExtension(fileNameToCheck);

			int i = 0;
			while (File.Exists(fileWithPath))
			{
				i++;
				string counter = i < 10 ? "0" : "";
				fileWithPath = filePathToCheck + "\\" + fileNameWithoutExtension + "_" + counter + i.ToString() + extension;
			}

			return fileWithPath;
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to save data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			string fileNameToSave = textBoxFileName.Text.Trim();
			if (fileNameToSave == "")
			{
				MessageBox.Show(this, "Please enter a name for the file.", "Enter File Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxFileName.Focus();
				return;
			}

			//GetDistinctFileName(infosetImagePath + textBoxFileName.Text.Trim()
			if (File.Exists(infosetImagePath + fileNameToSave))
			{
				//if (MessageBox.Show(this, "The file already exists.  Would you like to overwrite it?", "File Exists"
				//	, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
				//{
				//	this.DialogResult = DialogResult.No;
				//	this.Close();
				//}

				MessageBox.Show(this, "The file already exists.  Please enter a different file name.", "File Exists"
					, MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxFileName.Focus();
				return;
			}

			//save file to disk
			if (WAM.Common.CommonTasks.CopyImageFile(this.sourceFileWithPath, infosetImagePath + fileNameToSave))
			{
				using (System.IO.FileStream fileStream = new System.IO.FileStream(fileName, System.IO.FileMode.Open))
				{
					this.image = Image.FromStream(fileStream);
					fileStream.Close();
				}
			}

			//nameTemplate = textBoxFileName.Text;
			//if (nameTemplate.Length > 255)
			//	nameTemplate = nameTemplate.Substring(255);

			this.fileName = fileNameToSave;
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void PhotoFileSave_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
		}

		private void PhotoFileSave_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void GetFilesInImageFolder()
		{
			string[] files = Directory.GetFiles(infosetImagePath);
			foreach (string file in files)
			{
				//listBoxFiles.Items.Add(Drive.IO.Directory.GetFileNameFromPath(@file, true));
				listBoxFiles.Items.Add(Path.GetFileName(@file));
			}
		}

		private void buttonTest_Click(object sender, System.EventArgs e)
		{
			//string[] files = Directory.GetFiles(@"C:\marti\images\");
			//listBoxFiles.DataSource = files;
		}

		private void listBoxFiles_DoubleClick(object sender, System.EventArgs e)
		{
			textBoxFileName.Text = listBoxFiles.SelectedItem.ToString();
		}
	}

}
