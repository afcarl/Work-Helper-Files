using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ENRDetailFormCopy.
	/// </summary>
	public class ENRDetailFormCopy : System.Windows.Forms.Form
	{
		private int customENRListID = 0;
		private string nameENR = "";
		private string labelText = "";
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.TextBox textBoxName;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label labelENRName;
		private System.Windows.Forms.CheckBox checkBoxValues20Cities;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ENRDetailFormCopy()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ENRDetailFormCopy));
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.labelENRName = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.checkBoxValues20Cities = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// buttonSave
			// 
			this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(130, 114);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(72, 23);
			this.buttonSave.TabIndex = 2;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(211, 114);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// textBoxName
			// 
			this.textBoxName.Location = new System.Drawing.Point(13, 37);
			this.textBoxName.MaxLength = 255;
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(267, 20);
			this.textBoxName.TabIndex = 0;
			this.textBoxName.Text = "";
			// 
			// labelENRName
			// 
			this.labelENRName.BackColor = System.Drawing.Color.Transparent;
			this.labelENRName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelENRName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelENRName.Location = new System.Drawing.Point(12, 12);
			this.labelENRName.Name = "labelENRName";
			this.labelENRName.Size = new System.Drawing.Size(240, 21);
			this.labelENRName.TabIndex = 158;
			this.labelENRName.Text = "New ENR Name";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(260, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 159;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			// 
			// checkBoxValues20Cities
			// 
			this.checkBoxValues20Cities.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxValues20Cities.Location = new System.Drawing.Point(16, 64);
			this.checkBoxValues20Cities.Name = "checkBoxValues20Cities";
			this.checkBoxValues20Cities.Size = new System.Drawing.Size(196, 16);
			this.checkBoxValues20Cities.TabIndex = 1;
			this.checkBoxValues20Cities.Text = "Use 20 Cities Years and Values";
			this.checkBoxValues20Cities.Visible = false;
			// 
			// ENRDetailFormCopy
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(292, 144);
			this.Controls.Add(this.checkBoxValues20Cities);
			this.Controls.Add(this.textBoxName);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelENRName);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonSave);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ENRDetailFormCopy";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ENR Table";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ENRDetailFormCopy_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ENRDetailFormCopy_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(ref string nameENR, string labelText, int listID, Form owner)
		{
			ENRDetailFormCopy	form = new ENRDetailFormCopy();
			bool success;

			form.customENRListID = listID;
			form.nameENR = nameENR;
			form.labelText = labelText;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			if (success)
			{
				nameENR = form.nameENR;
			}

			return success;			
		}

		public static bool	ShowForm(ref string nameENR, ref bool use20CitiesValues, string labelText, int listID, Form owner)
		{
			ENRDetailFormCopy	form = new ENRDetailFormCopy();
			bool success;

			form.customENRListID = listID;
			form.nameENR = nameENR;
			form.labelText = labelText;
			form.checkBoxValues20Cities.Visible = true;
			form.checkBoxValues20Cities.Checked = use20CitiesValues;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			use20CitiesValues = form.checkBoxValues20Cities.Checked;
			if (success)
			{
				nameENR = form.nameENR;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			labelENRName.Text = labelText;

			textBoxName.Text = nameENR;
			if (nameENR.Length > 255)
				textBoxName.Text = nameENR.Substring(255);

			textBoxName.Focus();
			textBoxName.SelectionStart = 0;
			textBoxName.SelectionLength = textBoxName.Text.Length;

			base.OnLoad(e);
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			if (textBoxName.Text.Trim().Length == 0)
			{
				MessageBox.Show(this, 
					"Please enter a name for the ENR table.", "Enter ENR Table Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxName.Focus();
				return;
			}

			nameENR = textBoxName.Text;
			if (nameENR.Length > 255)
				nameENR = nameENR.Substring(255);

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ENRDetailFormCopy_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void ENRDetailFormCopy_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}