using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for LoadCacheForm.
	/// </summary>
	public class LoadCacheForm : System.Windows.Forms.Form
	{
		private int			m_infoSetID = 0;

		//mam
		//private bool forceLoadCache = false;
		private static bool forceNewLoadCache = false;
		private bool allowCancel = false;
		//</mam>

		private WAM.UI.CacheBuildStatusControl cacheBuildStatusControl1;
		private System.Windows.Forms.Timer timer;
		private System.ComponentModel.IContainer components;

		public LoadCacheForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.cacheBuildStatusControl1 = new WAM.UI.CacheBuildStatusControl();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// cacheBuildStatusControl1
			// 
			this.cacheBuildStatusControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cacheBuildStatusControl1.BackColor = System.Drawing.SystemColors.Control;
			this.cacheBuildStatusControl1.Location = new System.Drawing.Point(0, 0);
			this.cacheBuildStatusControl1.Name = "cacheBuildStatusControl1";
			this.cacheBuildStatusControl1.Size = new System.Drawing.Size(312, 128);
			this.cacheBuildStatusControl1.TabIndex = 0;
			// 
			// timer
			// 
			this.timer.Interval = 250;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// LoadCacheForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(312, 126);
			this.ControlBox = false;
			this.Controls.Add(this.cacheBuildStatusControl1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "LoadCacheForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Building cache - please wait...";
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowForm(int infoSetID, Form owner)
		{
			LoadCacheForm form = new LoadCacheForm();

			form.m_infoSetID = infoSetID;
			form.ShowDialog();
		}

		//mam - added this routine because of problems allowing user to load various databases
		public static void	ShowForm(int infoSetID, Form owner, bool forceLoadCache)
		{
			LoadCacheForm form = new LoadCacheForm();
			forceNewLoadCache = forceLoadCache;

			form.m_infoSetID = infoSetID;
			form.ShowDialog();
		}
		//</mam>

		//mam - added this routine to enable the Cancel button
		public static void	ShowForm(int infoSetID, Form owner, bool forceLoadCache, bool allowCancel)
		{
			LoadCacheForm form = new LoadCacheForm();
			forceNewLoadCache = forceLoadCache;

			// allow user to cancel caching operation under certain circumstances
			//	(such as preparing a graph)
			form.allowCancel = allowCancel;
			form.cacheBuildStatusControl1.AllowCancelCache = allowCancel;

			form.m_infoSetID = infoSetID;
			form.ShowDialog();
		}
		//</mam>

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			timer.Enabled = true;
		}

		private void timer_Tick(object sender, System.EventArgs e)
		{
			timer.Enabled = false;

			//mam - added forceLoadCache code
			if (forceNewLoadCache)
			{
				forceNewLoadCache = false;
				CacheManager.GetCacheForInfoSetID(m_infoSetID, true);
			}
			else
			{
				CacheManager.GetCacheForInfoSetID(m_infoSetID);
			}
			this.Close();
		}
	}
}
