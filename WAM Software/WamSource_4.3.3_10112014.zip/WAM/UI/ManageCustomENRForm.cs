using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using WAM.Data;
using Drive.Configuration;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ManageCustomENRForm.
	/// </summary>
	public class ManageCustomENRForm : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		private Facility	m_facility = null;

		//<mam>
		private WAM.Common.CommonImageList commonImageList = new WAM.Common.CommonImageList();
		private int facilitiesAffected = 0;
		private int newCustomENRID = 0;
		//private int rememberCustomENRListID = 0;
		private int selRow = 0;
		private int gridSortCol = 1;
		private int gridSortDirection = 0;
		private int gridColWidth = 150;
		private int maxGridDropDownItems = 16;
		private bool use20CitiesValues = false;
		private bool justResizedColumn = false;
		//</mam>

		private C1.Win.C1FlexGrid.C1FlexGrid gridENRValues;
		private System.Windows.Forms.Button buttonAddValue;
		private System.Windows.Forms.Button buttonEditValue;
		private System.Windows.Forms.Button buttonDeleteValue;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.PictureBox pictureBoxToolbarPreferences;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCopy;
		private System.Windows.Forms.PictureBox pictureBoxToolbarDelete;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private Hashtable	m_customENRValues = null;
		private int m_customENRListID = 0;
		private System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
		private ToolTip toolTip = new ToolTip();
		private System.Windows.Forms.PictureBox pictureBoxToolbarHelp;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBoxToolbarEdit;
		private System.Windows.Forms.TreeView treeViewFacilityCount;
		private System.Windows.Forms.Label labelFacilityCount;
		private System.Windows.Forms.Panel panelTreeViewFacilityCount;
		private System.Windows.Forms.CheckBox checkBoxShowENRThisInfosetOnly;
		private C1.Win.C1FlexGrid.C1FlexGrid gridCustomENRTables;
		private System.Windows.Forms.Panel panelgridCustomENRTables;
		private System.Windows.Forms.PictureBox pictureBoxShowGrid;
		private System.Windows.Forms.Panel panelToolbar;
		private System.Windows.Forms.Label labelLockedENR;
		private System.Windows.Forms.TextBox textBoxSelectedCustomENRTable;

		//mam - this variable is no longer used
		//private System.ComponentModel.IContainer components;
		//</mam>

		#endregion /***** Member Variables *****/
		
		#region /***** Construction *****/

		public ManageCustomENRForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			//mam - no longer using the variable 'components'
			//if( disposing )
			//{
			//	if(components != null)
			//	{
			//		components.Dispose();
			//	}
			//}
			//</mam>

			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ManageCustomENRForm));
			this.gridENRValues = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.buttonAddValue = new System.Windows.Forms.Button();
			this.buttonEditValue = new System.Windows.Forms.Button();
			this.buttonDeleteValue = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.pictureBoxToolbarHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.pictureBoxToolbarPreferences = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarCopy = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarDelete = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarEdit = new System.Windows.Forms.PictureBox();
			this.panelToolbar = new System.Windows.Forms.Panel();
			this.pictureBoxShowGrid = new System.Windows.Forms.PictureBox();
			this.checkBoxShowENRThisInfosetOnly = new System.Windows.Forms.CheckBox();
			this.textBoxSelectedCustomENRTable = new System.Windows.Forms.TextBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.panelTreeViewFacilityCount = new System.Windows.Forms.Panel();
			this.treeViewFacilityCount = new System.Windows.Forms.TreeView();
			this.labelFacilityCount = new System.Windows.Forms.Label();
			this.gridCustomENRTables = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.panelgridCustomENRTables = new System.Windows.Forms.Panel();
			this.labelLockedENR = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.gridENRValues)).BeginInit();
			this.panelToolbar.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panelTreeViewFacilityCount.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCustomENRTables)).BeginInit();
			this.panelgridCustomENRTables.SuspendLayout();
			this.SuspendLayout();
			// 
			// gridENRValues
			// 
			this.gridENRValues.AllowEditing = false;
			this.gridENRValues.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.gridENRValues.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.gridENRValues.ColumnInfo = @"3,1,0,0,0,85,Columns:0{Width:25;Visible:False;}	1{Width:94;AllowSorting:False;Caption:""Year"";AllowResizing:False;DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	2{Width:25;AllowSorting:False;Caption:""ENR Value"";AllowResizing:False;DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	";
			this.gridENRValues.ExtendLastCol = true;
			this.gridENRValues.Location = new System.Drawing.Point(1, 1);
			this.gridENRValues.Name = "gridENRValues";
			this.gridENRValues.Rows.Count = 1;
			this.gridENRValues.Size = new System.Drawing.Size(206, 339);
			this.gridENRValues.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Alternate{BackColor:245, 244, 235;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridENRValues.TabIndex = 0;
			this.gridENRValues.Click += new System.EventHandler(this.gridENRValues_Click);
			// 
			// buttonAddValue
			// 
			this.buttonAddValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddValue.Location = new System.Drawing.Point(226, 67);
			this.buttonAddValue.Name = "buttonAddValue";
			this.buttonAddValue.Size = new System.Drawing.Size(92, 23);
			this.buttonAddValue.TabIndex = 1;
			this.buttonAddValue.Text = "&Add Value";
			this.buttonAddValue.Click += new System.EventHandler(this.buttonAddValue_Click);
			// 
			// buttonEditValue
			// 
			this.buttonEditValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditValue.Location = new System.Drawing.Point(226, 99);
			this.buttonEditValue.Name = "buttonEditValue";
			this.buttonEditValue.Size = new System.Drawing.Size(92, 23);
			this.buttonEditValue.TabIndex = 2;
			this.buttonEditValue.Text = "&Edit Value";
			this.buttonEditValue.Click += new System.EventHandler(this.buttonEditValue_Click);
			// 
			// buttonDeleteValue
			// 
			this.buttonDeleteValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonDeleteValue.Location = new System.Drawing.Point(226, 131);
			this.buttonDeleteValue.Name = "buttonDeleteValue";
			this.buttonDeleteValue.Size = new System.Drawing.Size(92, 23);
			this.buttonDeleteValue.TabIndex = 3;
			this.buttonDeleteValue.Text = "&Remove Value";
			this.buttonDeleteValue.Click += new System.EventHandler(this.buttonDeleteValue_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(404, 384);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(92, 23);
			this.buttonClose.TabIndex = 4;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// pictureBoxToolbarHelp
			// 
			this.pictureBoxToolbarHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxToolbarHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarHelp.Image")));
			this.pictureBoxToolbarHelp.Location = new System.Drawing.Point(479, 6);
			this.pictureBoxToolbarHelp.Name = "pictureBoxToolbarHelp";
			this.pictureBoxToolbarHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxToolbarHelp.TabIndex = 97;
			this.pictureBoxToolbarHelp.TabStop = false;
			this.pictureBoxToolbarHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// pictureBoxToolbarPreferences
			// 
			this.pictureBoxToolbarPreferences.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarPreferences.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarPreferences.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarPreferences.Image")));
			this.pictureBoxToolbarPreferences.Location = new System.Drawing.Point(420, 72);
			this.pictureBoxToolbarPreferences.Name = "pictureBoxToolbarPreferences";
			this.pictureBoxToolbarPreferences.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarPreferences.TabIndex = 145;
			this.pictureBoxToolbarPreferences.TabStop = false;
			this.pictureBoxToolbarPreferences.Visible = false;
			// 
			// pictureBoxToolbarCopy
			// 
			this.pictureBoxToolbarCopy.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCopy.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCopy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCopy.Image")));
			this.pictureBoxToolbarCopy.Location = new System.Drawing.Point(34, 6);
			this.pictureBoxToolbarCopy.Name = "pictureBoxToolbarCopy";
			this.pictureBoxToolbarCopy.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCopy.TabIndex = 144;
			this.pictureBoxToolbarCopy.TabStop = false;
			this.pictureBoxToolbarCopy.Click += new System.EventHandler(this.pictureBoxToolbarCopy_Click);
			// 
			// pictureBoxToolbarDelete
			// 
			this.pictureBoxToolbarDelete.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarDelete.Image")));
			this.pictureBoxToolbarDelete.Location = new System.Drawing.Point(426, 6);
			this.pictureBoxToolbarDelete.Name = "pictureBoxToolbarDelete";
			this.pictureBoxToolbarDelete.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarDelete.TabIndex = 143;
			this.pictureBoxToolbarDelete.TabStop = false;
			this.pictureBoxToolbarDelete.Click += new System.EventHandler(this.pictureBoxToolbarDelete_Click);
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(8, 6);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 142;
			this.pictureBoxToolbarAdd.TabStop = false;
			this.pictureBoxToolbarAdd.Click += new System.EventHandler(this.pictureBoxToolbarAdd_Click);
			// 
			// pictureBoxToolbarEdit
			// 
			this.pictureBoxToolbarEdit.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarEdit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarEdit.Image")));
			this.pictureBoxToolbarEdit.Location = new System.Drawing.Point(400, 6);
			this.pictureBoxToolbarEdit.Name = "pictureBoxToolbarEdit";
			this.pictureBoxToolbarEdit.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxToolbarEdit.TabIndex = 148;
			this.pictureBoxToolbarEdit.TabStop = false;
			this.pictureBoxToolbarEdit.Click += new System.EventHandler(this.pictureBoxToolbarEdit_Click);
			// 
			// panelToolbar
			// 
			this.panelToolbar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelToolbar.BackColor = System.Drawing.Color.White;
			this.panelToolbar.Controls.Add(this.pictureBoxShowGrid);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarCopy);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarAdd);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarDelete);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarHelp);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarEdit);
			this.panelToolbar.Controls.Add(this.checkBoxShowENRThisInfosetOnly);
			this.panelToolbar.Controls.Add(this.textBoxSelectedCustomENRTable);
			this.panelToolbar.Location = new System.Drawing.Point(0, 0);
			this.panelToolbar.Name = "panelToolbar";
			this.panelToolbar.Size = new System.Drawing.Size(512, 33);
			this.panelToolbar.TabIndex = 152;
			this.panelToolbar.Click += new System.EventHandler(this.panelToolbar_Click);
			// 
			// pictureBoxShowGrid
			// 
			this.pictureBoxShowGrid.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxShowGrid.Image")));
			this.pictureBoxShowGrid.Location = new System.Drawing.Point(376, 8);
			this.pictureBoxShowGrid.Name = "pictureBoxShowGrid";
			this.pictureBoxShowGrid.Size = new System.Drawing.Size(17, 16);
			this.pictureBoxShowGrid.TabIndex = 168;
			this.pictureBoxShowGrid.TabStop = false;
			this.pictureBoxShowGrid.Click += new System.EventHandler(this.pictureBoxShowGrid_Click);
			// 
			// checkBoxShowENRThisInfosetOnly
			// 
			this.checkBoxShowENRThisInfosetOnly.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxShowENRThisInfosetOnly.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxShowENRThisInfosetOnly.Location = new System.Drawing.Point(451, 10);
			this.checkBoxShowENRThisInfosetOnly.Name = "checkBoxShowENRThisInfosetOnly";
			this.checkBoxShowENRThisInfosetOnly.Size = new System.Drawing.Size(13, 14);
			this.checkBoxShowENRThisInfosetOnly.TabIndex = 165;
			this.checkBoxShowENRThisInfosetOnly.Visible = false;
			this.checkBoxShowENRThisInfosetOnly.CheckedChanged += new System.EventHandler(this.checkBoxShowENRThisInfosetOnly_CheckedChanged);
			// 
			// textBoxSelectedCustomENRTable
			// 
			this.textBoxSelectedCustomENRTable.AutoSize = false;
			this.textBoxSelectedCustomENRTable.BackColor = System.Drawing.Color.White;
			this.textBoxSelectedCustomENRTable.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.textBoxSelectedCustomENRTable.Location = new System.Drawing.Point(62, 6);
			this.textBoxSelectedCustomENRTable.Name = "textBoxSelectedCustomENRTable";
			this.textBoxSelectedCustomENRTable.ReadOnly = true;
			this.textBoxSelectedCustomENRTable.Size = new System.Drawing.Size(332, 20);
			this.textBoxSelectedCustomENRTable.TabIndex = 168;
			this.textBoxSelectedCustomENRTable.Text = "";
			this.textBoxSelectedCustomENRTable.MouseDown += new System.Windows.Forms.MouseEventHandler(this.textBoxSelectedCustomENRTable_MouseDown);
			this.textBoxSelectedCustomENRTable.TextChanged += new System.EventHandler(this.textBoxSelectedCustomENRTable_TextChanged);
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel2.Location = new System.Drawing.Point(0, 32);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(508, 2);
			this.panel2.TabIndex = 154;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Controls.Add(this.gridENRValues);
			this.panel3.Location = new System.Drawing.Point(6, 67);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(208, 341);
			this.panel3.TabIndex = 155;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label2.Location = new System.Drawing.Point(7, 37);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(193, 28);
			this.label2.TabIndex = 156;
			this.label2.Text = "Custom ENR Values";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelTreeViewFacilityCount
			// 
			this.panelTreeViewFacilityCount.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(209)), ((System.Byte)(206)), ((System.Byte)(190)));
			this.panelTreeViewFacilityCount.Controls.Add(this.treeViewFacilityCount);
			this.panelTreeViewFacilityCount.Location = new System.Drawing.Point(227, 198);
			this.panelTreeViewFacilityCount.Name = "panelTreeViewFacilityCount";
			this.panelTreeViewFacilityCount.Size = new System.Drawing.Size(218, 129);
			this.panelTreeViewFacilityCount.TabIndex = 164;
			// 
			// treeViewFacilityCount
			// 
			this.treeViewFacilityCount.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(245)), ((System.Byte)(244)), ((System.Byte)(235)));
			this.treeViewFacilityCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewFacilityCount.ImageIndex = -1;
			this.treeViewFacilityCount.Location = new System.Drawing.Point(1, 1);
			this.treeViewFacilityCount.Name = "treeViewFacilityCount";
			this.treeViewFacilityCount.SelectedImageIndex = -1;
			this.treeViewFacilityCount.ShowLines = false;
			this.treeViewFacilityCount.ShowPlusMinus = false;
			this.treeViewFacilityCount.Size = new System.Drawing.Size(216, 127);
			this.treeViewFacilityCount.TabIndex = 0;
			this.treeViewFacilityCount.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewFacilityCount_AfterSelect);
			// 
			// labelFacilityCount
			// 
			this.labelFacilityCount.BackColor = System.Drawing.Color.Transparent;
			this.labelFacilityCount.Location = new System.Drawing.Point(228, 181);
			this.labelFacilityCount.Name = "labelFacilityCount";
			this.labelFacilityCount.Size = new System.Drawing.Size(215, 17);
			this.labelFacilityCount.TabIndex = 163;
			// 
			// gridCustomENRTables
			// 
			this.gridCustomENRTables.AllowEditing = false;
			this.gridCustomENRTables.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.gridCustomENRTables.ColumnInfo = @"3,1,0,0,0,85,Columns:0{Width:25;Visible:False;}	1{Width:150;Caption:""InfoSet"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	2{Width:150;Caption:""Custom ENR Table"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	";
			this.gridCustomENRTables.ExtendLastCol = true;
			this.gridCustomENRTables.Location = new System.Drawing.Point(1, 1);
			this.gridCustomENRTables.Name = "gridCustomENRTables";
			this.gridCustomENRTables.Rows.Count = 1;
			this.gridCustomENRTables.Rows.MaxSize = 20;
			this.gridCustomENRTables.Size = new System.Drawing.Size(330, 271);
			this.gridCustomENRTables.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridCustomENRTables.TabIndex = 166;
			this.gridCustomENRTables.AfterResizeColumn += new C1.Win.C1FlexGrid.RowColEventHandler(this.gridCustomENRTables_AfterResizeColumn);
			this.gridCustomENRTables.MouseUp += new System.Windows.Forms.MouseEventHandler(this.gridCustomENRTables_MouseUp);
			this.gridCustomENRTables.AfterSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.gridCustomENRTables_AfterSort);
			// 
			// panelgridCustomENRTables
			// 
			this.panelgridCustomENRTables.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelgridCustomENRTables.Controls.Add(this.gridCustomENRTables);
			this.panelgridCustomENRTables.Location = new System.Drawing.Point(379, 99);
			this.panelgridCustomENRTables.Name = "panelgridCustomENRTables";
			this.panelgridCustomENRTables.Size = new System.Drawing.Size(332, 273);
			this.panelgridCustomENRTables.TabIndex = 167;
			this.panelgridCustomENRTables.Visible = false;
			// 
			// labelLockedENR
			// 
			this.labelLockedENR.BackColor = System.Drawing.Color.Transparent;
			this.labelLockedENR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelLockedENR.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelLockedENR.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.labelLockedENR.Location = new System.Drawing.Point(224, 37);
			this.labelLockedENR.Name = "labelLockedENR";
			this.labelLockedENR.Size = new System.Drawing.Size(216, 28);
			this.labelLockedENR.TabIndex = 168;
			this.labelLockedENR.Text = "This ENR Table is Locked";
			this.labelLockedENR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelLockedENR.Visible = false;
			// 
			// ManageCustomENRForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(506, 416);
			this.Controls.Add(this.panelgridCustomENRTables);
			this.Controls.Add(this.panelTreeViewFacilityCount);
			this.Controls.Add(this.labelFacilityCount);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panelToolbar);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.buttonDeleteValue);
			this.Controls.Add(this.buttonEditValue);
			this.Controls.Add(this.buttonAddValue);
			this.Controls.Add(this.pictureBoxToolbarPreferences);
			this.Controls.Add(this.labelLockedENR);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "EditCustomENRTable.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ManageCustomENRForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Custom ENR Tables";
			this.Click += new System.EventHandler(this.ManageCustomENRForm_Click);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ManageCustomENRForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ManageCustomENRForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.gridENRValues)).EndInit();
			this.panelToolbar.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panelTreeViewFacilityCount.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridCustomENRTables)).EndInit();
			this.panelgridCustomENRTables.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Loading *****/

		public static void	ShowForm(Facility facility, Form owner)
		{
			ManageCustomENRForm form = new ManageCustomENRForm();

			form.m_facility = facility;
			if (facility != null)
			{
				form.m_customENRListID = facility.CustomENRListID;
			}

			form.ShowDialog(owner);
			form.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			//mam
			treeViewFacilityCount.ImageList = commonImageList.imageListTreeReport;
			treeViewFacilityCount.ImageIndex = 1;
			treeViewFacilityCount.SelectedImageIndex = 1;

			// position grid
			int posX = textBoxSelectedCustomENRTable.Location.X;
			int posY = textBoxSelectedCustomENRTable.Location.Y + textBoxSelectedCustomENRTable.Height - 1;
			panelgridCustomENRTables.Location = new System.Drawing.Point(posX, posY);

			GetOptions();
			//</mam>

			PopulateCustomENRGrid();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxToolbarHelp);
			commonTasks = null;

			SetToolTips();
			SetBitmaps();

			base.OnLoad(e);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			SaveOptions();

			base.OnClosing (e);
			this.Dispose(true);
		}

		#endregion /***** Loading *****/

		#region /***** Methods *****/

		//mam
		private void ManageCustomENRForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
		//</mam>

		//mam
		private void SetCustomENRListIDFromGridRow(int selectedRow)
		{
			// get CustomENRListID for the desired row and assign to m_customENRListID
			WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid(selectedRow);
			
			if (gridItemDropDown == null)
				return;

			m_customENRListID = gridItemDropDown.ItemID;
		}
		//</mam>

		//mam
		private void PopulateCustomENRGrid()
		{
			//  load the grid with a list of the ENR tables
			string queryValue = "";
			WAM.Common.GridMethods gridMethods;

			if (checkBoxShowENRThisInfosetOnly.Checked)
				gridMethods = new WAM.Common.GridMethods(InfoSet.CurrentID);
			else
				gridMethods = new WAM.Common.GridMethods();

			queryValue = gridMethods.QueryValueCustomENR;
			selRow = gridMethods.PopulateGrid(ref gridCustomENRTables, m_customENRListID, queryValue);
			gridMethods = null;

			if (gridSortDirection == (int)C1.Win.C1FlexGrid.SortFlags.Descending)
			{
				gridCustomENRTables.Sort(C1.Win.C1FlexGrid.SortFlags.Descending, gridSortCol);
			}
			else
			{
				gridCustomENRTables.Sort(C1.Win.C1FlexGrid.SortFlags.Ascending, gridSortCol);
			}

			DetermineLockedENRTables();

			gridCustomENRTables.Cols[1].Width = gridColWidth;
			gridCustomENRTables.TopRow = selRow;

			AfterENRTableChange();

			SetLockedENRControls();
		}
		//</mam>

		private void DetermineLockedENRTables()
		{
			//determine if any of the custom ENR tables are being used by locked infosets

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataTable dataTable = new DataTable();
			StringBuilder builder = new StringBuilder(200);

			builder.Append("SELECT DISTINCT C.CustomENRListID AS ENRID");
			builder.Append(" FROM (CustomENRList C INNER JOIN Facilities F ON C.CustomENRListID = F.CustomENRListID)");
			builder.Append(" INNER JOIN InfoSets I ON F.infoset_id = I.infoset_id");
			builder.Append(" WHERE I.FixedInfoset = 1");

			dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
			if (dataTable != null)
			{
				if (dataTable.Rows.Count > 0)
				{
					foreach (System.Data.DataRow dataRow in dataTable.Rows)
					{
						for (int i = 1; i < gridCustomENRTables.Rows.Count; i++)
						{
							if (gridCustomENRTables.Rows[i][0].ToString().Equals(dataRow["ENRID"].ToString()))
							{
								((WAM.Common.ComboBoxItem)gridCustomENRTables.Rows[i].UserData).ItemExtra2 = "true";
							}
						}
					}
				}
			}
			dataAccess = null;
			dataTable = null;
		}

		//mam
		private void AfterENRTableChange()
		{
			WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid();
			
			if (gridItemDropDown == null)
			{
				m_customENRListID = 0;
				textBoxSelectedCustomENRTable.Text = "";
			}
			else
			{
				m_customENRListID = gridItemDropDown.ItemID;
				textBoxSelectedCustomENRTable.Text = gridItemDropDown.ItemDescription;
			}

			LoadENRList();
			CountFacilitiesUsingENRTable();
		}
		//</mam>

		//mam
		private void SetToolTips()
		{
			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.pictureBoxToolbarAdd, "Add a new ENR table");
			toolTip.SetToolTip(this.pictureBoxToolbarCopy, "Copy the selected ENR table");
			toolTip.SetToolTip(this.pictureBoxToolbarEdit, "Change the name of the selected ENR table");
			toolTip.SetToolTip(this.pictureBoxToolbarDelete, "Delete the selected ENR table");
			toolTip.SetToolTip(this.pictureBoxToolbarPreferences, "Display the user preferences");
			toolTip.SetToolTip(this.pictureBoxToolbarHelp, "Help");

			toolTip.SetToolTip(this.labelLockedENR, "This ENR table is used by a locked Infoset and cannot be edited or deleted");
		}
		//</mam>

		//mam
		private void SetBitmaps()
		{
			//load toolbar pictureboxes with bitmaps
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			System.IO.Stream file = null;
			Image image = null;

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarAdd.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarAdd);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarDelete.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarDelete);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonHelpOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarHelp.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarHelp);

			//***************************

			Bitmap b = (Bitmap)pictureBoxToolbarAdd.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarAdd.Image = b;

			b = (Bitmap)pictureBoxToolbarCopy.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarCopy.Image = b;

			b = (Bitmap)pictureBoxToolbarDelete.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarDelete.Image = b;

			//b = (Bitmap)pictureBoxToolbarHelp.Image;
			//b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//pictureBoxToolbarHelp.Image = b;

			commonTasks = null;
			file = null;
			image = null;
		}
		//</mam>

		private void		LoadENRList()
		{
			//mam - no longer tying ENR tables only to one facility
			//ENRCustom[]		enrRecords = m_facility.GetAllENRValues();
			ENRCustom[]		enrRecords = GetAllENRValues();
			//</mam>

			ENRCustom		enrRecord;
			int				row = 1;

			gridENRValues.Redraw = false;
			gridENRValues.Rows.Count = 1;
			for (int pos = 0; pos < enrRecords.Length; pos++)
			{
				enrRecord = enrRecords[pos];
				gridENRValues.Rows.Add().UserData = enrRecord;
				gridENRValues.SetData(row, 1, enrRecord.Year);
				gridENRValues.SetData(row, 2, enrRecord.ENRValue);
				row++;
			}
			gridENRValues.Redraw = true;
		}

		//mam - need a method that doesn't rely on Facility (copied this method from Facility)
		public ENRCustom[] GetAllENRValues()
		{
			LoadCustomENRValues();

			ICollection	items = m_customENRValues.Values;
			ENRCustom[]	enrItems = new ENRCustom[items.Count];

			items.CopyTo(enrItems, 0);
			Array.Sort(enrItems);

			return enrItems;
		}
		//</mam>

		//mam - need a method that doesn't rely on Facility (copied this method from Facility)
		private void LoadCustomENRValues()
		{
			ENRCustom[]	enrData = ENRCustom.LoadForENR(m_customENRListID);

			m_customENRValues = new Hashtable(Drive.Math.FindHighestPrime(enrData.Length * 2), 1.0f);
			for (int pos = 0; pos < enrData.Length; pos++)
				m_customENRValues[enrData[pos].Year.GetHashCode()] = enrData[pos];
		}
		//</mam>

		private ENRCustom GetSelectedRecord()
		{
			ENRCustom		enrRecord = null;

			if (gridENRValues.Row >= gridENRValues.Rows.Fixed)
				enrRecord = gridENRValues.Rows[gridENRValues.Row].UserData as ENRCustom;

			return enrRecord;
		}

		//mam - need a method not connected to a facility (copied from Facility)
		private bool HasENRValueForYear(int year)
		{
			ENRCustom[] enrRecords = GetAllENRValues();
			ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];
			return (enr != null);
		}
		//</mam>

		//mam
		private ENRCustom GetSelectedRecordForGivenRow(int forRow)
		{
			ENRCustom enrRecord = null;

			if (forRow >= gridENRValues.Rows.Fixed)
				enrRecord = gridENRValues.Rows[forRow].UserData as ENRCustom;

			return enrRecord;
		}
		//</mam>

		//mam
		private WAM.Common.ComboBoxItem GetSelectedRecordENRTableGrid()
		{
			WAM.Common.ComboBoxItem gridItemDropDown = null;

			if (gridCustomENRTables.Row >= gridCustomENRTables.Rows.Fixed)
				gridItemDropDown = gridCustomENRTables.Rows[gridCustomENRTables.Row].UserData as WAM.Common.ComboBoxItem;

			return gridItemDropDown;
		}
		//</mam>

		//mam
		private WAM.Common.ComboBoxItem GetSelectedRecordENRTableGrid(int forRow)
		{
			WAM.Common.ComboBoxItem gridItemDropDown = null;

			if (forRow <= (gridCustomENRTables.Rows.Count - gridCustomENRTables.Rows.Fixed))
				gridItemDropDown = gridCustomENRTables.Rows[forRow].UserData as WAM.Common.ComboBoxItem;

			return gridItemDropDown;
		}
		//</mam>

		//mam - need method not associated with facility (copied from Facility)
		public ENRCustom GetENRRecordForYear(int year)
		{
			ENRCustom[] enrRecords = GetAllENRValues();
			ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

			return enr;
		}
		//</mam>

		//mam - need method not associated with facility (copied from Facility)
		public void SetENRValueForYear(int year, int enrValue)
		{
			ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];
			if (enr != null)
			{
				enr.ENRValue = enrValue;
				enr.CustomENRListID = m_customENRListID;
				enr.Save();
			}
			else
			{
				enr = new ENRCustom(0);
				enr.Year = year;
				enr.ENRValue = enrValue;
				enr.CustomENRListID = m_customENRListID;
				enr.Save();

				m_customENRValues[year.GetHashCode()] = enr;
			}
		}
		//</mam>

		//mam - need method not associated with facility (copied from Facility)
		public void DeleteENRValueForYear(int year)
		{
			ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

			if (enr != null)
			{
				m_customENRValues.Remove(year.GetHashCode());
				enr.Delete();
			}
		}
		//</mam>

		//mam
		private bool UpdateDatabaseForCustomENR(string executeStatement, bool isCopy, bool isAdd)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			//int setENRValue = 0;
			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);

			try
			{
				if (isCopy)
				{
					newCustomENRID = dataAccess.ExecuteCommandReturnAutoID(executeStatement);
					if (newCustomENRID == 0)
					{
						MessageBox.Show(this, "An error has occurred.  The ENR Table was not copied.", "Copy ENR Table", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					else
					{
						builder.AppendFormat("INSERT INTO CustomENR SELECT enr_year, enr_value, {0} AS CustomENRListID", newCustomENRID);
						builder.AppendFormat(" FROM CustomENR WHERE CustomENRListID = {0}", m_customENRListID);

						m_customENRListID = newCustomENRID;
						return dataAccess.ExecuteCommand(builder.ToString());
					}
				}
				else
				{
					return dataAccess.ExecuteCommand(executeStatement);
				}
			}
			catch
			{
				throw new Exception("Database Error.  An error occurred while updating the database. (ManageCustomENRForm.UpdateDatabaseForCustomENR)");
			}
			finally
			{
				dataAccess = null;
			}
			return false;
		}
		//</mam>

		//mam
		private int AddNewCustomENRValuesToDatabase(int useInfosetID, int setENRValue, string newENRTableName)
		{
			return WAM.Common.CommonTasks.CreateCustomENRTable(useInfosetID, setENRValue, use20CitiesValues, true, newENRTableName);
		}
		//</mam>

		//mam
		private void CountFacilitiesUsingENRTable()
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataTable dataTable = new DataTable();
			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);

			builder.Append("SELECT I.infoset_name, I.infoset_id, F.facility_name, F.facility_id, F.facility_usesCustomENR");
			builder.Append(" FROM Infosets I LEFT JOIN Facilities F ON I.infoset_id = F.infoset_id");

			//mam 102309 - put single quotes around true
			//builder.AppendFormat(" WHERE F.CustomENRListID = {0} AND F.facility_usesCustomENR = true", m_customENRListID);
			builder.AppendFormat(" WHERE F.CustomENRListID = {0} AND F.facility_usesCustomENR = 'true'", m_customENRListID);

			builder.Append(" ORDER BY I.infoset_name, F.facility_sortOrder, F.facility_id");

			dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
			facilitiesAffected = 0;
			if (dataTable == null)
			{
				panelTreeViewFacilityCount.Visible = false;
				labelFacilityCount.Text = "No Facilities are using these ENR values";
				treeViewFacilityCount.Nodes.Clear();
			}
			else
			{
				facilitiesAffected = dataTable.Rows.Count;
				if (facilitiesAffected > 0)
				{
					string labelText = "1 Facility is using these ENR values";
					if (facilitiesAffected > 1)
						labelText = string.Format("{0} Facilities are using these ENR values", facilitiesAffected.ToString());
					
					panelTreeViewFacilityCount.Visible = true;
					labelFacilityCount.Text = string.Format(labelText);
					PopulateTreeFacilityCount(dataTable);
				}
				else
				{
					panelTreeViewFacilityCount.Visible = false;
					labelFacilityCount.Text = "No Facilities are using these ENR values";
					treeViewFacilityCount.Nodes.Clear();
				}
			}
		}
		//</mam>

		//mam
		private void PopulateTreeFacilityCount(DataTable dataTable)
		{
			TreeNode nodeInfo = new TreeNode();
			TreeNode nodeFac = new TreeNode();
			int nodeCount = 0;
			string curInfo = "";
			string curFac = "";

			treeViewFacilityCount.BeginUpdate();
			treeViewFacilityCount.Nodes.Clear();

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				// add the current infoset
				if (dataRow["infoset_name"].ToString() != curInfo)
				{
					curInfo = dataRow["infoset_name"].ToString();
					nodeInfo = new TreeNode(curInfo);

					WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["infoset_id"], 
						curInfo, (int)NodeType.InfoSet, NodeType.InfoSet.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
					nodeInfo.Tag = treeViewItem;
					nodeInfo.ImageIndex = 1;
					nodeInfo.SelectedImageIndex = 1;
					nodeInfo.ForeColor = System.Drawing.Color.Gray;
					
					treeViewFacilityCount.Nodes.Add(nodeInfo);
				}

				// add the current facility
				if (dataRow["facility_name"].ToString() != curFac)
				{
					curFac = dataRow["facility_name"].ToString();
					nodeFac = new TreeNode(curFac);

					WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["facility_id"], 
						curFac, (int)NodeType.Facility, NodeType.Facility.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
					nodeFac.Tag = treeViewItem;
					nodeFac.ImageIndex = 0;
					nodeFac.SelectedImageIndex = 0;
					nodeFac.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);

					nodeInfo.Nodes.Add(nodeFac);
					nodeFac.Parent.Expand();
				}
			}
			treeViewFacilityCount.EndUpdate();
		}
		//</mam>

		//mam
		private void HideGrid()
		{
			panelgridCustomENRTables.Visible = false;
		}
		//</mam>

		//mam
		private void ShowHideGrid()
		{
			if (gridCustomENRTables.Rows.Count <= maxGridDropDownItems)
			{
				panelgridCustomENRTables.Height = (gridCustomENRTables.Rows[0].HeightDisplay * gridCustomENRTables.Rows.Count) + 2;
			}
			else
			{
				panelgridCustomENRTables.Height = (gridCustomENRTables.Rows[0].HeightDisplay * maxGridDropDownItems) + 2;
			}
			gridCustomENRTables.Height = panelgridCustomENRTables.Height - 2;

			panelgridCustomENRTables.Visible = !panelgridCustomENRTables.Visible;
		}
		//</mam>

		private void SaveOptions()
		{
			AppSettings.Settings.SetSetting(@"ManageCustomENRForm", "CustomENRSortCol", gridSortCol.ToString());
			AppSettings.Settings.SetSetting(@"ManageCustomENRForm", "CustomENRSortDir", gridSortDirection.ToString());
			AppSettings.Settings.SetSetting(@"ManageCustomENRForm", "CustomENRColWidth", gridCustomENRTables.Cols[1].Width.ToString());
			AppSettings.Settings.SetSetting(@"ManageCustomENRForm", "CustomENRUse20Cities", Convert.ToInt32(use20CitiesValues).ToString());
			AppSettings.Settings.Save();
		}

		//mam
		private void GetOptions()
		{
			int sortCol = 0;
			int sortDir = 0;
			int colWidth = 0;
			int use20Cities = 0;
			int sortDirAsc = (int)C1.Win.C1FlexGrid.SortFlags.Ascending;
			try
			{
				sortCol = Drive.Configuration.AppSettings.Settings.GetSettingInt("ManageCustomENRForm", "CustomENRSortCol", 1);
				sortDir = Drive.Configuration.AppSettings.Settings.GetSettingInt("ManageCustomENRForm", "CustomENRSortDir", sortDirAsc);
				colWidth = Drive.Configuration.AppSettings.Settings.GetSettingInt("ManageCustomENRForm", "CustomENRColWidth", 150);
				use20Cities = Drive.Configuration.AppSettings.Settings.GetSettingInt("ManageCustomENRForm", "CustomENRUse20Cities", 0);
			}
			catch
			{
				sortCol = 1;
				sortDir = sortDirAsc;
				colWidth = 150;
				use20Cities = 0;
			}
			
			if (sortCol != 1 && sortCol != 2)
				sortCol = 1;
			if (sortDir != sortDirAsc && sortDir != (int)C1.Win.C1FlexGrid.SortFlags.Descending)
				sortDir = sortDirAsc;
			if (use20Cities != 0 && use20Cities != 1)
				use20Cities = 0;

			if (WAM.Common.CommonTasks.IsNumericInteger(colWidth.ToString()))
			{
				if (colWidth < 0 || colWidth > 300)
				{
					colWidth = 150;
				}
			}
			else
			{
				colWidth = 150;
			}

			gridSortCol = sortCol;
			gridSortDirection = sortDir;
			gridColWidth = colWidth;
			use20CitiesValues = Convert.ToBoolean(use20Cities);
		}
		//</mam>

		//mam
		private void SetLockedENRControls()
		{
			bool enableControls = true;
			
			if (gridCustomENRTables.Row > 0)
				enableControls = !Convert.ToBoolean(((WAM.Common.ComboBoxItem)gridCustomENRTables.Rows[gridCustomENRTables.Row].UserData).ItemExtra2);

			buttonAddValue.Enabled = enableControls;
			buttonEditValue.Enabled = enableControls;
			buttonDeleteValue.Enabled = enableControls;
			labelLockedENR.Visible = !enableControls;
		}
		//</mam>

		//mam
		private bool CheckLockedENR()
		{
			return !buttonAddValue.Enabled;
		}
		//</mam>

		//mam
		private void ShowLockedENRMessage()
		{
			MessageBox.Show(this, "This ENR table is used by a locked Infoset and cannot be edited or deleted.", "Custom ENR Table", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Click Events *****/

		private void ManageCustomENRForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				if (panelgridCustomENRTables.Visible)
				{
					HideGrid();
				}
				else
				{
					this.Close();
				}
			}
		}

		private void ManageCustomENRForm_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			HideGrid();
			this.Close();
		}

		private void buttonEditValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			ENRCustom		enrRecord = GetSelectedRecord();
			int				year = 0;
			int				enrValue = 0;

			if (enrRecord == null)
				return;

			year = enrRecord.Year;
			enrValue = enrRecord.ENRValue;

			if (ENRDetailForm.ShowForm(ref year, ref enrValue, this))
			{
				int			row = gridENRValues.Row;

				//mam
				//set the enr values for the update/insert query in ENRCustom.Save()
				enrRecord.Year = year;
				enrRecord.ENRValue = enrValue;
				enrRecord.CustomENRListID = m_customENRListID;
				
				//allow Drive.Synchronization.SyncAction only if the current facility is using the 
				//	ENR values that the user is modifying
				enrRecord.AllowDriveSynchronization = (m_customENRListID == m_facility.CustomENRListID);

				//update the database with the edited ENR value
				enrRecord.UpdateDatabaseCustomENR(false);
				//</mam>
				
				gridENRValues.SetData(row, 2, enrRecord.ENRValue);
			}
		}

		private void buttonAddValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			int				year = 0;
			int				enrValue = 0;

			while (ENRDetailForm.ShowForm(ref year, ref enrValue, this))
			{
				// Check to make sure that there isn't an overlapping year
				//mam - Don't check the facility for this, because the facility may be using a different Custom ENR table;
				//	instead, check the database.  On second thought, why not just check the current ENR records?
				if (HasENRValueForYear(year))
				{
					MessageBox.Show(this,
						"The year " + year.ToString() + " already exists.", "Year Exists", MessageBoxButtons.OK, MessageBoxIcon.Information);
					year = 0;
				}
				else
				{
					//mam - not necessarily associated with current facility
					//m_facility.SetENRValueForYear(year, enrValue);
					this.SetENRValueForYear(year, enrValue);
					//</mam>

					//mam - need to get enr record that's not necessarily associated with any facility
					//ENRCustom enrRecord = m_facility.GetENRRecordForYear(year);
					ENRCustom enrRecord = GetENRRecordForYear(year);
					//</mam>

					if (enrRecord != null)
					{
						int	row = gridENRValues.Rows.Count;

						gridENRValues.Rows.Add().UserData = enrRecord;
						gridENRValues.SetData(row, 1, enrRecord.Year);
						gridENRValues.SetData(row, 2, enrRecord.ENRValue);
						gridENRValues.Sort(C1.Win.C1FlexGrid.SortFlags.Ascending, 1);
					}
					break;
				}
			}
		}

		private void buttonDeleteValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam - comment this code
//			ENRCustom		enrRecord = GetSelectedRecord();
//
//			if (enrRecord != null)
//			{
//				DialogResult result = MessageBox.Show(this,
//					"Are you sure that you want to delete the ENR value for year " + enrRecord.Year.ToString() + "?",
//					"Delete ENR Value?",
//					MessageBoxButtons.YesNo, MessageBoxIcon.Question);
//
//				if (result != DialogResult.Yes)
//					return;
//
//				this.DeleteENRValueForYear(enrRecord.Year);
//				gridENRValues.RemoveItem(gridENRValues.Row);
//			}
			//</mam>

			//mam - new code to handle multiple row deletion
			if (gridENRValues.Rows.Count <= gridENRValues.Rows.Fixed)
				return;

			ENRCustom enrRecord;
			C1.Win.C1FlexGrid.CellRange selectedRange = gridENRValues.Selection;
			selectedRange.Normalize();

			int selCount = selectedRange.BottomRow - selectedRange.TopRow + 1;
			if (selCount < 1)
				return;

			int topRow = selectedRange.TopRow;
			string msgText = "";

			if (selCount == 1)
			{
				enrRecord = GetSelectedRecordForGivenRow(topRow);
				msgText = string.Format("Are you sure that you want to delete the ENR value for year {0}?", enrRecord.Year.ToString());
			}
			else
			{
				msgText = string.Format("Are you sure that you want to delete these {0} ENR values?", selCount.ToString());
			}
			DialogResult result = MessageBox.Show(this, msgText, "Delete ENR Values", 
				MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

			if (result != DialogResult.Yes)
				return;

			for (int i = topRow; i <= selectedRange.BottomRow; i++)
			{
				enrRecord = GetSelectedRecordForGivenRow(topRow);
				this.DeleteENRValueForYear(enrRecord.Year);
				gridENRValues.RemoveItem(topRow);
			}
			//</mam>
		}
		
		//mam
		private void pictureBoxToolbarAdd_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//add a new ENR table
			HideGrid();

			int useInfosetID = 0;
			string curNameENR = "New ENR Table";

			if (ENRDetailFormCopy.ShowForm(ref curNameENR, ref use20CitiesValues, "Name for new ENR table:", m_customENRListID, this))
			{
				this.Refresh();
				try
				{
					this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

					if (InfoSet.IsFixed)
					{
					}
					else
					{
						useInfosetID = InfoSet.CurrentID;
					}
					//if (UpdateDatabaseForCustomENR(executeStatement, false, true))
					m_customENRListID = AddNewCustomENRValuesToDatabase(useInfosetID, 0, Drive.SQL.PadString(curNameENR));
					if (m_customENRListID == 0)
					{
						SetCustomENRListIDFromGridRow(gridCustomENRTables.Row);
					}
					{
						PopulateCustomENRGrid();
					}
				}
				catch
				{}
				finally
				{
					this.Cursor = System.Windows.Forms.Cursors.Default;
				}
			}
		}
		//</mam>

		//mam
		private void pictureBoxToolbarCopy_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to copy data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//copy the selected ENR table and all of its values

			HideGrid();

			string curNameENR = string.Format(@"Copy of {0}", textBoxSelectedCustomENRTable.Text);
			string executeStatement = "";
			
			if (ENRDetailFormCopy.ShowForm(ref curNameENR, "Name for ENR copy:", m_customENRListID, this))
			{
				this.Refresh();
				try
				{
					if (InfoSet.IsFixed)
					{
						executeStatement = string.Format(
							@"INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", "null", Drive.SQL.PadString(curNameENR));
					}
					else
					{
						executeStatement = string.Format(
							@"INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", InfoSet.CurrentID, Drive.SQL.PadString(curNameENR));
					}
					if (UpdateDatabaseForCustomENR(executeStatement, true, false))
					{
						PopulateCustomENRGrid();
					}
				}
				catch
				{}
				finally
				{
					this.Cursor = System.Windows.Forms.Cursors.Default;
				}
			}
		}
		//</mam>

		//mam
		private void pictureBoxToolbarEdit_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//change the name of the ENR table

			HideGrid();

			if (CheckLockedENR())
			{
				ShowLockedENRMessage();
				return;
			}

			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
			string curNameENR = textBoxSelectedCustomENRTable.Text;

			if (ENRDetailFormCopy.ShowForm(ref curNameENR, "New name for ENR table:", m_customENRListID, this))
			{
				try
				{
					builder.AppendFormat(@"UPDATE CustomENRList SET CustomENRListName = '{0}'", Drive.SQL.PadString(curNameENR));
					builder.AppendFormat(" WHERE CustomENRListID = {0}", m_customENRListID);
					UpdateDatabaseForCustomENR(builder.ToString(), false, false);
					PopulateCustomENRGrid();
				}
				catch
				{}
			}
		}
		//</mam>

		//mam
		private void pictureBoxToolbarDelete_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//delete the entire ENR table

			HideGrid();

			if (CheckLockedENR())
			{
				ShowLockedENRMessage();
				return;
			}
			
			int selectedRow = gridCustomENRTables.Row;

			if (selectedRow >= gridCustomENRTables.Rows.Count - gridCustomENRTables.Rows.Fixed)
				selectedRow--;
			else	
				selectedRow++;

			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
			string labelText = "Facilities";
			if (facilitiesAffected == 1)
				labelText = "Facility";

			builder.AppendFormat("Deleting this ENR Table will affect {0} {1}.", facilitiesAffected, labelText);
			builder.AppendFormat("\r\rAre you sure that you want to delete the ENR table '{0}?'", textBoxSelectedCustomENRTable.Text.ToString());

			if (gridCustomENRTables.Row > gridCustomENRTables.Rows.Fixed - 1)
			{
				DialogResult result = MessageBox.Show(this, builder.ToString(), "Delete ENR Table?", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
				if (result != DialogResult.Yes)
					return;
				this.Refresh();

				//If any facility (in any infoset) uses the custom ENR table that is to be deleted, update the cache for those 
				//	facilities (this is necessary (rather than just updating the database) because as the user clicks on each  
				//	facility in the tree, the facility's data is loaded from the cache, not from the database.
				//	Facilities in other infosets are not in the cache, so updating the database for those facilities is satisfactory.
				Facility[] facilities = CacheManager.GetFacilities(InfoSet.CurrentID);
				foreach (Facility facility in facilities)
				{
					if (facility.CustomENRListID == m_customENRListID)
					{
						facility.CustomENRListID = 0;
						facility.UsesCustomENRTable = false;
					}
				}

				//mam 102309 - put single quotes around false
				//if (UpdateDatabaseForCustomENR(string.Format(@"UPDATE Facilities SET CustomENRListID = null, facility_usesCustomENR = false WHERE CustomENRListID = {0}", m_customENRListID), false, false))
				if (UpdateDatabaseForCustomENR(string.Format(@"UPDATE Facilities SET CustomENRListID = null, facility_usesCustomENR = 'false' WHERE CustomENRListID = {0}", m_customENRListID), false, false))
				{
					try
					{
						UpdateDatabaseForCustomENR(string.Format(@"DELETE FROM CustomENRList WHERE CustomENRListID = {0}", m_customENRListID), false, false);
						SetCustomENRListIDFromGridRow(selectedRow);
						PopulateCustomENRGrid();
					}
					catch
					{}
				}
			}
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			HideGrid();
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "EditCustomENRTable.htm");
		}

		private void checkBoxShowENRThisInfosetOnly_CheckedChanged(object sender, System.EventArgs e)
		{
			//this code is not used
//			if (checkBoxShowENRThisInfosetOnly.Checked)
//			{
//				rememberCustomENRListID = m_customENRListID;
//			}
//			else
//			{
//				m_customENRListID = rememberCustomENRListID;
//			}
//
//			PopulateCustomENRGrid();
		}

		private void gridCustomENRTables_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (gridCustomENRTables.MouseRow > 0 && !justResizedColumn)
			{
				WAM.Common.ComboBoxItem gridItemDropDown = GetSelectedRecordENRTableGrid();
				m_customENRListID = gridItemDropDown.ItemID;
				textBoxSelectedCustomENRTable.Text = gridItemDropDown.ItemDescription;

				LoadENRList();
				CountFacilitiesUsingENRTable();
				SetLockedENRControls();

				HideGrid();
			}

			justResizedColumn = false;
		}

		private void gridCustomENRTables_AfterResizeColumn(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			justResizedColumn = true;
			gridColWidth = gridCustomENRTables.Cols[1].Width;
		}

		private void gridCustomENRTables_AfterSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
		{
			gridSortCol = e.Col;
			gridSortDirection = (int)e.Order;
		}

		private void treeViewFacilityCount_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			HideGrid();
		}

		private void gridENRValues_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void panelToolbar_Click(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void pictureBoxShowGrid_Click(object sender, System.EventArgs e)
		{
			ShowHideGrid();
		}

		private void textBoxSelectedCustomENRTable_TextChanged(object sender, System.EventArgs e)
		{
			HideGrid();
		}

		private void textBoxSelectedCustomENRTable_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			textBoxSelectedCustomENRTable.SelectionStart = 0;
			textBoxSelectedCustomENRTable.SelectionLength = textBoxSelectedCustomENRTable.Text.Length;
			ShowHideGrid();
		}

		#endregion /***** Click Events *****/


	}
}