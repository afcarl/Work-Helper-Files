using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for Manage20CitiesENRForm.
	/// </summary>
	public class Manage20CitiesENRForm : System.Windows.Forms.Form
	{
		private C1.Win.C1FlexGrid.C1FlexGrid gridENRValues;
		private System.Windows.Forms.Button buttonAddValue;
		private System.Windows.Forms.Button buttonEditValue;
		private System.Windows.Forms.Button buttonDeleteValue;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Manage20CitiesENRForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Manage20CitiesENRForm));
			this.gridENRValues = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.buttonAddValue = new System.Windows.Forms.Button();
			this.buttonEditValue = new System.Windows.Forms.Button();
			this.buttonDeleteValue = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.label2 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.gridENRValues)).BeginInit();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// gridENRValues
			// 
			this.gridENRValues.AllowEditing = false;
			this.gridENRValues.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.gridENRValues.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.gridENRValues.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.gridENRValues.ColumnInfo = @"3,1,0,0,0,85,Columns:0{Width:25;Visible:False;}	1{Width:94;AllowSorting:False;Caption:""Year"";AllowResizing:False;DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	2{Width:25;AllowSorting:False;Caption:""ENR Value"";AllowResizing:False;DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	";
			this.gridENRValues.ExtendLastCol = true;
			this.gridENRValues.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridENRValues.Location = new System.Drawing.Point(1, 1);
			this.gridENRValues.Name = "gridENRValues";
			this.gridENRValues.Rows.Count = 1;
			this.gridENRValues.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.RowRange;
			this.gridENRValues.Size = new System.Drawing.Size(206, 377);
			this.gridENRValues.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Alternate{BackColor:245, 244, 235;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridENRValues.TabIndex = 0;
			// 
			// buttonAddValue
			// 
			this.buttonAddValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddValue.Location = new System.Drawing.Point(226, 44);
			this.buttonAddValue.Name = "buttonAddValue";
			this.buttonAddValue.Size = new System.Drawing.Size(92, 23);
			this.buttonAddValue.TabIndex = 1;
			this.buttonAddValue.Text = "&Add Value";
			this.buttonAddValue.Click += new System.EventHandler(this.buttonAddValue_Click);
			// 
			// buttonEditValue
			// 
			this.buttonEditValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditValue.Location = new System.Drawing.Point(226, 76);
			this.buttonEditValue.Name = "buttonEditValue";
			this.buttonEditValue.Size = new System.Drawing.Size(92, 23);
			this.buttonEditValue.TabIndex = 2;
			this.buttonEditValue.Text = "&Edit Value";
			this.buttonEditValue.Click += new System.EventHandler(this.buttonEditValue_Click);
			// 
			// buttonDeleteValue
			// 
			this.buttonDeleteValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonDeleteValue.Location = new System.Drawing.Point(226, 108);
			this.buttonDeleteValue.Name = "buttonDeleteValue";
			this.buttonDeleteValue.Size = new System.Drawing.Size(92, 23);
			this.buttonDeleteValue.TabIndex = 3;
			this.buttonDeleteValue.Text = "&Remove Value";
			this.buttonDeleteValue.Click += new System.EventHandler(this.buttonDeleteValue_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(226, 400);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(92, 23);
			this.buttonClose.TabIndex = 4;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(295, 10);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 96;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label2.Location = new System.Drawing.Point(7, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(209, 28);
			this.label2.TabIndex = 157;
			this.label2.Text = "20 Cities ENR Values";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Controls.Add(this.gridENRValues);
			this.panel3.Location = new System.Drawing.Point(9, 44);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(208, 379);
			this.panel3.TabIndex = 158;
			// 
			// Manage20CitiesENRForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonClose;
			this.ClientSize = new System.Drawing.Size(324, 430);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.buttonDeleteValue);
			this.Controls.Add(this.buttonEditValue);
			this.Controls.Add(this.buttonAddValue);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "Edit20CitiesENRTable.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Manage20CitiesENRForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "20 Cities ENR Table";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Manage20CitiesENRForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Manage20CitiesENRForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.gridENRValues)).EndInit();
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowForm(Form owner)
		{
			Manage20CitiesENRForm form = new Manage20CitiesENRForm();

			form.ShowDialog(owner);
			form.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			LoadENRList();

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		private void		LoadENRList()
		{
			ENR20Cities[]	enrRecords = ENR20CitiesCache.GetAllENRValues();
			ENR20Cities		enrRecord;
			int				row = 1;

			gridENRValues.Redraw = false;
			gridENRValues.Rows.Count = 1;
			for (int pos = 0; pos < enrRecords.Length; pos++)
			{
				enrRecord = enrRecords[pos];
				gridENRValues.Rows.Add().UserData = enrRecord;
				gridENRValues.SetData(row, 1, enrRecord.Year);
				gridENRValues.SetData(row, 2, enrRecord.ENRValue);
				row++;
			}
			gridENRValues.Redraw = true;
		}

		private void buttonAddValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			int				year = 0;
			int				enrValue = 0;

			while (ENRDetailForm.ShowForm(ref year, ref enrValue, this))
			{
				// Check to make sure that there isn't an overlapping year
				if (ENR20CitiesCache.HasENRValueForYear(year))
				{
					MessageBox.Show(this,
						"An ENR value already exists for that year.",
						"ENR Value Exists");
					year = 0;
				}
				else
				{
					ENR20CitiesCache.SetENRValueForYear(year, enrValue);
					ENR20Cities enrRecord = ENR20CitiesCache.GetENRRecordForYear(year);

					if (enrRecord != null)
					{
						int	row = gridENRValues.Rows.Count;

						gridENRValues.Rows.Add().UserData = enrRecord;
						gridENRValues.SetData(row, 1, enrRecord.Year);
						gridENRValues.SetData(row, 2, enrRecord.ENRValue);
						gridENRValues.Sort(C1.Win.C1FlexGrid.SortFlags.Ascending, 1);
					}
					break;
				}
			}
		}

		private ENR20Cities GetSelectedRecord()
		{
			ENR20Cities		enrRecord = null;

			if (gridENRValues.Row >= gridENRValues.Rows.Fixed)
				enrRecord = gridENRValues.Rows[gridENRValues.Row].UserData as ENR20Cities;

			return enrRecord;
		}

		private void buttonEditValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			ENR20Cities		enrRecord = GetSelectedRecord();
			int				year = 0;
			int				enrValue = 0;

			if (enrRecord == null)
				return;

			year = enrRecord.Year;
			enrValue = enrRecord.ENRValue;

			if (ENRDetailForm.ShowForm(ref year, ref enrValue, this))
			{
				int			row = gridENRValues.Row;

				ENR20CitiesCache.SetENRValueForYear(year, enrValue);
				gridENRValues.SetData(row, 2, enrRecord.ENRValue);
			}
		}

		private void buttonDeleteValue_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam - comment this code
//			ENR20Cities		enrRecord = GetSelectedRecord();
//
//			if (enrRecord != null)
//			{
//				DialogResult result = MessageBox.Show(this,
//					"Are you sure that you want to delete the selected ENR value?",
//					"Delete ENR Value?",
//					MessageBoxButtons.YesNo, MessageBoxIcon.Question);
//
//				if (result != DialogResult.Yes)
//					return;
//
//				ENR20CitiesCache.DeleteENRValueForYear(enrRecord.Year);
//				gridENRValues.RemoveItem(gridENRValues.Row);
//			}

			//mam - new code to handle multiple row deletion
			if (gridENRValues.Rows.Count <= gridENRValues.Rows.Fixed)
				return;

			ENR20Cities enrRecord;
			C1.Win.C1FlexGrid.CellRange selectedRange = gridENRValues.Selection;
			selectedRange.Normalize();

			int selCount = selectedRange.BottomRow - selectedRange.TopRow + 1;
			if (selCount < 1)
				return;

			int topRow = selectedRange.TopRow;
			string msgText = "";

			if (selCount == 1)
			{
				enrRecord = GetSelectedRecordForGivenRow(topRow);
				msgText = string.Format("Are you sure that you want to delete the ENR value for year {0}?", enrRecord.Year.ToString());
			}
			else
			{
				msgText = string.Format("Are you sure that you want to delete these {0} ENR values?", selCount.ToString());
			}
			DialogResult result = MessageBox.Show(this, msgText, "Delete ENR Values", 
				MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

			if (result != DialogResult.Yes)
				return;

			for (int i = topRow; i <= selectedRange.BottomRow; i++)
			{
				enrRecord = GetSelectedRecordForGivenRow(topRow);
				ENR20CitiesCache.DeleteENRValueForYear(enrRecord.Year);
				gridENRValues.RemoveItem(topRow);
			}
			//</mam>
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void Manage20CitiesENRForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "Edit20CitiesENRTable.htm");
		}

		private void Manage20CitiesENRForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.Close();
			}
		}

		//mam
		private ENR20Cities GetSelectedRecordForGivenRow(int forRow)
		{
			ENR20Cities enrRecord = null;

			if (forRow >= gridENRValues.Rows.Fixed)
				enrRecord = gridENRValues.Rows[forRow].UserData as ENR20Cities;

			return enrRecord;
		}
		//</mam>

	}
}