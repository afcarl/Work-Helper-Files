//mam 102309

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for NewObjectNameForm.
	/// </summary>
	public class NewObjectNameForm : System.Windows.Forms.Form
	{
		private NodeType	m_type;

		//mam 03202012
		private int infosetId = 0;
		private int facilityId = 0;

		private System.Windows.Forms.Label labelName;
		private System.Windows.Forms.TextBox textBoxName;
		private System.Windows.Forms.Button buttonAccept;
		private System.Windows.Forms.Button buttonCancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public NewObjectNameForm(NodeType type)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_type = type;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(NewObjectNameForm));
			this.labelName = new System.Windows.Forms.Label();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.buttonAccept = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// labelName
			// 
			this.labelName.BackColor = System.Drawing.Color.Transparent;
			this.labelName.Location = new System.Drawing.Point(8, 8);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(304, 16);
			this.labelName.TabIndex = 0;
			this.labelName.Text = "Please enter the name of the new ";
			// 
			// textBoxName
			// 
			this.textBoxName.Location = new System.Drawing.Point(8, 28);
			this.textBoxName.MaxLength = 255;
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(300, 20);
			this.textBoxName.TabIndex = 1;
			this.textBoxName.Text = "";
			// 
			// buttonAccept
			// 
			this.buttonAccept.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAccept.Location = new System.Drawing.Point(149, 58);
			this.buttonAccept.Name = "buttonAccept";
			this.buttonAccept.TabIndex = 2;
			this.buttonAccept.Text = "&Accept";
			this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(234, 58);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			// 
			// NewObjectNameForm
			// 
			this.AcceptButton = this.buttonAccept;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(316, 88);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonAccept);
			this.Controls.Add(this.textBoxName);
			this.Controls.Add(this.labelName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "NewObjectNameForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NewObjectNameForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.NewObjectNameForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		//mam 03202012 - added infosetId, facilityId
		//public static string ShowForm(NodeType type, string startString, Form owner)
		public static string ShowForm(NodeType type, string startString, int infosetId, int facilityId, Form owner)
		{
			NewObjectNameForm form = new NewObjectNameForm(type);

			try
			{
				form.textBoxName.Text = startString;

				//mam 03202012
				form.infosetId = infosetId;
				form.facilityId = facilityId;

				if (form.ShowDialog(owner) == DialogResult.OK)
					return form.textBoxName.Text;
			}
			finally
			{
				form.Dispose(true);
			}

			return startString;
		}

		protected override void OnClosing(CancelEventArgs e)
		{
//			// Save our form state
//			Drive.Configuration.FormState formState = 
//				new Drive.Configuration.FormState(this);
//
//			Drive.Configuration.AppSettings.Settings.
//				SetSetting(@"ScreenSettings", 
//				this.Name, formState.ToString());

			base.OnClosing(e);
		}

		protected override void OnLoad(EventArgs e)
		{
//			Drive.Configuration.FormState formState = 
//				new Drive.Configuration.FormState(
//				Drive.Configuration.AppSettings.
//				Settings.GetSetting("ScreenSettings",
//				this.Name));
//			formState.RestoreLocation(this);

			string			typeString = 
				NodeTypeHandler.GetNodeTypeString(m_type);

			if (textBoxName.Text.Length == 0)
				this.Text = string.Format("Add {0}", typeString);
			else
				this.Text = string.Format("Edit {0}", typeString);

			this.labelName.Text = 
				string.Format("Please enter the name of the new {0}:", typeString);

			base.OnLoad(e);
		}

		private void buttonAccept_Click(object sender, System.EventArgs e)
		{
			if (textBoxName.Text.Length <= 0)
			{
				MessageBox.Show(this, 
					"Please enter a name.", "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxName.Focus();
				return;
			}

			//******************************
			//mam 03202012
			if (m_type == NodeType.Facility)
			{
				WAM.Data.Facility[] facilities = WAM.Data.CacheManager.GetFacilities(infosetId);
				for (int x = 0; x < facilities.Length; x++)
				{
					if (string.Compare(facilities[x].Name.Trim(), textBoxName.Text.Trim(), true) == 0)
					{
						MessageBox.Show(this, "There is already a Facility with the name  '" 
							+ textBoxName.Text.Trim() + ".'"
							+ Environment.NewLine + Environment.NewLine + "Please enter a different name."
							, "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
						textBoxName.Focus();
						return;
					}
				}
			}
			else if (m_type == NodeType.TreatmentProcess)
			{
				WAM.Data.TreatmentProcess[] processes = WAM.Data.CacheManager.GetProcesses(infosetId, facilityId);
				for (int x = 0; x < processes.Length; x++)
				{
					if (string.Compare(processes[x].Name.Trim(), textBoxName.Text.Trim(), true) == 0)
					{
						MessageBox.Show(this, "There is already a Process with the name  '" 
							+ textBoxName.Text.Trim() + "'  in the Facility."
							+ Environment.NewLine + Environment.NewLine + "Please enter a different name."
							, "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
						textBoxName.Focus();
						return;
					}
				}
			}
			//******************************

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void NewObjectNameForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void NewObjectNameForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}
