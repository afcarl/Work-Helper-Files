using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Drive.Data.OleDb;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for DatabaseCompact.
	/// </summary>
	public class DatabaseCompact : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.ComboBox comboBoxDatabase;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.CheckBox checkBoxMakeBackupCopy;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Panel panelMakeBackupCopy;
		private System.Windows.Forms.Panel panelMakeBackupCopyContainer;

		private System.IO.DirectoryInfo appDirectory;
		private double fileSizeBeforeCompacting = 0;
		private string fileToCompactNoPath = "";
		private string fileNameBackup = "";
		private bool preventComboSelectedIndexChange = false;
		private System.Windows.Forms.Label labelDatabaseSizeBeforeCompacting;
		private System.Windows.Forms.Label labelDatabaseSizeAfterCompacting;
		private System.Windows.Forms.Label labelDatabaseSizeAfter;
		private System.Windows.Forms.Label labelDatabaseSizeBefore;
		private System.Windows.Forms.Label labelBackupFileName1;
		private System.Windows.Forms.Panel panelSeparator1;
		private System.Windows.Forms.Label labelBackupFileName2;
		private System.Windows.Forms.Label labelCompactingStatus;
		string fileToCompactWithPath = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public DatabaseCompact()
		{
			InitializeComponent();
			LoadChores();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(DatabaseCompact));
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.comboBoxDatabase = new System.Windows.Forms.ComboBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.checkBoxMakeBackupCopy = new System.Windows.Forms.CheckBox();
			this.panelMakeBackupCopy = new System.Windows.Forms.Panel();
			this.labelBackupFileName2 = new System.Windows.Forms.Label();
			this.panelSeparator1 = new System.Windows.Forms.Panel();
			this.labelBackupFileName1 = new System.Windows.Forms.Label();
			this.labelDatabaseSizeBeforeCompacting = new System.Windows.Forms.Label();
			this.labelDatabaseSizeAfterCompacting = new System.Windows.Forms.Label();
			this.labelDatabaseSizeAfter = new System.Windows.Forms.Label();
			this.labelDatabaseSizeBefore = new System.Windows.Forms.Label();
			this.panelMakeBackupCopyContainer = new System.Windows.Forms.Panel();
			this.labelCompactingStatus = new System.Windows.Forms.Label();
			this.panelMakeBackupCopy.SuspendLayout();
			this.panelMakeBackupCopyContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(371, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 99;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label1.Location = new System.Drawing.Point(10, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(246, 24);
			this.label1.TabIndex = 98;
			this.label1.Text = "Select a database to compact";
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(240, 274);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 96;
			this.buttonOK.Text = "&Compact";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(321, 274);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 97;
			this.buttonCancel.Text = "Close";
			// 
			// comboBoxDatabase
			// 
			this.comboBoxDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxDatabase.DropDownWidth = 273;
			this.comboBoxDatabase.Location = new System.Drawing.Point(13, 40);
			this.comboBoxDatabase.Name = "comboBoxDatabase";
			this.comboBoxDatabase.Size = new System.Drawing.Size(378, 21);
			this.comboBoxDatabase.Sorted = true;
			this.comboBoxDatabase.TabIndex = 95;
			this.comboBoxDatabase.SelectedIndexChanged += new System.EventHandler(this.comboBoxDatabase_SelectedIndexChanged);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// checkBoxMakeBackupCopy
			// 
			this.checkBoxMakeBackupCopy.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxMakeBackupCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBoxMakeBackupCopy.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.checkBoxMakeBackupCopy.Location = new System.Drawing.Point(15, 65);
			this.checkBoxMakeBackupCopy.Name = "checkBoxMakeBackupCopy";
			this.checkBoxMakeBackupCopy.Size = new System.Drawing.Size(251, 23);
			this.checkBoxMakeBackupCopy.TabIndex = 100;
			this.checkBoxMakeBackupCopy.Text = "Make a backup copy before compacting";
			this.checkBoxMakeBackupCopy.CheckedChanged += new System.EventHandler(this.checkBoxMakeBackupCopy_CheckedChanged);
			// 
			// panelMakeBackupCopy
			// 
			this.panelMakeBackupCopy.BackColor = System.Drawing.SystemColors.Control;
			this.panelMakeBackupCopy.Controls.Add(this.labelBackupFileName2);
			this.panelMakeBackupCopy.Controls.Add(this.panelSeparator1);
			this.panelMakeBackupCopy.Controls.Add(this.labelBackupFileName1);
			this.panelMakeBackupCopy.Controls.Add(this.labelDatabaseSizeBeforeCompacting);
			this.panelMakeBackupCopy.Controls.Add(this.labelDatabaseSizeAfterCompacting);
			this.panelMakeBackupCopy.Controls.Add(this.labelDatabaseSizeAfter);
			this.panelMakeBackupCopy.Controls.Add(this.labelDatabaseSizeBefore);
			this.panelMakeBackupCopy.Location = new System.Drawing.Point(1, 1);
			this.panelMakeBackupCopy.Name = "panelMakeBackupCopy";
			this.panelMakeBackupCopy.Size = new System.Drawing.Size(376, 62);
			this.panelMakeBackupCopy.TabIndex = 106;
			this.panelMakeBackupCopy.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMakeBackupCopy_Paint);
			// 
			// labelBackupFileName2
			// 
			this.labelBackupFileName2.BackColor = System.Drawing.Color.Transparent;
			this.labelBackupFileName2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelBackupFileName2.Location = new System.Drawing.Point(24, 96);
			this.labelBackupFileName2.Name = "labelBackupFileName2";
			this.labelBackupFileName2.Size = new System.Drawing.Size(328, 40);
			this.labelBackupFileName2.TabIndex = 115;
			// 
			// panelSeparator1
			// 
			this.panelSeparator1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator1.Location = new System.Drawing.Point(16, 62);
			this.panelSeparator1.Name = "panelSeparator1";
			this.panelSeparator1.Size = new System.Drawing.Size(344, 1);
			this.panelSeparator1.TabIndex = 114;
			// 
			// labelBackupFileName1
			// 
			this.labelBackupFileName1.BackColor = System.Drawing.Color.Transparent;
			this.labelBackupFileName1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelBackupFileName1.Location = new System.Drawing.Point(10, 75);
			this.labelBackupFileName1.Name = "labelBackupFileName1";
			this.labelBackupFileName1.Size = new System.Drawing.Size(179, 16);
			this.labelBackupFileName1.TabIndex = 113;
			this.labelBackupFileName1.Text = "Backup file name:";
			// 
			// labelDatabaseSizeBeforeCompacting
			// 
			this.labelDatabaseSizeBeforeCompacting.BackColor = System.Drawing.Color.Transparent;
			this.labelDatabaseSizeBeforeCompacting.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelDatabaseSizeBeforeCompacting.Location = new System.Drawing.Point(10, 11);
			this.labelDatabaseSizeBeforeCompacting.Name = "labelDatabaseSizeBeforeCompacting";
			this.labelDatabaseSizeBeforeCompacting.Size = new System.Drawing.Size(179, 16);
			this.labelDatabaseSizeBeforeCompacting.TabIndex = 109;
			this.labelDatabaseSizeBeforeCompacting.Text = "Database size before compacting:";
			// 
			// labelDatabaseSizeAfterCompacting
			// 
			this.labelDatabaseSizeAfterCompacting.BackColor = System.Drawing.Color.Transparent;
			this.labelDatabaseSizeAfterCompacting.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelDatabaseSizeAfterCompacting.Location = new System.Drawing.Point(10, 37);
			this.labelDatabaseSizeAfterCompacting.Name = "labelDatabaseSizeAfterCompacting";
			this.labelDatabaseSizeAfterCompacting.Size = new System.Drawing.Size(179, 16);
			this.labelDatabaseSizeAfterCompacting.TabIndex = 110;
			this.labelDatabaseSizeAfterCompacting.Text = "Database size after compacting:";
			this.labelDatabaseSizeAfterCompacting.Visible = false;
			// 
			// labelDatabaseSizeAfter
			// 
			this.labelDatabaseSizeAfter.BackColor = System.Drawing.Color.Transparent;
			this.labelDatabaseSizeAfter.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelDatabaseSizeAfter.Location = new System.Drawing.Point(186, 37);
			this.labelDatabaseSizeAfter.Name = "labelDatabaseSizeAfter";
			this.labelDatabaseSizeAfter.Size = new System.Drawing.Size(104, 16);
			this.labelDatabaseSizeAfter.TabIndex = 112;
			this.labelDatabaseSizeAfter.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.labelDatabaseSizeAfter.Visible = false;
			// 
			// labelDatabaseSizeBefore
			// 
			this.labelDatabaseSizeBefore.BackColor = System.Drawing.Color.Transparent;
			this.labelDatabaseSizeBefore.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelDatabaseSizeBefore.Location = new System.Drawing.Point(186, 11);
			this.labelDatabaseSizeBefore.Name = "labelDatabaseSizeBefore";
			this.labelDatabaseSizeBefore.Size = new System.Drawing.Size(104, 16);
			this.labelDatabaseSizeBefore.TabIndex = 111;
			this.labelDatabaseSizeBefore.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// panelMakeBackupCopyContainer
			// 
			this.panelMakeBackupCopyContainer.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelMakeBackupCopyContainer.Controls.Add(this.panelMakeBackupCopy);
			this.panelMakeBackupCopyContainer.Location = new System.Drawing.Point(13, 105);
			this.panelMakeBackupCopyContainer.Name = "panelMakeBackupCopyContainer";
			this.panelMakeBackupCopyContainer.Size = new System.Drawing.Size(378, 64);
			this.panelMakeBackupCopyContainer.TabIndex = 107;
			// 
			// labelCompactingStatus
			// 
			this.labelCompactingStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelCompactingStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelCompactingStatus.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelCompactingStatus.Location = new System.Drawing.Point(16, 187);
			this.labelCompactingStatus.Name = "labelCompactingStatus";
			this.labelCompactingStatus.Size = new System.Drawing.Size(368, 24);
			this.labelCompactingStatus.TabIndex = 111;
			this.labelCompactingStatus.Text = "Compacting.  Please wait...";
			this.labelCompactingStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCompactingStatus.Visible = false;
			// 
			// DatabaseCompact
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(402, 304);
			this.Controls.Add(this.labelCompactingStatus);
			this.Controls.Add(this.panelMakeBackupCopyContainer);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.comboBoxDatabase);
			this.Controls.Add(this.checkBoxMakeBackupCopy);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "DatabaseCompact";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.Text = "DatabaseCompact";
			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.DatabaseLoad_Paint);
			this.panelMakeBackupCopy.ResumeLayout(false);
			this.panelMakeBackupCopyContainer.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		private void LoadChores()
		{
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.Text = "Compact Database";
			this.checkBoxMakeBackupCopy.Checked = true;
			this.buttonOK.Enabled = false;
			SetStatusControls(false, false);

			appDirectory = new System.IO.DirectoryInfo(@Drive.IO.Directory.GetApplicationPath());
			PopulateComboBox();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		private void PopulateComboBox()
		{
			comboBoxDatabase.Items.Clear();

			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();

			foreach (System.IO.FileInfo f in appDirectory.GetFiles("*.mdb"))
			{
				if (verify.VerifyTables(f.Name))
					comboBoxDatabase.Items.Add(f.Name);
			}
			if (comboBoxDatabase.Items.Count > 0)
			{
				this.buttonOK.Enabled = true;
				comboBoxDatabase.SelectedIndex = 0;
			}
			else
			{
				comboBoxDatabase.Text = "There are no databases to compact";
			}
		}

		//set which item is displayed in the combo box based on its name
		public void SetComboIndex(ComboBox comboBox, string comboBoxItemName)
		{
			if (comboBox == null)
				return;

			for (int i = 0; i < comboBox.Items.Count; i++)
			{
				//if (((WAM.Common.ComboBoxItem)comboBox.Items[i]).ItemID == comboBoxID)
				if (comboBox.Items[i].ToString() == comboBoxItemName)
				{
					comboBox.SelectedIndex = i;
					break;
				}
			}
		}

		private void DatabaseLoad_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void panelMakeBackupCopy_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private string GetBackupFileName()
		{
			//find an allowable file name for the backup copy
			int fileCounter = 1;
			int extensionLocation = fileToCompactNoPath.LastIndexOf(".");
			string fileExtension = fileToCompactNoPath.Substring(extensionLocation, fileToCompactNoPath.Length - extensionLocation);
			string fileBackupNoExtension = string.Format("Backup{0}", fileToCompactNoPath.Substring(0, extensionLocation));
			string curDate = string.Format("{0}{1}{2}", DateTime.Now.Month.ToString("00"), DateTime.Now.Day.ToString("00"), DateTime.Now.Year.ToString());
			fileBackupNoExtension = string.Format("{0}{1}", fileBackupNoExtension, curDate);
			string fileBackupWithPath = string.Format(@"{0}\{1}{2}", appDirectory, fileBackupNoExtension, fileExtension);

			try
			{
				while (System.IO.File.Exists(fileBackupWithPath))
				{
					fileBackupWithPath = string.Format(@"{0}\{1}_{2}{3}", appDirectory, fileBackupNoExtension, fileCounter++, fileExtension);
				}
				return fileBackupWithPath;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return "";
			}
		}

		private bool CompactDatabase()
		{
			int fileCounter = 1;
			string fileToCompactNoPath = comboBoxDatabase.Text;
			string fileToCompactWithPath = string.Format(@"{0}\{1}", appDirectory, comboBoxDatabase.Text);

			//make sure file exists
			if (!System.IO.File.Exists(fileToCompactWithPath))
			{
				MessageBox.Show(string.Format("The database file  '{0}'  cannot be found.", comboBoxDatabase.Text), "Compact Database", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			//****************

			int extensionLocation = fileToCompactNoPath.LastIndexOf(".");
			string fileExtension = fileToCompactNoPath.Substring(extensionLocation, fileToCompactNoPath.Length - extensionLocation);
			string fileBackupWithPath = fileNameBackup;
			if (fileBackupWithPath.Length == 0)
			{
				MessageBox.Show("An error occurred.  The compacting of the database failed on backup file name creation.", "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}

			//****************

			//make the backup copy, whether or not the user wants it
			//(it will be used to restore from, if an error occurs during compacting)
			try
			{
				System.IO.File.Copy(fileToCompactWithPath, fileBackupWithPath);
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());

				MessageBox.Show("An error occurred.  The compacting of the database failed on backup creation.", "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}

			//****************

			//find an allowable temporary file name for the compactor to create
			fileCounter = 0;
			string tempFileNameWithPathToCompactTo = string.Format(@"{0}\{1}{2}{3}", appDirectory, "zBackupTempFileName", fileCounter++, fileExtension);

			try
			{
				while (System.IO.File.Exists(tempFileNameWithPathToCompactTo))
				{
					tempFileNameWithPathToCompactTo = string.Format(@"{0}\{1}{2}{3}", appDirectory, "zBackupTempFileName", fileCounter++, fileExtension);
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());

				MessageBox.Show("An error occurred.  The compacting of the database failed on compactor file name creation.", "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}

			//****************

			//get the source string of the file to compact
			Jet40DataSource dataSource = new Jet40DataSource(fileToCompactWithPath);
			//add a password to the dataSource, if necessary
			dataSource.Provider = WAM.Data.WAMSource.CheckSourceConnection(dataSource.ConnectionString, dataSource.Provider);

			labelCompactingStatus.Visible = true;
			this.Refresh();
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			//call the compactor
			bool result = WAM.Common.CompactJetDatabase.CompactAccessDB(dataSource.ConnectionString, @fileToCompactWithPath, tempFileNameWithPathToCompactTo);

			labelCompactingStatus.Visible = false;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			SetStatusMessage(result);
			this.Refresh();

			if (result)
			{
				//compacting was successful, so remove the backup copy if the user didn't want it
				try
				{
					this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
					if (!checkBoxMakeBackupCopy.Checked)
						System.IO.File.Delete(fileBackupWithPath);

					string curComboBoxText = comboBoxDatabase.Text;

					//rather than reloading the combo box, which can drag if there are many databases (they need to be verified
					//before they are included in the combo box), what about just verifying that the items already in the 
					//combo actually exist? maybe later, if there's time
					preventComboSelectedIndexChange = true;
					PopulateComboBox();
					SetComboIndex(comboBoxDatabase, curComboBoxText);
					preventComboSelectedIndexChange = false;
				}
				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				}
				finally
				{
					this.Cursor = System.Windows.Forms.Cursors.Default;
				}
			}
			else
			{
				//compacting failed
				//if the original file no longer exists, rename the backup copy to the original file name
				try
				{
					SetStatusMessage(false);
					if (!System.IO.File.Exists(fileToCompactWithPath))
					{
						System.IO.File.Move(fileBackupWithPath, fileToCompactWithPath);
					}
				}
				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				}

				MessageBox.Show("An error occurred.  The compacting of the database failed.", "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			return true;
		}

		private void SetFileSizeVariable()
		{
			try
			{
				System.IO.FileInfo fileInfo = new System.IO.FileInfo(fileToCompactWithPath);
				fileSizeBeforeCompacting = fileInfo.Length / 1024;
			}
			catch
			{
				fileSizeBeforeCompacting = 0;
			}
		}

		private void SetStatusMessage(bool success)
		{
			if (success)
			{
				MessageBox.Show(this, "The database was compacted successfully.", 
					"Compact Database", MessageBoxButtons.OK, MessageBoxIcon.Information);

				//set the size variable for the compacted database file
				SetFileSizeVariable();
				labelDatabaseSizeAfter.Text = string.Format("{0} KB", fileSizeBeforeCompacting.ToString("0,0"));

				if (checkBoxMakeBackupCopy.Checked)
				{
					//set control size and visibility
					SetStatusControls(true, true);
					labelBackupFileName2.Text = fileNameBackup;
				}
				else
				{
					SetStatusControls(true, false);
				}
			}
			else
			{
				MessageBox.Show(this, "An error occurred.  The compaction of the database failed.", 
					"Compact Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		private void SetStatusControls(bool isVisible, bool showBackupInfo)
		{
			//set control size and visibility
			labelDatabaseSizeAfterCompacting.Visible = isVisible;
			labelDatabaseSizeAfter.Visible = isVisible;

			if (showBackupInfo)
			{
				panelMakeBackupCopyContainer.Size = new System.Drawing.Size(378, 142);
				panelMakeBackupCopy.Size = new System.Drawing.Size(376, 140);
			}
			else
			{
				panelMakeBackupCopyContainer.Size = new System.Drawing.Size(378, 64);
				panelMakeBackupCopy.Size = new System.Drawing.Size(376, 62);
			}
		}

		#endregion /***** Methods *****/

		#region /***** Click Events *****/

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			//set the file size again here so that the file size is refreshed in case the user 
			//	recompacts the database that was just compacted
			SetFileSizeVariable();
			labelDatabaseSizeBefore.Text = string.Format("{0} KB", fileSizeBeforeCompacting.ToString("0,0"));

			SetStatusControls(false, false);
			CompactDatabase();
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "CompactDatabase.htm");
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "CompactDatabase.htm");
		}

		private void checkBoxMakeBackupCopy_CheckedChanged(object sender, System.EventArgs e)
		{
			if (!checkBoxMakeBackupCopy.Checked)
			{
				System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
				builder.Append("You are strongly urged to create a backup copy before compacting.");
				builder.Append("\r\n\r\nIf a backup copy is not created and compacting fails, your data will likely be permanently lost.");
				builder.Append("\r\n\r\nDo you want to make a backup copy?");

				DialogResult result = MessageBox.Show(this, builder.ToString(), 
					"Make Backup Copy", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
				if (result != DialogResult.No)
				{
					checkBoxMakeBackupCopy.Checked = true;
				}
			}
		}

		private void comboBoxDatabase_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			//set the file name variables
			fileToCompactNoPath = comboBoxDatabase.Text;
			fileToCompactWithPath = string.Format(@"{0}\{1}", appDirectory, comboBoxDatabase.Text);

			if (!preventComboSelectedIndexChange)
			{
				//set control size and visibility
				SetStatusControls(false, false);
			}

			//set the size variable for the currently-selected database file
			SetFileSizeVariable();

			fileNameBackup = GetBackupFileName();

			if (!preventComboSelectedIndexChange)
				labelDatabaseSizeBefore.Text = string.Format("{0} KB", fileSizeBeforeCompacting.ToString("0,0"));
		}

		#endregion /***** Click Events *****/
	}
}
