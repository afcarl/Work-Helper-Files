using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Data;
using C1.C1Excel;
using Drive.Collections;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for GraphBuilderForm.
	/// </summary>
	public class GraphBuilderForm : System.Windows.Forms.Form
	{

		#region /***** Member Variables *****/

		private GraphUnitManager m_graphUnitManager = new GraphUnitManager();
		private ArrayList	m_selectedUnits = new ArrayList();
		private GraphYAxis	m_yAxisVariable = GraphYAxis.AcquisitionCost;
		private WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();

		//mam
		System.Data.DataTable dataTable = null;
		private TreeNode nodeHitTest;
		private TreeNode nodeSelected;
		private ArrayList nodesExpanded = new ArrayList();
		private static ArrayList nodesExpandedMainForm = new ArrayList();
		private ArrayList nodesExpandedResurrect = new ArrayList();
		private ArrayList printItems = new ArrayList();
		//private ArrayList infoSetLoadCache = new ArrayList();
		private int optionAutoSave = 1;
		private int infoSetCheckedCount = 0;
		private int currentTemplateID = 0;
		private string newTemplateNameFromForm;
		bool okToLoad = false;
		private bool savingTemplate = false;
		private bool dirtyTemplate = false;
		private bool dirtyNodes = false;
		private bool forceSave = false;
		private bool allowCheckDirty = true;

		private ArrayList		infoSetAlreadyCached = new ArrayList();
		private ArrayList		restoreItems = new ArrayList();
		private ArrayList		SelectedFac = new ArrayList();
		private ArrayList		SelectedProc = new ArrayList();
		private ArrayList		SelectedComp = new ArrayList();
		private ArrayList		SelectedDiscMech = new ArrayList();
		private ArrayList		SelectedDiscLand = new ArrayList();
		private ArrayList		SelectedDiscStruct = new ArrayList();
		private ArrayList		SelectedDiscPipe = new ArrayList();
		private ArrayList		SelectedDiscNode = new ArrayList();

		//use DiscAll
		private ArrayList		SelectedDiscAll = new ArrayList();
		private ArrayList		SelectedDiscAllLand = new ArrayList();
		private ArrayList		SelectedDiscAllMech = new ArrayList();
		private ArrayList		SelectedDiscAllStruct = new ArrayList();
		private ArrayList		SelectedDiscAllNode = new ArrayList();
		private ArrayList		SelectedDiscAllPipe = new ArrayList();
		//

		private ArrayList		selectedInfoSetMainTree = new ArrayList();
		private ArrayList		selectedFacMainTree = new ArrayList();
		private ArrayList		selectedProcMainTree = new ArrayList();
		private ArrayList		selectedCompMainTree = new ArrayList();
		private ArrayList		selectedDiscMechMainTree = new ArrayList();
		private ArrayList		selectedDiscLandMainTree = new ArrayList();
		private ArrayList		selectedDiscStructMainTree = new ArrayList();
		private ArrayList		selectedDiscPipeMainTree = new ArrayList();
		private ArrayList		selectedDiscNodeMainTree = new ArrayList();
		private int checkedNodeCount = 0;
		private System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();

		private static GraphViewerForm graphViewer;
		private GraphYAxis	m_yAxisVariable2 = GraphYAxis.AcquisitionCost;
		private bool showY2Axis = false;
		private bool autoChecking = false;
		private bool checkOnClick = false;
		private bool m_initialized = false;
		private bool rebuildingTree = false;
		private int reportTypeCount = 0;
		private string currentSelectedUnitType = "";

		object[] objGraphSettings = new object[] {"", false};
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.ImageList imageListTree;
		private System.Windows.Forms.Panel panelTree;
		private System.Windows.Forms.TreeView treeViewSpecificUnits;
		private System.Windows.Forms.ComboBox comboBoxReportType;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonClearAll;
		private System.Windows.Forms.Button buttonSelectAll;
		private System.Windows.Forms.ContextMenu mnuContextMenu;
		private System.Windows.Forms.MenuItem mnuItemSelectAll;
		private System.Windows.Forms.MenuItem mnuItemClearAll;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuItemSelectUnder;
		private System.Windows.Forms.MenuItem mnuItemClearUnder;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem mnuItemExpandAll;
		private System.Windows.Forms.MenuItem mnuItemCollapseAll;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem mnuItemView;
		private System.Windows.Forms.MenuItem mnuItemViewNormal;
		private System.Windows.Forms.MenuItem mnuItemViewSelected;
		private System.Windows.Forms.MenuItem mnuItemViewReport;
		private System.Windows.Forms.MenuItem mnuItemViewMainTree;
		private System.Windows.Forms.GroupBox groupBoxYAxes;
		private System.Windows.Forms.CheckBox checkBoxY2;
		private System.Windows.Forms.Label labelY2;
		private System.Windows.Forms.ComboBox comboBoxYValue2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox comboBoxYValue;
		private System.Windows.Forms.Panel panelGraphData;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonGraph;
		private System.Windows.Forms.Panel panelDivider;
		private System.Windows.Forms.Label labelReportTypeCount;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label labelCheckedNodeCount;
		private System.Windows.Forms.Panel panelToolbar;
		private System.Windows.Forms.PictureBox pictureBoxToolbarSave;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCopy;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private System.Windows.Forms.PictureBox pictureBoxTemplateOptions;
		private System.Windows.Forms.PictureBox pictureBoxTemplateNew;
		private System.Windows.Forms.PictureBox pictureBoxTemplateDelete;
		private System.Windows.Forms.PictureBox pictureBoxTemplateEdit;
		private System.Windows.Forms.PictureBox pictureBoxTemplateSaveAs;
		private System.Windows.Forms.PictureBox pictureBoxTemplateSave;
		private System.Windows.Forms.ComboBox comboBoxReportTemplate;
		private System.Windows.Forms.Panel panel24;
		private System.Windows.Forms.PictureBox pictureBoxTemplateResetChartProp;
		private System.Windows.Forms.Button buttonSendValuesToExcel;
		private System.ComponentModel.IContainer components;
		//</mam>

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public GraphBuilderForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.treeViewSpecificUnits.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.SetDirtyNodes);
			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxYValue.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxYValue2.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.checkBoxY2.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GraphBuilderForm));
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.treeViewSpecificUnits = new System.Windows.Forms.TreeView();
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.panelGraphData = new System.Windows.Forms.Panel();
			this.panel24 = new System.Windows.Forms.Panel();
			this.panelToolbar = new System.Windows.Forms.Panel();
			this.pictureBoxTemplateResetChartProp = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarSave = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarCopy = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateOptions = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateNew = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateDelete = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateEdit = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateSaveAs = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateSave = new System.Windows.Forms.PictureBox();
			this.comboBoxReportTemplate = new System.Windows.Forms.ComboBox();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.panelTree = new System.Windows.Forms.Panel();
			this.groupBoxYAxes = new System.Windows.Forms.GroupBox();
			this.comboBoxYValue = new System.Windows.Forms.ComboBox();
			this.comboBoxYValue2 = new System.Windows.Forms.ComboBox();
			this.checkBoxY2 = new System.Windows.Forms.CheckBox();
			this.labelY2 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.buttonClearAll = new System.Windows.Forms.Button();
			this.buttonSelectAll = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.comboBoxReportType = new System.Windows.Forms.ComboBox();
			this.mnuContextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuItemSelectAll = new System.Windows.Forms.MenuItem();
			this.mnuItemClearAll = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuItemSelectUnder = new System.Windows.Forms.MenuItem();
			this.mnuItemClearUnder = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.mnuItemExpandAll = new System.Windows.Forms.MenuItem();
			this.mnuItemCollapseAll = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.mnuItemView = new System.Windows.Forms.MenuItem();
			this.mnuItemViewNormal = new System.Windows.Forms.MenuItem();
			this.mnuItemViewSelected = new System.Windows.Forms.MenuItem();
			this.mnuItemViewReport = new System.Windows.Forms.MenuItem();
			this.mnuItemViewMainTree = new System.Windows.Forms.MenuItem();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonGraph = new System.Windows.Forms.Button();
			this.panelDivider = new System.Windows.Forms.Panel();
			this.labelReportTypeCount = new System.Windows.Forms.Label();
			this.labelCheckedNodeCount = new System.Windows.Forms.Label();
			this.buttonSendValuesToExcel = new System.Windows.Forms.Button();
			this.panelGraphData.SuspendLayout();
			this.panelToolbar.SuspendLayout();
			this.panelTree.SuspendLayout();
			this.groupBoxYAxes.SuspendLayout();
			this.SuspendLayout();
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// treeViewSpecificUnits
			// 
			this.treeViewSpecificUnits.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treeViewSpecificUnits.BackColor = System.Drawing.SystemColors.Window;
			this.treeViewSpecificUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewSpecificUnits.CheckBoxes = true;
			this.helpProvider1.SetHelpKeyword(this.treeViewSpecificUnits, "ReportsSelectReportData.htm");
			this.helpProvider1.SetHelpNavigator(this.treeViewSpecificUnits, System.Windows.Forms.HelpNavigator.Topic);
			this.treeViewSpecificUnits.ImageIndex = -1;
			this.treeViewSpecificUnits.Location = new System.Drawing.Point(1, 1);
			this.treeViewSpecificUnits.Name = "treeViewSpecificUnits";
			this.treeViewSpecificUnits.SelectedImageIndex = -1;
			this.helpProvider1.SetShowHelp(this.treeViewSpecificUnits, true);
			this.treeViewSpecificUnits.Size = new System.Drawing.Size(669, 301);
			this.treeViewSpecificUnits.TabIndex = 10;
			this.treeViewSpecificUnits.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeViewSpecificUnits_MouseDown);
			this.treeViewSpecificUnits.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterExpand);
			this.treeViewSpecificUnits.Click += new System.EventHandler(this.treeViewSpecificUnits_Click);
			this.treeViewSpecificUnits.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterCollapse);
			this.treeViewSpecificUnits.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterCheck);
			this.treeViewSpecificUnits.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeViewSpecificUnits_MouseUp);
			this.treeViewSpecificUnits.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterSelect);
			this.treeViewSpecificUnits.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeSelect);
			this.treeViewSpecificUnits.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCollapse);
			this.treeViewSpecificUnits.BeforeCheck += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCheck);
			this.treeViewSpecificUnits.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeExpand);
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// panelGraphData
			// 
			this.panelGraphData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelGraphData.Controls.Add(this.panel24);
			this.panelGraphData.Controls.Add(this.panelToolbar);
			this.panelGraphData.Controls.Add(this.panelTree);
			this.panelGraphData.Controls.Add(this.groupBoxYAxes);
			this.panelGraphData.Controls.Add(this.buttonClearAll);
			this.panelGraphData.Controls.Add(this.buttonSelectAll);
			this.panelGraphData.Controls.Add(this.label3);
			this.panelGraphData.Controls.Add(this.comboBoxReportType);
			this.panelGraphData.Location = new System.Drawing.Point(0, 0);
			this.panelGraphData.Name = "panelGraphData";
			this.panelGraphData.Size = new System.Drawing.Size(684, 440);
			this.panelGraphData.TabIndex = 11;
			// 
			// panel24
			// 
			this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel24.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel24.Location = new System.Drawing.Point(0, 33);
			this.panel24.Name = "panel24";
			this.panel24.Size = new System.Drawing.Size(684, 2);
			this.panel24.TabIndex = 93;
			// 
			// panelToolbar
			// 
			this.panelToolbar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelToolbar.BackColor = System.Drawing.Color.White;
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateResetChartProp);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarSave);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarCopy);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarAdd);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateOptions);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateNew);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateDelete);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateEdit);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateSaveAs);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateSave);
			this.panelToolbar.Controls.Add(this.comboBoxReportTemplate);
			this.panelToolbar.Controls.Add(this.pictureBoxHelp);
			this.panelToolbar.Location = new System.Drawing.Point(0, 0);
			this.panelToolbar.Name = "panelToolbar";
			this.panelToolbar.Size = new System.Drawing.Size(684, 33);
			this.panelToolbar.TabIndex = 92;
			// 
			// pictureBoxTemplateResetChartProp
			// 
			this.pictureBoxTemplateResetChartProp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateResetChartProp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateResetChartProp.Image")));
			this.pictureBoxTemplateResetChartProp.Location = new System.Drawing.Point(457, 6);
			this.pictureBoxTemplateResetChartProp.Name = "pictureBoxTemplateResetChartProp";
			this.pictureBoxTemplateResetChartProp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateResetChartProp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateResetChartProp.TabIndex = 147;
			this.pictureBoxTemplateResetChartProp.TabStop = false;
			this.pictureBoxTemplateResetChartProp.Click += new System.EventHandler(this.pictureBoxTemplateResetChartProp_Click);
			// 
			// pictureBoxToolbarSave
			// 
			this.pictureBoxToolbarSave.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarSave.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarSave.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarSave.Image")));
			this.pictureBoxToolbarSave.Location = new System.Drawing.Point(38, 6);
			this.pictureBoxToolbarSave.Name = "pictureBoxToolbarSave";
			this.pictureBoxToolbarSave.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarSave.TabIndex = 146;
			this.pictureBoxToolbarSave.TabStop = false;
			this.pictureBoxToolbarSave.Click += new System.EventHandler(this.pictureBoxToolbarSave_Click);
			// 
			// pictureBoxToolbarCopy
			// 
			this.pictureBoxToolbarCopy.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCopy.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCopy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCopy.Image")));
			this.pictureBoxToolbarCopy.Location = new System.Drawing.Point(65, 6);
			this.pictureBoxToolbarCopy.Name = "pictureBoxToolbarCopy";
			this.pictureBoxToolbarCopy.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCopy.TabIndex = 145;
			this.pictureBoxToolbarCopy.TabStop = false;
			this.pictureBoxToolbarCopy.Click += new System.EventHandler(this.pictureBoxToolbarCopy_Click);
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(11, 6);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 143;
			this.pictureBoxToolbarAdd.TabStop = false;
			this.pictureBoxToolbarAdd.Click += new System.EventHandler(this.pictureBoxToolbarAdd_Click);
			// 
			// pictureBoxTemplateOptions
			// 
			this.pictureBoxTemplateOptions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxTemplateOptions.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateOptions.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateOptions.Image")));
			this.pictureBoxTemplateOptions.Location = new System.Drawing.Point(631, 6);
			this.pictureBoxTemplateOptions.Name = "pictureBoxTemplateOptions";
			this.pictureBoxTemplateOptions.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateOptions.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateOptions.TabIndex = 91;
			this.pictureBoxTemplateOptions.TabStop = false;
			this.pictureBoxTemplateOptions.Click += new System.EventHandler(this.pictureBoxTemplateOptions_Click);
			// 
			// pictureBoxTemplateNew
			// 
			this.pictureBoxTemplateNew.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateNew.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateNew.Image")));
			this.pictureBoxTemplateNew.Location = new System.Drawing.Point(13, 6);
			this.pictureBoxTemplateNew.Name = "pictureBoxTemplateNew";
			this.pictureBoxTemplateNew.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateNew.TabIndex = 89;
			this.pictureBoxTemplateNew.TabStop = false;
			// 
			// pictureBoxTemplateDelete
			// 
			this.pictureBoxTemplateDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateDelete.Image")));
			this.pictureBoxTemplateDelete.Location = new System.Drawing.Point(387, 6);
			this.pictureBoxTemplateDelete.Name = "pictureBoxTemplateDelete";
			this.pictureBoxTemplateDelete.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateDelete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateDelete.TabIndex = 88;
			this.pictureBoxTemplateDelete.TabStop = false;
			this.pictureBoxTemplateDelete.Click += new System.EventHandler(this.pictureBoxTemplateDelete_Click);
			// 
			// pictureBoxTemplateEdit
			// 
			this.pictureBoxTemplateEdit.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateEdit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateEdit.Image")));
			this.pictureBoxTemplateEdit.Location = new System.Drawing.Point(360, 6);
			this.pictureBoxTemplateEdit.Name = "pictureBoxTemplateEdit";
			this.pictureBoxTemplateEdit.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateEdit.TabIndex = 87;
			this.pictureBoxTemplateEdit.TabStop = false;
			this.pictureBoxTemplateEdit.Click += new System.EventHandler(this.pictureBoxTemplateEdit_Click);
			// 
			// pictureBoxTemplateSaveAs
			// 
			this.pictureBoxTemplateSaveAs.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateSaveAs.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateSaveAs.Image")));
			this.pictureBoxTemplateSaveAs.Location = new System.Drawing.Point(64, 6);
			this.pictureBoxTemplateSaveAs.Name = "pictureBoxTemplateSaveAs";
			this.pictureBoxTemplateSaveAs.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateSaveAs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateSaveAs.TabIndex = 86;
			this.pictureBoxTemplateSaveAs.TabStop = false;
			// 
			// pictureBoxTemplateSave
			// 
			this.pictureBoxTemplateSave.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateSave.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateSave.Image")));
			this.pictureBoxTemplateSave.Location = new System.Drawing.Point(38, 6);
			this.pictureBoxTemplateSave.Name = "pictureBoxTemplateSave";
			this.pictureBoxTemplateSave.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateSave.TabIndex = 85;
			this.pictureBoxTemplateSave.TabStop = false;
			// 
			// comboBoxReportTemplate
			// 
			this.comboBoxReportTemplate.BackColor = System.Drawing.Color.White;
			this.comboBoxReportTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportTemplate.DropDownWidth = 194;
			this.comboBoxReportTemplate.Location = new System.Drawing.Point(93, 6);
			this.comboBoxReportTemplate.MaxDropDownItems = 20;
			this.comboBoxReportTemplate.Name = "comboBoxReportTemplate";
			this.comboBoxReportTemplate.Size = new System.Drawing.Size(259, 21);
			this.comboBoxReportTemplate.TabIndex = 0;
			this.comboBoxReportTemplate.DropDown += new System.EventHandler(this.comboBoxReportTemplate_DropDown);
			this.comboBoxReportTemplate.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportTemplate_SelectedIndexChanged);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(658, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 91;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// panelTree
			// 
			this.panelTree.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelTree.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelTree.Controls.Add(this.treeViewSpecificUnits);
			this.panelTree.Location = new System.Drawing.Point(7, 101);
			this.panelTree.Name = "panelTree";
			this.panelTree.Size = new System.Drawing.Size(671, 303);
			this.panelTree.TabIndex = 11;
			// 
			// groupBoxYAxes
			// 
			this.groupBoxYAxes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxYAxes.Controls.Add(this.comboBoxYValue);
			this.groupBoxYAxes.Controls.Add(this.comboBoxYValue2);
			this.groupBoxYAxes.Controls.Add(this.checkBoxY2);
			this.groupBoxYAxes.Controls.Add(this.labelY2);
			this.groupBoxYAxes.Controls.Add(this.label2);
			this.groupBoxYAxes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxYAxes.Location = new System.Drawing.Point(172, 395);
			this.groupBoxYAxes.Name = "groupBoxYAxes";
			this.groupBoxYAxes.Size = new System.Drawing.Size(504, 49);
			this.groupBoxYAxes.TabIndex = 79;
			this.groupBoxYAxes.TabStop = false;
			// 
			// comboBoxYValue
			// 
			this.comboBoxYValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxYValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxYValue.Location = new System.Drawing.Point(55, 16);
			this.comboBoxYValue.MaxDropDownItems = 30;
			this.comboBoxYValue.Name = "comboBoxYValue";
			this.comboBoxYValue.Size = new System.Drawing.Size(182, 21);
			this.comboBoxYValue.TabIndex = 80;
			// 
			// comboBoxYValue2
			// 
			this.comboBoxYValue2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxYValue2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxYValue2.Location = new System.Drawing.Point(318, 16);
			this.comboBoxYValue2.MaxDropDownItems = 30;
			this.comboBoxYValue2.Name = "comboBoxYValue2";
			this.comboBoxYValue2.Size = new System.Drawing.Size(182, 21);
			this.comboBoxYValue2.TabIndex = 82;
			// 
			// checkBoxY2
			// 
			this.checkBoxY2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.checkBoxY2.Location = new System.Drawing.Point(257, 20);
			this.checkBoxY2.Name = "checkBoxY2";
			this.checkBoxY2.Size = new System.Drawing.Size(16, 16);
			this.checkBoxY2.TabIndex = 83;
			this.checkBoxY2.CheckedChanged += new System.EventHandler(this.checkBoxY2_CheckedChanged);
			// 
			// labelY2
			// 
			this.labelY2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.labelY2.Location = new System.Drawing.Point(271, 20);
			this.labelY2.Name = "labelY2";
			this.labelY2.Size = new System.Drawing.Size(56, 16);
			this.labelY2.TabIndex = 81;
			this.labelY2.Text = "Y Axis 2:";
			this.labelY2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelY2.Click += new System.EventHandler(this.labelY2_Click);
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Location = new System.Drawing.Point(8, 20);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 16);
			this.label2.TabIndex = 79;
			this.label2.Text = "Y Axis 1:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// buttonClearAll
			// 
			this.buttonClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClearAll.Location = new System.Drawing.Point(88, 411);
			this.buttonClearAll.Name = "buttonClearAll";
			this.buttonClearAll.Size = new System.Drawing.Size(73, 23);
			this.buttonClearAll.TabIndex = 17;
			this.buttonClearAll.Text = "Clear All";
			this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
			// 
			// buttonSelectAll
			// 
			this.buttonSelectAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSelectAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonSelectAll.Location = new System.Drawing.Point(10, 411);
			this.buttonSelectAll.Name = "buttonSelectAll";
			this.buttonSelectAll.Size = new System.Drawing.Size(74, 23);
			this.buttonSelectAll.TabIndex = 16;
			this.buttonSelectAll.Text = "Select All";
			this.buttonSelectAll.Click += new System.EventHandler(this.buttonSelectAll_Click);
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label3.Location = new System.Drawing.Point(11, 44);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(189, 28);
			this.label3.TabIndex = 13;
			this.label3.Text = "Select Graph Data";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxReportType
			// 
			this.comboBoxReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportType.DropDownWidth = 194;
			this.comboBoxReportType.Location = new System.Drawing.Point(7, 79);
			this.comboBoxReportType.MaxDropDownItems = 10;
			this.comboBoxReportType.Name = "comboBoxReportType";
			this.comboBoxReportType.Size = new System.Drawing.Size(265, 21);
			this.comboBoxReportType.TabIndex = 12;
			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportType_SelectedIndexChanged);
			// 
			// mnuContextMenu
			// 
			this.mnuContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.mnuItemSelectAll,
																						   this.mnuItemClearAll,
																						   this.menuItem3,
																						   this.mnuItemSelectUnder,
																						   this.mnuItemClearUnder,
																						   this.menuItem6,
																						   this.mnuItemExpandAll,
																						   this.mnuItemCollapseAll,
																						   this.menuItem9,
																						   this.mnuItemView});
			// 
			// mnuItemSelectAll
			// 
			this.mnuItemSelectAll.Index = 0;
			this.mnuItemSelectAll.Text = "&Select All";
			// 
			// mnuItemClearAll
			// 
			this.mnuItemClearAll.Index = 1;
			this.mnuItemClearAll.Text = "&Clear All";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// mnuItemSelectUnder
			// 
			this.mnuItemSelectUnder.Index = 3;
			this.mnuItemSelectUnder.Text = "Select all items under";
			// 
			// mnuItemClearUnder
			// 
			this.mnuItemClearUnder.Index = 4;
			this.mnuItemClearUnder.Text = "Clear all items under";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "-";
			// 
			// mnuItemExpandAll
			// 
			this.mnuItemExpandAll.Index = 6;
			this.mnuItemExpandAll.Text = "E&xpand All";
			// 
			// mnuItemCollapseAll
			// 
			this.mnuItemCollapseAll.Index = 7;
			this.mnuItemCollapseAll.Text = "C&ollapse All";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 8;
			this.menuItem9.Text = "-";
			// 
			// mnuItemView
			// 
			this.mnuItemView.Index = 9;
			this.mnuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.mnuItemViewNormal,
																						this.mnuItemViewSelected,
																						this.mnuItemViewReport,
																						this.mnuItemViewMainTree});
			this.mnuItemView.Text = "View";
			// 
			// mnuItemViewNormal
			// 
			this.mnuItemViewNormal.Checked = true;
			this.mnuItemViewNormal.Index = 0;
			this.mnuItemViewNormal.Text = "User selection";
			// 
			// mnuItemViewSelected
			// 
			this.mnuItemViewSelected.Index = 1;
			this.mnuItemViewSelected.Text = "Selected items only";
			// 
			// mnuItemViewReport
			// 
			this.mnuItemViewReport.Index = 2;
			this.mnuItemViewReport.Text = "Graph Type items only";
			// 
			// mnuItemViewMainTree
			// 
			this.mnuItemViewMainTree.Index = 3;
			this.mnuItemViewMainTree.Text = "Same as main data view";
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(571, 446);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(104, 23);
			this.buttonCancel.TabIndex = 74;
			this.buttonCancel.Text = "Close";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// buttonGraph
			// 
			this.buttonGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonGraph.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonGraph.Location = new System.Drawing.Point(339, 446);
			this.buttonGraph.Name = "buttonGraph";
			this.buttonGraph.Size = new System.Drawing.Size(104, 23);
			this.buttonGraph.TabIndex = 73;
			this.buttonGraph.Text = "&Graph";
			this.buttonGraph.Click += new System.EventHandler(this.buttonGraph_Click);
			// 
			// panelDivider
			// 
			this.panelDivider.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelDivider.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelDivider.Location = new System.Drawing.Point(0, 439);
			this.panelDivider.Name = "panelDivider";
			this.panelDivider.Size = new System.Drawing.Size(684, 2);
			this.panelDivider.TabIndex = 82;
			// 
			// labelReportTypeCount
			// 
			this.labelReportTypeCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelReportTypeCount.Location = new System.Drawing.Point(10, 443);
			this.labelReportTypeCount.Name = "labelReportTypeCount";
			this.labelReportTypeCount.Size = new System.Drawing.Size(150, 28);
			this.labelReportTypeCount.TabIndex = 81;
			this.labelReportTypeCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelCheckedNodeCount
			// 
			this.labelCheckedNodeCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCheckedNodeCount.Location = new System.Drawing.Point(171, 443);
			this.labelCheckedNodeCount.Name = "labelCheckedNodeCount";
			this.labelCheckedNodeCount.Size = new System.Drawing.Size(145, 28);
			this.labelCheckedNodeCount.TabIndex = 83;
			this.labelCheckedNodeCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// buttonSendValuesToExcel
			// 
			this.buttonSendValuesToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonSendValuesToExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSendValuesToExcel.Location = new System.Drawing.Point(455, 446);
			this.buttonSendValuesToExcel.Name = "buttonSendValuesToExcel";
			this.buttonSendValuesToExcel.Size = new System.Drawing.Size(104, 23);
			this.buttonSendValuesToExcel.TabIndex = 84;
			this.buttonSendValuesToExcel.Text = "&Values to Excel";
			this.buttonSendValuesToExcel.Click += new System.EventHandler(this.buttonSendValuesToExcel_Click);
			// 
			// GraphBuilderForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(684, 474);
			this.Controls.Add(this.buttonSendValuesToExcel);
			this.Controls.Add(this.panelGraphData);
			this.Controls.Add(this.buttonGraph);
			this.Controls.Add(this.labelCheckedNodeCount);
			this.Controls.Add(this.panelDivider);
			this.Controls.Add(this.labelReportTypeCount);
			this.Controls.Add(this.buttonCancel);
			this.helpProvider1.SetHelpKeyword(this, "Graphing.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(692, 300);
			this.Name = "GraphBuilderForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Select Time-Series Graph Settings";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.GraphBuilderForm_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GraphBuilderForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.panelToolbar_Paint);
			this.panelGraphData.ResumeLayout(false);
			this.panelToolbar.ResumeLayout(false);
			this.panelTree.ResumeLayout(false);
			this.groupBoxYAxes.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		public static void TestMethod1()
		{
		}

		public void TestMethod2()
		{
		}

		public static void	ShowForm(Form owner, ArrayList nodesExpandedMain)
		{
			GraphBuilderForm form = new GraphBuilderForm();

			//mam
			try
			{
				nodesExpandedMainForm = nodesExpandedMain;

				form.ShowDialog(owner);
			}
			catch (System.ArgumentException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("GraphBuilderForm.ShowForm Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			//</mam>

			//mam - move this code so that it is executed other than when the form is closing
			//	so we can leave this form open while the graph is being viewed
//			if (form.ShowDialog(owner) == DialogResult.OK)
//			{
//				// Get the selected values and display the graph view
//
//				//mam - include y2 axis
//				//GraphViewerForm.ShowForm(form.m_selectedUnits, 
//				//	form.m_yAxisVariable, MainForm.AppForm);
//
//				GraphViewerForm.ShowForm(form.m_selectedUnits, 
//					form.m_yAxisVariable, form.m_yAxisVariable2, form.showY2Axis, MainForm.AppForm);
//				//</mam>
//			}
			//</mam>
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			// Save our form state
			Drive.Configuration.FormState formState = 
				new Drive.Configuration.FormState(this);

			Drive.Configuration.AppSettings.Settings.
				SetSetting(@"ScreenSettings", 
				this.Name, formState.ToString());

			//mam - make sure View and AutoSave are written out to the WAM.xml file
			SavePreferences();
			Drive.Configuration.AppSettings.Settings.Save();
			SaveUserSettings();
			//</mam>

			//mam
			if (dataTable != null)
			{
				try
				{
					dataTable.Clear();
					dataTable = null;
					dataTable.Dispose();
				}
				catch
				{
				}
			}
			//</mam>

			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			Drive.Configuration.FormState formState = 
				new Drive.Configuration.FormState(
				Drive.Configuration.AppSettings.
				Settings.GetSetting("ScreenSettings",
				this.Name));
			formState.RestoreState(this);

			//mam
			SetToolTips();
			SetBitmaps();
			this.Refresh();

			treeViewSpecificUnits.ImageList = this.imageListTree;
			treeViewSpecificUnits.ImageIndex = 9;
			treeViewSpecificUnits.SelectedImageIndex = 9;
			treeViewSpecificUnits.ContextMenu = mnuContextMenu;
			LoadTemplateCombo();
			PopulateReportTypeCombo();
			LoadContextMenu();
			LoadPreferences();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			DetermineRestoreItemsMainTree();

			m_initialized = true;

			//must come after setting m_initialized
			comboBoxReportType_SelectedIndexChanged(this, e);
			if (comboBoxReportTemplate.SelectedIndex > -1)
				currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;

			SetReportTemplateSettings();
			SetTreeNodesPerSelectedView();
			CountCheckedNodes();
			ResetDirty();

			treeViewSpecificUnits.Focus();
			//</mam>

			base.OnLoad(e);
		}

		private void panelToolbar_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void LoadPreferences()
		{
			SetCurrentView(Drive.Configuration.AppSettings.Settings.GetSettingInt("Defaults", "GraphBuilderView", 0));
			optionAutoSave = Drive.Configuration.AppSettings.Settings.GetSettingInt("Defaults", "GraphTemplateAutoSave", 1);
		}

		//mam
		private void SetToolTips()
		{
			// Create the ToolTip and associate with the Form container.
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;

			toolTip.SetToolTip(this.pictureBoxToolbarAdd, "Create a new graph template");
			toolTip.SetToolTip(this.pictureBoxToolbarSave, "Save the current template settings");
			toolTip.SetToolTip(this.pictureBoxToolbarCopy, "Save the current settings to a new template");

			toolTip.SetToolTip(this.pictureBoxTemplateEdit, "Edit the name of the graph template");
			toolTip.SetToolTip(this.pictureBoxTemplateDelete, "Delete the current graph template");
			toolTip.SetToolTip(this.pictureBoxTemplateResetChartProp, "Reset the graph properties for the current graph template");
			toolTip.SetToolTip(this.pictureBoxTemplateOptions, "Preferences");
			toolTip.SetToolTip(this.pictureBoxHelp, "Help");

			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.buttonSelectAll, "Select all items");
			toolTip.SetToolTip(this.buttonClearAll, "Clear all selected items");
			
		}
		//</mam>

		//mam
		private void SetBitmaps()
		{
			//load toolbar pictureboxes with bitmaps
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			System.IO.Stream file = null;
			Image image = null;

			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks.SetBitmap(pictureBoxTemplateDelete);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarAdd.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarAdd);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonSaveOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarSave.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarSave);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonCopyOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarCopy.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarCopy);

			Bitmap b = (Bitmap)pictureBoxToolbarAdd.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarAdd.Image = b;

			b = (Bitmap)pictureBoxToolbarCopy.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarCopy.Image = b;

			b = (Bitmap)pictureBoxToolbarSave.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarSave.Image = b;

			commonTasks = null;
			file = null;
			image = null;
		}
		//</mam>

		//mam
		private void PopulateTree(bool expandAllNodes, int specificLevel)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			TreeNode node = null;
			TreeNode nodeInfo = null;
			TreeNode nodeFac = null;
			TreeNode nodeProc = null;
			TreeNode nodeComp = null;
			int nodeCount = 0;

			string queryValue = "";
			string curInfo = "";
			string curFac = "";
			string curProc = "";
			string curComp = "";
			string curDisc = "";

			string curInfoID = "";
			string curFacID = "";
			string curProcID = "";
			string curCompID = "";

			string selectedUnitType = GetSelectedUnitTypeString();
			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);

			reportTypeCount = 0;

			if (dataTable == null)
			{
				//new query to get the pipe and node count to determine whether to show Pipe and Node nodes in tree
				builder.Append("SELECT I.infoset_name, I.infoset_id, F.facility_name, F.facility_id, P.process_name,");
				builder.Append(" P.process_id, C.component_name, C.component_id, DM.disc1_id AS MechDisciplineID,");
				builder.Append(" DS.disc2_id AS StructDisciplineID, DL.disc3_id AS LandDisciplineID,");
				builder.Append(" DP.discpipe_id AS PipeDisciplineID, DN.discnode_id AS NodeDisciplineID,");
				builder.Append(" DM.disc1_conditionRanking AS CondMech, DS.disc2_conditionRanking AS CondStruct,");
				builder.Append(" disc3_conditionRanking AS CondLand,");
				builder.Append(" SUM(PC.pipe_conditionRank) AS CondPipe, SUM(NC.node_conditionRank) AS CondNode,");
				builder.Append(" COUNT(PC.pipe_id) AS NumberOfPipes, COUNT(NC.node_id) AS NumberOfNodes");
				builder.Append(" FROM (((((((((Infosets AS I LEFT JOIN Facilities AS F ON I.infoset_id=F.infoset_id)");
				builder.Append(" LEFT JOIN TreatmentProcesses AS P ON F.facility_id=P.facility_id)");
				builder.Append(" LEFT JOIN MajorComponents AS C ON P.process_id=C.process_id)");
				builder.Append(" LEFT JOIN DisciplineMech AS DM ON C.component_id=DM.component_id)");
				builder.Append(" LEFT JOIN DisciplineStruct AS DS ON C.component_id=DS.component_id)");
				builder.Append(" LEFT JOIN DisciplineLand AS DL ON C.component_id=DL.component_id)");
				builder.Append(" LEFT JOIN DisciplinePipes AS DP ON C.component_id=DP.component_id)");
				builder.Append(" LEFT JOIN DisciplineNodes AS DN ON C.component_id=DN.component_id)");
				builder.Append(" LEFT JOIN PipingComponents AS PC ON DP.discpipe_id=PC.discpipe_id)");
				builder.Append(" LEFT JOIN NodeAppurtComponents AS NC ON DN.discnode_id=NC.discnode_id");
				builder.Append(" GROUP BY I.infoset_name, F.facility_sortOrder, F.facility_id, P.process_sortOrder,");
				builder.Append(" P.process_id, C.component_sortOrder, C.component_id, I.infoset_id, F.facility_name,");
				builder.Append(" P.process_name, C.component_name, DM.disc1_id, DS.disc2_id, DL.disc3_id, DP.discpipe_id,");
				builder.Append(" DN.discnode_id, DM.disc1_conditionRanking, DS.disc2_conditionRanking, disc3_conditionRanking");
				builder.Append(" ORDER BY I.infoset_name, F.facility_sortOrder, F.facility_id, P.process_sortOrder,");
				builder.Append(" P.process_id, C.component_sortOrder, C.component_id;");

				queryValue = builder.ToString();
				dataTable = dataAccess.GetDisconnectedDataTable(queryValue);
			}
			if (dataTable != null)
			{
				if (dataTable.Rows.Count == 0)
				{
					MessageBox.Show(this,
						"No records found.", "No Records Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					treeViewSpecificUnits.SuspendLayout();
					treeViewSpecificUnits.BeginUpdate();
					treeViewSpecificUnits.Nodes.Clear();

					foreach (System.Data.DataRow dataRow in dataTable.Rows)
					{
						// add the current infoset
						if (dataRow["infoset_id"].ToString() != curInfoID)
						{
							curInfoID = dataRow["infoset_id"].ToString();
							curInfo = dataRow["infoset_name"].ToString();
							nodeInfo = new TreeNode(curInfo);

							WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["infoset_id"], 
								curInfo, (int)NodeType.InfoSet, NodeType.InfoSet.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
							nodeInfo.Tag = treeViewItem;

							nodeInfo.ImageIndex = 0;
							nodeInfo.SelectedImageIndex = 0;
							treeViewSpecificUnits.Nodes.Add(nodeInfo);

							nodeInfo.ForeColor = System.Drawing.SystemColors.GrayText;
							nodeInfo.ImageIndex = 1;
							nodeInfo.SelectedImageIndex = 1;
						}

						// add the current facility
						if (dataRow["facility_id"].ToString() != curFacID)
						{
							curFacID = dataRow["facility_id"].ToString();
							curFac = dataRow["facility_name"].ToString();

							if (curFac == "")
								continue;
							
							nodeFac = new TreeNode(curFac);

							WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["facility_id"], 
								curFac, (int)NodeType.Facility, NodeType.Facility.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
							nodeFac.Tag = treeViewItem;

							nodeFac.ImageIndex = 0;
							nodeFac.SelectedImageIndex = 0;
							nodeInfo.Nodes.Add(nodeFac);

							// color the node either blue (if active) or grey (if inactive)
							if (selectedUnitType == NodeType.Facility.ToString())
							{
								nodeFac.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
								reportTypeCount++;
							}
							else
							{
								nodeFac.ForeColor = System.Drawing.SystemColors.GrayText;
								nodeFac.ImageIndex = 1;
								nodeFac.SelectedImageIndex = 1;
							}

							// expand the node's parent if all nodes are being expanded, or if a specific level of
							//	node is being expanded (for "Graph type items" view)
							if (expandAllNodes || specificLevel == (int)NodeType.Facility)
								nodeFac.Parent.Expand();
						}

						// add the current process
						if (dataRow["process_id"].ToString() != curProcID)
						{
							curProcID = dataRow["process_id"].ToString();
							curProc = dataRow["process_name"].ToString();
							if (curProc == "")
								continue;

							nodeProc = new TreeNode(curProc);

							WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["process_id"], 
								curProc, (int)NodeType.TreatmentProcess, NodeType.TreatmentProcess.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
							nodeProc.Tag = treeViewItem;
							
							nodeProc.ImageIndex = 3;
							nodeProc.SelectedImageIndex = 3;
							nodeFac.Nodes.Add(nodeProc);

							if (selectedUnitType == NodeType.TreatmentProcess.ToString())
							{
								nodeProc.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
								reportTypeCount++;
							}
							else
							{
								nodeProc.ForeColor = System.Drawing.SystemColors.GrayText;
								nodeProc.ImageIndex = 1;
								nodeProc.SelectedImageIndex = 1;
							}

							if (expandAllNodes)
							{
								nodeProc.Parent.Expand();
							}
							else if (specificLevel == (int)NodeType.TreatmentProcess)
							{
								nodeProc.Parent.Expand();
								nodeProc.Parent.Parent.Expand();
							}
						}

						// add the current component
						if (dataRow["component_id"].ToString() != curCompID)
						{
							curCompID = dataRow["component_id"].ToString();
							curComp = dataRow["component_name"].ToString();
							if (curComp == "")
								continue;

							nodeComp = new TreeNode(curComp);

							WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["component_id"], 
								curComp, (int)NodeType.MajorComponent, NodeType.MajorComponent.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
							nodeComp.Tag = treeViewItem;
							
							nodeComp.ImageIndex = 5;
							nodeComp.SelectedImageIndex = 5;
							nodeProc.Nodes.Add(nodeComp);

							if (selectedUnitType == NodeType.MajorComponent.ToString())
							{
								nodeComp.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
								reportTypeCount++;
							}
							else
							{
								nodeComp.ForeColor = System.Drawing.SystemColors.GrayText;
								nodeComp.ImageIndex = 1;
								nodeComp.SelectedImageIndex = 1;
							}

							if (expandAllNodes)
							{
								nodeComp.Parent.Expand();
							}
							else if (specificLevel == (int)NodeType.MajorComponent)
							{
								nodeComp.Parent.Expand();
								nodeComp.Parent.Parent.Expand();
								nodeComp.Parent.Parent.Parent.Expand();
							}
						}

						// add the mech discipline
						curDisc = dataRow["MechDisciplineID"].ToString();
						if (curDisc != "")
						{
							//if the condition is zero or n/a, don't create the node
							if ((dataRow["CondMech"]).ToString() != "0" && dataRow["CondMech"].ToString() != "255")
							{
								node = new TreeNode(WAM.UI.NodeTypeHandler.GetNodeTypeString(WAM.UI.NodeType.DisciplineMech));

								WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["MechDisciplineID"], 
									curDisc, (int)NodeType.DisciplineMech, NodeType.DisciplineMech.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
								node.Tag = treeViewItem;

								node.ImageIndex = 7;
								node.SelectedImageIndex = 7;
								nodeComp.Nodes.Add(node);

								if (selectedUnitType == NodeType.DisciplineMech.ToString() 
									|| specificLevel == (int)NodeType.NoneSelected
									|| selectedUnitType == "Discipline")
								{
									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
									reportTypeCount++;
								}
								else
								{
									node.ForeColor = System.Drawing.SystemColors.GrayText;
									node.ImageIndex = 1;
									node.SelectedImageIndex = 1;
								}

								if (expandAllNodes)
								{
									node.Parent.Expand();
								}
								else if (specificLevel == (int)NodeType.DisciplineMech || specificLevel == (int)NodeType.NoneSelected)
								{
									node.Parent.Expand();
									node.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Parent.Expand();
								}
							}
						}

						// add the struct discipline
						curDisc = dataRow["StructDisciplineID"].ToString();
						if (curDisc != "")
						{
							//if the condition is zero or n/a, don't create the node
							if (dataRow["CondStruct"].ToString() != "0" && dataRow["CondStruct"].ToString() != "255")
							{
								node = new TreeNode(WAM.UI.NodeTypeHandler.GetNodeTypeString(WAM.UI.NodeType.DisciplineStruct));

								WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["StructDisciplineID"], 
									curDisc, (int)NodeType.DisciplineStruct, NodeType.DisciplineStruct.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
								node.Tag = treeViewItem;

								node.ImageIndex = 7;
								node.SelectedImageIndex = 7;
								nodeComp.Nodes.Add(node);

								if (selectedUnitType == NodeType.DisciplineStruct.ToString() 
									|| specificLevel == (int)NodeType.NoneSelected
									|| selectedUnitType == "Discipline")
								{
									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
									reportTypeCount++;
								}
								else
								{
									node.ForeColor = System.Drawing.SystemColors.GrayText;
									node.ImageIndex = 1;
									node.SelectedImageIndex = 1;
								}

								if (expandAllNodes)
								{
									node.Parent.Expand();
								}
								else if (specificLevel == (int)NodeType.DisciplineStruct || specificLevel == (int)NodeType.NoneSelected)
								{
									node.Parent.Expand();
									node.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Parent.Expand();
								}
							}
						}

						// add the land discipline
						curDisc = dataRow["LandDisciplineID"].ToString();
						if (curDisc != "")
						{
							//if the condition is zero or n/a, don't create the node
							if (dataRow["CondLand"].ToString() != "0" && dataRow["CondLand"].ToString() != "255")
							{
								node = new TreeNode(WAM.UI.NodeTypeHandler.GetNodeTypeString(WAM.UI.NodeType.DisciplineLand));

								WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["LandDisciplineID"], 
									curDisc, (int)NodeType.DisciplineLand, NodeType.DisciplineLand.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
								node.Tag = treeViewItem;

								node.ImageIndex = 7;
								node.SelectedImageIndex = 7;
								nodeComp.Nodes.Add(node);

								if (selectedUnitType == NodeType.DisciplineLand.ToString() 
									|| specificLevel == (int)NodeType.NoneSelected
									|| selectedUnitType == "Discipline")
								{
									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
									reportTypeCount++;
								}
								else
								{
									node.ForeColor = System.Drawing.SystemColors.GrayText;
									node.ImageIndex = 1;
									node.SelectedImageIndex = 1;
								}

								if (expandAllNodes)
								{
									node.Parent.Expand();
								}
								else if (specificLevel == (int)NodeType.DisciplineLand || specificLevel == (int)NodeType.NoneSelected)
								{
									node.Parent.Expand();
									node.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Parent.Expand();
								}
							}
						}

						// add the pipes discipline
						curDisc = dataRow["PipeDisciplineID"].ToString();
						if (curDisc != "")
						{
							//if the discipline has no pipes, don't create the node
							if (dataRow["NumberOfPipes"].ToString() == "0")
							{}
							else
							{
								node = new TreeNode(WAM.UI.NodeTypeHandler.GetNodeTypeString(WAM.UI.NodeType.DisciplinePipe));

								WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["PipeDisciplineID"], 
									curDisc, (int)NodeType.DisciplinePipe, NodeType.DisciplinePipe.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
								node.Tag = treeViewItem;

								node.ImageIndex = 7;
								node.SelectedImageIndex = 7;
								nodeComp.Nodes.Add(node);

								if (selectedUnitType == NodeType.DisciplinePipe.ToString()
									|| specificLevel == (int)NodeType.NoneSelected
									|| selectedUnitType == "Discipline")
								{
									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
									reportTypeCount++;
								}
								else
								{
									node.ForeColor = System.Drawing.SystemColors.GrayText;
									node.ImageIndex = 1;
									node.SelectedImageIndex = 1;
								}

								if (expandAllNodes)
								{
									node.Parent.Expand();
								}
								else if (specificLevel == (int)NodeType.DisciplinePipe || specificLevel == (int)NodeType.NoneSelected)
								{
									node.Parent.Expand();
									node.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Parent.Expand();
								}
							}
						}

						// add the nodes discipline
						curDisc = dataRow["NodeDisciplineID"].ToString();
						if (curDisc != "")
						{
							//if the discipline has no nodes, don't create the node
							if (dataRow["NumberOfNodes"].ToString() == "0")
							{}
							else
							{
								node = new TreeNode(WAM.UI.NodeTypeHandler.GetNodeTypeString(WAM.UI.NodeType.DisciplineNode));

								WAM.Common.TreeViewItem treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeDisciplineID"], 
									curDisc, (int)NodeType.DisciplineNode, NodeType.DisciplineNode.ToString(), ++nodeCount, (int)dataRow["infoset_id"]);
								node.Tag = treeViewItem;

								node.ImageIndex = 7;
								node.SelectedImageIndex = 7;
								nodeComp.Nodes.Add(node);

								if (selectedUnitType == NodeType.DisciplineNode.ToString() 
									|| specificLevel == (int)NodeType.NoneSelected 
									|| selectedUnitType == "Discipline")
								{
									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
									reportTypeCount++;
								}
								else
								{
									node.ForeColor = System.Drawing.SystemColors.GrayText;
									node.ImageIndex = 1;
									node.SelectedImageIndex = 1;
								}

								if (expandAllNodes)
								{
									node.Parent.Expand();
								}
								else if (specificLevel == (int)NodeType.DisciplineNode || specificLevel == (int)NodeType.NoneSelected)
								{
									node.Parent.Expand();
									node.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Expand();
									node.Parent.Parent.Parent.Parent.Expand();
								}
							}
						}
					}
					treeViewSpecificUnits.EndUpdate();
					treeViewSpecificUnits.ResumeLayout();
					currentSelectedUnitType = GetSelectedUnitTypeString();
					UpdateReportTypeLabel();
				}
			}
		}
		//</mam>

		//mam
		private void RebuildTree(bool expandAllNodes, int specificLevel)
		{
			rebuildingTree = true;

			// note the nodes that have been selected (checked) by the user
			GetSelectedTreeNodes();

			//rebuild the tree
			treeViewSpecificUnits.Nodes.Clear();
			PopulateTree(expandAllNodes, specificLevel);

			// restore the checked nodes
			DetermineRestoreItems();
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				ResurrectSelectedNodes(node);
			}

			// if the view is user-selected, restore the expanded state of the tree
			if (mnuItemViewNormal.Checked)
			{
				//if there are more than 1000 nodes in the nodesExpandedResurrect array, ask the user 
				// whether to continue restoring the user-expanded nodes
				DialogResult result = DialogResult.Yes;
				if (nodesExpanded.Count > 1000)
				{
					result = MessageBox.Show(this, "Restoring the User Selection View may take a minute or more.  Do you want to continue?",
						"User Selection View", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
				}
				if (result == DialogResult.Yes)
				{
					this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
					try
					{
						nodesExpandedResurrect = nodesExpanded;
						foreach (TreeNode node in treeViewSpecificUnits.Nodes)
						{
							ResurrectExpandedNodes(node);
						}
					}
					finally
					{
						this.Cursor = System.Windows.Forms.Cursors.Default;
					}
				}
				else
				{
					nodesExpanded.Clear();
				}
			}

			// if the view is the same as the main tree, restore the expanded state of the tree
			if (mnuItemViewMainTree.Checked)
			{
				// find the InfoSet node in the Graph tree that matches the InfoSet node in the Main Tree
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					if (((WAM.Common.TreeViewItem)node.Tag).ItemID == InfoSet.CurrentID)
					{
						ResurrectExpandedNodesMainTree(node);
						break;
					}
				}
			}

			rebuildingTree = false;
		}
		//</mam>

		//mam
		private void UpdateReportTypeLabel()
		{
			labelReportTypeCount.Text = "Report items available:  " + reportTypeCount.ToString();
		}
		//</mam>

		//mam
		private void PopulateReportTypeCombo()
		{
			WAM.Common.ComboBoxMethods comboBoxMethods = new WAM.Common.ComboBoxMethods();
			System.Text.StringBuilder builder = new System.Text.StringBuilder(200);

			builder.Append("SELECT C.ComboReportLevelID AS ID, C.NodeTypeID AS EnumValue,");
			builder.Append(" C.ReportLevelText AS Description, N.NodeType AS ItemTag");
			builder.Append(" FROM ComboReportLevel C LEFT JOIN NodeType N ON C.NodeTypeID = N.NodeTypeID");
			builder.Append(" WHERE C.ApplyToGraph = 1 ORDER BY C.SortBy");

			comboBoxMethods.PopulateComboBox(comboBoxReportType, builder.ToString());
		}
		//</mam>

		//mam
		private void LoadContextMenu()
		{
			this.mnuContextMenu.Popup += new System.EventHandler(MyPopupEventHandler);
			this.mnuItemSelectAll.Click += new System.EventHandler(mnuItemSelectAll_OnClick);
			this.mnuItemClearAll.Click += new System.EventHandler(mnuItemClearAll_OnClick);
			this.mnuItemSelectUnder.Click += new System.EventHandler(mnuItemSelectUnder_OnClick);
			this.mnuItemClearUnder.Click += new System.EventHandler(mnuItemClearUnder_OnClick);
			this.mnuItemExpandAll.Click += new System.EventHandler(mnuItemExpandAll_OnClick);
			this.mnuItemCollapseAll.Click += new System.EventHandler(mnuItemCollapseAll_OnClick);
			this.mnuItemViewNormal.Click += new System.EventHandler(mnuItemViewNormal_OnClick);
			this.mnuItemViewSelected.Click += new System.EventHandler(mnuItemViewSelected_OnClick);
			this.mnuItemViewReport.Click += new System.EventHandler(mnuItemViewReport_OnClick);
			this.mnuItemViewMainTree.Click += new System.EventHandler(mnuItemViewMainTree_OnClick);
		}
		//</mam>

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/
		
		//mam
		private void RemoveFacilityFromCache()
		{
			int curInfosetID = 0;
			curInfosetID = Convert.ToInt32(treeViewSpecificUnits.Nodes[0].Tag);

			Facility[] facilities;

			facilities = CacheManager.GetFacilities(curInfosetID);
			for (int pos = 0; pos < facilities.Length; pos++)
			{
				CacheManager.GetFacilityCache(curInfosetID).RemoveFacilityFromCache(facilities[pos].ID);
			}
		}
		//</mam>

		//mam
		protected void MyPopupEventHandler(System.Object sender, System.EventArgs e)
		{
			string nodeText = "";
 
			if (nodeHitTest == null)
			{
				mnuContextMenu.MenuItems[2].Visible = false;
				mnuContextMenu.MenuItems[3].Visible = false;
				mnuContextMenu.MenuItems[4].Visible = false;
			}
			else
			{
				if (nodeHitTest.Nodes.Count == 0)
				{
					mnuContextMenu.MenuItems[2].Visible = false;
					mnuContextMenu.MenuItems[3].Visible = false;
					mnuContextMenu.MenuItems[4].Visible = false;
				}
					//may not do this:
					//check for red or black ForeColor because we're color-coding them red or black
					//	to match the main data tree
				else if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
					//else if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
				{
					if (nodeHitTest.Parent != null)
					{
						mnuContextMenu.MenuItems[2].Visible = true;
						mnuContextMenu.MenuItems[3].Visible = true;
						mnuContextMenu.MenuItems[4].Visible = true;

						nodeText = nodeHitTest.Parent.Text;
						if (nodeText.Length > 25)
						{
							nodeText = nodeHitTest.Parent.Text.Substring(0, 25) + "...";
						}
					
						mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
						mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
					}
				}
				else
				{
					mnuContextMenu.MenuItems[2].Visible = true;
					mnuContextMenu.MenuItems[3].Visible = true;
					mnuContextMenu.MenuItems[4].Visible = true;

					nodeText = nodeHitTest.Text;
					if (nodeText.Length > 25)
					{
						nodeText = nodeHitTest.Text.Substring(0, 25) + "...";
					}
					
					mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
					mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
				}
			}
		}
		//</mam>

		//mam
		private void SetY2Status()
		{
			comboBoxYValue2.Enabled = checkBoxY2.Checked;
			showY2Axis = checkBoxY2.Checked;
		}

		private void checkBoxY2_CheckedChanged(object sender, System.EventArgs e)
		{
			SetY2Status();
		}

		private void labelY2_Click(object sender, System.EventArgs e)
		{
			checkBoxY2.Checked = !checkBoxY2.Checked;
		}
		//</mam>

		//mam
		private void comboBoxReportType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				nodeHitTest = null;

				LoadYAxisValues(comboBoxYValue);
				LoadYAxisValues(comboBoxYValue2);
				SetY2Status();

				if (mnuItemViewReport.Checked)
				{
					RebuildTree(false, ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).EnumValue);
				}
				else if (mnuItemViewNormal.Checked || mnuItemViewMainTree.Checked)
				{
					if (treeViewSpecificUnits.Nodes.Count == 0)
					{
						RebuildTree(false, -1);
					}
					else
					{
						// note the nodes that have been selected (checked) by the user
						GetSelectedTreeNodes();

						reportTypeCount = 0;
						string nextSelectedUnitType = ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemTag;
						foreach (TreeNode node in treeViewSpecificUnits.Nodes)
						{
							ConfigureNodes(node, nextSelectedUnitType, 5);
						}

						currentSelectedUnitType = nextSelectedUnitType;
						UpdateReportTypeLabel();

						// restore the checked nodes
						DetermineRestoreItems();
						foreach (TreeNode node in treeViewSpecificUnits.Nodes)
						{
							ResurrectSelectedNodes(node);
						}

						CountReportTypeNodes();
					}
				}
				else
				{
					RebuildTree(false, -1);
				}

				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
				//currentSelectedUnitType = GetSelectedUnitTypeString();
				treeViewSpecificUnits.Focus();
			}

			DetermineRestoreItems();
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				ResurrectSelectedNodes(node);
			}

			CountCheckedNodes();
		}

		private void ConfigureNodes(TreeNode node, string nextSelectedUnitType, int imageIndex)
		{
			node.Checked = false;

			// color the node grey
			node.ForeColor = System.Drawing.SystemColors.GrayText;
			node.ImageIndex = 1;
			node.SelectedImageIndex = 1;

			if (node.Tag.ToString() == nextSelectedUnitType 
				|| (node.Tag.ToString().StartsWith("Disc") && nextSelectedUnitType == "Discipline"))
			{
				// color the node blue
				node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
				node.ImageIndex = imageIndex;
				node.SelectedImageIndex = imageIndex;
			}

			foreach (TreeNode nodeChild in node.Nodes)
			{
				ConfigureNodes(nodeChild, nextSelectedUnitType, imageIndex);
			}
		}

		private void ResetViewItems()
		{
			mnuItemViewNormal.Checked = false;
			mnuItemViewSelected.Checked = false;
			mnuItemViewReport.Checked = false;
			mnuItemViewMainTree.Checked = false;
		}

		private void SetTreeNodesPerSelectedView()
		{
			if (mnuItemViewNormal.Checked)
				mnuItemViewNormal_OnClick(null, null);

			if (mnuItemViewSelected.Checked)
				mnuItemViewSelected_OnClick(null, null);

			if (mnuItemViewReport.Checked)
				mnuItemViewReport_OnClick(null, null);

			if (mnuItemViewMainTree.Checked)
				mnuItemViewMainTree_OnClick(null, null);
		}

		private int GetCurrentView()
		{
			if (mnuItemViewNormal.Checked)
				return 0;

			if (mnuItemViewSelected.Checked)
				return 1;

			if (mnuItemViewReport.Checked)
				return 2;

			if (mnuItemViewMainTree.Checked)
				return 3;

			return 0;
		}

		private void SetCurrentView(int curView)
		{
			ResetViewItems();

			switch (curView)
			{
				case 0:
					mnuItemViewNormal.Checked = true;
					break;
				case 1:
					mnuItemViewSelected.Checked = true;
					break;
				case 2:
					mnuItemViewReport.Checked = true;
					break;
				case 3:
					mnuItemViewMainTree.Checked = true;
					break;
				default:
					mnuItemViewNormal.Checked = true;
					break;
			}
		}

		protected bool SaveView()
		{
			try
			{
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "GraphBuilderView", GetCurrentView().ToString());
			}
			catch
			{
				return false;
			}
			return true;
		}

		//mam
		private void LoadSelectedCache()
		{
			int curInfosetID = 0;
			infoSetCheckedCount = 0;

			//count infosets
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				okToLoad = false;
				if (DetermineSelectedCache(node))
					infoSetCheckedCount += 1;
			}

			//loop through the first level of nodes in the tree, which is the infoset level nodes
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				okToLoad = false;
				curInfosetID = ((WAM.Common.TreeViewItem)node.Tag).ItemID;
				if (curInfosetID == InfoSet.CurrentID || infoSetAlreadyCached.Contains(curInfosetID))
				{
					continue;
				}

				if (CacheManager.IsLoadedCacheForInfoSetID(curInfosetID))
				{
					continue;
				}

				if (DetermineSelectedCache(node))
				{
					infoSetAlreadyCached.Add(curInfosetID);
					LoadCacheForm.ShowForm(curInfosetID, this, true, false);
				}
			}
		}
		//</mam>

		//mam
		private bool DetermineSelectedCache(TreeNode node)
		{
			if (node.Checked)
			{
				okToLoad = true;
				return okToLoad;
			}

			if (!okToLoad)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					DetermineSelectedCache(nodeChild);
				}
			}
			return okToLoad;
		}
		//</mam>

		//mam
		private void CountCheckedNodes()
		{
			checkedNodeCount = 0;
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				CountCheckedNodes2(node);
			}
			labelCheckedNodeCount.Text = "Report items selected: " + checkedNodeCount.ToString();
		}
		//</mam>

		//mam
		private void CountCheckedNodes2(TreeNode node)
		{
			if (node.Checked)
				checkedNodeCount++;

			foreach (TreeNode nodeChild in node.Nodes)
			{
				CountCheckedNodes2(nodeChild);
			}
		}
		//</mam>

		//mam
		private void CountReportTypeNodes()
		{
			reportTypeCount = 0;
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				CountReportTypeNodes2(node);
			}
			UpdateReportTypeLabel();
		}
		//</mam>

		//mam
		private void CountReportTypeNodes2(TreeNode node)
		{
			if (node.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				reportTypeCount++;

			foreach (TreeNode nodeChild in node.Nodes)
			{
				CountReportTypeNodes2(nodeChild);
			}
		}
		//</mam>

		private NodeType GetSelectedUnitType2()
		{
			//return the selected unit type based on ComboBoxItem rather than ListItem, as in GetSelectedUnitType
			if (comboBoxReportType.SelectedItem == null)
				return NodeType.Facility;
			else
				return (NodeType)((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).EnumValue;
		}

		//mam - new method to return a string, rather than a NodeType
		private string GetSelectedUnitTypeString()
		{
			// Check to see what unit is selected
			if (comboBoxReportType.SelectedItem == null)
				return NodeType.Facility.ToString();
			else
				return ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemTag;
		}
		//</mam>

		//mam
		private void GetSelectedUnits()
		{
			Facility facility;
			TreatmentProcess process;
			MajorComponent component;
			Discipline discipline;

			m_graphUnitManager.Clear();

			switch (currentSelectedUnitType)
			{
				case "Facility":
				{
					for (int i = 0; i < SelectedFac.Count; i++)
					{
						facility = CacheManager.GetFacility(((WAM.Common.TreeViewItem)SelectedFac[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedFac[i]).ItemID);
						m_graphUnitManager.AddUnit((IGraphableUnit)facility);
					}

					break;
				}
				case "TreatmentProcess":
				{
					for (int i = 0; i < SelectedProc.Count; i++)
					{
						process = CacheManager.GetTreatmentProcess(((WAM.Common.TreeViewItem)SelectedProc[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedProc[i]).ItemID);
						//MessageBox.Show("add from process to m_graphUnitManager: " + process.Name);
						m_graphUnitManager.AddUnit((IGraphableUnit)process);
					}
					break;
				}
				case "MajorComponent":
				{
					for (int i = 0; i < SelectedComp.Count; i++)
					{
						component = CacheManager.GetMajorComponent(((WAM.Common.TreeViewItem)SelectedComp[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedComp[i]).ItemID);
						m_graphUnitManager.AddUnit((IGraphableUnit)component);
					}
					break;
				}
				case "DisciplineMech":
				{
					for (int i = 0; i < SelectedDiscMech.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscMech[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscMech[i]).ItemID, WAM.Data.DisciplineType.Mechanical);
						m_graphUnitManager.AddUnit((IGraphableUnit)discipline);
					}
					break;
				}
				case "DisciplineLand":
				{
					for (int i = 0; i < SelectedDiscLand.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscLand[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscLand[i]).ItemID, WAM.Data.DisciplineType.Land);
						m_graphUnitManager.AddUnit((IGraphableUnit)discipline);
					}
					break;
				}
				case "DisciplineStruct":
				{
					for (int i = 0; i < SelectedDiscStruct.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscStruct[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscStruct[i]).ItemID, WAM.Data.DisciplineType.Structural);
						m_graphUnitManager.AddUnit((IGraphableUnit)discipline);
					}
					break;
				}
				case "DisciplinePipe":
				{
					for (int i = 0; i < SelectedDiscPipe.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscPipe[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscPipe[i]).ItemID, WAM.Data.DisciplineType.Pipes);
						//MessageBox.Show(discipline.GetFullName().ToString());
						//MessageBox.Show(discipline.GetFullNameWithInfoset().ToString());
						m_graphUnitManager.AddUnit((IGraphableUnit)discipline);
					}
					break;
				}
				case "DisciplineNode":
				{
					for (int i = 0; i < SelectedDiscNode.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscNode[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscNode[i]).ItemID, WAM.Data.DisciplineType.Nodes);
						m_graphUnitManager.AddUnit((IGraphableUnit)discipline);
					}
					break;
				}

				//use DiscAll
				case "Discipline":
				{
					for (int i = 0; i < SelectedDiscAllMech.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscAllMech[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscAllMech[i]).ItemID, WAM.Data.DisciplineType.Mechanical);
						m_graphUnitManager.AddUnitForceAddition((IGraphableUnit)discipline);
					}
					for (int i = 0; i < SelectedDiscAllLand.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscAllLand[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscAllLand[i]).ItemID, WAM.Data.DisciplineType.Land);
						m_graphUnitManager.AddUnitForceAddition((IGraphableUnit)discipline);
					}
					for (int i = 0; i < SelectedDiscAllStruct.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscAllStruct[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscAllStruct[i]).ItemID, WAM.Data.DisciplineType.Structural);
						m_graphUnitManager.AddUnitForceAddition((IGraphableUnit)discipline);
					}
					for (int i = 0; i < SelectedDiscAllPipe.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscAllPipe[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscAllPipe[i]).ItemID, WAM.Data.DisciplineType.Pipes);
						m_graphUnitManager.AddUnitForceAddition((IGraphableUnit)discipline);
					}
					for (int i = 0; i < SelectedDiscAllNode.Count; i++)
					{
						discipline = CacheManager.GetDiscipline(((WAM.Common.TreeViewItem)SelectedDiscAllNode[i]).InfoSetID, ((WAM.Common.TreeViewItem)SelectedDiscAllNode[i]).ItemID, WAM.Data.DisciplineType.Nodes);
						m_graphUnitManager.AddUnitForceAddition((IGraphableUnit)discipline);
					}
					break;
				}
			}
		}
		//</mam>

		private void CheckPreviewProperties()
		{
			if (graphViewer.WindowState == FormWindowState.Minimized 
				|| graphViewer.Height < 50 
				|| Math.Abs(graphViewer.Left) > 2000 || Math.Abs(graphViewer.Top) > 2000)
			{
				graphViewer.WindowState = FormWindowState.Normal;
				graphViewer.Size = new Size(this.Width, this.Height);
				graphViewer.Location = this.Location;
			}
		}

		//mam - added comboBox parameter
		private GraphYAxis	GetSelectedYAxisVariable(ComboBox comboBox)
		{
			ListItem		item = comboBox.SelectedItem as ListItem;
			
			if (item == null)
				return GraphYAxis.AcquisitionCost;

			return (GraphYAxis)item.Value;
		}
		//</mam>

		private void		LoadYAxisValues(ComboBox comboBox)
		{
			int				selectedIndex = 0;

			//mam - get a string representation of the selected unit type
			//NodeType		selectedUnitType = GetSelectedUnitType();
			string selectedUnitType = GetSelectedUnitTypeString();
			//</mam>

			comboBox.Sorted = true;
			if (comboBox.Items.Count > 0)
				selectedIndex = comboBox.SelectedIndex;

			comboBox.BeginUpdate();
			comboBox.Items.Clear();
			comboBox.DisplayMember = "DisplayMember";
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.AcquisitionCost),
				GraphYAxis.AcquisitionCost));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.CurrentValue),
				GraphYAxis.CurrentValue));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.ReplacementValue),
				GraphYAxis.ReplacementValue));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.BookValue),
				GraphYAxis.BookValue));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.SalvageValue),
				GraphYAxis.SalvageValue));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.AnnualDepreciation),
				GraphYAxis.AnnualDepreciation));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.CumulativeDepreciation),
				GraphYAxis.CumulativeDepreciation));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.EvaluatedValue),
				GraphYAxis.EvaluatedValue));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.RepairCost),
				GraphYAxis.RepairCost));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.AnnualMaintenanceCost),
				GraphYAxis.AnnualMaintenanceCost));

			//mam 050806
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.AcquisitionCostEscalated),
				GraphYAxis.AcquisitionCostEscalated));
			comboBox.Items.Add(
				new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.RehabCost),
				GraphYAxis.RehabCost));

			// Check to see what unit is selected
			//mam - use string rather than NodeType
			//if (selectedUnitType != NodeType.Facility && selectedUnitType != NodeType.TreatmentProcess)
			if (selectedUnitType != NodeType.Facility.ToString() && 
				selectedUnitType != NodeType.TreatmentProcess.ToString())
				//</mam>
			{
				// Allow these selections on components and disciplines
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.Condition),
					GraphYAxis.Condition));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.LOS),
					GraphYAxis.LOS));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.Vulnerability),
					GraphYAxis.Vulnerability));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.Criticality),
					GraphYAxis.Criticality));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.Risk),
					GraphYAxis.Risk));

				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.ConditionAndLOS),
					GraphYAxis.ConditionAndLOS));

				// Allow these selections on components and disciplines
				//mam 090105
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.OriginalUsefulLife),
					GraphYAxis.OriginalUsefulLife));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.RemainingUsefulLife),
					GraphYAxis.RemainingUsefulLife));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.EvaluatedRemainingUsefulLife),
					GraphYAxis.EvaluatedRemainingUsefulLife));
				comboBox.Items.Add(
					new ListItem(EnumHandlers.GetGraphYAxisString(GraphYAxis.EconomicRemainingUsefulLife),
					GraphYAxis.EconomicRemainingUsefulLife));
			}

			comboBox.EndUpdate();

			if (selectedIndex >= comboBox.Items.Count)
				selectedIndex = 0;

			comboBox.SelectedIndex = selectedIndex;
		}

		private void GraphBuilderForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (allowCheckDirty)
			{
				CheckDirty();
			}

			try
			{
				CheckPreviewProperties();
			}
			catch (SystemException ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
		}

		private void CloseGraphViewer()
		{
			try
			{
				CheckPreviewProperties();
				graphViewer.Close();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("GraphBuilderForm.buttonGraph_Click Error (attempting to close graphViewer): {0}\n", ex.Message));
			}
		}

		#endregion /***** Methods *****/

		//mam
		#region /***** Click Events *****/

		private void buttonSelectAll_Click(object sender, System.EventArgs e)
		{
			mnuItemSelectAll_OnClick(sender, e);
		}

		private void buttonClearAll_Click(object sender, System.EventArgs e)
		{
			mnuItemClearAll_OnClick(sender, e);
		}

		protected void mnuItemSelectAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(true);
		}

		protected void mnuItemClearAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(false);
		}

		protected void mnuItemExpandAll_OnClick(System.Object sender, System.EventArgs e)
		{
			try
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

				RebuildTree(true, -1);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemCollapseAll_OnClick(System.Object sender, System.EventArgs e)
		{
			treeViewSpecificUnits.CollapseAll();
		}

		protected void mnuItemSelectUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(true);
		}

		protected void mnuItemClearUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(false);
		}

		protected void mnuItemViewNormal_OnClick(System.Object sender, System.EventArgs e)
		{
			//show user-selected node expansion
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
			try
			{
				if (mnuItemViewNormal.Text == "User selection")
				{
					//begin user selection
					ResetViewItems();
					mnuItemViewNormal.Checked = true;
				}
				else
				{
					//restore most recent user selections (since form was opened)
					ResetViewItems();
					mnuItemViewNormal.Checked = true;
					mnuItemViewNormal.Text = "User selection";
					SaveView();

					RebuildTree(false, -1);

					if (treeViewSpecificUnits.Nodes.Count > 0)
						treeViewSpecificUnits.Nodes[0].EnsureVisible();
				}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewSelected_OnClick(System.Object sender, System.EventArgs e)
		{
			//expand nodes that are checked
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewSelected.Checked = true;
				SaveView();
				RebuildTree(false, -1);

				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewReport_OnClick(System.Object sender, System.EventArgs e)
		{
			//expand nodes that are of the selected graph type
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewReport.Checked = true;
				SaveView();
				RebuildTree(false, ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).EnumValue);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewMainTree_OnClick(System.Object sender, System.EventArgs e)
		{
			//expand the tree nodes to match the tree on the main form
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewMainTree.Checked = true;
				SaveView();
				RebuildTree(false, -1);

				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		private void buttonSendValuesToExcel_Click(object sender, System.EventArgs e)
		{
			buttonGraph_Click(sender, e);
		}

		private void SendGraphDataToExcelFile()
		{
			//mam 050806

			SaveFileDialog saveFileDialog = new SaveFileDialog();
			C1.C1Excel.C1XLBook excelBook = new C1XLBook();

			try
			{
				//open the file save dialog
				saveFileDialog.DefaultExt = "xls";
				saveFileDialog.FileName = "*.xls";
				saveFileDialog.Filter = "Excel (*.xls)|*.xls";
				saveFileDialog.Title = "Save Graph Values to Excel File";
				saveFileDialog.ValidateNames = true;
				saveFileDialog.OverwritePrompt = true;
				saveFileDialog.CheckPathExists = true;
				saveFileDialog.ShowHelp = true;
				saveFileDialog.AddExtension = true;
				//saveFileDialog.CreatePrompt = true;
				//saveFileDialog.DefaultExt = true;
				
				if (saveFileDialog.ShowDialog() != DialogResult.OK || saveFileDialog.FileName == "")
				{
					//OK button npt pressed or no file name specified
					return;
				}

				//write data to Excel rather than graphing it

				//C1.C1Excel.C1XLBook excelBook = new C1XLBook();
				XLSheet sheet;
				XLCell cell;
				GraphYAxis curYAxis = GraphYAxis.AcquisitionCost;
				int excelRow = 0;
				int excelCol = -1;
				bool isLosCond1 = false;
				bool isLosCond2 = false;
				bool useInspectionYear = true;
				string yearTypeName = "Inspection Year";

				int roundDigit = WAM.Common.Globals.AllowRoundingDigit;
				if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
				{
					roundDigit = 0;
				}

				if (excelBook.Sheets.Count == 0)
				{
					sheet = excelBook.Sheets.Add();
				}
				else
				{
					sheet = excelBook.Sheets[0];
				}

				//************************

				//write column headers to Excel file

				if (m_selectedUnits.Count > 0)
				{
					if (((GraphUnit)m_selectedUnits[0])[0] is Facility || ((GraphUnit)m_selectedUnits[0])[0] is TreatmentProcess)
					{
						yearTypeName = "Facility Year";
						useInspectionYear = false;
					}
				}

				cell = sheet[excelRow, ++excelCol];
				cell.Value = "Full Name";
				cell = sheet[excelRow, ++excelCol];
				cell.Value = comboBoxReportType.Text;
				cell = sheet[excelRow, ++excelCol];
				cell.Value = yearTypeName;

				if (m_yAxisVariable == GraphYAxis.ConditionAndLOS)
				{
					isLosCond1 = true;

					cell = sheet[excelRow, ++excelCol];
					cell.Value = WAM.Logic.UnitFilter.GetFilterSourceString(WAM.Logic.UnitFilter.FilterSource.LevelOfService);

					cell = sheet[excelRow, ++excelCol];
					cell.Value = WAM.Logic.UnitFilter.GetFilterSourceString(WAM.Logic.UnitFilter.FilterSource.ConditionRank);
				}
				else
				{
					cell = sheet[excelRow, ++excelCol];
					cell.Value = comboBoxYValue.Text;
				}

				if (this.showY2Axis && m_yAxisVariable2 == GraphYAxis.ConditionAndLOS)
				{
					isLosCond2 = true;

					cell = sheet[excelRow, ++excelCol];
					cell.Value = WAM.Logic.UnitFilter.GetFilterSourceString(WAM.Logic.UnitFilter.FilterSource.LevelOfService);

					cell = sheet[excelRow, ++excelCol];
					cell.Value = WAM.Logic.UnitFilter.GetFilterSourceString(WAM.Logic.UnitFilter.FilterSource.ConditionRank);
				}
				else if (this.showY2Axis)
				{
					cell = sheet[excelRow, ++excelCol];
					cell.Value = comboBoxYValue2.Text;
				}

				//************************

				for (int i = 0; i < m_selectedUnits.Count; i++)
				{
					excelRow++;
					GraphUnit graphUnit;
					IGraphableUnit unit;
					graphUnit = (GraphUnit)m_selectedUnits[i];
					for (int j = 0; j < graphUnit.Count; j++)
					{
						excelCol = -1;
						unit = graphUnit[j];

						cell = sheet[excelRow, ++excelCol]; 
						cell.Value = unit.GetFullNameWithInfoset().ToString();
						cell = sheet[excelRow, ++excelCol]; 
						cell.Value = unit.GetShortName().ToString();
						cell = sheet[excelRow, ++excelCol]; 

						if (useInspectionYear)
						{
							cell.Value = unit.GetInspectionYear();
						}
						else
						{
							cell.Value = unit.GetYearValue();
						}

						//**********************

						for (int axisNumber = 1; axisNumber <= 2; axisNumber++)
						{
							//determine the column to be populated

							curYAxis = m_yAxisVariable;
							if (axisNumber == 2)
							{
								curYAxis = m_yAxisVariable2;
							}

							bool isPipe = false;
							bool isNode = false;
							if (unit is WAM.Data.DisciplinePipe)
								isPipe = true;
							else if (unit is WAM.Data.DisciplineNode)
								isNode = true;

							cell = sheet[excelRow, ++excelCol]; 
							if (axisNumber == 1)
							{
								if (isLosCond1)
								{
									PopulateExcelCell(curYAxis, unit.GetYAxisValue(GraphYAxis.LOS, isPipe, isNode), cell, roundDigit);

									cell = sheet[excelRow, ++excelCol];
									if (isPipe || isNode)
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(GraphYAxis.Condition, isPipe, isNode), cell, roundDigit);
									}
									else
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(GraphYAxis.Condition), cell, roundDigit);
									}
								}
								else
								{
									if (isPipe || isNode)
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(curYAxis, isPipe, isNode), cell, roundDigit);
									}
									else
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(curYAxis), cell, roundDigit);
									}
								}
							}
							else
							{
								if (isLosCond2)
								{
									PopulateExcelCell(curYAxis, unit.GetYAxisValue(GraphYAxis.LOS, isPipe, isNode), cell, roundDigit);

									cell = sheet[excelRow, ++excelCol];
									PopulateExcelCell(curYAxis, unit.GetYAxisValue(GraphYAxis.Condition, isPipe, isNode), cell, roundDigit);
								}
								else if (this.showY2Axis)
								{
									if (isPipe || isNode)
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(curYAxis, isPipe, isNode), cell, roundDigit);
									}
									else
									{
										PopulateExcelCell(curYAxis, unit.GetYAxisValue(curYAxis), cell, roundDigit);
									}
								}
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error has occurred: " + ex.Message, "Send Graph Data to Excel", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}

			try
			{
				//save file
				excelBook.Save(saveFileDialog.FileName);
			}
			catch
			{
				string msgText = "An error has occurred while trying to save the Excel file.";
				msgText += "\r\n\r\nPlease make sure the Excel file is not already open in another application.";

				MessageBox.Show(msgText, "Save Excel File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		
		private void PopulateExcelCell(GraphYAxis curYAxis, decimal curValue, XLCell cell, int roundDigit)
		{
			try
			{
				bool isNA = false;
				if (curYAxis == GraphYAxis.LOS )
				{
					if (curValue == 0)
						curValue = -1;
				}

				//determine n/a for pipes and nodes
				if (curYAxis == GraphYAxis.Criticality || curYAxis == GraphYAxis.Vulnerability || curYAxis == GraphYAxis.Risk)
				{
					if (curValue == -1)
						isNA = true;
				}

				if (curYAxis == GraphYAxis.LOS || curYAxis == GraphYAxis.Condition || curYAxis == GraphYAxis.ConditionAndLOS)
				{
					if (curValue == -1)
						isNA = true;
				}

				if (isNA)
				{
					cell.Value = "N/A";
				}
				else
				{
					if (curYAxis == GraphYAxis.LOS || curYAxis == GraphYAxis.Condition || curYAxis == GraphYAxis.ConditionAndLOS)
					{
						curValue = Math.Round(curValue, 1);
						cell.Value = curValue;
					}
					else
					{
						curValue = WAMRounding.RoundNumber(curValue, roundDigit);
						cell.Value = curValue;
					}
				}
			}
			catch(Exception ex)
			{
				
				MessageBox.Show("An error has occurred: " + ex.Message, "PopulateExcelCell", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void buttonGraph_Click(object sender, System.EventArgs e)
		{
			//mam
			GetSelectedTreeNodes();
			LoadSelectedCache();
			GetSelectedUnits();

			m_selectedUnits.Clear();
			for (int i = 0; i < m_graphUnitManager.Count; i++)
			{
				m_selectedUnits.Add(m_graphUnitManager[i]);
			}

			if (m_selectedUnits.Count == 0)
			{
				MessageBox.Show("Please select at least one item to graph", "Select Graph Data", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			m_yAxisVariable = GetSelectedYAxisVariable(comboBoxYValue);
			m_yAxisVariable2 = GetSelectedYAxisVariable(comboBoxYValue2);

			if (((Button)sender).Name.Equals(buttonSendValuesToExcel.Name))
			{
				SendGraphDataToExcelFile();
				return;
			}

			try
			{
				//this should not be necessary now because the displayer is to be recreated
				CheckPreviewProperties();
				graphViewer.Close();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("GraphBuilderForm.buttonGraph_Click Error (attempting to close graphViewer): {0}\n", ex.Message));
			}

			graphViewer = new GraphViewerForm();

			if (infoSetCheckedCount > 1)
			{
				objGraphSettings.SetValue(true, 1);
			}
			else
			{
				objGraphSettings.SetValue(false, 1);
			}

			NodeType selUnitType = GetSelectedUnitType2();
			string unitType =  WAM.UI.NodeTypeHandler.GetNodeTypeString(selUnitType);
			if (unitType == "N/A")
				unitType = "Discipline";

			graphViewer.SetValues(this.m_selectedUnits, this.m_yAxisVariable, this.m_yAxisVariable2, this.showY2Axis, unitType, this, this, ref objGraphSettings);
			//</mam>
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void GraphBuilderForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				allowCheckDirty = false;
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void pictureBoxTemplateEdit_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				MessageBox.Show("There are no graph templates to edit.", "Edit Graph Template Name", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			newTemplateNameFromForm = comboBoxReportTemplate.Text;
			if (GraphTemplate.ShowForm(ref newTemplateNameFromForm, "Graph Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					if (!SaveReportTemplate(false, false, @newTemplateNameFromForm, true))
						MessageBox.Show("An error has occurred.  The graph template was not saved.", "Save Graph Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
					MessageBox.Show("The graph template name contains no characters.", "New Graph Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
		}

		private void pictureBoxTemplateResetChartProp_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			ResetChartProperties();
		}

		#endregion /***** Click Events *****/
		//</mam>

		//mam
		#region /***** Tree Handling Code *****/

		private void CheckNodes(TreeNode nodeStart, string graphUnitType, bool checkNode, bool checkNodeStart)
		{
			//check all nodes of a certain node type under nodeStart

			if (checkNodeStart)
			{
				if (nodeStart.Tag.ToString() == graphUnitType)
				{
					nodeStart.Checked = checkNode;
				}
			}

			foreach(TreeNode nodeChild in nodeStart.Nodes)
			{
				if (nodeChild.Tag.ToString() == graphUnitType || (graphUnitType == "Discipline" && nodeChild.Tag.ToString().StartsWith("Discipline")))
				{
					nodeChild.Checked = checkNode;
				}

				if (nodeChild.Nodes.Count > 0)
				{
					CheckNodes(nodeChild, graphUnitType, checkNode, checkNodeStart);
				}
			}
		}

		private void CheckNodesBasedOnTextColor(TreeNode nodeStart, bool checkNode, bool checkNodeStart)
		{
			//check all nodes that are not greyed out

			if (checkNodeStart)
			{
				if (nodeStart.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				{
					nodeStart.Checked = checkNode;
				}
			}

			foreach(TreeNode nodeChild in nodeStart.Nodes)
			{
				if (nodeChild.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				{
					nodeChild.Checked = checkNode;
				}

				if (nodeChild.Nodes.Count > 0)
				{
					CheckNodesBasedOnTextColor(nodeChild, checkNode, checkNodeStart);
				}
			}
		}

		private void CheckNodesAll(bool checkNode)
		{
			autoChecking = true;

			string curReportType = ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemTag;
			if (curReportType == "Discipline")
			{
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					CheckNodesBasedOnTextColor(node, checkNode, true);
				}
			}
			else
			{
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					CheckNodes(node, curReportType, checkNode, true);
				}
			}

			autoChecking = false;
			CountCheckedNodes();
		}

		private void CheckNodesAll2(TreeNode node, bool checkNode)
		{
			node.Checked = checkNode;
			if (node.Nodes.Count > 0)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					CheckNodesAll2(nodeChild, checkNode);
				}
			}
		}

		private void SelectUnder(bool checkNode)
		{
			autoChecking = true;

			//may not do this:
			//check for red or black ForeColor because we're color-coding them red or black
			//	to match the main data tree
			if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				//if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
			{
				if (nodeHitTest.Parent != null)
				{
					CheckNodes(nodeHitTest.Parent, ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemTag, checkNode, false);
				}
			}
			else
			{
				CheckNodes(nodeHitTest, ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemTag, checkNode, false);
			}

			autoChecking = false;
			CountCheckedNodes();
		}

		private void treeViewSpecificUnits_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
				
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
			else
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor == System.Drawing.SystemColors.GrayText)
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
			}
		}

		private void treeViewSpecificUnits_Click(object sender, System.EventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null && nodeSelected != null && nodeHitTest == nodeSelected)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
			}
		}

		private void treeViewSpecificUnits_AfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
		}

		private void treeViewSpecificUnits_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
			if (treeViewSpecificUnits.SelectedNode == null)
			{
				treeViewSpecificUnits.SelectedNode = treeViewSpecificUnits.Nodes[0];
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
		}

		private void treeViewSpecificUnits_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			nodeHitTest = treeViewSpecificUnits.GetNodeAt(e.X, e.Y);
		}

		private void treeViewSpecificUnits_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (nodeHitTest != null)
				CountCheckedNodes();
		}

		private void treeViewSpecificUnits_AfterCollapse(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeCollapse(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
		}

		private void treeViewSpecificUnits_BeforeCheck(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (rebuildingTree)
				return;

			if (nodeHitTest == null || autoChecking == true)
				return;

			if (nodeHitTest.ForeColor == System.Drawing.SystemColors.GrayText)
			{
				e.Cancel = true;
			}
		}

		private void RecordTreeExpandedState()
		{
			nodesExpanded.Clear();

			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				RecordTreeExpandedNodes(node);
			}
		}

		private void RecordTreeExpandedNodes(TreeNode node)
		{
			if (node.IsExpanded)
			{
				//nodesExpanded.Add((WAM.Common.TreeViewItem)node.Tag);
				nodesExpanded.Add(((WAM.Common.TreeViewItem)node.Tag).NodeCount);
			}
			foreach (TreeNode childNode in node.Nodes)
			{
				RecordTreeExpandedNodes(childNode);
			}
		}

		private void GetSelectedTreeNodes()
		{
			printItems.Clear();

			// Add the checked nodes to the printItems array
			foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
			{
				if (treeNode.Checked)
				{
					printItems.Add((WAM.Common.TreeViewItem)treeNode.Tag);
				}
				if (treeNode.Nodes.Count > 0)
				{
					GetCheckedNodes(treeNode);
				}
			}

			RecordSelectedNodes();
		}

		private void GetCheckedNodes(TreeNode parent)
		{
			TreeNode node;

			for (int pos = 0; pos < parent.Nodes.Count; pos++)
			{
				node = parent.Nodes[pos];

				if (node.Checked)
				{
					//MessageBox.Show(node.Text);
					printItems.Add((WAM.Common.TreeViewItem)node.Tag);
				}

				if (node.Nodes.Count > 0)
				{
					GetCheckedNodes(node);
				}
			}
		}

		private void RecordSelectedNodes()
		{
//			// Add the nodes in printItems[] to the various array lists
			switch (currentSelectedUnitType)
			{
				case "Facility":
				{
					SelectedFac.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedFac.Add(printItems[i]);
					}
					break;
				}
				case "TreatmentProcess":
				{
					SelectedProc.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//MessageBox.Show("add from printItems to SelectedProc: " + ((WAM.Common.TreeViewItem)printItems[i]).ItemDescription.ToString());
						SelectedProc.Add(printItems[i]);
					}
					break;
				}
				case "MajorComponent":
				{
					SelectedComp.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedComp.Add(printItems[i]);
					}
					break;
				}
				case "DisciplineMech":
				{
					SelectedDiscMech.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedDiscMech.Add(printItems[i]);
					}
					break;
				}
				case "DisciplineLand":
				{
					SelectedDiscLand.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedDiscLand.Add(printItems[i]);
					}
					break;
				}
				case "DisciplineStruct":
				{
					SelectedDiscStruct.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedDiscStruct.Add(printItems[i]);
					}
					break;
				}
				case "DisciplinePipe":
				{
					SelectedDiscPipe.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedDiscPipe.Add(printItems[i]);
					}
					break;
				}
				case "DisciplineNode":
				{
					SelectedDiscNode.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedDiscNode.Add(printItems[i]);
					}
					break;
				}
				//mam - use DiscAll
				//case NodeType.NoneSelected:
				case "Discipline":
				{
					SelectedDiscAllLand.Clear();
					SelectedDiscAllMech.Clear();
					SelectedDiscAllStruct.Clear();
					SelectedDiscAllNode.Clear();
					SelectedDiscAllPipe.Clear();

					for (int i = 0; i < printItems.Count; i++)
					{
						if (printItems[i].ToString() == NodeType.DisciplineLand.ToString())
							SelectedDiscAllLand.Add(printItems[i]);
						else if (printItems[i].ToString() ==  NodeType.DisciplineMech.ToString())
							SelectedDiscAllMech.Add(printItems[i]);
						else if (printItems[i].ToString() ==  NodeType.DisciplineStruct.ToString())
							SelectedDiscAllStruct.Add(printItems[i]);
						else if (printItems[i].ToString() ==  NodeType.DisciplineNode.ToString())
							SelectedDiscAllNode.Add(printItems[i]);
						else if (printItems[i].ToString() ==  NodeType.DisciplinePipe.ToString())
							SelectedDiscAllPipe.Add(printItems[i]);
					}
					break;
				}
				//</mam>
			}
		}

		private void ResurrectSelectedNodes(TreeNode node)
		{
			string curRestoreInfo = ((WAM.Common.TreeViewItem)node.Tag).ItemTag.ToString();
			curRestoreInfo += ((WAM.Common.TreeViewItem)node.Tag).ItemID.ToString();

			// check the node if it has been previously selected and if it is currently enabled (not greyed out)
			if (restoreItems.Contains(curRestoreInfo) && node.ImageIndex != 1)
			{
				node.Checked = true;

				// if current view is selected (checked) items only, expand all ancestors for selected nodes
				if (mnuItemViewSelected.Checked)
				{
					TreeNode node2 = node;
					while (node2.Parent != null)
					{
						node2.Parent.Expand();
						node2 = node2.Parent;
					}
				}
			}

			foreach (TreeNode treeNode in node.Nodes)
			{
				ResurrectSelectedNodes(treeNode);
			}
		}

		//mam
		// load the nodes to be checked into the restoreItems array
		private void DetermineRestoreItems()
		{
			string curRestoreInfo = "";
			restoreItems.Clear();

			switch (currentSelectedUnitType)
			{
				case "Facility":
					for (int i = 0; i < SelectedFac.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedFac[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedFac[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "TreatmentProcess":
					for (int i = 0; i < SelectedProc.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedProc[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedProc[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "MajorComponent":
					for (int i = 0; i < SelectedComp.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedComp[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedComp[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "DisciplineMech":
					for (int i = 0; i < SelectedDiscMech.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscMech[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscMech[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "DisciplineStruct":
					for (int i = 0; i < SelectedDiscStruct.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscStruct[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscStruct[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "DisciplineLand":
					for (int i = 0; i < SelectedDiscLand.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscLand[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscLand[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "DisciplinePipe":
					for (int i = 0; i < SelectedDiscPipe.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscPipe[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscPipe[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "DisciplineNode":
					for (int i = 0; i < SelectedDiscNode.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscNode[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscNode[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;

				case "Discipline":
					for (int i = 0; i < SelectedDiscAllMech.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscAllMech[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscAllMech[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					for (int i = 0; i < SelectedDiscAllStruct.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscAllStruct[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscAllStruct[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					for (int i = 0; i < SelectedDiscAllLand.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscAllLand[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscAllLand[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					for (int i = 0; i < SelectedDiscAllPipe.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscAllPipe[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscAllPipe[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					for (int i = 0; i < SelectedDiscAllNode.Count; i++)
					{
						curRestoreInfo = (((WAM.Common.TreeViewItem)SelectedDiscAllNode[i]).ItemTag.ToString());
						curRestoreInfo += (((WAM.Common.TreeViewItem)SelectedDiscAllNode[i]).ItemID.ToString());
						restoreItems.Add(curRestoreInfo);
					}
					break;
			}
		}
		//</mam>

		//mam
		private void ResurrectExpandedNodes(TreeNode node)
		{
			//if (nodesExpandedResurrect.Contains((WAM.Common.TreeViewItem)node.Tag))
			if (nodesExpandedResurrect.Contains(((WAM.Common.TreeViewItem)node.Tag).NodeCount))
				node.Expand();

			foreach (TreeNode nodeChild in node.Nodes)
				ResurrectExpandedNodes(nodeChild);
		}
		//</mam>

		//mam
		private void ResurrectExpandedNodesMainTree(TreeNode node)
		{
			switch (node.Tag.ToString())
			{
				case "InfoSet":
					if (selectedInfoSetMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "Facility":
					if (selectedFacMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "TreatmentProcess":
					if (selectedProcMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "MajorComponent":
					if (selectedCompMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "DisciplineMech":
					if (selectedDiscMechMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "DisciplineStruct":
					if (selectedDiscStructMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "DisciplineLand":
					if (selectedDiscLandMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "DisciplinePipe":
					if (selectedDiscPipeMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
				case "DisciplineNode":
					if (selectedDiscNodeMainTree.Contains(((WAM.Common.TreeViewItem)node.Tag).ItemID))
						node.Expand();
					break;
			}

			foreach (TreeNode nodeChild in node.Nodes)
				ResurrectExpandedNodesMainTree(nodeChild);
		}
		//</mam>

		private void DetermineRestoreItemsMainTree()
		{
			for (int i = 0; i < nodesExpandedMainForm.Count; i++)
			{
				if (nodesExpandedMainForm[i] is InfoSet)
					selectedInfoSetMainTree.Add(((InfoSet)nodesExpandedMainForm[i]).ID);
				if (nodesExpandedMainForm[i] is Facility)
					selectedFacMainTree.Add(((Facility)nodesExpandedMainForm[i]).ID);
				else if (nodesExpandedMainForm[i] is TreatmentProcess)
					selectedProcMainTree.Add(((TreatmentProcess)nodesExpandedMainForm[i]).ID);
				else if (nodesExpandedMainForm[i] is MajorComponent)
				{
					// Check to see if it is a component or asset list node
					if (nodesExpandedMainForm[i] is DisciplineMech)
						return;
					else
						selectedCompMainTree.Add(((MajorComponent)nodesExpandedMainForm[i]).ID);
				}
				else
					continue;
			}
		}

		#endregion /***** Tree Handling Code *****/
		//</mam>

		#region /***** Template Code *****/

		private bool SavePreferences()
		{
			try
			{
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "GraphTemplateAutoSave", optionAutoSave.ToString());
			}
			catch
			{
				return false;
			}

			return true;
		}

		private void ResetChartProperties()
		{
			objGraphSettings.SetValue("", 0);
			if (SaveUserSettings())
			{
				MessageBox.Show("The graph properties have been reset for the current template.", "Reset Graph Properties", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
			{
				MessageBox.Show("An error has occurred.  The graph properties may not have been reset.", "Reset Graph Properties", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private bool SaveUserSettings()
		{
			//mam 07072011 - call a method in DataAccess rather than creating a command object here
			////mam 102309
			////System.Data.OleDb.OleDbCommand cmd = null;
			//System.Data.SqlClient.SqlCommand cmd = null;

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			//cmd = dataAccess.GetCommandObject();

			StringBuilder builder = new StringBuilder(200);

			builder.AppendFormat(@"UPDATE ReportTemplate SET ChartProperties = '{0}'", Drive.SQL.PadString(objGraphSettings.GetValue(0).ToString()));
			builder.AppendFormat(" WHERE ReportTemplateID = {0}", currentTemplateID);

			try
			{
				//mam 07072011
				//if (cmd == null)
				//	return false;
				//cmd.CommandText = builder.ToString();
				//cmd.ExecuteNonQuery();
				
				dataAccess.ExecuteCommand(builder.ToString());
			}
			catch(Exception ex)
			{
				Common.CommonTasks.ShowErrorMessage("GraphBuilderForm.SaveUserSettings", ex.Message);
			}
			finally
			{
				//cmd = null;
				dataAccess = null;
			}

			return true;
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphingNew.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphingNew.htm");
		}

		private void pictureBoxToolbarSave_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			forceSave = true;

			if (comboBoxReportTemplate.Items.Count == 0)
			{
				pictureBoxToolbarCopy_Click(sender, e);
			}
			else
			{
				if (!SaveReportTemplate(false, false, comboBoxReportTemplate.Text, false))
					MessageBox.Show("An error has occurred.  The graph template was not saved.", "Save Graph Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			ResetDirty();
		}
		//</mam>

		private void pictureBoxTemplateOptions_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			ReportTemplateOptions.ShowForm(ref optionAutoSave, "Graph Preferences", "Automatically save graph templates", this);
		}

		//mam
		private bool SaveReportTemplate(bool newTemplate, bool saveAs, string templateName, bool nameChangeOnly)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			savingTemplate = true;

			int valueReportType = 0;
			string selectionY1 = GetSelectedYAxisVariable(comboBoxYValue).ToString();
			string selectionY2 = GetSelectedYAxisVariable(comboBoxYValue2).ToString();

			if (!checkBoxY2.Checked)
			{
				selectionY2 = "";
			}

			int templateID = 0;
			if (!newTemplate)
			{
				templateID = currentTemplateID;
			}

			if (templateID == 0)
			{
				//there is no existing template, and the app is trying to automatically
				//	save a template because the user has triggered the automatic save
				//	(by closing the form when it has unsaved data, for instance)
				newTemplate = true;
				saveAs = true;
			}
			
			if (templateName.Trim() == "")
				templateName = "Default Template";

			StringBuilder builder = new StringBuilder(200);

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			if (!nameChangeOnly)
			{
				valueReportType = ((WAM.Common.ComboBoxItem)comboBoxReportType.SelectedItem).ItemID;
			}

			if (newTemplate)
			{
				builder.Append(@"INSERT INTO ReportTemplate (InfoSetID, ReportType, TemplateName, GraphTemplate, GraphYAxis1, GraphYAxis2, ChartProperties)");
				builder.AppendFormat(" VALUES ({0}, 0, '{1}', 1,", InfoSet.CurrentID, Drive.SQL.PadString(templateName));
				builder.AppendFormat(" '{0}', '{1}', '')", selectionY1.ToString(), selectionY2.ToString());

				templateID = dataAccess.ExecuteCommandReturnAutoID(builder.ToString());
				if (templateID == 0)
				{
					ResetDirty();
					this.Cursor = System.Windows.Forms.Cursors.Default;
					return false;
				}
				else
				{
					// carry on with saving
					if (saveAs)
					{
						//copy the existing node selections
						if (!SaveTemplateNodesChecked(templateID))
						{
							ResetDirty();
							this.Cursor = System.Windows.Forms.Cursors.Default;
							return false;
						}
					}
				}
			}
			else if (nameChangeOnly)
			{
				builder.AppendFormat("UPDATE ReportTemplate SET TemplateName = '{0}'", Drive.SQL.PadString(templateName));
				builder.AppendFormat(" WHERE ReportTemplateID = {0}", templateID);

				if (!dataAccess.ExecuteCommand(builder.ToString()))
				{
					ResetDirty();
					this.Cursor = System.Windows.Forms.Cursors.Default;
					return false;
				}
			}
			else
			{
				// save existing template
				if (dirtyTemplate || forceSave)
				{
					builder.AppendFormat("UPDATE ReportTemplate SET InfoSetID = {0},", InfoSet.CurrentID);
					builder.AppendFormat(" ReportType = {0},", valueReportType);
					builder.AppendFormat(" TemplateName = '{0}',", Drive.SQL.PadString(templateName));
					builder.AppendFormat(" GraphYAxis1 = '{0}',", selectionY1.ToString());
					builder.AppendFormat(" GraphYAxis2 = '{0}',", selectionY2.ToString());
					builder.AppendFormat(" ChartProperties = '{0}'", Drive.SQL.PadString(objGraphSettings.GetValue(0).ToString()));
					builder.AppendFormat(" WHERE ReportTemplateID = {0}", templateID);

					if (!dataAccess.ExecuteCommand(builder.ToString()))
					{
						ResetDirty();
						this.Cursor = System.Windows.Forms.Cursors.Default;
						return false;
					}
				}
					
				// carry on with saving
				if (dirtyNodes || forceSave)
				{
					if (!SaveTemplateNodesChecked(templateID))
					{
						ResetDirty();
						this.Cursor = System.Windows.Forms.Cursors.Default;
						return false;
					}
				}
			}

			if (!nameChangeOnly)
			{
				ResetDirty();
			}

			if (newTemplate || nameChangeOnly)
			{
				LoadTemplateCombo();
				SetComboIndex(comboBoxReportTemplate, templateID);
				currentTemplateID = templateID;
			}

			this.Cursor = System.Windows.Forms.Cursors.Default;
			savingTemplate = false;
			//ResetDirty();
			return true;
		}
		//</mam>

		private void ResetDirty()
		{
			dirtyNodes = false;
			dirtyTemplate = false;
			forceSave = false;
		}

		private void pictureBoxToolbarCopy_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			if (comboBoxReportTemplate.Items.Count > 0)
				CheckDirty();

			forceSave = true;

			if (comboBoxReportTemplate.Items.Count > 0)
				newTemplateNameFromForm = string.Format("Copy of {0}", comboBoxReportTemplate.Text);
			else
				newTemplateNameFromForm = string.Format("New Graph Template");

			if (GraphTemplate.ShowForm(ref newTemplateNameFromForm, "Graph Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					if (!SaveReportTemplate(true, true, @newTemplateNameFromForm, false))
						MessageBox.Show("An error has occurred.  The graph template was not saved.", "Save Graph Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
					MessageBox.Show("The graph template name contains no characters.", "New Graph Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
			SetTreeNodesPerSelectedView();
			ResetDirty();
		}

		private void SetDirtyNodes(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			dirtyNodes = true;
		}

		private void SetDirtyTemplate(object sender, System.EventArgs e)
		{
			dirtyTemplate = true;
		}

		//mam - set which item is displayed in the combo box
		private void SetComboIndex(ComboBox comboBox, int comboBoxID)
		{
			for (int i = 0; i < comboBox.Items.Count; i++)
				if (((WAM.Common.ComboBoxItem)comboBox.Items[i]).ItemID == comboBoxID)
				{
					comboBox.SelectedIndex = i;
					break;
				}
		}
		//</mam>

		private void LoadTemplateCombo()
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			ArrayList ComboBoxItems = new ArrayList();
			StringBuilder builder = new StringBuilder(200);

			//clear the combo box whether or not there are any new items to put into it
			comboBoxReportTemplate.DataSource = null;
			comboBoxReportTemplate.Items.Clear();

			builder.Append(@"SELECT ReportTemplateID AS ID, 0 AS EnumValue, TemplateName AS Description FROM ReportTemplate");
			builder.AppendFormat(" WHERE InfoSetID = {0} AND GraphTemplate = 1", InfoSet.CurrentID);
			builder.Append(" ORDER BY TemplateName, ReportTemplateID");
			dataSet = dataAccess.GetDisconnectedDataset(builder.ToString());

			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.LoadTemplateCombo.");
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Unable to load combo box");
			
			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				ComboBoxItems.Add(new WAM.Common.ComboBoxItem((int)dataRow["ID"], 
					(string)dataRow["Description"], (int)dataRow["EnumValue"], ""));
			}

			if (ComboBoxItems.Count > 0)
			{
				comboBoxReportTemplate.DataSource = null;
				comboBoxReportTemplate.BeginUpdate();
				comboBoxReportTemplate.Items.Clear();
				comboBoxReportTemplate.DataSource = ComboBoxItems;
				comboBoxReportTemplate.EndUpdate();
			}
			
			if (comboBoxReportTemplate.Items.Count > 0)
				comboBoxReportTemplate.SelectedIndex = 0;
			
			comboBoxReportTemplate.DisplayMember = "ItemDescription";
			comboBoxReportTemplate.ValueMember = "ItemID";

			if (comboBoxReportTemplate.SelectedIndex > -1)
			{
				currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
			}
		}

		private void CheckDirty()
		{
			if (m_initialized && !savingTemplate)
			{
				bool saveData = true;

				//if dirty and not automatically saving, ask user whether or not to save changes
				if ((dirtyTemplate || dirtyNodes) && optionAutoSave == 0)
				{
					if (ReportTemplateDirty.ShowForm(ref optionAutoSave, "Save Graph Template Changes", this))
					{
						//user pressed the Yes button
						saveData = true;
					}
					else
					{
						//user pressed the No button
						saveData = false;
					}
					SavePreferences();
				}

				if ((dirtyTemplate || dirtyNodes) && saveData) 
				{
					if (!SaveReportTemplate(false, false, comboBoxReportTemplate.Text, false))
						MessageBox.Show("An error has occurred.  The graph template was not saved.", "Save Graph Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}

				ResetDirty();
			}
		}

		private bool SaveTemplateNodesChecked(int templateID)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataSet dataSet = new DataSet();
			string queryString = "";
			bool result = false;

			result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedAsset WHERE ReportTemplateID = " + templateID);

			if (!result)
				return false;

			GetSelectedTreeNodes();

			// Facility nodes *************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedFac.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedFac[i]).ItemID;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// Process nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedProc.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedProc[i]).ItemID;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);


			// Major Component nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedComp.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedComp[i]).ItemID;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			//mam - use DiscAll
			// DiscAll nodes *************************

			// DiscAllLand
			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllLand.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscAllLand[i]).ItemID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);
			
			// DiscAllMech
			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllMech.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscAllMech[i]).ItemID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscAllStruct
			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllStruct.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscAllStruct[i]).ItemID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscAllNodes
			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllNode.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscAllNode[i]).ItemID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscAllPipes
			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllPipe.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscAllPipe[i]).ItemID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);
			//</mam>

			// DiscLand nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			
			for (int i = 0; i < SelectedDiscLand.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscLand[i]).ItemID;
				dataRow["DiscAll"] = 0;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscMech nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedDiscMech.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscMech[i]).ItemID;
				dataRow["DiscAll"] = 0;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscStruct nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedDiscStruct.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscStruct[i]).ItemID;
				dataRow["DiscAll"] = 0;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscNode nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscNode.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscNode[i]).ItemID;
				dataRow["DiscAll"] = 0;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscPipe nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscPipe.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((WAM.Common.TreeViewItem)SelectedDiscPipe[i]).ItemID;
				dataRow["DiscAll"] = 0;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			return result;
		}

		private void pictureBoxToolbarAdd_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			CheckDirty();

			newTemplateNameFromForm = "New Graph Template";

			if (GraphTemplate.ShowForm(ref newTemplateNameFromForm, "New Graph Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					ResetDirty();
					ResetTemplateValues();
					if (!SaveReportTemplate(true, false, @newTemplateNameFromForm, false))
						MessageBox.Show("An error has occurred.  The new graph template was not created.", "Save Graph Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
					MessageBox.Show("The graph template name contains no characters.", "New Graph Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
			SetTreeNodesPerSelectedView();
			ResetDirty();
		}
		//</mam>

		private void ResetTemplateValues()
		{
			comboBoxReportType.SelectedIndex = 0;
			CheckNodesAll(false);

			checkBoxY2.Checked = false;
			if (comboBoxYValue.Items.Count > 0)
				comboBoxYValue.SelectedIndex = 0;
			if (comboBoxYValue2.Items.Count > 0)
				comboBoxYValue2.SelectedIndex = 0;

			ClearSelectedNodesArrays();

			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
				treeViewSpecificUnits.CollapseAll();

			objGraphSettings.SetValue("", 0);
			objGraphSettings.SetValue(false, 1);
		}

		//mam
		private void ClearSelectedNodesArrays()
		{
			SelectedFac.Clear();
			SelectedProc.Clear();
			SelectedComp.Clear();
			SelectedDiscMech.Clear();
			SelectedDiscStruct.Clear();
			SelectedDiscLand.Clear();
			SelectedDiscNode.Clear();
			SelectedDiscPipe.Clear();
			printItems.Clear();
			restoreItems.Clear();

			//mam - use DiscAll
			SelectedDiscAll.Clear();
			SelectedDiscAllLand.Clear();
			SelectedDiscAllMech.Clear();
			SelectedDiscAllStruct.Clear();
			SelectedDiscAllNode.Clear();
			SelectedDiscAllPipe.Clear();
			//</mam>
		}
		//</mam>

		private void pictureBoxTemplateDelete_Click(object sender, System.EventArgs e)
		{
			CloseGraphViewer();
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				MessageBox.Show("There are no graph templates to delete.", "Delete Graph Template", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			int templateID = 0;
			bool result = false;
			DialogResult dialogResult = DialogResult.No;

			if (comboBoxReportTemplate.SelectedIndex != -1)
			{
				dialogResult = MessageBox.Show("Would you like to delete graph template  '" 
					+ comboBoxReportTemplate.Text + "'  ?", "Delete Graph Template", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
			}

			if (dialogResult == DialogResult.Yes)
			{
				try
				{
					this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
					templateID = (int)comboBoxReportTemplate.SelectedValue;
					WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
					result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplate WHERE ReportTemplateID = " + templateID);
					if (result)
					{
						// delete successful
						int curSelIndex = comboBoxReportTemplate.SelectedIndex;

						savingTemplate = true;
						LoadTemplateCombo();
						SetReportTemplateSettings();
						savingTemplate = false;

						currentTemplateID = 0;
						if (comboBoxReportTemplate.Items.Count == 0)
						{
							ResetTemplateValues();
						}
						else
						{
							if (curSelIndex >= comboBoxReportTemplate.Items.Count)
								comboBoxReportTemplate.SelectedIndex = curSelIndex - 1;
							else
							{
								savingTemplate = true;
								comboBoxReportTemplate.SelectedIndex = curSelIndex;
								SetReportTemplateSettings();
								savingTemplate = false;
							}

							if (comboBoxReportTemplate.SelectedIndex > -1)
							{
								currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
							}
						}
					}
					else
					{
						MessageBox.Show("An error has occurred.  The graph template was not deleted.", "Delete Graph Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				finally
				{
					this.Cursor = System.Windows.Forms.Cursors.Default;
					SetTreeNodesPerSelectedView();
					ResetDirty();
				}
			}
		}

		private void SetReportTemplateSettings()
		{
			StringBuilder builder = new StringBuilder(200);
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				treeViewSpecificUnits.Refresh();
				currentSelectedUnitType = GetSelectedUnitTypeString();

				return;
			}

			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			ArrayList ComboBoxItems = new ArrayList();

			builder.AppendFormat(@"SELECT * FROM ReportTemplate WHERE ReportTemplateID = {0}", (int)comboBoxReportTemplate.SelectedValue);
			dataSet = dataAccess.GetDisconnectedDataset(builder.ToString());

			if (dataSet == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SetReportTemplateSettings.");
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];

			if (dataTable == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SetReportTemplateSettings.");
			}

			ResetTemplateValues();

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				if (dataRow["ReportType"] == System.DBNull.Value)
					comboBoxReportType.SelectedIndex = 0;
				else
					comboBoxReportType.SelectedIndex = Convert.ToInt32(dataRow["ReportType"]);

				if (dataRow["GraphYAxis1"].ToString().Length > 0)
				{
					SetComboBoxItem(comboBoxYValue, dataRow["GraphYAxis1"].ToString());
				}
				if (dataRow["GraphYAxis2"].ToString().Length > 0)
				{
					checkBoxY2.Checked = true;
					SetComboBoxItem(comboBoxYValue2, dataRow["GraphYAxis2"].ToString());
					SetY2Status();
				}

				//get user settings for graph
				string chartProperties = "";
				if (dataRow["ChartProperties"].ToString().Length > 0)
				{
					chartProperties = dataRow["ChartProperties"].ToString();
				}

				objGraphSettings = new object[] {chartProperties, false};
			}

			currentSelectedUnitType = GetSelectedUnitTypeString();
			SetReportTemplateCheckedNodes();
		}

		private void SetComboBoxItem(ComboBox comboBox, string listItemText)
		{
			if (comboBox == null)
				return;

			int i = 0;

			if (listItemText == "")
			{
				if (comboBox.Items.Count > 0)
					comboBox.SelectedIndex = 0;
			}
			else
			{
				for (i = 0; i < comboBox.Items.Count; i++)
				{
					if (((ListItem)comboBox.Items[i]).Value.ToString() == listItemText)
					{
						comboBox.SelectedIndex = i;
						break;
					}
				}
			}
		}

		private void SetReportTemplateCheckedNodes()
		{
			// Get the selected nodes from the database and set the tree accordingly
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			WAM.Common.TreeViewItem treeViewItem;
			DataTable dataTable;
			int templateID = (int)comboBoxReportTemplate.SelectedValue;
			int curNodeTypeInt = 0;
			string curSwitchValue = "";
			string curNodeTypeString = "";
			string selectedUnitType = GetSelectedUnitTypeString();
			string whereClauseOther = "";
			string whereClauseDisc = "";
			StringBuilder builder = new StringBuilder(200);

			if (selectedUnitType == "Discipline")
			{
				whereClauseOther = " AND ReportTemplateID = -1";
				whereClauseDisc = " AND Z.DiscAll = 1";
			}

			whereClauseOther = "";
			whereClauseDisc = "";

			SelectedFac.Clear();
			SelectedProc.Clear();
			SelectedComp.Clear();

			//mam - use DiscAll
			//SelectedDiscAll.Clear();
			SelectedDiscAllLand.Clear();
			SelectedDiscAllMech.Clear();
			SelectedDiscAllStruct.Clear();
			SelectedDiscAllNode.Clear();
			SelectedDiscAllPipe.Clear();
			//</mam>

			SelectedDiscLand.Clear();
			SelectedDiscMech.Clear();
			SelectedDiscStruct.Clear();
			SelectedDiscNode.Clear();
			SelectedDiscPipe.Clear();
			//SelectedAsset.Clear();

			//All nodes ************************************
//			builder.Append("SELECT 1 AS SortBy, 'Fac' AS NodeType, NodeID FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 2 AS SortBy, 'Proc' AS NodeType, NodeID FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 3 AS SortBy, 'Comp' AS NodeType, NodeID FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 4 AS SortBy, 'DiscLand' AS NodeType, NodeID FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 5 AS SortBy, 'DiscMech' AS NodeType, NodeID FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 6 AS SortBy, 'DiscStruct' AS NodeType, NodeID FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 7 AS SortBy, 'DiscNode' AS NodeType, NodeID FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = 15");
//			builder.Append(" UNION SELECT 8 AS SortBy, 'DiscPipe' AS NodeType, NodeID FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = 15");
//			builder.Append(" ORDER BY SortBy");

			//this is getting out of hand now
			builder.Append("SELECT 1 AS SortBy, 'Fac' AS NodeType, X.infoset_id, Z.NodeID, X.facility_name AS NodeName, -1 AS ForDiscAll"); 
			builder.Append(" FROM ReportTemplateNodesCheckedFac Z INNER JOIN Facilities X ON Z.NodeID = X.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseOther); 

			builder.Append(" UNION SELECT 2 AS SortBy, 'Proc' AS NodeType, X2.infoset_id, Z.NodeID, X.process_name AS NodeName, -1 AS ForDiscAll"); 
			builder.Append(" FROM (ReportTemplateNodesCheckedProc Z INNER JOIN TreatmentProcesses X ON Z.NodeID = X.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON X.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseOther); 

			builder.Append(" UNION SELECT 3 AS SortBy, 'Comp' AS NodeType, X2.infoset_id, Z.NodeID, X.component_name AS NodeName, -1 AS ForDiscAll"); 
			builder.Append(" FROM ((ReportTemplateNodesCheckedComp Z INNER JOIN MajorComponents X ON Z.NodeID = X.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON X.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseOther); 

			builder.Append(" UNION SELECT 4 AS SortBy, 'DiscLand' AS NodeType, X2.infoset_id, Z.NodeID, 'DiscLand' AS NodeName, Z.DiscAll AS ForDiscAll"); 
			builder.Append(" FROM (((ReportTemplateNodesCheckedDiscLand Z INNER JOIN DisciplineLand X ON Z.NodeID = X.disc3_id)"); 
			builder.Append(" INNER JOIN MajorComponents C ON X.component_id = C.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON C.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseDisc);  

			builder.Append(" UNION SELECT 5 AS SortBy, 'DiscMech' AS NodeType, X2.infoset_id, Z.NodeID, 'DiscMech' AS NodeName, Z.DiscAll AS ForDiscAll"); 
			builder.Append(" FROM (((ReportTemplateNodesCheckedDiscMech Z INNER JOIN DisciplineMech X ON Z.NodeID = X.disc1_id)"); 
			builder.Append(" INNER JOIN MajorComponents C ON X.component_id = C.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON C.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseDisc);  

			builder.Append(" UNION SELECT 6 AS SortBy, 'DiscStruct' AS NodeType, X2.infoset_id, Z.NodeID, 'DiscStruct' AS NodeName, Z.DiscAll AS ForDiscAll"); 
			builder.Append(" FROM (((ReportTemplateNodesCheckedDiscStruct Z INNER JOIN DisciplineStruct X ON Z.NodeID = X.disc2_id)"); 
			builder.Append(" INNER JOIN MajorComponents C ON X.component_id = C.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON C.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseDisc);  

			builder.Append(" UNION SELECT 7 AS SortBy, 'DiscNode' AS NodeType, X2.infoset_id, Z.NodeID, 'DiscNode' AS NodeName, Z.DiscAll AS ForDiscAll"); 
			builder.Append(" FROM (((ReportTemplateNodesCheckedDiscNode Z INNER JOIN DisciplineNodes X ON Z.NodeID = X.discnode_id)"); 
			builder.Append(" INNER JOIN MajorComponents C ON X.component_id = C.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON C.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseDisc);  

			builder.Append(" UNION SELECT 8 AS SortBy, 'DiscPipe' AS NodeType, X2.infoset_id, Z.NodeID, 'DiscPipe' AS NodeName, Z.DiscAll AS ForDiscAll"); 
			builder.Append(" FROM (((ReportTemplateNodesCheckedDiscPipe Z INNER JOIN DisciplinePipes X ON Z.NodeID = X.discpipe_id)"); 
			builder.Append(" INNER JOIN MajorComponents C ON X.component_id = C.component_id)"); 
			builder.Append(" INNER JOIN TreatmentProcesses P ON C.process_id = P.process_id)"); 
			builder.Append(" INNER JOIN Facilities X2 ON P.facility_id = X2.facility_id"); 
			builder.AppendFormat(" WHERE ReportTemplateID = {0}{1}", templateID, whereClauseDisc);  

			builder.Append(" ORDER BY SortBy"); 
			dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());

			if (dataTable == null)
			{
				throw new Exception("Database Error.  GraphBuilderForm.SetReportTemplateCheckedNodes.");
			}

			foreach (DataRow dataRow in dataTable.Rows)
			{
				curSwitchValue = dataRow["NodeType"].ToString();
				switch (curSwitchValue)
				{
					case "Fac":
					{
						curNodeTypeInt = (int)NodeType.Facility;
						curNodeTypeString = NodeType.Facility.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);
						SelectedFac.Add(treeViewItem);

						break;
					}
					case "Proc":
						curNodeTypeInt = (int)NodeType.TreatmentProcess;
						curNodeTypeString = NodeType.TreatmentProcess.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);
						SelectedProc.Add(treeViewItem);
						break;
					case "Comp":
						curNodeTypeInt = (int)NodeType.MajorComponent;
						curNodeTypeString = NodeType.MajorComponent.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);
						SelectedComp.Add(treeViewItem);
						break;
					case "DiscLand":
						curNodeTypeInt = (int)NodeType.DisciplineLand;
						curNodeTypeString = NodeType.DisciplineLand.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);

						if ((int)dataRow["ForDiscAll"] == 1)
							SelectedDiscAllLand.Add(treeViewItem);
						else
							SelectedDiscLand.Add(treeViewItem);

						break;
					case "DiscMech":
						curNodeTypeInt = (int)NodeType.DisciplineMech;
						curNodeTypeString = NodeType.DisciplineMech.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);

						if ((int)dataRow["ForDiscAll"] == 1)
							SelectedDiscAllMech.Add(treeViewItem);
						else
							SelectedDiscMech.Add(treeViewItem);

						break;
					case "DiscStruct":
						curNodeTypeInt = (int)NodeType.DisciplineStruct;
						curNodeTypeString = NodeType.DisciplineStruct.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);

						if ((int)dataRow["ForDiscAll"] == 1)
							SelectedDiscAllStruct.Add(treeViewItem);
						else
							SelectedDiscStruct.Add(treeViewItem);

						break;
					case "DiscNode":
						curNodeTypeInt = (int)NodeType.DisciplineNode;
						curNodeTypeString = NodeType.DisciplineNode.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);

						if ((int)dataRow["ForDiscAll"] == 1)
							SelectedDiscAllNode.Add(treeViewItem);
						else
							SelectedDiscNode.Add(treeViewItem);

						break;
					case "DiscPipe":
						curNodeTypeInt = (int)NodeType.DisciplinePipe;
						curNodeTypeString = NodeType.DisciplinePipe.ToString();
						treeViewItem =  new WAM.Common.TreeViewItem((int)dataRow["NodeID"], 
							dataRow["NodeName"].ToString(), curNodeTypeInt, curNodeTypeString, -1, (int)dataRow["infoset_id"]);

						if ((int)dataRow["ForDiscAll"] == 1)
							SelectedDiscAllPipe.Add(treeViewItem);
						else
							SelectedDiscPipe.Add(treeViewItem);

						break;
				}
			}

			DetermineRestoreItems();
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				ResurrectSelectedNodes(node);
			}
		}

		private void comboBoxReportTemplate_DropDown(object sender, System.EventArgs e)
		{
			CheckDirty();
			return;
		}

		private void comboBoxReportTemplate_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (m_initialized && !savingTemplate)
			{
				SetReportTemplateSettings();
				
				currentTemplateID = 0;
				if (comboBoxReportTemplate.SelectedIndex > -1)
				{
					currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
				}

				ResetDirty();
				SetTreeNodesPerSelectedView();
				CountCheckedNodes();
				ResetDirty();
			}
		}

		#endregion /***** Template Code *****/



	}
}