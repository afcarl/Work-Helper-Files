using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for DollarTextBox.
	/// </summary>
	public class DollarTextBox : System.Windows.Forms.TextBox
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DollarTextBox()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

		}
		#endregion

		public decimal		Value
		{
			get { return Drive.Convert.DollarStringToDecimal(this.Text); }
			set { this.Text = value.ToString("$#,##0"); }
		}

		protected override void OnEnter(EventArgs e)
		{
			if (!ReadOnly && Enabled && !this.DesignMode)
			{
				decimal val = Drive.Convert.DollarStringToDecimal(this.Text);
				this.Text = val.ToString();
				this.SelectAll();
			}
			else if (ReadOnly && Enabled && !this.DesignMode)
			{
				this.SelectAll();
			}
			base.OnEnter(e);
		}

		protected override void OnLeave(EventArgs e)
		{
			if (!ReadOnly && Enabled && !this.DesignMode)
			{
				decimal val = Drive.Convert.DollarStringToDecimal(this.Text);
				this.Text = val.ToString("$#,##0");
			}
			base.OnLeave(e);
		}
	}
}
