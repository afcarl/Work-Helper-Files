using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Logic;


namespace WAM.UI
{
	/// <summary>
	/// Summary description for FilterBuilderForm2.
	/// </summary>
	public class FilterBuilderForm2 : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/
		//mam
		//private UnitFilter	m_unitFilter = null;
		public UnitFilter	m_unitFilter = new UnitFilter();
		//</mam>

		private bool		m_initialized = false;

		//mam 07072011
		ArrayList arrayListCip = new ArrayList();

		public System.Windows.Forms.Button buttonAddCriteria;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label labelFilterAnd;
		public System.Windows.Forms.TextBox textBoxFilterVal1;
		public System.Windows.Forms.TextBox textBoxFilterVal2;
		private System.Windows.Forms.Label labelSpecificValue;
		public System.Windows.Forms.ComboBox comboBoxFilterCompareTo;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label labelOperator;
		private System.Windows.Forms.Label label12;
		public System.Windows.Forms.ComboBox comboBoxOperator;
		public System.Windows.Forms.ComboBox comboBoxSource;
		public System.Windows.Forms.Button buttonCancelEdit;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		public FilterBuilderForm2()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call

		}
		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/

//		public int CompareTo(object obj)
//		{
//			//if (obj is ENR20Cities)
//			if (obj is FilterBuilderForm2)
//			{
//				//ENR20Cities comp = (ENR20Cities)obj;
//				FilterBuilderForm2 comp = (FilterBuilderForm2)obj;
//
//				//return Drive.Math.Compare(m_year, comp.m_year);
//				return Drive.Math.Compare(m_year, comp.m_year);
//			}
//
//			throw new ArgumentException("Not a Report Form object!");
//		}
//		#endregion

//		public int CompareTo(object obj)
//		{
//			ComponentAsset comp = obj as ComponentAsset;
//
//			if (comp != null)
//			{
//				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);
//
//				if (compare == 0)
//					compare = Drive.Math.Compare(this.ID, comp.ID);
//
//				return compare;
//			}
//			else
//				throw new InvalidCastException("Not a ComponentAsset");
//		//----------------
//			ListItem[]		items = new ListItem[arrayList.Count];
//			for (pos = 0; pos < arrayList.Count; pos++)
//				items[pos] = (ListItem)arrayList[pos];
//		//----------------
//		}
		#endregion /***** IComparable Members *****/

		#region /***** Disposable Members *****/
		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion /***** Static Methods *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.buttonAddCriteria = new System.Windows.Forms.Button();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.labelFilterAnd = new System.Windows.Forms.Label();
			this.textBoxFilterVal1 = new System.Windows.Forms.TextBox();
			this.textBoxFilterVal2 = new System.Windows.Forms.TextBox();
			this.labelSpecificValue = new System.Windows.Forms.Label();
			this.comboBoxFilterCompareTo = new System.Windows.Forms.ComboBox();
			this.label11 = new System.Windows.Forms.Label();
			this.labelOperator = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.comboBoxOperator = new System.Windows.Forms.ComboBox();
			this.comboBoxSource = new System.Windows.Forms.ComboBox();
			this.buttonCancelEdit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// buttonAddCriteria
			// 
			this.buttonAddCriteria.BackColor = System.Drawing.SystemColors.Control;
			this.buttonAddCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddCriteria.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonAddCriteria.Location = new System.Drawing.Point(309, 142);
			this.buttonAddCriteria.Name = "buttonAddCriteria";
			this.buttonAddCriteria.Size = new System.Drawing.Size(86, 23);
			this.buttonAddCriteria.TabIndex = 15;
			this.buttonAddCriteria.Text = "&Add";
			this.buttonAddCriteria.Click += new System.EventHandler(this.buttonAddCriteria_Click);
			// 
			// label16
			// 
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label16.Location = new System.Drawing.Point(0, 126);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(20, 16);
			this.label16.TabIndex = 9;
			this.label16.Text = "(4)";
			// 
			// label15
			// 
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label15.Location = new System.Drawing.Point(0, 84);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(20, 16);
			this.label15.TabIndex = 6;
			this.label15.Text = "(3)";
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label14.Location = new System.Drawing.Point(0, 42);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(20, 16);
			this.label14.TabIndex = 3;
			this.label14.Text = "(2)";
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label13.Location = new System.Drawing.Point(0, 0);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(20, 16);
			this.label13.TabIndex = 0;
			this.label13.Text = "(1)";
			// 
			// labelFilterAnd
			// 
			this.labelFilterAnd.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.labelFilterAnd.Location = new System.Drawing.Point(128, 142);
			this.labelFilterAnd.Name = "labelFilterAnd";
			this.labelFilterAnd.Size = new System.Drawing.Size(32, 16);
			this.labelFilterAnd.TabIndex = 12;
			this.labelFilterAnd.Text = "and";
			this.labelFilterAnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBoxFilterVal1
			// 
			this.textBoxFilterVal1.Location = new System.Drawing.Point(24, 142);
			this.textBoxFilterVal1.Name = "textBoxFilterVal1";
			this.textBoxFilterVal1.TabIndex = 11;
			this.textBoxFilterVal1.Text = "";
			// 
			// textBoxFilterVal2
			// 
			this.textBoxFilterVal2.Location = new System.Drawing.Point(168, 142);
			this.textBoxFilterVal2.Name = "textBoxFilterVal2";
			this.textBoxFilterVal2.TabIndex = 13;
			this.textBoxFilterVal2.Text = "";
			// 
			// labelSpecificValue
			// 
			this.labelSpecificValue.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.labelSpecificValue.Location = new System.Drawing.Point(8, 126);
			this.labelSpecificValue.Name = "labelSpecificValue";
			this.labelSpecificValue.Size = new System.Drawing.Size(248, 16);
			this.labelSpecificValue.TabIndex = 10;
			this.labelSpecificValue.Text = "4)  Enter the &specific value(s) to be filtered on:";
			// 
			// comboBoxFilterCompareTo
			// 
			this.comboBoxFilterCompareTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFilterCompareTo.ItemHeight = 13;
			this.comboBoxFilterCompareTo.Location = new System.Drawing.Point(24, 100);
			this.comboBoxFilterCompareTo.MaxDropDownItems = 30;
			this.comboBoxFilterCompareTo.Name = "comboBoxFilterCompareTo";
			this.comboBoxFilterCompareTo.Size = new System.Drawing.Size(244, 21);
			this.comboBoxFilterCompareTo.Sorted = true;
			this.comboBoxFilterCompareTo.TabIndex = 8;
			this.comboBoxFilterCompareTo.SelectedIndexChanged += new System.EventHandler(this.UpdateSpecificValueStatus);
			// 
			// label11
			// 
			this.label11.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label11.Location = new System.Drawing.Point(8, 84);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(172, 16);
			this.label11.TabIndex = 7;
			this.label11.Text = "3)  Select the filter &value type:";
			// 
			// labelOperator
			// 
			this.labelOperator.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.labelOperator.Location = new System.Drawing.Point(8, 42);
			this.labelOperator.Name = "labelOperator";
			this.labelOperator.Size = new System.Drawing.Size(180, 16);
			this.labelOperator.TabIndex = 4;
			this.labelOperator.Text = "2)  Select a comparison &operator:";
			// 
			// label12
			// 
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label12.Location = new System.Drawing.Point(8, 0);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(180, 16);
			this.label12.TabIndex = 1;
			this.label12.Text = "1)  Select a &field to filter by:";
			// 
			// comboBoxOperator
			// 
			this.comboBoxOperator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOperator.ItemHeight = 13;
			this.comboBoxOperator.Location = new System.Drawing.Point(24, 58);
			this.comboBoxOperator.MaxDropDownItems = 20;
			this.comboBoxOperator.Name = "comboBoxOperator";
			this.comboBoxOperator.Size = new System.Drawing.Size(144, 21);
			this.comboBoxOperator.TabIndex = 5;
			this.comboBoxOperator.SelectedIndexChanged += new System.EventHandler(this.UpdateSpecificValueStatus);
			// 
			// comboBoxSource
			// 
			this.comboBoxSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxSource.ItemHeight = 13;
			this.comboBoxSource.Location = new System.Drawing.Point(24, 16);
			this.comboBoxSource.MaxDropDownItems = 30;
			this.comboBoxSource.Name = "comboBoxSource";
			this.comboBoxSource.Size = new System.Drawing.Size(244, 21);
			this.comboBoxSource.Sorted = true;
			this.comboBoxSource.TabIndex = 2;
			// 
			// buttonCancelEdit
			// 
			this.buttonCancelEdit.BackColor = System.Drawing.SystemColors.Control;
			this.buttonCancelEdit.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancelEdit.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancelEdit.Location = new System.Drawing.Point(308, 112);
			this.buttonCancelEdit.Name = "buttonCancelEdit";
			this.buttonCancelEdit.Size = new System.Drawing.Size(86, 23);
			this.buttonCancelEdit.TabIndex = 14;
			this.buttonCancelEdit.Text = "Cancel Edit";
			this.buttonCancelEdit.Visible = false;
			this.buttonCancelEdit.Click += new System.EventHandler(this.buttonCancelEdit_Click);
			// 
			// FilterBuilderForm2
			// 
			this.Controls.Add(this.buttonCancelEdit);
			this.Controls.Add(this.comboBoxSource);
			this.Controls.Add(this.comboBoxOperator);
			this.Controls.Add(this.buttonAddCriteria);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.labelFilterAnd);
			this.Controls.Add(this.textBoxFilterVal1);
			this.Controls.Add(this.textBoxFilterVal2);
			this.Controls.Add(this.labelSpecificValue);
			this.Controls.Add(this.comboBoxFilterCompareTo);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.labelOperator);
			this.Controls.Add(this.label12);
			this.Name = "FilterBuilderForm2";
			this.Size = new System.Drawing.Size(400, 168);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/
		public void buttonAddCriteria_Click(object sender, System.EventArgs e)
		{
			//mam - create new UnitFilter
			UnitFilter	m_unitFilter2 = new UnitFilter();
			//</mam>

			// Save the selected values
			ListItem		sourceItem = comboBoxSource.SelectedItem as ListItem;
			ListItem		opItem = comboBoxOperator.SelectedItem as ListItem;
			ListItem		compItem = comboBoxFilterCompareTo.SelectedItem as ListItem;

			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.Undefined)
			{
				MessageBox.Show(this, "Please select a field to filter by in Step (1).", "Select Filter Field",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			m_unitFilter.Source = (UnitFilter.FilterSource)sourceItem.Value;
			m_unitFilter.Operator = (UnitFilter.FilterOperator)opItem.Value;
			m_unitFilter.Compare = (UnitFilter.FilterCompareTo)compItem.Value;

			//mam - make text boxes zero if disabled
			//mam - changed my mind - save the values whether disabled or not
			//if (!textBoxFilterVal1.Enabled)
			//	textBoxFilterVal1.Text = "0";
			//if (!textBoxFilterVal2.Enabled)
			//	textBoxFilterVal2.Text = "0";
			//</mam>

			//mam 07072011 - if the selected filter is Planning Mode, or Asset Class, the user will enter a non-numeric value
			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.AssetClass
				|| (UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.CipMode)
			{
				m_unitFilter.CompareVal1String = textBoxFilterVal1.Text;
				m_unitFilter.CompareVal2String = textBoxFilterVal2.Text;
			}
			else
			{
				m_unitFilter.CompareVal1 = Drive.Convert.StringToDecimal(textBoxFilterVal1.Text);
				m_unitFilter.CompareVal2 = Drive.Convert.StringToDecimal(textBoxFilterVal2.Text);
			}

			ResetButtons();

			//this.DialogResult = DialogResult.OK;
			//this.Close();
		}

		protected override void OnLoad(EventArgs e)
		{
			LoadSourceFilterList(WAM.UI.NodeType.Facility);

			//mam 07072011 - added false
			LoadOperatorList(false);

			LoadCompareToList(WAM.UI.NodeType.Facility);

			m_initialized = true;
			textBoxFilterVal1.Text = m_unitFilter.CompareVal1.ToString();
			textBoxFilterVal2.Text = m_unitFilter.CompareVal2.ToString();
			UpdateSpecificValueStatus(null, null);

			//mam 07072011
			this.comboBoxSource.SelectedIndexChanged += new System.EventHandler(this.UpdateSpecificValueStatus);
			textBoxFilterVal1.MaxLength = 50;
			textBoxFilterVal2.MaxLength = 20;

			base.OnLoad(e);

		}

		public void		LoadSourceFilterList(WAM.UI.NodeType nodeType)
		{
			UnitFilter.FilterSource[] sources = (UnitFilter.FilterSource[])Enum.GetValues(typeof(UnitFilter.FilterSource));
			//ListItem[]		items = new ListItem[sources.Length];
			ArrayList		arrayList = new ArrayList();

			int				pos;
			int				selectedIndex = 0;

			for (pos = 0; pos < sources.Length; pos++)
				if (UnitFilter.GetFilterSourceString(sources[pos], nodeType) != "")
				{
					//items[pos] = new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]);
					arrayList.Add(new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]));
				}

			ListItem[]		items = new ListItem[arrayList.Count];
			for (pos = 0; pos < arrayList.Count; pos++)
				items[pos] = (ListItem)arrayList[pos];

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			comboBoxSource.BeginUpdate();
			comboBoxSource.DisplayMember = "DisplayMember";
			comboBoxSource.Items.Clear();
			comboBoxSource.Items.AddRange(items);
			comboBoxSource.EndUpdate();

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterSource)items[pos].Value) == m_unitFilter.Source)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxSource.SelectedIndex = selectedIndex;
		}

		//mam 07072011 - added bool isAssetClass
		private void		LoadOperatorList(bool isAssetClass)
		{
			UnitFilter.FilterOperator[] ops;

			//mam 07072011
			ListItem listItem = comboBoxSource.SelectedItem as ListItem;
			if ((UnitFilter.FilterSource)listItem.Value == UnitFilter.FilterSource.AssetClass
				|| (UnitFilter.FilterSource)listItem.Value == UnitFilter.FilterSource.CipMode)
			{
				ops = new UnitFilter.FilterOperator[2];
				ops[0] = UnitFilter.FilterOperator.Equals;
				ops[1] = UnitFilter.FilterOperator.NotEquals;
			}
			else
			{
				//mam 07072011
				ops = (UnitFilter.FilterOperator[])Enum.GetValues(typeof(UnitFilter.FilterOperator));
			}

			ListItem[]		items = new ListItem[ops.Length];
			int				pos;
			int				selectedIndex = 0;

			for (pos = 0; pos < ops.Length; pos++)
				items[pos] = new ListItem(UnitFilter.GetFilterOperatorString(ops[pos]), ops[pos]);

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			//mam 07072011
			comboBoxOperator.Items.Clear();

			comboBoxOperator.BeginUpdate();
			comboBoxOperator.DisplayMember = "DisplayMember";
			comboBoxOperator.Items.Clear();
			comboBoxOperator.Items.AddRange(items);
			comboBoxOperator.EndUpdate();

			//mam 07072011 - allow <> operator only for asset class
			//for now, the last item in the combo box will always be <>, so remove it for choices other than Asset Class and Planning Mode
			if (comboBoxOperator.Items.Count > 2)
			{
				//comboBoxOperator.Items.Remove(UnitFilter.FilterOperator.NotEquals);
				comboBoxOperator.Items.RemoveAt(comboBoxOperator.Items.Count - 1);
			}

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterOperator)items[pos].Value) == m_unitFilter.Operator)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxOperator.SelectedIndex = selectedIndex;
		}

		public void		LoadCompareToList(WAM.UI.NodeType nodeType)
		{
			//UnitFilter.FilterCompareTo[] ops = (UnitFilter.FilterCompareTo[])Enum.GetValues(typeof(UnitFilter.FilterCompareTo));
			//ListItem[]		items = new ListItem[ops.Length];
			UnitFilter.FilterCompareTo[] sources = (UnitFilter.FilterCompareTo[])Enum.GetValues(typeof(UnitFilter.FilterCompareTo));
			//ListItem[]		items = new ListItem[sources.Length];
			ArrayList		arrayList = new ArrayList();
			int				pos;
			int				selectedIndex = 0;

			//for (pos = 0; pos < ops.Length; pos++)
			for (pos = 0; pos < sources.Length; pos++)
			{
				if (UnitFilter.GetFilterCompareToString(sources[pos], nodeType) != "")
				{
					////items[pos] = new ListItem(UnitFilter.GetFilterCompareToString(ops[pos]), ops[pos]);
					//items[pos] = new ListItem(UnitFilter.GetFilterCompareToString(sources[pos]), sources[pos]);
					arrayList.Add(new ListItem(UnitFilter.GetFilterCompareToString(sources[pos]), sources[pos]));
				}
			}

			ListItem[]		items = new ListItem[arrayList.Count];
			for (pos = 0; pos < arrayList.Count; pos++)
				items[pos] = (ListItem)arrayList[pos];

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			comboBoxFilterCompareTo.BeginUpdate();
			comboBoxFilterCompareTo.DisplayMember = "DisplayMember";
			comboBoxFilterCompareTo.Items.Clear();
			comboBoxFilterCompareTo.Items.AddRange(items);
			comboBoxFilterCompareTo.EndUpdate();

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterCompareTo)items[pos].Value) == m_unitFilter.Compare)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxFilterCompareTo.SelectedIndex = selectedIndex;
		}

		private void UpdateSpecificValueStatus(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			//mam 07072011
			//check whether Asset Class has been selected
			if (sender != null && ((ComboBox)sender).Name == "comboBoxSource")
			{
				ListItem		sourceItem = comboBoxSource.SelectedItem as ListItem;
				if (sourceItem != null && ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.AssetClass
					|| (UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.CipMode))
				{
					LoadOperatorList(true);
					comboBoxFilterCompareTo.Enabled = false;
					textBoxFilterVal1.Text = "";
				}
				else
				{
					LoadOperatorList(false);
					comboBoxFilterCompareTo.Enabled = true;
					textBoxFilterVal1.Text = "0";
				}
				return;
			}

			ListItem		opItem = comboBoxOperator.SelectedItem as ListItem;
			ListItem		targItem = comboBoxFilterCompareTo.SelectedItem as ListItem;
			bool			enableVal1 = false, enableVal2 = false;
			bool			enableCompare = true;

			// Make sure that the specific values get enabled correctly based on
			// operator and target compare field
			if (opItem != null && targItem != null)
			{
				UnitFilter.FilterOperator op = (UnitFilter.FilterOperator)opItem.Value;
				UnitFilter.FilterCompareTo comp = (UnitFilter.FilterCompareTo)targItem.Value;

				if (op == UnitFilter.FilterOperator.Between || 
					op == UnitFilter.FilterOperator.OutsideOf)
				{
					// Disallow compare value to get set
					enableCompare = false;
				}

				if (comp == UnitFilter.FilterCompareTo.Value)
				{
					enableVal1 = true;

					if (op == UnitFilter.FilterOperator.Between || 
						op == UnitFilter.FilterOperator.OutsideOf)
					{
						enableVal2 = true;
					}
				}
			}

			textBoxFilterVal1.Enabled = enableVal1;
			labelFilterAnd.Enabled = enableVal2;
			textBoxFilterVal2.Enabled = enableVal2;

			comboBoxFilterCompareTo.Enabled = enableCompare;
			if (!enableCompare)
			{
				// Make sure that "< Specific Value(s) >" is selected
				if (comboBoxFilterCompareTo.SelectedIndex != 0)
					comboBoxFilterCompareTo.SelectedIndex = 0;
			}
		}

		public void GetSelectedComboBoxItemSource(UnitFilter unitFilter)
		{
			ListItem		listItem = comboBoxSource.SelectedItem as ListItem;

			int pos;
			int selectedIndex = 0;

			//MessageBox.Show(UnitFilter.GetFilterSourceString(unitFilter.Source));
			//MessageBox.Show(unitFilter.ToString());
			for (pos = 0; pos < comboBoxSource.Items.Count; pos++)
			{
				listItem = (ListItem)comboBoxSource.Items[pos];

				//if (listItem.DisplayMember.ToString() == unitFilter.Source.ToString())
				if (listItem.DisplayMember.ToString() == UnitFilter.GetFilterSourceString(unitFilter.Source))
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxSource.SelectedIndex = selectedIndex;
			//comboBoxSource.Refresh();
		}

		public void GetSelectedComboBoxItemOperator(UnitFilter unitFilter)
		{
			ListItem		listItem = comboBoxOperator.SelectedItem as ListItem;

			int pos;
			int selectedIndex = 0;

			for (pos = 0; pos < comboBoxOperator.Items.Count; pos++)
			{
				listItem = (ListItem)comboBoxOperator.Items[pos];

				//if (listItem.DisplayMember.ToString() == unitFilter.Source.ToString())
				if (listItem.DisplayMember.ToString() == UnitFilter.GetFilterOperatorString(unitFilter.Operator))
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxOperator.SelectedIndex = selectedIndex;
			//comboBoxOperator.Refresh();
		}

		public void GetSelectedComboBoxItemCompare(UnitFilter unitFilter)
		{
			ListItem		listItem = comboBoxFilterCompareTo.SelectedItem as ListItem;

			int pos;
			int selectedIndex = 0;

			for (pos = 0; pos < comboBoxFilterCompareTo.Items.Count; pos++)
			{
				listItem = (ListItem)comboBoxFilterCompareTo.Items[pos];

				//if (listItem.DisplayMember.ToString() == unitFilter.Source.ToString())
				if (listItem.DisplayMember.ToString() == UnitFilter.GetFilterCompareToString(unitFilter.Compare))
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxFilterCompareTo.SelectedIndex = selectedIndex;
			//comboBoxFilterCompareTo.Refresh();
		}

		public void GetSelectedTextBoxItems(UnitFilter unitFilter)
		{
			//mam 07072011 - added check for asset class
			ListItem sourceItem = comboBoxSource.SelectedItem as ListItem;
			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.AssetClass
				|| (UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.CipMode)
			{
				textBoxFilterVal1.Text = unitFilter.CompareVal1String.ToString();
				//textBoxFilterVal2.Text = unitFilter.CompareVal2String.ToString();	//asset class and planning mode don't use second box
			}
			else
			{
				textBoxFilterVal1.Text = unitFilter.CompareVal1.ToString();
				textBoxFilterVal2.Text = unitFilter.CompareVal2.ToString();
			}
		}

		private void buttonCancelEdit_Click(object sender, System.EventArgs e)
		{
			ResetButtons();
		}

		public void ResetButtons()
		{
			this.buttonAddCriteria.Text = "&Add";
			this.buttonAddCriteria.Focus();
			this.buttonCancelEdit.Visible = false;
		}

		public void ResetAll()
		{
			this.comboBoxSource.SelectedIndex = 0;
			this.comboBoxOperator.SelectedIndex = 0;
			this.comboBoxFilterCompareTo.SelectedIndex = 0;
			this.textBoxFilterVal1.Text = "0";
			this.textBoxFilterVal2.Text = "0";

			ResetButtons();
		}

		#endregion /***** Methods *****/

	}
}
