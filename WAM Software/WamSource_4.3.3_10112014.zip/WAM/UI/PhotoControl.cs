using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for PhotoControl.
	/// </summary>
	public class PhotoControl : System.Windows.Forms.Control
	{
		private Image		m_image = null;
		private bool		m_centerInRect = true;

		private StringFormat m_format;
		

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PhotoControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			this.SetStyle(ControlStyles.DoubleBuffer, true);
			this.SetStyle(ControlStyles.UserPaint, true);
			this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);

			m_format = new StringFormat();
			m_format.LineAlignment = StringAlignment.Center;
			m_format.Alignment = StringAlignment.Center;
			ResizeRedraw = true;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// PhotoControl
			// 
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "PhotoControl";
			this.Size = new System.Drawing.Size(104, 108);

		}
		#endregion

		protected override void OnPaint(PaintEventArgs e)
		{
			if (m_image == null)
			{
				e.Graphics.DrawString("No Photo", this.Font,
					System.Drawing.SystemBrushes.ControlText, this.ClientRectangle, 
					m_format);
			}
			else
			{
				double		scaleHorzPct = (double)this.ClientRectangle.Width / (double)m_image.Width;
				double		scaleVertPct = (double)this.ClientRectangle.Height / (double)m_image.Height;
				double		scalePct;
				float		height;
				float		width;
				float		borderSides = 0.0f;
				float		borderUpDown = 0.0f;

				if (scaleHorzPct < scaleVertPct)
					scalePct = scaleHorzPct;
				else
					scalePct = scaleVertPct;
				
				width = (float)((double)m_image.Width * scalePct);
				height = (float)((double)m_image.Height * scalePct);

				if (m_centerInRect)
				{
					borderSides = (float)((this.ClientRectangle.Width - width) / 2.0);
					borderUpDown = (float)((this.ClientRectangle.Height - height) / 2.0);
				}

				e.Graphics.DrawImage(m_image, borderSides, borderUpDown, width, height);
			}

			int				bottom = this.ClientRectangle.Bottom - 1;
			int				right = this.ClientRectangle.Right - 1;

			e.Graphics.DrawLine(SystemPens.ControlDark, 
				this.ClientRectangle.Left, this.ClientRectangle.Top, 
				right, this.ClientRectangle.Top);
			e.Graphics.DrawLine(SystemPens.ControlDark, 
				this.ClientRectangle.Left, this.ClientRectangle.Top, 
				this.ClientRectangle.Left, bottom);
			e.Graphics.DrawLine(SystemPens.ControlLightLight, 
				this.ClientRectangle.Left, bottom, 
				right, bottom);
			e.Graphics.DrawLine(SystemPens.ControlLightLight, 
				right, this.ClientRectangle.Top, 
				right, bottom);

			base.OnPaint(e);
		}

		public Image		Image
		{
			get { return m_image; }
			set 
			{ 
				if (m_image != null)
					m_image.Dispose();

				m_image = value;
				Invalidate(true); 
			}
		}

	}
}
