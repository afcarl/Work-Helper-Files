using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;
using WAM.Logic;
using Drive.Collections;
using Drive.Configuration;

//mam
namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportFilterForm2.
	/// </summary>
	public class ReportFilterForm2 : System.Windows.Forms.Form
	{
		//UnitFilter[]	m_filters = null;
		//private bool	m_initialized = false;
		private WAM.UI.ReportFilterForm formReportForm1;
		//private WAM.UI.ReportFilterForm2 formReportForm2;

		public static Reports.UI.C1ReportDisplayerForm MyReportDisplayer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panelSortBy;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.ComboBox comboBoxSortBy3;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.ComboBox comboBoxSortBy2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox comboBoxSortBy1;
		private System.Windows.Forms.RadioButton radioSortTree;
		private System.Windows.Forms.RadioButton radioSortFields;
		private System.Windows.Forms.RadioButton radioDesc3;
		private System.Windows.Forms.RadioButton radioAsc3;
		private System.Windows.Forms.RadioButton radioDesc2;
		private System.Windows.Forms.RadioButton radioAsc2;
		private System.Windows.Forms.RadioButton radioDesc1;
		private System.Windows.Forms.RadioButton radioAsc1;
		private System.Windows.Forms.ComboBox comboBoxReportType;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckedListBox listBoxMatrixColumns;
		private System.Windows.Forms.Panel panelReportType;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonBack;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		//public static void	ShowForm(Form owner, WAM.UI.ReportFilterForm reportDialog1)
		//public void	ShowForm(Form owner, WAM.UI.ReportFilterForm reportDialog1)
//		public WAM.UI.ReportFilterForm2	ShowForm(Form owner, WAM.UI.ReportFilterForm reportDialog1)
//		{
//			//ReportFilterForm2 form = new ReportFilterForm2();
//			formReportForm1 = reportDialog1;
//			formReportForm2 = new ReportFilterForm2();
//			if (formReportForm1 == null)
//				MessageBox.Show("null");
//
//			formReportForm2.ShowDialog(owner);
//			return formReportForm2;
//		}

		public ReportFilterForm2(ReportFilterForm formReportForm1)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.formReportForm1 = formReportForm1;
		}

//		public ReportFilterForm2()
//		{
//			//
//			// Required for Windows Form Designer support
//			//
//			InitializeComponent();
//		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.comboBoxReportType = new System.Windows.Forms.ComboBox();
			this.radioSortTree = new System.Windows.Forms.RadioButton();
			this.radioSortFields = new System.Windows.Forms.RadioButton();
			this.panelSortBy = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.radioDesc3 = new System.Windows.Forms.RadioButton();
			this.radioAsc3 = new System.Windows.Forms.RadioButton();
			this.panel9 = new System.Windows.Forms.Panel();
			this.radioDesc2 = new System.Windows.Forms.RadioButton();
			this.radioAsc2 = new System.Windows.Forms.RadioButton();
			this.panel7 = new System.Windows.Forms.Panel();
			this.radioDesc1 = new System.Windows.Forms.RadioButton();
			this.radioAsc1 = new System.Windows.Forms.RadioButton();
			this.panel6 = new System.Windows.Forms.Panel();
			this.comboBoxSortBy3 = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.comboBoxSortBy2 = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.comboBoxSortBy1 = new System.Windows.Forms.ComboBox();
			this.panelReportType = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.listBoxMatrixColumns = new System.Windows.Forms.CheckedListBox();
			this.buttonBack = new System.Windows.Forms.Button();
			this.panelSortBy.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panelReportType.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(9, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(189, 28);
			this.label1.TabIndex = 10;
			this.label1.Text = "Report Type";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(222, 6);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(189, 28);
			this.label2.TabIndex = 11;
			this.label2.Text = "Sort By";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// buttonOK
			// 
			this.buttonOK.Location = new System.Drawing.Point(416, 448);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(104, 23);
			this.buttonOK.TabIndex = 14;
			this.buttonOK.Text = "&OK";
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(532, 448);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(104, 23);
			this.buttonCancel.TabIndex = 13;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(206, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(3, 440);
			this.panel1.TabIndex = 25;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel2.Location = new System.Drawing.Point(0, 437);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(676, 3);
			this.panel2.TabIndex = 26;
			// 
			// comboBoxReportType
			// 
			this.comboBoxReportType.Location = new System.Drawing.Point(8, 42);
			this.comboBoxReportType.Name = "comboBoxReportType";
			this.comboBoxReportType.Size = new System.Drawing.Size(190, 21);
			this.comboBoxReportType.TabIndex = 27;
			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportType_SelectedIndexChanged);
			// 
			// radioSortTree
			// 
			this.radioSortTree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioSortTree.Location = new System.Drawing.Point(228, 44);
			this.radioSortTree.Name = "radioSortTree";
			this.radioSortTree.Size = new System.Drawing.Size(228, 16);
			this.radioSortTree.TabIndex = 33;
			this.radioSortTree.Text = "Data Tree Order";
			this.radioSortTree.CheckedChanged += new System.EventHandler(this.radioSortTree_CheckedChanged);
			// 
			// radioSortFields
			// 
			this.radioSortFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioSortFields.Location = new System.Drawing.Point(228, 72);
			this.radioSortFields.Name = "radioSortFields";
			this.radioSortFields.Size = new System.Drawing.Size(228, 16);
			this.radioSortFields.TabIndex = 34;
			this.radioSortFields.Text = "Selected Fields";
			this.radioSortFields.CheckedChanged += new System.EventHandler(this.radioSortFields_CheckedChanged);
			// 
			// panelSortBy
			// 
			this.panelSortBy.Controls.Add(this.panel10);
			this.panelSortBy.Controls.Add(this.panel9);
			this.panelSortBy.Controls.Add(this.panel7);
			this.panelSortBy.Controls.Add(this.panel6);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy3);
			this.panelSortBy.Controls.Add(this.label7);
			this.panelSortBy.Controls.Add(this.panel5);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy2);
			this.panelSortBy.Controls.Add(this.label6);
			this.panelSortBy.Controls.Add(this.panel4);
			this.panelSortBy.Controls.Add(this.panel3);
			this.panelSortBy.Controls.Add(this.label5);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy1);
			this.panelSortBy.Location = new System.Drawing.Point(248, 96);
			this.panelSortBy.Name = "panelSortBy";
			this.panelSortBy.Size = new System.Drawing.Size(348, 204);
			this.panelSortBy.TabIndex = 49;
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.radioDesc3);
			this.panel10.Controls.Add(this.radioAsc3);
			this.panel10.Location = new System.Drawing.Point(240, 144);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(100, 32);
			this.panel10.TabIndex = 64;
			// 
			// radioDesc3
			// 
			this.radioDesc3.Location = new System.Drawing.Point(0, 17);
			this.radioDesc3.Name = "radioDesc3";
			this.radioDesc3.Size = new System.Drawing.Size(84, 16);
			this.radioDesc3.TabIndex = 34;
			this.radioDesc3.Text = "Descending";
			// 
			// radioAsc3
			// 
			this.radioAsc3.Location = new System.Drawing.Point(0, 0);
			this.radioAsc3.Name = "radioAsc3";
			this.radioAsc3.Size = new System.Drawing.Size(84, 16);
			this.radioAsc3.TabIndex = 33;
			this.radioAsc3.Text = "Ascending";
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.radioDesc2);
			this.panel9.Controls.Add(this.radioAsc2);
			this.panel9.Location = new System.Drawing.Point(240, 88);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(100, 32);
			this.panel9.TabIndex = 63;
			// 
			// radioDesc2
			// 
			this.radioDesc2.Location = new System.Drawing.Point(0, 17);
			this.radioDesc2.Name = "radioDesc2";
			this.radioDesc2.Size = new System.Drawing.Size(84, 16);
			this.radioDesc2.TabIndex = 34;
			this.radioDesc2.Text = "Descending";
			// 
			// radioAsc2
			// 
			this.radioAsc2.Location = new System.Drawing.Point(0, 0);
			this.radioAsc2.Name = "radioAsc2";
			this.radioAsc2.Size = new System.Drawing.Size(84, 16);
			this.radioAsc2.TabIndex = 33;
			this.radioAsc2.Text = "Ascending";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.radioDesc1);
			this.panel7.Controls.Add(this.radioAsc1);
			this.panel7.Location = new System.Drawing.Point(240, 28);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(100, 32);
			this.panel7.TabIndex = 62;
			// 
			// radioDesc1
			// 
			this.radioDesc1.Location = new System.Drawing.Point(0, 17);
			this.radioDesc1.Name = "radioDesc1";
			this.radioDesc1.Size = new System.Drawing.Size(84, 16);
			this.radioDesc1.TabIndex = 34;
			this.radioDesc1.Text = "Descending";
			// 
			// radioAsc1
			// 
			this.radioAsc1.Location = new System.Drawing.Point(0, 0);
			this.radioAsc1.Name = "radioAsc1";
			this.radioAsc1.Size = new System.Drawing.Size(84, 16);
			this.radioAsc1.TabIndex = 33;
			this.radioAsc1.Text = "Ascending";
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel6.Location = new System.Drawing.Point(8, 192);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(328, 1);
			this.panel6.TabIndex = 61;
			// 
			// comboBoxSortBy3
			// 
			this.comboBoxSortBy3.Location = new System.Drawing.Point(8, 148);
			this.comboBoxSortBy3.Name = "comboBoxSortBy3";
			this.comboBoxSortBy3.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy3.TabIndex = 60;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(8, 124);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(47, 14);
			this.label7.TabIndex = 59;
			this.label7.Text = "Then by";
			this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel5.Location = new System.Drawing.Point(56, 132);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(280, 1);
			this.panel5.TabIndex = 58;
			// 
			// comboBoxSortBy2
			// 
			this.comboBoxSortBy2.Location = new System.Drawing.Point(8, 92);
			this.comboBoxSortBy2.Name = "comboBoxSortBy2";
			this.comboBoxSortBy2.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy2.TabIndex = 57;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(8, 64);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(47, 14);
			this.label6.TabIndex = 56;
			this.label6.Text = "Then by";
			this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Location = new System.Drawing.Point(56, 72);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(280, 1);
			this.panel4.TabIndex = 55;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Location = new System.Drawing.Point(56, 16);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(280, 1);
			this.panel3.TabIndex = 54;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(8, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(47, 14);
			this.label5.TabIndex = 53;
			this.label5.Text = "Sort by";
			this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// comboBoxSortBy1
			// 
			this.comboBoxSortBy1.Location = new System.Drawing.Point(8, 32);
			this.comboBoxSortBy1.Name = "comboBoxSortBy1";
			this.comboBoxSortBy1.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy1.TabIndex = 52;
			// 
			// panelReportType
			// 
			this.panelReportType.Controls.Add(this.label4);
			this.panelReportType.Controls.Add(this.listBoxMatrixColumns);
			this.panelReportType.Location = new System.Drawing.Point(2, 66);
			this.panelReportType.Name = "panelReportType";
			this.panelReportType.Size = new System.Drawing.Size(202, 370);
			this.panelReportType.TabIndex = 50;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(7, 8);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(189, 14);
			this.label4.TabIndex = 31;
			this.label4.Text = "Include Columns in Matrix Report";
			this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// listBoxMatrixColumns
			// 
			this.listBoxMatrixColumns.CheckOnClick = true;
			this.listBoxMatrixColumns.Location = new System.Drawing.Point(6, 28);
			this.listBoxMatrixColumns.Name = "listBoxMatrixColumns";
			this.listBoxMatrixColumns.Size = new System.Drawing.Size(190, 334);
			this.listBoxMatrixColumns.TabIndex = 30;
			// 
			// buttonBack
			// 
			this.buttonBack.Location = new System.Drawing.Point(300, 448);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(104, 23);
			this.buttonBack.TabIndex = 51;
			this.buttonBack.Text = "&Back";
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// ReportFilterForm2
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(646, 480);
			this.Controls.Add(this.buttonBack);
			this.Controls.Add(this.panelReportType);
			this.Controls.Add(this.panelSortBy);
			this.Controls.Add(this.radioSortFields);
			this.Controls.Add(this.radioSortTree);
			this.Controls.Add(this.comboBoxReportType);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(652, 512);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(652, 512);
			this.Name = "ReportFilterForm2";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Print Facility Information";
			this.panelSortBy.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panelReportType.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			LoadReportTypeCombo();
			LoadMatrixReportColumnsList();
			LoadSortByLists();
			this.radioSortTree.Checked = true;
			this.radioAsc1.Checked = true;
			this.radioAsc2.Checked = true;
			this.radioAsc3.Checked = true;

			base.OnLoad(e);
		}

		private void LoadReportTypeCombo()
		{
			comboBoxReportType.Items.Add("Individual Report (including Photos)");
			comboBoxReportType.Items.Add("Matrix");
			comboBoxReportType.SelectedIndex = 0;
		}

		private void LoadMatrixReportColumnsList()
		{
			UnitFilter.FilterSource[] sources = (UnitFilter.FilterSource[])Enum.GetValues(typeof(UnitFilter.FilterSource));
			ListItem[]		items = new ListItem[sources.Length-1];

			int				pos;
			//int				selectedIndex = 0;
			string[] TestString = new string[sources.Length-1];

			for (pos = 1; pos < sources.Length; pos++)
			{
				//items[pos] = new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]);
				//TestString[pos] = UnitFilter.GetFilterSourceString(sources[pos]);
				items[pos-1] = new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]);
				TestString[pos-1] = UnitFilter.GetFilterSourceString(sources[pos]);
			}

			//mam - for testing
			//for (pos = 0; pos < items.Length; pos++)
			//	System.Diagnostics.Debug.WriteLine((UnitFilter.FilterSource)items[pos].Value);
			//</mam>

			//mam - commented for testing
			//Array.Sort(items);
			//</mam>

			listBoxMatrixColumns.BeginUpdate();
			listBoxMatrixColumns.Items.Clear();
			//listBoxMatrixColumns.Items.AddRange(items);
			listBoxMatrixColumns.Items.AddRange(TestString);
			listBoxMatrixColumns.EndUpdate();

//			for (pos = 0; pos < items.Length; pos++)
//			{
//				if (((UnitFilter.FilterSource)items[pos].Value) == m_unitFilter.Source)
//				{
//					selectedIndex = pos;
//					break;
//				}
//			}
//
//			comboBoxSource.SelectedIndex = selectedIndex;
		}

		private void		LoadSortByLists()
		{
			UnitFilter.FilterSourceSort[] sources = (UnitFilter.FilterSourceSort[])Enum.GetValues(typeof(UnitFilter.FilterSourceSort));
			ListItem[]		items = new ListItem[sources.Length];
			int				pos;
			//int				selectedIndex = 0;

			for (pos = 0; pos < sources.Length; pos++)
				items[pos] = new ListItem(UnitFilter.GetFilterSourceStringSort(sources[pos]), sources[pos]);

			//mam - for testing
			//for (pos = 0; pos < items.Length; pos++)
			//	System.Diagnostics.Debug.WriteLine((UnitFilter.FilterSourceSort)items[pos].Value);
			//</mam>

			//mam - commented for testing
			//Array.Sort(items);
			//</mam>

			comboBoxSortBy1.BeginUpdate();
			comboBoxSortBy1.DisplayMember = "DisplayMember";
			comboBoxSortBy1.Items.Clear();
			comboBoxSortBy1.Items.AddRange(items);
			comboBoxSortBy1.EndUpdate();

			comboBoxSortBy2.BeginUpdate();
			comboBoxSortBy2.DisplayMember = "DisplayMember";
			comboBoxSortBy2.Items.Clear();
			comboBoxSortBy2.Items.AddRange(items);
			comboBoxSortBy2.EndUpdate();

			comboBoxSortBy3.BeginUpdate();
			comboBoxSortBy3.DisplayMember = "DisplayMember";
			comboBoxSortBy3.Items.Clear();
			comboBoxSortBy3.Items.AddRange(items);
			comboBoxSortBy3.EndUpdate();

//			for (pos = 0; pos < items.Length; pos++)
//			{
//				if (((UnitFilter.FilterSourceSort)items[pos].Value) == m_unitFilter.Source)
//				{
//					selectedIndex = pos;
//					break;
//				}
//			}
//
//			comboBoxSortBy1.SelectedIndex = selectedIndex;
			comboBoxSortBy1.SelectedIndex = 0;
			comboBoxSortBy2.SelectedIndex = 0;
			comboBoxSortBy3.SelectedIndex = 0;
		}

		private void radioSortTree_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panelSortBy.Enabled = this.radioSortFields.Checked;
		}

		private void radioSortFields_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panelSortBy.Enabled = this.radioSortFields.Checked;
		}

		private void comboBoxReportType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.panelReportType.Enabled = false;
			if (comboBoxReportType.SelectedIndex == 1)
				this.panelReportType.Enabled = true;
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void buttonBack_Click(object sender, System.EventArgs e)
		{
			this.Visible = false;
			//formReportForm1.Visible = true;
			this.Hide();
			if (formReportForm1 == null)
				MessageBox.Show("null");
			formReportForm1.Show();
		}

	}
}