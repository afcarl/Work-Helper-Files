using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for DatabaseSave.
	/// </summary>
	public class DatabaseSave : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.ComboBox comboBoxDatabase;
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.TextBox textBoxCopyName;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label labelFileName;
		string disallowedChar = @"\/:;*=?" + (char)34 + @"<>|";
		string existingText = "";
		string currentlyLoadedDatabase = "";
		char[] disallowedChars = new char[11];
		int currentPos = 0;
		bool fileExists;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Panel panelStatus;
		private System.Windows.Forms.Label labelStatus;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DatabaseSave()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.Text = "Copy Database";
			this.buttonOK.Enabled = false;
			LoadCharArray();
			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();
			System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(@Drive.IO.Directory.GetApplicationPath());

			foreach (System.IO.FileInfo fileFound in dir.GetFiles("*.mdb"))
			{
				if (verify.VerifyTables(fileFound.Name))
					comboBoxDatabase.Items.Add(fileFound.Name);
			}
			if (comboBoxDatabase.Items.Count > 0)
			{
				this.buttonOK.Enabled = true;
				comboBoxDatabase.SelectedIndex = 0;

				currentlyLoadedDatabase = Drive.Configuration.AppSettings.
					Settings.GetSetting("DBConnection", "LastSource");
				currentlyLoadedDatabase = Drive.IO.Directory.GetFileNameFromPath(currentlyLoadedDatabase, true);

				//mam 090105 - added a check to make sure there is no connection string data in the string
				//	returned from Drive
				//this could cause a problem here if there is no path!!!
				currentlyLoadedDatabase = WAM.Common.CommonTasks.RemoveConnectionDataFromStringToGetFileName(currentlyLoadedDatabase);

				if (currentlyLoadedDatabase != null || currentlyLoadedDatabase.Length != 0)
				{
					for (int i = 0; i < comboBoxDatabase.Items.Count; i++)
					{
						if (comboBoxDatabase.Items[i].ToString() == currentlyLoadedDatabase)
							comboBoxDatabase.SelectedIndex = i;
					}
				}
			}
			else
			{
				comboBoxDatabase.Text = "There are no databases to load";
			}

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(DatabaseSave));
			this.label1 = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.comboBoxDatabase = new System.Windows.Forms.ComboBox();
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.textBoxCopyName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.labelFileName = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panelStatus = new System.Windows.Forms.Panel();
			this.labelStatus = new System.Windows.Forms.Label();
			this.panelStatus.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label1.Location = new System.Drawing.Point(10, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(246, 24);
			this.label1.TabIndex = 98;
			this.label1.Text = "Select a database to copy";
			this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(176, 194);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&Make Copy";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(257, 194);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Close";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// comboBoxDatabase
			// 
			this.comboBoxDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxDatabase.DropDownWidth = 273;
			this.comboBoxDatabase.Location = new System.Drawing.Point(11, 39);
			this.comboBoxDatabase.Name = "comboBoxDatabase";
			this.comboBoxDatabase.Size = new System.Drawing.Size(317, 21);
			this.comboBoxDatabase.Sorted = true;
			this.comboBoxDatabase.TabIndex = 1;
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(10, 89);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(270, 21);
			this.labelReportTemplateName.TabIndex = 100;
			this.labelReportTemplateName.Text = "Enter a file name for the copy";
			this.labelReportTemplateName.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// textBoxCopyName
			// 
			this.textBoxCopyName.Location = new System.Drawing.Point(11, 115);
			this.textBoxCopyName.MaxLength = 100;
			this.textBoxCopyName.Name = "textBoxCopyName";
			this.textBoxCopyName.Size = new System.Drawing.Size(315, 20);
			this.textBoxCopyName.TabIndex = 0;
			this.textBoxCopyName.Text = "";
			this.textBoxCopyName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCopyName_KeyPress);
			this.textBoxCopyName.TextChanged += new System.EventHandler(this.textBoxCopyName_TextChanged);
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label2.Location = new System.Drawing.Point(11, 140);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 16);
			this.label2.TabIndex = 102;
			this.label2.Text = "File will be saved as:";
			// 
			// labelFileName
			// 
			this.labelFileName.BackColor = System.Drawing.Color.Transparent;
			this.labelFileName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelFileName.Location = new System.Drawing.Point(22, 154);
			this.labelFileName.Name = "labelFileName";
			this.labelFileName.Size = new System.Drawing.Size(306, 16);
			this.labelFileName.TabIndex = 103;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(307, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 104;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// panelStatus
			// 
			this.panelStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panelStatus.Controls.Add(this.labelStatus);
			this.panelStatus.Location = new System.Drawing.Point(11, 38);
			this.panelStatus.Name = "panelStatus";
			this.panelStatus.Size = new System.Drawing.Size(317, 98);
			this.panelStatus.TabIndex = 105;
			this.panelStatus.Visible = false;
			this.panelStatus.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStatus_Paint);
			// 
			// labelStatus
			// 
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelStatus.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(51)), ((System.Byte)(79)), ((System.Byte)(162)));
			this.labelStatus.Location = new System.Drawing.Point(7, 36);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(301, 24);
			this.labelStatus.TabIndex = 112;
			this.labelStatus.Text = "Copying.  Please wait...";
			this.labelStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DatabaseSave
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(338, 224);
			this.Controls.Add(this.panelStatus);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelFileName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.labelReportTemplateName);
			this.Controls.Add(this.textBoxCopyName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.comboBoxDatabase);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "CopyDatabase.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "DatabaseSave";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.Text = "DatabaseSave";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DatabaseSave_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.DatabaseSave_Paint);
			this.panelStatus.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			bool copyPhotos = false;

			DialogResult result = MessageBox.Show(this, 
				"Would you like to copy the photos for this Database?", 
				"Copy Database Photos", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2);
			//</mam>

			if (result == DialogResult.Cancel)
			{
				MessageBox.Show("The Database has not been copied.", "Copy Database", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			else if (result == DialogResult.Yes)
			{
				copyPhotos = true;
			}
			else if (result == DialogResult.No)
			{	
				copyPhotos = false;
			}

			try
			{
				buttonOK.Enabled = false;
				buttonCancel.Enabled = false;
				ControlBox = false;
				panelStatus.Visible = true;
				panelStatus.Refresh();
				labelStatus.Refresh();
				this.Refresh();
				this.CopyDatabaseFile(copyPhotos);
			}
			finally
			{
				buttonOK.Enabled = true;
				buttonCancel.Enabled = true;
				this.ControlBox = true;
				panelStatus.Visible = false;
			}
		}

		private string CopyDatabaseFile(bool copyPhotos)
		{
			// make sure a database has been selected
			if (comboBoxDatabase.Items.Count > 0 && comboBoxDatabase.SelectedIndex < 0)
			{
				MessageBox.Show(this, "Please select a database to copy.", 
					"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return "";
			}

			// make sure a file name has been entered
			if (textBoxCopyName.Text.Trim().Length == 0)
			{
				MessageBox.Show(this, "Please enter a file name for the copy.", 
					"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return "";
			}

			// check whether the database to be copied exists
			string dbPathCopyFrom = string.Format(@"{0}\" + comboBoxDatabase.Text, Drive.IO.Directory.GetApplicationPath());
			if (!System.IO.File.Exists(dbPathCopyFrom))
			{
				// the 'copy from' file does not exist
				MessageBox.Show(this, "The database  '" + dbPathCopyFrom + "'  cannot be found.", 
					"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return "";
			}

			// append ".mdb" to the "copy to" file name
			string dbPathCopyTo = string.Format(@"{0}\" + textBoxCopyName.Text, Drive.IO.Directory.GetApplicationPath());
			dbPathCopyTo += ".mdb";

			// check whether the "copy to" file name is the same as the currently loaded database
			string fileNameCopyTo = Drive.IO.Directory.GetFileNameFromPath(dbPathCopyTo, true);

			//mam 090105 - added a check to make sure there is no connection string data in the string
			//	returned from Drive
			//this could cause a problem here if there is no path!!!
			fileNameCopyTo = WAM.Common.CommonTasks.RemoveConnectionDataFromStringToGetFileName(fileNameCopyTo);

			if (fileNameCopyTo != null || fileNameCopyTo.Length != 0)
			{
				if (fileNameCopyTo.ToUpper() == currentlyLoadedDatabase.ToUpper())
				{
					MessageBox.Show(this, "The copy cannot have the same name as the currently loaded database.", 
						"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return "";
				}
			}

			// check whether the database and the "copy to" file have the same name
			if (dbPathCopyFrom.ToUpper() == dbPathCopyTo.ToUpper())
			{
				MessageBox.Show(this, "The database and the copy cannot have the same name.", 
					"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return "";
			}

			//			// check whether the "copy to" file already exists
			//			fileExists = false;
			//			if (System.IO.File.Exists(dbPathCopyTo))
			//			{
			//				// the 'copy to' file already exists
			//				DialogResult result = MessageBox.Show(this, "A file with the name  '" + dbPathCopyTo + "'  already exists.  Overwrite it?", 
			//					"Copy Database", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			//	
			//				if (result != DialogResult.Yes)
			//					return "";
			//
			//				fileExists = true;
			//			}

			//rather than allowing file to be overwritten, don't allow it, because there could be an issue
			//	with the folder name for the photos
			// check whether the "copy to" file already exists
			fileExists = false;
			if (System.IO.File.Exists(dbPathCopyTo))
			{
				// the 'copy to' file already exists
				fileExists = true;
				MessageBox.Show(this, "A file with the name  '" + dbPathCopyTo + "'  already exists.  Please enter a different name.", 
					"Copy Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return "";
			}

			// OK to overwrite, if necessary
			//update:  don't allow overwriting
			try
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

				System.IO.File.Copy(dbPathCopyFrom, dbPathCopyTo, true);

				// check if copy was made
				if (System.IO.File.Exists(dbPathCopyTo))
				{
					if (!fileExists)
					{
						string fileName = Drive.IO.Directory.GetFileNameFromPath(dbPathCopyTo, true);

						//mam 090105 - added a check to make sure there is no connection string data in the string
						//	returned from Drive
						//this could cause a problem here if there is no path!!!
						fileName = WAM.Common.CommonTasks.RemoveConnectionDataFromStringToGetFileName(fileName);

						if (fileName != null || fileName.Length != 0)
							comboBoxDatabase.Items.Add(fileName);
					}

					PerformCleanUpChores(dbPathCopyFrom, copyPhotos);

					MessageBox.Show("The database was successfully copied.", "Copy Database",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					MessageBox.Show("An error occurred.  The database was NOT copied.", "Copy Database",
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error.  " + ex.Message.ToString(), "Copy Database",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}

			return dbPathCopyFrom;
		}

		private bool PerformCleanUpChores(string dbPathCopyFrom, bool copyPhotos)
		{
			string appPath = Drive.IO.Directory.GetApplicationPath();
			string databaseNameCopyTo = textBoxCopyName.Text.Trim();
			string databaseNameCopyFrom = Drive.IO.Directory.GetFileNameFromPath(dbPathCopyFrom, false);
			string databaseImagesFolderCopyFrom = "";
			string imageFolderName = "";
			string connectionString = "";
			bool useDatabaseName = false;
			int pos = 0;

			//mam 090105 - added a check to make sure there is no connection string data in the string
			//	returned from Drive
			//this could cause a problem here if there is no path!!!
			databaseNameCopyFrom = WAM.Common.CommonTasks.RemoveConnectionDataFromStringToGetFileName(databaseNameCopyFrom);

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//create the images folder for the new database
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			string imageFolderNameWithPath = commonTasks.CreateDatabaseImageFolderName(databaseNameCopyTo);

			if (imageFolderNameWithPath == "")
				return false;

			//get the database folder name (without the path)
			imageFolderName = imageFolderNameWithPath;
			pos = imageFolderName.LastIndexOf(@"\");
			imageFolderName = imageFolderName.Remove(0, pos + 1);

			//update the newly-created database with the image folder name
			//connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(appPath + @"\" + databaseNameCopyTo);
			connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseNameCopyTo + ".mdb");
			dataAccess.ExecuteCommand(
				@"CREATE TABLE DatabaseInfo (DatabaseImageFolder VARCHAR (255) WITH COMPRESSION)", 
				connectionString);
			dataTable = dataAccess.GetDisconnectedDataTable(
				"SELECT * FROM DatabaseInfo", connectionString);
			if (dataTable != null)
			{
				if (dataTable.Rows.Count == 0)
				{
					dataAccess.ExecuteCommand(
						"INSERT INTO DatabaseInfo (DatabaseImageFolder) VALUES('" + imageFolderName + "')", 
						connectionString);
				}
				else
				{
					dataAccess.ExecuteCommand(
						"UPDATE DatabaseInfo SET DatabaseImageFolder = '" + imageFolderName + "'", 
						connectionString);
				}
			}

			//get the database image folder name from the original database
			connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseNameCopyFrom + ".mdb");
			dataTable = dataAccess.GetDisconnectedDataTable(
				"SELECT DatabaseImageFolder FROM DatabaseInfo", connectionString);
			if (dataTable == null)
			{
				//the DatabaseInfo table does not exist in the original database
				//this means that the there should be an images folder for each infoset in that database
				//get the name of each infoset in that database, and copy images from folders with those infoset names
				useDatabaseName = false;
			}
			else
			{
				foreach (System.Data.DataRow dataRow in dataTable.Rows)
				{
					databaseImagesFolderCopyFrom = dataRow["DatabaseImageFolder"].ToString();
					break;
				}

				if (databaseImagesFolderCopyFrom == "")
				{
					useDatabaseName = false;
				}
				else
				{
					useDatabaseName = true;
				}
			}

			if (copyPhotos)
			{
				//copy the images to the new folder
				if (useDatabaseName)
				{
					//the images for the original database should be in a database-named folder
					//check for existence of original images folder
					if (System.IO.Directory.Exists(appPath + @"\images\" + databaseImagesFolderCopyFrom))
					{
						try
						{
							WAM.Common.CommonTasks.FileCopy(appPath + @"\images\" + databaseImagesFolderCopyFrom, 
								imageFolderNameWithPath, true);
						}
						catch
						{
						}
					}

				}
				else
				{
					//get the name of each infoset in that database, and copy images from folders with those infoset names
					string curInfoset = "";
					dataTable = dataAccess.GetDisconnectedDataTable(
						"SELECT infoset_name FROM Infosets", connectionString);
					foreach (System.Data.DataRow dataRow in dataTable.Rows)
					{
						curInfoset = dataRow["infoset_name"].ToString();

						//check for existence of original images folder
						if (System.IO.Directory.Exists(appPath + @"\images\" + curInfoset))
						{
							try
							{
								WAM.Common.CommonTasks.FileCopy(appPath + @"\images\" + curInfoset, 
									imageFolderNameWithPath + @"\" + curInfoset, true);
							}
							catch
							{
							}
						}
					}
				}
			}

			return true;
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void DatabaseSave_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "CopyDatabase.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "CopyDatabase.htm");
		}

		private void textBoxCopyName_TextChanged(object sender, System.EventArgs e)
		{
			this.labelFileName.Text = this.textBoxCopyName.Text + ".mdb";

			bool changedText = false;
			string currentText = textBoxCopyName.Text;
			string correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (disallowedChar.IndexOf(currentText.Substring(i, 1)) > -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				textBoxCopyName.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxCopyName.SelectionStart = currentPos;
			}
		}

		private void textBoxCopyName_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxCopyName.SelectionStart;
			existingText = textBoxCopyName.Text;

			if (disallowedChar.IndexOf(e.KeyChar) > -1)
			{
				e.Handled = true;
			}
		}

		private void LoadCharArray()
		{
			//the following characters are not allowed in file names:
			disallowedChars[0] = '\'';
			disallowedChars[1] = '/';
			disallowedChars[2] = ':';
			disallowedChars[3] = ';';
			disallowedChars[4] = '*';
			disallowedChars[5] = '=';
			disallowedChars[6] = '?';
			disallowedChars[7] = '"';
			disallowedChars[8] = '<';
			disallowedChars[9] = '>';
			disallowedChars[10] = '|';
		}

		private void DatabaseSave_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void panelStatus_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
	}
}
