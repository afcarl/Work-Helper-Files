using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

//mam 102309
//using System.Data.OleDb;

using System.Text;
using Drive.Collections;
using WAM.Data;
using C1.Win.C1Report;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for FieldSheet.
	/// </summary>
	public class FieldSheet : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		public static Reports.UI.C1ReportDisplayerForm MyReportDisplayer;
		ReportPrintStatus reportPrintStatusForm = new ReportPrintStatus();
		WAM.UI.ReportPrintStatus.ReportUpdateEventArgs eventArgs = new WAM.UI.ReportPrintStatus.ReportUpdateEventArgs();

		private System.Data.DataSet dataSetLoad = new System.Data.DataSet("FieldSheetCheckedNodes");
		private string newTemplateNameFromForm;
		private bool autoChecking = false;
		private bool	m_initialized = false;
		private ArrayList		printItems = new ArrayList();
		private ArrayList		currentReport = new ArrayList();
		private ArrayList		SelectedDiscMech = new ArrayList();
		private ArrayList		SelectedDiscLand = new ArrayList();
		private ArrayList		SelectedDiscStruct = new ArrayList();
		private ArrayList		SelectedDiscAllLand = new ArrayList();
		private ArrayList		SelectedDiscAllMech = new ArrayList();
		private ArrayList		SelectedDiscAllStruct = new ArrayList();
		private ArrayList		nodesExpanded = new ArrayList();
		private static ArrayList		nodesExpandedMainForm = new ArrayList();
		private ArrayList		nodesExpandedResurrect = new ArrayList();
		private NodeType		currentNodeType = new NodeType();
		private TreeNode		nodeHitTest;
		private TreeNode		nodeSelected;
		private bool			checkOnClick = false;
		private System.Drawing.Color	colorDisabled = System.Drawing.Color.Gray;
		private static C1Report reportAllPages = new C1Report();
		string fieldSheetData = "";

		private System.Windows.Forms.Button buttonClearAll;
		private System.Windows.Forms.Button buttonSelectAll;
		private System.Windows.Forms.Panel panelTree;
		private System.Windows.Forms.TreeView treeViewSpecificUnits;
		private System.Windows.Forms.Button buttonPrint;
		private System.Windows.Forms.Label label1;

		private System.Windows.Forms.ContextMenu mnuContextMenu;
		private System.Windows.Forms.MenuItem mnuItemSelectAll;
		private System.Windows.Forms.MenuItem mnuItemClearAll;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuItemSelectUnder;
		private System.Windows.Forms.MenuItem mnuItemClearUnder;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem mnuItemExpandAll;
		private System.Windows.Forms.MenuItem mnuItemCollapseAll;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem mnuItemView;
		private System.Windows.Forms.MenuItem mnuItemViewNormal;
		private System.Windows.Forms.MenuItem mnuItemViewSelected;
		private System.Windows.Forms.MenuItem mnuItemViewReport;
		private System.Windows.Forms.MenuItem mnuItemViewMainTree;
		private System.Windows.Forms.ComboBox comboBoxReportType;
		public System.Windows.Forms.Timer timer;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.ImageList imageListTree;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.ComponentModel.IContainer components;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public FieldSheet()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FieldSheet));
			this.buttonClearAll = new System.Windows.Forms.Button();
			this.buttonSelectAll = new System.Windows.Forms.Button();
			this.panelTree = new System.Windows.Forms.Panel();
			this.treeViewSpecificUnits = new System.Windows.Forms.TreeView();
			this.buttonPrint = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.mnuContextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuItemSelectAll = new System.Windows.Forms.MenuItem();
			this.mnuItemClearAll = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuItemSelectUnder = new System.Windows.Forms.MenuItem();
			this.mnuItemClearUnder = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.mnuItemExpandAll = new System.Windows.Forms.MenuItem();
			this.mnuItemCollapseAll = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.mnuItemView = new System.Windows.Forms.MenuItem();
			this.mnuItemViewNormal = new System.Windows.Forms.MenuItem();
			this.mnuItemViewSelected = new System.Windows.Forms.MenuItem();
			this.mnuItemViewReport = new System.Windows.Forms.MenuItem();
			this.mnuItemViewMainTree = new System.Windows.Forms.MenuItem();
			this.comboBoxReportType = new System.Windows.Forms.ComboBox();
			this.buttonClose = new System.Windows.Forms.Button();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panelTree.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonClearAll
			// 
			this.buttonClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClearAll.Location = new System.Drawing.Point(101, 432);
			this.buttonClearAll.Name = "buttonClearAll";
			this.buttonClearAll.Size = new System.Drawing.Size(88, 23);
			this.buttonClearAll.TabIndex = 5;
			this.buttonClearAll.Text = "&Clear All";
			this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
			// 
			// buttonSelectAll
			// 
			this.buttonSelectAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSelectAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonSelectAll.Location = new System.Drawing.Point(9, 432);
			this.buttonSelectAll.Name = "buttonSelectAll";
			this.buttonSelectAll.Size = new System.Drawing.Size(88, 23);
			this.buttonSelectAll.TabIndex = 4;
			this.buttonSelectAll.Text = "&Select All";
			this.buttonSelectAll.Click += new System.EventHandler(this.buttonSelectAll_Click);
			// 
			// panelTree
			// 
			this.panelTree.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelTree.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelTree.Controls.Add(this.treeViewSpecificUnits);
			this.panelTree.Location = new System.Drawing.Point(7, 68);
			this.panelTree.Name = "panelTree";
			this.panelTree.Size = new System.Drawing.Size(405, 356);
			this.panelTree.TabIndex = 2;
			// 
			// treeViewSpecificUnits
			// 
			this.treeViewSpecificUnits.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treeViewSpecificUnits.BackColor = System.Drawing.SystemColors.Window;
			this.treeViewSpecificUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewSpecificUnits.CheckBoxes = true;
			this.treeViewSpecificUnits.ImageIndex = -1;
			this.treeViewSpecificUnits.Location = new System.Drawing.Point(1, 1);
			this.treeViewSpecificUnits.Name = "treeViewSpecificUnits";
			this.treeViewSpecificUnits.SelectedImageIndex = -1;
			this.treeViewSpecificUnits.Size = new System.Drawing.Size(403, 354);
			this.treeViewSpecificUnits.TabIndex = 3;
			this.treeViewSpecificUnits.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeViewSpecificUnits_MouseDown);
			this.treeViewSpecificUnits.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterExpand);
			this.treeViewSpecificUnits.Click += new System.EventHandler(this.treeViewSpecificUnits_Click);
			this.treeViewSpecificUnits.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterCollapse);
			this.treeViewSpecificUnits.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterSelect);
			this.treeViewSpecificUnits.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCollapse);
			this.treeViewSpecificUnits.BeforeCheck += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCheck);
			this.treeViewSpecificUnits.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeExpand);
			// 
			// buttonPrint
			// 
			this.buttonPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrint.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonPrint.Location = new System.Drawing.Point(226, 432);
			this.buttonPrint.Name = "buttonPrint";
			this.buttonPrint.Size = new System.Drawing.Size(88, 23);
			this.buttonPrint.TabIndex = 6;
			this.buttonPrint.Text = "&Print";
			this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label1.Location = new System.Drawing.Point(11, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(189, 28);
			this.label1.TabIndex = 0;
			this.label1.Text = "Select Field Sheets";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// mnuContextMenu
			// 
			this.mnuContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.mnuItemSelectAll,
																						   this.mnuItemClearAll,
																						   this.menuItem3,
																						   this.mnuItemSelectUnder,
																						   this.mnuItemClearUnder,
																						   this.menuItem6,
																						   this.mnuItemExpandAll,
																						   this.mnuItemCollapseAll,
																						   this.menuItem9,
																						   this.mnuItemView});
			// 
			// mnuItemSelectAll
			// 
			this.mnuItemSelectAll.Index = 0;
			this.mnuItemSelectAll.Text = "&Select All";
			// 
			// mnuItemClearAll
			// 
			this.mnuItemClearAll.Index = 1;
			this.mnuItemClearAll.Text = "&Clear All";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// mnuItemSelectUnder
			// 
			this.mnuItemSelectUnder.Index = 3;
			this.mnuItemSelectUnder.Text = "Select all items under";
			// 
			// mnuItemClearUnder
			// 
			this.mnuItemClearUnder.Index = 4;
			this.mnuItemClearUnder.Text = "Clear all items under";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "-";
			// 
			// mnuItemExpandAll
			// 
			this.mnuItemExpandAll.Index = 6;
			this.mnuItemExpandAll.Text = "E&xpand All";
			// 
			// mnuItemCollapseAll
			// 
			this.mnuItemCollapseAll.Index = 7;
			this.mnuItemCollapseAll.Text = "C&ollapse All";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 8;
			this.menuItem9.Text = "-";
			// 
			// mnuItemView
			// 
			this.mnuItemView.Index = 9;
			this.mnuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.mnuItemViewNormal,
																						this.mnuItemViewSelected,
																						this.mnuItemViewReport,
																						this.mnuItemViewMainTree});
			this.mnuItemView.Text = "View";
			// 
			// mnuItemViewNormal
			// 
			this.mnuItemViewNormal.Checked = true;
			this.mnuItemViewNormal.Index = 0;
			this.mnuItemViewNormal.Text = "User selection";
			// 
			// mnuItemViewSelected
			// 
			this.mnuItemViewSelected.Index = 1;
			this.mnuItemViewSelected.Text = "Selected items only";
			// 
			// mnuItemViewReport
			// 
			this.mnuItemViewReport.Index = 2;
			this.mnuItemViewReport.Text = "Report Type items only";
			// 
			// mnuItemViewMainTree
			// 
			this.mnuItemViewMainTree.Index = 3;
			this.mnuItemViewMainTree.Text = "Same as main data view";
			// 
			// comboBoxReportType
			// 
			this.comboBoxReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportType.DropDownWidth = 194;
			this.helpProvider1.SetHelpKeyword(this.comboBoxReportType, "FieldSheets.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxReportType, System.Windows.Forms.HelpNavigator.Topic);
			this.helpProvider1.SetHelpString(this.comboBoxReportType, "");
			this.comboBoxReportType.Location = new System.Drawing.Point(7, 37);
			this.comboBoxReportType.MaxDropDownItems = 10;
			this.comboBoxReportType.Name = "comboBoxReportType";
			this.helpProvider1.SetShowHelp(this.comboBoxReportType, true);
			this.comboBoxReportType.Size = new System.Drawing.Size(249, 21);
			this.comboBoxReportType.TabIndex = 1;
			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportType_SelectedIndexChanged);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClose.Location = new System.Drawing.Point(322, 432);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(88, 23);
			this.buttonClose.TabIndex = 7;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// timer
			// 
			this.timer.Interval = 250;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(391, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 107;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// FieldSheet
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(418, 464);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.comboBoxReportType);
			this.Controls.Add(this.buttonClearAll);
			this.Controls.Add(this.buttonSelectAll);
			this.Controls.Add(this.panelTree);
			this.Controls.Add(this.buttonPrint);
			this.Controls.Add(this.label1);
			this.helpProvider1.SetHelpKeyword(this, "FieldSheets.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.helpProvider1.SetHelpString(this, "");
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(424, 496);
			this.Name = "FieldSheet";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "FieldSheet";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FieldSheet_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.FieldSheet_Paint);
			this.panelTree.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		protected override void OnLoad(EventArgs e)
		{
			this.SuspendLayout();

			this.Text = "WAM Field Sheets";

			Drive.Configuration.FormState formState = new Drive.Configuration.FormState(
				Drive.Configuration.AppSettings.Settings.GetSetting("ScreenSettings", this.Name));
			formState.RestoreState(this);
			CheckFormProperties();

			//set the dimensions manually because the tree is configured before the controls set their sizes automatically
			pictureBoxHelp.Location = new System.Drawing.Point(this.Width - 34, pictureBoxHelp.Location.Y);
			buttonSelectAll.Location = new System.Drawing.Point(buttonSelectAll.Location.X, this.Height - 66);
			buttonClearAll.Location = new System.Drawing.Point(buttonSelectAll.Location.X + 96, buttonSelectAll.Location.Y);
			buttonClose.Location = new System.Drawing.Point(this.Width - 109, buttonSelectAll.Location.Y);
			buttonPrint.Location = new System.Drawing.Point(buttonClose.Location.X -96, buttonSelectAll.Location.Y);
			this.panelTree.Size = new Size(this.Width - 21, this.Height - 142);
			this.treeViewSpecificUnits.Size = new Size(panelTree.Width - 2, panelTree.Height - 2);

			//this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);

			treeViewSpecificUnits.ImageList = this.imageListTree;
			treeViewSpecificUnits.ImageIndex = 9;
			treeViewSpecificUnits.SelectedImageIndex = 9;

			SetToolTips();
			treeViewSpecificUnits.ContextMenu = mnuContextMenu;

			LoadSpecificUnitsTree();
			LoadReportTypeCombo();
			LoadContextMenu();
			LoadPreferences();

			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			comboBoxReportType_SelectedIndexChanged(this, e);

			SetReportTemplateSettings();

			if (mnuItemViewMainTree.Checked)
			{
				nodesExpandedResurrect = nodesExpandedMainForm;
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectExpandedNodes(node);
				}
				treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			m_initialized = true;

			this.ResumeLayout();
			base.OnLoad(e);
		}

		private void LoadPreferences()
		{
			SetCurrentView(Drive.Configuration.AppSettings.Settings.GetSettingInt("FieldSheetForm", "FieldSheetView", 0));
			SetReportType(Drive.Configuration.AppSettings.Settings.GetSettingInt("FieldSheetForm", "ReportType", 0));
		}

		private void SetToolTips()
		{
			// Create the ToolTip and associate with the Form container.
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			toolTip.SetToolTip(this.pictureBoxHelp, "Help");
		}

		private void LoadContextMenu()
		{
			this.mnuContextMenu.Popup += new System.EventHandler(MyPopupEventHandler);
			this.mnuItemSelectAll.Click += new System.EventHandler(mnuItemSelectAll_OnClick);
			this.mnuItemClearAll.Click += new System.EventHandler(mnuItemClearAll_OnClick);
			this.mnuItemSelectUnder.Click += new System.EventHandler(mnuItemSelectUnder_OnClick);
			this.mnuItemClearUnder.Click += new System.EventHandler(mnuItemClearUnder_OnClick);
			this.mnuItemExpandAll.Click += new System.EventHandler(mnuItemExpandAll_OnClick);
			this.mnuItemCollapseAll.Click += new System.EventHandler(mnuItemCollapseAll_OnClick);
			this.mnuItemViewNormal.Click += new System.EventHandler(mnuItemViewNormal_OnClick);
			this.mnuItemViewSelected.Click += new System.EventHandler(mnuItemViewSelected_OnClick);
			this.mnuItemViewReport.Click += new System.EventHandler(mnuItemViewReport_OnClick);
			this.mnuItemViewMainTree.Click += new System.EventHandler(mnuItemViewMainTree_OnClick);
		}

		protected void MyPopupEventHandler(System.Object sender, System.EventArgs e)
		{
			string nodeText = "";
 
			if (nodeHitTest == null)
			{
				mnuContextMenu.MenuItems[2].Visible = false;
				mnuContextMenu.MenuItems[3].Visible = false;
				mnuContextMenu.MenuItems[4].Visible = false;
			}
			else
			{
				if (nodeHitTest.Nodes.Count == 0)
				{
					mnuContextMenu.MenuItems[2].Visible = false;
					mnuContextMenu.MenuItems[3].Visible = false;
					mnuContextMenu.MenuItems[4].Visible = false;
				}
				//check for red or black ForeColor because we're color-coding them red or black
				//	to match the main data tree
				//else if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				else if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
				{
					if (nodeHitTest.Parent != null)
					{
						mnuContextMenu.MenuItems[2].Visible = true;
						mnuContextMenu.MenuItems[3].Visible = true;
						mnuContextMenu.MenuItems[4].Visible = true;

						nodeText = nodeHitTest.Parent.Text;
						if (nodeText.Length > 25)
						{
							nodeText = nodeHitTest.Parent.Text.Substring(0, 25) + "...";
						}
					
						mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
						mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
					}
				}
				else
				{
					mnuContextMenu.MenuItems[2].Visible = true;
					mnuContextMenu.MenuItems[3].Visible = true;
					mnuContextMenu.MenuItems[4].Visible = true;

					nodeText = nodeHitTest.Text;
					if (nodeText.Length > 25)
					{
						nodeText = nodeHitTest.Text.Substring(0, 25) + "...";
					}
					
					mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
					mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
				}
			}
		}

		private void LoadReportTypeCombo()
		{
			// the following code uses the enumerated values to populate the combo boxes
			NodeTypeHandler.NodeTypeReport[] sources = (NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			ListItem[]		items = new ListItem[sources.Length];
			string curType = "";

			comboBoxReportType.BeginUpdate();
			comboBoxReportType.Items.Clear();
			comboBoxReportType.DisplayMember = "DisplayMember";

			for (int i = 0; i < sources.Length; i++)
			{
				items[i] = new ListItem(NodeTypeHandler.GetNodeTypeStringReport(sources[i]), sources[i]);
				curType = NodeTypeHandler.GetNodeTypeStringReport(sources[i]);
				if (curType.IndexOf("Discipline") > -1 && curType.IndexOf("Pipe") < 0 && curType.IndexOf("Node") < 0)
					comboBoxReportType.Items.Add(items[i]);
			}

			comboBoxReportType.EndUpdate();
			comboBoxReportType.SelectedIndex = 0;
		}

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/

		public static void	ShowForm(Form owner, ArrayList nodesExpandedMain)
		{
			FieldSheet form = new FieldSheet();
			try
			{
				nodesExpandedMainForm = nodesExpandedMain;
				form.ShowDialog(owner);
			}
			catch (System.ArgumentException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("FieldSheet.ShowForm Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			try
			{
				Drive.Configuration.FormState formState = 
					new Drive.Configuration.FormState(this);

				Drive.Configuration.AppSettings.Settings.SetSetting(
					@"ScreenSettings", this.Name, formState.ToString());

				Drive.Configuration.AppSettings.Settings.Save();

				Drive.Configuration.AppSettings.Settings.SetSetting(
					"FieldSheetForm", "FieldSheetView", GetCurrentView().ToString());
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"FieldSheetForm", "ReportType", GetReportType().ToString());

				SaveReportTemplate();
			}
			catch
			{
				System.Diagnostics.Debug.WriteLine("Error.  FieldSheet.OnClosing");
			}

			base.OnClosing(e);
			this.Dispose(true);
		}

		private void comboBoxReportType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				nodeHitTest = null;

				GetSelectedTreeNodes();
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (
					NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				ConfigureTree(nodeTypeReport, true);
				treeViewSpecificUnits.Refresh();
				SetCurrentNodeType();

				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectSelectedNodes(node);
				}

				// if the user is viewing only the selected items, 
				//	configure the tree to show only those items
				if (mnuItemViewSelected.Checked)
				{
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ConfigureTreeSelectedNodes(node);
					}
					if (treeViewSpecificUnits.Nodes.Count > 0)
						treeViewSpecificUnits.Nodes[0].EnsureVisible();
				}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		private void FieldSheet_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void ResetViewItems()
		{
			mnuItemViewNormal.Checked = false;
			mnuItemViewSelected.Checked = false;
			mnuItemViewReport.Checked = false;
			mnuItemViewMainTree.Checked = false;
		}

		private int GetCurrentView()
		{
			if (mnuItemViewNormal.Checked)
				return 0;

			if (mnuItemViewSelected.Checked)
				return 1;

			if (mnuItemViewReport.Checked)
				return 2;

			if (mnuItemViewMainTree.Checked)
				return 3;

			return 0;
		}

		private void SetCurrentView(int curView)
		{
			ResetViewItems();

			switch (curView)
			{
				case 0:
					mnuItemViewNormal.Checked = true;
					break;
				case 1:
					mnuItemViewSelected.Checked = true;
					break;
				case 2:
					mnuItemViewReport.Checked = true;
					break;
				case 3:
					mnuItemViewMainTree.Checked = true;
					break;
				default:
					mnuItemViewNormal.Checked = true;
					break;
			}
		}

		private int GetReportType()
		{
			if (comboBoxReportType.SelectedIndex == -1)
				return 0;
			else
				return comboBoxReportType.SelectedIndex;
		}

		private void SetReportType(int repType)
		{
			//ResetViewItems();

			if (repType > -1 && repType < 4)
				comboBoxReportType.SelectedIndex = repType;
			else
				comboBoxReportType.SelectedIndex = 0;
		}

		private void SetCurrentNodeType()
		{
			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			switch (nodeTypeReport)
			{
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Facility:
					currentNodeType = WAM.UI.NodeType.Facility;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.TreatmentProcess:
					currentNodeType = WAM.UI.NodeType.TreatmentProcess;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.MajorComponent:
					currentNodeType = WAM.UI.NodeType.MajorComponent;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Discipline:
					currentNodeType = WAM.UI.NodeType.NoneSelected;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineLand:
					currentNodeType = WAM.UI.NodeType.DisciplineLand;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineMech:
					currentNodeType = WAM.UI.NodeType.DisciplineMech;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineStruct:
					currentNodeType = WAM.UI.NodeType.DisciplineStruct;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineNode:
					currentNodeType = WAM.UI.NodeType.DisciplineNode;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplinePipe:
					currentNodeType = WAM.UI.NodeType.DisciplinePipe;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset:
					currentNodeType = WAM.UI.NodeType.AssetList;
					break;
			}

		}

		private void FieldSheet_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				MyReportDisplayer.Close();
			}
			catch (SystemException ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
		}

		private void CheckFormProperties()
		{
			if (this.WindowState == FormWindowState.Minimized 
				|| this.Height < 50 
				|| Math.Abs(this.Left) > 2000 || Math.Abs(this.Top) > 2000)
			{
				this.WindowState = FormWindowState.Normal;
				this.Size = this.MinimumSize;
				this.Left = 0;
				this.Top = 0;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Click Events *****/

		private void FieldSheet_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		protected void mnuItemSelectAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(true);
		}

		protected void mnuItemClearAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(false);
		}

		protected void mnuItemExpandAll_OnClick(System.Object sender, System.EventArgs e)
		{
			try
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
				treeViewSpecificUnits.ExpandAll();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemCollapseAll_OnClick(System.Object sender, System.EventArgs e)
		{
			treeViewSpecificUnits.CollapseAll();
		}

		protected void mnuItemSelectUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(true);
		}

		protected void mnuItemClearUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(false);
		}

		protected void mnuItemView_OnClick(System.Object sender, System.EventArgs e)
		{
		}

		protected bool SaveView()
		{
			try
			{
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "FieldSheetView", GetCurrentView().ToString());
			}
			catch
			{
				return false;
			}
			return true;
		}

		protected void mnuItemViewNormal_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
			try
			{
				if (!mnuItemViewNormal.Checked)
				{
					if (mnuItemViewNormal.Text == "User selection")
					{
						//begin user selection
						ResetViewItems();
						mnuItemViewNormal.Checked = true;
					}
					else
					{
						ResetViewItems();
						mnuItemViewNormal.Checked = true;
						mnuItemViewNormal.Text = "User selection";
						SaveView();
						nodesExpandedResurrect = nodesExpanded;
						treeViewSpecificUnits.CollapseAll();
						foreach (TreeNode node in treeViewSpecificUnits.Nodes)
						{
							ResurrectExpandedNodes(node);
						}
					}
				}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewSelected_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewSelected.Checked = true;
				SaveView();
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ConfigureTreeSelectedNodes(node);
				}
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewReport_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewReport.Checked = true;
				SaveView();
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				ConfigureTree(nodeTypeReport, false);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewMainTree_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				//if (!mnuItemViewMainTree.Checked)
				//{
					ResetViewItems();
					mnuItemViewMainTree.Checked = true;
					SaveView();
					nodesExpandedResurrect = nodesExpandedMainForm;
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ResurrectExpandedNodes(node);
					}
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
				//}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		private void buttonSelectAll_Click(object sender, System.EventArgs e)
		{
			mnuItemSelectAll_OnClick(sender, e);
		}

		private void buttonClearAll_Click(object sender, System.EventArgs e)
		{
			mnuItemClearAll_OnClick(sender, e);
		}

		#endregion /***** Click Events *****/

		#region /***** Tree Populate *****/

		private void		LoadSpecificUnitsTree()
		{
			Facility[]		facilities = null;
			Facility		facility = null;

			facilities = CacheManager.GetFacilities(InfoSet.CurrentID);
			TreeNode		node;

			// Walk the facilities array and add the items to the tree
			treeViewSpecificUnits.BeginUpdate();
			treeViewSpecificUnits.Nodes.Clear();
			
			// Populate the facilities
			for (int pos = 0; pos < facilities.Length; pos++)
			{
				facility = facilities[pos];
				node = new TreeNode(facility.Name);
				node.Tag = facility;

				node.ImageIndex = 0;
				node.SelectedImageIndex = 0;

				treeViewSpecificUnits.Nodes.Add(node);

				if (facility.HasChildren)
					PopulateTreeProcesses(node);
			}

			treeViewSpecificUnits.EndUpdate();
		}

		private void PopulateTreeProcesses(TreeNode facilityNode)
		{
			// Get the root nodes (facilities)
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(InfoSet.CurrentID, 
				((Facility)facilityNode.Tag).ID);
			TreatmentProcess process;
			TreeNode		node;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				node = new TreeNode(process.Name);
				node.Tag = process;

				node.ImageIndex = 3;
				node.SelectedImageIndex = 3;

				facilityNode.Nodes.Add(node);

				if (process.HasChildren)
					PopulateTreeComponents(node);
			}
		}

		private void		PopulateTreeComponents(TreeNode processNode)
		{
			// Get the root nodes (facilities)
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, 
				((TreatmentProcess)processNode.Tag).ID);
			MajorComponent	component;
			TreeNode		node;

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				node = new TreeNode(component.Name);
				node.Tag = component;
				
				node.ImageIndex = 5;
				node.SelectedImageIndex = 5;
				
				processNode.Nodes.Add(node);

				// Add disciplines
				PopulateTreeDisciplines(node);
			}
		}

		private void		PopulateTreeDisciplines(TreeNode componentNode)
		{
			// Get the root nodes (facilities)
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, 
				((MajorComponent)componentNode.Tag).ID);
			Discipline		discipline;
			TreeNode		node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				//show all disciplines, regardless of condition
				//if (discipline.ConditionRanking == CondRank.No)
				//	continue;

				node = new TreeNode(discipline.Name);
				node.Tag = discipline;

				node.ImageIndex = 7;
				node.SelectedImageIndex = 7;

				componentNode.Nodes.Add(node);

				//since we're showing all disciplines, color code them to match the data tree so the user will know
				//	which ones have condition values
				if (discipline.ConditionRanking == CondRank.No)
					node.ForeColor = Color.FromArgb(255, 0, 0);
				else
					node.ForeColor = Color.FromArgb(0, 0, 0);

				if (discipline.Type == DisciplineType.Mechanical)
				{
					// Check to see if there are any assets for this item, and if
					// so, add an "asset list" node
					ComponentAsset[] assets = 
						CacheManager.GetAssets(InfoSet.CurrentID, discipline.ComponentID);

					if (assets.Length > 0)
					{
						TreeNode assetNode;

						assetNode = new TreeNode("Asset List");
						assetNode.Tag = assets[0];

						node.ImageIndex = 7;
						node.SelectedImageIndex = 7;

						node.Nodes.Add(assetNode);
					}
				}
			}
		}

		#endregion /***** Tree Populate *****/

		#region /***** Tree Handling Code *****/

		private void ResurrectExpandedNodes(TreeNode node)
		{
			if (nodesExpandedResurrect.Contains(node.Tag))
				node.Expand();

			foreach (TreeNode nodeChild in node.Nodes)
				ResurrectExpandedNodes(nodeChild);
		}

		private void ResurrectSelectedNodes(TreeNode node)
		{
			switch (currentNodeType)
			{
				case WAM.UI.NodeType.DisciplineMech:
					if (node.Tag is DisciplineMech)
					{
						if (SelectedDiscMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineLand:
					if (node.Tag is DisciplineLand)
					{
						if (SelectedDiscLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineStruct:
					if (node.Tag is DisciplineStruct)
					{
						if (SelectedDiscStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.NoneSelected:

					if (node.Tag is DisciplineLand)
					{
						if (SelectedDiscAllLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplineMech)
					{
						if (SelectedDiscAllMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplineStruct)
					{
						if (SelectedDiscAllStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;
			}
		}

		private void CheckNodesAll(bool checkNode)
		{
			autoChecking = true;
			ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				if (checkNode)
					CheckNodes(node, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, true);
				else
					CheckNodesAll2(node, checkNode);
			}
			autoChecking = false;
		}

		private void CheckNodes(TreeNode nodeStart, NodeTypeHandler.NodeTypeReport nodeReportType, bool checkNode, bool checkNodeStart)
		{
			//check all nodes of a certain node type under nodeStart
			if (checkNodeStart)
			{
				if (nodeStart.Tag.ToString() == "WAM.Data." + nodeReportType.ToString() 
					&& nodeStart.Tag.ToString().IndexOf("Pipe") < 0 
					&& nodeStart.Tag.ToString().IndexOf("Node") < 0)
				{
					nodeStart.Checked = checkNode;
				}
			}

			foreach(TreeNode nodeChild in nodeStart.Nodes)
			{
				//allow only Mech, Struct, and Land disciplines to be checked (not pipes and nodes)
				//if (nodeReportType == NodeTypeHandler.NodeTypeReport.Discipline
				//	&& nodeChild.Parent.Tag.ToString() == "WAM.Data.MajorComponent")
				if (nodeReportType == NodeTypeHandler.NodeTypeReport.Discipline
					&& nodeChild.Parent.Tag.ToString() == "WAM.Data.MajorComponent"
					&& nodeChild.Tag.ToString() != "WAM.Data.DisciplinePipe"
					&& nodeChild.Tag.ToString() != "WAM.Data.DisciplineNode")
				{
					nodeChild.Checked = checkNode;
				}
				else if (nodeChild.Tag.ToString() == "WAM.Data." + nodeReportType.ToString() 
					&& nodeChild.Tag.ToString().IndexOf("Pipe") < 0 
					&& nodeChild.Tag.ToString().IndexOf("Node") < 0)
				{
					nodeChild.Checked = checkNode;
				}
				if (nodeChild.Nodes.Count > 0)
					CheckNodes(nodeChild, nodeReportType, checkNode, checkNodeStart);
			}
		}

		private void CheckNodesAll2(TreeNode node, bool checkNode)
		{
			node.Checked = checkNode;
			if (node.Nodes.Count > 0)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					CheckNodesAll2(nodeChild, checkNode);
				}

			}
		}

		private void SelectUnder(bool checkNode)
		{
			autoChecking = true;
			ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			//check for red or black ForeColor because we're color-coding them red or black
			//	to match the main data tree
			//if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
			if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
			{
				if (nodeHitTest.Parent != null)
				{
					CheckNodes(nodeHitTest.Parent, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
				}
			}
			else
			{
				CheckNodes(nodeHitTest, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
			}

			autoChecking = false;
		}

		private void GetSelectedTreeNodes()
		{
			printItems.Clear();

			foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
			{
				if (treeNode.Checked)
				{
					printItems.Add(treeNode.Tag);
				}
				if (treeNode.Nodes.Count > 0)
				{
					GetCheckedNodes(treeNode);
				}
			}

			RecordSelectedNodes();
		}

		private void		GetCheckedNodes(TreeNode parent)
		{
			TreeNode		node;

			for (int pos = 0; pos < parent.Nodes.Count; pos++)
			{
				node = parent.Nodes[pos];

				if (node.Checked)
				{
					printItems.Add(node.Tag);
				}

				if (node.Nodes.Count > 0)
				{
					GetCheckedNodes(node);
				}
			}
		}

		private void ConfigureTree(NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				treeViewSpecificUnits.CollapseAll();
			}

			NodeTypeHandler.NodeTypeReport[] sources = 
				(NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			
			for (int i = 0; i < sources.Length; i++)
			{
				if (nodeTypeReport == sources[i])
				{
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						if (uncheckNodes == true)
						{
							node.Checked = false;
						}
						if (node.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString()
							&& node.Tag.ToString().IndexOf("Pipe") < 0 
							&& node.Tag.ToString().IndexOf("Node") < 0)
						{
							//don't make the discipline nodes blue, because we're color-coding them red or black
							//	to match the main data tree
							//node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
							if (((Discipline)node.Tag).ConditionRanking == CondRank.No)
								node.ForeColor = Color.FromArgb(255, 0, 0);
							else
								node.ForeColor = Color.FromArgb(0, 0, 0);

							node.ImageIndex = 0;
							node.SelectedImageIndex = 0;
						}
						else
						{
							node.ForeColor = System.Drawing.SystemColors.GrayText;
							node.ImageIndex = 1;
							node.SelectedImageIndex = 1;
						}

						ConfigureChildren(node, nodeTypeReport, uncheckNodes);
					}
				}
			}
			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
		}

		private void ConfigureChildren(TreeNode node, NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			TreeNode nodeParent;
			int useImageIndex = 0;
			if (uncheckNodes == true)
			{
				node.Checked = false;
			}
			foreach(TreeNode nodeChild in node.Nodes)
			{
				if (uncheckNodes == true)
				{
					nodeChild.Checked = false;
				}
				if (nodeChild.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString() 
					|| nodeChild.Tag.ToString().Substring(9).StartsWith(nodeTypeReport.ToString())
					&& nodeChild.Tag.ToString().IndexOf("Pipe") < 0 
					&& nodeChild.Tag.ToString().IndexOf("Node") < 0)
				{
					//don't make the discipline nodes blue, because we're color-coding them red or black
					//	to match the main data tree
					//nodeChild.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
					if (((Discipline)nodeChild.Tag).ConditionRanking == CondRank.No)
						nodeChild.ForeColor = Color.FromArgb(255, 0, 0);
					else
						nodeChild.ForeColor = Color.FromArgb(0, 0, 0);

					switch (nodeTypeReport.ToString())
					{
						case "TreatmentProcess":
						{
							useImageIndex = 3;
							break;
						}
						case "MajorComponent":
						{
							useImageIndex = 5;
							break;
						}
						case "Discipline":
						case "DisciplineMech":
						case "DisciplineStruct":
						case "DisciplineLand":
						case "DisciplinePipe":
						case "DisciplineNode":
						{
							useImageIndex = 7;
							break;
						}
						case "ComponentAsset":
						{
							useImageIndex = 9;
							break;
						}
					}

					nodeChild.ImageIndex = useImageIndex;
					nodeChild.SelectedImageIndex = useImageIndex;

					if (mnuItemViewReport.Checked)
					{
						//expand all parents of nodeChild so that nodeChild is visible
						nodeParent = nodeChild.Parent;
						nodeParent.Expand();
						while (nodeParent.Parent != null)
						{
							nodeParent.Parent.Expand();
							nodeParent = nodeParent.Parent;
						}
					}

				}
				else
				{
					nodeChild.ForeColor = System.Drawing.SystemColors.GrayText;
					nodeChild.ImageIndex = 1;
					nodeChild.SelectedImageIndex = 1;
				}

				ConfigureChildren(nodeChild, nodeTypeReport, uncheckNodes);
			}
		}

		private void ConfigureTreeSelectedNodes(TreeNode node)
		{
			TreeNode nodeExpand = node;
			if (node.Checked == true)
				while (nodeExpand.Parent != null && nodeExpand.Parent.IsExpanded == false)
				{
					nodeExpand.Parent.Expand();
					nodeExpand = nodeExpand.Parent;
				}

			foreach (TreeNode nodeChild in node.Nodes)
			{
				ConfigureTreeSelectedNodes(nodeChild);
			}
		}

		private void treeViewSpecificUnits_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
				
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
			else
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor == System.Drawing.SystemColors.GrayText)
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
			}
		}

		private void treeViewSpecificUnits_Click(object sender, System.EventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null && nodeSelected != null && nodeHitTest == nodeSelected)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
			}
		}

		private void treeViewSpecificUnits_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
			if (treeViewSpecificUnits.SelectedNode == null)
			{
				treeViewSpecificUnits.SelectedNode = treeViewSpecificUnits.Nodes[0];
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
		}

		private void treeViewSpecificUnits_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			nodeHitTest = treeViewSpecificUnits.GetNodeAt(e.X, e.Y);
		}

		private void treeViewSpecificUnits_AfterCollapse(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeCollapse(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeCheck(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (nodeHitTest == null || autoChecking == true)
				return;

			if (nodeHitTest.ForeColor == System.Drawing.SystemColors.GrayText)
				e.Cancel = true;
		}

		private void RecordTreeExpandedState()
		{
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();

			nodesExpanded.Clear();
			nodesExpanded = commonTasks.RecordTreeExpandedState(treeViewSpecificUnits);
			commonTasks = null;
		}

		private void RecordSelectedNodes()
		{
			// Add the nodes in printItems[] to the various array lists

			switch (currentNodeType)
			{
				//case NodeTypeHandler.NodeTypeReport.DisciplineMech:
				case NodeType.DisciplineMech:
				{
					SelectedDiscMech.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscMech.Add(((DisciplineMech)printItems[i]).ID);
						SelectedDiscMech.Add(printItems[i]);
					}
					break;
				}
				//case NodeTypeHandler.NodeTypeReport.DisciplineLand:
				case NodeType.DisciplineLand:
				{
					SelectedDiscLand.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscLand.Add(((DisciplineLand)printItems[i]).ID);
						SelectedDiscLand.Add(printItems[i]);
					}
					break;
				}
				//case NodeTypeHandler.NodeTypeReport.DisciplineStruct:
				case NodeType.DisciplineStruct:
				{
					SelectedDiscStruct.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscStruct.Add(((DisciplineStruct)printItems[i]).ID);
						SelectedDiscStruct.Add(printItems[i]);
					}
					break;
				}
				//case NodeTypeHandler.NodeTypeReport.Discipline:
				case NodeType.NoneSelected:
				{
					SelectedDiscAllLand.Clear();
					SelectedDiscAllMech.Clear();
					SelectedDiscAllStruct.Clear();

					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscAll.Add(printItems[i]);
						if (printItems[i] is DisciplineLand)
							SelectedDiscAllLand.Add(printItems[i]);
						else if (printItems[i] is DisciplineMech)
							SelectedDiscAllMech.Add(printItems[i]);
						else if (printItems[i] is DisciplineStruct)
							SelectedDiscAllStruct.Add(printItems[i]);
					}
					break;
				}
			}
		}

		#endregion /***** Tree Handling Code *****/

		#region /***** Create Reports *****/

		private void timer_Tick(object sender, System.EventArgs e)
		{
			if (newTemplateNameFromForm.Length != 0)
			{
				newTemplateNameFromForm = "";
				timer.Enabled = false;
				CreateReports(true);

				try
				{
					reportPrintStatusForm.Close();
				}
				catch
				{
					System.Diagnostics.Debug.WriteLine("PrintStatusReport form did not close in timer_Tick");
				}
			}
		}

		private object GetSelectedNodeObject()
		{
			TreeNode node = treeViewSpecificUnits.SelectedNode;

			if (node == null)
				return null;

			return node.Tag;
		}

		private void CreateReports(bool printOnly)
		{
			reportAllPages.Clear();

			try
			{
				MyReportDisplayer.Close();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("FieldSheet.CreateReports Error (attempting to close MyReportDisplayer): {0}\n", ex.Message));
			}

			MyReportDisplayer = new Reports.UI.C1ReportDisplayerForm(MainForm.AppForm);


			ListItem reportType = comboBoxReportType.SelectedItem as ListItem;
			NodeTypeHandler.NodeTypeReport[] sources = (NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			NodeTypeHandler.NodeTypeReport nodeReportType = new WAM.UI.NodeTypeHandler.NodeTypeReport();

			for (int i = 0; i < sources.Length; i++)
			{
				if (sources[i] == (NodeTypeHandler.NodeTypeReport)reportType.Value)
				{
					nodeReportType = (NodeTypeHandler.NodeTypeReport)reportType.Value;
					break;
				}
			}
			for (int pos = 0; pos < printItems.Count; pos++)
			{
				currentReport.Clear();
				currentReport.Add(printItems[pos]);
			}

			for (int pos = 0; pos < printItems.Count; pos++)
			{
				if (reportPrintStatusForm.CancelPreview)
				{
					reportPrintStatusForm.CancelPreview = false;
					reportPrintStatusForm.Close();
					MessageBox.Show("The report printing has been cancelled.", "Print Reports", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);

					return;
				}
				else
				{
					eventArgs.Status = "Generating report " + (pos + 1) + " of " + printItems.Count.ToString();
					WAM.UI.ReportPrintStatus.InvokeUpdateEvent(null, eventArgs); 
				}

				WAM.Reports.FieldSheetReport.Print((Discipline)printItems[pos]);
			}

			try
			{
				reportPrintStatusForm.Close();
				reportPrintStatusForm.Dispose();
			}
			catch
			{
				System.Diagnostics.Debug.WriteLine("PrintStatusForm did not close in CreateReports");
			}

			MyReportDisplayer.c1PrintPreview.Print();
		}

		public static bool LoadReport(C1.Win.C1Report.C1Report MyReport)
		{
			C1Report m_report = new C1Report();
			StringBuilder builder = new StringBuilder(60);

			m_report = MyReport;
			m_report.Render();

			foreach (Image img in m_report.PageImages)
			{
				MyReportDisplayer.c1PrintPreview.Pages.Add((object)img.Clone());
			}

			return true;
		}

		#endregion /***** Create Reports *****/

		#region /***** Navigation Buttons *****/

		private void buttonPrint_Click(object sender, System.EventArgs e)
		{
			GetSelectedTreeNodes();

			if (printItems.Count == 0)
			{
				MessageBox.Show("Please select at least one item to print", "Field Sheets", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			newTemplateNameFromForm = "";

			if (reportPrintStatusForm.IsDisposed || reportPrintStatusForm == null)
			{
				reportPrintStatusForm = new ReportPrintStatus();
			}

			timer.Enabled = true;
			reportPrintStatusForm.OnMessage += new ReportPrintStatus.Message(this.txtMessage);
			reportPrintStatusForm.ShowDialog();
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		#endregion /***** Navigation Buttons *****/

		#region /***** Template *****/

		private void txtMessage(string str)
		{
			newTemplateNameFromForm = str;
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", HelpNavigator.Topic, "FieldSheets.htm");
		}

		private void SetReportTemplateSettings()
		{
			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			ConfigureTree(nodeTypeReport, true);
			treeViewSpecificUnits.Refresh();
			SetCurrentNodeType();
			SetReportTemplateCheckedNodes();
		}

		private void SetReportTemplateCheckedNodes()
		{
			// Get the selected nodes from the xml file and set the tree accordingly

			int currentInfoSetID = InfoSet.CurrentID;

			SelectedDiscAllLand.Clear();
			SelectedDiscAllMech.Clear();
			SelectedDiscAllStruct.Clear();
			SelectedDiscLand.Clear();
			SelectedDiscMech.Clear();
			SelectedDiscStruct.Clear();

			//determine if file exists
			System.IO.FileStream fileStream = null;
			string filePath = string.Format(@"{0}\" + "FieldSheet.xml", Drive.IO.Directory.GetApplicationPath());
			if (!System.IO.File.Exists(filePath))
				return;

			try
			{
				//read xml file
				dataSetLoad.Clear();
				fileStream = new System.IO.FileStream(@filePath, System.IO.FileMode.Open);
				DataRow[] dataRows;
	
				dataSetLoad.ReadXml(fileStream);

				foreach(System.Data.DataTable dataTable in dataSetLoad.Tables)
				{
					dataRows = dataTable.Select("InfoSetID = " + currentInfoSetID);
					if (dataRows == null)
					{
						continue;
					}
					if (dataRows.Length == 0)
					{
						continue;
					}

					switch (dataTable.TableName)
					{
						case "FieldSheetDiscLand":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								//MessageBox.Show(dataRow["InfoSetID"].ToString() + "; " + dataRow["NodeID"].ToString());
								SelectedDiscLand.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Land));
							}
							break;

						case "FieldSheetDiscMech":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								SelectedDiscMech.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Mechanical));
							}
							break;

						case "FieldSheetDiscStruct":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								SelectedDiscStruct.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Structural));
							}
							break;

						case "FieldSheetDiscLandAll":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								SelectedDiscAllLand.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Land));
							}
							break;

						case "FieldSheetDiscMechAll":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								SelectedDiscAllMech.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Mechanical));
							}
							break;

						case "FieldSheetDiscStructAll":
							foreach(System.Data.DataRow dataRow in dataTable.Rows)
							{
								SelectedDiscAllStruct.Add(CacheManager.GetDiscipline(currentInfoSetID, Convert.ToInt32(dataRow["NodeID"]), 
									WAM.Data.DisciplineType.Structural));
							}
							break;
					}
				}

				//remove rows from dataSetLoad so that it contains only data for InfoSets OTHER than the current one
				System.Data.DataSet dataSetTemp = dataSetLoad.Clone();
				foreach(System.Data.DataTable dataTable in dataSetLoad.Tables)
				{
					dataRows = dataTable.Select("InfoSetID <> " + currentInfoSetID);

					if (dataRows == null)
					{
						continue;
					}

					foreach(System.Data.DataRow dataRow in dataRows)
					{
						DataRow dataRowAdd;
						dataRowAdd = dataSetTemp.Tables[dataTable.ToString()].NewRow();
						dataRowAdd["InfoSetID"] = dataRow["InfoSetID"];
						dataRowAdd["NodeID"] = dataRow["NodeID"];
						dataRowAdd["DiscAll"] = dataRow["DiscAll"];
						dataSetTemp.Tables[dataTable.ToString()].Rows.Add(dataRowAdd);
					}
				}
				dataSetLoad = dataSetTemp;

				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectSelectedNodes(node);
				}

				// if the user is viewing only the selected items, 
				//	configure the tree to show only those items
				if (mnuItemViewSelected.Checked)
				{
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
					{
						ConfigureTreeSelectedNodes(treeNode);
					}
					if (treeViewSpecificUnits.Nodes.Count > 0)
						treeViewSpecificUnits.Nodes[0].EnsureVisible();
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			try
			{
				fileStream.Close();
				fileStream = null;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
		}

		private bool SaveReportTemplate()
		{
			bool result = false;

			try
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
				SaveTemplateNodesChecked();
				result = true;
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
				result = false;
			}

			return result;
		}

		private bool SaveTemplateNodesChecked()
		{
			System.IO.FileStream fileStream = null;
			bool result = false;

			try
			{
				DataSet dataSet = new DataSet();
				
				dataSet.Tables.Add("FieldSheetDiscLandAll");
				dataSet.Tables.Add("FieldSheetDiscMechAll");
				dataSet.Tables.Add("FieldSheetDiscStructAll");
				dataSet.Tables.Add("FieldSheetDiscLand");
				dataSet.Tables.Add("FieldSheetDiscMech");
				dataSet.Tables.Add("FieldSheetDiscStruct");

				for (int i = 0; i < dataSet.Tables.Count; i++)
				{
					dataSet.Tables[i].Columns.Add("InfoSetID", System.Type.GetType("System.Int32"));
					dataSet.Tables[i].Columns.Add("NodeID", System.Type.GetType("System.Int32"));
					dataSet.Tables[i].Columns.Add("DiscAll", System.Type.GetType("System.Byte"));
				}

				GetSelectedTreeNodes();

				// DiscAll nodes *************************

				for (int i = 0; i < SelectedDiscAllLand.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscLandAll"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineLand)SelectedDiscAllLand[i]).ID;
					dataRow["DiscAll"] = 1;
					dataSet.Tables["FieldSheetDiscLandAll"].Rows.Add(dataRow);
				}

				for (int i = 0; i < SelectedDiscAllMech.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscMechAll"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineMech)SelectedDiscAllMech[i]).ID;
					dataRow["DiscAll"] = 1;
					dataSet.Tables["FieldSheetDiscMechAll"].Rows.Add(dataRow);
				}

				for (int i = 0; i < SelectedDiscAllStruct.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscStructAll"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineStruct)SelectedDiscAllStruct[i]).ID;
					dataRow["DiscAll"] = 1;
					dataSet.Tables["FieldSheetDiscStructAll"].Rows.Add(dataRow);
				}

				// DiscLand nodes *************************

				for (int i = 0; i < SelectedDiscLand.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscLand"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineLand)SelectedDiscLand[i]).ID;
					dataRow["DiscAll"] = 0;
					dataSet.Tables["FieldSheetDiscLand"].Rows.Add(dataRow);
				}

				// DiscMech nodes *************************

				for (int i = 0; i < SelectedDiscMech.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscMech"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineMech)SelectedDiscMech[i]).ID;
					dataRow["DiscAll"] = 0;
					dataSet.Tables["FieldSheetDiscMech"].Rows.Add(dataRow);
				}

				// DiscStruct nodes *************************

				for (int i = 0; i < SelectedDiscStruct.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSet.Tables["FieldSheetDiscStruct"].NewRow();
					dataRow["InfoSetID"] = InfoSet.CurrentID;
					dataRow["NodeID"] = ((DisciplineStruct)SelectedDiscStruct[i]).ID;
					dataRow["DiscAll"] = 0;
					dataSet.Tables["FieldSheetDiscStruct"].Rows.Add(dataRow);
				}

				//add the currently selected nodes to dataSetLoad (which already contains the data for other InfoSets)
				foreach(System.Data.DataTable dataTable in dataSet.Tables)
				{
					foreach(System.Data.DataRow dataRow in dataTable.Rows)
					{
						if (dataSetLoad.Tables[dataTable.ToString()] == null)
						{
							dataSetLoad.Tables.Add(dataTable.ToString());
							dataSetLoad.Tables[dataTable.ToString()].Columns.Add("InfoSetID", System.Type.GetType("System.Int32"));
							dataSetLoad.Tables[dataTable.ToString()].Columns.Add("NodeID", System.Type.GetType("System.Int32"));
							dataSetLoad.Tables[dataTable.ToString()].Columns.Add("DiscAll", System.Type.GetType("System.Byte"));

						}

						DataRow dataRowAdd;
						dataRowAdd = dataSetLoad.Tables[dataTable.ToString()].NewRow();
						dataRowAdd["InfoSetID"] = dataRow["InfoSetID"];
						dataRowAdd["NodeID"] = dataRow["NodeID"];
						dataRowAdd["DiscAll"] = dataRow["DiscAll"];
						dataSetLoad.Tables[dataTable.ToString()].Rows.Add(dataRowAdd);
					}
				}

				//this is getting pretty kludgey
				//write the data to an xml file
				string filenameWrite = string.Format(@"{0}\" + "FieldSheet.xml", Drive.IO.Directory.GetApplicationPath());
				fileStream = new System.IO.FileStream(filenameWrite, System.IO.FileMode.Create);
				dataSetLoad.WriteXml(fileStream);
				fileStream.Close();

				//mam 112806 - don't set file to hidden, as it seems to be causing an error when trying to open the
				//	file for reading in the code above
				//if (System.IO.File.Exists(filenameWrite))
				//{
				//	System.IO.File.SetAttributes(filenameWrite, System.IO.FileAttributes.Hidden);
				//}

				//write the data to the database
				System.IO.StreamReader streamReader = new System.IO.StreamReader(filenameWrite);
				fieldSheetData = streamReader.ReadToEnd();
				streamReader.Close();

				WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
				dataAccess.ExecuteCommand("DELETE FROM FieldSheetData");
				dataAccess.ExecuteCommand("INSERT INTO FieldSheetData (FieldSheetData) VALUES('" + fieldSheetData.ToString() + "')");

				fileStream = null;
				streamReader = null;
				dataAccess = null;

				result = true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return result;
		}

		private void ResetTemplateValues()
		{
			comboBoxReportType.SelectedIndex = 0;
			CheckNodesAll(false);

			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
				treeViewSpecificUnits.CollapseAll();
		}

		#endregion /***** Template *****/

	}
}
