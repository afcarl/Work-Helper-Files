using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for SplashScreenForm.
	/// </summary>
	public class SplashScreenForm : System.Windows.Forms.Form
	{
		private bool		m_isAboutBox = false;

		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private WAM.UI.CacheBuildStatusControl cacheBuildStatusControl1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labelVersion;
		private System.Windows.Forms.Label labelBuildDate;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SplashScreenForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SplashScreenForm));
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.cacheBuildStatusControl1 = new WAM.UI.CacheBuildStatusControl();
			this.label1 = new System.Windows.Forms.Label();
			this.labelVersion = new System.Windows.Forms.Label();
			this.labelBuildDate = new System.Windows.Forms.Label();
			this.buttonClose = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(280, 376);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 0;
			this.pictureBoxLogo.TabStop = false;
			// 
			// cacheBuildStatusControl1
			// 
			this.cacheBuildStatusControl1.AllowCancelCache = false;
			this.cacheBuildStatusControl1.BackColor = System.Drawing.SystemColors.Control;
			this.cacheBuildStatusControl1.Location = new System.Drawing.Point(288, 258);
			this.cacheBuildStatusControl1.Name = "cacheBuildStatusControl1";
			this.cacheBuildStatusControl1.Size = new System.Drawing.Size(320, 118);
			this.cacheBuildStatusControl1.TabIndex = 5;
			this.cacheBuildStatusControl1.Visible = false;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(324, 92);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(260, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Carollo Water / Wastewater Asset Manager";
			// 
			// labelVersion
			// 
			this.labelVersion.BackColor = System.Drawing.Color.Transparent;
			this.labelVersion.Location = new System.Drawing.Point(324, 112);
			this.labelVersion.Name = "labelVersion";
			this.labelVersion.Size = new System.Drawing.Size(260, 16);
			this.labelVersion.TabIndex = 2;
			// 
			// labelBuildDate
			// 
			this.labelBuildDate.BackColor = System.Drawing.Color.Transparent;
			this.labelBuildDate.Location = new System.Drawing.Point(324, 132);
			this.labelBuildDate.Name = "labelBuildDate";
			this.labelBuildDate.Size = new System.Drawing.Size(260, 16);
			this.labelBuildDate.TabIndex = 4;
			// 
			// buttonClose
			// 
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(411, 340);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.TabIndex = 6;
			this.buttonClose.Text = "&Close";
			this.buttonClose.Visible = false;
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(324, 152);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(260, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Copyright � 2001-2014";	//mam 10112014
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Location = new System.Drawing.Point(288, 257);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(321, 1);
			this.panel3.TabIndex = 9;
			this.panel3.Visible = false;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Location = new System.Drawing.Point(608, 257);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(1, 120);
			this.panel4.TabIndex = 10;
			this.panel4.Visible = false;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel5.Location = new System.Drawing.Point(288, 257);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(1, 120);
			this.panel5.TabIndex = 11;
			this.panel5.Visible = false;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(288, 376);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(321, 1);
			this.panel1.TabIndex = 12;
			this.panel1.Visible = false;
			// 
			// SplashScreenForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(614, 382);
			this.ControlBox = false;
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.labelVersion);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cacheBuildStatusControl1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.labelBuildDate);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SplashScreenForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.TransparencyKey = System.Drawing.Color.Fuchsia;
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SplashScreenForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.SplashScreenForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowAboutForm(Form owner)
		{
			SplashScreenForm form = new SplashScreenForm();

			form.m_isAboutBox = true;
			form.ShowDialog(owner);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			//mam 11142011 - change this to a hard-coded compile date - no, let's leave it as is
			DateTime date = Directory.GetLastWriteTime(Application.ExecutablePath);

			//mam 020607 - updated Repair Cost equation, so increased version from 3.0 to 3.0.1
			//	update: left it at 3.0
			//labelVersion.Text = string.Format("Version {0}", Application.ProductVersion.ToString().Substring(0, 3));

			//mam 11142011 - go back to displaying major.minor.build instead of major.minor
			labelVersion.Text = string.Format("Version {0}", Application.ProductVersion.ToString().Substring(0, 5));

			labelBuildDate.Text = string.Format("Build Date: {0}", date.ToString("MM/dd/yyyy"));

			System.Reflection.Assembly thisExe;
			thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = thisExe.GetManifestResourceStream("WAM.Graphics.Logo.bmp");

			Image image = (Bitmap)Bitmap.FromStream(file);
			pictureBoxLogo.Image = image;

			buttonClose.Visible = m_isAboutBox;
			cacheBuildStatusControl1.Visible = !m_isAboutBox;

			if (m_isAboutBox)
				this.Text = "About Carollo Water / Wastewater Asset Manager";

			base.OnLoad(e);
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void SplashScreenForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void SplashScreenForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (buttonClose.Visible)
			{
				if (e.KeyChar == (char)27)
				{
					//this.DialogResult = DialogResult.Cancel;
					this.Close();
				}
			}
		}
	}
}
