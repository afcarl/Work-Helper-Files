using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for EquationViewer.
	/// </summary>
	public class EquationViewer : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		//private MainForm parentForm = new MainForm();
		private MainForm parentForm = null;

		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.Button buttonClearSelected;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.Button buttonClearAll;
		private System.Windows.Forms.Panel panelToolbarBottom;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Splitter splitter1;
		private C1.Win.C1FlexGrid.C1FlexGrid gridEquation;
		private System.Windows.Forms.TextBox textBoxEquationOriginal;
		private System.Windows.Forms.TextBox textBoxEquation;
		private System.Windows.Forms.HelpProvider helpProvider1;

		public delegate void MessageEquation(bool equationFormOpen);
		//public event MessageEquation OnMessageEquation;
//		//public bool userCancelPreview = false;
//		private ReportUpdateHandler	m_reportUpdateDelegate = null;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public EquationViewer(MainForm form)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			parentForm = form;
			this.Text = "Equation Viewer";
			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(EquationViewer));
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.panelToolbarBottom = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.buttonClearSelected = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.buttonClearAll = new System.Windows.Forms.Button();
			this.textBoxEquationOriginal = new System.Windows.Forms.TextBox();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.gridEquation = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.textBoxEquation = new System.Windows.Forms.TextBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panelToolbarBottom.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridEquation)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(500, 5);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 94;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(0, 0);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(528, 32);
			this.labelReportTemplateName.TabIndex = 93;
			this.labelReportTemplateName.Text = "Equation Viewer";
			this.labelReportTemplateName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(528, 2);
			this.panelSeparator.TabIndex = 95;
			// 
			// panelToolbarBottom
			// 
			this.panelToolbarBottom.Controls.Add(this.panel1);
			this.panelToolbarBottom.Controls.Add(this.buttonClearSelected);
			this.panelToolbarBottom.Controls.Add(this.buttonClose);
			this.panelToolbarBottom.Controls.Add(this.buttonClearAll);
			this.panelToolbarBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelToolbarBottom.Location = new System.Drawing.Point(0, 222);
			this.panelToolbarBottom.Name = "panelToolbarBottom";
			this.panelToolbarBottom.Size = new System.Drawing.Size(528, 40);
			this.panelToolbarBottom.TabIndex = 102;
			this.panelToolbarBottom.Paint += new System.Windows.Forms.PaintEventHandler(this.panelToolbarBottom_Paint);
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(528, 2);
			this.panel1.TabIndex = 103;
			// 
			// buttonClearSelected
			// 
			this.buttonClearSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonClearSelected.BackColor = System.Drawing.SystemColors.Control;
			this.buttonClearSelected.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearSelected.Location = new System.Drawing.Point(100, 8);
			this.buttonClearSelected.Name = "buttonClearSelected";
			this.buttonClearSelected.Size = new System.Drawing.Size(88, 24);
			this.buttonClearSelected.TabIndex = 102;
			this.buttonClearSelected.Text = "Clear Selected";
			this.buttonClearSelected.Click += new System.EventHandler(this.buttonClearSelected_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.BackColor = System.Drawing.SystemColors.Control;
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(435, 8);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(88, 24);
			this.buttonClose.TabIndex = 101;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// buttonClearAll
			// 
			this.buttonClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonClearAll.BackColor = System.Drawing.SystemColors.Control;
			this.buttonClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearAll.Location = new System.Drawing.Point(5, 8);
			this.buttonClearAll.Name = "buttonClearAll";
			this.buttonClearAll.Size = new System.Drawing.Size(88, 24);
			this.buttonClearAll.TabIndex = 100;
			this.buttonClearAll.Text = "Clear All";
			this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
			// 
			// textBoxEquationOriginal
			// 
			this.textBoxEquationOriginal.AutoSize = false;
			this.textBoxEquationOriginal.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(249)), ((System.Byte)(247)), ((System.Byte)(233)));
			this.textBoxEquationOriginal.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxEquationOriginal.Dock = System.Windows.Forms.DockStyle.Top;
			this.textBoxEquationOriginal.Location = new System.Drawing.Point(0, 34);
			this.textBoxEquationOriginal.Multiline = true;
			this.textBoxEquationOriginal.Name = "textBoxEquationOriginal";
			this.textBoxEquationOriginal.ReadOnly = true;
			this.textBoxEquationOriginal.Size = new System.Drawing.Size(528, 32);
			this.textBoxEquationOriginal.TabIndex = 103;
			this.textBoxEquationOriginal.TabStop = false;
			this.textBoxEquationOriginal.Text = "";
			// 
			// splitter1
			// 
			this.splitter1.BackColor = System.Drawing.SystemColors.Control;
			this.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitter1.Location = new System.Drawing.Point(0, 66);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(528, 6);
			this.splitter1.TabIndex = 109;
			this.splitter1.TabStop = false;
			// 
			// gridEquation
			// 
			this.gridEquation.AllowDelete = true;
			this.gridEquation.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
			this.gridEquation.BackColor = System.Drawing.SystemColors.Window;
			this.gridEquation.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.gridEquation.ColumnInfo = @"4,1,0,0,0,85,Columns:0{Width:20;Visible:False;AllowResizing:False;}	1{Width:100;Caption:""Value"";DataType:System.String;TextAlign:LeftTop;}	2{Width:168;Caption:""Equation"";DataType:System.String;TextAlign:LeftTop;}	3{Width:177;Caption:""Additional Information"";DataType:System.String;TextAlign:LeftTop;}	";
			this.gridEquation.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridEquation.ExtendLastCol = true;
			this.gridEquation.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridEquation.ForeColor = System.Drawing.SystemColors.WindowText;
			this.gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Never;
			this.gridEquation.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.gridEquation.Location = new System.Drawing.Point(0, 72);
			this.gridEquation.Name = "gridEquation";
			this.gridEquation.Rows.Count = 1;
			this.gridEquation.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.RowRange;
			this.gridEquation.Size = new System.Drawing.Size(528, 150);
			this.gridEquation.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Bisque;}	Focus{BackColor:Bisque;Border:None,1,Black,Both;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	NewRow{BackColor:White;}	EmptyArea{BackColor:249, 247, 233;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridEquation.TabIndex = 110;
			// 
			// textBoxEquation
			// 
			this.textBoxEquation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxEquation.AutoSize = false;
			this.textBoxEquation.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(249)), ((System.Byte)(247)), ((System.Byte)(233)));
			this.textBoxEquation.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxEquation.Location = new System.Drawing.Point(5, 34);
			this.textBoxEquation.Multiline = true;
			this.textBoxEquation.Name = "textBoxEquation";
			this.textBoxEquation.Size = new System.Drawing.Size(523, 188);
			this.textBoxEquation.TabIndex = 111;
			this.textBoxEquation.Text = "";
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// EquationViewer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(528, 262);
			this.Controls.Add(this.gridEquation);
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.textBoxEquation);
			this.Controls.Add(this.textBoxEquationOriginal);
			this.Controls.Add(this.panelToolbarBottom);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelReportTemplateName);
			this.helpProvider1.SetHelpKeyword(this, "EquationViewer.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(232, 150);
			this.Name = "EquationViewer";
			this.helpProvider1.SetShowHelp(this, true);
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "EquationViewer";
			this.TopMost = true;
			this.Resize += new System.EventHandler(this.EquationViewer_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.EquationViewer_Paint);
			this.panelToolbarBottom.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.gridEquation)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		protected override void OnLoad(EventArgs e)
		{
			Drive.Configuration.FormState formState = new Drive.Configuration.FormState(
				Drive.Configuration.AppSettings.Settings.GetSetting("ScreenSettings", this.Name));
			formState.RestoreState(this);
			CheckFormProperties();

			SetSplitterPosition(Drive.Configuration.AppSettings.Settings.GetSettingInt("EquationViewerForm", "SplitterPosition", 87));

			gridEquation.Cols[1].Width = (this.Width - gridEquation.Cols[1].Width) * 1 / 4;
			gridEquation.Cols[2].Width = (this.Width - gridEquation.Cols[1].Width) * 2 / 4;

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Never;
			gridEquation.Styles.Focus.BackColor = SystemColors.Window;

			SetBitmaps();

			this.buttonClose.Focus();

			base.OnLoad(e);
		}

		private void SetSplitterPosition(int splitterPos)
		{
			if (splitterPos > this.Height - 150)
				splitter1.SplitPosition = 87;
			else
				splitter1.SplitPosition = splitterPos;
		}

		//mam
		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)pictureBoxHelp.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxHelp.Image = b;
		}
		//</mam>

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/

		private void CheckFormProperties()
		{
			if (this.WindowState == FormWindowState.Minimized 
				|| this.Height < 50 
				|| Math.Abs(this.Left) > 2000 || Math.Abs(this.Top) > 2000)
			{
				this.WindowState = FormWindowState.Normal;
				this.Size = this.MinimumSize;
				this.splitter1.SplitPosition = 87;
				this.Left = 0;
				this.Top = 0;
			}
		}
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "EquationViewer.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "EquationViewer.htm");
		}

		private void EquationViewer_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		protected override void OnClosing(CancelEventArgs e)
		{

			parentForm.viewEquation2 = false;

			try
			{
				// Save form state
				Drive.Configuration.FormState formState = 
					new Drive.Configuration.FormState(this);

				Drive.Configuration.AppSettings.Settings.SetSetting(
					@"ScreenSettings", this.Name, formState.ToString());

				Drive.Configuration.AppSettings.Settings.Save();

				Drive.Configuration.AppSettings.Settings.SetSetting(
					"EquationViewerForm", "SplitterPosition", splitter1.SplitPosition.ToString());
			}
			catch
			{
				System.Diagnostics.Debug.WriteLine("Error.  EquationViewer.OnClosing");
			}

			base.OnClosing(e);
			this.Dispose(true);
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void buttonClearAll_Click(object sender, System.EventArgs e)
		{
			int top = gridEquation.Selection.TopRow;
			int bot = gridEquation.Selection.BottomRow;
			for (int i = gridEquation.Rows.Count - 1; i >= 1; i--)
			{
				gridEquation.Rows.Remove(i);
			}

			if (gridEquation.Rows.Count < 3)
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Never;
				gridEquation.Styles.Focus.BackColor = SystemColors.Window;
			}
			else
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Always;
				gridEquation.Styles.Focus.BackColor = Color.Bisque;
			}
		}

		public void ShowEquation(string eqn)
		{
			//this.textBoxEquation.Text = eqn.ToString();

			string [] eqnSplit = null;
			string delimStr = "~";
			char [] delimiter = delimStr.ToCharArray();

			for (int i = 1; i <= 3; i++) 
			{
				eqnSplit = eqn.Split(delimiter, i);
			}
			if (eqnSplit[0].Length != 0)
				textBoxEquation.Text = eqnSplit[0] + " = " + eqnSplit[1];
			else
				textBoxEquation.Text = "";
		}

		public void PinEquation(string eqn)
		{
			gridEquation.Rows.Add();
			int row = gridEquation.Rows.Count-1;
			string [] eqnSplit = null;
			string delimStr = "~";
			char [] delimiter = delimStr.ToCharArray();

			for (int i = 1; i <= 3; i++) 
			{
				eqnSplit = eqn.Split(delimiter, i);
				//gridAssets.Rows.Add().UserData = asset;
				//gridAssets_AfterSelChange(null, null);
			}

			for (int i = 0; i <= 2; i++)
			{
				gridEquation.SetData(row, i + 1, eqnSplit[i]);
			}

			gridEquation.AutoSizeRows();

			if (gridEquation.Rows.Count < 3)
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Never;
				gridEquation.Styles.Focus.BackColor = SystemColors.Window;
			}
			else
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Always;
				gridEquation.Styles.Focus.BackColor = Color.Bisque;
			}
		}

		public void ClearEquationTextBox()
		{
			this.textBoxEquation.Clear();
		}

		private void buttonClearSelected_Click(object sender, System.EventArgs e)
		{
			int top = gridEquation.Selection.TopRow;
			int bot = gridEquation.Selection.BottomRow;
			
			if (top < 1 || bot < 1)
				return;

			for (int i = bot; i >= top; i--)
			{
				gridEquation.Rows.Remove(i);
			}

			if (gridEquation.Rows.Count < 3)
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Never;
				gridEquation.Styles.Focus.BackColor = SystemColors.Window;
			}
			else
			{
				gridEquation.HighLight = C1.Win.C1FlexGrid.HighLightEnum.Always;
				gridEquation.Styles.Focus.BackColor = Color.Bisque;
			}
		}

		private void EquationViewer_Resize(object sender, System.EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine(splitter1.SplitPosition.ToString());
			System.Diagnostics.Debug.WriteLine(this.Height.ToString());

			if (splitter1.SplitPosition > this.Height - 150)
				splitter1.SplitPosition = this.Height - 100;
		}

		private void gridEquation_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void panelToolbarBottom_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		#endregion /***** Methods *****/
	}
}
