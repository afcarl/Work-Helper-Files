using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportTemplate.
	/// </summary>
	public class ReportTemplateDirty : System.Windows.Forms.Form
	{
		private int autoSaveOption = 1;
		private string formText = "";
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox checkBoxAutomaticSave;
		private System.Windows.Forms.Label labelAutomaticSave;
		private System.Windows.Forms.Label labelMessage;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Button buttonYes;
		private System.Windows.Forms.Button buttonNo;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ReportTemplateDirty()
		{
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportTemplateDirty));
			this.label1 = new System.Windows.Forms.Label();
			this.checkBoxAutomaticSave = new System.Windows.Forms.CheckBox();
			this.labelAutomaticSave = new System.Windows.Forms.Label();
			this.labelMessage = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.buttonYes = new System.Windows.Forms.Button();
			this.buttonNo = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label1.Location = new System.Drawing.Point(10, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(358, 24);
			this.label1.TabIndex = 75;
			this.label1.Text = "Save Changes to Report Template?";
			// 
			// checkBoxAutomaticSave
			// 
			this.checkBoxAutomaticSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.checkBoxAutomaticSave.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxAutomaticSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxAutomaticSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBoxAutomaticSave.Location = new System.Drawing.Point(13, 151);
			this.checkBoxAutomaticSave.Name = "checkBoxAutomaticSave";
			this.checkBoxAutomaticSave.Size = new System.Drawing.Size(12, 13);
			this.checkBoxAutomaticSave.TabIndex = 3;
			this.checkBoxAutomaticSave.TabStop = false;
			this.checkBoxAutomaticSave.CheckedChanged += new System.EventHandler(this.checkBoxAutomaticSave_CheckedChanged);
			// 
			// labelAutomaticSave
			// 
			this.labelAutomaticSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAutomaticSave.BackColor = System.Drawing.Color.Transparent;
			this.labelAutomaticSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAutomaticSave.Location = new System.Drawing.Point(29, 149);
			this.labelAutomaticSave.Name = "labelAutomaticSave";
			this.labelAutomaticSave.Size = new System.Drawing.Size(390, 19);
			this.labelAutomaticSave.TabIndex = 2;
			this.labelAutomaticSave.Text = "&Don\'t ask me - just save the changes automatically.";
			this.labelAutomaticSave.Click += new System.EventHandler(this.labelAutomaticSave_Click);
			// 
			// labelMessage
			// 
			this.labelMessage.BackColor = System.Drawing.Color.Transparent;
			this.labelMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelMessage.Location = new System.Drawing.Point(32, 56);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.Size = new System.Drawing.Size(340, 24);
			this.labelMessage.TabIndex = 78;
			this.labelMessage.Text = "The template data has changed.  Save the changes?";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(347, 10);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 91;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// buttonYes
			// 
			this.buttonYes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonYes.Location = new System.Drawing.Point(117, 83);
			this.buttonYes.Name = "buttonYes";
			this.buttonYes.Size = new System.Drawing.Size(72, 23);
			this.buttonYes.TabIndex = 0;
			this.buttonYes.Text = "&Yes";
			this.buttonYes.Click += new System.EventHandler(this.buttonYes_Click);
			// 
			// buttonNo
			// 
			this.buttonNo.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonNo.Location = new System.Drawing.Point(198, 83);
			this.buttonNo.Name = "buttonNo";
			this.buttonNo.Size = new System.Drawing.Size(72, 23);
			this.buttonNo.TabIndex = 1;
			this.buttonNo.Text = "&No";
			this.buttonNo.Click += new System.EventHandler(this.buttonNo_Click);
			// 
			// ReportTemplateDirty
			// 
			this.AcceptButton = this.buttonYes;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(378, 176);
			this.ControlBox = false;
			this.Controls.Add(this.buttonNo);
			this.Controls.Add(this.buttonYes);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelMessage);
			this.Controls.Add(this.labelAutomaticSave);
			this.Controls.Add(this.checkBoxAutomaticSave);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportTemplateDirty";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ReportTemplate";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		public static bool ShowForm(ref int autoSaveOption, string formText, Form owner)
		{
			ReportTemplateDirty form = new ReportTemplateDirty();
			bool success;

			form.autoSaveOption = autoSaveOption;
			form.formText = formText;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			if (success)
			{
				autoSaveOption = form.autoSaveOption;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			//this.Text = "Save Report Template Changes";
			this.Text = formText;

			if (autoSaveOption == 1)
				this.checkBoxAutomaticSave.Checked = true;
			else
				this.checkBoxAutomaticSave.Checked = false;

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void labelAutomaticSave_Click(object sender, System.EventArgs e)
		{
			checkBoxAutomaticSave.Checked = !checkBoxAutomaticSave.Checked;
		}

		private void buttonYes_Click(object sender, System.EventArgs e)
		{
			if (this.checkBoxAutomaticSave.Checked)
				autoSaveOption = 1;
			else
				autoSaveOption = 0;

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonNo_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "Reports.htm");
		}

		private void checkBoxAutomaticSave_CheckedChanged(object sender, System.EventArgs e)
		{
			if (this.checkBoxAutomaticSave.Checked)
				autoSaveOption = 1;
			else
				autoSaveOption = 0;
		}
	}

}
