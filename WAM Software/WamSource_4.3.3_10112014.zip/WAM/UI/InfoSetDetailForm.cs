using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for InfoSetDetailForm.
	/// </summary>
	public class InfoSetDetailForm : System.Windows.Forms.Form
	{
		private InfoSet		m_infoSet = null;

		//mam
		string disallowedChar = @"\/:;*=?" + (char)34 + @"<>|";
		string existingText = "";
		char[] disallowedChars = new char[11];
		int currentPos = 0;
		//</mam>

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBoxSetName;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxDescription;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public InfoSetDetailForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//mam
			LoadCharArray();
			//</mam>
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(InfoSetDetailForm));
			this.label1 = new System.Windows.Forms.Label();
			this.textBoxSetName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxDescription = new System.Windows.Forms.TextBox();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(8, 10);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(68, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Set &Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxSetName
			// 
			this.textBoxSetName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxSetName.Location = new System.Drawing.Point(76, 8);
			this.textBoxSetName.MaxLength = 255;
			this.textBoxSetName.Name = "textBoxSetName";
			this.textBoxSetName.Size = new System.Drawing.Size(312, 20);
			this.textBoxSetName.TabIndex = 1;
			this.textBoxSetName.Text = "";
			this.textBoxSetName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSetName_KeyPress);
			this.textBoxSetName.TextChanged += new System.EventHandler(this.textBoxSetName_TextChanged);
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(8, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(68, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "&Description:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxDescription
			// 
			this.textBoxDescription.AcceptsReturn = true;
			this.textBoxDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxDescription.Location = new System.Drawing.Point(76, 32);
			this.textBoxDescription.Multiline = true;
			this.textBoxDescription.Name = "textBoxDescription";
			this.textBoxDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxDescription.Size = new System.Drawing.Size(312, 168);
			this.textBoxDescription.TabIndex = 3;
			this.textBoxDescription.Text = "";
			// 
			// buttonSave
			// 
			this.buttonSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(228, 208);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 4;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(311, 208);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 4;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// InfoSetDetailForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(394, 240);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.textBoxDescription);
			this.Controls.Add(this.textBoxSetName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(400, 272);
			this.Name = "InfoSetDetailForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Information Set";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.InfoSetDetailForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.InfoSetDetailForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(int infoSetID, Form owner)
		{
			InfoSetDetailForm	form = new InfoSetDetailForm();

			form.m_infoSet = new InfoSet(infoSetID);
			return (form.ShowDialog(owner) == DialogResult.OK);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			textBoxSetName.Text = m_infoSet.Name;
			textBoxDescription.Text = m_infoSet.Description;

			base.OnLoad(e);
		}

		private void textBoxSetName_TextChanged(object sender, System.EventArgs e)
		{
			//mam
			bool changedText = false;
			string currentText = textBoxSetName.Text;
			string correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (disallowedChar.IndexOf(currentText.Substring(i, 1)) > -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				textBoxSetName.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxSetName.SelectionStart = currentPos;
			}
			//</mam>

			if (textBoxSetName.Text.Length == 0)
				this.Text = "Information Set";
			else
				this.Text = string.Format("InfoSet: {0}", textBoxSetName.Text);
		}

		private void textBoxSetName_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxSetName.SelectionStart;
			existingText = textBoxSetName.Text;

			if (disallowedChar.IndexOf(e.KeyChar) > -1)
			{
				e.Handled = true;
			}
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			m_infoSet.Name = textBoxSetName.Text;
			m_infoSet.Description = textBoxDescription.Text;

			if (m_infoSet.Name.Trim().Length == 0)
			{
				MessageBox.Show(this, "Please enter a name for the Information Set.", "Information Set",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

				//mam
				textBoxSetName.Focus();
				//</mam>

				return;
			}


			//mam - don't allow duplicate infoset names (because there cannot be two image folders
			//	with the same name
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			//mam 102309
			//string connectionString = WAMSource.SelectedDBConnectionString(m_infoSet.DatabasePath);
			string connectionString = WAMSource.SelectedDBConnectionString();

			System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTable(
				"SELECT infoset_name FROM InfoSets WHERE infoset_name = '" + m_infoSet.Name + "' AND infoset_id <> " + m_infoSet.ID);
			if (dataTable != null)
			{
				if (dataTable.Rows.Count > 0)
				{
					//there is an existing infoset with the same name
					MessageBox.Show(this, "An Information Set already exists with this name.  Please enter another name.", 
						"Information Set", System.Windows.Forms.MessageBoxButtons.OK, 
						System.Windows.Forms.MessageBoxIcon.Exclamation);
					textBoxSetName.Focus();
					return;
				}
			}
			//</mam>

			if (!m_infoSet.Save())
			{
				MessageBox.Show(this, "Error saving Information Set.", "Error",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
				return;
			}

			//mam 050806 - update the infoset name in the cache (after changing an infoset name, the change does
			//	not show up in the grid legend)
			CacheManager.SetInfosetNameForInfoSetID(m_infoSet.ID, m_infoSet.Name);

			this.DialogResult = DialogResult.OK;

			//mam 102309
			CreateImagesFolder(m_infoSet.Name);

			this.Close();
		}

		//mam 102309
		private string CreateImagesFolder(string assetName)
		{
			string curPath = WAM.Common.Globals.WamPhotoPath;
			string imagePathCopyTo = curPath + "\\" + assetName;

			try
			{
				System.IO.Directory.CreateDirectory(imagePathCopyTo);
			}
			catch
			{
				imagePathCopyTo = "";
			}

			return imagePathCopyTo;
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void InfoSetDetailForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void LoadCharArray()
		{
			//the following characters are not allowed in file names:
			disallowedChars[0] = '\'';
			disallowedChars[1] = '/';
			disallowedChars[2] = ':';
			disallowedChars[3] = ';';
			disallowedChars[4] = '*';
			disallowedChars[5] = '=';
			disallowedChars[6] = '?';
			disallowedChars[7] = '"';
			disallowedChars[8] = '<';
			disallowedChars[9] = '>';
			disallowedChars[10] = '|';
		}

		private void InfoSetDetailForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}
