using System;
using System.Windows.Forms;
using System.Text;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for EquationViewerHandler.
	/// </summary>
	/// 
	
	public class EquationViewerHandler
	{
		#region /***** Member Variables *****/

		private Form parentForm = null;
		private Control parentControl = null;
		private string parentFormName = "";
		private object colTag = null;

		#endregion /***** Member Variables *****/
	
		#region /***** Construction *****/

		public EquationViewerHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#endregion /***** Construction *****/

		#region /***** Assign Mouse Handler *****/

		public void AssignMouseHandler(Form curForm)
		{
			parentForm = curForm;
			parentFormName = parentForm.Name;

			foreach (Control formControl in curForm.Controls)
			{
				if (formControl is TextBox)
				{
					if (formControl.Tag != null)
					{
						((TextBox)formControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
						((TextBox)formControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
						((TextBox)formControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

						if (MainForm.viewEquation)
						{
							((TextBox)formControl).MouseDown += new MouseEventHandler(MouseDownHandler);
							((TextBox)formControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
							((TextBox)formControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
						}
					}
				}
				else if (formControl is GroupBox)
				{
					foreach (Control groupBoxControl in formControl.Controls)
					{
						if (groupBoxControl is TextBox)
						{
							if (groupBoxControl.Tag != null)
							{
								((TextBox)groupBoxControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
								((TextBox)groupBoxControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
								((TextBox)groupBoxControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

								if (MainForm.viewEquation)
								{
									((TextBox)groupBoxControl).MouseDown += new MouseEventHandler(MouseDownHandler);
									((TextBox)groupBoxControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
									((TextBox)groupBoxControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
								}
							}
						}
					}
				}
			}
		}

		public void AssignMouseHandler(Control curControl)
		{
			parentControl = curControl;
			parentFormName = curControl.Name;
			switch (curControl.Name)
			{
				case "disciplineLandControl1":
					parentControl = (WAM.UI.MainViews.DisciplineLandControl)curControl;
					break;
				case "disciplineMechControl1":
					parentControl = (WAM.UI.MainViews.DisciplineMechControl)curControl;
					break;
				case "disciplineStructControl1":
					parentControl = (WAM.UI.MainViews.DisciplineStructControl)curControl;
					break;
			}

			foreach (Control formControl in curControl.Controls)
			{
				//mam 01222012 - added this for Fac Crit
				if (formControl is NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)
				{
					if (formControl.Tag != null && formControl.Tag.ToString() != "")
					{
						((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
						((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
						((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

						if (MainForm.viewEquation)
						{
							((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseDown += new MouseEventHandler(MouseDownHandler);
							((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
							((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
						}
					}
				}

				else if (formControl is TabControl)
				{
					//look at first two tabs
					for (int i = 0; i <= 1; i++)
					{
						foreach (Control tabPageControl in ((TabControl)formControl).TabPages[i].Controls)
						{
							if (tabPageControl is WAM.UI.DollarTextBox)
							{
								//mam 07072011 - added check for empty string
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((WAM.UI.DollarTextBox)tabPageControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
									((WAM.UI.DollarTextBox)tabPageControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
									((WAM.UI.DollarTextBox)tabPageControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

									if (MainForm.viewEquation)
									{
										((WAM.UI.DollarTextBox)tabPageControl).MouseDown += new MouseEventHandler(MouseDownHandler);
										((WAM.UI.DollarTextBox)tabPageControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
										((WAM.UI.DollarTextBox)tabPageControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
									}
								}
							}

							//mam 07072011
							else if (tabPageControl is WAM.UI.NumberTextBox)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((WAM.UI.NumberTextBox)tabPageControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
									((WAM.UI.NumberTextBox)tabPageControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
									((WAM.UI.NumberTextBox)tabPageControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

									if (MainForm.viewEquation)
									{
										((WAM.UI.NumberTextBox)tabPageControl).MouseDown += new MouseEventHandler(MouseDownHandler);
										((WAM.UI.NumberTextBox)tabPageControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
										((WAM.UI.NumberTextBox)tabPageControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
									}
								}
							}
							else if (tabPageControl is NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
									((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
									((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

									if (MainForm.viewEquation)
									{
										((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseDown += new MouseEventHandler(MouseDownHandler);
										((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
										((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
									}
								}
							}
							//</mam>

							//mam 01222012
							else if (tabPageControl is NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
									((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
									((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

									if (MainForm.viewEquation)
									{
										((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseDown += new MouseEventHandler(MouseDownHandler);
										((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
										((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
									}
								}
							}

							else if (tabPageControl is TextBox)
							{
								if (tabPageControl.Tag != null)
								{
									((TextBox)tabPageControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
									((TextBox)tabPageControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
									((TextBox)tabPageControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

									if (MainForm.viewEquation)
									{
										((TextBox)tabPageControl).MouseDown += new MouseEventHandler(MouseDownHandler);
										((TextBox)tabPageControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
										((TextBox)tabPageControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
									}
								}
							}
							//included GroupBox for MajorComponentControl groupBox1 textBoxRisk
							else if (tabPageControl is GroupBox)
							{
								foreach (Control groupBoxControl in ((GroupBox)tabPageControl).Controls)
								{
									if (groupBoxControl is TextBox)
									{
										if (groupBoxControl.Tag != null)
										{
											((TextBox)groupBoxControl).MouseDown -= new MouseEventHandler(MouseDownHandler);
											((TextBox)groupBoxControl).MouseEnter -= new System.EventHandler(MouseEnterHandler);
											((TextBox)groupBoxControl).MouseLeave -= new System.EventHandler(MouseLeaveHandler);

											if (MainForm.viewEquation)
											{
												((TextBox)groupBoxControl).MouseDown += new MouseEventHandler(MouseDownHandler);
												((TextBox)groupBoxControl).MouseEnter += new System.EventHandler(MouseEnterHandler);
												((TextBox)groupBoxControl).MouseLeave += new System.EventHandler(MouseLeaveHandler);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		public void AssignMouseHandlerGrid(C1.Win.C1FlexGrid.C1FlexGrid curGridControl, System.Collections.ArrayList colArray)
		{
			parentFormName = curGridControl.Parent.Name;
			parentControl = curGridControl.Parent;
			((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).Click -= new System.EventHandler(GridClickHandler);
			((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).MouseLeave -= new System.EventHandler(GridMouseLeaveHandler);

			((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).MouseMove -= new System.Windows.Forms.MouseEventHandler(GridMouseMoveHandler);
			
			if (MainForm.viewEquation)
			{
				((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).Click += new System.EventHandler(GridClickHandler);
				//((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).MouseEnter += new System.EventHandler(GridMouseEnterHandler);
				((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).MouseLeave += new System.EventHandler(GridMouseLeaveHandler);

				((C1.Win.C1FlexGrid.C1FlexGrid)curGridControl).MouseMove += new System.Windows.Forms.MouseEventHandler(GridMouseMoveHandler);

				colTag = colArray;
			}
		}

		#endregion /***** Assign Mouse Handler *****/

		#region /***** Assign Cursor *****/

		public void AssignCursor(Form curForm)
		{
			//assign cursor to textboxes that have equations

			Cursor cursor = System.Windows.Forms.Cursors.IBeam;
			if (MainForm.viewEquation)
				cursor = System.Windows.Forms.Cursors.Help;
			else
				cursor = System.Windows.Forms.Cursors.IBeam;

			foreach (Control formControl in curForm.Controls)
			{
				if (formControl is TextBox)
				{
					if (formControl.Tag != null)
					{
						((TextBox)formControl).Cursor = cursor;
					}
				}
				else if (formControl is GroupBox)
				{
					foreach (Control groupBoxControl in formControl.Controls)
					{
						if (groupBoxControl is TextBox)
						{
							if (groupBoxControl.Tag != null)
								((TextBox)groupBoxControl).Cursor = cursor;
						}
					}
				}
			}
		}

		public void AssignCursor(Control curControl)
		{
			//assign cursor to textboxes that have equations

			parentFormName = curControl.Name;
			switch (curControl.Name)
			{
				case "disciplineLandControl1":
					parentControl = (WAM.UI.MainViews.DisciplineLandControl)curControl;
					break;
				case "disciplineMechControl1":
					parentControl = (WAM.UI.MainViews.DisciplineMechControl)curControl;
					break;
				case "disciplineStructControl1":
					parentControl = (WAM.UI.MainViews.DisciplineStructControl)curControl;
					break;
			}

			Cursor cursor = System.Windows.Forms.Cursors.IBeam;
			if (MainForm.viewEquation)
				cursor = System.Windows.Forms.Cursors.Help;
			else
				cursor = System.Windows.Forms.Cursors.IBeam;

			foreach (Control formControl in curControl.Controls)
			{
				//mam 01222012 - added this for Fac Crit
				if (formControl is NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)
				{
					if (formControl.Tag != null && formControl.Tag.ToString() != "")
					{
						((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)formControl).Cursor = cursor;
					}
				}

				else if (formControl is TabControl)
				{
					//look at first two tabs
					for (int i = 0; i <= 1; i++)
					{
						foreach (Control tabPageControl in ((TabControl)formControl).TabPages[i].Controls)
						{
							if (tabPageControl is WAM.UI.DollarTextBox)
							{
								//mam 07072011 - added check for empty string
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((WAM.UI.DollarTextBox)tabPageControl).Cursor = cursor;
								}
							}

							//mam 07072011
							else if (tabPageControl is WAM.UI.NumberTextBox)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((WAM.UI.NumberTextBox)tabPageControl).Cursor = cursor;
								}
							}
							else if (tabPageControl is NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((NumericTextBoxOneDecimal.NumericTextBoxOneDecimal)tabPageControl).Cursor = cursor;
								}
							}
							//</mam>

							//mam 01222012
							else if (tabPageControl is NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)
							{
								if (tabPageControl.Tag != null && tabPageControl.Tag.ToString() != "")
								{
									((NumericTextBoxTwoDecimals.NumericTextBoxTwoDecimals)tabPageControl).Cursor = cursor;
								}
							}

							else if (tabPageControl is TextBox)
							{
								if (tabPageControl.Tag != null)
								{
									((TextBox)tabPageControl).Cursor = cursor;
								}
							}
							//included GroupBox for MajorComponentControl groupBox1 textBoxRisk
							else if (tabPageControl is GroupBox)
							{
								foreach (Control groupBoxControl in ((GroupBox)tabPageControl).Controls)
								{
									if (groupBoxControl is TextBox)
									{
										if (groupBoxControl.Tag != null)
										{
											((TextBox)groupBoxControl).Cursor = cursor;
										}
									}
								}
							}
						}
					}
				}
			}
		}

		#endregion /***** Assign Cursor *****/

		#region /***** Mouse Event Handler *****/

		private void MouseDownHandler(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			string equationString = "";

			if (sender is TextBox)
				equationString = PinEquation(((TextBox)sender).Tag.ToString());

			DisplayEquation(equationString, "pin");
		}

		private void MouseEnterHandler(object sender, System.EventArgs e)
		{
			string equationString = "";

			if (sender is TextBox)
				equationString = PinEquation(((TextBox)sender).Tag.ToString());

			DisplayEquation(equationString, "show");
		}

		private void MouseLeaveHandler(object sender, System.EventArgs e)
		{
			DisplayEquation("", "clear");
		}


		private void GridMouseMoveHandler(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			((C1.Win.C1FlexGrid.C1FlexGrid)sender).Cursor = System.Windows.Forms.Cursors.Default;

			int curMouseRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseRow;
			int curMouseCol = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseCol;
			int fixedRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).Rows.Fixed;

			if (curMouseRow < 0 || curMouseCol < 0 || fixedRow < 0)
				return;

			if (curMouseRow < fixedRow)
			{
				if (((System.Collections.ArrayList)colTag)[curMouseCol].ToString() != "")
				{
					((C1.Win.C1FlexGrid.C1FlexGrid)sender).Cursor = System.Windows.Forms.Cursors.Help;
				}
				string equationString = PinEquation(((System.Collections.ArrayList)colTag)[curMouseCol].ToString());
				DisplayEquation(equationString, "show");
			}
		}

		private void GridMouseEnterHandler(object sender, System.EventArgs e)
		{
//			Cursor cursor = System.Windows.Forms.Cursors.Default;
//
//			//if (MainForm.viewEquation)
//			//{
//				int curMouseRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseRow;
//				int curMouseCol = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseCol;
//				int fixedRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).Rows.Fixed;
//
//				if (curMouseRow < fixedRow)
//				{
//					((C1.Win.C1FlexGrid.C1FlexGrid)sender).Cursor = System.Windows.Forms.Cursors.Help;
//					string equationString = PinEquation(((System.Collections.ArrayList)colTag)[curMouseCol].ToString());
//					DisplayEquation(equationString, "show");
//				}
//			//}
		}

		private void GridMouseLeaveHandler(object sender, System.EventArgs e)
		{
			((C1.Win.C1FlexGrid.C1FlexGrid)sender).Cursor = System.Windows.Forms.Cursors.Default;
			DisplayEquation("", "clear");
		}

		private void GridClickHandler(object sender, System.EventArgs e)
		{
			int curMouseRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseRow;
			int curMouseCol = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).MouseCol;
			int fixedRow = ((C1.Win.C1FlexGrid.C1FlexGrid)sender).Rows.Fixed;

			if (curMouseRow < 0 || curMouseCol < 0 || fixedRow < 0)
				return;

			if (curMouseRow < fixedRow && ((System.Collections.ArrayList)colTag)[curMouseCol].ToString() != "")
			{
				string equationString = PinEquation(((System.Collections.ArrayList)colTag)[curMouseCol].ToString());
				DisplayEquation(equationString, "pin");
			}
		}

		#endregion /***** Mouse Event Handler *****/

		#region /***** Display Equation *****/

		private void DisplayEquation(string equationString, string displayType)
		{
			switch (parentFormName)
			{
				//mam 01222012
				case "facilityControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.FacilityControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.FacilityControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.FacilityControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
				break;

				case "disciplineNodesControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.DisciplineNodesControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.DisciplineNodesControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.DisciplineNodesControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "NodeAppurtenanceDetailForm":
				{
					switch (displayType)
					{
						case "pin":
							((NodeAppurtenanceDetailForm)parentForm).PinEquation(equationString);
							break;
						case "show":
							((NodeAppurtenanceDetailForm)parentForm).ShowEquation(equationString);
							break;
						case "clear":
							((NodeAppurtenanceDetailForm)parentForm).ClearEquationTextBox();
							break;
					}
				}
					break;
				

				case "disciplinePipeControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.DisciplinePipeControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.DisciplinePipeControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.DisciplinePipeControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "PipeDetailForm":
				{
					switch (displayType)
					{
						case "pin":
							((PipeDetailForm)parentForm).PinEquation(equationString);
							break;
						case "show":
							((PipeDetailForm)parentForm).ShowEquation(equationString);
							break;
						case "clear":
							((PipeDetailForm)parentForm).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "disciplineLandControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.DisciplineLandControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.DisciplineLandControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.DisciplineLandControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "disciplineMechControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.DisciplineMechControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.DisciplineMechControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.DisciplineMechControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "disciplineStructControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.DisciplineStructControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.DisciplineStructControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.DisciplineStructControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "treatmentProcessGrid1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.TreatmentProcessGrid)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.TreatmentProcessGrid)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.TreatmentProcessGrid)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "componentGrid1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.Grids.ComponentGrid)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.Grids.ComponentGrid)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.Grids.ComponentGrid)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "majorComponentControl1":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.MainViews.MajorComponentControl)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.MainViews.MajorComponentControl)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.MainViews.MajorComponentControl)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "gridAssessment":
				{
					if (parentControl is WAM.UI.Grids.ComponentAssessmentGrid)
					{
						switch (displayType)
						{
							case "pin":
								((WAM.UI.Grids.ComponentAssessmentGrid)parentControl).PinEquation(equationString);
								break;
							case "show":
								((WAM.UI.Grids.ComponentAssessmentGrid)parentControl).ShowEquation(equationString);
								break;
							case "clear":
								((WAM.UI.Grids.ComponentAssessmentGrid)parentControl).ClearEquationTextBox();
								break;
						}
					}
					else if (parentControl is WAM.UI.Grids.DisciplineAssessmentGrid)
					{
						switch (displayType)
						{
							case "pin":
								((WAM.UI.Grids.DisciplineAssessmentGrid)parentControl).PinEquation(equationString);
								break;
							case "show":
								((WAM.UI.Grids.DisciplineAssessmentGrid)parentControl).ShowEquation(equationString);
								break;
							case "clear":
								((WAM.UI.Grids.DisciplineAssessmentGrid)parentControl).ClearEquationTextBox();
								break;
						}
					}
				}
					break;

				case "pipeGrid":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.Grids.PipeGrid)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.Grids.PipeGrid)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.Grids.PipeGrid)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				case "nodeAppurtenanceGrid":
				{
					switch (displayType)
					{
						case "pin":
							((WAM.UI.Grids.NodeAppurtenanceGrid)parentControl).PinEquation(equationString);
							break;
						case "show":
							((WAM.UI.Grids.NodeAppurtenanceGrid)parentControl).ShowEquation(equationString);
							break;
						case "clear":
							((WAM.UI.Grids.NodeAppurtenanceGrid)parentControl).ClearEquationTextBox();
							break;
					}
				}
					break;

				default:
					break;
			}
		}

		#endregion /***** Display Equation *****/

		#region /***** Equations *****/

		//public string PinEquation(object sender)
		public string PinEquation(string curTag)
		{
			string equationString = "";
			StringBuilder builder = new StringBuilder();

			switch (curTag)
			{
				//mam 01222012 - new field
				case "FACCRIT":
					//facility crit weighting factor
					builder.Append("Facility Criticality Weighting Factor~");

					builder.Append("User-entered value from 0.10 to 1.00 in increments of 0.01.");
					builder.Append("\r\n\r\nThe Facility Criticality Weighting Factor reflects the relative importance of a particular");
					builder.Append(" facility (or service provided by that facility) among the other facilities (or services provided) in the system.");
					builder.Append("~");
					break;

				//add new col ECUL for Economic UL
				case "ECUL":
					//economic remaining useful life
					builder.Append("Economic Remaining Useful Life~");
					builder.Append("(Original Useful Life / 2) - (Original Useful Life * Condition Fraction)");
					builder.Append("\r\n\r\nIf Condition = N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "ECULMSL":
					//economic remaining useful life on the component assessment tab for MSL disciplines
					builder.Append("Economic Remaining Useful Life~");
					builder.Append("(Original Useful Life / 2) - (Original Useful Life * Condition Fraction)");
					builder.Append("\r\n\r\nTotal Economic Remaining Useful Life = Sum of Economic Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Economic Remaining Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Total Economic Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "ECULPN":
					//economic remaining useful life on the component assessment tab for pipes and nodes
					builder.Append("Economic Remaining Useful Life~");
					builder.Append("Sum of Economic Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Economic Remaining Useful Life");
					builder.Append("\r\n   where Economic Remaining Useful Life = (Original Useful Life / 2) - (Original Useful Life * Condition Fraction)");
					builder.Append("\r\n\r\nIf Condition = N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "AECUL":
					//avg economic remaining useful life
					//equationString = "AECUL";
					builder.Append("Average Economic Remaining Useful Life~");
					builder.Append("Sum of Economic Remaining Useful Life weighted by Current Value:");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Economic Remaining Useful Life");
					builder.Append("\r\n   where Economic Remaining Useful Life = (Original Useful Life / 2) - (Original Useful Life * Condition Fraction)");
					builder.Append("\r\n\r\nIf Average Condition = N/A, then Average Economic Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Average Economic Remaining Useful Life = N/A");
					builder.Append("~\r\nCondition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "RECUL":
					//rolled-up economic remaining useful life
					builder.Append("Economic Remaining Useful Life~");
					builder.Append("Sum of Economic Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Economic Remaining Useful Life");
					builder.Append("\r\n   where Economic Remaining Useful Life = (Original Useful Life / 2) - (Original Useful Life * Condition Fraction)");
					builder.Append("\r\n\r\nIf Condition = N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Economic Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "ERUL":
					//evaluated remaining useful life
					//equationString = "ERUL";
					builder.Append("Evaluated Remaining Useful Life~");
					builder.Append("(1 - Condition Fraction) * Original Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "ERULMSL":
					//evaluated remaining useful life on the component assessment tab for MSL disciplines
					builder.Append("Evaluated Remaining Useful Life~");
					builder.Append("(1 - Condition Fraction) * Original Useful Life");
					builder.Append("\r\n\r\nTotal Evaluated Remaining Useful Life = Sum of Evaluated Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Evaluated Remaining Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Total Evaluated Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "ERULPN":
					//evaluated remaining useful life
					//equationString = "ERUL";
					builder.Append("Evaluated Remaining Useful Life~");
					builder.Append("Sum of Evaluated Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Evaluated Remaining Useful Life");
					builder.Append("\r\n   where Evaluated Remaining Useful Life = (1 - Condition Fraction) * Original Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "AERUL":
					//avg evaluated remaining useful life
					//equationString = "AERUL";
					builder.Append("Average Evaluated Remaining Useful Life~");
					builder.Append("Sum of Evaluated Remaining Useful Life weighted by Current Value:");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Evaluated Remaining Useful Life");
					builder.Append("\r\n   where Evaluated Remaining Useful Life = (1 - Condition Fraction) * Original Useful Life");
					builder.Append("\r\n\r\nIf Average Condition = N/A, then Average Evaluated Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Average Evaluated Remaining Useful Life = N/A");
					builder.Append("~\r\nCondition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "RERUL":
					//rolled-up evaluated remaining useful life
					builder.Append("Evaluated Remaining Useful Life~");
					builder.Append("Sum of Evaluated Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Evaluated Remaining Useful Life");
					builder.Append("\r\n   where Evaluated Remaining Useful Life = (1 - Condition Fraction) * Original Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Evaluated Remaining Useful Life = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");

					//mam 051708 - change to condition values that pertain to useful life values
					//builder.Append("\r\nCondition 2: 0.047");
					//builder.Append("\r\nCondition 3: 0.153");
					//builder.Append("\r\nCondition 4: 0.304");
					//builder.Append("\r\nCondition 5: 0.496");
					builder.Append("\r\nCondition 2: 0.10");
					builder.Append("\r\nCondition 3: 0.20");
					builder.Append("\r\nCondition 4: 0.40");
					builder.Append("\r\nCondition 5: 0.90");
					break;

				case "OCRIT":
					//overall criticality
					//equationString = "OCRIT";R
					builder.Append("Overall Criticality~");

					//mam 07072011
					//builder.Append("The sum of four Criticality values");
					builder.Append("The weighted sum of the Criticality values");
					builder.Append("\r\n      (sum of (Criticality value x Criticality weight))");

					//mam 01222012
					builder.Append("\r\nmultiplied by the Facility Criticality Weighting Factor");

					builder.Append("\r\nmultiplied by the Redundancy Factor");
					builder.Append("\r\n      (based on the Number of Assets with Similar Functionality)");
					builder.Append("~No. of\t  Redundancy");
					builder.Append("\r\nAssets\t      Factor");
					builder.Append("\r\n    2\t        95%");
					builder.Append("\r\n    3\t        92%");
					builder.Append("\r\n    4\t        88%");
					builder.Append("\r\n    5\t        85%");
					builder.Append("\r\n  6-10\t        80%"); 
					builder.Append("\r\n11-15\t        70%");
					builder.Append("\r\n16-20\t        60%");
					builder.Append("\r\n  >20\t        50%");
					break;

				case "ACRIT":
					//avg criticality
					//equationString = "ACRIT";
					builder.Append("Average Criticality~");
					builder.Append("Sum of Overall Criticality weighted by Current Value:");
					builder.Append("\r\n\r\n= Sum of (Current Value / Total Current Value) * Overall Criticality");

					//mam 07072011
					//builder.Append("\r\n   where Overall Criticality = the sum of four Criticality values");
					builder.Append("\r\n      where Overall Criticality = the weighted sum of the Criticality values");
					builder.Append("\r\n      (sum of (Criticality value x Criticality weight))");

					//mam 01222012
					builder.Append("\r\n\r\nmultiplied by the Facility Criticality Weighting Factor");

					builder.Append("\r\n\r\nmultiplied by the Redundancy Factor");
					builder.Append("\r\n      (based on the Number of Assets with Similar Functionality)");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Criticality = N/A");
					builder.Append("~No. of\t  Redundancy");
					builder.Append("\r\nAssets\t      Factor");
					builder.Append("\r\n    2\t        95%");
					builder.Append("\r\n    3\t        92%");
					builder.Append("\r\n    4\t        88%");
					builder.Append("\r\n    5\t        85%");
					builder.Append("\r\n  6-10\t        80%"); 
					builder.Append("\r\n11-15\t        70%");
					builder.Append("\r\n16-20\t        60%");
					builder.Append("\r\n  >20\t        50%");
					break;

				case "VULN":
					//vulnerability
					builder.Append("Vulnerability~");
					builder.Append("If 0 < Evaluated Remaining Useful Life <= 1 then Vuln = 0.9");
					builder.Append("\r\nIf 1 < Evaluated Remaining Useful Life <= 2 then Vuln = 0.7");
					builder.Append("\r\nIf 2 < Evaluated Remaining Useful Life <= 3 then Vuln = 0.4");
					builder.Append("\r\nIf 3 < Evaluated Remaining Useful Life <= 5 then Vuln = 0.2");
					builder.Append("\r\nIf Evaluated Remaining Useful Life > 5 then Vuln = 1/Evaluated Remaining Useful Life");
					builder.Append("\r\n\r\nIf Condition = N/A, then Vulnerability = N/A, unless Vulnerability is overridden");
					builder.Append("~Vulnerability depends on Evaluated Remaining Useful Life value, or can be user-entered");
					break;

				case "VULNPN":
					//rolled-up vulnerability
					builder.Append("Vulnerability~");
					builder.Append("Sum of Vulnerability weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Vulnerability");
					builder.Append("\r\n\r\nIf Condition = N/A, then Vulnerability = N/A, unless Vulnerability is overridden");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Vulnerability = N/A");
					builder.Append("~If 0 < Evaluated Remaining Useful Life <= 1 then Vuln = 0.9");
					builder.Append("\r\nIf 1 < Evaluated Remaining Useful Life <= 2 then Vuln = 0.7");
					builder.Append("\r\nIf 2 < Evaluated Remaining Useful Life <= 3 then Vuln = 0.4");
					builder.Append("\r\nIf 3 < Evaluated Remaining Useful Life <= 5 then Vuln = 0.2");
					builder.Append("\r\nIf Evaluated Remaining Useful Life > 5 then Vuln = 1/Evaluated Remaining Useful Life");
					builder.Append("\r\n\r\nVulnerability depends on Evaluated Remaining Useful Life value, or can be user-entered");
					break;

				case "AVULN":
					//avg vulnerability
					//equationString = "AVULN";
					builder.Append("Average Vulnerability~");
					builder.Append("Sum of Vulnerability weighted by Current Value:");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Vulnerability");
					builder.Append("\r\n\r\nIf Average Condition = N/A, then Average Vulnerability = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Average Vulnerability = N/A");
					builder.Append("~If 0 < Evaluated Remaining Useful Life <= 1 then Vuln = 0.9");
					builder.Append("\r\nIf 1 < Evaluated Remaining Useful Life <= 2 then Vuln = 0.7");
					builder.Append("\r\nIf 2 < Evaluated Remaining Useful Life <= 3 then Vuln = 0.4");
					builder.Append("\r\nIf 3 < Evaluated Remaining Useful Life <= 5 then Vuln = 0.2");
					builder.Append("\r\nIf Evaluated Remaining Useful Life > 5 then Vuln = 1/Evaluated Remaining Useful Life");
					builder.Append("\r\n\r\nVulnerability depends on Evaluated Remaining Useful Life value, or can be user-entered");
					break;

				case "RISK":
					//risk
					//equationString = "Overall Criticality * Vulnerability";
					builder.Append("Risk~");
					builder.Append("Overall Criticality * Vulnerability");
					builder.Append("\r\n\r\nIf Condition = N/A, then Risk = N/A");
					builder.Append("~");
					break;

				case "RISKPN":
					//risk
					builder.Append("Risk~");
					builder.Append("Sum of Risk weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Risk");
					builder.Append("\r\n   where Risk = Overall Criticality * Vulnerability");
					builder.Append("\r\n\r\nIf Condition = N/A, then Risk = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Risk = N/A");
					builder.Append("~If 0 < Evaluated Remaining Useful Life <= 1 then Vuln = 0.9");
					builder.Append("\r\nIf 1 < Evaluated Remaining Useful Life <= 2 then Vuln = 0.7");
					builder.Append("\r\nIf 2 < Evaluated Remaining Useful Life <= 3 then Vuln = 0.4");
					builder.Append("\r\nIf 3 < Evaluated Remaining Useful Life <= 5 then Vuln = 0.2");
					builder.Append("\r\nIf Evaluated Remaining Useful Life > 5 then Vuln = 1/Evaluated Remaining Useful Life");
					break;

				case "ARISK":
					//avg risk
					//equationString = "ARISK";
					builder.Append("Average Risk~");
					builder.Append("Sum of Risk weighted by Current Value:");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Risk");
					builder.Append("\r\n   where Risk = Overall Criticality * Vulnerability");
					builder.Append("\r\n\r\nIf Average Condition = N/A, then Average Risk = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Average Risk = N/A");
					builder.Append("~");
					break;

				case "AC":
					//acquisition cost
					//equationString = "AC";
					builder.Append("Acquisition Cost~");

					//builder.Append("When Current Value is overridden: Acquisition Cost = Current Value * Original ENR / Current ENR");
					//builder.Append("\r\nWhen Current Value is NOT overridden: Acquisition Cost = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Original ENR / Current ENR");

					//mam 050806
					builder.Append("Replacement Value * Original ENR / Replacement Value Year ENR");
					builder.Append("\r\n\r\nIf ENR for Replacement Year = 0, then Acquisition Cost = 0");

					builder.Append("~");
					break;

				case "TAC":
					//total acq cost
					//equationString = "TAC";
					builder.Append("Total Acquisition Cost~");
					builder.Append("Sum of Acquisition Costs");

					//builder.Append("\r\nWhen Current Value is overridden: Acquisition Cost = Current Value * Original ENR / Current ENR");
					//builder.Append("\r\nWhen Current Value is NOT overridden: Acquisition Cost = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Original ENR / Current ENR");

					//mam 050806
					builder.Append("\r\nAcquisition Cost = Replacement Value * Original ENR / Replacement Value Year ENR");
					builder.Append("\r\n\r\nIf ENR for Replacement Year = 0, then Acquisition Cost = 0");

					builder.Append("~");
					break;

				case "RAC":
					//rolled-up acq cost
					//equationString = "TAC";
					builder.Append("Acquisition Cost~");
					builder.Append("Sum of Acquisition Costs");

					//builder.Append("\r\nWhen Current Value is overridden: Acquisition Cost = Current Value * Original ENR / Current ENR");
					//builder.Append("\r\nWhen Current Value is NOT overridden: Acquisition Cost = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Original ENR / Current ENR");

					//mam 050806
					builder.Append("\r\nAcquisition Cost = Replacement Value * Original ENR / Replacement Value Year ENR");
					builder.Append("\r\n\r\nIf ENR for Replacement Year = 0, then Acquisition Cost = 0");

					builder.Append("~");
					break;

				case "PAC":
					//pipe acq cost
					//equationString = "TAC";
					builder.Append("Acquisition Cost~");

					//builder.Append("Current Value * Original ENR / Current ENR");
					//builder.Append("\r\nIf ENR for Installation Year = 0, then Acquisition Cost = 0");

					//mam 050806
					builder.Append("Replacement Value * Original ENR / Replacement Value Year ENR");
					builder.Append("\r\n\r\nIf ENR for Replacement Year = 0, then Acquisition Cost = 0");

					builder.Append("~");
					break;

				case "NAC":
					//node acq cost
					//equationString = "TAC";
					builder.Append("Acquisition Cost~");

					//builder.Append("User-entered value");

					//mam 050806
					builder.Append("Replacement Value * Original ENR / Replacement Value Year ENR");
					builder.Append("\r\n\r\nIf ENR for Replacement Year = 0, then Acquisition Cost = 0");

					builder.Append("~");
					break;

				//********************

				//mam 050806
				case "EAC":
					//escalated acquisition cost
					builder.Append("Escalated Acquisition Cost~");
					
					builder.Append("Acquisition Cost * Current ENR / Original ENR");
					builder.Append("\r\n\r\nIf ENR for Installation Year = 0, then Escalated Acquisition Cost = 0");

					builder.Append("~");
					break;

				//mam 050806
				case "TEAC":
					//total escalated acq cost
					builder.Append("Total Escalated Acquisition Cost~");
					builder.Append("Sum of Escalated Acquisition Costs");

					builder.Append("\r\nEscalated Acquisition Cost = Acquisition Cost * Current ENR / Original ENR");
					builder.Append("\r\n\r\nIf ENR for Installation Year = 0, then Escalated Acquisition Cost = 0");

					builder.Append("~");
					break;

				//mam 050806
				case "REAC":
					//rolled-up escalated acq cost
					builder.Append("Escalated Acquisition Cost~");
					builder.Append("Sum of Escalated Acquisition Costs");

					builder.Append("\r\nEscalated Acquisition Cost = Acquisition Cost * Current ENR / Original ENR");
					builder.Append("\r\n\r\nIf ENR for Installation Year = 0, then Escalated Acquisition Cost = 0");

					builder.Append("~");
					break;

				//mam 050806
				case "PEAC":
					//pipe escalated acq cost
					builder.Append("Escalated Acquisition Cost~");

					builder.Append("Acquisition Cost * Current ENR / Original ENR");
					builder.Append("\r\n\r\nIf ENR for Installation Year = 0, then Escalated Acquisition Cost = 0");

					builder.Append("~");
					break;

				//mam 050806
				case "NEAC":
					//node escalated acq cost
					builder.Append("Escalated Acquisition Cost~");

					builder.Append("Acquisition Cost * Current ENR / Original ENR");
					builder.Append("\r\n\r\nIf ENR for Installation Year = 0, then Escalated Acquisition Cost = 0");

					builder.Append("~");
					break;

				//********************

				//mam 112806
				case "RVY":
					//avg replacement value yr
					//for MSC Component grid only
					builder.Append("Replacement Value Year~");
					builder.Append("The Replacement Value Year for the asset");
					builder.Append("\r\n\r\nThe Total row shows the average Replacement Value Year for the rows in the grid");
					builder.Append("\r\n(The average includes only those assets with a Replacement Value Year greater than zero)");
					builder.Append("~");
					break;

				//mam 112806
				case "ARRVY":
					//avg replacement value yr
					//for PN Component grid only
					builder.Append("Average Replacement Value Year~");
					builder.Append("(Sum of Replacement Value Year) / Number of Pipes or Nodes");
					builder.Append("\r\n(Includes only Pipes or Nodes with a Replacement Value Year greater than zero)");
					builder.Append("\r\n\r\nThe Total row shows the average Replacement Value Year for the rows in the grid");
					builder.Append("\r\n(The average includes only those assets with a Replacement Value Year greater than zero)");
					builder.Append("~");
					break;

				//mam 112806
				case "ARVY":
					//avg replacement value yr
					//for Pipes and Nodes avgs and totals screen only
					builder.Append("Average Replacement Value Year~");
					builder.Append("(Sum of Replacement Value Year) / Number of Pipes or Nodes");
					builder.Append("\r\n(Includes only Pipes or Nodes with a Replacement Value Year greater than zero)");
					builder.Append("~");
					break;

				//mam 112806
				case "RRVY":
					//rolled-up replacement value year
					//for treatment and facility grids
					builder.Append("Average Replacement Value Year~");
					builder.Append("Average of Replacement Value Years");
					builder.Append("\r\n(Includes only assets with a Replacement Value Year greater than zero)");

					builder.Append("\r\n\r\nThe Total row shows the average Replacement Value Year for the rows in the grid");
					builder.Append("\r\n(The average includes only those assets with a Replacement Value Year greater than zero)");

					builder.Append("~");
					break;

				//********************

				case "CV":
					//current value
					//equationString = "CV";
					
					builder.Append("Current Value~");

					//builder.Append("When Acquisition Cost is overridden: Current Value = Acquisition Cost * Current ENR / Original ENR");
					//builder.Append("\r\nWhen Acquisition Cost is NOT overridden: Current Value = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("~");

					//mam 050806
					//builder.Append("Escalated Acquisition Cost + Rehab Cost - (Escalated Acquisition Cost * (1 - Condition Fraction))");

					//mam 112806
					builder.Append("Escalated Acquisition Cost * (1 - Condition Fraction) + Rehabilitation Cost");

					builder.Append("\r\n\r\nIf Condition = N/A, then Current Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "TCV":
					//total current value
					//equationString = "TCV";
					
					builder.Append("Total Current Value~");
					builder.Append("Sum of Current Values");

					//builder.Append("\r\nWhen Acquisition Cost is overridden: Current Value = Acquisition Cost * Current ENR / Original ENR");
					//builder.Append("\r\nWhen Acquisition Cost is NOT overridden: Current Value = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("~");

					//mam 050806
					//builder.Append("\r\nCurrent Value = Escalated Acquisition Cost + Rehab Cost - (Escalated Acquisition Cost * (1 - Condition Fraction))");

					//mam 112806
					builder.Append("\r\nCurrent Value = Escalated Acquisition Cost * (1 - Condition Fraction) + Rehabilitation Cost");

					builder.Append("\r\n\r\nIf Condition = N/A, then Current Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "RCV":
					//rolled-up current value
					//equationString = "TCV";
					builder.Append("Current Value~");
					builder.Append("Sum of Current Values");

					//builder.Append("\r\nWhen Acquisition Cost is overridden: Current Value = Acquisition Cost * Current ENR / Original ENR");
					//builder.Append("\r\nWhen Acquisition Cost is NOT overridden: Current Value = ");
					//builder.Append("\r\n          Treatment Process Cost Allocation Current Value");
					//builder.Append("\r\n          * Major Component Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("\r\n          * Discipline Cost Allocation Cost-Weighted Percentage of Asset Value");
					//builder.Append("~");

					//mam 050806
					//builder.Append("\r\nCurrent Value = Escalated Acquisition Cost + Rehab Cost - (Escalated Acquisition Cost * (1 - Condition Fraction))");

					//mam 112806
					builder.Append("\r\nCurrent Value = Escalated Acquisition Cost * (1 - Condition Fraction) + Rehabilitation Cost");

					builder.Append("\r\n\r\nIf Condition = N/A, then Current Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "PCV":
					//pipe current value
					//equationString = "TCV";
					builder.Append("Current Value~");
					
					//builder.Append("Length * Unit Cost");
					//builder.Append("~");

					//mam 050806
					//builder.Append("Escalated Acquisition Cost + Rehab Cost - (Escalated Acquisition Cost * (1 - Condition Fraction))");

					//mam 112806
					builder.Append("Escalated Acquisition Cost * (1 - Condition Fraction) + Rehabilitation Cost");

					builder.Append("\r\n\r\nIf Condition = N/A, then Current Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "NCV":
					//node current value
					//equationString = "TCV";
					builder.Append("Current Value~");

					//builder.Append("Acquisition Cost * Current ENR / Original ENR");
					//builder.Append("\r\nIf Original ENR = 0, then Current Value = 0");
					//builder.Append("~");

					//mam 050806
					//builder.Append("Escalated Acquisition Cost + Rehab Cost - (Escalated Acquisition Cost * (1 - Condition Fraction))");

					//mam 112806
					builder.Append("Escalated Acquisition Cost * (1 - Condition Fraction) + Rehabilitation Cost");

					builder.Append("\r\n\r\nIf Condition = N/A, then Current Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "BV":
					//book value
					//equationString = "BV";
					builder.Append("Book Value~");
					builder.Append("Acquisition Cost - (Annual Depreciation * (Current Year - Installation Year))");
					builder.Append("~");
					break;

				case "TBV":
					//total book value
					//equationString = "TBV";
					builder.Append("Total Book Value~");
					builder.Append("Sum of Book Values");
					builder.Append("\r\nBook Value = Acquisition Cost - (Annual Depreciation * (Current Year - Installation Year))");
					builder.Append("~");
					break;

				case "RBV":
					//rolled-up book value
					//equationString = "TBV";
					builder.Append("Book Value~");
					builder.Append("Sum of Book Values");
					builder.Append("\r\nBook Value = Acquisition Cost - (Annual Depreciation * (Current Year - Installation Year))");
					builder.Append("~");
					break;

				case "AD":
					//annual deprn
					//equationString = "AD";
					builder.Append("Annual Depreciation~");
					builder.Append("(Acquisition Cost - Salvage Value) / Original Useful Life");
					builder.Append("~");
					break;

				case "TAD":
					//total annual deprn
					//equationString = "TAD";
					builder.Append("Total Annual Depreciation~");
					builder.Append("Sum of Annual Depreciation values");
					builder.Append("\r\nAnnual Depreciation = (Acquisition Cost - Salvage Value) / Original Useful Life");
					builder.Append("~");
					break;

				case "RAD":
					//rolled-up annual deprn
					//equationString = "TAD";
					builder.Append("Annual Depreciation~");
					builder.Append("Sum of Annual Depreciation values");
					builder.Append("\r\nAnnual Depreciation = (Acquisition Cost - Salvage Value) / Original Useful Life");
					builder.Append("~");
					break;

				case "CD":
					//cumulative deprn
					//equationString = "CD";
					builder.Append("Cumulative Depreciation~");
					builder.Append("Acquisition Cost - Book Value");
					builder.Append("~");
					break;

				case "TCD":
					//total cumulative deprn
					//equationString = "TCD";
					builder.Append("Total Cumulative Depreciation~");
					builder.Append("Sum of Cumulative Depreciation values");
					builder.Append("\r\nCumulative Depreciation = Acquisition Cost - Book Value");
					builder.Append("~");
					break;

				case "RCD":
					//rolled-up cumulative deprn
					//equationString = "TCD";
					builder.Append("Cumulative Depreciation~");
					builder.Append("Sum of Cumulative Depreciation values");
					builder.Append("\r\nCumulative Depreciation = Acquisition Cost - Book Value");
					builder.Append("~");
					break;

				case "EV":
					//evaluated value
					//equationString = "EV";
					builder.Append("Evaluated Value~");

					//builder.Append("Current Value * (1 - Condition Fraction)");

					//mam 050806
					builder.Append("Escalated Acquisition Cost * (1 - Condition Fraction)");

					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "TEV":
					//total evaluated value
					builder.Append("Total Evaluated Value~");
					builder.Append("Sum of Evaluated Values");

					//builder.Append("\r\nEvaluated Value = Current Value * (1 - Condition Fraction)");

					//mam 050806
					builder.Append("\r\nEvaluated Value = Escalated Acquisition Cost * (1 - Condition Fraction)");

					builder.Append("\r\n\r\nIf Average Condition = N/A, then Total Evaluated Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "REV":
					//rolled-up evaluated value
					builder.Append("Evaluated Value~");
					builder.Append("Sum of Evaluated Values");

					//builder.Append("\r\nEvaluated Value = Current Value * (1 - Condition Fraction)");

					//mam 050806
					builder.Append("\r\nEvaluated Value = Escalated Acquisition Cost * (1 - Condition Fraction)");

					builder.Append("\r\n\r\nIf Condition = N/A, then Evaluated Value = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "RC":
					//repair cost
					//equationString = "RC";
					builder.Append("Repair Cost~");

					//mam 020607 - new equation for Repair Cost = EAC * (Cond - LOS)
					//builder.Append("Current Value * (Condition Fraction - Level of Service Fraction)");
					builder.Append("Escalated Acquisition Cost * (Condition Fraction - Level of Service Fraction)");

					builder.Append("\r\n\r\nIf Condition = 0 or 5 and LOS = 1, then Repair Cost = Replacement Value");
					builder.Append("\r\nIf Condition < LOS, then Repair Cost = 0");
					builder.Append("\r\nIf Condition = N/A, then Repair Cost = N/A");
					builder.Append("~Condition and LOS Fractions:");
					builder.Append("\r\nCondition/LOS 0 and 1: 0");
					builder.Append("\r\nCondition/LOS 2: 0.047");
					builder.Append("\r\nCondition/LOS 3: 0.153");
					builder.Append("\r\nCondition/LOS 4: 0.304");
					builder.Append("\r\nCondition/LOS 5: 0.496");
					break;

				case "TRC":
					//total repair cost
					builder.Append("Total Repair Cost~");
					builder.Append("Sum of Repair Cost values");

					//mam 020607 - new equation for Repair Cost = EAC * (Cond - LOS)
					//builder.Append("\r\nRepair Cost = Current Value * (Condition Fraction - Level of Service Fraction)");
					builder.Append("\r\nRepair Cost = Escalated Acquisition Cost * (Condition Fraction - Level of Service Fraction)");

					builder.Append("\r\n\r\nIf Condition < LOS, then Repair Cost = 0");
					builder.Append("\r\nIf Average Condition = N/A, then Total Repair Cost = N/A");
					builder.Append("~Condition and LOS Fractions:");
					builder.Append("\r\nCondition/LOS 0 and 1: 0");
					builder.Append("\r\nCondition/LOS 2: 0.047");
					builder.Append("\r\nCondition/LOS 3: 0.153");
					builder.Append("\r\nCondition/LOS 4: 0.304");
					builder.Append("\r\nCondition/LOS 5: 0.496");
					break;

				case "RRC":
					//rolled-up repair cost
					builder.Append("Repair Cost~");
					builder.Append("Sum of Repair Cost values");

					//mam 020607 - new equation for Repair Cost = EAC * (Cond - LOS)
					//builder.Append("\r\nRepair Cost = Current Value * (Condition Fraction - Level of Service Fraction)");
					builder.Append("\r\nRepair Cost = Escalated Acquisition Cost * (Condition Fraction - Level of Service Fraction)");

					builder.Append("\r\n\r\nIf Condition = 0 or 5 and LOS = 1, then Repair Cost = Replacement Value");
					builder.Append("\r\nIf Condition < LOS, then Repair Cost = 0");
					builder.Append("\r\nIf Condition = N/A, then Repair Cost = N/A");
					builder.Append("~Condition and LOS Fractions:");
					builder.Append("\r\nCondition/LOS 0 and 1: 0");
					builder.Append("\r\nCondition/LOS 2: 0.047");
					builder.Append("\r\nCondition/LOS 3: 0.153");
					builder.Append("\r\nCondition/LOS 4: 0.304");
					builder.Append("\r\nCondition/LOS 5: 0.496");
					break;

				//mam 07072011
				//mam 0702011 - rehab cost is no longer being set to zero
				//case "REHABCOST":
				//	//rehabilitation cost
				//	builder.Append("Rehabilitation Cost~");
				//	builder.Append("When the Planning Mode is 'Replacement' RehabilitationCost = 0");
				//	builder.Append("\r\n\r\nOtherwise, Rehabilitation Cost is entered manually by the user.");
				//	builder.Append("~");
				//	break;
				case "REHABINTERVAL":
					//rehabilitation interval
					builder.Append("Rehabilitation Interval~");
					builder.Append("User-entered value");
					builder.Append(Environment.NewLine + Environment.NewLine + "When a new Discipline is created, Rehabilitation Interval is set to 50% of the Original Useful Life");
					builder.Append(Environment.NewLine + Environment.NewLine + "If Planning Mode = Replacement, Rehabilitation Interval is displayed as zero");
					builder.Append(Environment.NewLine + "\t(Although the Rehabilitation Interval is displayed as zero, its value still exists and");
					builder.Append(Environment.NewLine + "\tcan be restored by setting Planning Mode to Rehabilitation)");

					//mam 01222012
					builder.Append(Environment.NewLine + Environment.NewLine + "Note: Rehabilitation Interval is required to calculate recurring rehabilitation costs outside of WAM");

					builder.Append("~");
					break;
				case "REHABYEARLAST":
					//last rehabilitation year
					builder.Append("Last Rehabilitation Year~");
					builder.Append("User-entered value");

					//mam 01222012 - default last rehab year for a new discipline is the lesser of fac current year or calendar year
					//builder.Append(Environment.NewLine + Environment.NewLine + "When a new Discipline is created, Last Rehabilitation Year is set to the most recent possible");
					//builder.Append(Environment.NewLine + "\trehabilitation year based on Facility Current Year, Installation Year and Rehabilitation Interval");
					builder.Append(Environment.NewLine + Environment.NewLine + "When a new Discipline is created, Last Rehabilitation Year is set the Facility Current Year or the current calendar year, whichever is less");

					//mam 01222012
					builder.Append(Environment.NewLine + Environment.NewLine + "Note: Last Rehabilitation Year is a user reference value and is also used as a timing constraint where");
					builder.Append(" Installation Year <= Last Rehabilitation Year <= Inspection Year <= Current Year <= Next Rehabilitation Year");

					builder.Append("~");
					break;
				case "REHABNEXT":
					//time to next rehabilitation
					builder.Append("Time to Next Rehabilitation~");

					//mam 01222012 - new calc
					//builder.Append("Last Rehabilitation Year + Rehabilitation Interval - Current Year");
					//builder.Append("\r\n\r\nIf Rehabilitation Interval = 0 or Last Rehabilitation Year = 0, then");
					//builder.Append("\r\n\tTime to Next Rehabilitation = 0");
					builder.Append("Economic Remaining Useful Life + Inspection Year - Current Year");
					builder.Append("\r\n\r\nIf Next Rehabilitation Year is overridden, then");
					builder.Append("\r\n\tTime to Next Rehabilitation = Next Rehabilitation Year - Current Year");
					builder.Append("\r\n\r\nIf Time to Next Rehabilitation < 0, then");
					builder.Append("\r\n\tTime to Next Rehabilitation = 0");

					builder.Append("\r\n\r\nIf Planning Mode = Replacement, then Time to Next Rehabilitation = 0");
					builder.Append("~");
					break;
				case "REHABYEARNEXT":
					//the year when the next rehabilitation is due
					builder.Append("Next Rehabilitation Year~");

					//mam 01222012 - new calc
					//builder.Append("Last Rehabilitation Year + Rehabilitation Interval");
					//builder.Append("\r\n\r\nIf Rehabilitation Interval = 0 or Last Rehabilitation Year = 0, then");
					//builder.Append("\r\n\tNext Rehabilitation Year = 0 (unless Time to Next Rehabilitation is overridden)");
					//builder.Append("\r\n\r\nIf Time To Next Rehabilitation is overridden, then");
					//builder.Append("\r\n\tNext Rehabilitation Year = Current Year + Time to Next Rehabilitation");
					builder.Append("Current Year + Time to Next Rehabilitation");
					builder.Append("\r\n\r\nIf Next Rehabilitation Year < Current Year, then");
					builder.Append("\r\n\tNext Rehabilitation Year = Current Year");

					builder.Append("\r\n\r\nIf Planning Mode = Replacement, then Next Rehabilitation Year = 0, whether or not it is overridden");
					builder.Append("~");
					break;

				//mam 01222012 - new field
				case "REPLACEMENTNEXT":
					//time to next replacement
					builder.Append("Time to Next Replacement~");

					builder.Append("Evaluated Remaining Useful Life + Inspection Year - Current Year");
					builder.Append("\r\n\r\nIf Next Replacement Year is overridden, then");
					builder.Append("\r\n\tTime to Next Replacement = Next Replacement Year - Current Year");
					builder.Append("\r\n\r\nIf Time to Next Replacement < 0, then");
					builder.Append("\r\n\tTime to Next Replacement = 0");

					builder.Append("\r\n\r\nIf Planning Mode = Rehabilitation, then Time to Next Rehabilitation = 0");
					builder.Append("~");
					break;

				case "NEXTREPLACEYEAR":
					//the next replacement year
					builder.Append("Next Replacement Year~");

					//mam 01222012 - new calc
					//builder.Append("Date of Inspection Year + Evaluated Remaining Useful Life");
					//builder.Append("\r\n\r\nNext Replacement Year is always rounded up to the next year when it is a calculated value");
					////builder.Append("\r\n\r\nIf Planning Mode = Replacement, then Next Replacement Year is automatically calculated, unless it is overridden");
					////builder.Append("\r\nIf Planning Mode = Rehabilitation, then Next Replacement Year = 0, unless it is overridden");
					////builder.Append("\r\n\r\nIf Next Replacement Year is overridden, its value will remain unchanged regardless of the Planning Mode");
					builder.Append("Current Year + Time to Next Replacement");
					builder.Append("\r\n\r\nIf Next Replacement Year < Current Year, then");
					builder.Append("\r\n\tNext Replacement Year = Current Year");
					builder.Append("\r\n\r\nIf Planning Mode = Rehabilitation, then Next Replacement Year = 0, whether or not it is overridden");

					builder.Append("~");
					break;

				case "RUL":
					//remaining useful life
					//equationString = "RUL";
					builder.Append("Remaining Useful Life~");
					builder.Append("Original Useful Life - (Current Year - Installation Year)");
					builder.Append("~");
					break;

				case "RULMSL":
					//remaining useful life on the component assessment tab for MSL disciplines
					builder.Append("Remaining Useful Life~");
					builder.Append("Original Useful Life - (Current Year - Installation Year)");
					//builder.Append("\r\n\r\nIf Condition = N/A, then Remaining Useful Life = N/A");
					builder.Append("\r\n\r\nTotal Remaining Useful Life = Sum of Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Remaining Useful Life");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Total Remaining Useful Life = N/A");
					builder.Append("~");
					break;

				case "RULPN":
					//remaining useful life on the component assessment tab for pipes and nodes
					builder.Append("Remaining Useful Life~");
					//builder.Append("Original Useful Life - (Current Year - Installation Year)");
					builder.Append("Sum of Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Remaining Useful Life");
					builder.Append("\r\n   where Remaining Useful Life = Original Useful Life - (Current Year - Installation Year)");
					//builder.Append("\r\n\r\nIf Condition = N/A, then Remaining Useful Life = N/A");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Remaining Useful Life = N/A");
					builder.Append("~");
					break;

				case "ARUL":
					//avg remaining useful life
					//equationString = "ARUL";
					builder.Append("Average Remaining Useful Life~");
					builder.Append("Sum of Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Remaining Useful Life");
					builder.Append("\r\n   where Remaining Useful Life = Original Useful Life - (Current Year - Installation Year)");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Remaining Useful Life = N/A");
					builder.Append("~");
					break;

				case "AIY":
					//avg install yr
					//equationString = "AIY";
					builder.Append("Average Installation Year~");
					builder.Append("(Sum of Installation Year) / Number of Pipes or Nodes");
					builder.Append("~");
					break;

				case "AOUL":
					//avg orig useful life
					//equationString = "AOUL";
					builder.Append("Average Original Useful Life~");
					builder.Append("Sum of Original Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Original Useful Life");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Original Useful Life = N/A");
					builder.Append("~");
					break;

				case "ALOS":
					//avg level of service
					//equationString = "ALOS";
					builder.Append("Average Level of Service~");
					builder.Append("([(Sum of (Level of Service Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Level of Service = N/A");
					builder.Append("~Level of Service Fractions:");
					builder.Append("\r\nLOS 0 and 1: 0");
					builder.Append("\r\nLOS 2: 0.047");
					builder.Append("\r\nLOS 3: 0.153");
					builder.Append("\r\nLOS 4: 0.304");
					builder.Append("\r\nLOS 5: 0.496");
					break;

				case "ACOND":
					//avg condition
					//equationString = "ACOND";
					builder.Append("Average Condition~");
					builder.Append("([(Sum of (Condition Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Condition = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "TRV":
					//total replacement value
					//equationString = "TRV";
					builder.Append("Total Replacement Value~");
					builder.Append("Sum of Replacement Values");
					builder.Append("~");
					break;

				case "TSV":
					//total salvage value
					//equationString = "TSV";
					builder.Append("Total Salvage Value~");
					builder.Append("Sum of Salvage Values");
					builder.Append("~");
					break;

				case "TAM":
					//total annual maint cost
					//equationString = "TAM";
					builder.Append("Total Annual Maintenance Cost~");
					builder.Append("Sum of Annual Maintenance Costs");
					builder.Append("~");
					break;

				//mam 050806
				case "TREHAB":
					//total rehabilitation cost
					builder.Append("Total Rehabilitation Cost~");
					builder.Append("Sum of Rehabilitation Costs");
					builder.Append("~");
					break;

//***********************************
				case "COND":
					//rolled-up condition
					builder.Append("Condition~");
					builder.Append("Sum of Condition Fraction weighted by Current Value");
					builder.Append("\r\n([(Sum of (Condition Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Condition = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "CONDASSESSMSL":
					//condition on the component assessment tab for MSL disciplines
					builder.Append("Condition~");
					builder.Append("Condition of the Mechanical, Structural, or Civil Discipline");
					builder.Append("\r\n\r\nTotal Condition = Sum of Condition Fraction weighted by Current Value");
					builder.Append("\r\n([(Sum of (Condition Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Total Condition = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "CONDASSESSPN":
					//condition on the component assessment tab for pipes and nodes
					builder.Append("Condition~");
					builder.Append("Sum of Condition Fraction weighted by Current Value");
					builder.Append("\r\n([(Sum of (Condition Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Condition = N/A");
					builder.Append("~Condition Fractions:");
					builder.Append("\r\nCondition 0 and 1: 0");
					builder.Append("\r\nCondition 2: 0.047");
					builder.Append("\r\nCondition 3: 0.153");
					builder.Append("\r\nCondition 4: 0.304");
					builder.Append("\r\nCondition 5: 0.496");
					break;

				case "OUL":
					//rolled-up OUL
					builder.Append("Original Useful Life~");
					builder.Append("Sum of Original Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Original Useful Life");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Original Useful Life = N/A");
					builder.Append("~");
					break;

				case "OULMSL":
					//OUL on the component assessment tab for MSL disciplines
					builder.Append("Original Useful Life~");
					builder.Append("Original Useful Life of the Mechanical, Structural, or Civil Discipline");
					//builder.Append("\r\n\r\nIf Condition = N/A, then Original Useful Life = N/A");
					builder.Append("\r\n\r\nTotal Original Useful Life = Sum of Original Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Original Useful Life");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Total Original Useful Life = N/A");
					builder.Append("~");
					break;

				case "OULPN":
					//OUL on the component assessment tab for pipes and nodes
					builder.Append("Original Useful Life~");
					builder.Append("Sum of Original Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Original Useful Life");
					//builder.Append("\r\n\r\nIf Condition = N/A, then Original Useful Life = N/A");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Original Useful Life = N/A");
					builder.Append("~");
					break;

				case "RRUL":
					//rolled-up remaining useful life
					builder.Append("Remaining Useful Life~");
					builder.Append("Sum of Remaining Useful Life weighted by Current Value");
					builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Remaining Useful Life");
					builder.Append("\r\n   where Remaining Useful Life = Original Useful Life - (Current Year - Installation Year)");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Remaining Useful Life = N/A");
					builder.Append("~");
					break;

				case "LOS":
					//rolled-up los
					builder.Append("Level of Service~");
					builder.Append("Sum of Level of Service weighted by Current Value");
					//builder.Append("\r\n= Sum of (Current Value / Total Current Value) * Level of Service Fraction");
					builder.Append("\r\n([(Sum of (LOS Fraction * Current Value) / Total Current Value) * 100] ^ 0.5885) * 0.4021 + 1");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Level of Service = N/A");
					builder.Append("~Level of Service Fractions:");
					builder.Append("\r\nLOS 0 and 1: 0");
					builder.Append("\r\nLOS 2: 0.047");
					builder.Append("\r\nLOS 3: 0.153");
					builder.Append("\r\nLOS 4: 0.304");
					builder.Append("\r\nLOS 5: 0.496");
					break;

				case "CRIT":
					//rolled-up crit
					builder.Append("Criticality~");
					builder.Append("Sum of Overall Criticality values weighted by Current Value");
					builder.Append("\r\n\r\n= Sum of (Current Value / Total Current Value) * Overall Criticality");

					//mam 07072011
					//builder.Append("\r\n   where Overall Criticality = the sum of four Criticality values");
					builder.Append("\r\n      where Overall Criticality = the weighted sum of the Criticality values");
					builder.Append("\r\n      (sum of (Criticality value x Criticality weight))");

					//mam 01222012
					builder.Append("\r\n\r\nmultiplied by the Facility Criticality Weighting Factor");

					builder.Append("\r\n\r\nmultiplied by the Redundancy Factor");
					builder.Append("\r\n      (based on the Number of Assets with Similar Functionality)");
					builder.Append("\r\n\r\nIf Total Current Value = 0 or N/A, then Average Criticality = N/A");
					builder.Append("\r\nIf Total Current Value = 0 or N/A, then Criticality = N/A");
					builder.Append("~No. of\t  Redundancy");
					builder.Append("\r\nAssets\t      Factor");
					builder.Append("\r\n    2\t        95%");
					builder.Append("\r\n    3\t        92%");
					builder.Append("\r\n    4\t        88%");
					builder.Append("\r\n    5\t        85%");
					builder.Append("\r\n  6-10\t        80%"); 
					builder.Append("\r\n11-15\t        70%");
					builder.Append("\r\n16-20\t        60%");
					builder.Append("\r\n  >20\t        50%");
					break;

				default:
					builder.Append("");
					break;
			}

			equationString = builder.ToString();
			return equationString;
		}

		#endregion /***** Equations *****/

	}
}
