using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for TreatmentProcessControl.
	/// </summary>
	public class TreatmentProcessControl : System.Windows.Forms.UserControl
	{
		private	TreatmentProcess m_process = null;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private WAM.UI.PhotoControl pictureBox;
		private System.Windows.Forms.Button buttonBrowsePhoto;
		private System.Windows.Forms.TextBox textBoxPhotoCaption;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private WAM.UI.Grids.ComponentGrid componentGrid1;
		private System.Windows.Forms.TabPage tabPageAssessment;
		private System.Windows.Forms.TextBox textBoxAssessmentComments;
		private System.Windows.Forms.Label label7;
		private WAM.UI.Grids.ComponentAssessmentGrid gridAssessment;
		private System.Windows.Forms.TabPage tabPageAllocation;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxAllocComments;
		private WAM.UI.Grids.CostAllocationGrid gridAllocation;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label3;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TreatmentProcessControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.componentGrid1 = new WAM.UI.Grids.ComponentGrid();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tabPageAssessment = new System.Windows.Forms.TabPage();
			this.textBoxAssessmentComments = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.gridAssessment = new WAM.UI.Grids.ComponentAssessmentGrid();
			this.tabPageAllocation = new System.Windows.Forms.TabPage();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxAllocComments = new System.Windows.Forms.TextBox();
			this.gridAllocation = new WAM.UI.Grids.CostAllocationGrid();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.pictureBox = new WAM.UI.PhotoControl();
			this.buttonBrowsePhoto = new System.Windows.Forms.Button();
			this.textBoxPhotoCaption = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			this.tabPageAssessment.SuspendLayout();
			this.tabPageAllocation.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageAssessment);
			this.tabControl.Controls.Add(this.tabPageAllocation);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.tabControl.ItemSize = new System.Drawing.Size(110, 18);
			this.tabControl.Location = new System.Drawing.Point(4, 117);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.tabControl.Size = new System.Drawing.Size(608, 332);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl.TabIndex = 24;
			this.tabControl.Leave += new System.EventHandler(this.textBoxComments_Leave);
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.componentGrid1);
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.label4);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.tabPageMain.Size = new System.Drawing.Size(600, 306);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// componentGrid1
			// 
			this.componentGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.componentGrid1.GridStyle = WAM.UI.Grids.ComponentGrid.GridType.MajorComponents;
			this.componentGrid1.Location = new System.Drawing.Point(4, 4);
			this.componentGrid1.Name = "componentGrid1";
			this.componentGrid1.Size = new System.Drawing.Size(592, 180);
			this.componentGrid1.TabIndex = 3;
			// 
			// textBoxComments
			// 
			this.textBoxComments.AcceptsReturn = true;
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxComments.TabIndex = 2;
			this.textBoxComments.Text = "";
			this.textBoxComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.Location = new System.Drawing.Point(4, 188);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Comments:";
			// 
			// tabPageAssessment
			// 
			this.tabPageAssessment.Controls.Add(this.textBoxAssessmentComments);
			this.tabPageAssessment.Controls.Add(this.label7);
			this.tabPageAssessment.Controls.Add(this.gridAssessment);
			this.tabPageAssessment.Location = new System.Drawing.Point(4, 22);
			this.tabPageAssessment.Name = "tabPageAssessment";
			this.tabPageAssessment.Size = new System.Drawing.Size(600, 306);
			this.tabPageAssessment.TabIndex = 2;
			this.tabPageAssessment.Text = "Assessment";
			// 
			// textBoxAssessmentComments
			// 
			this.textBoxAssessmentComments.AcceptsReturn = true;
			this.textBoxAssessmentComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAssessmentComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxAssessmentComments.Multiline = true;
			this.textBoxAssessmentComments.Name = "textBoxAssessmentComments";
			this.textBoxAssessmentComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAssessmentComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxAssessmentComments.TabIndex = 5;
			this.textBoxAssessmentComments.Text = "";
			this.textBoxAssessmentComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label7
			// 
			this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label7.Location = new System.Drawing.Point(4, 188);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 16);
			this.label7.TabIndex = 4;
			this.label7.Text = "Comments:";
			// 
			// gridAssessment
			// 
			this.gridAssessment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAssessment.GridStyle = WAM.UI.Grids.ComponentAssessmentGrid.GridType.MajorComponents;
			this.gridAssessment.Location = new System.Drawing.Point(4, 4);
			this.gridAssessment.Name = "gridAssessment";
			this.gridAssessment.Size = new System.Drawing.Size(592, 180);
			this.gridAssessment.TabIndex = 3;
			// 
			// tabPageAllocation
			// 
			this.tabPageAllocation.Controls.Add(this.label16);
			this.tabPageAllocation.Controls.Add(this.textBoxAllocComments);
			this.tabPageAllocation.Controls.Add(this.gridAllocation);
			this.tabPageAllocation.Location = new System.Drawing.Point(4, 22);
			this.tabPageAllocation.Name = "tabPageAllocation";
			this.tabPageAllocation.Size = new System.Drawing.Size(600, 306);
			this.tabPageAllocation.TabIndex = 3;
			this.tabPageAllocation.Text = "Cost Allocation by %";
			// 
			// label16
			// 
			this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label16.Location = new System.Drawing.Point(4, 188);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(100, 16);
			this.label16.TabIndex = 8;
			this.label16.Text = "Comments:";
			// 
			// textBoxAllocComments
			// 
			this.textBoxAllocComments.AcceptsReturn = true;
			this.textBoxAllocComments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAllocComments.Location = new System.Drawing.Point(4, 204);
			this.textBoxAllocComments.Multiline = true;
			this.textBoxAllocComments.Name = "textBoxAllocComments";
			this.textBoxAllocComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAllocComments.Size = new System.Drawing.Size(592, 100);
			this.textBoxAllocComments.TabIndex = 7;
			this.textBoxAllocComments.Text = "";
			// 
			// gridAllocation
			// 
			this.gridAllocation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAllocation.GridStyle = WAM.UI.Grids.CostAllocationGrid.GridType.MajorComponents;
			this.gridAllocation.Location = new System.Drawing.Point(4, 4);
			this.gridAllocation.Name = "gridAllocation";
			this.gridAllocation.Size = new System.Drawing.Size(592, 180);
			this.gridAllocation.TabIndex = 6;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.pictureBox);
			this.tabPagePhoto.Controls.Add(this.buttonBrowsePhoto);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.tabPagePhoto.Size = new System.Drawing.Size(600, 306);
			this.tabPagePhoto.TabIndex = 1;
			this.tabPagePhoto.Text = "Photo";
			this.tabPagePhoto.Visible = false;
			// 
			// pictureBox
			// 
			this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pictureBox.Image = null;
			this.pictureBox.Location = new System.Drawing.Point(4, 4);
			this.pictureBox.Name = "pictureBox";
			this.pictureBox.Size = new System.Drawing.Size(592, 244);
			this.pictureBox.TabIndex = 17;
			// 
			// buttonBrowsePhoto
			// 
			this.buttonBrowsePhoto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonBrowsePhoto.Location = new System.Drawing.Point(263, 276);
			this.buttonBrowsePhoto.Name = "buttonBrowsePhoto";
			this.buttonBrowsePhoto.TabIndex = 16;
			this.buttonBrowsePhoto.Text = "Browse...";
			this.buttonBrowsePhoto.Click += new System.EventHandler(this.buttonBrowsePhoto_Click);
			// 
			// textBoxPhotoCaption
			// 
			this.textBoxPhotoCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption.Location = new System.Drawing.Point(4, 252);
			this.textBoxPhotoCaption.MaxLength = 255;
			this.textBoxPhotoCaption.Name = "textBoxPhotoCaption";
			this.textBoxPhotoCaption.Size = new System.Drawing.Size(592, 20);
			this.textBoxPhotoCaption.TabIndex = 15;
			this.textBoxPhotoCaption.Text = "";
			this.textBoxPhotoCaption.Leave += new System.EventHandler(this.textBoxPhotoCaption_Leave);
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 18;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 17;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 5);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 23;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 19;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 20;
			this.textBoxProcessName.Text = "";
			this.textBoxProcessName.Leave += new System.EventHandler(this.textBoxProcessName_Leave);
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 34;
			this.textBoxCurrentYear.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(456, 6);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 16);
			this.label3.TabIndex = 35;
			this.label3.Text = "Current Year:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// TreatmentProcessControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(616, 452);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Name = "TreatmentProcessControl";
			this.Size = new System.Drawing.Size(616, 452);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			this.tabPageAssessment.ResumeLayout(false);
			this.tabPageAllocation.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public void			SetProcess(TreatmentProcess process)
		{
			m_process = process;
			RefreshData();
		}

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			base.OnLoad(e);
		}

		public void			RefreshData()
		{
			componentGrid1.SetRootObject(m_process);
			gridAssessment.SetRootObject(m_process);
			gridAllocation.SetRootObject(m_process);

			if (m_process == null)
				return;

			tabControl.SelectedIndex = 0;

			Facility facility = 
				FacilityCache.Cached.GetFacility(m_process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = m_process.Name;
			textBoxComments.Text = m_process.Comments;
		}

		private void textBoxProcessName_Leave(object sender, System.EventArgs e)
		{
			if (m_process != null && textBoxProcessName.Text.Length > 0)
			{
				if (string.Compare(m_process.Name, textBoxProcessName.Text) != 0)
				{
					// Update the name
					m_process.Name = textBoxProcessName.Text;
					m_process.Save();
				}
			}
		}

		private void textBoxComments_Leave(object sender, System.EventArgs e)
		{
			if (m_process == null)
				return;

			bool			changed = false;

			if (sender is TextBox)
			{
				if (((TextBox)sender).Text != m_process.Comments)
				{
					m_process.Comments = ((TextBox)sender).Text;
					changed = true;
				}
			}

			if (changed)
			{
				m_process.Save();

				// Update all of the comments fields that are NOT 
				// the comments field that sent the notification
				if (!object.ReferenceEquals(sender, textBoxComments))
					textBoxComments.Text = m_process.Comments;
				if (!object.ReferenceEquals(sender, textBoxAllocComments))
					textBoxAllocComments.Text = m_process.Comments;
				if (!object.ReferenceEquals(sender, textBoxAssessmentComments))
					textBoxAssessmentComments.Text = m_process.Comments;
			}
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_process != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption.Text = m_process.CaptionPhoto;

					pictureBox.Image = m_process.GetPhoto();
					if (pictureBox.Image == null)
						buttonBrowsePhoto.Text = "Browse";
					else
						buttonBrowsePhoto.Text = "Delete";
				}
				else
				{
					textBoxPhotoCaption.Text = "";
					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";
				}
			}
		}

		private void buttonBrowsePhoto_Click(object sender, System.EventArgs e)
		{
			if (pictureBox.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_process.GetImagePath();

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_process.CaptionPhoto = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption.Text = m_process.CaptionPhoto;
					m_process.Save();
					buttonBrowsePhoto.Text = "Delete";
					pictureBox.Image = m_process.GetPhoto();
				}
			}
			else
			{
				pictureBox.Image = null;
				string		targetPath = m_process.GetImagePath();

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_process.CaptionPhoto = "";
				textBoxPhotoCaption.Text = "";
				buttonBrowsePhoto.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption_Leave(object sender, System.EventArgs e)
		{
			if (m_process.CaptionPhoto != textBoxPhotoCaption.Text)
			{
				m_process.CaptionPhoto = textBoxPhotoCaption.Text;
				m_process.Save();
			}
		}
	}
}
