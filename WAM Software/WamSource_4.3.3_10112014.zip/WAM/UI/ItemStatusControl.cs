using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ItemStatusControl.
	/// </summary>
	public class ItemStatusControl : System.Windows.Forms.UserControl
	{
		private bool		m_suppressUpdate = false;
		private WAM.Data.ItemStatus m_status = WAM.Data.ItemStatus.No;

		private System.Windows.Forms.Label labelQuestion;
		private System.Windows.Forms.RadioButton radioButtonYes;
		private System.Windows.Forms.RadioButton radioButtonNo;
		private System.Windows.Forms.RadioButton radioButtonNA;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ItemStatusControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.labelQuestion = new System.Windows.Forms.Label();
			this.radioButtonYes = new System.Windows.Forms.RadioButton();
			this.radioButtonNo = new System.Windows.Forms.RadioButton();
			this.radioButtonNA = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// labelQuestion
			// 
			this.labelQuestion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelQuestion.Location = new System.Drawing.Point(0, 0);
			this.labelQuestion.Name = "labelQuestion";
			this.labelQuestion.Size = new System.Drawing.Size(88, 16);
			this.labelQuestion.TabIndex = 0;
			// 
			// radioButtonYes
			// 
			this.radioButtonYes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.radioButtonYes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonYes.Location = new System.Drawing.Point(88, 0);
			this.radioButtonYes.Name = "radioButtonYes";
			this.radioButtonYes.Size = new System.Drawing.Size(32, 16);
			this.radioButtonYes.TabIndex = 1;
			this.radioButtonYes.Text = "Y";
			this.radioButtonYes.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
			// 
			// radioButtonNo
			// 
			this.radioButtonNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.radioButtonNo.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonNo.Location = new System.Drawing.Point(120, 0);
			this.radioButtonNo.Name = "radioButtonNo";
			this.radioButtonNo.Size = new System.Drawing.Size(32, 16);
			this.radioButtonNo.TabIndex = 2;
			this.radioButtonNo.Text = "N";
			this.radioButtonNo.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
			// 
			// radioButtonNA
			// 
			this.radioButtonNA.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.radioButtonNA.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonNA.Location = new System.Drawing.Point(152, 0);
			this.radioButtonNA.Name = "radioButtonNA";
			this.radioButtonNA.Size = new System.Drawing.Size(44, 16);
			this.radioButtonNA.TabIndex = 3;
			this.radioButtonNA.Text = "N/A";
			this.radioButtonNA.CheckedChanged += new System.EventHandler(this.OnCheckChanged);
			// 
			// ItemStatusControl
			// 
			this.Controls.Add(this.radioButtonYes);
			this.Controls.Add(this.labelQuestion);
			this.Controls.Add(this.radioButtonNo);
			this.Controls.Add(this.radioButtonNA);
			this.Name = "ItemStatusControl";
			this.Size = new System.Drawing.Size(196, 16);
			this.ResumeLayout(false);

		}
		#endregion

		public WAM.Data.ItemStatus Status
		{
			get { return m_status; }
			set 
			{
				m_status = value;
				UpdateSetting();
			}
		}

		public string		Caption
		{
			get { return labelQuestion.Text; }
			set { labelQuestion.Text = value; }
		}

		protected override void OnLoad(EventArgs e)
		{
			if (this.DesignMode)
			{
				radioButtonYes.AutoCheck = false;
				radioButtonNo.AutoCheck = false;
				radioButtonNA.AutoCheck = false;
			}

			UpdateSetting();
			base.OnLoad(e);
		}

		private void		UpdateSetting()
		{
			m_suppressUpdate = true;
			radioButtonYes.Checked = (m_status == WAM.Data.ItemStatus.Yes);
			radioButtonNo.Checked = (m_status == WAM.Data.ItemStatus.No);
			radioButtonNA.Checked = (m_status == WAM.Data.ItemStatus.NotApplicable);
			m_suppressUpdate = false;
		}

		private void		OnCheckChanged(object sender, System.EventArgs e)
		{
			if (m_suppressUpdate)
				return;

			if (radioButtonYes.Checked)
				m_status = WAM.Data.ItemStatus.Yes;
			else if (radioButtonNo.Checked)
				m_status = WAM.Data.ItemStatus.No;
			else if (radioButtonNA.Checked)
				m_status = WAM.Data.ItemStatus.NotApplicable;
		}
	}
}
