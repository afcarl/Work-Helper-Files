using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ChangeSortOrderForm.
	/// </summary>
	public class ChangeSortOrderForm : System.Windows.Forms.Form
	{
		private object		m_parentObject = null;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxParent;
		private C1.Win.C1FlexGrid.C1FlexGrid gridSortOrder;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ChangeSortOrderForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ChangeSortOrderForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxParent = new System.Windows.Forms.TextBox();
			this.gridSortOrder = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.gridSortOrder)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 34);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(352, 28);
			this.label1.TabIndex = 2;
			this.label1.Text = "Please arrange the items to be in the order that you would like them to be listed" +
				":";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(4, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(80, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Sort Order For:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBoxParent
			// 
			this.textBoxParent.Location = new System.Drawing.Point(79, 7);
			this.textBoxParent.Name = "textBoxParent";
			this.textBoxParent.ReadOnly = true;
			this.textBoxParent.Size = new System.Drawing.Size(253, 20);
			this.textBoxParent.TabIndex = 1;
			this.textBoxParent.TabStop = false;
			this.textBoxParent.Text = "";
			// 
			// gridSortOrder
			// 
			this.gridSortOrder.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.Rows;
			this.gridSortOrder.AllowEditing = false;
			this.gridSortOrder.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.gridSortOrder.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.gridSortOrder.BackColor = System.Drawing.SystemColors.Window;
			this.gridSortOrder.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:25;}\t1{DataType:System.String;TextAlign:LeftCenter;}" +
				"\t";
			this.gridSortOrder.DragMode = C1.Win.C1FlexGrid.DragModeEnum.AutomaticMove;
			this.gridSortOrder.ExtendLastCol = true;
			this.gridSortOrder.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridSortOrder.ForeColor = System.Drawing.SystemColors.WindowText;
			this.gridSortOrder.Location = new System.Drawing.Point(4, 71);
			this.gridSortOrder.Name = "gridSortOrder";
			this.gridSortOrder.Rows.Fixed = 0;
			this.gridSortOrder.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.gridSortOrder.Size = new System.Drawing.Size(352, 239);
			this.gridSortOrder.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridSortOrder.TabIndex = 3;
			// 
			// buttonSave
			// 
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(194, 316);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 4;
			this.buttonSave.Text = "&Save Order";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(279, 316);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 5;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(336, 7);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 95;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// ChangeSortOrderForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(362, 344);
			this.Controls.Add(this.textBoxParent);
			this.Controls.Add(this.gridSortOrder);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "ChangeSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ChangeSortOrderForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Change Sort Order";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ChangeSortOrderForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ChangeSortOrderForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.gridSortOrder)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(object parentObject, Form owner)
		{
			ChangeSortOrderForm form = new ChangeSortOrderForm();

			form.m_parentObject = parentObject;
			return (form.ShowDialog(owner) == DialogResult.OK);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			int				pos;

			gridSortOrder.Redraw = false;
			gridSortOrder.Rows.Count = 0;
			if (m_parentObject is InfoSet)
			{
				InfoSet		infoSet = (InfoSet)m_parentObject;
				Facility[]
							facilities = CacheManager.GetFacilities(infoSet.ID);

				textBoxParent.Text = infoSet.Name;

				for (pos = 0; pos < facilities.Length; pos++)
				{
					gridSortOrder.Rows.Add().UserData = facilities[pos];
					gridSortOrder.SetData(pos, 1, facilities[pos].Name);
				}
			}
			else if (m_parentObject is Facility)
			{
				Facility	facility = (Facility)m_parentObject;
				TreatmentProcess[]
							processes = CacheManager.GetProcesses(InfoSet.CurrentID, facility.ID);

				textBoxParent.Text = facility.Name;
				for (pos = 0; pos < processes.Length; pos++)
				{
					gridSortOrder.Rows.Add().UserData = processes[pos];
					gridSortOrder.SetData(pos, 1, processes[pos].Name);
				}
			}
			else if (m_parentObject is TreatmentProcess)
			{
				TreatmentProcess process = (TreatmentProcess)m_parentObject;
				MajorComponent[]
							components = CacheManager.GetComponents(InfoSet.CurrentID, process.ID);

				textBoxParent.Text = process.Name;
				for (pos = 0; pos < components.Length; pos++)
				{
					gridSortOrder.Rows.Add().UserData = components[pos];
					gridSortOrder.SetData(pos, 1, components[pos].Name);
				}
			}

			gridSortOrder.Redraw = true;

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			object			rowObject = null;

			// Save the new sort order
			for (int row = 0; row < gridSortOrder.Rows.Count; row++)
			{
				rowObject = gridSortOrder.Rows[row].UserData;

				if (rowObject is Facility)
				{
					((Facility)rowObject).InfoSetID = InfoSet.CurrentID;
					((Facility)rowObject).SortOrder = row;
					((Facility)rowObject).Save();
				}
				else if (rowObject is TreatmentProcess)
				{
					((TreatmentProcess)rowObject).InfoSetID = InfoSet.CurrentID;
					((TreatmentProcess)rowObject).SortOrder = row;
					((TreatmentProcess)rowObject).Save();
				}
				else if (rowObject is MajorComponent)
				{
					((MajorComponent)rowObject).InfoSetID = InfoSet.CurrentID;
					((MajorComponent)rowObject).SortOrder = row;
					((MajorComponent)rowObject).Save();
				}
			}

			if (m_parentObject is InfoSet)
			{
				CacheManager.GetFacilityCache(InfoSet.CurrentID).Sort();
			}
			else if (m_parentObject is Facility)
			{
				CacheManager.GetProcessCache(InfoSet.CurrentID).SortForFacility(
					((Facility)m_parentObject).ID);
			}
			else if (m_parentObject is TreatmentProcess)
			{
				CacheManager.GetComponentCache(InfoSet.CurrentID).SortForProcess(
					((TreatmentProcess)m_parentObject).ID);
			}

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();		
		}

		private void ChangeSortOrderForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ChangeSortOrder.htm");
		}

		private void ChangeSortOrderForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}