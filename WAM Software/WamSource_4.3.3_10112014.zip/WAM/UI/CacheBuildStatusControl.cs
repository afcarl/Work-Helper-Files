using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for CacheBuildStatusControl.
	/// </summary>
	public class CacheBuildStatusControl : System.Windows.Forms.UserControl
	{
		private CacheUpdateHandler	m_cacheUpdateDelegate = null;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.Button buttonCancel;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		//mam
		private bool allowCancel = false;
		private bool cancelCache = false;
		//</mam>

		public CacheBuildStatusControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			m_cacheUpdateDelegate = new CacheUpdateHandler(this.UpdateStatus);
			AddCacheEventHandler(m_cacheUpdateDelegate);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				if(components != null)
					components.Dispose();

				if (m_cacheUpdateDelegate != null)
				{
					RemoveCacheEventHandler(m_cacheUpdateDelegate);
					m_cacheUpdateDelegate = null; 
				}
			}

			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CacheBuildStatusControl));
			this.label1 = new System.Windows.Forms.Label();
			this.labelStatus = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(184, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Building cache - please wait...";
			// 
			// labelStatus
			// 
			this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Location = new System.Drawing.Point(4, 37);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(292, 58);
			this.labelStatus.TabIndex = 1;
			// 
			// buttonCancel
			// 
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.buttonCancel.Image = ((System.Drawing.Image)(resources.GetObject("buttonCancel.Image")));
			this.buttonCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonCancel.Location = new System.Drawing.Point(212, 74);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 2;
			this.buttonCancel.TabStop = false;
			this.buttonCancel.Text = "     Cancel";
			this.buttonCancel.Visible = false;
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// CacheBuildStatusControl
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelStatus);
			this.Controls.Add(this.label1);
			this.Name = "CacheBuildStatusControl";
			this.Size = new System.Drawing.Size(300, 104);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.CacheBuildStatusControl_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		private void UpdateStatus(object sender, CacheUpdateEventArgs e)
		{
			if (this.IsDisposed)
				return;
			//mam
			else if (cancelCache)
			{
				e.Status = "Cancelling...";
				return;
			}
			//</mam>
			else
			{
				this.labelStatus.Text = e.Status;
				Application.DoEvents();
			}
		}

		//mam
		public bool AllowCancelCache
		{
			get 
			{ 
				return allowCancel; 
			}
			set 
			{ 
				allowCancel = value;
				buttonCancel.Visible = value;
			}
		}
		//</mam>

		#region /****** Event Handling ******/
		public delegate void CacheUpdateHandler(object sender, CacheUpdateEventArgs e);
		private static event CacheUpdateHandler CacheUpdate;

		public static void	AddCacheEventHandler(CacheUpdateHandler handler)
		{
			// example: 
			// CacheUpdateHandler handler = new CacheBuildStatusControl.CacheUpdateHandler(myClass.DataChanged)
			// CacheBuildStatusControl.AddCacheEventHandler(handler);

			// Declare method as:
			// private void UpdateStatus(object sender, CacheUpdateEventArgs e)
			CacheUpdate += handler;
		}

		public static void	RemoveCacheEventHandler(CacheUpdateHandler handler)
		{
			CacheUpdate -= handler;
		}

		public static void	InvokeUpdateEvent(object sender, CacheUpdateEventArgs e)
		{
			if (CacheUpdate != null)
				CacheUpdate(sender, e);
		}

		private void CacheBuildStatusControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		//mam
		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			cancelCache = true;
		}
		//</mam>

		public class CacheUpdateEventArgs : EventArgs
		{
			public CacheUpdateEventArgs()
			{
				m_status = "";
			}

			public string	Status
			{
				get { return m_status; }
				set { m_status = value; }
			}

			private string	m_status;
		}
		#endregion //****** Event Handling ******/
	}
}
