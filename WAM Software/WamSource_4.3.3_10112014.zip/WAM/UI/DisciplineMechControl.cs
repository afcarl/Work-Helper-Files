using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for DisciplineMechControl.
	/// </summary>
	public class DisciplineMechControl : System.Windows.Forms.UserControl
	{
		private DisciplineMech m_discipline = null;
		private Drive.Windows.Forms.DataChangeMonitor
							m_dataMonitor = null;
		private bool		m_suppressUpdate = false;

		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPageComponentInfo;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox comboBoxConditionRanking;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBoxOriginalUL;
		private System.Windows.Forms.TextBox textBoxRepairCostCurVal;
		private System.Windows.Forms.TextBox textBoxOrgCostCurVal;
		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxDisciplineName;
		private System.Windows.Forms.TextBox textBoxRemainingUL;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBoxEvaluatedRemainingUL;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBoxAssessedBy;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxEquipmentNumber;
		private System.Windows.Forms.TextBox textBoxManufacturer;
		private System.Windows.Forms.TextBox textBoxRunHours;
		private System.Windows.Forms.TextBox textBoxInstallYear;
		private WAM.UI.PhotoControl photoControl1;
		private System.Windows.Forms.TextBox textBoxPhotoCaption;
		private System.Windows.Forms.Button buttonBrowsePhoto;
		private System.Windows.Forms.CheckBox checkBoxRunningAtInspect;
		private C1.Win.C1Input.C1DateEdit dateInspect;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveVibration;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveNoise;
		private WAM.UI.ItemStatusControl itemStatusMechRunningHot;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveLeaks;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveCorrosion;
		private WAM.UI.ItemStatusControl itemStatusMechCanRun;
		private WAM.UI.ItemStatusControl itemStatusMechSupportFunctional;
		private WAM.UI.ItemStatusControl itemStatusMechPartsMissing;
		private WAM.UI.ItemStatusControl itemStatusMechPartsAvailable;
		private WAM.UI.ItemStatusControl itemStatusMechAdequate;
		private WAM.UI.ItemStatusControl itemStatusMechMotorAmps;
		private System.Windows.Forms.GroupBox groupBox1;
		private WAM.UI.ItemStatusControl itemStatusInstrSystemsFunctional;
		private WAM.UI.ItemStatusControl itemStatusInstrAlarmsFunctional;
		private WAM.UI.ItemStatusControl itemStatusInstrPartsMissing;
		private WAM.UI.ItemStatusControl itemStatusInstrPartsAvailable;
		private WAM.UI.ItemStatusControl itemStatusElecExcessiveCorrosion;
		private WAM.UI.ItemStatusControl itemStatusElecCleanContacts;
		private WAM.UI.ItemStatusControl itemStatusElecPartsAvailable;
		private WAM.UI.ItemStatusControl itemStatusPipingExcessiveCorrosion;
		private WAM.UI.ItemStatusControl itemStatusPipingExcessiveLeaks;
		private WAM.UI.ItemStatusControl itemStatusPipingPaintGood;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label labelComments;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private System.Windows.Forms.Button buttonViewAssetList;
		private WAM.UI.DollarTextBox textBoxReplacementValue;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private WAM.UI.DollarTextBox textBoxAcquisitionCost;
		private System.Windows.Forms.TextBox textBoxBookValue;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox textBoxAnnualDepreciation;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox textBoxEvaluatedValue;
		private System.Windows.Forms.TextBox textBoxCumulativeDepreciation;
		private System.Windows.Forms.Label label22;
		private WAM.UI.NumberTextBox textBoxOriginalENR;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private WAM.UI.DollarTextBox textBoxSalvageValue;
		private System.Windows.Forms.Label label25;
		private WAM.UI.DollarTextBox textBoxAnnualMaintenanceCost;
		private System.Windows.Forms.CheckBox checkBoxOverrideAcquisitionCost;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox textBoxCurrentENR;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.TextBox textBoxLOS;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DisciplineMechControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxDisciplineName = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.label28 = new System.Windows.Forms.Label();
			this.checkBoxOverrideAcquisitionCost = new System.Windows.Forms.CheckBox();
			this.label17 = new System.Windows.Forms.Label();
			this.textBoxReplacementValue = new WAM.UI.DollarTextBox();
			this.comboBoxConditionRanking = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxAcquisitionCost = new WAM.UI.DollarTextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.textBoxInstallYear = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxEvaluatedRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxOriginalUL = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxRepairCostCurVal = new System.Windows.Forms.TextBox();
			this.textBoxOrgCostCurVal = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBoxAssessedBy = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.textBoxBookValue = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.checkBoxRunningAtInspect = new System.Windows.Forms.CheckBox();
			this.dateInspect = new C1.Win.C1Input.C1DateEdit();
			this.label11 = new System.Windows.Forms.Label();
			this.textBoxEquipmentNumber = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.textBoxManufacturer = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.textBoxRunHours = new System.Windows.Forms.TextBox();
			this.textBoxAnnualDepreciation = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.textBoxEvaluatedValue = new System.Windows.Forms.TextBox();
			this.textBoxCumulativeDepreciation = new System.Windows.Forms.TextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.textBoxOriginalENR = new WAM.UI.NumberTextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.textBoxSalvageValue = new WAM.UI.DollarTextBox();
			this.textBoxAnnualMaintenanceCost = new WAM.UI.DollarTextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.textBoxLOS = new System.Windows.Forms.TextBox();
			this.tabPageComponentInfo = new System.Windows.Forms.TabPage();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.labelComments = new System.Windows.Forms.Label();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.itemStatusPipingExcessiveLeaks = new WAM.UI.ItemStatusControl();
			this.itemStatusPipingPaintGood = new WAM.UI.ItemStatusControl();
			this.itemStatusPipingExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.itemStatusElecPartsAvailable = new WAM.UI.ItemStatusControl();
			this.itemStatusElecCleanContacts = new WAM.UI.ItemStatusControl();
			this.itemStatusElecExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.itemStatusInstrAlarmsFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrPartsAvailable = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrSystemsFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrPartsMissing = new WAM.UI.ItemStatusControl();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.itemStatusMechAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveLeaks = new WAM.UI.ItemStatusControl();
			this.itemStatusMechMotorAmps = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.itemStatusMechSupportFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusMechCanRun = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveNoise = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveVibration = new WAM.UI.ItemStatusControl();
			this.itemStatusMechRunningHot = new WAM.UI.ItemStatusControl();
			this.itemStatusMechPartsMissing = new WAM.UI.ItemStatusControl();
			this.itemStatusMechPartsAvailable = new WAM.UI.ItemStatusControl();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.buttonBrowsePhoto = new System.Windows.Forms.Button();
			this.textBoxPhotoCaption = new System.Windows.Forms.TextBox();
			this.photoControl1 = new WAM.UI.PhotoControl();
			this.buttonViewAssetList = new System.Windows.Forms.Button();
			this.label26 = new System.Windows.Forms.Label();
			this.textBoxCurrentENR = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).BeginInit();
			this.tabPageComponentInfo.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.TabStop = false;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 6;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.TabStop = false;
			this.textBoxProcessName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 4;
			this.label3.Text = "Component / Subasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.ReadOnly = true;
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 5;
			this.textBoxComponentName.TabStop = false;
			this.textBoxComponentName.Text = "";
			// 
			// textBoxDisciplineName
			// 
			this.textBoxDisciplineName.Location = new System.Drawing.Point(216, 88);
			this.textBoxDisciplineName.Name = "textBoxDisciplineName";
			this.textBoxDisciplineName.ReadOnly = true;
			this.textBoxDisciplineName.Size = new System.Drawing.Size(228, 20);
			this.textBoxDisciplineName.TabIndex = 7;
			this.textBoxDisciplineName.TabStop = false;
			this.textBoxDisciplineName.Text = "Mechanical/Electrical/Instrumentation/ Piping";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(84, 90);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Discipline:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageComponentInfo);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.tabControl.Size = new System.Drawing.Size(608, 360);
			this.tabControl.TabIndex = 13;
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.label28);
			this.tabPageMain.Controls.Add(this.checkBoxOverrideAcquisitionCost);
			this.tabPageMain.Controls.Add(this.label17);
			this.tabPageMain.Controls.Add(this.textBoxReplacementValue);
			this.tabPageMain.Controls.Add(this.comboBoxConditionRanking);
			this.tabPageMain.Controls.Add(this.label5);
			this.tabPageMain.Controls.Add(this.textBoxAcquisitionCost);
			this.tabPageMain.Controls.Add(this.label18);
			this.tabPageMain.Controls.Add(this.textBoxInstallYear);
			this.tabPageMain.Controls.Add(this.label16);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxOriginalUL);
			this.tabPageMain.Controls.Add(this.label8);
			this.tabPageMain.Controls.Add(this.label9);
			this.tabPageMain.Controls.Add(this.label10);
			this.tabPageMain.Controls.Add(this.label7);
			this.tabPageMain.Controls.Add(this.textBoxRepairCostCurVal);
			this.tabPageMain.Controls.Add(this.textBoxOrgCostCurVal);
			this.tabPageMain.Controls.Add(this.label6);
			this.tabPageMain.Controls.Add(this.textBoxAssessedBy);
			this.tabPageMain.Controls.Add(this.label12);
			this.tabPageMain.Controls.Add(this.textBoxBookValue);
			this.tabPageMain.Controls.Add(this.label19);
			this.tabPageMain.Controls.Add(this.checkBoxRunningAtInspect);
			this.tabPageMain.Controls.Add(this.dateInspect);
			this.tabPageMain.Controls.Add(this.label11);
			this.tabPageMain.Controls.Add(this.textBoxEquipmentNumber);
			this.tabPageMain.Controls.Add(this.label13);
			this.tabPageMain.Controls.Add(this.textBoxManufacturer);
			this.tabPageMain.Controls.Add(this.label14);
			this.tabPageMain.Controls.Add(this.label15);
			this.tabPageMain.Controls.Add(this.textBoxRunHours);
			this.tabPageMain.Controls.Add(this.textBoxAnnualDepreciation);
			this.tabPageMain.Controls.Add(this.label20);
			this.tabPageMain.Controls.Add(this.label21);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedValue);
			this.tabPageMain.Controls.Add(this.textBoxCumulativeDepreciation);
			this.tabPageMain.Controls.Add(this.label22);
			this.tabPageMain.Controls.Add(this.textBoxOriginalENR);
			this.tabPageMain.Controls.Add(this.label23);
			this.tabPageMain.Controls.Add(this.label24);
			this.tabPageMain.Controls.Add(this.textBoxSalvageValue);
			this.tabPageMain.Controls.Add(this.textBoxAnnualMaintenanceCost);
			this.tabPageMain.Controls.Add(this.label25);
			this.tabPageMain.Controls.Add(this.textBoxLOS);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.tabPageMain.Size = new System.Drawing.Size(600, 334);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// label28
			// 
			this.label28.Location = new System.Drawing.Point(44, 178);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(100, 16);
			this.label28.TabIndex = 15;
			this.label28.Text = "Level of Service:";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxOverrideAcquisitionCost
			// 
			this.checkBoxOverrideAcquisitionCost.Location = new System.Drawing.Point(220, 10);
			this.checkBoxOverrideAcquisitionCost.Name = "checkBoxOverrideAcquisitionCost";
			this.checkBoxOverrideAcquisitionCost.Size = new System.Drawing.Size(272, 16);
			this.checkBoxOverrideAcquisitionCost.TabIndex = 2;
			this.checkBoxOverrideAcquisitionCost.Text = "Override calculated acquisition cost";
			this.checkBoxOverrideAcquisitionCost.CheckedChanged += new System.EventHandler(this.checkBoxOverrideAcquisitionCost_CheckedChanged);
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(36, 34);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(108, 16);
			this.label17.TabIndex = 3;
			this.label17.Text = "&Replacement Value:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxReplacementValue
			// 
			this.textBoxReplacementValue.Location = new System.Drawing.Point(144, 32);
			this.textBoxReplacementValue.MaxLength = 30;
			this.textBoxReplacementValue.Name = "textBoxReplacementValue";
			this.textBoxReplacementValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxReplacementValue.TabIndex = 4;
			this.textBoxReplacementValue.Text = "$0";
			this.textBoxReplacementValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxReplacementValue.Value = new System.Decimal(new int[] {
																				  0,
																				  0,
																				  0,
																				  0});
			this.textBoxReplacementValue.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// comboBoxConditionRanking
			// 
			this.comboBoxConditionRanking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxConditionRanking.Location = new System.Drawing.Point(144, 200);
			this.comboBoxConditionRanking.Name = "comboBoxConditionRanking";
			this.comboBoxConditionRanking.Size = new System.Drawing.Size(164, 21);
			this.comboBoxConditionRanking.TabIndex = 18;
			this.comboBoxConditionRanking.SelectedIndexChanged += new System.EventHandler(this.comboBoxConditionRanking_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(40, 202);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 17;
			this.label5.Text = "&Condition Ranking:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAcquisitionCost
			// 
			this.textBoxAcquisitionCost.Location = new System.Drawing.Point(144, 8);
			this.textBoxAcquisitionCost.MaxLength = 30;
			this.textBoxAcquisitionCost.Name = "textBoxAcquisitionCost";
			this.textBoxAcquisitionCost.ReadOnly = true;
			this.textBoxAcquisitionCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxAcquisitionCost.TabIndex = 1;
			this.textBoxAcquisitionCost.Text = "$0";
			this.textBoxAcquisitionCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAcquisitionCost.Value = new System.Decimal(new int[] {
																				 0,
																				 0,
																				 0,
																				 0});
			this.textBoxAcquisitionCost.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(36, 10);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(108, 16);
			this.label18.TabIndex = 0;
			this.label18.Text = "&Acquisition Cost:";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInstallYear
			// 
			this.textBoxInstallYear.Location = new System.Drawing.Point(144, 104);
			this.textBoxInstallYear.MaxLength = 4;
			this.textBoxInstallYear.Name = "textBoxInstallYear";
			this.textBoxInstallYear.Size = new System.Drawing.Size(72, 20);
			this.textBoxInstallYear.TabIndex = 10;
			this.textBoxInstallYear.Text = "";
			this.textBoxInstallYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxInstallYear.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(48, 106);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(96, 16);
			this.label16.TabIndex = 9;
			this.label16.Text = "Installation &Year:";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEvaluatedRemainingUL
			// 
			this.textBoxEvaluatedRemainingUL.Location = new System.Drawing.Point(488, 200);
			this.textBoxEvaluatedRemainingUL.Name = "textBoxEvaluatedRemainingUL";
			this.textBoxEvaluatedRemainingUL.ReadOnly = true;
			this.textBoxEvaluatedRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedRemainingUL.TabIndex = 45;
			this.textBoxEvaluatedRemainingUL.Text = "";
			this.textBoxEvaluatedRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxRemainingUL
			// 
			this.textBoxRemainingUL.Location = new System.Drawing.Point(488, 176);
			this.textBoxRemainingUL.Name = "textBoxRemainingUL";
			this.textBoxRemainingUL.ReadOnly = true;
			this.textBoxRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxRemainingUL.TabIndex = 43;
			this.textBoxRemainingUL.Text = "";
			this.textBoxRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOriginalUL
			// 
			this.textBoxOriginalUL.Location = new System.Drawing.Point(144, 152);
			this.textBoxOriginalUL.MaxLength = 4;
			this.textBoxOriginalUL.Name = "textBoxOriginalUL";
			this.textBoxOriginalUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxOriginalUL.TabIndex = 14;
			this.textBoxOriginalUL.Text = "";
			this.textBoxOriginalUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxOriginalUL.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(40, 154);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(104, 16);
			this.label8.TabIndex = 13;
			this.label8.Text = "Original Useful &Life:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(368, 178);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(120, 16);
			this.label9.TabIndex = 42;
			this.label9.Text = "Remaining Useful Life:";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(312, 202);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(176, 16);
			this.label10.TabIndex = 44;
			this.label10.Text = "Evaluated Remaining Useful Life:";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(416, 154);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 16);
			this.label7.TabIndex = 40;
			this.label7.Text = "Repair Cost:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRepairCostCurVal
			// 
			this.textBoxRepairCostCurVal.Location = new System.Drawing.Point(488, 152);
			this.textBoxRepairCostCurVal.Name = "textBoxRepairCostCurVal";
			this.textBoxRepairCostCurVal.ReadOnly = true;
			this.textBoxRepairCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxRepairCostCurVal.TabIndex = 41;
			this.textBoxRepairCostCurVal.Text = "";
			this.textBoxRepairCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOrgCostCurVal
			// 
			this.textBoxOrgCostCurVal.Location = new System.Drawing.Point(488, 32);
			this.textBoxOrgCostCurVal.Name = "textBoxOrgCostCurVal";
			this.textBoxOrgCostCurVal.ReadOnly = true;
			this.textBoxOrgCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxOrgCostCurVal.TabIndex = 29;
			this.textBoxOrgCostCurVal.Text = "";
			this.textBoxOrgCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(408, 34);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(80, 16);
			this.label6.TabIndex = 28;
			this.label6.Text = "Current Value:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAssessedBy
			// 
			this.textBoxAssessedBy.Location = new System.Drawing.Point(488, 224);
			this.textBoxAssessedBy.Name = "textBoxAssessedBy";
			this.textBoxAssessedBy.Size = new System.Drawing.Size(104, 20);
			this.textBoxAssessedBy.TabIndex = 47;
			this.textBoxAssessedBy.Text = "";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(392, 226);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(96, 16);
			this.label12.TabIndex = 46;
			this.label12.Text = "Assessed &By:";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxBookValue
			// 
			this.textBoxBookValue.Location = new System.Drawing.Point(488, 56);
			this.textBoxBookValue.Name = "textBoxBookValue";
			this.textBoxBookValue.ReadOnly = true;
			this.textBoxBookValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxBookValue.TabIndex = 31;
			this.textBoxBookValue.Text = "";
			this.textBoxBookValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(408, 58);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(80, 16);
			this.label19.TabIndex = 30;
			this.label19.Text = "Book Value:";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxRunningAtInspect
			// 
			this.checkBoxRunningAtInspect.Location = new System.Drawing.Point(216, 298);
			this.checkBoxRunningAtInspect.Name = "checkBoxRunningAtInspect";
			this.checkBoxRunningAtInspect.Size = new System.Drawing.Size(180, 16);
			this.checkBoxRunningAtInspect.TabIndex = 27;
			this.checkBoxRunningAtInspect.Text = "Running at &time of inspection?";
			// 
			// dateInspect
			// 
			this.dateInspect.AllowDbNull = false;
			this.dateInspect.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate;
			this.dateInspect.Location = new System.Drawing.Point(144, 224);
			this.dateInspect.Name = "dateInspect";
			this.dateInspect.Size = new System.Drawing.Size(104, 20);
			this.dateInspect.TabIndex = 20;
			this.dateInspect.Tag = null;
			this.dateInspect.Value = new System.DateTime(2003, 7, 31, 0, 0, 0, 0);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(44, 226);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(100, 16);
			this.label11.TabIndex = 19;
			this.label11.Text = "&Date of Inspection:";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEquipmentNumber
			// 
			this.textBoxEquipmentNumber.Location = new System.Drawing.Point(144, 248);
			this.textBoxEquipmentNumber.MaxLength = 255;
			this.textBoxEquipmentNumber.Name = "textBoxEquipmentNumber";
			this.textBoxEquipmentNumber.Size = new System.Drawing.Size(136, 20);
			this.textBoxEquipmentNumber.TabIndex = 22;
			this.textBoxEquipmentNumber.Text = "";
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(36, 250);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(108, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "E&quipment Number:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxManufacturer
			// 
			this.textBoxManufacturer.Location = new System.Drawing.Point(144, 272);
			this.textBoxManufacturer.MaxLength = 255;
			this.textBoxManufacturer.Name = "textBoxManufacturer";
			this.textBoxManufacturer.Size = new System.Drawing.Size(216, 20);
			this.textBoxManufacturer.TabIndex = 24;
			this.textBoxManufacturer.Text = "";
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(68, 274);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(76, 16);
			this.label14.TabIndex = 23;
			this.label14.Text = "Manu&facturer:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(68, 298);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(76, 16);
			this.label15.TabIndex = 25;
			this.label15.Text = "Run &Hours:";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRunHours
			// 
			this.textBoxRunHours.Location = new System.Drawing.Point(144, 296);
			this.textBoxRunHours.MaxLength = 255;
			this.textBoxRunHours.Name = "textBoxRunHours";
			this.textBoxRunHours.Size = new System.Drawing.Size(68, 20);
			this.textBoxRunHours.TabIndex = 26;
			this.textBoxRunHours.Text = "";
			// 
			// textBoxAnnualDepreciation
			// 
			this.textBoxAnnualDepreciation.Location = new System.Drawing.Point(488, 80);
			this.textBoxAnnualDepreciation.Name = "textBoxAnnualDepreciation";
			this.textBoxAnnualDepreciation.ReadOnly = true;
			this.textBoxAnnualDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxAnnualDepreciation.TabIndex = 33;
			this.textBoxAnnualDepreciation.Text = "";
			this.textBoxAnnualDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(376, 82);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(112, 16);
			this.label20.TabIndex = 32;
			this.label20.Text = "Annual Depreciation:";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(384, 130);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(104, 16);
			this.label21.TabIndex = 37;
			this.label21.Text = "Evaluated Value:";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEvaluatedValue
			// 
			this.textBoxEvaluatedValue.Location = new System.Drawing.Point(488, 128);
			this.textBoxEvaluatedValue.Name = "textBoxEvaluatedValue";
			this.textBoxEvaluatedValue.ReadOnly = true;
			this.textBoxEvaluatedValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedValue.TabIndex = 39;
			this.textBoxEvaluatedValue.Text = "";
			this.textBoxEvaluatedValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxCumulativeDepreciation
			// 
			this.textBoxCumulativeDepreciation.Location = new System.Drawing.Point(488, 104);
			this.textBoxCumulativeDepreciation.Name = "textBoxCumulativeDepreciation";
			this.textBoxCumulativeDepreciation.ReadOnly = true;
			this.textBoxCumulativeDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxCumulativeDepreciation.TabIndex = 35;
			this.textBoxCumulativeDepreciation.Text = "";
			this.textBoxCumulativeDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(352, 106);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(136, 16);
			this.label22.TabIndex = 34;
			this.label22.Text = "Cumulative Depreciation:";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxOriginalENR
			// 
			this.textBoxOriginalENR.Location = new System.Drawing.Point(144, 128);
			this.textBoxOriginalENR.MaxLength = 4;
			this.textBoxOriginalENR.Name = "textBoxOriginalENR";
			this.textBoxOriginalENR.Size = new System.Drawing.Size(72, 20);
			this.textBoxOriginalENR.TabIndex = 12;
			this.textBoxOriginalENR.Text = "0";
			this.textBoxOriginalENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxOriginalENR.Value = ((long)(0));
			this.textBoxOriginalENR.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(40, 130);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(104, 16);
			this.label23.TabIndex = 11;
			this.label23.Text = "Original &ENR:";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(36, 58);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(108, 16);
			this.label24.TabIndex = 5;
			this.label24.Text = "&Salvage Value:";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxSalvageValue
			// 
			this.textBoxSalvageValue.Location = new System.Drawing.Point(144, 56);
			this.textBoxSalvageValue.MaxLength = 30;
			this.textBoxSalvageValue.Name = "textBoxSalvageValue";
			this.textBoxSalvageValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxSalvageValue.TabIndex = 6;
			this.textBoxSalvageValue.Text = "$0";
			this.textBoxSalvageValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxSalvageValue.Value = new System.Decimal(new int[] {
																			  0,
																			  0,
																			  0,
																			  0});
			this.textBoxSalvageValue.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// textBoxAnnualMaintenanceCost
			// 
			this.textBoxAnnualMaintenanceCost.Location = new System.Drawing.Point(144, 80);
			this.textBoxAnnualMaintenanceCost.MaxLength = 30;
			this.textBoxAnnualMaintenanceCost.Name = "textBoxAnnualMaintenanceCost";
			this.textBoxAnnualMaintenanceCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxAnnualMaintenanceCost.TabIndex = 8;
			this.textBoxAnnualMaintenanceCost.Text = "$0";
			this.textBoxAnnualMaintenanceCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAnnualMaintenanceCost.Value = new System.Decimal(new int[] {
																					   0,
																					   0,
																					   0,
																					   0});
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(4, 82);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(140, 16);
			this.label25.TabIndex = 7;
			this.label25.Text = "Annual &Maintenance Cost:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxLOS
			// 
			this.textBoxLOS.Location = new System.Drawing.Point(144, 176);
			this.textBoxLOS.MaxLength = 4;
			this.textBoxLOS.Name = "textBoxLOS";
			this.textBoxLOS.ReadOnly = true;
			this.textBoxLOS.Size = new System.Drawing.Size(72, 20);
			this.textBoxLOS.TabIndex = 16;
			this.textBoxLOS.TabStop = false;
			this.textBoxLOS.Text = "";
			this.textBoxLOS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tabPageComponentInfo
			// 
			this.tabPageComponentInfo.Controls.Add(this.textBoxComments);
			this.tabPageComponentInfo.Controls.Add(this.labelComments);
			this.tabPageComponentInfo.Controls.Add(this.groupBox4);
			this.tabPageComponentInfo.Controls.Add(this.groupBox3);
			this.tabPageComponentInfo.Controls.Add(this.groupBox2);
			this.tabPageComponentInfo.Controls.Add(this.groupBox1);
			this.tabPageComponentInfo.Location = new System.Drawing.Point(4, 22);
			this.tabPageComponentInfo.Name = "tabPageComponentInfo";
			this.tabPageComponentInfo.Size = new System.Drawing.Size(600, 334);
			this.tabPageComponentInfo.TabIndex = 1;
			this.tabPageComponentInfo.Text = "Component Information";
			// 
			// textBoxComments
			// 
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 260);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(592, 72);
			this.textBoxComments.TabIndex = 5;
			this.textBoxComments.Text = "";
			// 
			// labelComments
			// 
			this.labelComments.Location = new System.Drawing.Point(4, 244);
			this.labelComments.Name = "labelComments";
			this.labelComments.Size = new System.Drawing.Size(100, 16);
			this.labelComments.TabIndex = 4;
			this.labelComments.Text = "&Comments:";
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.itemStatusPipingExcessiveLeaks);
			this.groupBox4.Controls.Add(this.itemStatusPipingPaintGood);
			this.groupBox4.Controls.Add(this.itemStatusPipingExcessiveCorrosion);
			this.groupBox4.Location = new System.Drawing.Point(288, 172);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(296, 68);
			this.groupBox4.TabIndex = 3;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "&Piping";
			// 
			// itemStatusPipingExcessiveLeaks
			// 
			this.itemStatusPipingExcessiveLeaks.Caption = "Excessive leaks?";
			this.itemStatusPipingExcessiveLeaks.Location = new System.Drawing.Point(8, 32);
			this.itemStatusPipingExcessiveLeaks.Name = "itemStatusPipingExcessiveLeaks";
			this.itemStatusPipingExcessiveLeaks.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingExcessiveLeaks.Status = WAM.Data.ItemStatus.No;
			this.itemStatusPipingExcessiveLeaks.TabIndex = 1;
			// 
			// itemStatusPipingPaintGood
			// 
			this.itemStatusPipingPaintGood.Caption = "Paint in good condition?";
			this.itemStatusPipingPaintGood.Location = new System.Drawing.Point(8, 48);
			this.itemStatusPipingPaintGood.Name = "itemStatusPipingPaintGood";
			this.itemStatusPipingPaintGood.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingPaintGood.Status = WAM.Data.ItemStatus.No;
			this.itemStatusPipingPaintGood.TabIndex = 2;
			// 
			// itemStatusPipingExcessiveCorrosion
			// 
			this.itemStatusPipingExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusPipingExcessiveCorrosion.Location = new System.Drawing.Point(8, 16);
			this.itemStatusPipingExcessiveCorrosion.Name = "itemStatusPipingExcessiveCorrosion";
			this.itemStatusPipingExcessiveCorrosion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingExcessiveCorrosion.Status = WAM.Data.ItemStatus.No;
			this.itemStatusPipingExcessiveCorrosion.TabIndex = 0;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.itemStatusElecPartsAvailable);
			this.groupBox3.Controls.Add(this.itemStatusElecCleanContacts);
			this.groupBox3.Controls.Add(this.itemStatusElecExcessiveCorrosion);
			this.groupBox3.Location = new System.Drawing.Point(288, 96);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(296, 72);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "&Electrical";
			// 
			// itemStatusElecPartsAvailable
			// 
			this.itemStatusElecPartsAvailable.Caption = "Parts for maintenance available?";
			this.itemStatusElecPartsAvailable.Location = new System.Drawing.Point(8, 52);
			this.itemStatusElecPartsAvailable.Name = "itemStatusElecPartsAvailable";
			this.itemStatusElecPartsAvailable.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecPartsAvailable.Status = WAM.Data.ItemStatus.No;
			this.itemStatusElecPartsAvailable.TabIndex = 2;
			// 
			// itemStatusElecCleanContacts
			// 
			this.itemStatusElecCleanContacts.Caption = "Clean, well-maintained contacts?";
			this.itemStatusElecCleanContacts.Location = new System.Drawing.Point(8, 36);
			this.itemStatusElecCleanContacts.Name = "itemStatusElecCleanContacts";
			this.itemStatusElecCleanContacts.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecCleanContacts.Status = WAM.Data.ItemStatus.No;
			this.itemStatusElecCleanContacts.TabIndex = 1;
			// 
			// itemStatusElecExcessiveCorrosion
			// 
			this.itemStatusElecExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusElecExcessiveCorrosion.Location = new System.Drawing.Point(8, 20);
			this.itemStatusElecExcessiveCorrosion.Name = "itemStatusElecExcessiveCorrosion";
			this.itemStatusElecExcessiveCorrosion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecExcessiveCorrosion.Status = WAM.Data.ItemStatus.No;
			this.itemStatusElecExcessiveCorrosion.TabIndex = 0;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.itemStatusInstrAlarmsFunctional);
			this.groupBox2.Controls.Add(this.itemStatusInstrPartsAvailable);
			this.groupBox2.Controls.Add(this.itemStatusInstrSystemsFunctional);
			this.groupBox2.Controls.Add(this.itemStatusInstrPartsMissing);
			this.groupBox2.Location = new System.Drawing.Point(288, 4);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(296, 88);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "&Instrumentation";
			// 
			// itemStatusInstrAlarmsFunctional
			// 
			this.itemStatusInstrAlarmsFunctional.Caption = "Alarms functional?";
			this.itemStatusInstrAlarmsFunctional.Location = new System.Drawing.Point(8, 36);
			this.itemStatusInstrAlarmsFunctional.Name = "itemStatusInstrAlarmsFunctional";
			this.itemStatusInstrAlarmsFunctional.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrAlarmsFunctional.Status = WAM.Data.ItemStatus.No;
			this.itemStatusInstrAlarmsFunctional.TabIndex = 1;
			// 
			// itemStatusInstrPartsAvailable
			// 
			this.itemStatusInstrPartsAvailable.Caption = "Parts available for maintenance?";
			this.itemStatusInstrPartsAvailable.Location = new System.Drawing.Point(8, 68);
			this.itemStatusInstrPartsAvailable.Name = "itemStatusInstrPartsAvailable";
			this.itemStatusInstrPartsAvailable.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrPartsAvailable.Status = WAM.Data.ItemStatus.No;
			this.itemStatusInstrPartsAvailable.TabIndex = 3;
			// 
			// itemStatusInstrSystemsFunctional
			// 
			this.itemStatusInstrSystemsFunctional.Caption = "All critical indications functioning?";
			this.itemStatusInstrSystemsFunctional.Location = new System.Drawing.Point(8, 20);
			this.itemStatusInstrSystemsFunctional.Name = "itemStatusInstrSystemsFunctional";
			this.itemStatusInstrSystemsFunctional.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrSystemsFunctional.Status = WAM.Data.ItemStatus.No;
			this.itemStatusInstrSystemsFunctional.TabIndex = 0;
			// 
			// itemStatusInstrPartsMissing
			// 
			this.itemStatusInstrPartsMissing.Caption = "Equipment or parts missing?";
			this.itemStatusInstrPartsMissing.Location = new System.Drawing.Point(8, 52);
			this.itemStatusInstrPartsMissing.Name = "itemStatusInstrPartsMissing";
			this.itemStatusInstrPartsMissing.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrPartsMissing.Status = WAM.Data.ItemStatus.No;
			this.itemStatusInstrPartsMissing.TabIndex = 2;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.itemStatusMechAdequate);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveLeaks);
			this.groupBox1.Controls.Add(this.itemStatusMechMotorAmps);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveCorrosion);
			this.groupBox1.Controls.Add(this.itemStatusMechSupportFunctional);
			this.groupBox1.Controls.Add(this.itemStatusMechCanRun);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveNoise);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveVibration);
			this.groupBox1.Controls.Add(this.itemStatusMechRunningHot);
			this.groupBox1.Controls.Add(this.itemStatusMechPartsMissing);
			this.groupBox1.Controls.Add(this.itemStatusMechPartsAvailable);
			this.groupBox1.Location = new System.Drawing.Point(4, 4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(280, 236);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "&Mechanical";
			// 
			// itemStatusMechAdequate
			// 
			this.itemStatusMechAdequate.Caption = "Adequate for intended service?";
			this.itemStatusMechAdequate.Location = new System.Drawing.Point(8, 188);
			this.itemStatusMechAdequate.Name = "itemStatusMechAdequate";
			this.itemStatusMechAdequate.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechAdequate.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechAdequate.TabIndex = 9;
			// 
			// itemStatusMechExcessiveLeaks
			// 
			this.itemStatusMechExcessiveLeaks.Caption = "Excessive leaks?";
			this.itemStatusMechExcessiveLeaks.Location = new System.Drawing.Point(8, 68);
			this.itemStatusMechExcessiveLeaks.Name = "itemStatusMechExcessiveLeaks";
			this.itemStatusMechExcessiveLeaks.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveLeaks.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechExcessiveLeaks.TabIndex = 3;
			// 
			// itemStatusMechMotorAmps
			// 
			this.itemStatusMechMotorAmps.Caption = "Motor amps within ratings?";
			this.itemStatusMechMotorAmps.Location = new System.Drawing.Point(8, 216);
			this.itemStatusMechMotorAmps.Name = "itemStatusMechMotorAmps";
			this.itemStatusMechMotorAmps.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechMotorAmps.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechMotorAmps.TabIndex = 10;
			// 
			// itemStatusMechExcessiveCorrosion
			// 
			this.itemStatusMechExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusMechExcessiveCorrosion.Location = new System.Drawing.Point(8, 52);
			this.itemStatusMechExcessiveCorrosion.Name = "itemStatusMechExcessiveCorrosion";
			this.itemStatusMechExcessiveCorrosion.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveCorrosion.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechExcessiveCorrosion.TabIndex = 2;
			// 
			// itemStatusMechSupportFunctional
			// 
			this.itemStatusMechSupportFunctional.Caption = "Support equipment functional?";
			this.itemStatusMechSupportFunctional.Location = new System.Drawing.Point(8, 128);
			this.itemStatusMechSupportFunctional.Name = "itemStatusMechSupportFunctional";
			this.itemStatusMechSupportFunctional.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechSupportFunctional.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechSupportFunctional.TabIndex = 6;
			// 
			// itemStatusMechCanRun
			// 
			this.itemStatusMechCanRun.Caption = "Capable of running when inspected?";
			this.itemStatusMechCanRun.Location = new System.Drawing.Point(8, 100);
			this.itemStatusMechCanRun.Name = "itemStatusMechCanRun";
			this.itemStatusMechCanRun.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechCanRun.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechCanRun.TabIndex = 5;
			// 
			// itemStatusMechExcessiveNoise
			// 
			this.itemStatusMechExcessiveNoise.Caption = "Excessive noise?";
			this.itemStatusMechExcessiveNoise.Location = new System.Drawing.Point(8, 36);
			this.itemStatusMechExcessiveNoise.Name = "itemStatusMechExcessiveNoise";
			this.itemStatusMechExcessiveNoise.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveNoise.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechExcessiveNoise.TabIndex = 1;
			// 
			// itemStatusMechExcessiveVibration
			// 
			this.itemStatusMechExcessiveVibration.Caption = "Excessive vibration?";
			this.itemStatusMechExcessiveVibration.Location = new System.Drawing.Point(8, 20);
			this.itemStatusMechExcessiveVibration.Name = "itemStatusMechExcessiveVibration";
			this.itemStatusMechExcessiveVibration.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveVibration.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechExcessiveVibration.TabIndex = 0;
			// 
			// itemStatusMechRunningHot
			// 
			this.itemStatusMechRunningHot.Caption = "Running hot?";
			this.itemStatusMechRunningHot.Location = new System.Drawing.Point(8, 84);
			this.itemStatusMechRunningHot.Name = "itemStatusMechRunningHot";
			this.itemStatusMechRunningHot.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechRunningHot.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechRunningHot.TabIndex = 4;
			// 
			// itemStatusMechPartsMissing
			// 
			this.itemStatusMechPartsMissing.Caption = "Equipment or parts missing?";
			this.itemStatusMechPartsMissing.Location = new System.Drawing.Point(8, 144);
			this.itemStatusMechPartsMissing.Name = "itemStatusMechPartsMissing";
			this.itemStatusMechPartsMissing.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechPartsMissing.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechPartsMissing.TabIndex = 7;
			// 
			// itemStatusMechPartsAvailable
			// 
			this.itemStatusMechPartsAvailable.Caption = "Parts for maintenance available?";
			this.itemStatusMechPartsAvailable.Location = new System.Drawing.Point(8, 160);
			this.itemStatusMechPartsAvailable.Name = "itemStatusMechPartsAvailable";
			this.itemStatusMechPartsAvailable.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechPartsAvailable.Status = WAM.Data.ItemStatus.No;
			this.itemStatusMechPartsAvailable.TabIndex = 8;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.buttonBrowsePhoto);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption);
			this.tabPagePhoto.Controls.Add(this.photoControl1);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.tabPagePhoto.Size = new System.Drawing.Size(600, 334);
			this.tabPagePhoto.TabIndex = 2;
			this.tabPagePhoto.Text = "Photo";
			// 
			// buttonBrowsePhoto
			// 
			this.buttonBrowsePhoto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonBrowsePhoto.Location = new System.Drawing.Point(265, 304);
			this.buttonBrowsePhoto.Name = "buttonBrowsePhoto";
			this.buttonBrowsePhoto.TabIndex = 14;
			this.buttonBrowsePhoto.Text = "Browse";
			this.buttonBrowsePhoto.Click += new System.EventHandler(this.buttonBrowsePhoto_Click);
			// 
			// textBoxPhotoCaption
			// 
			this.textBoxPhotoCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption.Location = new System.Drawing.Point(8, 276);
			this.textBoxPhotoCaption.Name = "textBoxPhotoCaption";
			this.textBoxPhotoCaption.Size = new System.Drawing.Size(588, 20);
			this.textBoxPhotoCaption.TabIndex = 13;
			this.textBoxPhotoCaption.Text = "";
			this.textBoxPhotoCaption.Leave += new System.EventHandler(this.textBoxPhotoCaption_Leave);
			// 
			// photoControl1
			// 
			this.photoControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.photoControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.photoControl1.Image = null;
			this.photoControl1.Location = new System.Drawing.Point(4, 4);
			this.photoControl1.Name = "photoControl1";
			this.photoControl1.Size = new System.Drawing.Size(592, 268);
			this.photoControl1.TabIndex = 12;
			this.photoControl1.Text = "photoControl1";
			// 
			// buttonViewAssetList
			// 
			this.buttonViewAssetList.Location = new System.Drawing.Point(452, 87);
			this.buttonViewAssetList.Name = "buttonViewAssetList";
			this.buttonViewAssetList.TabIndex = 12;
			this.buttonViewAssetList.Text = "Asset List";
			this.buttonViewAssetList.Click += new System.EventHandler(this.buttonViewAssetList_Click);
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(456, 34);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(72, 16);
			this.label26.TabIndex = 10;
			this.label26.Text = "C&urrent ENR:";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentENR
			// 
			this.textBoxCurrentENR.Location = new System.Drawing.Point(528, 32);
			this.textBoxCurrentENR.Name = "textBoxCurrentENR";
			this.textBoxCurrentENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentENR.TabIndex = 11;
			this.textBoxCurrentENR.Text = "";
			this.textBoxCurrentENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxCurrentENR.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(456, 6);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(72, 16);
			this.label27.TabIndex = 8;
			this.label27.Text = "Current Year:";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(528, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 9;
			this.textBoxCurrentYear.TabStop = false;
			this.textBoxCurrentYear.Text = "";
			// 
			// DisciplineMechControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(616, 480);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.label27);
			this.Controls.Add(this.textBoxCurrentENR);
			this.Controls.Add(this.label26);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBoxDisciplineName);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.buttonViewAssetList);
			this.Name = "DisciplineMechControl";
			this.Size = new System.Drawing.Size(616, 480);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).EndInit();
			this.tabPageComponentInfo.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			LoadConditionRankBox();

			m_dataMonitor = 
				new Drive.Windows.Forms.DataChangeMonitor(this.Controls);
			base.OnLoad(e);
		}

		private void		LoadConditionRankBox()
		{
			comboBoxConditionRanking.BeginUpdate();
			comboBoxConditionRanking.DisplayMember = "DisplayMember";
			comboBoxConditionRanking.Items.Clear();
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.No),
				CondRank.No));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C0),
				CondRank.C0));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C1),
				CondRank.C1));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C2),
				CondRank.C2));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C3),
				CondRank.C3));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C4),
				CondRank.C4));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C5),
				CondRank.C5));
			comboBoxConditionRanking.EndUpdate();
		}

		public void			SetDiscipline(DisciplineMech disc)
		{
			if (m_discipline != null &&
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				SaveFormData();
			}
			m_discipline = disc;
			RefreshData();
		}

		protected override void OnVisibleChanged(EventArgs e)
		{
			if (this.Visible == false && m_discipline != null && 
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				// Save outstanding data
				SaveFormData();
			}

			base.OnVisibleChanged(e);
		}

		private bool		SaveFormData()
		{
			if (m_discipline == null)
				return true;

			m_discipline.OrgUsefulLife = 
				Drive.Convert.StringToShort(textBoxOriginalUL.Text);

			// Main Tab
			// -- User modifiable
			if (m_discipline.OverrideAcquisitionCost)
				m_discipline.AcquisitionCost = textBoxAcquisitionCost.Value;
			m_discipline.OverrideAcquisitionCost = checkBoxOverrideAcquisitionCost.Checked;
			m_discipline.ReplacementValue = textBoxReplacementValue.Value;
			m_discipline.SalvageValue = textBoxSalvageValue.Value;
			m_discipline.AnnualMaintCost = textBoxAnnualMaintenanceCost.Value;
			m_discipline.OriginalENR = 
				Drive.Convert.StringToInt(textBoxOriginalENR.Text);
			m_discipline.CurrentENR = 
				Drive.Convert.StringToInt(textBoxCurrentENR.Text);

			// miscellaneous information
			m_discipline.DateInspected = ((DateTime)dateInspect.Value).Date;
			m_discipline.AssessedBy = textBoxAssessedBy.Text;
			m_discipline.EquipmentNumber = textBoxEquipmentNumber.Text;
			m_discipline.Manufacturer = textBoxManufacturer.Text;
			m_discipline.RunHours = textBoxRunHours.Text;
			m_discipline.InstallationYear = 
				Drive.Convert.StringToShort(textBoxInstallYear.Text);
			m_discipline.RunningAtInspect = checkBoxRunningAtInspect.Checked;
			m_discipline.CaptionPhoto = textBoxPhotoCaption.Text;

			// Component Info tab
			m_discipline.MechExcessiveVibration = itemStatusMechExcessiveVibration.Status;
			m_discipline.MechExcessiveNoise = itemStatusMechExcessiveNoise.Status;
			m_discipline.MechExcessiveCorrosion = itemStatusMechExcessiveCorrosion.Status;
			m_discipline.MechExcessiveLeaks = itemStatusMechExcessiveLeaks.Status;
			m_discipline.MechRunningHot = itemStatusMechRunningHot.Status;
			m_discipline.MechCanRunWhenInspected = itemStatusMechCanRun.Status;
			m_discipline.MechSupportIsFunctional = itemStatusMechSupportFunctional.Status;
			m_discipline.MechPartsMissing = itemStatusMechPartsMissing.Status;
			m_discipline.MechPartsAvailable = itemStatusMechPartsAvailable.Status;
			m_discipline.MechAdequate = itemStatusMechAdequate.Status;
			m_discipline.MechMotorAmps = itemStatusMechMotorAmps.Status;
			m_discipline.InstrIndicationFunctional = itemStatusInstrSystemsFunctional.Status;
			m_discipline.InstrAlarmFunctional = itemStatusInstrAlarmsFunctional.Status;
			m_discipline.InstrPartsMissing = itemStatusInstrPartsMissing.Status;
			m_discipline.InstrPartsAvailable = itemStatusInstrPartsAvailable.Status;
			m_discipline.ElecExcessiveCorrosion = itemStatusElecExcessiveCorrosion.Status;
			m_discipline.ElecCleanContacts = itemStatusElecCleanContacts.Status;
			m_discipline.ElecPartsAvailable = itemStatusElecPartsAvailable.Status;
			m_discipline.PipeExcessiveCorrosion = itemStatusPipingExcessiveCorrosion.Status;
			m_discipline.PipeExcessiveLeaks = itemStatusPipingExcessiveLeaks.Status;
			m_discipline.PipePaintGood = itemStatusPipingPaintGood.Status;
			m_discipline.Comments = textBoxComments.Text;

			m_discipline.Save();
			m_dataMonitor.Dirty = false;
			return true;
		}

		private void		SelectConditionRank()
		{
			for (int pos = 0; pos < comboBoxConditionRanking.Items.Count; pos++)
			{
				if (m_discipline.ConditionRanking == 
					((CondRank)((ListItem)comboBoxConditionRanking.Items[pos]).Value))
				{
					comboBoxConditionRanking.SelectedIndex = pos;
					return;
				}
			}

			comboBoxConditionRanking.SelectedIndex = 0;
		}

		public void			RefreshData()
		{
			if (m_discipline == null)
				return;

			m_suppressUpdate = true;
			// Ignore UI change events
			m_dataMonitor.IgnoreChanges = true;
			tabControl.SelectedIndex = 0;

			MajorComponent component = MajorComponentCache.Cached.GetMajorComponent(m_discipline.ComponentID);
			TreatmentProcess process = TreatmentProcessCache.Cached.GetTreatmentProcess(component.ProcessID);
			Facility facility = FacilityCache.Cached.GetFacility(process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();
			textBoxLOS.Text = EnumHandlers.GetLOSShort(component.LOS);

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = component.Name;

			// Main Tab
			// -- User modifiable
			textBoxAcquisitionCost.Value = m_discipline.AcquisitionCost;
			textBoxAcquisitionCost.ReadOnly = !m_discipline.OverrideAcquisitionCost;
			checkBoxOverrideAcquisitionCost.Checked = m_discipline.OverrideAcquisitionCost;
			textBoxReplacementValue.Value = m_discipline.ReplacementValue;
			textBoxSalvageValue.Value = m_discipline.SalvageValue;
			textBoxAnnualMaintenanceCost.Value = m_discipline.AnnualMaintCost;
			textBoxInstallYear.Text = m_discipline.InstallationYear.ToString();
			textBoxOriginalENR.Text = m_discipline.OriginalENR.ToString();
			textBoxCurrentENR.Text = m_discipline.CurrentENR.ToString();
			textBoxOriginalUL.Text = m_discipline.OrgUsefulLife.ToString();

			SelectConditionRank();

			dateInspect.Value = m_discipline.DateInspected;
			textBoxEquipmentNumber.Text = m_discipline.EquipmentNumber;
			textBoxManufacturer.Text = m_discipline.Manufacturer;
			textBoxRunHours.Text = m_discipline.RunHours;
			checkBoxRunningAtInspect.Checked = m_discipline.RunningAtInspect;
			textBoxAssessedBy.Text = m_discipline.AssessedBy;

			// Photo tab
			textBoxPhotoCaption.Text = m_discipline.CaptionPhoto;

			// -- calculated
			UpdateCalculatedProperties();

			// Component Info tab
			itemStatusMechExcessiveVibration.Status = m_discipline.MechExcessiveVibration;
			itemStatusMechExcessiveNoise.Status = m_discipline.MechExcessiveNoise;
			itemStatusMechExcessiveCorrosion.Status = m_discipline.MechExcessiveCorrosion;
			itemStatusMechExcessiveLeaks.Status = m_discipline.MechExcessiveLeaks;
			itemStatusMechRunningHot.Status = m_discipline.MechRunningHot;
			itemStatusMechCanRun.Status = m_discipline.MechCanRunWhenInspected;
			itemStatusMechSupportFunctional.Status = m_discipline.MechSupportIsFunctional;
			itemStatusMechPartsMissing.Status = m_discipline.MechPartsMissing;
			itemStatusMechPartsAvailable.Status = m_discipline.MechPartsAvailable;
			itemStatusMechAdequate.Status = m_discipline.MechAdequate;
			itemStatusMechMotorAmps.Status = m_discipline.MechMotorAmps;
			itemStatusInstrSystemsFunctional.Status = m_discipline.InstrIndicationFunctional;
			itemStatusInstrAlarmsFunctional.Status = m_discipline.InstrAlarmFunctional;
			itemStatusInstrPartsMissing.Status = m_discipline.InstrPartsMissing;
			itemStatusInstrPartsAvailable.Status = m_discipline.InstrPartsAvailable;
			itemStatusElecExcessiveCorrosion.Status = m_discipline.ElecExcessiveCorrosion;
			itemStatusElecCleanContacts.Status = m_discipline.ElecCleanContacts;
			itemStatusElecPartsAvailable.Status = m_discipline.ElecPartsAvailable;
			itemStatusPipingExcessiveCorrosion.Status = m_discipline.PipeExcessiveCorrosion;
			itemStatusPipingExcessiveLeaks.Status = m_discipline.PipeExcessiveLeaks;
			itemStatusPipingPaintGood.Status = m_discipline.PipePaintGood;
			textBoxComments.Text = m_discipline.Comments;

			m_dataMonitor.IgnoreChanges = false;
			m_dataMonitor.Dirty = false;
			m_suppressUpdate = false;
		}

		private void		UpdateCalculatedProperties()
		{
			textBoxOrgCostCurVal.Text = 
				m_discipline.GetCurrentValue().ToString("$#,##0");
			textBoxBookValue.Text = 
				m_discipline.GetBookValue().ToString("$#,##0");
			textBoxAnnualDepreciation.Text = 
				m_discipline.GetAnnualDepreciation().ToString("$#,##0");
			textBoxCumulativeDepreciation.Text = 
				m_discipline.GetCumulativeDepreciation().ToString("$#,##0");
			textBoxEvaluatedValue.Text = 
				m_discipline.GetEvaluatedValue().ToString("$#,##0");
			textBoxRepairCostCurVal.Text = 
				m_discipline.GetRepairCost().ToString("$#,##0");
			textBoxRemainingUL.Text = 
				m_discipline.GetRemainingUsefulLife().ToString();
			textBoxEvaluatedRemainingUL.Text = 
				m_discipline.GetEvaluatedRemainingUsefulLife().ToString();
		}

		private CondRank	GetSelectedConditionRanking()
		{
			ListItem		listItem = comboBoxConditionRanking.SelectedItem as ListItem;

			if (listItem == null)
				return CondRank.No;

			return (CondRank)listItem.Value;
		}

		private void comboBoxConditionRanking_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			// Update the condition ranking on the discipline object immediately
			m_discipline.ConditionRanking = GetSelectedConditionRanking();

			// Update calculated properties
			UpdateCalculatedProperties();
		}

		private void checkBoxOverrideAcquisitionCost_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			m_discipline.OverrideAcquisitionCost = 
				checkBoxOverrideAcquisitionCost.Checked;
			textBoxAcquisitionCost.ReadOnly = 
				!m_discipline.OverrideAcquisitionCost;
			UpdateCalculatedProperties();
		}

		private void OnDependentCalcField_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			if (object.ReferenceEquals(sender, textBoxAcquisitionCost))
			{
				if (m_discipline.OverrideAcquisitionCost)
					m_discipline.AcquisitionCost = textBoxAcquisitionCost.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxReplacementValue))
			{
				m_discipline.ReplacementValue = textBoxReplacementValue.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxSalvageValue))
			{
				m_discipline.SalvageValue = textBoxSalvageValue.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxAnnualMaintenanceCost))
			{
				m_discipline.AnnualMaintCost = textBoxAnnualMaintenanceCost.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxOriginalENR))
			{
				m_discipline.OriginalENR = 
					Drive.Convert.StringToInt(textBoxOriginalENR.Text);
				textBoxOriginalENR.Text = m_discipline.OriginalENR.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxCurrentENR))
			{
				m_discipline.CurrentENR = 
					Drive.Convert.StringToInt(textBoxCurrentENR.Text);
				textBoxCurrentENR.Text = m_discipline.CurrentENR.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxOriginalUL))
			{
				m_discipline.OrgUsefulLife = 
					Drive.Convert.StringToShort(textBoxOriginalUL.Text);
				textBoxOriginalUL.Text = m_discipline.OrgUsefulLife.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxInstallYear))
			{
				m_discipline.InstallationYear = 
					Drive.Convert.StringToShort(textBoxInstallYear.Text);
				textBoxInstallYear.Text = m_discipline.InstallationYear.ToString();
			}

			UpdateCalculatedProperties();
		}

		private void buttonViewAssetList_Click(object sender, System.EventArgs e)
		{
			if (ViewAssets != null)
				ViewAssets(m_discipline, e);
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_discipline != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption.Text = m_discipline.CaptionPhoto;
					photoControl1.Image = m_discipline.GetPhoto();
					if (photoControl1.Image == null)
						buttonBrowsePhoto.Text = "Browse";
					else
						buttonBrowsePhoto.Text = "Delete";
				}
				else
				{
					textBoxPhotoCaption.Text = "";
					photoControl1.Image = null;
					buttonBrowsePhoto.Text = "Browse";
				}
			}
		}

		#region /***** Photo Tab *****/
		private void buttonBrowsePhoto_Click(object sender, System.EventArgs e)
		{
			if (photoControl1.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_discipline.GetImagePath();

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_discipline.CaptionPhoto = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption.Text = m_discipline.CaptionPhoto;
					m_discipline.Save();
					buttonBrowsePhoto.Text = "Delete";
					photoControl1.Image = m_discipline.GetPhoto();
				}
			}
			else
			{
				photoControl1.Image = null;
				string		targetPath = m_discipline.GetImagePath();

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_discipline.CaptionPhoto = "";
				textBoxPhotoCaption.Text = "";
				buttonBrowsePhoto.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline.CaptionPhoto != textBoxPhotoCaption.Text)
			{
				m_discipline.CaptionPhoto = textBoxPhotoCaption.Text;
				m_discipline.Save();
			}
		}
		#endregion /***** Photo Tab *****/

		public delegate void ViewAssetHandler(object sender, EventArgs e);
		public event ViewAssetHandler ViewAssets;
	}
}
