using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;
using WAM.Logic;
using Drive.Collections;
using ADODB;
using System.Data;

//mam 03202012
using C1.Win.C1FlexGrid;
using C1.C1Excel;

//mam 102309
//using System.Data.OleDb;

using System.Text;

//mam - added the following:
using Drive.Configuration;
using C1.Win.C1Report;
//</mam>

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportFilterForm.
	/// </summary>
	public class ReportFilterForm : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		UnitFilter[]	m_filters = null;
		private bool	m_initialized = false;

		//mam
		public static Reports.UI.C1ReportDisplayerForm MyReportDisplayer;
		//private static C1Report reportTest = new C1Report();
		ListItem selectedSortItem1 = null;
		ListItem selectedSortItem2 = null;
		ListItem selectedSortItem3 = null;
		ListItem selectedSortItem4 = null;
		ListItem selectedSortItem5 = null;
		bool wasAssetReport = false;
		//</mam>

		//mam 050806
		int treeNodeIndex = 0;

		//mam
		ReportPrintStatus reportPrintStatusForm = new ReportPrintStatus();
		WAM.UI.ReportPrintStatus.ReportUpdateEventArgs eventArgs = new WAM.UI.ReportPrintStatus.ReportUpdateEventArgs();
		private string newTemplateNameFromForm;
		private int optionAutoSave = 1;
		//private int optionAutoSaveFromForm;
		private int currentTemplateID = 0;
		private int reportTypeCount = 0;
		private bool editingFilter = false;
		private bool autoChecking = false;
		private bool savingTemplate = false;
		private bool dirtyTemplate = false;
		private bool dirtyNodes = false;
		private bool dirtyFilters = false;
		private bool forceSave = false;
		private bool allowCheckDirty = true;
		private string selectedFilters = "";
		private string selectedSortOrder = "";
		//</mam>

		//mam
		private string emptyListBoxValue = "< Click the Add button to add a filter item >";
		private ArrayList		printItems = new ArrayList();
		private ArrayList		filteredItems = new ArrayList();
		private ArrayList		applyFilteredItems = new ArrayList();
		private ArrayList		currentReport = new ArrayList();

		private ArrayList		SelectedFac = new ArrayList();
		private ArrayList		SelectedProc = new ArrayList();
		private ArrayList		SelectedComp = new ArrayList();
		private ArrayList		SelectedDiscMech = new ArrayList();
		private ArrayList		SelectedDiscLand = new ArrayList();
		private ArrayList		SelectedDiscStruct = new ArrayList();
		private ArrayList		SelectedDiscPipe = new ArrayList();
		private ArrayList		SelectedDiscNode = new ArrayList();
		//private ArrayList		SelectedDiscAll = new ArrayList();
		private ArrayList		SelectedDiscAllLand = new ArrayList();
		private ArrayList		SelectedDiscAllMech = new ArrayList();
		private ArrayList		SelectedDiscAllStruct = new ArrayList();
		private ArrayList		SelectedDiscAllNode = new ArrayList();
		private ArrayList		SelectedDiscAllPipe = new ArrayList();
		private ArrayList		SelectedAsset = new ArrayList();
		private ArrayList		nodesExpanded = new ArrayList();
		private static ArrayList		nodesExpandedMainForm = new ArrayList();
		private ArrayList		nodesExpandedResurrect = new ArrayList();
		private NodeType		currentNodeType = new NodeType();
		private NodeType		currentApplyFilterNodeType = new NodeType();
		private TreeNode		nodeHitTest;
		private TreeNode		nodeSelected;
		private int				checkedNodeCount = 0;
		private bool			checkOnClick = false;
		private System.Drawing.Color	colorDisabled = System.Drawing.Color.Gray;
		private static C1Report reportAllPages = new C1Report();
		private System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
		//</mam>

		//mam 03202012
		private NodeTypeHandler.NodeTypeReport previousReportType;
		private ArrayList SelectedFacImport = new ArrayList();
		private ArrayList SelectedProcImport = new ArrayList();
		private ArrayList SelectedCompImport = new ArrayList();
		private ArrayList SelectedDiscMechImport = new ArrayList();
		private ArrayList SelectedDiscLandImport = new ArrayList();
		private ArrayList SelectedDiscStructImport = new ArrayList();
		private ArrayList SelectedDiscPipeImport = new ArrayList();
		private ArrayList SelectedDiscNodeImport = new ArrayList();
		private ArrayList SelectedAssetImport = new ArrayList();
		private ArrayList nodesExpandedImport = new ArrayList();

		private System.Windows.Forms.Button buttonPrint;
		private System.Windows.Forms.Button buttonPreview;
		private System.Windows.Forms.Button buttonCancelOrig;
		private System.Windows.Forms.Panel panelReportForm1;
		private System.Windows.Forms.Panel panelReportForm2;
		private System.Windows.Forms.Panel panelFilter;
		private System.Windows.Forms.Button buttonNext;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonBack;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button buttonCancel1;
		private System.Windows.Forms.Button buttonCancel2;
		private System.Windows.Forms.TreeView treeViewSpecificUnits;
		private System.Windows.Forms.Panel panelTree;
		private System.Windows.Forms.CheckedListBox listBoxMatrixColumns;
		private System.Windows.Forms.Panel panelMatrixColumns;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.ComboBox comboBoxReportFormat;
		private System.Windows.Forms.Panel panelReportFormat;
		private System.Windows.Forms.ComboBox comboBoxReportType;
		private System.Windows.Forms.ImageList imageListTree;
		private System.Windows.Forms.Panel panelFilterYesNo;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.RadioButton radioFilterNo;
		private System.Windows.Forms.RadioButton radioFilterYes;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.GroupBox groupBoxAddFilter;
		private System.Windows.Forms.Panel panel22;
		private System.Windows.Forms.GroupBox groupBoxApplyLevel;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Panel panelListBox;
		private System.Windows.Forms.ListBox listBoxCriteria;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Button buttonEditCriteria;
		private System.Windows.Forms.Button buttonRemoveCriteria;
		private System.Windows.Forms.Button buttonClearCriteria;
		private System.Windows.Forms.RadioButton radioMatchAny;
		private System.Windows.Forms.RadioButton radioMatchAllCriteria;
		private System.Windows.Forms.ComboBox comboBoxApplyFiltersTo;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel23;
		private System.Windows.Forms.Panel panel24;
		private WAM.UI.FilterBuilderForm2 filterBuilderForm21;
		private System.Windows.Forms.GroupBox groupBoxCriteria;
		private System.Windows.Forms.Button buttonSelectAll;
		private System.Windows.Forms.Button buttonClearAll;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.ContextMenu mnuContextMenu;
		private System.Windows.Forms.MenuItem mnuItemSelectAll;
		private System.Windows.Forms.MenuItem mnuItemExpandAll;
		private System.Windows.Forms.MenuItem mnuItemClearAll;
		private System.Windows.Forms.MenuItem mnuItemCollapseAll;
		private System.Windows.Forms.MenuItem mnuItemSelectUnder;
		private System.Windows.Forms.MenuItem mnuItemClearUnder;
		private System.Windows.Forms.MenuItem mnuItemView;
		private System.Windows.Forms.MenuItem mnuItemViewNormal;
		private System.Windows.Forms.MenuItem mnuItemViewSelected;
		private System.Windows.Forms.MenuItem mnuItemViewReport;
		private System.Windows.Forms.MenuItem mnuItemViewMainTree;
		private System.Windows.Forms.GroupBox groupBoxSortBy;
		private System.Windows.Forms.Panel panelSortBy;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.RadioButton radioDesc3;
		private System.Windows.Forms.RadioButton radioAsc3;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.RadioButton radioDesc2;
		private System.Windows.Forms.RadioButton radioAsc2;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.RadioButton radioDesc1;
		private System.Windows.Forms.RadioButton radioAsc1;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.ComboBox comboBoxSortBy3;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.ComboBox comboBoxSortBy2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox comboBoxSortBy1;
		private System.Windows.Forms.RadioButton radioSortFields;
		private System.Windows.Forms.RadioButton radioSortTree;
		private System.Windows.Forms.GroupBox groupBoxIncludePhotos;
		private System.Windows.Forms.CheckBox checkBoxIncludePhotos;
		private System.Windows.Forms.Panel panelToolbar;
		private System.Windows.Forms.ComboBox comboBoxReportTemplate;
		private System.Windows.Forms.PictureBox pictureBoxTemplateSave;
		private System.Windows.Forms.PictureBox pictureBoxTemplateSaveAs;
		private System.Windows.Forms.PictureBox pictureBoxTemplateEdit;
		private System.Windows.Forms.PictureBox pictureBoxTemplateNew;
		private System.Windows.Forms.PictureBox pictureBoxTemplateDelete;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.PictureBox pictureBoxTemplateOptions;
		private System.Windows.Forms.Panel panel25;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Panel panel17;
		private System.Windows.Forms.RadioButton radioDesc5;
		private System.Windows.Forms.RadioButton radioAsc5;
		private System.Windows.Forms.ComboBox comboBoxSortBy5;
		private System.Windows.Forms.RadioButton radioDesc4;
		private System.Windows.Forms.RadioButton radioAsc4;
		private System.Windows.Forms.ComboBox comboBoxSortBy4;
		public System.Windows.Forms.Timer timer;
		private System.Windows.Forms.GroupBox groupBoxIncludeRetired;
		private System.Windows.Forms.CheckBox checkBoxIncludeRetired;
		private System.Windows.Forms.TreeView treeViewCriteria;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
		private System.Windows.Forms.Label labelReportTypeCount;
		private System.Windows.Forms.Button buttonExport;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label labelCheckedNodeCount;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCopy;
		private System.Windows.Forms.PictureBox pictureBoxToolbarSave;
		private System.Windows.Forms.Button buttonPrint2;
		private System.Windows.Forms.Button buttonPreview2;
		private System.ComponentModel.IContainer components;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public ReportFilterForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//UI.CacheBuildStatusControl.CacheUpdateEventArgs
			//	eventArgs = new WAM.UI.CacheBuildStatusControl.CacheUpdateEventArgs();
			//WAM.UI.ReportPrintStatus.ReportUpdateEventArgs eventArgs = new WAM.UI.ReportPrintStatus.ReportUpdateEventArgs();

			this.treeViewSpecificUnits.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.SetDirtyNodes);

			this.buttonRemoveCriteria.Click += new System.EventHandler(this.SetDirtyFilter);
			this.buttonClearCriteria.Click += new System.EventHandler(this.SetDirtyFilter);
			this.filterBuilderForm21.buttonAddCriteria.Click += new System.EventHandler(this.SetDirtyFilter);

			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioFilterYes.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioFilterNo.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxApplyFiltersTo.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioMatchAny.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioMatchAllCriteria.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);

			this.checkBoxIncludePhotos.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioSortTree.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioSortFields.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);

			this.comboBoxSortBy1.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxSortBy2.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxSortBy3.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxSortBy4.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.comboBoxSortBy5.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);

			this.radioAsc1.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioAsc2.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioAsc3.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioAsc4.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioAsc5.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);

			this.radioDesc1.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioDesc2.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioDesc3.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioDesc4.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);
			this.radioDesc5.CheckedChanged += new System.EventHandler(this.SetDirtyTemplate);

			this.comboBoxReportFormat.SelectedIndexChanged += new System.EventHandler(this.SetDirtyTemplate);
			//this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportFilterForm));
			this.buttonPrint = new System.Windows.Forms.Button();
			this.buttonCancelOrig = new System.Windows.Forms.Button();
			this.buttonPreview = new System.Windows.Forms.Button();
			this.panelReportForm1 = new System.Windows.Forms.Panel();
			this.labelCheckedNodeCount = new System.Windows.Forms.Label();
			this.labelReportTypeCount = new System.Windows.Forms.Label();
			this.buttonClearAll = new System.Windows.Forms.Button();
			this.buttonSelectAll = new System.Windows.Forms.Button();
			this.panel23 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panelFilterYesNo = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.radioFilterNo = new System.Windows.Forms.RadioButton();
			this.radioFilterYes = new System.Windows.Forms.RadioButton();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBoxReportType = new System.Windows.Forms.ComboBox();
			this.panelTree = new System.Windows.Forms.Panel();
			this.treeViewSpecificUnits = new System.Windows.Forms.TreeView();
			this.panelFilter = new System.Windows.Forms.Panel();
			this.groupBoxAddFilter = new System.Windows.Forms.GroupBox();
			this.filterBuilderForm21 = new WAM.UI.FilterBuilderForm2();
			this.groupBoxCriteria = new System.Windows.Forms.GroupBox();
			this.radioMatchAny = new System.Windows.Forms.RadioButton();
			this.radioMatchAllCriteria = new System.Windows.Forms.RadioButton();
			this.buttonEditCriteria = new System.Windows.Forms.Button();
			this.buttonRemoveCriteria = new System.Windows.Forms.Button();
			this.buttonClearCriteria = new System.Windows.Forms.Button();
			this.label19 = new System.Windows.Forms.Label();
			this.panelListBox = new System.Windows.Forms.Panel();
			this.treeViewCriteria = new System.Windows.Forms.TreeView();
			this.listBoxCriteria = new System.Windows.Forms.ListBox();
			this.groupBoxApplyLevel = new System.Windows.Forms.GroupBox();
			this.label18 = new System.Windows.Forms.Label();
			this.comboBoxApplyFiltersTo = new System.Windows.Forms.ComboBox();
			this.label17 = new System.Windows.Forms.Label();
			this.panel22 = new System.Windows.Forms.Panel();
			this.label10 = new System.Windows.Forms.Label();
			this.buttonNext = new System.Windows.Forms.Button();
			this.buttonCancel1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.panelReportForm2 = new System.Windows.Forms.Panel();
			this.buttonExport = new System.Windows.Forms.Button();
			this.groupBoxIncludePhotos = new System.Windows.Forms.GroupBox();
			this.checkBoxIncludePhotos = new System.Windows.Forms.CheckBox();
			this.groupBoxIncludeRetired = new System.Windows.Forms.GroupBox();
			this.checkBoxIncludeRetired = new System.Windows.Forms.CheckBox();
			this.groupBoxSortBy = new System.Windows.Forms.GroupBox();
			this.panelSortBy = new System.Windows.Forms.Panel();
			this.panel16 = new System.Windows.Forms.Panel();
			this.radioDesc5 = new System.Windows.Forms.RadioButton();
			this.radioAsc5 = new System.Windows.Forms.RadioButton();
			this.comboBoxSortBy5 = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.panel17 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.radioDesc4 = new System.Windows.Forms.RadioButton();
			this.radioAsc4 = new System.Windows.Forms.RadioButton();
			this.comboBoxSortBy4 = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.panel15 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.radioDesc3 = new System.Windows.Forms.RadioButton();
			this.radioAsc3 = new System.Windows.Forms.RadioButton();
			this.panel9 = new System.Windows.Forms.Panel();
			this.radioDesc2 = new System.Windows.Forms.RadioButton();
			this.radioAsc2 = new System.Windows.Forms.RadioButton();
			this.panel7 = new System.Windows.Forms.Panel();
			this.radioDesc1 = new System.Windows.Forms.RadioButton();
			this.radioAsc1 = new System.Windows.Forms.RadioButton();
			this.panel6 = new System.Windows.Forms.Panel();
			this.comboBoxSortBy3 = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.comboBoxSortBy2 = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.comboBoxSortBy1 = new System.Windows.Forms.ComboBox();
			this.radioSortFields = new System.Windows.Forms.RadioButton();
			this.radioSortTree = new System.Windows.Forms.RadioButton();
			this.buttonPrint2 = new System.Windows.Forms.Button();
			this.panel24 = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel13 = new System.Windows.Forms.Panel();
			this.buttonBack = new System.Windows.Forms.Button();
			this.panelReportFormat = new System.Windows.Forms.Panel();
			this.panelMatrixColumns = new System.Windows.Forms.Panel();
			this.listBoxMatrixColumns = new System.Windows.Forms.CheckedListBox();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBoxReportFormat = new System.Windows.Forms.ComboBox();
			this.buttonPreview2 = new System.Windows.Forms.Button();
			this.buttonCancel2 = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.mnuContextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuItemSelectAll = new System.Windows.Forms.MenuItem();
			this.mnuItemClearAll = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuItemSelectUnder = new System.Windows.Forms.MenuItem();
			this.mnuItemClearUnder = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.mnuItemExpandAll = new System.Windows.Forms.MenuItem();
			this.mnuItemCollapseAll = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.mnuItemView = new System.Windows.Forms.MenuItem();
			this.mnuItemViewNormal = new System.Windows.Forms.MenuItem();
			this.mnuItemViewSelected = new System.Windows.Forms.MenuItem();
			this.mnuItemViewReport = new System.Windows.Forms.MenuItem();
			this.mnuItemViewMainTree = new System.Windows.Forms.MenuItem();
			this.panelToolbar = new System.Windows.Forms.Panel();
			this.pictureBoxToolbarSave = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarCopy = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateOptions = new System.Windows.Forms.PictureBox();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.panel25 = new System.Windows.Forms.Panel();
			this.label13 = new System.Windows.Forms.Label();
			this.pictureBoxTemplateNew = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateDelete = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateEdit = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateSaveAs = new System.Windows.Forms.PictureBox();
			this.pictureBoxTemplateSave = new System.Windows.Forms.PictureBox();
			this.comboBoxReportTemplate = new System.Windows.Forms.ComboBox();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panelReportForm1.SuspendLayout();
			this.panelFilterYesNo.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panelTree.SuspendLayout();
			this.panelFilter.SuspendLayout();
			this.groupBoxAddFilter.SuspendLayout();
			this.groupBoxCriteria.SuspendLayout();
			this.panelListBox.SuspendLayout();
			this.groupBoxApplyLevel.SuspendLayout();
			this.panelReportForm2.SuspendLayout();
			this.groupBoxIncludePhotos.SuspendLayout();
			this.groupBoxIncludeRetired.SuspendLayout();
			this.groupBoxSortBy.SuspendLayout();
			this.panelSortBy.SuspendLayout();
			this.panel16.SuspendLayout();
			this.panel14.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panelReportFormat.SuspendLayout();
			this.panelMatrixColumns.SuspendLayout();
			this.panelToolbar.SuspendLayout();
			this.panel25.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonPrint
			// 
			this.buttonPrint.Location = new System.Drawing.Point(116, 570);
			this.buttonPrint.Name = "buttonPrint";
			this.buttonPrint.Size = new System.Drawing.Size(104, 23);
			this.buttonPrint.TabIndex = 4;
			this.buttonPrint.TabStop = false;
			this.buttonPrint.Text = "&Print";
			this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
			// 
			// buttonCancelOrig
			// 
			this.buttonCancelOrig.BackColor = System.Drawing.Color.Red;
			this.buttonCancelOrig.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancelOrig.Location = new System.Drawing.Point(352, 570);
			this.buttonCancelOrig.Name = "buttonCancelOrig";
			this.buttonCancelOrig.Size = new System.Drawing.Size(104, 23);
			this.buttonCancelOrig.TabIndex = 5;
			this.buttonCancelOrig.TabStop = false;
			this.buttonCancelOrig.Text = "Cancel";
			this.buttonCancelOrig.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// buttonPreview
			// 
			this.buttonPreview.BackColor = System.Drawing.Color.Red;
			this.buttonPreview.Location = new System.Drawing.Point(236, 570);
			this.buttonPreview.Name = "buttonPreview";
			this.buttonPreview.Size = new System.Drawing.Size(104, 23);
			this.buttonPreview.TabIndex = 6;
			this.buttonPreview.TabStop = false;
			this.buttonPreview.Text = "Pre&view";
			this.buttonPreview.Click += new System.EventHandler(this.buttonPreview_Click);
			// 
			// panelReportForm1
			// 
			this.panelReportForm1.BackColor = System.Drawing.SystemColors.Control;
			this.panelReportForm1.Controls.Add(this.labelCheckedNodeCount);
			this.panelReportForm1.Controls.Add(this.labelReportTypeCount);
			this.panelReportForm1.Controls.Add(this.buttonClearAll);
			this.panelReportForm1.Controls.Add(this.buttonSelectAll);
			this.panelReportForm1.Controls.Add(this.panel23);
			this.panelReportForm1.Controls.Add(this.panel2);
			this.panelReportForm1.Controls.Add(this.panel1);
			this.panelReportForm1.Controls.Add(this.panelFilterYesNo);
			this.panelReportForm1.Controls.Add(this.label2);
			this.panelReportForm1.Controls.Add(this.comboBoxReportType);
			this.panelReportForm1.Controls.Add(this.panelTree);
			this.panelReportForm1.Controls.Add(this.panelFilter);
			this.panelReportForm1.Controls.Add(this.buttonNext);
			this.panelReportForm1.Controls.Add(this.buttonCancel1);
			this.panelReportForm1.Controls.Add(this.label1);
			this.helpProvider1.SetHelpKeyword(this.panelReportForm1, "ReportsSelectReportData.htm");
			this.helpProvider1.SetHelpNavigator(this.panelReportForm1, System.Windows.Forms.HelpNavigator.Topic);
			this.panelReportForm1.Location = new System.Drawing.Point(0, 33);
			this.panelReportForm1.Name = "panelReportForm1";
			this.helpProvider1.SetShowHelp(this.panelReportForm1, true);
			this.panelReportForm1.Size = new System.Drawing.Size(748, 480);
			this.panelReportForm1.TabIndex = 2;
			this.panelReportForm1.Paint += new System.Windows.Forms.PaintEventHandler(this.panelReportForm1_Paint);
			// 
			// labelCheckedNodeCount
			// 
			this.labelCheckedNodeCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCheckedNodeCount.Location = new System.Drawing.Point(196, 448);
			this.labelCheckedNodeCount.Name = "labelCheckedNodeCount";
			this.labelCheckedNodeCount.Size = new System.Drawing.Size(174, 28);
			this.labelCheckedNodeCount.TabIndex = 84;
			this.labelCheckedNodeCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelReportTypeCount
			// 
			this.labelReportTypeCount.Location = new System.Drawing.Point(8, 448);
			this.labelReportTypeCount.Name = "labelReportTypeCount";
			this.labelReportTypeCount.Size = new System.Drawing.Size(174, 28);
			this.labelReportTypeCount.TabIndex = 69;
			this.labelReportTypeCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// buttonClearAll
			// 
			this.buttonClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClearAll.Location = new System.Drawing.Point(112, 412);
			this.buttonClearAll.Name = "buttonClearAll";
			this.buttonClearAll.Size = new System.Drawing.Size(88, 23);
			this.buttonClearAll.TabIndex = 7;
			this.buttonClearAll.Text = "Clear All";
			this.buttonClearAll.Click += new System.EventHandler(this.buttonClearAll_Click);
			// 
			// buttonSelectAll
			// 
			this.buttonSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSelectAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonSelectAll.Location = new System.Drawing.Point(8, 412);
			this.buttonSelectAll.Name = "buttonSelectAll";
			this.buttonSelectAll.Size = new System.Drawing.Size(88, 23);
			this.buttonSelectAll.TabIndex = 6;
			this.buttonSelectAll.Text = "Select All";
			this.buttonSelectAll.Click += new System.EventHandler(this.buttonSelectAll_Click);
			// 
			// panel23
			// 
			this.panel23.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel23.Location = new System.Drawing.Point(0, 0);
			this.panel23.Name = "panel23";
			this.panel23.Size = new System.Drawing.Size(652, 2);
			this.panel23.TabIndex = 68;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel2.Location = new System.Drawing.Point(0, 442);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(752, 2);
			this.panel2.TabIndex = 67;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel1.Location = new System.Drawing.Point(307, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(2, 444);
			this.panel1.TabIndex = 66;
			// 
			// panelFilterYesNo
			// 
			this.panelFilterYesNo.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelFilterYesNo.Controls.Add(this.panel4);
			this.panelFilterYesNo.Location = new System.Drawing.Point(570, 12);
			this.panelFilterYesNo.Name = "panelFilterYesNo";
			this.panelFilterYesNo.Size = new System.Drawing.Size(133, 26);
			this.panelFilterYesNo.TabIndex = 9;
			this.panelFilterYesNo.TabStop = true;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.SystemColors.Control;
			this.panel4.Controls.Add(this.radioFilterNo);
			this.panel4.Controls.Add(this.radioFilterYes);
			this.panel4.Location = new System.Drawing.Point(1, 1);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(131, 24);
			this.panel4.TabIndex = 0;
			this.panel4.TabStop = true;
			// 
			// radioFilterNo
			// 
			this.radioFilterNo.BackColor = System.Drawing.SystemColors.Control;
			this.radioFilterNo.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioFilterNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioFilterNo.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.radioFilterNo.Location = new System.Drawing.Point(77, 4);
			this.radioFilterNo.Name = "radioFilterNo";
			this.radioFilterNo.Size = new System.Drawing.Size(50, 16);
			this.radioFilterNo.TabIndex = 1;
			this.radioFilterNo.TabStop = true;
			this.radioFilterNo.Text = "Off";
			this.radioFilterNo.CheckedChanged += new System.EventHandler(this.radioFilterNo_CheckedChanged);
			// 
			// radioFilterYes
			// 
			this.radioFilterYes.BackColor = System.Drawing.SystemColors.Control;
			this.radioFilterYes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioFilterYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioFilterYes.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.radioFilterYes.Location = new System.Drawing.Point(17, 4);
			this.radioFilterYes.Name = "radioFilterYes";
			this.radioFilterYes.Size = new System.Drawing.Size(50, 16);
			this.radioFilterYes.TabIndex = 0;
			this.radioFilterYes.TabStop = true;
			this.radioFilterYes.Text = "On";
			this.radioFilterYes.CheckedChanged += new System.EventHandler(this.radioFilterYes_CheckedChanged);
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label2.Location = new System.Drawing.Point(319, 11);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(253, 28);
			this.label2.TabIndex = 8;
			this.label2.Text = "Filter the Selected Report Data";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxReportType
			// 
			this.comboBoxReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportType.DropDownWidth = 194;
			this.comboBoxReportType.Location = new System.Drawing.Point(7, 46);
			this.comboBoxReportType.MaxDropDownItems = 20;
			this.comboBoxReportType.Name = "comboBoxReportType";
			this.comboBoxReportType.Size = new System.Drawing.Size(294, 21);
			this.comboBoxReportType.TabIndex = 3;
			this.comboBoxReportType.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportType_SelectedIndexChanged);
			// 
			// panelTree
			// 
			this.panelTree.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelTree.Controls.Add(this.treeViewSpecificUnits);
			this.panelTree.Location = new System.Drawing.Point(7, 68);
			this.panelTree.Name = "panelTree";
			this.panelTree.Size = new System.Drawing.Size(294, 336);
			this.panelTree.TabIndex = 4;
			// 
			// treeViewSpecificUnits
			// 
			this.treeViewSpecificUnits.BackColor = System.Drawing.SystemColors.Window;
			this.treeViewSpecificUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewSpecificUnits.CheckBoxes = true;
			this.helpProvider1.SetHelpKeyword(this.treeViewSpecificUnits, "ReportsSelectReportData.htm");
			this.helpProvider1.SetHelpNavigator(this.treeViewSpecificUnits, System.Windows.Forms.HelpNavigator.Topic);
			this.treeViewSpecificUnits.ImageIndex = -1;
			this.treeViewSpecificUnits.Location = new System.Drawing.Point(1, 1);
			this.treeViewSpecificUnits.Name = "treeViewSpecificUnits";
			this.treeViewSpecificUnits.SelectedImageIndex = -1;
			this.helpProvider1.SetShowHelp(this.treeViewSpecificUnits, true);
			this.treeViewSpecificUnits.Size = new System.Drawing.Size(292, 334);
			this.treeViewSpecificUnits.TabIndex = 5;
			this.treeViewSpecificUnits.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeViewSpecificUnits_MouseDown);
			this.treeViewSpecificUnits.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterExpand);
			this.treeViewSpecificUnits.Click += new System.EventHandler(this.treeViewSpecificUnits_Click);
			this.treeViewSpecificUnits.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterCollapse);
			this.treeViewSpecificUnits.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterCheck);
			this.treeViewSpecificUnits.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeViewSpecificUnits_MouseUp);
			this.treeViewSpecificUnits.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewSpecificUnits_AfterSelect);
			this.treeViewSpecificUnits.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeSelect);
			this.treeViewSpecificUnits.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCollapse);
			this.treeViewSpecificUnits.BeforeCheck += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeCheck);
			this.treeViewSpecificUnits.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewSpecificUnits_BeforeExpand);
			// 
			// panelFilter
			// 
			this.panelFilter.BackColor = System.Drawing.SystemColors.Control;
			this.panelFilter.Controls.Add(this.groupBoxAddFilter);
			this.panelFilter.Controls.Add(this.groupBoxCriteria);
			this.panelFilter.Controls.Add(this.groupBoxApplyLevel);
			this.panelFilter.Controls.Add(this.panel22);
			this.panelFilter.Controls.Add(this.label10);
			this.panelFilter.Enabled = false;
			this.panelFilter.Location = new System.Drawing.Point(316, 38);
			this.panelFilter.Name = "panelFilter";
			this.panelFilter.Size = new System.Drawing.Size(464, 402);
			this.panelFilter.TabIndex = 10;
			// 
			// groupBoxAddFilter
			// 
			this.groupBoxAddFilter.BackColor = System.Drawing.SystemColors.Control;
			this.groupBoxAddFilter.Controls.Add(this.filterBuilderForm21);
			this.groupBoxAddFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxAddFilter.Location = new System.Drawing.Point(2, 2);
			this.groupBoxAddFilter.Name = "groupBoxAddFilter";
			this.groupBoxAddFilter.Size = new System.Drawing.Size(422, 189);
			this.groupBoxAddFilter.TabIndex = 11;
			this.groupBoxAddFilter.TabStop = false;
			// 
			// filterBuilderForm21
			// 
			this.filterBuilderForm21.BackColor = System.Drawing.SystemColors.Control;
			this.helpProvider1.SetHelpKeyword(this.filterBuilderForm21, "ReportsFilteringData.htm");
			this.helpProvider1.SetHelpNavigator(this.filterBuilderForm21, System.Windows.Forms.HelpNavigator.Topic);
			this.filterBuilderForm21.Location = new System.Drawing.Point(20, 15);
			this.filterBuilderForm21.Name = "filterBuilderForm21";
			this.helpProvider1.SetShowHelp(this.filterBuilderForm21, true);
			this.filterBuilderForm21.Size = new System.Drawing.Size(394, 168);
			this.filterBuilderForm21.TabIndex = 12;
			// 
			// groupBoxCriteria
			// 
			this.groupBoxCriteria.BackColor = System.Drawing.SystemColors.Control;
			this.groupBoxCriteria.Controls.Add(this.radioMatchAny);
			this.groupBoxCriteria.Controls.Add(this.radioMatchAllCriteria);
			this.groupBoxCriteria.Controls.Add(this.buttonEditCriteria);
			this.groupBoxCriteria.Controls.Add(this.buttonRemoveCriteria);
			this.groupBoxCriteria.Controls.Add(this.buttonClearCriteria);
			this.groupBoxCriteria.Controls.Add(this.label19);
			this.groupBoxCriteria.Controls.Add(this.panelListBox);
			this.groupBoxCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.helpProvider1.SetHelpKeyword(this.groupBoxCriteria, "ReportsFilteringData.htm");
			this.helpProvider1.SetHelpNavigator(this.groupBoxCriteria, System.Windows.Forms.HelpNavigator.Topic);
			this.groupBoxCriteria.Location = new System.Drawing.Point(2, 198);
			this.groupBoxCriteria.Name = "groupBoxCriteria";
			this.helpProvider1.SetShowHelp(this.groupBoxCriteria, true);
			this.groupBoxCriteria.Size = new System.Drawing.Size(422, 200);
			this.groupBoxCriteria.TabIndex = 13;
			this.groupBoxCriteria.TabStop = false;
			// 
			// radioMatchAny
			// 
			this.radioMatchAny.BackColor = System.Drawing.SystemColors.Control;
			this.radioMatchAny.Checked = true;
			this.radioMatchAny.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioMatchAny.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.radioMatchAny.Location = new System.Drawing.Point(16, 177);
			this.radioMatchAny.Name = "radioMatchAny";
			this.radioMatchAny.Size = new System.Drawing.Size(124, 16);
			this.radioMatchAny.TabIndex = 2;
			this.radioMatchAny.TabStop = true;
			this.radioMatchAny.Text = "Match Any Criteria";
			// 
			// radioMatchAllCriteria
			// 
			this.radioMatchAllCriteria.BackColor = System.Drawing.SystemColors.Control;
			this.radioMatchAllCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioMatchAllCriteria.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.radioMatchAllCriteria.Location = new System.Drawing.Point(144, 177);
			this.radioMatchAllCriteria.Name = "radioMatchAllCriteria";
			this.radioMatchAllCriteria.Size = new System.Drawing.Size(124, 16);
			this.radioMatchAllCriteria.TabIndex = 3;
			this.radioMatchAllCriteria.TabStop = true;
			this.radioMatchAllCriteria.Text = "Match All Criteria";
			// 
			// buttonEditCriteria
			// 
			this.buttonEditCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditCriteria.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonEditCriteria.Location = new System.Drawing.Point(348, 33);
			this.buttonEditCriteria.Name = "buttonEditCriteria";
			this.buttonEditCriteria.Size = new System.Drawing.Size(66, 23);
			this.buttonEditCriteria.TabIndex = 4;
			this.buttonEditCriteria.Text = "&Edit";
			this.buttonEditCriteria.Click += new System.EventHandler(this.buttonEditCriteria_Click);
			// 
			// buttonRemoveCriteria
			// 
			this.buttonRemoveCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonRemoveCriteria.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonRemoveCriteria.Location = new System.Drawing.Point(348, 73);
			this.buttonRemoveCriteria.Name = "buttonRemoveCriteria";
			this.buttonRemoveCriteria.Size = new System.Drawing.Size(66, 23);
			this.buttonRemoveCriteria.TabIndex = 5;
			this.buttonRemoveCriteria.Text = "&Delete";
			this.buttonRemoveCriteria.Click += new System.EventHandler(this.buttonRemoveCriteria_Click);
			// 
			// buttonClearCriteria
			// 
			this.buttonClearCriteria.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearCriteria.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClearCriteria.Location = new System.Drawing.Point(348, 103);
			this.buttonClearCriteria.Name = "buttonClearCriteria";
			this.buttonClearCriteria.Size = new System.Drawing.Size(66, 23);
			this.buttonClearCriteria.TabIndex = 6;
			this.buttonClearCriteria.Text = "De&lete All";
			this.buttonClearCriteria.Click += new System.EventHandler(this.buttonClearCriteria_Click);
			// 
			// label19
			// 
			this.label19.BackColor = System.Drawing.Color.Transparent;
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label19.Location = new System.Drawing.Point(10, 12);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(96, 14);
			this.label19.TabIndex = 0;
			this.label19.Text = "Filters";
			this.label19.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panelListBox
			// 
			this.panelListBox.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelListBox.Controls.Add(this.treeViewCriteria);
			this.panelListBox.Controls.Add(this.listBoxCriteria);
			this.panelListBox.Location = new System.Drawing.Point(10, 30);
			this.panelListBox.Name = "panelListBox";
			this.panelListBox.Size = new System.Drawing.Size(332, 145);
			this.panelListBox.TabIndex = 1;
			this.panelListBox.TabStop = true;
			// 
			// treeViewCriteria
			// 
			this.treeViewCriteria.BackColor = System.Drawing.SystemColors.Window;
			this.treeViewCriteria.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewCriteria.ForeColor = System.Drawing.Color.Black;
			this.treeViewCriteria.FullRowSelect = true;
			this.treeViewCriteria.HideSelection = false;
			this.treeViewCriteria.ImageIndex = -1;
			this.treeViewCriteria.ItemHeight = 14;
			this.treeViewCriteria.Location = new System.Drawing.Point(1, 1);
			this.treeViewCriteria.Name = "treeViewCriteria";
			this.treeViewCriteria.SelectedImageIndex = -1;
			this.treeViewCriteria.ShowLines = false;
			this.treeViewCriteria.ShowPlusMinus = false;
			this.treeViewCriteria.ShowRootLines = false;
			this.treeViewCriteria.Size = new System.Drawing.Size(330, 143);
			this.treeViewCriteria.TabIndex = 2;
			this.treeViewCriteria.DoubleClick += new System.EventHandler(this.treeViewCriteria_DoubleClick);
			this.treeViewCriteria.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCriteria_AfterSelect);
			// 
			// listBoxCriteria
			// 
			this.listBoxCriteria.BackColor = System.Drawing.SystemColors.Window;
			this.listBoxCriteria.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.listBoxCriteria.Location = new System.Drawing.Point(1, 1);
			this.listBoxCriteria.Name = "listBoxCriteria";
			this.listBoxCriteria.Size = new System.Drawing.Size(330, 143);
			this.listBoxCriteria.TabIndex = 1;
			this.listBoxCriteria.TabStop = false;
			this.listBoxCriteria.DoubleClick += new System.EventHandler(this.listBoxCriteria_DoubleClick);
			// 
			// groupBoxApplyLevel
			// 
			this.groupBoxApplyLevel.BackColor = System.Drawing.SystemColors.Control;
			this.groupBoxApplyLevel.Controls.Add(this.label18);
			this.groupBoxApplyLevel.Controls.Add(this.comboBoxApplyFiltersTo);
			this.groupBoxApplyLevel.Controls.Add(this.label17);
			this.groupBoxApplyLevel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxApplyLevel.Location = new System.Drawing.Point(2, 2);
			this.groupBoxApplyLevel.Name = "groupBoxApplyLevel";
			this.groupBoxApplyLevel.Size = new System.Drawing.Size(422, 46);
			this.groupBoxApplyLevel.TabIndex = 10;
			this.groupBoxApplyLevel.TabStop = false;
			this.groupBoxApplyLevel.Visible = false;
			// 
			// label18
			// 
			this.label18.BackColor = System.Drawing.Color.Transparent;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label18.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label18.Location = new System.Drawing.Point(308, 19);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(32, 14);
			this.label18.TabIndex = 52;
			this.label18.Text = "level";
			this.label18.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label18.Visible = false;
			// 
			// comboBoxApplyFiltersTo
			// 
			this.comboBoxApplyFiltersTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxApplyFiltersTo.DropDownWidth = 193;
			this.comboBoxApplyFiltersTo.Location = new System.Drawing.Point(107, 15);
			this.comboBoxApplyFiltersTo.MaxDropDownItems = 10;
			this.comboBoxApplyFiltersTo.Name = "comboBoxApplyFiltersTo";
			this.comboBoxApplyFiltersTo.Size = new System.Drawing.Size(193, 21);
			this.comboBoxApplyFiltersTo.TabIndex = 0;
			this.comboBoxApplyFiltersTo.SelectedIndexChanged += new System.EventHandler(this.comboBoxApplyFiltersTo_SelectedIndexChanged);
			// 
			// label17
			// 
			this.label17.BackColor = System.Drawing.Color.Transparent;
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label17.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.label17.Location = new System.Drawing.Point(30, 19);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(104, 14);
			this.label17.TabIndex = 51;
			this.label17.Text = "Apply filters to";
			this.label17.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel22
			// 
			this.panel22.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panel22.Location = new System.Drawing.Point(6, 37);
			this.panel22.Name = "panel22";
			this.panel22.Size = new System.Drawing.Size(414, 1);
			this.panel22.TabIndex = 50;
			this.panel22.Visible = false;
			// 
			// label10
			// 
			this.label10.BackColor = System.Drawing.Color.Transparent;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label10.Location = new System.Drawing.Point(4, 256);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(340, 14);
			this.label10.TabIndex = 45;
			this.label10.Text = "Filters";
			this.label10.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.label10.Visible = false;
			// 
			// buttonNext
			// 
			this.buttonNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonNext.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonNext.Location = new System.Drawing.Point(538, 450);
			this.buttonNext.Name = "buttonNext";
			this.buttonNext.Size = new System.Drawing.Size(94, 23);
			this.buttonNext.TabIndex = 23;
			this.buttonNext.Text = "&Next";
			this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
			// 
			// buttonCancel1
			// 
			this.buttonCancel1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel1.Location = new System.Drawing.Point(642, 450);
			this.buttonCancel1.Name = "buttonCancel1";
			this.buttonCancel1.Size = new System.Drawing.Size(94, 23);
			this.buttonCancel1.TabIndex = 24;
			this.buttonCancel1.Text = "Close";
			this.buttonCancel1.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label1.Location = new System.Drawing.Point(11, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(189, 28);
			this.label1.TabIndex = 2;
			this.label1.Text = "Select Report Data";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelReportForm2
			// 
			this.panelReportForm2.BackColor = System.Drawing.SystemColors.Control;
			this.panelReportForm2.Controls.Add(this.buttonExport);
			this.panelReportForm2.Controls.Add(this.groupBoxIncludePhotos);
			this.panelReportForm2.Controls.Add(this.groupBoxIncludeRetired);
			this.panelReportForm2.Controls.Add(this.groupBoxSortBy);
			this.panelReportForm2.Controls.Add(this.buttonPrint2);
			this.panelReportForm2.Controls.Add(this.panel24);
			this.panelReportForm2.Controls.Add(this.panel12);
			this.panelReportForm2.Controls.Add(this.panel13);
			this.panelReportForm2.Controls.Add(this.buttonBack);
			this.panelReportForm2.Controls.Add(this.panelReportFormat);
			this.panelReportForm2.Controls.Add(this.comboBoxReportFormat);
			this.panelReportForm2.Controls.Add(this.buttonPreview2);
			this.panelReportForm2.Controls.Add(this.buttonCancel2);
			this.panelReportForm2.Controls.Add(this.label8);
			this.panelReportForm2.Controls.Add(this.label9);
			this.helpProvider1.SetHelpKeyword(this.panelReportForm2, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.panelReportForm2, System.Windows.Forms.HelpNavigator.Topic);
			this.panelReportForm2.Location = new System.Drawing.Point(0, 33);
			this.panelReportForm2.Name = "panelReportForm2";
			this.helpProvider1.SetShowHelp(this.panelReportForm2, true);
			this.panelReportForm2.Size = new System.Drawing.Size(748, 480);
			this.panelReportForm2.TabIndex = 1;
			// 
			// buttonExport
			// 
			this.buttonExport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonExport.Location = new System.Drawing.Point(10, 450);
			this.buttonExport.Name = "buttonExport";
			this.buttonExport.Size = new System.Drawing.Size(95, 23);
			this.buttonExport.TabIndex = 75;
			this.buttonExport.Text = "&Export";
			this.buttonExport.Click += new System.EventHandler(this.buttonExport_Click);
			// 
			// groupBoxIncludePhotos
			// 
			this.groupBoxIncludePhotos.Controls.Add(this.checkBoxIncludePhotos);
			this.groupBoxIncludePhotos.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxIncludePhotos.Location = new System.Drawing.Point(7, 76);
			this.groupBoxIncludePhotos.Name = "groupBoxIncludePhotos";
			this.groupBoxIncludePhotos.Size = new System.Drawing.Size(194, 56);
			this.groupBoxIncludePhotos.TabIndex = 5;
			this.groupBoxIncludePhotos.TabStop = false;
			// 
			// checkBoxIncludePhotos
			// 
			this.checkBoxIncludePhotos.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxIncludePhotos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBoxIncludePhotos.Location = new System.Drawing.Point(26, 23);
			this.checkBoxIncludePhotos.Name = "checkBoxIncludePhotos";
			this.checkBoxIncludePhotos.Size = new System.Drawing.Size(132, 16);
			this.checkBoxIncludePhotos.TabIndex = 0;
			this.checkBoxIncludePhotos.Text = "&Include Photos";
			// 
			// groupBoxIncludeRetired
			// 
			this.groupBoxIncludeRetired.Controls.Add(this.checkBoxIncludeRetired);
			this.groupBoxIncludeRetired.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxIncludeRetired.Location = new System.Drawing.Point(11, 132);
			this.groupBoxIncludeRetired.Name = "groupBoxIncludeRetired";
			this.groupBoxIncludeRetired.Size = new System.Drawing.Size(184, 56);
			this.groupBoxIncludeRetired.TabIndex = 6;
			this.groupBoxIncludeRetired.TabStop = false;
			this.groupBoxIncludeRetired.Visible = false;
			// 
			// checkBoxIncludeRetired
			// 
			this.checkBoxIncludeRetired.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxIncludeRetired.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBoxIncludeRetired.Location = new System.Drawing.Point(26, 23);
			this.checkBoxIncludeRetired.Name = "checkBoxIncludeRetired";
			this.checkBoxIncludeRetired.Size = new System.Drawing.Size(132, 16);
			this.checkBoxIncludeRetired.TabIndex = 0;
			this.checkBoxIncludeRetired.Text = "Include Retired";
			// 
			// groupBoxSortBy
			// 
			this.groupBoxSortBy.Controls.Add(this.panelSortBy);
			this.groupBoxSortBy.Controls.Add(this.radioSortFields);
			this.groupBoxSortBy.Controls.Add(this.radioSortTree);
			this.groupBoxSortBy.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxSortBy.Location = new System.Drawing.Point(318, 40);
			this.groupBoxSortBy.Name = "groupBoxSortBy";
			this.groupBoxSortBy.Size = new System.Drawing.Size(422, 380);
			this.groupBoxSortBy.TabIndex = 8;
			this.groupBoxSortBy.TabStop = false;
			// 
			// panelSortBy
			// 
			this.panelSortBy.BackColor = System.Drawing.SystemColors.Control;
			this.panelSortBy.Controls.Add(this.panel16);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy5);
			this.panelSortBy.Controls.Add(this.label14);
			this.panelSortBy.Controls.Add(this.panel17);
			this.panelSortBy.Controls.Add(this.panel14);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy4);
			this.panelSortBy.Controls.Add(this.label3);
			this.panelSortBy.Controls.Add(this.panel15);
			this.panelSortBy.Controls.Add(this.panel10);
			this.panelSortBy.Controls.Add(this.panel9);
			this.panelSortBy.Controls.Add(this.panel7);
			this.panelSortBy.Controls.Add(this.panel6);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy3);
			this.panelSortBy.Controls.Add(this.label7);
			this.panelSortBy.Controls.Add(this.panel5);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy2);
			this.panelSortBy.Controls.Add(this.label6);
			this.panelSortBy.Controls.Add(this.panel8);
			this.panelSortBy.Controls.Add(this.panel11);
			this.panelSortBy.Controls.Add(this.label5);
			this.panelSortBy.Controls.Add(this.comboBoxSortBy1);
			this.helpProvider1.SetHelpKeyword(this.panelSortBy, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.panelSortBy, System.Windows.Forms.HelpNavigator.Topic);
			this.panelSortBy.Location = new System.Drawing.Point(14, 64);
			this.panelSortBy.Name = "panelSortBy";
			this.helpProvider1.SetShowHelp(this.panelSortBy, true);
			this.panelSortBy.Size = new System.Drawing.Size(388, 308);
			this.panelSortBy.TabIndex = 11;
			// 
			// panel16
			// 
			this.panel16.Controls.Add(this.radioDesc5);
			this.panel16.Controls.Add(this.radioAsc5);
			this.panel16.Location = new System.Drawing.Point(255, 252);
			this.panel16.Name = "panel16";
			this.panel16.Size = new System.Drawing.Size(100, 32);
			this.panel16.TabIndex = 10;
			// 
			// radioDesc5
			// 
			this.radioDesc5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioDesc5.Location = new System.Drawing.Point(0, 17);
			this.radioDesc5.Name = "radioDesc5";
			this.radioDesc5.Size = new System.Drawing.Size(84, 16);
			this.radioDesc5.TabIndex = 1;
			this.radioDesc5.Text = "Descending";
			// 
			// radioAsc5
			// 
			this.radioAsc5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioAsc5.Location = new System.Drawing.Point(0, 0);
			this.radioAsc5.Name = "radioAsc5";
			this.radioAsc5.Size = new System.Drawing.Size(84, 16);
			this.radioAsc5.TabIndex = 0;
			this.radioAsc5.Text = "Ascending";
			// 
			// comboBoxSortBy5
			// 
			this.comboBoxSortBy5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxSortBy5, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxSortBy5, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxSortBy5.Location = new System.Drawing.Point(23, 256);
			this.comboBoxSortBy5.MaxDropDownItems = 30;
			this.comboBoxSortBy5.Name = "comboBoxSortBy5";
			this.helpProvider1.SetShowHelp(this.comboBoxSortBy5, true);
			this.comboBoxSortBy5.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy5.Sorted = true;
			this.comboBoxSortBy5.TabIndex = 9;
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label14.Location = new System.Drawing.Point(8, 232);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(47, 14);
			this.label14.TabIndex = 16;
			this.label14.Text = "Then by";
			this.label14.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel17
			// 
			this.panel17.BackColor = System.Drawing.Color.LightGray;
			this.panel17.Location = new System.Drawing.Point(56, 240);
			this.panel17.Name = "panel17";
			this.panel17.Size = new System.Drawing.Size(280, 1);
			this.panel17.TabIndex = 70;
			// 
			// panel14
			// 
			this.panel14.Controls.Add(this.radioDesc4);
			this.panel14.Controls.Add(this.radioAsc4);
			this.panel14.Location = new System.Drawing.Point(255, 196);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(100, 32);
			this.panel14.TabIndex = 8;
			// 
			// radioDesc4
			// 
			this.radioDesc4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioDesc4.Location = new System.Drawing.Point(0, 17);
			this.radioDesc4.Name = "radioDesc4";
			this.radioDesc4.Size = new System.Drawing.Size(84, 16);
			this.radioDesc4.TabIndex = 1;
			this.radioDesc4.Text = "Descending";
			// 
			// radioAsc4
			// 
			this.radioAsc4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioAsc4.Location = new System.Drawing.Point(0, 0);
			this.radioAsc4.Name = "radioAsc4";
			this.radioAsc4.Size = new System.Drawing.Size(84, 16);
			this.radioAsc4.TabIndex = 0;
			this.radioAsc4.Text = "Ascending";
			// 
			// comboBoxSortBy4
			// 
			this.comboBoxSortBy4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxSortBy4, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxSortBy4, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxSortBy4.Location = new System.Drawing.Point(23, 200);
			this.comboBoxSortBy4.MaxDropDownItems = 30;
			this.comboBoxSortBy4.Name = "comboBoxSortBy4";
			this.helpProvider1.SetShowHelp(this.comboBoxSortBy4, true);
			this.comboBoxSortBy4.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy4.Sorted = true;
			this.comboBoxSortBy4.TabIndex = 7;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label3.Location = new System.Drawing.Point(8, 176);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(47, 14);
			this.label3.TabIndex = 12;
			this.label3.Text = "Then by";
			this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel15
			// 
			this.panel15.BackColor = System.Drawing.Color.LightGray;
			this.panel15.Location = new System.Drawing.Point(56, 184);
			this.panel15.Name = "panel15";
			this.panel15.Size = new System.Drawing.Size(280, 1);
			this.panel15.TabIndex = 66;
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.radioDesc3);
			this.panel10.Controls.Add(this.radioAsc3);
			this.panel10.Location = new System.Drawing.Point(255, 140);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(100, 32);
			this.panel10.TabIndex = 6;
			// 
			// radioDesc3
			// 
			this.radioDesc3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioDesc3.Location = new System.Drawing.Point(0, 17);
			this.radioDesc3.Name = "radioDesc3";
			this.radioDesc3.Size = new System.Drawing.Size(84, 16);
			this.radioDesc3.TabIndex = 1;
			this.radioDesc3.Text = "Descending";
			// 
			// radioAsc3
			// 
			this.radioAsc3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioAsc3.Location = new System.Drawing.Point(0, 0);
			this.radioAsc3.Name = "radioAsc3";
			this.radioAsc3.Size = new System.Drawing.Size(84, 16);
			this.radioAsc3.TabIndex = 0;
			this.radioAsc3.Text = "Ascending";
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.radioDesc2);
			this.panel9.Controls.Add(this.radioAsc2);
			this.panel9.Location = new System.Drawing.Point(255, 84);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(100, 32);
			this.panel9.TabIndex = 4;
			// 
			// radioDesc2
			// 
			this.radioDesc2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioDesc2.Location = new System.Drawing.Point(0, 17);
			this.radioDesc2.Name = "radioDesc2";
			this.radioDesc2.Size = new System.Drawing.Size(84, 16);
			this.radioDesc2.TabIndex = 1;
			this.radioDesc2.Text = "Descending";
			// 
			// radioAsc2
			// 
			this.radioAsc2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioAsc2.Location = new System.Drawing.Point(0, 0);
			this.radioAsc2.Name = "radioAsc2";
			this.radioAsc2.Size = new System.Drawing.Size(84, 16);
			this.radioAsc2.TabIndex = 0;
			this.radioAsc2.Text = "Ascending";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.radioDesc1);
			this.panel7.Controls.Add(this.radioAsc1);
			this.panel7.Location = new System.Drawing.Point(255, 28);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(100, 32);
			this.panel7.TabIndex = 2;
			// 
			// radioDesc1
			// 
			this.radioDesc1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioDesc1.Location = new System.Drawing.Point(0, 17);
			this.radioDesc1.Name = "radioDesc1";
			this.radioDesc1.Size = new System.Drawing.Size(84, 16);
			this.radioDesc1.TabIndex = 1;
			this.radioDesc1.Text = "Descending";
			// 
			// radioAsc1
			// 
			this.radioAsc1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioAsc1.Location = new System.Drawing.Point(0, 0);
			this.radioAsc1.Name = "radioAsc1";
			this.radioAsc1.Size = new System.Drawing.Size(84, 16);
			this.radioAsc1.TabIndex = 0;
			this.radioAsc1.Text = "Ascending";
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.LightGray;
			this.panel6.Location = new System.Drawing.Point(23, 293);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(313, 1);
			this.panel6.TabIndex = 61;
			// 
			// comboBoxSortBy3
			// 
			this.comboBoxSortBy3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxSortBy3, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxSortBy3, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxSortBy3.Location = new System.Drawing.Point(23, 144);
			this.comboBoxSortBy3.MaxDropDownItems = 30;
			this.comboBoxSortBy3.Name = "comboBoxSortBy3";
			this.helpProvider1.SetShowHelp(this.comboBoxSortBy3, true);
			this.comboBoxSortBy3.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy3.Sorted = true;
			this.comboBoxSortBy3.TabIndex = 5;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label7.Location = new System.Drawing.Point(8, 120);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(47, 14);
			this.label7.TabIndex = 8;
			this.label7.Text = "Then by";
			this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightGray;
			this.panel5.Location = new System.Drawing.Point(56, 128);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(280, 1);
			this.panel5.TabIndex = 58;
			// 
			// comboBoxSortBy2
			// 
			this.comboBoxSortBy2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxSortBy2, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxSortBy2, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxSortBy2.Location = new System.Drawing.Point(23, 88);
			this.comboBoxSortBy2.MaxDropDownItems = 30;
			this.comboBoxSortBy2.Name = "comboBoxSortBy2";
			this.helpProvider1.SetShowHelp(this.comboBoxSortBy2, true);
			this.comboBoxSortBy2.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy2.Sorted = true;
			this.comboBoxSortBy2.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label6.Location = new System.Drawing.Point(8, 64);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(47, 14);
			this.label6.TabIndex = 4;
			this.label6.Text = "Then by";
			this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel8
			// 
			this.panel8.BackColor = System.Drawing.Color.LightGray;
			this.panel8.Location = new System.Drawing.Point(56, 72);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(280, 1);
			this.panel8.TabIndex = 55;
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.Color.LightGray;
			this.panel11.Location = new System.Drawing.Point(56, 16);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(280, 1);
			this.panel11.TabIndex = 54;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(33)), ((System.Byte)(78)), ((System.Byte)(209)));
			this.label5.Location = new System.Drawing.Point(8, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(47, 14);
			this.label5.TabIndex = 0;
			this.label5.Text = "Sort by";
			this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// comboBoxSortBy1
			// 
			this.comboBoxSortBy1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxSortBy1, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxSortBy1, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxSortBy1.Location = new System.Drawing.Point(23, 32);
			this.comboBoxSortBy1.MaxDropDownItems = 30;
			this.comboBoxSortBy1.Name = "comboBoxSortBy1";
			this.helpProvider1.SetShowHelp(this.comboBoxSortBy1, true);
			this.comboBoxSortBy1.Size = new System.Drawing.Size(228, 21);
			this.comboBoxSortBy1.Sorted = true;
			this.comboBoxSortBy1.TabIndex = 1;
			// 
			// radioSortFields
			// 
			this.radioSortFields.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioSortFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.radioSortFields, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.radioSortFields, System.Windows.Forms.HelpNavigator.Topic);
			this.radioSortFields.Location = new System.Drawing.Point(6, 40);
			this.radioSortFields.Name = "radioSortFields";
			this.helpProvider1.SetShowHelp(this.radioSortFields, true);
			this.radioSortFields.Size = new System.Drawing.Size(158, 16);
			this.radioSortFields.TabIndex = 10;
			this.radioSortFields.TabStop = true;
			this.radioSortFields.Text = "Selected Field";
			this.radioSortFields.CheckedChanged += new System.EventHandler(this.radioSortFields_CheckedChanged);
			// 
			// radioSortTree
			// 
			this.radioSortTree.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioSortTree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.helpProvider1.SetHelpKeyword(this.radioSortTree, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.radioSortTree, System.Windows.Forms.HelpNavigator.Topic);
			this.radioSortTree.Location = new System.Drawing.Point(6, 12);
			this.radioSortTree.Name = "radioSortTree";
			this.helpProvider1.SetShowHelp(this.radioSortTree, true);
			this.radioSortTree.Size = new System.Drawing.Size(158, 16);
			this.radioSortTree.TabIndex = 9;
			this.radioSortTree.TabStop = true;
			this.radioSortTree.Text = "Data Tree Order";
			this.radioSortTree.CheckedChanged += new System.EventHandler(this.radioSortTree_CheckedChanged);
			// 
			// buttonPrint2
			// 
			this.buttonPrint2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrint2.Location = new System.Drawing.Point(420, 450);
			this.buttonPrint2.Name = "buttonPrint2";
			this.buttonPrint2.Size = new System.Drawing.Size(96, 23);
			this.buttonPrint2.TabIndex = 13;
			this.buttonPrint2.Text = "&Print";
			this.buttonPrint2.Click += new System.EventHandler(this.buttonPrint_Click);
			// 
			// panel24
			// 
			this.panel24.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel24.Location = new System.Drawing.Point(0, 0);
			this.panel24.Name = "panel24";
			this.panel24.Size = new System.Drawing.Size(652, 2);
			this.panel24.TabIndex = 69;
			// 
			// panel12
			// 
			this.panel12.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel12.Location = new System.Drawing.Point(0, 442);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(752, 2);
			this.panel12.TabIndex = 65;
			// 
			// panel13
			// 
			this.panel13.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel13.Location = new System.Drawing.Point(307, 0);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(2, 444);
			this.panel13.TabIndex = 64;
			// 
			// buttonBack
			// 
			this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBack.Location = new System.Drawing.Point(538, 450);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(94, 23);
			this.buttonBack.TabIndex = 14;
			this.buttonBack.Text = "&Back";
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// panelReportFormat
			// 
			this.panelReportFormat.Controls.Add(this.panelMatrixColumns);
			this.panelReportFormat.Controls.Add(this.label4);
			this.panelReportFormat.Location = new System.Drawing.Point(0, 73);
			this.panelReportFormat.Name = "panelReportFormat";
			this.panelReportFormat.Size = new System.Drawing.Size(302, 367);
			this.panelReportFormat.TabIndex = 62;
			this.panelReportFormat.Visible = false;
			// 
			// panelMatrixColumns
			// 
			this.panelMatrixColumns.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelMatrixColumns.Controls.Add(this.listBoxMatrixColumns);
			this.panelMatrixColumns.Location = new System.Drawing.Point(7, 26);
			this.panelMatrixColumns.Name = "panelMatrixColumns";
			this.panelMatrixColumns.Size = new System.Drawing.Size(294, 337);
			this.panelMatrixColumns.TabIndex = 3;
			this.panelMatrixColumns.TabStop = true;
			// 
			// listBoxMatrixColumns
			// 
			this.listBoxMatrixColumns.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.listBoxMatrixColumns.CheckOnClick = true;
			this.helpProvider1.SetHelpKeyword(this.listBoxMatrixColumns, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.listBoxMatrixColumns, System.Windows.Forms.HelpNavigator.Topic);
			this.listBoxMatrixColumns.IntegralHeight = false;
			this.listBoxMatrixColumns.Location = new System.Drawing.Point(1, 1);
			this.listBoxMatrixColumns.Name = "listBoxMatrixColumns";
			this.helpProvider1.SetShowHelp(this.listBoxMatrixColumns, true);
			this.listBoxMatrixColumns.Size = new System.Drawing.Size(292, 335);
			this.listBoxMatrixColumns.TabIndex = 4;
			// 
			// label4
			// 
			this.label4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(13, 6);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(189, 14);
			this.label4.TabIndex = 31;
			this.label4.Text = "Columns to Include in Matrix Report";
			this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// comboBoxReportFormat
			// 
			this.comboBoxReportFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.helpProvider1.SetHelpKeyword(this.comboBoxReportFormat, "ReportsReportFormatSortOrder.htm");
			this.helpProvider1.SetHelpNavigator(this.comboBoxReportFormat, System.Windows.Forms.HelpNavigator.Topic);
			this.comboBoxReportFormat.Location = new System.Drawing.Point(7, 46);
			this.comboBoxReportFormat.Name = "comboBoxReportFormat";
			this.helpProvider1.SetShowHelp(this.comboBoxReportFormat, true);
			this.comboBoxReportFormat.Size = new System.Drawing.Size(194, 21);
			this.comboBoxReportFormat.TabIndex = 3;
			this.comboBoxReportFormat.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportFormat_SelectedIndexChanged);
			// 
			// buttonPreview2
			// 
			this.buttonPreview2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPreview2.Location = new System.Drawing.Point(316, 450);
			this.buttonPreview2.Name = "buttonPreview2";
			this.buttonPreview2.Size = new System.Drawing.Size(95, 23);
			this.buttonPreview2.TabIndex = 12;
			this.buttonPreview2.Text = "Pre&view";
			this.buttonPreview2.Click += new System.EventHandler(this.buttonPreview_Click);
			// 
			// buttonCancel2
			// 
			this.buttonCancel2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel2.Location = new System.Drawing.Point(642, 450);
			this.buttonCancel2.Name = "buttonCancel2";
			this.buttonCancel2.Size = new System.Drawing.Size(94, 23);
			this.buttonCancel2.TabIndex = 15;
			this.buttonCancel2.Text = "&Close";
			this.buttonCancel2.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(319, 11);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(301, 28);
			this.label8.TabIndex = 7;
			this.label8.Text = "Sort Order";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.Location = new System.Drawing.Point(11, 11);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(189, 28);
			this.label9.TabIndex = 2;
			this.label9.Text = "Report Format";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// mnuContextMenu
			// 
			this.mnuContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.mnuItemSelectAll,
																						   this.mnuItemClearAll,
																						   this.menuItem3,
																						   this.mnuItemSelectUnder,
																						   this.mnuItemClearUnder,
																						   this.menuItem6,
																						   this.mnuItemExpandAll,
																						   this.mnuItemCollapseAll,
																						   this.menuItem9,
																						   this.mnuItemView});
			// 
			// mnuItemSelectAll
			// 
			this.mnuItemSelectAll.Index = 0;
			this.mnuItemSelectAll.Text = "&Select All";
			// 
			// mnuItemClearAll
			// 
			this.mnuItemClearAll.Index = 1;
			this.mnuItemClearAll.Text = "&Clear All";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// mnuItemSelectUnder
			// 
			this.mnuItemSelectUnder.Index = 3;
			this.mnuItemSelectUnder.Text = "Select all items under";
			// 
			// mnuItemClearUnder
			// 
			this.mnuItemClearUnder.Index = 4;
			this.mnuItemClearUnder.Text = "Clear all items under";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "-";
			// 
			// mnuItemExpandAll
			// 
			this.mnuItemExpandAll.Index = 6;
			this.mnuItemExpandAll.Text = "E&xpand All";
			// 
			// mnuItemCollapseAll
			// 
			this.mnuItemCollapseAll.Index = 7;
			this.mnuItemCollapseAll.Text = "C&ollapse All";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 8;
			this.menuItem9.Text = "-";
			// 
			// mnuItemView
			// 
			this.mnuItemView.Index = 9;
			this.mnuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.mnuItemViewNormal,
																						this.mnuItemViewSelected,
																						this.mnuItemViewReport,
																						this.mnuItemViewMainTree});
			this.mnuItemView.Text = "View";
			// 
			// mnuItemViewNormal
			// 
			this.mnuItemViewNormal.Checked = true;
			this.mnuItemViewNormal.Index = 0;
			this.mnuItemViewNormal.Text = "User selection";
			// 
			// mnuItemViewSelected
			// 
			this.mnuItemViewSelected.Index = 1;
			this.mnuItemViewSelected.Text = "Selected items only";
			// 
			// mnuItemViewReport
			// 
			this.mnuItemViewReport.Index = 2;
			this.mnuItemViewReport.Text = "Report Type items only";
			// 
			// mnuItemViewMainTree
			// 
			this.mnuItemViewMainTree.Index = 3;
			this.mnuItemViewMainTree.Text = "Same as main data view";
			// 
			// panelToolbar
			// 
			this.panelToolbar.BackColor = System.Drawing.Color.White;
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarSave);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarCopy);
			this.panelToolbar.Controls.Add(this.pictureBoxToolbarAdd);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateOptions);
			this.panelToolbar.Controls.Add(this.pictureBoxHelp);
			this.panelToolbar.Controls.Add(this.panel25);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateNew);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateDelete);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateEdit);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateSaveAs);
			this.panelToolbar.Controls.Add(this.pictureBoxTemplateSave);
			this.panelToolbar.Controls.Add(this.comboBoxReportTemplate);
			this.panelToolbar.Location = new System.Drawing.Point(0, 0);
			this.panelToolbar.Name = "panelToolbar";
			this.panelToolbar.Size = new System.Drawing.Size(752, 33);
			this.panelToolbar.TabIndex = 0;
			this.panelToolbar.Paint += new System.Windows.Forms.PaintEventHandler(this.panelToolbar_Paint);
			// 
			// pictureBoxToolbarSave
			// 
			this.pictureBoxToolbarSave.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarSave.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarSave.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarSave.Image")));
			this.pictureBoxToolbarSave.Location = new System.Drawing.Point(38, 6);
			this.pictureBoxToolbarSave.Name = "pictureBoxToolbarSave";
			this.pictureBoxToolbarSave.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarSave.TabIndex = 146;
			this.pictureBoxToolbarSave.TabStop = false;
			this.pictureBoxToolbarSave.Click += new System.EventHandler(this.pictureBoxTemplateSave_Click);
			// 
			// pictureBoxToolbarCopy
			// 
			this.pictureBoxToolbarCopy.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCopy.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCopy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCopy.Image")));
			this.pictureBoxToolbarCopy.Location = new System.Drawing.Point(65, 6);
			this.pictureBoxToolbarCopy.Name = "pictureBoxToolbarCopy";
			this.pictureBoxToolbarCopy.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCopy.TabIndex = 145;
			this.pictureBoxToolbarCopy.TabStop = false;
			this.pictureBoxToolbarCopy.Click += new System.EventHandler(this.pictureBoxTemplateSaveAs_Click);
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(11, 6);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 143;
			this.pictureBoxToolbarAdd.TabStop = false;
			this.pictureBoxToolbarAdd.Click += new System.EventHandler(this.pictureBoxTemplateNew_Click);
			// 
			// pictureBoxTemplateOptions
			// 
			this.pictureBoxTemplateOptions.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateOptions.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateOptions.Image")));
			this.pictureBoxTemplateOptions.Location = new System.Drawing.Point(692, 6);
			this.pictureBoxTemplateOptions.Name = "pictureBoxTemplateOptions";
			this.pictureBoxTemplateOptions.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateOptions.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateOptions.TabIndex = 91;
			this.pictureBoxTemplateOptions.TabStop = false;
			this.pictureBoxTemplateOptions.Click += new System.EventHandler(this.pictureBoxTemplateOptions_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(719, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 90;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// panel25
			// 
			this.panel25.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(224)), ((System.Byte)(192)));
			this.panel25.Controls.Add(this.label13);
			this.panel25.Location = new System.Drawing.Point(602, 4);
			this.panel25.Name = "panel25";
			this.panel25.Size = new System.Drawing.Size(140, 24);
			this.panel25.TabIndex = 93;
			this.panel25.Visible = false;
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.White;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(213)), ((System.Byte)(106)), ((System.Byte)(0)));
			this.label13.Location = new System.Drawing.Point(2, 2);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(136, 20);
			this.label13.TabIndex = 93;
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBoxTemplateNew
			// 
			this.pictureBoxTemplateNew.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateNew.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateNew.Image")));
			this.pictureBoxTemplateNew.Location = new System.Drawing.Point(13, 6);
			this.pictureBoxTemplateNew.Name = "pictureBoxTemplateNew";
			this.pictureBoxTemplateNew.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateNew.TabIndex = 89;
			this.pictureBoxTemplateNew.TabStop = false;
			this.pictureBoxTemplateNew.Click += new System.EventHandler(this.pictureBoxTemplateNew_Click);
			// 
			// pictureBoxTemplateDelete
			// 
			this.pictureBoxTemplateDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateDelete.Image")));
			this.pictureBoxTemplateDelete.Location = new System.Drawing.Point(387, 6);
			this.pictureBoxTemplateDelete.Name = "pictureBoxTemplateDelete";
			this.pictureBoxTemplateDelete.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateDelete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateDelete.TabIndex = 88;
			this.pictureBoxTemplateDelete.TabStop = false;
			this.pictureBoxTemplateDelete.Click += new System.EventHandler(this.pictureBoxTemplateDelete_Click);
			// 
			// pictureBoxTemplateEdit
			// 
			this.pictureBoxTemplateEdit.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateEdit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateEdit.Image")));
			this.pictureBoxTemplateEdit.Location = new System.Drawing.Point(360, 6);
			this.pictureBoxTemplateEdit.Name = "pictureBoxTemplateEdit";
			this.pictureBoxTemplateEdit.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateEdit.TabIndex = 87;
			this.pictureBoxTemplateEdit.TabStop = false;
			this.pictureBoxTemplateEdit.Click += new System.EventHandler(this.pictureBoxTemplateEdit_Click);
			// 
			// pictureBoxTemplateSaveAs
			// 
			this.pictureBoxTemplateSaveAs.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateSaveAs.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateSaveAs.Image")));
			this.pictureBoxTemplateSaveAs.Location = new System.Drawing.Point(64, 6);
			this.pictureBoxTemplateSaveAs.Name = "pictureBoxTemplateSaveAs";
			this.pictureBoxTemplateSaveAs.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateSaveAs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateSaveAs.TabIndex = 86;
			this.pictureBoxTemplateSaveAs.TabStop = false;
			this.pictureBoxTemplateSaveAs.Click += new System.EventHandler(this.pictureBoxTemplateSaveAs_Click);
			// 
			// pictureBoxTemplateSave
			// 
			this.pictureBoxTemplateSave.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxTemplateSave.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTemplateSave.Image")));
			this.pictureBoxTemplateSave.Location = new System.Drawing.Point(38, 6);
			this.pictureBoxTemplateSave.Name = "pictureBoxTemplateSave";
			this.pictureBoxTemplateSave.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxTemplateSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxTemplateSave.TabIndex = 85;
			this.pictureBoxTemplateSave.TabStop = false;
			this.pictureBoxTemplateSave.Click += new System.EventHandler(this.pictureBoxTemplateSave_Click);
			// 
			// comboBoxReportTemplate
			// 
			this.comboBoxReportTemplate.BackColor = System.Drawing.Color.White;
			this.comboBoxReportTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportTemplate.DropDownWidth = 194;
			this.comboBoxReportTemplate.Location = new System.Drawing.Point(93, 6);
			this.comboBoxReportTemplate.MaxDropDownItems = 20;
			this.comboBoxReportTemplate.Name = "comboBoxReportTemplate";
			this.comboBoxReportTemplate.Size = new System.Drawing.Size(259, 21);
			this.comboBoxReportTemplate.TabIndex = 0;
			this.comboBoxReportTemplate.DropDown += new System.EventHandler(this.comboBoxReportTemplate_DropDown);
			this.comboBoxReportTemplate.SelectedIndexChanged += new System.EventHandler(this.comboBoxReportTemplate_SelectedIndexChanged);
			// 
			// timer
			// 
			this.timer.Interval = 250;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// ReportFilterForm
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(746, 512);
			this.Controls.Add(this.buttonCancelOrig);
			this.Controls.Add(this.panelToolbar);
			this.Controls.Add(this.buttonPreview);
			this.Controls.Add(this.buttonPrint);
			this.Controls.Add(this.panelReportForm1);
			this.Controls.Add(this.panelReportForm2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.helpProvider1.SetHelpKeyword(this, "Reports.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(752, 544);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(752, 544);
			this.Name = "ReportFilterForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "WAM Reports";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.ReportFilterForm_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReportFilterForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportFilterForm_Paint);
			this.panelReportForm1.ResumeLayout(false);
			this.panelFilterYesNo.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panelTree.ResumeLayout(false);
			this.panelFilter.ResumeLayout(false);
			this.groupBoxAddFilter.ResumeLayout(false);
			this.groupBoxCriteria.ResumeLayout(false);
			this.panelListBox.ResumeLayout(false);
			this.groupBoxApplyLevel.ResumeLayout(false);
			this.panelReportForm2.ResumeLayout(false);
			this.groupBoxIncludePhotos.ResumeLayout(false);
			this.groupBoxIncludeRetired.ResumeLayout(false);
			this.groupBoxSortBy.ResumeLayout(false);
			this.panelSortBy.ResumeLayout(false);
			this.panel16.ResumeLayout(false);
			this.panel14.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panelReportFormat.ResumeLayout(false);
			this.panelMatrixColumns.ResumeLayout(false);
			this.panelToolbar.ResumeLayout(false);
			this.panel25.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/
		protected override void OnLoad(EventArgs e)
		{
//			//make the first report screen visible
//			panelReportForm1.Visible = true;
//			panelReportForm1.BringToFront();
//			panelReportForm2.Visible = false;

			//retrieve the form state
			Drive.Configuration.FormState formState = new Drive.Configuration.FormState(
				Drive.Configuration.AppSettings.Settings.GetSetting("ScreenSettings", this.Name));
			formState.RestoreState(this);
			CheckFormProperties();

			//mam
			this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);

			//make the first report screen visible
			panelReportForm1.Visible = true;
			panelReportForm1.BringToFront();
			panelReportForm2.Visible = false;

			//mam
			SetToolTips();
			SetBitmaps();
			this.Refresh();
			//</mam>

			treeViewSpecificUnits.ImageList = this.imageListTree;
			treeViewSpecificUnits.ImageIndex = 9;
			treeViewSpecificUnits.SelectedImageIndex = 9;
			//imageListTree.TransparentColor = Color.Fuchsia;

			treeViewCriteria.ImageList = this.imageListTree;
			treeViewCriteria.ImageIndex = 6;
			treeViewCriteria.SelectedImageIndex = 6;

			//mam 03202012 - added isImportFormatReport argument
			//LoadSpecificUnitsTree();
			LoadSpecificUnitsTree(false);

			this.radioFilterYes.Checked = true;
			SetDefaultValue("Criteria");
			LoadReportTypeCombo();
			LoadContextMenu();
			LoadReportFormatCombo();
			LoadMatrixReportColumnsList();
			LoadSortByLists();
			LoadTemplateCombo();

			this.radioSortTree.Checked = true;
			this.radioAsc1.Checked = true;
			this.radioAsc2.Checked = true;
			this.radioAsc3.Checked = true;
			this.radioAsc4.Checked = true;
			this.radioAsc5.Checked = true;
			//</mam>

//			//mam
//			SetToolTips();
//			SetBitmaps();
//			//</mam>

			listBoxCriteria.DisplayMember = "Description";
			treeViewSpecificUnits.ContextMenu = mnuContextMenu;
			filterBuilderForm21.buttonAddCriteria.Click += new System.EventHandler(this.buttonAddCriteria_Click2);
			filterBuilderForm21.buttonCancelEdit.Click += new System.EventHandler(this.buttonCancel_Click2);

			LoadPreferences();

			m_initialized = true;

			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			PopulateSortByCombos(nodeTypeReport);

			comboBoxReportType_SelectedIndexChanged(this, e);
			if (comboBoxReportTemplate.SelectedIndex > -1)
				currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;

			//m_initialized = true;

			SetReportTemplateSettings();

			if (mnuItemViewMainTree.Checked)
			{
				nodesExpandedResurrect = nodesExpandedMainForm;
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectExpandedNodes(node);
				}
				treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}

			//mam
			CountCheckedNodes();
			//</mam>

			ResetDirty();

			comboBoxReportType.Focus();

			//m_initialized = true;

			this.ResumeLayout();
			base.OnLoad(e);
		}

		private void panelToolbar_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void LoadPreferences()
		{
			SetCurrentView(Drive.Configuration.AppSettings.Settings.GetSettingInt("Defaults", "ReportTemplateView", 0));
			optionAutoSave = Drive.Configuration.AppSettings.Settings.GetSettingInt("Defaults", "ReportTemplateAutoSave", 1);
		}

		private void SetToolTips()
		{
			// Create the ToolTip and associate with the Form container.
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.comboBoxReportTemplate, "Report templates");

			//toolTip.SetToolTip(this.pictureBoxTemplateNew, "Create a new report template");
			//toolTip.SetToolTip(this.pictureBoxTemplateSave, "Save the current template settings");
			//toolTip.SetToolTip(this.pictureBoxTemplateSaveAs, "Save the current settings to a new template");

			toolTip.SetToolTip(this.pictureBoxToolbarAdd, "Create a new report template");
			toolTip.SetToolTip(this.pictureBoxToolbarSave, "Save the current template settings");
			toolTip.SetToolTip(this.pictureBoxToolbarCopy, "Save the current settings to a new template");

			toolTip.SetToolTip(this.pictureBoxTemplateEdit, "Edit the name of the report template");
			toolTip.SetToolTip(this.pictureBoxTemplateDelete, "Delete the current report template");
			toolTip.SetToolTip(this.pictureBoxTemplateOptions, "Preferences");
			toolTip.SetToolTip(this.pictureBoxHelp, "Help");

			toolTip.SetToolTip(this.comboBoxReportTemplate, "Existing report templates");
		}

		private void SetBitmaps()
		{
			//load toolbar pictureboxes with bitmaps
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			System.IO.Stream file = null;
			Image image = null;

			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks.SetBitmap(pictureBoxTemplateDelete);

			//***************************
			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarAdd.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarAdd);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonSaveOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarSave.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarSave);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonCopyOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarCopy.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarCopy);

			Bitmap b = (Bitmap)pictureBoxToolbarAdd.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarAdd.Image = b;

			b = (Bitmap)pictureBoxToolbarCopy.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarCopy.Image = b;

			b = (Bitmap)pictureBoxToolbarSave.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarSave.Image = b;

			commonTasks = null;
			file = null;
			image = null;
		}
		private void LoadContextMenu()
		{
			this.mnuContextMenu.Popup += new System.EventHandler(MyPopupEventHandler);
			this.mnuItemSelectAll.Click += new System.EventHandler(mnuItemSelectAll_OnClick);
			this.mnuItemClearAll.Click += new System.EventHandler(mnuItemClearAll_OnClick);
			this.mnuItemSelectUnder.Click += new System.EventHandler(mnuItemSelectUnder_OnClick);
			this.mnuItemClearUnder.Click += new System.EventHandler(mnuItemClearUnder_OnClick);
			this.mnuItemExpandAll.Click += new System.EventHandler(mnuItemExpandAll_OnClick);
			this.mnuItemCollapseAll.Click += new System.EventHandler(mnuItemCollapseAll_OnClick);
			this.mnuItemViewNormal.Click += new System.EventHandler(mnuItemViewNormal_OnClick);
			this.mnuItemViewSelected.Click += new System.EventHandler(mnuItemViewSelected_OnClick);
			this.mnuItemViewReport.Click += new System.EventHandler(mnuItemViewReport_OnClick);
			this.mnuItemViewMainTree.Click += new System.EventHandler(mnuItemViewMainTree_OnClick);
		}

		protected void MyPopupEventHandler(System.Object sender, System.EventArgs e)
		{
			string nodeText = "";
 
			if (nodeHitTest == null)
			{
				mnuContextMenu.MenuItems[2].Visible = false;
				mnuContextMenu.MenuItems[3].Visible = false;
				mnuContextMenu.MenuItems[4].Visible = false;
			}
			else
			{
				//mam 03202012 - get report type
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (
					NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;

				if (nodeHitTest.Nodes.Count == 0)
				{
					mnuContextMenu.MenuItems[2].Visible = false;
					mnuContextMenu.MenuItems[3].Visible = false;
					mnuContextMenu.MenuItems[4].Visible = false;
				}
				//may not do this:
				//check for red or black ForeColor because we're color-coding them red or black
				//	to match the main data tree
				//mam 03202012 - added check for ImportFormat report type
				//	(always use hit test node, not its parent node, when report is ImportFormat because all nodes are selectable)
				else if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209)
					&& nodeTypeReport != NodeTypeHandler.NodeTypeReport.ImportFormat)
				//else if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
				{
					if (nodeHitTest.Parent != null)
					{
						mnuContextMenu.MenuItems[2].Visible = true;
						mnuContextMenu.MenuItems[3].Visible = true;
						mnuContextMenu.MenuItems[4].Visible = true;

						nodeText = nodeHitTest.Parent.Text;
						if (nodeText.Length > 25)
						{
							nodeText = nodeHitTest.Parent.Text.Substring(0, 25) + "...";
						}
					
						mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
						mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
					}
				}
				else
				{
					mnuContextMenu.MenuItems[2].Visible = true;
					mnuContextMenu.MenuItems[3].Visible = true;
					mnuContextMenu.MenuItems[4].Visible = true;

					nodeText = nodeHitTest.Text;
					if (nodeText.Length > 25)
					{
						nodeText = nodeHitTest.Text.Substring(0, 25) + "...";
					}
					
					mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
					mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
				}
			}
		}

		private void LoadReportTypeCombo()
		{
			// the following code uses the enumerated values to populate the combo boxes
			NodeTypeHandler.NodeTypeReport[] sources = (NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			ListItem[]		items = new ListItem[sources.Length];

			for (int i = 0; i < sources.Length; i++)
				items[i] = new ListItem(NodeTypeHandler.GetNodeTypeStringReport(sources[i]), sources[i]);

			comboBoxReportType.BeginUpdate();
			comboBoxReportType.Items.Clear();
			comboBoxReportType.DisplayMember = "DisplayMember";
			comboBoxReportType.Items.AddRange (items);
			comboBoxReportType.EndUpdate();

			comboBoxReportType.SelectedIndex = 0;

			comboBoxApplyFiltersTo.BeginUpdate();
			comboBoxApplyFiltersTo.Items.Clear();
			comboBoxApplyFiltersTo.DisplayMember = "DisplayMember";
			comboBoxApplyFiltersTo.Items.AddRange (items);
			comboBoxApplyFiltersTo.EndUpdate();

			comboBoxApplyFiltersTo.SelectedIndex = 0;
		}

		private void LoadReportFormatCombo()
		{
			ReportFormat[] reportFormat = (ReportFormat[])Enum.GetValues(typeof(ReportFormat));

			comboBoxReportFormat.Items.Clear();
			comboBoxReportFormat.BeginUpdate();
			comboBoxReportFormat.DisplayMember = "DisplayMember";
			for (int pos = 0; pos < reportFormat.Length; pos++)
			{
				comboBoxReportFormat.Items.Add(new ListItem(
					EnumHandlers.GetReportFormatString(reportFormat[pos]),reportFormat[pos]));
			}
			comboBoxReportFormat.EndUpdate();

			comboBoxReportFormat.SelectedIndex = 0;
		}

		private void LoadMatrixReportColumnsList()
		{
			UnitFilter.FilterSource[] sources = (UnitFilter.FilterSource[])Enum.GetValues(typeof(UnitFilter.FilterSource));
			ListItem[]		items = new ListItem[sources.Length-1];

			int				pos;
			string[] TestString = new string[sources.Length-1];

			for (pos = 1; pos < sources.Length; pos++)
			{
				items[pos-1] = new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]);
				TestString[pos-1] = UnitFilter.GetFilterSourceString(sources[pos]);
			}

			//mam
			//Array.Sort(items);
			Array.Sort(TestString);
			//</mam>

			listBoxMatrixColumns.BeginUpdate();
			listBoxMatrixColumns.Items.Clear();
			listBoxMatrixColumns.Items.AddRange(TestString);
			listBoxMatrixColumns.EndUpdate();
		}

		private void		LoadSortByLists()
		{
			//mam - loading the SortBy combos will be performed when clicking the Next button
			comboBoxSortBy1.DisplayMember = "DisplayMember";
			comboBoxSortBy2.DisplayMember = "DisplayMember";
			comboBoxSortBy3.DisplayMember = "DisplayMember";
			comboBoxSortBy4.DisplayMember = "DisplayMember";
			comboBoxSortBy5.DisplayMember = "DisplayMember";
		}

		//mam
		private void PopulateApplyToCombo(NodeTypeHandler.NodeTypeReport nodeTypeReport)
		{
			comboBoxApplyFiltersTo.Items.Clear();

			//mam - for temporary use only (to allow only the report type to be filtered on)
			//mam - update - the combobox is not being used, but let's leave the code here for now
			comboBoxApplyFiltersTo.Items.Add(comboBoxReportType.Items[comboBoxReportType.SelectedIndex]);

			if (comboBoxApplyFiltersTo.Items.Count > 0)
			{
				comboBoxApplyFiltersTo.SelectedIndex = 0;
			}

			VerifyFilters();
		}
		//</mam>

		//mam
		private void PopulateSortByCombos(NodeTypeHandler.NodeTypeReport nodeReportType)
		{
			if (!m_initialized)
				return;

			//get the selected node type
			WAM.UI.NodeType nodeType = new WAM.UI.NodeType();
			switch (nodeReportType)
			{
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Facility:
					nodeType = WAM.UI.NodeType.Facility;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.TreatmentProcess:
					nodeType = WAM.UI.NodeType.TreatmentProcess;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.MajorComponent:
					nodeType = WAM.UI.NodeType.MajorComponent;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Discipline:
					nodeType = WAM.UI.NodeType.NoneSelected;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineLand:
					nodeType = WAM.UI.NodeType.DisciplineLand;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineMech:
					nodeType = WAM.UI.NodeType.DisciplineMech;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineStruct:
					nodeType = WAM.UI.NodeType.DisciplineStruct;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineNode:
					nodeType = WAM.UI.NodeType.DisciplineNode;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplinePipe:
					nodeType = WAM.UI.NodeType.DisciplinePipe;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset:
					nodeType = WAM.UI.NodeType.AssetList;
					break;
			}

			//note the selected sort items unless the report type is Component Asset
			//if (nodeType != WAM.UI.NodeType.AssetList)
			if (!wasAssetReport)
			{	wasAssetReport = false;
				selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
				selectedSortItem2 = comboBoxSortBy2.SelectedItem as ListItem;
				selectedSortItem3 = comboBoxSortBy3.SelectedItem as ListItem;
				selectedSortItem4 = comboBoxSortBy4.SelectedItem as ListItem;
				selectedSortItem5 = comboBoxSortBy5.SelectedItem as ListItem;
			}

			//clear the sort combo boxes
			comboBoxSortBy1.Items.Clear();
			comboBoxSortBy2.Items.Clear();
			comboBoxSortBy3.Items.Clear();
			comboBoxSortBy4.Items.Clear();
			comboBoxSortBy5.Items.Clear();

			//load the combo boxes with approved items
			if (comboBoxReportType.SelectedItem != null)
			{
				UnitFilter.FilterSourceSort[] sources = (UnitFilter.FilterSourceSort[])Enum.GetValues(typeof(UnitFilter.FilterSourceSort));
				ArrayList		arrayList = new ArrayList();

				int				pos;
				int				selectedIndex = 0;
				
				for (pos = 0; pos < sources.Length; pos++)
					if (UnitFilter.GetFilterSourceStringSort(sources[pos], nodeType) != "")
					{
						arrayList.Add(new ListItem(UnitFilter.GetFilterSourceStringSort(sources[pos]), sources[pos]));
					}

				ListItem[]		items = new ListItem[arrayList.Count];
				for (pos = 0; pos < arrayList.Count; pos++)
					items[pos] = (ListItem)arrayList[pos];

				comboBoxSortBy1.BeginUpdate();
				comboBoxSortBy1.DisplayMember = "DisplayMember";
				comboBoxSortBy1.Items.Clear();
				comboBoxSortBy1.Items.AddRange(items);
				comboBoxSortBy1.EndUpdate();

				comboBoxSortBy2.BeginUpdate();
				comboBoxSortBy2.DisplayMember = "DisplayMember";
				comboBoxSortBy2.Items.Clear();
				comboBoxSortBy2.Items.AddRange(items);
				comboBoxSortBy2.EndUpdate();

				comboBoxSortBy3.BeginUpdate();
				comboBoxSortBy3.DisplayMember = "DisplayMember";
				comboBoxSortBy3.Items.Clear();
				comboBoxSortBy3.Items.AddRange(items);
				comboBoxSortBy3.EndUpdate();

				comboBoxSortBy4.BeginUpdate();
				comboBoxSortBy4.DisplayMember = "DisplayMember";
				comboBoxSortBy4.Items.Clear();
				comboBoxSortBy4.Items.AddRange(items);
				comboBoxSortBy4.EndUpdate();

				comboBoxSortBy5.BeginUpdate();
				comboBoxSortBy5.DisplayMember = "DisplayMember";
				comboBoxSortBy5.Items.Clear();
				comboBoxSortBy5.Items.AddRange(items);
				comboBoxSortBy5.EndUpdate();

				comboBoxSortBy1.SelectedIndex = selectedIndex;
				comboBoxSortBy2.SelectedIndex = selectedIndex;
				comboBoxSortBy3.SelectedIndex = selectedIndex;
				comboBoxSortBy4.SelectedIndex = selectedIndex;
				comboBoxSortBy5.SelectedIndex = selectedIndex;

				if (nodeType != WAM.UI.NodeType.AssetList)
					ResurrectSelectedSortSelections();
			}
		}
		//</mam>

		private void ResurrectSelectedSortSelections()
		{
			//selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
			//if (selectedSortItem1 != null)
			//	MessageBox.Show(selectedSortItem1.DisplayMember.ToString());

			//if (selectedSortItem2 != null)
			//	MessageBox.Show(selectedSortItem2.Value.ToString());

			SetComboBoxItem(comboBoxSortBy1, selectedSortItem1);
			SetComboBoxItem(comboBoxSortBy2, selectedSortItem2);
			SetComboBoxItem(comboBoxSortBy3, selectedSortItem3);
			SetComboBoxItem(comboBoxSortBy4, selectedSortItem4);
			SetComboBoxItem(comboBoxSortBy5, selectedSortItem5);
		}

		private void SetComboBoxItem(ComboBox comboBox, ListItem listItem)
		{
			if (comboBox == null)
				return;

			int i = 0;

			if (listItem == null)
			{
				if (comboBox.Items.Count > 0)
					comboBox.SelectedIndex = 0;
			}
			else
			{
				for (i = 0; i < comboBox.Items.Count; i++)
				{
					//MessageBox.Show(listItem.DisplayMember.ToString());
					//MessageBox.Show(((ListItem)comboBox.Items[i]).DisplayMember.ToString());
					if (((ListItem)comboBox.Items[i]).DisplayMember == listItem.DisplayMember)
					{
						comboBox.SelectedIndex = i;
						break;
					}
				}
			}
		}

		private void LoadTemplateCombo()
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			ArrayList ComboBoxItems = new ArrayList();
			StringBuilder builder = new StringBuilder(200);

			//clear the combo box whether or not there are any new items to put into it
			comboBoxReportTemplate.DataSource = null;
			comboBoxReportTemplate.Items.Clear();
			
			//dataSet = dataAccess.GetDisconnectedDataset(
			//	@"SELECT ReportTemplateID AS ID, 0 AS EnumValue, 
			//	TemplateName AS Description FROM ReportTemplate 
			//	WHERE InfoSetID = " + InfoSet.CurrentID
			//	+ " ORDER BY TemplateName, ReportTemplateID");
			builder.Append(@"SELECT ReportTemplateID AS ID, 0 AS EnumValue, TemplateName AS Description FROM ReportTemplate");
			builder.AppendFormat(" WHERE InfoSetID = {0} AND GraphTemplate <> 1", InfoSet.CurrentID);
			builder.Append(" ORDER BY TemplateName, ReportTemplateID");
			dataSet = dataAccess.GetDisconnectedDataset(builder.ToString());

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.LoadTemplateCombo.");
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Unable to load combo box");
			
			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				ComboBoxItems.Add(new WAM.Common.ComboBoxItem((int)dataRow["ID"], 
					(string)dataRow["Description"], (int)dataRow["EnumValue"], ""));
			}

			if (ComboBoxItems.Count > 0)
			{
				comboBoxReportTemplate.DataSource = null;
				comboBoxReportTemplate.BeginUpdate();
				comboBoxReportTemplate.Items.Clear();
				comboBoxReportTemplate.DataSource = ComboBoxItems;
				comboBoxReportTemplate.EndUpdate();
			}
			
			if (comboBoxReportTemplate.Items.Count > 0)
				comboBoxReportTemplate.SelectedIndex = 0;
			
			comboBoxReportTemplate.DisplayMember = "ItemDescription";
			comboBoxReportTemplate.ValueMember = "ItemID";

			if (comboBoxReportTemplate.SelectedIndex > -1)
			{
				currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
			}
		}

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/

		public static void	ShowForm(Form owner, ArrayList nodesExpandedMain)
			//public static void	ShowForm(Form owner, WAM.UI.ReportFilterForm2 formReport)
		{
			ReportFilterForm form = new ReportFilterForm();
			try
			{
				//mam
				nodesExpandedMainForm = nodesExpandedMain;
				//</mam>

				form.ShowDialog(owner);
			}
			catch (System.ArgumentException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("ReportFilterForm.ShowForm Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			// Save our form state
			Drive.Configuration.FormState formState = 
				new Drive.Configuration.FormState(this);

			Drive.Configuration.AppSettings.Settings.SetSetting(
				@"ScreenSettings", this.Name, formState.ToString());

			//mam - make sure View and AutoSave are written out to the WAM.xml file
			SavePreferences();
			Drive.Configuration.AppSettings.Settings.Save();
			//</mam>

			base.OnClosing(e);
			this.Dispose(true);
		}

		private void panelReportForm1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void ResetDirty()
		{
			dirtyNodes = false;
			dirtyFilters = false;
			dirtyTemplate = false;
			forceSave = false;
		}

		private void SetDirtyNodes(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			Control requestingControl = (Control)sender;
			//MessageBox.Show(requestingControl.Name.ToString());
			dirtyNodes = true;
		}

		private void SetDirtyFilter(object sender, System.EventArgs e)
		{
			Control requestingControl = (Control)sender;
			dirtyFilters = true;
		}

		private void SetDirtyTemplate(object sender, System.EventArgs e)
		{
			Control requestingControl = (Control)sender;
			dirtyTemplate = true;
		}

		//mam 03202012 - commented this code - there is no comboBoxFacility
		//private void comboBoxFacility_SelectedIndexChanged(object sender, System.EventArgs e)
		//{
		//	if (!m_initialized)
		//	{
		//		LoadSpecificUnitsTree();
		//		return;
		//	}
		//}
		
		private void treeViewSpecificUnits_AfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			//if (!m_initialized)
			//	return;

			//mam - not using this code
			//			if (!m_initialized)
			//				return;
			//
			//			if (!radioSelectedUnits.Checked)
			//				radioSelectedUnits.Checked = true;
			//</mam>
		}

		private void radioFilterYes_CheckedChanged(object sender, System.EventArgs e)
		{
			panelFilter.Enabled = radioFilterYes.Checked;
		}

		private void radioFilterNo_CheckedChanged(object sender, System.EventArgs e)
		{
			panelFilter.Enabled = !radioFilterNo.Checked;
		}

		private void radioSortTree_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panelSortBy.Enabled = this.radioSortFields.Checked;
		}

		private void radioSortFields_CheckedChanged(object sender, System.EventArgs e)
		{
			this.panelSortBy.Enabled = this.radioSortFields.Checked;
		}

		private void buttonBack_Click(object sender, System.EventArgs e)
		{
			panelReportForm1.Visible = true;
			panelReportForm2.SendToBack();
			panelReportForm2.Visible = false;

			comboBoxReportType.Focus();
		}

		private void comboBoxReportType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				nodeHitTest = null;

				//mam - commented because the filters don't need to be reset when changing report type
				//	unless we're going to recreate them based on report type
//				filterBuilderForm21.ResetAll();
//				this.listBoxCriteria.Items.Clear();
//				SetDefaultValue("Criteria");
//				ResetFilters();

				GetSelectedTreeNodes();
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (
					NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;

				//mam 03202012 - moved this up from below
				//SetCurrentNodeType();

				//mam
				//disable "Include Photos" for Pipes, Nodes, and Assets
				//mam 03202012 - and for Import Format report
				this.checkBoxIncludePhotos.Enabled = true;
				if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ComponentAsset
					|| nodeTypeReport == NodeTypeHandler.NodeTypeReport.DisciplineNode
					|| nodeTypeReport == NodeTypeHandler.NodeTypeReport.DisciplinePipe
					|| nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat)
				{
					this.checkBoxIncludePhotos.Enabled = false;
				}

				//mam 03202012
				RecordTreeExpandedState();

				//mam 03202012
				bool restoreExpanded = false;
				if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat)
				{
					//load the tree with all disciplines
					//save checked nodes first???
					LoadSpecificUnitsTree(true);
					restoreExpanded = true;
				}
				if (previousReportType == NodeTypeHandler.NodeTypeReport.ImportFormat)
				{
					//load the tree with only disciplines that have a condition other than n/a
					//save checked nodes first???
					LoadSpecificUnitsTree(false);
					restoreExpanded = true;
				}

				//mam 03202012
				if (restoreExpanded)
				{
					nodesExpandedResurrect = nodesExpanded;
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ResurrectExpandedNodes(node);
					}
				}

				ConfigureTree(nodeTypeReport, true);
				treeViewSpecificUnits.Refresh();
				PopulateApplyToCombo(nodeTypeReport);
				SetCurrentNodeType();
				SetCurrentApplyFilterNodeType();

				//mam - not necessary to call CheckNodesAll because the nodes are
				//	unchecked in ConfigureTree when passing in "true"
				//if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.Discipline)
				//	CheckNodesAll(false);

				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectSelectedNodes(node);
				}

				// if the user is viewing only the selected items, 
				//	configure the tree to show only those items
				if (mnuItemViewSelected.Checked)
				{
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ConfigureTreeSelectedNodes(node);
					}
					if (treeViewSpecificUnits.Nodes.Count > 0)
						treeViewSpecificUnits.Nodes[0].EnsureVisible();
				}
//				else if (mnuItemViewMainTree.Checked)
//				{
//					nodesExpandedResurrect = nodesExpandedMainForm;
//					treeViewSpecificUnits.CollapseAll();
//					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
//					{
//						ResurrectExpandedNodes(node);
//					}
//				}

				PopulateSortByCombos(nodeTypeReport);
				ResetEditing(false);
				VerifyFilters();

				//mam - note whether the current report is Component Asset
				wasAssetReport = false;
				if (currentNodeType == WAM.UI.NodeType.AssetList)
					wasAssetReport = true;
				//</mam>

				//disable Sort By for Asset
				this.radioSortFields.Enabled = true;

				//no need to remove items from combo box - just disable the radio button
				panelFilterYesNo.Enabled = true;
				if (radioFilterYes.Checked)
					panelFilter.Enabled = true;
				else
					panelFilter.Enabled = false;

				if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ComponentAsset)
				{
					panelFilterYesNo.Enabled = false;
					panelFilter.Enabled = false;
				}

				//mam 03202012 - disable filter, report format combo, include photos checkbox, and the preview and print buttons for ImportFormat report
				bool enableReportControls = nodeTypeReport != NodeTypeHandler.NodeTypeReport.ImportFormat;
				panelFilter.Enabled = enableReportControls;
				panel4.Enabled = enableReportControls;
				//comboBoxReportFormat.Enabled = enableReportControls;
				//checkBoxIncludePhotos.Enabled = enableReportControls;
				buttonPreview2.Enabled = enableReportControls;
				buttonPrint2.Enabled = enableReportControls;

				//mam 03202012
				previousReportType = nodeTypeReport;

				//mam 03202012
				//nodesExpandedResurrect = nodesExpanded;
				//treeViewSpecificUnits.CollapseAll();
				//foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				//{
				//	ResurrectExpandedNodes(node);
				//}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
				CountCheckedNodes();
			}
		}

		private void comboBoxReportFormat_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.panelReportFormat.Enabled = false;
			if (comboBoxReportFormat.SelectedIndex == 1)
				this.panelReportFormat.Enabled = true;

			if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Standard)
				checkBoxIncludePhotos.Enabled = true;
			else
				checkBoxIncludePhotos.Enabled = false;
		}

		private void ReportFilterForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//MakeTransparentBitmap(e);
		}

		private void comboBoxApplyFiltersTo_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			SetFilterComboBoxContents(sender, e);
			SetCurrentApplyFilterNodeType();
		}

		private void VerifyFilters()
		{
			if (listBoxCriteria.Items.Count == 1 &&
				listBoxCriteria.Items[0] is string)
				return;

			foreach (TreeNode node in treeViewCriteria.Nodes)
			{
				node.ForeColor = Color.Black;
				node.Tag = "ENABLED";
				node.ImageIndex = 6;
				node.SelectedImageIndex = 6;
			}

			for (int i = 0; i < listBoxCriteria.Items.Count; i++)
			{
				UnitFilter unitFilter = listBoxCriteria.Items[i] as UnitFilter;

				if (UnitFilter.GetFilterSourceString((UnitFilter.FilterSource)unitFilter.Source, currentApplyFilterNodeType) == ""
					|| UnitFilter.GetFilterCompareToString((UnitFilter.FilterCompareTo)unitFilter.Compare, currentApplyFilterNodeType) == "")
				{
					//listBoxCriteria.Items.RemoveAt(i);
					treeViewCriteria.Nodes[i].ForeColor = Color.Gray;
					treeViewCriteria.Nodes[i].Tag = "DISABLED";
					treeViewCriteria.Nodes[i].ImageIndex = 1;
					treeViewCriteria.Nodes[i].SelectedImageIndex = 1;
				}
			}

			SetDefaultValue("Criteria");
		}

		private void SetFilterComboBoxContents(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			if (comboBoxApplyFiltersTo.SelectedItem != null)
			{
				ListItem sourceItem = comboBoxApplyFiltersTo.SelectedItem as ListItem;
				switch ((NodeTypeHandler.NodeTypeReport)sourceItem.Value)
				{
					case NodeTypeHandler.NodeTypeReport.Facility:
						filterBuilderForm21.LoadSourceFilterList(NodeType.Facility);
						filterBuilderForm21.LoadCompareToList(NodeType.Facility);
						break;
					case NodeTypeHandler.NodeTypeReport.TreatmentProcess:
						filterBuilderForm21.LoadSourceFilterList(NodeType.TreatmentProcess);
						filterBuilderForm21.LoadCompareToList(NodeType.TreatmentProcess);
						break;
					case NodeTypeHandler.NodeTypeReport.MajorComponent:
						filterBuilderForm21.LoadSourceFilterList(NodeType.MajorComponent);
						filterBuilderForm21.LoadCompareToList(NodeType.MajorComponent);
						break;
					case NodeTypeHandler.NodeTypeReport.Discipline:
						//mam - change to none selected
						//filterBuilderForm21.LoadSourceFilterList(NodeType.DisciplineLand);
						//filterBuilderForm21.LoadCompareToList(NodeType.DisciplineLand);
						filterBuilderForm21.LoadSourceFilterList(NodeType.NoneSelected);
						filterBuilderForm21.LoadCompareToList(NodeType.NoneSelected);
						break;
					case NodeTypeHandler.NodeTypeReport.DisciplineLand:
						filterBuilderForm21.LoadSourceFilterList(NodeType.DisciplineLand);
						filterBuilderForm21.LoadCompareToList(NodeType.DisciplineLand);
						break;
					case NodeTypeHandler.NodeTypeReport.DisciplineMech:
						filterBuilderForm21.LoadSourceFilterList(NodeType.DisciplineMech);
						filterBuilderForm21.LoadCompareToList(NodeType.DisciplineMech);
						break;
					case NodeTypeHandler.NodeTypeReport.DisciplineStruct:
						filterBuilderForm21.LoadSourceFilterList(NodeType.DisciplineStruct);
						filterBuilderForm21.LoadCompareToList(NodeType.DisciplineStruct);
						break;
					case NodeTypeHandler.NodeTypeReport.ComponentAsset:
						filterBuilderForm21.LoadSourceFilterList(NodeType.AssetList);
						filterBuilderForm21.LoadCompareToList(NodeType.AssetList);
						break;
					default:
						filterBuilderForm21.LoadSourceFilterList(NodeType.InfoSet);
						filterBuilderForm21.LoadCompareToList(NodeType.InfoSet);
						break;
				}
			}
		}

		private void ResetFilters()
		{
			m_filters = null;
		}

		private void ResetEditing(bool allowEdit)
		{
			if (allowEdit)
			{
				editingFilter = true;
				filterBuilderForm21.buttonCancelEdit.Visible = true;
				filterBuilderForm21.buttonAddCriteria.Text = "Save Changes";
			}
			else
			{
				editingFilter = false;
				filterBuilderForm21.ResetButtons();
			}
		}

		private void ResetViewItems()
		{
			mnuItemViewNormal.Checked = false;
			mnuItemViewSelected.Checked = false;
			mnuItemViewReport.Checked = false;
			mnuItemViewMainTree.Checked = false;
		}

		private int GetCurrentView()
		{
			if (mnuItemViewNormal.Checked)
				return 0;

			if (mnuItemViewSelected.Checked)
				return 1;

			if (mnuItemViewReport.Checked)
				return 2;

			if (mnuItemViewMainTree.Checked)
				return 3;

			return 0;
		}

		private void SetCurrentView(int curView)
		{
			ResetViewItems();

			switch (curView)
			{
				case 0:
					mnuItemViewNormal.Checked = true;
					break;
				case 1:
					mnuItemViewSelected.Checked = true;
					break;
				case 2:
					mnuItemViewReport.Checked = true;
					break;
				case 3:
					mnuItemViewMainTree.Checked = true;
					break;
				default:
					mnuItemViewNormal.Checked = true;
					break;
			}
		}

		private void listBoxCriteria_DoubleClick(object sender, System.EventArgs e)
		{
			if (listBoxCriteria.SelectedItem != null)
				buttonEditCriteria_Click(sender, e);
		}

		private void SetCurrentNodeType()
		{
			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			switch (nodeTypeReport)
			{
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Facility:
					currentNodeType = WAM.UI.NodeType.Facility;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.TreatmentProcess:
					currentNodeType = WAM.UI.NodeType.TreatmentProcess;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.MajorComponent:
					currentNodeType = WAM.UI.NodeType.MajorComponent;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Discipline:
					currentNodeType = WAM.UI.NodeType.NoneSelected;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineLand:
					currentNodeType = WAM.UI.NodeType.DisciplineLand;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineMech:
					currentNodeType = WAM.UI.NodeType.DisciplineMech;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineStruct:
					currentNodeType = WAM.UI.NodeType.DisciplineStruct;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineNode:
					currentNodeType = WAM.UI.NodeType.DisciplineNode;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplinePipe:
					currentNodeType = WAM.UI.NodeType.DisciplinePipe;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset:
					currentNodeType = WAM.UI.NodeType.AssetList;
					break;

				//mam 03202012
				case WAM.UI.NodeTypeHandler.NodeTypeReport.ImportFormat:
					currentNodeType = WAM.UI.NodeType.ImportFormat;
					break;
			}
		}

		private void SetCurrentApplyFilterNodeType()
		{
			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxApplyFiltersTo.SelectedItem).Value;
			switch (nodeTypeReport)
			{
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Facility:
					currentApplyFilterNodeType = WAM.UI.NodeType.Facility;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.TreatmentProcess:
					currentApplyFilterNodeType = WAM.UI.NodeType.TreatmentProcess;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.MajorComponent:
					currentApplyFilterNodeType = WAM.UI.NodeType.MajorComponent;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.Discipline:
					currentApplyFilterNodeType = WAM.UI.NodeType.NoneSelected;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineLand:
					currentApplyFilterNodeType = WAM.UI.NodeType.DisciplineLand;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineMech:
					currentApplyFilterNodeType = WAM.UI.NodeType.DisciplineMech;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineStruct:
					currentApplyFilterNodeType = WAM.UI.NodeType.DisciplineStruct;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplineNode:
					currentApplyFilterNodeType = WAM.UI.NodeType.DisciplineNode;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.DisciplinePipe:
					currentApplyFilterNodeType = WAM.UI.NodeType.DisciplinePipe;
					break;
				case WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset:
					currentApplyFilterNodeType = WAM.UI.NodeType.AssetList;
					break;
			}
		}

		private void ReportFilterForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (allowCheckDirty)
			{
				CheckDirty();
			}

			try
			{
				CheckPreviewProperties();
				//MyReportDisplayer.Visible = false;
				MyReportDisplayer.Close();
			}
			catch (SystemException ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
		}

		private void CheckPreviewProperties()
		{
			if (MyReportDisplayer.WindowState == FormWindowState.Minimized 
				|| MyReportDisplayer.Height < 50 
				|| Math.Abs(MyReportDisplayer.Left) > 2000 || Math.Abs(MyReportDisplayer.Top) > 2000)
			{
				MyReportDisplayer.WindowState = FormWindowState.Normal;
				MyReportDisplayer.Size = new Size(this.Width, this.Height);
				MyReportDisplayer.Location = this.Location;
			}
		}

		private void CheckFormProperties()
		{
			if (this.WindowState == FormWindowState.Minimized 
				|| this.Height < 50 
				|| Math.Abs(this.Left) > 2000 || Math.Abs(this.Top) > 2000)
			{
				this.WindowState = FormWindowState.Normal;
				this.Size = this.MinimumSize;
				this.Left = 0;
				this.Top = 0;
			}
		}

		//mam
		private void CountCheckedNodes()
		{
			checkedNodeCount = 0;
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				CountCheckedNodes2(node);
			}
			labelCheckedNodeCount.Text = "Report items selected: " + checkedNodeCount.ToString();
		}
		//</mam>

		//mam
		private void CountCheckedNodes2(TreeNode node)
		{
			if (node.Checked)
				checkedNodeCount++;

			foreach (TreeNode nodeChild in node.Nodes)
			{
				CountCheckedNodes2(nodeChild);
			}
		}
		//</mam>

		//mam
		private void CountReportTypeNodes()
		{
			reportTypeCount = 0;
			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				CountReportTypeNodes2(node);
			}
			UpdateReportTypeLabel();
		}
		//</mam>

		//mam
		private void CountReportTypeNodes2(TreeNode node)
		{
			if (node.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				reportTypeCount++;

			foreach (TreeNode nodeChild in node.Nodes)
			{
				CountReportTypeNodes2(nodeChild);
			}
		}
		//</mam>

		//mam
		private void UpdateReportTypeLabel()
		{
			labelReportTypeCount.Text = "Report items available:  " + reportTypeCount.ToString();
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Click Events *****/

		private void ReportFilterForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			//MessageBox.Show("KeyPress " + e.KeyChar.ToString());
			//if the user has pressed the Esc key, just close the form without saving
			if (e.KeyChar == (char)27)
			{
				allowCheckDirty = false;
				this.Close();
			}
		}

		protected void mnuItemSelectAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(true);
		}

		protected void mnuItemClearAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(false);
		}

		protected void mnuItemExpandAll_OnClick(System.Object sender, System.EventArgs e)
		{
			try
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
				treeViewSpecificUnits.ExpandAll();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemCollapseAll_OnClick(System.Object sender, System.EventArgs e)
		{
			treeViewSpecificUnits.CollapseAll();
		}

		protected void mnuItemSelectUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(true);
		}

		protected void mnuItemClearUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(false);
		}

		protected void mnuItemView_OnClick(System.Object sender, System.EventArgs e)
		{
//			MessageBox.Show("View click");
		}

		protected bool SaveView()
		{
			//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			////return dataAccess.ExecuteCommand("UPDATE ReportTemplate SET UserView = " + (int)GetCurrentView());
			//return(dataAccess.ExecuteCommand(@"UPDATE Preference SET PreferenceValue = " + (int)GetCurrentView() 
			//	+ " WHERE PreferenceType = 'ReportTemplate' AND PreferenceText = 'UserView'"));
			//dataAccess = null;

			try
			{
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "ReportTemplateView", GetCurrentView().ToString());
			}
			catch
			{
				return false;
			}
			return true;
		}

		//private bool SavePreferences(int autoSave)
		private bool SavePreferences()
		{
			//optionAutoSaveFromForm = autoSave;
			//optionAutoSave = autoSave;

			//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			//dataAccess.ExecuteCommand(@"UPDATE Preference SET PreferenceValue = " + optionAutoSaveFromForm 
			//	+ " WHERE PreferenceType = 'ReportTemplate' AND PreferenceText = 'AutomaticSave'");
			//dataAccess = null;

			try
			{
				//Drive.Configuration.AppSettings.Settings.SetSetting(
				//	"Defaults", "ReportTemplateAutoSave", optionAutoSaveFromForm.ToString());
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "ReportTemplateAutoSave", optionAutoSave.ToString());
			}
			catch
			{
				return false;
			}

			//if (optionAutoSaveFromForm.Equals(null))
			//{
			//	optionAutoSave = 1;
			//}
			//else
			//{
			//	optionAutoSave = Convert.ToInt32(optionAutoSaveFromForm);
			//}

			return true;
		}

		protected void mnuItemViewNormal_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
			try
			{
				//if (!mnuItemViewNormal.Checked)
				//{
					if (mnuItemViewNormal.Text == "User selection")
					{
						//begin user selection
						ResetViewItems();
						mnuItemViewNormal.Checked = true;
					}
					else
					{
						//restore most recent user selections (since form was opened)
						ResetViewItems();
						mnuItemViewNormal.Checked = true;
						mnuItemViewNormal.Text = "User selection";
						SaveView();
						nodesExpandedResurrect = nodesExpanded;
						treeViewSpecificUnits.CollapseAll();
						foreach (TreeNode node in treeViewSpecificUnits.Nodes)
						{
							ResurrectExpandedNodes(node);
						}
					}
				//}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewSelected_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewSelected.Checked = true;
				SaveView();
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ConfigureTreeSelectedNodes(node);
				}
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewReport_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				ResetViewItems();
				mnuItemViewReport.Checked = true;
				SaveView();
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				ConfigureTree(nodeTypeReport, false);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewMainTree_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					mnuItemViewNormal.Text = "Restore last user selection";
				}

				//if (!mnuItemViewMainTree.Checked)
				//{
					ResetViewItems();
					mnuItemViewMainTree.Checked = true;
					SaveView();
					nodesExpandedResurrect = nodesExpandedMainForm;
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ResurrectExpandedNodes(node);
					}
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
				//}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		private void buttonSelectAll_Click(object sender, System.EventArgs e)
		{
			mnuItemSelectAll_OnClick(sender, e);
		}

		private void buttonClearAll_Click(object sender, System.EventArgs e)
		{
			mnuItemClearAll_OnClick(sender, e);
		}

		private void C1PrintPreview1_PreviewButtonClick(object sender, C1.Win.C1PrintPreview.PreviewToolBarButtonClickEventArgs e) 
		{
			//Handles C1PrintPreview1.PreviewButtonClick
			if (e.Action == C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileSave)
			{
			// cancel default handling
				e.Handled = true;
				// ... insert your own handling here ...
			}
		}

		#endregion /***** Click Events *****/

		#region /***** Tree Populate *****/

		//mam 03202012 - added isImportFormatReport parameter
		private void		LoadSpecificUnitsTree(bool isImportFormatReport)
		{
			Facility[]		facilities = null;
			Facility		facility = null;

			//mam - comment lines no longer used
			//			if (radioPrintAllFacilities.Checked)
			//			{
			//				// Load a list of all items from all facilities into a tree
			facilities = CacheManager.GetFacilities(InfoSet.CurrentID);
			//			}
			//			else
			//			{
			//				facility = comboBoxFacility.SelectedItem as Facility;
			//				if (facility != null && facility.ID != 0)
			//					facilities = new Facility[1] { facility };
			//				else
			//					facilities = new Facility[0];
			//			}

			TreeNode		node;

			// Walk the facilities array and add the items to the tree
			treeViewSpecificUnits.BeginUpdate();
			treeViewSpecificUnits.Nodes.Clear();
			
			// Populate the facilities
			for (int pos = 0; pos < facilities.Length; pos++)
			{
				facility = facilities[pos];
				node = new TreeNode(facility.Name);
				node.Tag = facility;
				facility.TreeNodeIndex = treeNodeIndex++;

				//mam
				node.ImageIndex = 0;
				node.SelectedImageIndex = 0;
				//</mam>

				treeViewSpecificUnits.Nodes.Add(node);

				//mam 03202012 - added isImportFormatReport argument
				if (facility.HasChildren)
					PopulateTreeProcesses(node, isImportFormatReport);
			}

			treeViewSpecificUnits.EndUpdate();
		}

		//mam 03202012 - added isImportFormatReport parameter
		private void PopulateTreeProcesses(TreeNode facilityNode, bool isImportFormatReport)
		{
			// Get the root nodes (facilities)
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(InfoSet.CurrentID, 
				((Facility)facilityNode.Tag).ID);
			TreatmentProcess process;
			TreeNode		node;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				node = new TreeNode(process.Name);
				node.Tag = process;
				process.TreeNodeIndex = treeNodeIndex++;

				//mam
				node.ImageIndex = 3;
				node.SelectedImageIndex = 3;
				//</mam>

				facilityNode.Nodes.Add(node);

				//mam 03202012 - added isImportFormatReport argument
				if (process.HasChildren)
					PopulateTreeComponents(node, isImportFormatReport);
			}
		}

		//mam 03202012 - added isImportFormatReport parameter
		private void		PopulateTreeComponents(TreeNode processNode, bool isImportFormatReport)
		{
			// Get the root nodes (facilities)
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, 
				((TreatmentProcess)processNode.Tag).ID);
			MajorComponent	component;
			TreeNode		node;

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				node = new TreeNode(component.Name);
				node.Tag = component;
				component.TreeNodeIndex = treeNodeIndex++;
				
				//mam
				node.ImageIndex = 5;
				node.SelectedImageIndex = 5;
				//</mam>
				
				processNode.Nodes.Add(node);

				//mam 03202012 - added isImportFormatReport argument
				// Add disciplines
				PopulateTreeDisciplines(node, isImportFormatReport);
			}
		}

		//mam 03202012 - added isImportFormatReport parameter
		private void		PopulateTreeDisciplines(TreeNode componentNode, bool isImportFormatReport)
		{
			// Get the root nodes (facilities)
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, 
				((MajorComponent)componentNode.Tag).ID);
			Discipline		discipline;
			TreeNode		node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				//mam 03202012 - added isImportFormatReport
				//	include all disciplines regardless of their condition if report type is ImportFormat
				//	what if there is not a matching record in one of the discipline database tables???
				//	if ImportFormat, put discipline in the tree only if the discipline has a non-zero Id
				//	don't put it in tree if cond = n/a and report is not ImportFormat
				bool includeImportFormatDiscipline = isImportFormatReport && discipline.ID != 0;
				//if (discipline.ConditionRanking == CondRank.No)
				if (discipline.ConditionRanking == CondRank.No && !includeImportFormatDiscipline)
					continue;

				node = new TreeNode(discipline.Name);
				node.Tag = discipline;
				discipline.TreeNodeIndex = treeNodeIndex++;

				//mam
				node.ImageIndex = 7;
				node.SelectedImageIndex = 7;
				//</mam>

				componentNode.Nodes.Add(node);

				//mam
				//may not do this:
//				//since we're showing all disciplines, color code them to match the data tree so the user will know
//				//	which ones have condition values
//				if (discipline.ConditionRanking == CondRank.No)
//					node.ForeColor = Color.FromArgb(255, 0, 0);
//				else
//					node.ForeColor = Color.FromArgb(0, 0, 0);
//				//</mam>

				if (discipline.Type == DisciplineType.Mechanical)
				{
					// Check to see if there are any assets for this item, and if
					// so, add an "asset list" node
					ComponentAsset[] assets = 
						CacheManager.GetAssets(InfoSet.CurrentID, discipline.ComponentID);

					if (assets.Length > 0)
					{
						TreeNode assetNode;

						assetNode = new TreeNode("Asset List");
						assetNode.Tag = assets[0];

						//mam
						node.ImageIndex = 7;
						node.SelectedImageIndex = 7;
						//</mam>

						node.Nodes.Add(assetNode);
					}
				}
			}
		}

		#endregion /***** Tree Populate *****/

		#region /***** Tree Handling Code *****/

		private void ResurrectExpandedNodes(TreeNode node)
		{
//			if (nodesExpanded.Contains(node.Tag))
//				node.Expand();
//
//			foreach (TreeNode nodeChild in node.Nodes)
//				ResurrectExpandedNodes(nodeChild);

			if (nodesExpandedResurrect.Contains(node.Tag))
				node.Expand();

			foreach (TreeNode nodeChild in node.Nodes)
				ResurrectExpandedNodes(nodeChild);
		}

		private void ResurrectSelectedNodes(TreeNode node)
		{
			//System.Diagnostics.Debug.WriteLine("Now start = " + DateTime.Now.Second);

			switch (currentNodeType)
			{
				//mam 03202012
				case WAM.UI.NodeType.ImportFormat:
					ResurrectSelectedNodesImportFormat(node);
					break;

				case WAM.UI.NodeType.Facility:
					if (SelectedFac.Contains(node.Tag))
						node.Checked = true;
					break;

				case WAM.UI.NodeType.TreatmentProcess:
					if (SelectedProc.Contains(node.Tag))
					{
						node.Checked = true;
					}
					if (node.Tag is TreatmentProcess)
					{
						//if (node.NextNode != null)
						//	ResurrectSelectedNodes(node.NextNode);
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.MajorComponent:
					if (node.Tag is MajorComponent)
					{
						if (SelectedComp.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineMech:
					if (node.Tag is DisciplineMech)
					{
						if (SelectedDiscMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineLand:
					if (node.Tag is DisciplineLand)
					{
						if (SelectedDiscLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineStruct:
					if (node.Tag is DisciplineStruct)
					{
						if (SelectedDiscStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplinePipe:
					if (node.Tag is DisciplinePipe)
					{
						if (SelectedDiscPipe.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineNode:
					if (node.Tag is DisciplineNode)
					{
						if (SelectedDiscNode.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.NoneSelected:
//					// this is for the DiscAll nodes
//					if (node.Tag is DisciplineMech || node.Tag is DisciplineLand 
//						|| node.Tag is DisciplineStruct || node.Tag is DisciplinePipe 
//						|| node.Tag is DisciplineNode)
//					{
//						if (SelectedDiscAll.Contains(node.Tag))
//						{
//							node.Checked = true;
//						}
//					}
//					else
//					{
//						foreach (TreeNode nodeChild in node.Nodes)
//							ResurrectSelectedNodes(nodeChild);
//					}
//					break;

					if (node.Tag is DisciplineLand)
					{
						if (SelectedDiscAllLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplineMech)
					{
						if (SelectedDiscAllMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplineStruct)
					{
						if (SelectedDiscAllStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplineNode)
					{
						if (SelectedDiscAllNode.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is DisciplinePipe)
					{
						if (SelectedDiscAllPipe.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.AssetList:
					if (node.Tag is ComponentAsset)
					{
						if (SelectedAsset.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;
			}

//			// if the user is viewing only the selected items, 
//			//	configure the tree to show only those items
//			if (mnuItemViewSelected.Checked)
//			{
//				treeViewSpecificUnits.CollapseAll();
//				foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
//				{
//					ConfigureTreeSelectedNodes(treeNode);
//				}
//				if (treeViewSpecificUnits.Nodes.Count > 0)
//					treeViewSpecificUnits.Nodes[0].EnsureVisible();
//			}

//			if (currentNodeType == (NodeType)node.Tag)
//			//if (currentNodeType.Equals(node))
//			{
//				if (SelectedFac.Contains(node.Tag))
//					node.Checked = true;
//
//				foreach (TreeNode nodeChild in node.Nodes)
//					ResurrectSelectedNodes(nodeChild);
//			}
			//System.Diagnostics.Debug.WriteLine("Now stop = " + DateTime.Now.Second);
		}

		private void ResurrectSelectedNodesImportFormat(TreeNode node)
		{
			//if (node.Tag.ToString() == "WAM.Data.MajorComponent")
			if (node.Tag is Facility)
			{
				if (SelectedFacImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is TreatmentProcess)
			{
				if (SelectedProcImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is MajorComponent)
			{
				if (SelectedCompImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is DisciplineMech)
			{
				if (SelectedDiscMechImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is DisciplineLand)
			{
				if (SelectedDiscLandImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is DisciplineStruct)
			{
				if (SelectedDiscStructImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is DisciplinePipe)
			{
				if (SelectedDiscPipeImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is DisciplineNode)
			{
				if (SelectedDiscNodeImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}
			else if (node.Tag is ComponentAsset)
			{
				if (SelectedAssetImport.Contains(node.Tag))
				{
					node.Checked = true;
				}
			}

			foreach (TreeNode nodeChild in node.Nodes)
			ResurrectSelectedNodesImportFormat(nodeChild);
		}

		private void CheckNodes(TreeNode nodeStart, NodeTypeHandler.NodeTypeReport nodeReportType, bool checkNode, bool checkNodeStart)
		{
			//check all nodes of a certain node type under nodeStart
			if (checkNodeStart)
			{
				if (nodeStart.Tag.ToString() == "WAM.Data." + nodeReportType.ToString())
				{
					nodeStart.Checked = checkNode;
				}
			}

			foreach(TreeNode nodeChild in nodeStart.Nodes)
			{
				if (nodeReportType == NodeTypeHandler.NodeTypeReport.Discipline
					&& nodeChild.Parent.Tag.ToString() == "WAM.Data.MajorComponent")
				{
					nodeChild.Checked = checkNode;
				}
				else if (nodeChild.Tag.ToString() == "WAM.Data." + nodeReportType.ToString())
				{
					nodeChild.Checked = checkNode;
				}
				if (nodeChild.Nodes.Count > 0)
					CheckNodes(nodeChild, nodeReportType, checkNode, checkNodeStart);
			}
		}
		//</mam>

		private void CheckNodesAll(bool checkNode)
		{
			autoChecking = true;
			ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				//mam 03202012 - if report is ImportFormat, check all nodes regardless of node type
				//if (checkNode)
				if (checkNode && (NodeTypeHandler.NodeTypeReport)reportType.Value != NodeTypeHandler.NodeTypeReport.ImportFormat)
					CheckNodes(node, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, true);
				else
					CheckNodesAll2(node, checkNode);
			}
			autoChecking = false;
			CountCheckedNodes();
		}

		private void CheckNodesAll2(TreeNode node, bool checkNode)
		{
			node.Checked = checkNode;
			if (node.Nodes.Count > 0)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					CheckNodesAll2(nodeChild, checkNode);
				}
			}
		}

		//mam 03202012
		private void CheckNodesAllUnder(TreeNode node, bool checkNode)
		{
			if (node.Nodes.Count > 0)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					CheckNodesAll2(nodeChild, checkNode);
				}
			}
		}

		//mam
		private void SelectUnder(bool checkNode)
		{
			autoChecking = true;
			ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			//if the hit test is node with blue text, then that node is selectable, which means the report is of that node type
			//select all nodes at the level for the parent of the hit test node by going to the hit test node's parent node and 
			//	selecting all nodes under it

			//if the hit test is a node with grey text, then that node is not selectable, and the report is not that of the node type
			//select all nodes under the hit test node

			//if the report is ImportFormat, all nodes are selectable, so select all nodes under the hit test node

			//mam 03202012
			if ((NodeTypeHandler.NodeTypeReport)reportType.Value == NodeTypeHandler.NodeTypeReport.ImportFormat)
			{
				//CheckNodesAll2(nodeHitTest, checkNode);
				CheckNodesAllUnder(nodeHitTest, checkNode);
			}

			//may not do this:
			//check for red or black ForeColor because we're color-coding them red or black
			//	to match the main data tree
			//mam 03202012 - added else
			else if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
			//if (nodeHitTest.ForeColor == Color.FromArgb(255, 0, 0) || nodeHitTest.ForeColor == Color.FromArgb(0, 0, 0))
			{
				if (nodeHitTest.Parent != null)
				{
					CheckNodes(nodeHitTest.Parent, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
				}
			}
			else
			{
				CheckNodes(nodeHitTest, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
			}

			autoChecking = false;
			CountCheckedNodes();
		}
		//</mam>

		//mam - moved this code from above and made changes
		private void GetSelectedTreeNodes()
		{
			printItems.Clear();

			// Print the specific selected units
			foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
			{
				if (treeNode.Checked)
				{
					//MessageBox.Show(treeNode.FullPath.ToString());
					printItems.Add(treeNode.Tag);
				}
				if (treeNode.Nodes.Count > 0)
				{
					//GetCheckedNodes(treeNode, printItems);
					GetCheckedNodes(treeNode);
				}
			}

			RecordSelectedNodes();
		}
		//</mam>

		//private void		GetCheckedNodes(TreeNode parent, ArrayList checkedNodes)
		private void		GetCheckedNodes(TreeNode parent)
		{
			TreeNode		node;

			for (int pos = 0; pos < parent.Nodes.Count; pos++)
			{
				node = parent.Nodes[pos];

				if (node.Checked)
				{
					//MessageBox.Show(node.FullPath.ToString());
					printItems.Add(node.Tag);
				}

				if (node.Nodes.Count > 0)
				{
					GetCheckedNodes(node);
				}
			}
		}

		//mam
		private void ConfigureTree(NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				treeViewSpecificUnits.CollapseAll();
			}

			NodeTypeHandler.NodeTypeReport[] sources = 
				(NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));

			reportTypeCount = 0;

			for (int i = 0; i < sources.Length; i++)
			{
				if (nodeTypeReport == sources[i])
				{
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						if (uncheckNodes == true)
						{
							node.Checked = false;
						}
//						if (nodeTypeReport.ToString() == "Facility")
//						{
//							MessageBox.Show(node.Tag.ToString());
//						}
						
						//mam 11142011
						//if (node.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString())
						if (node.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString() 
							//mam 03202012
							|| nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat)
						{
							//may not do this:
							//don't make the discipline nodes blue, because we're color-coding them red or black
							//	to match the main data tree
							node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
//							//**************************
//							switch (nodeTypeReport.ToString())
//							{
//								case "Facility":
//								case "TreatmentProcess":
//								case "MajorComponent":
//								case "Asset":
//									node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
//									break;
//								//case "Discipline":
//								//case "DisciplineMech":
//								//case "DisciplineStruct":
//								//case "DisciplineLand":
//								//case "DisciplinePipe":
//								//case "DisciplineNode":
//								default:
//									if (((Discipline)node.Tag).ConditionRanking == CondRank.No)
//										node.ForeColor = Color.FromArgb(255, 0, 0);
//									else
//										node.ForeColor = Color.FromArgb(0, 0, 0);
//									break;
//							}
//							//**************************
							node.ImageIndex = 0;
							node.SelectedImageIndex = 0;
							reportTypeCount += 1;
						}
						else
						{
							//disabled node
							node.ForeColor = System.Drawing.SystemColors.GrayText;
							node.ImageIndex = 1;
							node.SelectedImageIndex = 1;
						}

						ConfigureChildren(node, nodeTypeReport, uncheckNodes);
					}
				}
			}
			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}

			//labelReportTypeCount.Text = reportTypeCount.ToString() + " report items available";
			labelReportTypeCount.Text = "Report items available:  " + reportTypeCount.ToString();

			//cancelCheck = false;
		}
		//</mam>

		//mam
		private void ConfigureChildren(TreeNode node, NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			TreeNode nodeParent;
			int useImageIndex = 0;
			if (uncheckNodes == true)
			{
				node.Checked = false;
			}

			foreach(TreeNode nodeChild in node.Nodes)
			{
				if (uncheckNodes == true)
				{
					nodeChild.Checked = false;
				}
				if (nodeChild.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString()
					|| nodeChild.Tag.ToString().Substring(9).StartsWith(nodeTypeReport.ToString())
					//mam 03202012
					|| nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat)
				{
					//may not do this:
					//don't make the discipline nodes blue, because we're color-coding them red or black
					//	to match the main data tree
					nodeChild.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
					//</mam>

					reportTypeCount += 1;

					switch (nodeTypeReport.ToString())
					{
						case "TreatmentProcess":
						{
							useImageIndex = 3;
							break;
						}
						case "MajorComponent":
						{
							useImageIndex = 5;
							break;
						}
						case "Discipline":
						case "DisciplineMech":
						case "DisciplineStruct":
						case "DisciplineLand":
						case "DisciplinePipe":
						case "DisciplineNode":
						{
							//may not do this:
//							//don't make the discipline nodes blue, because we're color-coding them red or black
//							//	to match the main data tree
//							if (((Discipline)nodeChild.Tag).ConditionRanking == CondRank.No)
//							{
//								nodeChild.ForeColor = Color.FromArgb(255, 0, 0);
//							}
//							else
//							{
//								//MessageBox.Show(((Discipline)nodeChild.Tag).ConditionRanking.ToString());
//								nodeChild.ForeColor = Color.FromArgb(0, 0, 0);
//							}

							useImageIndex = 7;
							break;
						}
						case "ComponentAsset":
						{
							useImageIndex = 9;
							break;
						}

						//mam 03202012
						case "ImportFormat":
						{
							//mam 03202012 - if report is ImportFormat, configure the discipline nodes
							//if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat &&
							if (nodeChild.Tag.ToString() == "WAM.Data." + WAM.Data.Facility.GetTypeString())
							{
								//this won't happen because facility isn't ever a child node
								useImageIndex = 0;
							}
							if (nodeChild.Tag.ToString() == "WAM.Data." + WAM.Data.TreatmentProcess.GetTypeString())
							{
								useImageIndex = 3;
							}
							else if (nodeChild.Tag.ToString() == "WAM.Data." + WAM.Data.MajorComponent.GetTypeString())
							{
								useImageIndex = 5;
							}
							else if (nodeChild.Tag.ToString() == "WAM.Data.ComponentAsset")
							{
								useImageIndex = 9;
							}
							else
							{
								//discipline
								useImageIndex = 7;
								if (((Discipline)nodeChild.Tag).ConditionRanking == CondRank.No)
								{
									nodeChild.ForeColor = Color.FromArgb(255, 0, 0);
								}
							}
							break;
						}
					}

					//nodeChild.ImageIndex = 0;
					//nodeChild.SelectedImageIndex = 0;
					nodeChild.ImageIndex = useImageIndex;
					nodeChild.SelectedImageIndex = useImageIndex;

					if (mnuItemViewReport.Checked)
					{
						//expand all parents of nodeChild so that nodeChild is visible
						nodeParent = nodeChild.Parent;
						nodeParent.Expand();
						while (nodeParent.Parent != null)
						{
							nodeParent.Parent.Expand();
							nodeParent = nodeParent.Parent;
						}
					}
				}
				else
				{
					//disabled node
					nodeChild.ForeColor = System.Drawing.SystemColors.GrayText;
					nodeChild.ImageIndex = 1;
					nodeChild.SelectedImageIndex = 1;
				}

				//				//MessageBox.Show(nodeChild.Text);
				//				if (nodeChild.Text == "Asset List")
				//				{
				//					System.Diagnostics.Debug.WriteLine("Test");
				//					MessageBox.Show("tag = " + nodeChild.Tag.ToString());
				//					MessageBox.Show("nodeTypeReport.ToString() = " + nodeTypeReport.ToString());
				//				}
					

				ConfigureChildren(nodeChild, nodeTypeReport, uncheckNodes);
			}
		}
		//</mam>

		//mam
		private void ConfigureTreeSelectedNodes(TreeNode node)
		{
			TreeNode nodeExpand = node;
			if (node.Checked == true)
				while (nodeExpand.Parent != null && nodeExpand.Parent.IsExpanded == false)
				{
					nodeExpand.Parent.Expand();
					nodeExpand = nodeExpand.Parent;
				}

			foreach (TreeNode nodeChild in node.Nodes)
			{
				ConfigureTreeSelectedNodes(nodeChild);
			}

			//cancelCheck = false;
		}
		//</mam>

		private void treeViewSpecificUnits_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
				
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
			else
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor == System.Drawing.SystemColors.GrayText)
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				else
				{
					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
			}
		}

		private void treeViewSpecificUnits_Click(object sender, System.EventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null && nodeSelected != null && nodeHitTest == nodeSelected)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
			}
		}

		private void treeViewSpecificUnits_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
			if (treeViewSpecificUnits.SelectedNode == null)
			{
				treeViewSpecificUnits.SelectedNode = treeViewSpecificUnits.Nodes[0];
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
		}

		private void treeViewSpecificUnits_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			nodeHitTest = treeViewSpecificUnits.GetNodeAt(e.X, e.Y);
		}

		private void treeViewSpecificUnits_AfterCollapse(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeCollapse(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
		}

		private void treeViewSpecificUnits_BeforeCheck(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (nodeHitTest == null || autoChecking == true)
				return;

			//if (cancelCheck)
			//	return;

			//MessageBox.Show(nodeHitTest.Text + " = " + nodeHitTest.ForeColor.ToString());
			if (nodeHitTest.ForeColor == System.Drawing.SystemColors.GrayText)
				e.Cancel = true;
		}

//		private void RecordTreeExpandedState(TreeNode node)
//		{
//			if (node.IsExpanded)
//			{
//				nodesExpanded.Add(node.Tag);
//			}
//			foreach (TreeNode childNode in node.Nodes)
//			{
//				RecordTreeExpandedState(childNode);
//			}
//		}

		private void RecordTreeExpandedState()
		{
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();

			nodesExpanded.Clear();
			//return commonTasks.RecordTreeExpandedState(treeViewFacility);
			nodesExpanded = commonTasks.RecordTreeExpandedState(treeViewSpecificUnits);
			//MessageBox.Show("nodesExpanded.Count = " + nodesExpanded.Count.ToString());

			commonTasks = null;
		}

		//mam 03202012
		private void RecordSelectedNodesImportFormat()
		{
			//if report type is ImportFormat, nodes of all types may be selected

			SelectedFacImport.Clear();
			SelectedProcImport.Clear();
			SelectedCompImport.Clear();
			SelectedDiscMechImport.Clear();
			SelectedDiscStructImport.Clear();
			SelectedDiscLandImport.Clear();
			SelectedDiscPipeImport.Clear();
			SelectedDiscNodeImport.Clear();
			SelectedAssetImport.Clear();

			for (int i = 0; i < printItems.Count; i++)
			{
				if (printItems[i].ToString() == "WAM.Data.Facility")
				{
					SelectedFacImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.TreatmentProcess")
				{
					SelectedProcImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.MajorComponent")
				{
					SelectedCompImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.DisciplineMech")
				{
					SelectedDiscMechImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.DisciplineStruct")
				{
					SelectedDiscStructImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.DisciplineLand")
				{
					SelectedDiscLandImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.DisciplinePipe")
				{
					SelectedDiscPipeImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.DisciplineNode")
				{
					SelectedDiscNodeImport.Add(printItems[i]);
				}
				else if (printItems[i].ToString() == "WAM.Data.ComponentAsset")
				{
					//when the node type is Asset List, the report type is Component Asset
					//nodeType = WAM.UI.NodeType.AssetList
					//report type = WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset

					SelectedAssetImport.Add(printItems[i]);
				}
			}
		}

		private void RecordSelectedNodes()
		{
			//if ((NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value == NodeTypeHandler.NodeTypeReport.ImportFormat)
			if (currentNodeType == NodeType.ImportFormat)
			{
				RecordSelectedNodesImportFormat();
				return;
			}

			// Add the nodes in printItems[] to the various array lists

			//NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			switch (currentNodeType)
			{
					//case NodeTypeHandler.NodeTypeReport.Facility:
				case NodeType.Facility:
				{
					SelectedFac.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						SelectedFac.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.TreatmentProcess:
				case NodeType.TreatmentProcess:
				{
					SelectedProc.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedProc.Add(((TreatmentProcess)printItems[i]).ID);
						SelectedProc.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.MajorComponent:
				case NodeType.MajorComponent:
				{
					SelectedComp.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedComp.Add(((MajorComponent)printItems[i]).ID);
						SelectedComp.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineMech:
				case NodeType.DisciplineMech:
				{
					SelectedDiscMech.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscMech.Add(((DisciplineMech)printItems[i]).ID);
						SelectedDiscMech.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineLand:
				case NodeType.DisciplineLand:
				{
					SelectedDiscLand.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscLand.Add(((DisciplineLand)printItems[i]).ID);
						SelectedDiscLand.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineStruct:
				case NodeType.DisciplineStruct:
				{
					SelectedDiscStruct.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscStruct.Add(((DisciplineStruct)printItems[i]).ID);
						SelectedDiscStruct.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplinePipe:
				case NodeType.DisciplinePipe:
				{
					SelectedDiscPipe.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscPipe.Add(((DisciplinePipe)printItems[i]).ID);
						SelectedDiscPipe.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineNode:
				case NodeType.DisciplineNode:
				{
					SelectedDiscNode.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscNode.Add(((DisciplineNode)printItems[i]).ID);
						SelectedDiscNode.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.Discipline:
				case NodeType.NoneSelected:
				{
					SelectedDiscAllLand.Clear();
					SelectedDiscAllMech.Clear();
					SelectedDiscAllStruct.Clear();
					SelectedDiscAllNode.Clear();
					SelectedDiscAllPipe.Clear();

					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscAll.Add(printItems[i]);
						if (printItems[i] is DisciplineLand)
							SelectedDiscAllLand.Add(printItems[i]);
						else if (printItems[i] is DisciplineMech)
							SelectedDiscAllMech.Add(printItems[i]);
						else if (printItems[i] is DisciplineStruct)
							SelectedDiscAllStruct.Add(printItems[i]);
						else if (printItems[i] is DisciplineNode)
							SelectedDiscAllNode.Add(printItems[i]);
						else if (printItems[i] is DisciplinePipe)
							SelectedDiscAllPipe.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.ComponentAsset:
				case NodeType.AssetList:
				{
					SelectedAsset.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedAsset.Add(((ComponentAsset)printItems[i]).ID);
						SelectedAsset.Add(printItems[i]);
					}
					break;
				}
			}
		}

		private void treeViewCriteria_DoubleClick(object sender, System.EventArgs e)
		{
			listBoxCriteria.SelectedIndex = treeViewCriteria.SelectedNode.Index;
			//listBoxCriteria.SelectedItem
			listBoxCriteria_DoubleClick(sender, e);
		}

		private void treeViewCriteria_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			try
			{
				listBoxCriteria.SelectedIndex = treeViewCriteria.SelectedNode.Index;
			}
			catch
			{
			}
		}

		#endregion /***** Tree Handling Code *****/

		#region /***** Filter *****/

		private void AddFilter()
		{
			//FilterBuilderForm2 filterBuilderForm2 = new FilterBuilderForm2();
			UnitFilter		unitFilter = new UnitFilter();

			ListItem		sourceItem = filterBuilderForm21.comboBoxSource.SelectedItem as ListItem;
			ListItem		opItem = filterBuilderForm21.comboBoxOperator.SelectedItem as ListItem;
			ListItem		compItem = filterBuilderForm21.comboBoxFilterCompareTo.SelectedItem as ListItem;

			int selectedIndex = 0;

			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.Undefined)
			{
				//				MessageBox.Show(this, "Please select a field to filter by.", "Select Filter Field");
				return;
			}

			if (listBoxCriteria.Items.Count == 1 &&
				listBoxCriteria.Items[0] is string)
			{
				listBoxCriteria.Items.RemoveAt(0);
				treeViewCriteria.Nodes.RemoveAt(0);
			}

			unitFilter.Source = (UnitFilter.FilterSource)sourceItem.Value;
			unitFilter.Operator = (UnitFilter.FilterOperator)opItem.Value;
			unitFilter.Compare = (UnitFilter.FilterCompareTo)compItem.Value;

			//mam 07072011 - allow user to filter by Asset Class and Planning, both of which are strings (every other filter is numeric)
			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.AssetClass
				|| (UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.CipMode)
			{
				unitFilter.CompareVal1String = filterBuilderForm21.textBoxFilterVal1.Text;
				unitFilter.CompareVal2String = filterBuilderForm21.textBoxFilterVal2.Text;
			}
			else
			{
				unitFilter.CompareVal1 = Drive.Convert.StringToDecimal(filterBuilderForm21.textBoxFilterVal1.Text);
				unitFilter.CompareVal2 = Drive.Convert.StringToDecimal(filterBuilderForm21.textBoxFilterVal2.Text);
			}

			if (editingFilter)
			{
				editingFilter = false;
				selectedIndex = listBoxCriteria.SelectedIndex;

				listBoxCriteria.Items.RemoveAt(listBoxCriteria.SelectedIndex);
				treeViewCriteria.Nodes.RemoveAt(selectedIndex);

				listBoxCriteria.Items.Insert(selectedIndex, unitFilter);
				
				TreeNode node = new TreeNode();
				node.Text = unitFilter.Description.ToString();
				node.Tag = "ENABLED";
				node.ForeColor = Color.Black;
				node.ImageIndex = 6;
				node.SelectedImageIndex = 6;
				treeViewCriteria.Nodes.Insert(selectedIndex, node);

				listBoxCriteria.SelectedIndex = selectedIndex;
				treeViewCriteria.SelectedNode = node;
			}
			else
			{
				listBoxCriteria.Items.Add(unitFilter);
				TreeNode node = new TreeNode();
				node.Text = unitFilter.Description.ToString();
				node.Tag = "ENABLED";
				node.ForeColor = Color.Black;
				node.ImageIndex = 6;
				node.SelectedImageIndex = 6;
				treeViewCriteria.Nodes.Add(node);
			}

			//MessageBox.Show(unitFilter.Description.ToString());

			ResetFilters();

			SetDirtyFilter(null, null);
		}

		private void buttonEditCriteria_Click(object sender, System.EventArgs e)
		{
			//ListItem		listItem = filterBuilderForm21.comboBoxSource.SelectedItem as ListItem;
			UnitFilter		unitFilter = listBoxCriteria.SelectedItem as UnitFilter;
			//MessageBox.Show(unitFilter.Source.ToString());

			if (unitFilter == null)
			{
				//if the user has not yet added any filters
				if (listBoxCriteria.Items.Count == 1 &&
					listBoxCriteria.Items[0] is string)
				{
					MessageBox.Show("There are no filters to edit.  Press the Add button to add a filter.", "Edit Filter", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				//filters exist, but none is selected
				else
				{
					MessageBox.Show("Please click on a filter in the Filters box, and then press the Edit button to edit it.", "Edit Filter", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}

				return;
			}

			//filterBuilderForm21.GetSelectedComboBoxItem(unitFilter);
			filterBuilderForm21.GetSelectedComboBoxItemSource(unitFilter);
			filterBuilderForm21.GetSelectedComboBoxItemOperator(unitFilter);
			filterBuilderForm21.GetSelectedComboBoxItemCompare(unitFilter);
			filterBuilderForm21.GetSelectedTextBoxItems(unitFilter);

			ResetEditing(true);
			//editingFilter = true;
			//filterBuilderForm21.buttonCancelEdit.Visible = true;
			//filterBuilderForm21.buttonAddCriteria.Text = "Save Changes";

			filterBuilderForm21.comboBoxSource.Focus();

			//listBoxCriteria.Items.RemoveAt(listBoxCriteria.SelectedIndex);
			//listBoxCriteria.SelectedIndex = listBoxCriteria.Items.Add(unitFilter);

		}

		private void buttonRemoveCriteria_Click(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			UnitFilter		unitFilter = listBoxCriteria.SelectedItem as UnitFilter;
			int				index = listBoxCriteria.SelectedIndex;

			//mam
			if (unitFilter == null)
			{
				//if the user has not yet added any filters
				if (listBoxCriteria.Items.Count == 1 &&
					listBoxCriteria.Items[0] is string)
				{
					MessageBox.Show("There are no filters to delete.", "Delete Filter", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
				//filters exist, but none is selected
				else
				{
					//if there is only one filter, go ahead and delete it; otherwise, user must select one
					if (listBoxCriteria.Items.Count > 1)
					{
						MessageBox.Show("Please click on a filter in the Filters box, and then press the Delete button to delete it.", "Delete Filter", 
							MessageBoxButtons.OK, MessageBoxIcon.Information);
						return;
					}
				}
			}
			//</mam>

			//if there is only one filter and it is not highlighted, go ahead and select it
			if (listBoxCriteria.SelectedIndex == -1 && listBoxCriteria.Items.Count == 1)
			{
				listBoxCriteria.SelectedIndex = 0;
				index = 0;
			}

			listBoxCriteria.Items.RemoveAt(index);
			treeViewCriteria.Nodes.RemoveAt(index);
			//MessageBox.Show("after remove index = " + index);

			//mam - replaced the following two lines with the code below
			//if (index > 0)
			//	listBoxCriteria.SelectedIndex = (index - 1);
			if (listBoxCriteria.Items.Count == 0)
			{
			}
			else if (index > -1 && index <= listBoxCriteria.Items.Count - 1)
			{
				listBoxCriteria.SelectedIndex = index;
			}
			else if (index > -1 && index > listBoxCriteria.Items.Count -1)
			{
				listBoxCriteria.SelectedIndex = (index - 1);
			}
			//</mam>

			//mam
			ResetEditing(false);
			SetDefaultValue("Criteria");
			ResetFilters();
			treeViewCriteria.Focus();
			//</mam>
		}

		private void buttonClearCriteria_Click(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			//mam
			//if the user has not yet added any filters
			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string
				|| listBoxCriteria.Items.Count == 0)
			{
				MessageBox.Show("There are no filters to delete.", "Delete Filter", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			//</mam>

			listBoxCriteria.Items.Clear();
			treeViewCriteria.Nodes.Clear();
		
			//mam
			SetDefaultValue("Criteria");
			ResetFilters();
			//</mam>
		}

		//mam
		private void SetDefaultValue(string controlType)
		{
			switch (controlType)
			{
				case "Criteria":
					if (listBoxCriteria.Items.Count == 0)
					{
						listBoxCriteria.Items.Add(emptyListBoxValue);
						treeViewCriteria.Nodes.Add(emptyListBoxValue);
					}
					return;
			}
		}
		//</mam>

		//mam
		private void buttonCancel_Click2(object sender, System.EventArgs e)
		{
			//editingFilter = false;
			ResetEditing(false);
		}
		//</mam>

		//mam
		private void buttonAddCriteria_Click2(object sender, System.EventArgs e)
		{
			AddFilter();
		}
		//</mam>

		#endregion /***** Filter *****/

		#region /***** Create Reports *****/

		private void timer_Tick(object sender, System.EventArgs e)
		{
			if (newTemplateNameFromForm.Length != 0)
			{
				newTemplateNameFromForm = "";
				timer.Enabled = false;
				CreateReports(true, false);

				try
				{
					reportPrintStatusForm.Close();
				}
				catch
				{
					System.Diagnostics.Debug.WriteLine("PrintStatusReport form did not close in timer_Tick");
				}
			}
		}

		//mam 07072011 - added bool isExport
		private void CreateReports(bool printOnly, bool isExport)
		{
			try
			{
				//mam
				//Cursor = Cursors.WaitCursor;
				reportAllPages.Clear();
				//</mam>

				//mam 050806
				treeNodeIndex = 0;

				//mam 07072011
				if (isExport)
				{
				}
					//mam - create the previewer
				else if (printOnly)
				{
					//rather than printing from the pages in the report, which doesn't seem to work,
					//	let's print from an invisible instance of the PrintPreview
					try
					{
						//this should not be necessary now because the displayer is to be recreated
						CheckPreviewProperties();
						MyReportDisplayer.Close();
					}
					catch (Exception ex)
					{
						System.Diagnostics.Trace.WriteLine(
							String.Format("ReportFilterForm.CreateReports Error (attempting to close MyReportDisplayer): {0}\n", ex.Message));
					}

					MyReportDisplayer = new Reports.UI.C1ReportDisplayerForm(MainForm.AppForm);
				}
				else
				{
					try
					{
						//this should not be necessary now because the displayer is to be recreated
						CheckPreviewProperties();
						MyReportDisplayer.Close();
					}
					catch (Exception ex)
					{
						System.Diagnostics.Trace.WriteLine(
							String.Format("ReportFilterForm.CreateReports Error (attempting to close MyReportDisplayer): {0}\n", ex.Message));
					}

					MyReportDisplayer = new Reports.UI.C1ReportDisplayerForm(MainForm.AppForm);

					if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						MyReportDisplayer.CurrentReportFormat = ReportFormat.Matrix;
					else
						MyReportDisplayer.CurrentReportFormat = ReportFormat.Standard;
				}
				//</mam>

				//mam - find the report type and the "filters apply to" type
				ListItem reportType = comboBoxReportType.SelectedItem as ListItem;
				ListItem filterApplyType = comboBoxApplyFiltersTo.SelectedItem as ListItem;
			
				NodeTypeHandler.NodeTypeReport[] sources = (NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			
				NodeTypeHandler.NodeTypeReport nodeReportType = new WAM.UI.NodeTypeHandler.NodeTypeReport();
				NodeTypeHandler.NodeTypeReport nodeFilterApplyType = new WAM.UI.NodeTypeHandler.NodeTypeReport();

				for (int i = 0; i < sources.Length; i++)
				{
					if (sources[i] == (NodeTypeHandler.NodeTypeReport)reportType.Value)
					{
						nodeReportType = (NodeTypeHandler.NodeTypeReport)reportType.Value;
						break;
					}
				}
				for (int i = 0; i < sources.Length; i++)
				{
					if (sources[i] == (NodeTypeHandler.NodeTypeReport)filterApplyType.Value)
					{
						nodeFilterApplyType = (NodeTypeHandler.NodeTypeReport)filterApplyType.Value;
						break;
					}
				}

				filteredItems.Clear();

				for (int pos = 0; pos < printItems.Count; pos++)
				{
					if (radioFilterNo.Checked == true)
					{
						filteredItems.Add(printItems[pos]);
					}
					else
					{
						currentReport.Clear();
						currentReport.Add(printItems[pos]);

						//pass to the proper method based on report type
						if (nodeReportType == NodeTypeHandler.NodeTypeReport.Facility)
							AddFilteredFacilities(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.TreatmentProcess)
							AddFilteredProcesses(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.MajorComponent)
							AddFilteredComponents(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.Discipline)
							AddFilteredDisciplines(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.DisciplineLand
							|| nodeReportType == NodeTypeHandler.NodeTypeReport.DisciplineMech
							|| nodeReportType == NodeTypeHandler.NodeTypeReport.DisciplineStruct)
							AddFilteredDisciplines(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.DisciplineNode
							|| nodeReportType == NodeTypeHandler.NodeTypeReport.DisciplinePipe)
							AddFilteredDisciplines(nodeFilterApplyType);
						else if (nodeReportType == NodeTypeHandler.NodeTypeReport.ComponentAsset)
							AddFilteredAssets (nodeFilterApplyType);
					}
				}

				if (filteredItems.Count == 0)
				{
					MessageBox.Show("There are no reports that match the selected criteria.", "Reports", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}


				//mam 07072011
				//if (!printOnly)
				if (!printOnly && !isExport)
				{
					MyReportDisplayer.Text = "Report Preview";

					if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Loading report...";
					else
						MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Loading reports...";

					MyReportDisplayer.c1PrintPreview.PreviewPane.ZoomMode = (C1.Win.C1PrintPreview.ZoomModeEnum)
						AppSettings.Settings.GetSettingInt(@"C1ReportDisplayerForm", "ZoomMode", 
						(int)C1.Win.C1PrintPreview.ZoomModeEnum.FullPage);

					//mam
					MyReportDisplayer.c1PrintPreview.PreviewPane.ZoomPercent = 
						AppSettings.Settings.GetSettingInt(@"C1ReportDisplayerForm", "ZoomPercent", (int)33);
					//</mam>

					MyReportDisplayer.previewToolBarButton6.Enabled = true;
					MyReportDisplayer.Show();
					CheckPreviewProperties();
				}

			{
				//Facility testFacility = filteredItems[pos];

				//mam - sort the reports according to the user selection
				if (radioSortFields.Checked)
				{
					if (comboBoxSortBy1.SelectedIndex != 0
						|| comboBoxSortBy2.SelectedIndex != 0
						|| comboBoxSortBy3.SelectedIndex != 0
						|| comboBoxSortBy4.SelectedIndex != 0
						|| comboBoxSortBy5.SelectedIndex != 0)
					{

						if (filteredItems[0] is Facility)
						{
							Facility.FacilityComparer facComparer = Facility.GetComparer();

							facComparer.SortLowToHigh1 = this.radioAsc1.Checked;
							facComparer.SortLowToHigh2 = this.radioAsc2.Checked;
							facComparer.SortLowToHigh3 = this.radioAsc3.Checked;
							facComparer.SortLowToHigh4 = this.radioAsc4.Checked;
							facComparer.SortLowToHigh5 = this.radioAsc5.Checked;

							ListItem sourceItem1 = comboBoxSortBy1.SelectedItem as ListItem;
							ListItem sourceItem2 = comboBoxSortBy2.SelectedItem as ListItem;
							ListItem sourceItem3 = comboBoxSortBy3.SelectedItem as ListItem;
							ListItem sourceItem4 = comboBoxSortBy4.SelectedItem as ListItem;
							ListItem sourceItem5 = comboBoxSortBy5.SelectedItem as ListItem;

							facComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
							facComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
							facComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
							facComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
							facComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

							filteredItems.Sort(facComparer);
						}
				
						else if (filteredItems[0] is TreatmentProcess)
						{
							TreatmentProcess.TreatmentProcessComparer procComparer = TreatmentProcess.GetComparer();

							procComparer.SortLowToHigh1 = this.radioAsc1.Checked;
							procComparer.SortLowToHigh2 = this.radioAsc2.Checked;
							procComparer.SortLowToHigh3 = this.radioAsc3.Checked;
							procComparer.SortLowToHigh4 = this.radioAsc4.Checked;
							procComparer.SortLowToHigh5 = this.radioAsc5.Checked;

							ListItem sourceItem1 = comboBoxSortBy1.SelectedItem as ListItem;
							ListItem sourceItem2 = comboBoxSortBy2.SelectedItem as ListItem;
							ListItem sourceItem3 = comboBoxSortBy3.SelectedItem as ListItem;
							ListItem sourceItem4 = comboBoxSortBy4.SelectedItem as ListItem;
							ListItem sourceItem5 = comboBoxSortBy5.SelectedItem as ListItem;

							procComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
							procComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
							procComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
							procComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
							procComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

							filteredItems.Sort(procComparer);
							
						}

						else if (filteredItems[0] is MajorComponent)
						{
							MajorComponent.MajorComponentComparer compComparer = MajorComponent.GetComparer();

							compComparer.SortLowToHigh1 = this.radioAsc1.Checked;
							compComparer.SortLowToHigh2 = this.radioAsc2.Checked;
							compComparer.SortLowToHigh3 = this.radioAsc3.Checked;
							compComparer.SortLowToHigh4 = this.radioAsc4.Checked;
							compComparer.SortLowToHigh5 = this.radioAsc5.Checked;

							ListItem sourceItem1 = comboBoxSortBy1.SelectedItem as ListItem;
							ListItem sourceItem2 = comboBoxSortBy2.SelectedItem as ListItem;
							ListItem sourceItem3 = comboBoxSortBy3.SelectedItem as ListItem;
							ListItem sourceItem4 = comboBoxSortBy4.SelectedItem as ListItem;
							ListItem sourceItem5 = comboBoxSortBy5.SelectedItem as ListItem;

							compComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
							compComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
							compComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
							compComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
							compComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

							filteredItems.Sort(compComparer);
						}
						else if (filteredItems[0] is Discipline)
						{
							DisciplineLand.DisciplineComparer discLandComparer = DisciplineLand.GetComparer();
							DisciplineMech.DisciplineComparer discMechComparer = DisciplineMech.GetComparer();
							DisciplineStruct.DisciplineComparer discStructComparer = DisciplineStruct.GetComparer();
							DisciplineNode.DisciplineComparer discNodeComparer = DisciplineNode.GetComparer();
							DisciplinePipe.DisciplineComparer discPipeComparer = DisciplinePipe.GetComparer();
							Discipline.DisciplineComparerBase discComparerBase = Discipline.GetComparerBase();

							ListItem sourceItem1 = comboBoxSortBy1.SelectedItem as ListItem;
							ListItem sourceItem2 = comboBoxSortBy2.SelectedItem as ListItem;
							ListItem sourceItem3 = comboBoxSortBy3.SelectedItem as ListItem;
							ListItem sourceItem4 = comboBoxSortBy4.SelectedItem as ListItem;
							ListItem sourceItem5 = comboBoxSortBy5.SelectedItem as ListItem;

							if (currentNodeType == WAM.UI.NodeType.DisciplineLand)
							{
								discLandComparer.SortLowToHigh1 = this.radioAsc1.Checked;
								discLandComparer.SortLowToHigh2 = this.radioAsc2.Checked;
								discLandComparer.SortLowToHigh3 = this.radioAsc3.Checked;
								discLandComparer.SortLowToHigh4 = this.radioAsc4.Checked;
								discLandComparer.SortLowToHigh5 = this.radioAsc5.Checked;

								discLandComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discLandComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discLandComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discLandComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discLandComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discLandComparer);
							}
							else if (currentNodeType == WAM.UI.NodeType.DisciplineMech)
							{
								discMechComparer.SortLowToHigh1 = this.radioAsc1.Checked;
								discMechComparer.SortLowToHigh2 = this.radioAsc2.Checked;
								discMechComparer.SortLowToHigh3 = this.radioAsc3.Checked;
								discMechComparer.SortLowToHigh4 = this.radioAsc4.Checked;
								discMechComparer.SortLowToHigh5 = this.radioAsc5.Checked;

								discMechComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discMechComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discMechComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discMechComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discMechComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discMechComparer);
							}
							else if (currentNodeType == WAM.UI.NodeType.DisciplineStruct)
							{
								discStructComparer.SortLowToHigh1 = this.radioAsc1.Checked;
								discStructComparer.SortLowToHigh2 = this.radioAsc2.Checked;
								discStructComparer.SortLowToHigh3 = this.radioAsc3.Checked;
								discStructComparer.SortLowToHigh4 = this.radioAsc4.Checked;
								discStructComparer.SortLowToHigh5 = this.radioAsc5.Checked;

								discStructComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discStructComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discStructComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discStructComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discStructComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discStructComparer);
							}
							else if (currentNodeType == WAM.UI.NodeType.DisciplineNode)
							{
								discNodeComparer.SortLowToHigh1 = this.radioAsc1.Checked;
								discNodeComparer.SortLowToHigh2 = this.radioAsc2.Checked;
								discNodeComparer.SortLowToHigh3 = this.radioAsc3.Checked;
								discNodeComparer.SortLowToHigh4 = this.radioAsc4.Checked;
								discNodeComparer.SortLowToHigh5 = this.radioAsc5.Checked;

								discNodeComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discNodeComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discNodeComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discNodeComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discNodeComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discNodeComparer);
							}
							else if (currentNodeType == WAM.UI.NodeType.DisciplinePipe)
							{
								discPipeComparer.SortLowToHigh1 = this.radioAsc1.Checked;
								discPipeComparer.SortLowToHigh2 = this.radioAsc2.Checked;
								discPipeComparer.SortLowToHigh3 = this.radioAsc3.Checked;
								discPipeComparer.SortLowToHigh4 = this.radioAsc4.Checked;
								discPipeComparer.SortLowToHigh5 = this.radioAsc5.Checked;

								discPipeComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discPipeComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discPipeComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discPipeComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discPipeComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discPipeComparer);
							}
							else
							{
								discComparerBase.SortLowToHigh1 = this.radioAsc1.Checked;
								discComparerBase.SortLowToHigh2 = this.radioAsc2.Checked;
								discComparerBase.SortLowToHigh3 = this.radioAsc3.Checked;
								discComparerBase.SortLowToHigh4 = this.radioAsc4.Checked;
								discComparerBase.SortLowToHigh5 = this.radioAsc5.Checked;

								discComparerBase.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
								discComparerBase.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
								discComparerBase.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
								discComparerBase.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
								discComparerBase.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;

								filteredItems.Sort(discComparerBase);
							}
						}
						else if (filteredItems[0] is ComponentAsset)
						{
							ComponentAsset.ComponentAssetComparer assetComparer = ComponentAsset.GetComparer();

							assetComparer.SortLowToHigh1 = this.radioAsc1.Checked;
							assetComparer.SortLowToHigh2 = this.radioAsc2.Checked;
							assetComparer.SortLowToHigh3 = this.radioAsc3.Checked;
							assetComparer.SortLowToHigh4 = this.radioAsc4.Checked;
							assetComparer.SortLowToHigh5 = this.radioAsc5.Checked;

							ListItem sourceItem1 = comboBoxSortBy1.SelectedItem as ListItem;
							ListItem sourceItem2 = comboBoxSortBy2.SelectedItem as ListItem;
							ListItem sourceItem3 = comboBoxSortBy3.SelectedItem as ListItem;
							ListItem sourceItem4 = comboBoxSortBy4.SelectedItem as ListItem;
							ListItem sourceItem5 = comboBoxSortBy5.SelectedItem as ListItem;

							assetComparer.WhichComparison1 = (UnitFilter.FilterSourceSort)sourceItem1.Value;
							assetComparer.WhichComparison2 = (UnitFilter.FilterSourceSort)sourceItem2.Value;
							assetComparer.WhichComparison3 = (UnitFilter.FilterSourceSort)sourceItem3.Value;
							assetComparer.WhichComparison4 = (UnitFilter.FilterSourceSort)sourceItem4.Value;
							assetComparer.WhichComparison5 = (UnitFilter.FilterSourceSort)sourceItem5.Value;
						
							filteredItems.Sort(assetComparer);
						}
					}
				}
				//</mam>

			{
				//mam 07072011
				if (!isExport)
				{
					//mam
					MyReportDisplayer.filteredItemsReport = filteredItems;
					MyReportDisplayer.selectedFiltersReport = selectedFilters;
					MyReportDisplayer.selectedSortOrderReport = selectedSortOrder;
					//</mam>
				}

				//mam 07072011 - let's try something - if we only want to export, why do we need to bother with creating the xml file?
				//it's very quick, but let's try to just go straight to the csv code
				//result:  success - let's just get out here and write the csv file
				if (isExport)
				{
					return;
				}

				//for (int pos = 0; pos < printItems.Count; pos++)
				for (int pos = 0; pos < filteredItems.Count; pos++)
				{
					if (filteredItems[pos] is Facility)
					{
						// Print the facility
					}

					if (printOnly)
					{
						//eventArgs.Status = "Loading Facilities";
						//UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs); 
						if (reportPrintStatusForm.CancelPreview)
						{
							reportPrintStatusForm.CancelPreview = false;
							reportPrintStatusForm.Close();
							MessageBox.Show("The report printing has been cancelled.", "Print Reports", 
								MessageBoxButtons.OK, MessageBoxIcon.Information);

							return;
						}
						else
						{
							eventArgs.Status = "Generating report " + (pos + 1) + " of " + filteredItems.Count.ToString();
							WAM.UI.ReportPrintStatus.InvokeUpdateEvent(null, eventArgs); 
						}
					}
					else
					{
						if (MyReportDisplayer.CancelPreview)
						{
							MyReportDisplayer.CancelPreview = false;
							MyReportDisplayer.previewToolBarButton6.Enabled = false;
							MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Ready";
							
							if (MyReportDisplayer != null)
							{
								MessageBox.Show("The preview has been cancelled.", "Preview Reports", 
									MessageBoxButtons.OK, MessageBoxIcon.Information);
							}

							break;
						}
						else
						{
							if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
								MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Loading report...";
							else
								MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Loading report " + (pos + 1) + " of " + filteredItems.Count.ToString();
						}
					}

					if (filteredItems[pos] is Facility)
					{
						// Print the facility

						//mam
						if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						{
							string reportXML = ((Facility)filteredItems[pos]).GetXMLMatrix(checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, filteredItems);

 							WAM.Reports.MatrixReport.PrintMatrix(
								(Facility)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, reportXML);
							break;
						}
						else
							//</mam>
						{
							WAM.Reports.FacilityReport.Print(
								(Facility)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters);
						}
					}
					else if (filteredItems[pos] is TreatmentProcess)
					{
						// Print the Treatment Process
							
						//mam
						if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						{
							string reportXML = ((TreatmentProcess)filteredItems[pos]).GetXMLMatrix(checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, filteredItems);

							WAM.Reports.MatrixReport.PrintMatrix(
								(TreatmentProcess)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, reportXML);
							break;
						}
						else
							//</mam>
						{
							WAM.Reports.TreatmentProcessReport.Print(
								(TreatmentProcess)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters);
						}
					}
					else if (filteredItems[pos] is MajorComponent)
					{
						// Print the Major Component

						//mam
						if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						{
							string reportXML = ((MajorComponent)filteredItems[pos]).GetXMLMatrix(checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, filteredItems);
							
							WAM.Reports.MatrixReport.PrintMatrix(
								(MajorComponent)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, reportXML);
							break;
						}
						else
							//</mam>
						{

							WAM.Reports.MajorComponentReport.Print(
								(MajorComponent)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters);
						}
					}
					else if (filteredItems[pos] is Discipline)
					{
						// Print discipline report

						//mam
						if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
						{
							//string reportXML = ((Discipline)filteredItems[pos]).GetXMLMatrix(checkBoxIncludePhotos.Checked, selectedFilters, filteredItems);
							WAM.Reports.MatrixReport matrixReport = new WAM.Reports.MatrixReport();
							string reportXML = matrixReport.GetXMLMatrix(checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, filteredItems);

							if (WAM.Reports.MatrixReport.PrintMatrix(
								(Discipline)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters, selectedSortOrder, reportXML))
							{
							}
							else
							{
								return;
							}
							break;
						}
						else
							//</mam>
						{

							WAM.Reports.DisciplineReport.Print(
								(Discipline)filteredItems[pos], printOnly, checkBoxIncludePhotos.Checked, selectedFilters);
						}
					}
					else if (filteredItems[pos] is ComponentAsset)
					{
						// Get the component
						ComponentAsset tempAsset = (ComponentAsset)filteredItems[pos];
						MajorComponent tempComponent = 
							CacheManager.GetMajorComponent(tempAsset.InfoSetID,
							tempAsset.ComponentID);

						// Print Component Assets
						WAM.Reports.ComponentAssetsReport.Print(tempComponent, printOnly, selectedFilters);
					}
				}
			}
				//mam - new code to preview reports
				if (printOnly)
				{
					try
					{
						reportPrintStatusForm.Close();
						reportPrintStatusForm.Dispose();
						MyReportDisplayer.c1PrintPreview.Print();
					}
					catch
					{
						System.Diagnostics.Debug.WriteLine("PrintStatusForm did not close in CreateReports");
					}
				}
				else
				{
					MyReportDisplayer.previewToolBarButton6.Enabled = false;
					MyReportDisplayer.c1PrintPreview.StatusBar.Text = "Ready";
				}

				//Cursor = Cursors.Default;
				MyReportDisplayer.Cursor = Cursors.Default;

				//</mam>
			}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred in CreateReports: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			//mam 07072011
			finally
			{
				if (!isExport)
				{
					MyReportDisplayer.Cursor = Cursors.Default;
				}
			}
		}

		private void		AddFilteredFacilities(NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS A FACILITY REPORT, AND CAN BE NO OTHER

			Facility	facility = null;
			facility = (Facility)currentReport[0];
			bool matchFound = true;

			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				// filters are not being used
				filteredItems.Add(facility);
			}
			else
			{
				// facility report filtering on facilities
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Facility)
				{
					// filtering on facility data
					if (ItemMatchesFilters(facility as IFilterable))
					{
						//filteredItems.Add(facility);

						//no break
						//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//break;
					}
					else
					{
						//note that there is no match
						matchFound = false;
						//break;
					}
				}
				else
				{
					// facility report filtering on something besides facilities
					AddFilteredProcesses(facility, nodeFilterApplyType);
				}
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Facility 
					&& matchFound)
				{
					if (!filteredItems.Contains(facility))
					{
						filteredItems.Add(facility);
					}
				}
			}
		}

		private void		AddFilteredProcesses(NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS A PROCESS REPORT, AND CAN BE NO OTHER

			TreatmentProcess	process = (TreatmentProcess)currentReport[0];
			Facility			facility = CacheManager.GetFacility(process.InfoSetID, process.FacilityID);
			bool matchFound = true;

			// if filters are not being used
			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				filteredItems.Add(process);
			}
			else
			{
				// process report with filters applied to processes
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.TreatmentProcess)
				{
					if (ItemMatchesFilters(process as IFilterable))
					{
						//filteredItems.Add(process);

						//no break
						//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
						//	break;
					}
					else
					{
						//note that there is no match
						matchFound = false;
						//break;
					}
				}
				else
				{
					// filters are applied to something besides processes
					AddFilteredComponents(facility, process, nodeFilterApplyType);
				}
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.TreatmentProcess 
					&& matchFound)
				{
					if (!filteredItems.Contains(process))
					{
						filteredItems.Add(process);
					}
				}
			}
		}

		private void		AddFilteredComponents(NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS A COMPONENT REPORT AND CAN BE NO OTHER

			MajorComponent		component = (MajorComponent)currentReport[0];
			TreatmentProcess	process = CacheManager.GetTreatmentProcess(component.InfoSetID, component.ProcessID);
			Facility			facility = CacheManager.GetFacility(process.InfoSetID, process.FacilityID);
			bool matchFound = true;

			// if filters are not being used
			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				filteredItems.Add(component);
			}
			else
			{
				// component report with filters applied to components
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.MajorComponent)
				{
					if (ItemMatchesFilters(component as IFilterable))
					{
						//filteredItems.Add(component);

						//no break
						//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
						//	break;
					}
					else
					{
						//note that there is no match
						matchFound = false;
						//break;
					}
				}
				else
				{
					// filters are applied to something besides processes and components
					AddFilteredDisciplines(facility, process, component, nodeFilterApplyType);
				}
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.MajorComponent 
					&& matchFound)
				{
					if (!filteredItems.Contains(component))
					{
						filteredItems.Add(component);
					}
				}
			}
		}

		private void		AddFilteredDisciplines(NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS A DISCIPLINE REPORT AND CAN BE NO OTHER

			NodeType nodeType = new NodeType();
			Discipline discipline = (Discipline)currentReport[0];
			MajorComponent		component = CacheManager.GetMajorComponent(discipline.InfoSetID, discipline.ComponentID);
			TreatmentProcess	process = CacheManager.GetTreatmentProcess(component.InfoSetID, component.ProcessID);
			Facility			facility = CacheManager.GetFacility(process.InfoSetID, process.FacilityID);
			bool matchFound = true;

			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineLand)
				nodeType = WAM.UI.NodeType.DisciplineLand;
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineMech)
				nodeType = WAM.UI.NodeType.DisciplineMech;
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineStruct)
				nodeType = WAM.UI.NodeType.DisciplineStruct;
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineNode)
				nodeType = WAM.UI.NodeType.DisciplineNode;
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplinePipe)
				nodeType = WAM.UI.NodeType.DisciplinePipe;

			// if filters are not being used
			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				filteredItems.Add(discipline);
			}
			else
			{
				// discipline report with filters applied to discipline
				if (NodeTypeHandler.IsNodeTypeSameAsDisciplineType(nodeType, discipline.Type)
					|| nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Discipline)
				{
					if (ItemMatchesFilters(discipline as IFilterable))
					{
						//filteredItems.Add(discipline);

						//no break
						//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
						//	break;
					}
					else
					{
						//note that there is no match
						matchFound = false;
						//break;
					}
				}
				else
				{
					// filters are applied to something besides processes and components and disciplines
					AddFilteredAssets(facility, process, component, discipline, nodeFilterApplyType);
				}
				//if (NodeTypeHandler.IsNodeTypeSameAsDisciplineType(nodeType, discipline.Type)
				//	|| nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Discipline
				//	&& matchFound)
				if (nodeFilterApplyType.ToString().StartsWith("Discipline") 
					&& matchFound)
				{
					if (!filteredItems.Contains(discipline))
					{
						filteredItems.Add(discipline);
					}
				}
			}
		}

		private void		AddFilteredAssets(NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS AN ASSET REPORT, AND CAN BE NO OTHER

			ComponentAsset asset = (ComponentAsset)currentReport[0];
			bool matchFound = true;
			// if filters are not being used
			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				filteredItems.Add(asset);
			}
			else
			{
				ComponentAsset[] assets = CacheManager.GetAssets(asset.InfoSetID, asset.ComponentID);

				for (int i = 0; i < assets.Length; i++)
				{
					// asset report with filters applied to assets
					if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.ComponentAsset)
					{
						if (ItemMatchesFilters(assets[i] as IFilterable))
						{
							//filteredItems.Add(asset);
							//break;
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							matchFound = true;
								break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							//break;
						}
					}
				}
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.ComponentAsset 
					&& matchFound)
				{
					if (!filteredItems.Contains(asset))
					{
						filteredItems.Add(asset);
					}
				}
			}
		}

		private void AddFilteredProcesses(Facility facility, NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS NOT A PROCESS REPORT, SO IT MUST BE A FACILITY REPORT

			//TreatmentProcess		process = null;
			TreatmentProcess[] processes = CacheManager.GetProcesses(facility.InfoSetID, facility.ID);
			bool matchFound = true;

			foreach (TreatmentProcess process in processes)
			{
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.TreatmentProcess)
				{
					// facility report filtering on processes
					if (ItemMatchesFilters(process as IFilterable))
					{
//						if (!filteredItems.Contains(facility))
//						{
//							filteredItems.Add(facility);
//							break;
//						}
						//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
						//	break;
					}
					else
					{
						//note that there is no match
						matchFound = false;
						break;
					}
				}
				else
				{
					// facility report filtering on something besides facilities or processes
					AddFilteredComponents(facility, process, nodeFilterApplyType);
				}
			}
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.TreatmentProcess 
				&& matchFound)
			{
				if (!filteredItems.Contains(facility))
				{
					filteredItems.Add(facility);
				}
			}
		}

		private void AddFilteredComponents(Facility facility, TreatmentProcess process, 
										   NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS NOT A COMPONENT REPORT, BUT COULD BE EITHER A FACILITY OR PROCESS REPORT

			//MajorComponent		component = null;
			MajorComponent[] components = CacheManager.GetComponents(process.InfoSetID, process.ID);
			bool matchFound = true;

			foreach (MajorComponent component in components)
			{
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.MajorComponent)
				{
					// facility or process report filtering on components
					if (currentReport[0] is Facility)
					{
						// add the facility to the list if the report is a facility report
						if (ItemMatchesFilters(component as IFilterable))
						{
							//if (!filteredItems.Contains(facility))
							//{
							//	filteredItems.Add(facility);
							//	break;
							//}
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//	break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							break;
						}
					}
					else if (currentReport[0] is TreatmentProcess)
					{
						// add the process to the list if the report is a process report
						if (ItemMatchesFilters(component as IFilterable))
						{
							//if (!filteredItems.Contains(process))
							//{
							//	filteredItems.Add(process);
							//	break;
							//}
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//	break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							break;
						}
					}
				}
				else
				{
					// facility or process report filtering on something besides facilities or processes or components
					AddFilteredDisciplines(facility, process, component, nodeFilterApplyType);
				}
			}
			if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.MajorComponent 
				&& matchFound)
			{
				if (currentReport[0] is Facility)
				{
					if (!filteredItems.Contains(facility))
					{
						filteredItems.Add(facility);
					}
				}
				else if (currentReport[0] is TreatmentProcess)
				{
					if (!filteredItems.Contains(process))
					{
						filteredItems.Add(process);
					}
				}
			}
		}

		private void AddFilteredDisciplines(Facility facility, TreatmentProcess process, MajorComponent component, 
											NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS NOT A DISCIPLINE REPORT, BUT COULD BE EITHER A FACILITY OR PROCESS OR COMPONENT REPORT

			Discipline[] disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);
			NodeType nodeType = new NodeType();
			bool matchFound = true;

			foreach (Discipline discipline in disciplines)
			{
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineLand)
					nodeType = WAM.UI.NodeType.DisciplineLand;
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineMech)
					nodeType = WAM.UI.NodeType.DisciplineMech;
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineStruct)
					nodeType = WAM.UI.NodeType.DisciplineStruct;
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplineNode)
					nodeType = WAM.UI.NodeType.DisciplineNode;
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.DisciplinePipe)
					nodeType = WAM.UI.NodeType.DisciplinePipe;

				if (NodeTypeHandler.IsNodeTypeSameAsDisciplineType(nodeType, discipline.Type)
					|| nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Discipline)
				{
					// facility or process or component report filtering on components
					if (currentReport[0] is Facility)
					{
						// add the facility to the list if the report is a facility report
						if (ItemMatchesFilters(discipline as IFilterable))
						{
							//if (!filteredItems.Contains(facility))
							//{
							//	filteredItems.Add(facility);
							//	break;
							//}
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//	break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							break;
						}
					}
					else if (currentReport[0] is TreatmentProcess)
					{
						// add the process to the list if the report is a process report
						if (ItemMatchesFilters(discipline as IFilterable))
						{
							//if (!filteredItems.Contains(process))
							//{
							//	filteredItems.Add(process);
							//	break;
							//}
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//	break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							break;
						}
					}

					else if (currentReport[0] is MajorComponent)
					{
						// add the process to the list if the report is a process report
						if (ItemMatchesFilters(discipline as IFilterable))
						{
							//if (!filteredItems.Contains(component))
							//{
							//	filteredItems.Add(component);
							//	break;
							//}
							//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
							//	break;
						}
						else
						{
							//note that there is no match
							matchFound = false;
							break;
						}
					}
				}
				else
				{
					// facility or process or component report filtering on something besides facilities or processes or components
					AddFilteredAssets(facility, process, component, discipline, nodeFilterApplyType);
				}
			}
			//if (NodeTypeHandler.IsNodeTypeSameAsDisciplineType(nodeType, discipline.Type)
			//	|| nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.Discipline
			//	&& matchFound)
			if (nodeFilterApplyType.ToString().StartsWith("Discipline") 
				&& matchFound)
			{
				if (currentReport[0] is Facility)
				{
					if (!filteredItems.Contains(facility))
					{
						filteredItems.Add(facility);
					}
				}
				else if (currentReport[0] is TreatmentProcess)
				{
					if (!filteredItems.Contains(process))
					{
						filteredItems.Add(process);
					}
				}
				else if (currentReport[0] is MajorComponent)
				{
					if (!filteredItems.Contains(component))
					{
						filteredItems.Add(component);
					}
				}
			}
		}

		private void		AddFilteredAssets(Facility facility, TreatmentProcess process, MajorComponent component, 
											  Discipline discipline, NodeTypeHandler.NodeTypeReport nodeFilterApplyType)
		{
			// THIS IS NOT AN ASSET REPORT, BUT COULD BE EITHER A FACILITY OR PROCESS OR COMPONENT OR DISCIPLINE REPORT

			ComponentAsset[] assets = CacheManager.GetAssets(facility.InfoSetID, component.ID);
			bool matchFound = true;

			// only Mech disciplines have assets
			//MessageBox.Show(discipline.Type.ToString());
			if (discipline.Type == WAM.Data.DisciplineType.Mechanical)
			{
				assets = CacheManager.GetAssets(discipline.InfoSetID, discipline.ComponentID);

				foreach (ComponentAsset asset in assets)
				{
					if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.ComponentAsset)
					{
						// facility or process or component or discipline report filtering on assets
						if (currentReport[0] is Facility)
						{
							// add the asset to the list if the report is a facility report
							if (ItemMatchesFilters(asset as IFilterable))
							{
								//if (!filteredItems.Contains(facility))
								//{
								//	filteredItems.Add(facility);
								//	break;
								//}
								//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
								//	break;
							}
							else
							{
								//note that there is no match
								matchFound = false;
								break;
							}
						}
						else if (currentReport[0] is TreatmentProcess)
						{
							// add the asset to the list if the report is a process report
							if (ItemMatchesFilters(asset as IFilterable))
							{
								//if (!filteredItems.Contains(process))
								//{
								//	filteredItems.Add(process);
								//	break;
								//}
								//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
								//	break;
							}
							else
							{
								//note that there is no match
								matchFound = false;
								break;
							}
						}
						else if (currentReport[0] is MajorComponent)
						{
							// add the asset to the list if the report is a component report
							if (ItemMatchesFilters(asset as IFilterable))
							{
								//if (!filteredItems.Contains(component))
								//{
								//	filteredItems.Add(component);
								//	break;
								//}
								//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
								//	break;
							}
							else
							{
								//note that there is no match
								matchFound = false;
								break;
							}
						}
						else if (currentReport[0] is Discipline)
						{
							// add the asset to the list if the report is a discipline report
							if (ItemMatchesFilters(asset as IFilterable))
							{
								//if (!filteredItems.Contains(discipline))
								//{
								//	filteredItems.Add(discipline);
								//	break;
								//}
								//if (radioMatchAny.Checked && listBoxCriteria.Items.Count > 1)
								//	break;
							}
							else
							{
								//note that there is no match
								matchFound = false;
								break;
							}
						}
					}
				}
				if (nodeFilterApplyType == NodeTypeHandler.NodeTypeReport.ComponentAsset 
					&& matchFound)
				{
					if (currentReport[0] is Facility)
					{
						if (!filteredItems.Contains(facility))
						{
							filteredItems.Add(facility);
						}
					}
					else if (currentReport[0] is TreatmentProcess)
					{
						if (!filteredItems.Contains(process))
						{
							filteredItems.Add(process);
						}
					}
					else if (currentReport[0] is MajorComponent)
					{
						if (!filteredItems.Contains(component))
						{
							filteredItems.Add(component);
						}
					}
					else if (currentReport[0] is Discipline)
					{
						if (!filteredItems.Contains(discipline))
						{
							filteredItems.Add(discipline);
						}
					}
				}
			}
		}

		private bool ItemMatchesFilters(IFilterable filterObj)
		{
			if (m_filters == null)
				m_filters = GetUnitFilters();

			// If the object is not IFilterable, then return false (should not happen)
			if (filterObj == null)
				return false;

			bool			matchAll = radioMatchAllCriteria.Checked;

			//mam - set hasMatch to true
			//bool			hasMatch = m_filters.Length == 0;
			bool			hasMatch = true;
			//</mam>
			UnitFilter		filter = null;

			for (int pos = 0; pos < m_filters.Length; pos++)
			{
				//mam
				if (treeViewCriteria.Nodes[pos].Tag.ToString().ToUpper() == "DISABLED")
				{
					//hasMatch = true;
					continue;
				}
				//</mam>

				filter = m_filters[pos];
				// Test to see if the item matches the filter
				hasMatch = filter.MatchesFilter(filterObj);

				if (!hasMatch && matchAll)
				{
					// If not, and matchAll is selected, no need to continue
					break;
				}

				// If we have a match, and it is match any, then 
				// go ahead and stop comparing filters
				if (hasMatch && !matchAll)
					break;
			}

			return hasMatch;
		}

		private UnitFilter[] GetUnitFilters()
		{
			UnitFilter[]	filters = new UnitFilter[listBoxCriteria.Items.Count];

			for (int pos = 0; pos < filters.Length; pos++)
			{
				filters[pos] = (UnitFilter)listBoxCriteria.Items[pos];

				UnitFilter filter = filters[pos];
			}

			return filters;
		}

		//mam
		public static bool LoadReport(C1.Win.C1Report.C1Report MyReport)
		{
			C1Report m_report = new C1Report();

			m_report = MyReport;
			//m_report.Render();

			try
			{
				m_report.Render();
			}
			catch
			{
				//MessageBox.Show(this, ex.Message.ToString(), "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				MessageBox.Show("An error has occurred.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			foreach (Image img in m_report.PageImages)
			{
				MyReportDisplayer.c1PrintPreview.Pages.Add((object)img.Clone());
				//reportTest.PageImages.Add((object)img.Clone());
			}

			return true;
		}
		//</mam>

		//mam
		private void GetSortOrder()
		{
			selectedSortOrder = "";
			StringBuilder builder = new StringBuilder();

			if (radioSortFields.Checked)
			{
				if (comboBoxSortBy1.SelectedIndex != 0)
				{
					builder.Append(comboBoxSortBy1.Text);
					if (radioAsc1.Checked)
						builder.Append(" (Ascending)");
					else
						builder.Append(" (Descending)");

					builder.Append(",  ");
				}
				if (comboBoxSortBy2.SelectedIndex != 0)
				{
					builder.Append(comboBoxSortBy2.Text);
					if (radioAsc2.Checked)
						builder.Append(" (Ascending)");
					else
						builder.Append(" (Descending)");

					builder.Append(",  ");
				}
				if (comboBoxSortBy3.SelectedIndex != 0)
				{
					builder.Append(comboBoxSortBy3.Text);
					if (radioAsc3.Checked)
						builder.Append(" (Ascending)");
					else
						builder.Append(" (Descending)");
					
					builder.Append(",  ");
				}
				if (comboBoxSortBy4.SelectedIndex != 0)
				{
					builder.Append(comboBoxSortBy4.Text);
					if (radioAsc4.Checked)
						builder.Append(" (Ascending)");
					else
						builder.Append(" (Descending)");
					
					builder.Append(",  ");
				}
				if (comboBoxSortBy5.SelectedIndex != 0)
				{
					builder.Append(comboBoxSortBy5.Text);
					if (radioAsc5.Checked)
						builder.Append(" (Ascending)");
					else
						builder.Append(" (Descending)");
					builder.Append(",  ");
				}
			}

			//remove the trailing ",  "
			if (builder.Length != 0)
			{
				switch (currentNodeType)
				{
					case WAM.UI.NodeType.Facility:
						builder.Insert(0, "Facilities are sorted by:  ");
						break;
					case WAM.UI.NodeType.TreatmentProcess:
						builder.Insert(0, "Processes are sorted by:  ");
						break;
					case WAM.UI.NodeType.MajorComponent:
						builder.Insert(0, "Components are sorted by:  ");
						break;
					default:
						builder.Insert(0, "Disciplines are sorted by:  ");
						break;
				}

				builder.Remove(builder.Length - 3, 3);
				//builder.Append("\r\n");
				selectedSortOrder = builder.ToString();
			}
		}
		//</mam>

		#endregion /***** Create Reports *****/

		#region /***** Navigation Buttons *****/

		private void SaveExportImportReportToExcel()
		{
			DataTable dataTableResults = new DataTable();
			DataColumn newCol = new DataColumn();
			dataTableResults.Rows.Clear();
			dataTableResults.Columns.Clear();
			newCol = dataTableResults.Columns.Add("Photo File", typeof(string));
			newCol = dataTableResults.Columns.Add("Saved to Database", typeof(string));
			newCol = dataTableResults.Columns.Add("Not Saved to Database", typeof(string));
			newCol = dataTableResults.Columns.Add("Reason Not Saved to Database", typeof(string));
			newCol = dataTableResults.Columns.Add("Error", typeof(string));
			newCol = dataTableResults.Columns.Add("Asset Type", typeof(string));
			newCol = dataTableResults.Columns.Add("Discipline Type", typeof(string));
			newCol = dataTableResults.Columns.Add("Facility Id", typeof(string));
			newCol = dataTableResults.Columns.Add("Treatment Process Id", typeof(string));
			newCol = dataTableResults.Columns.Add("Major Component Id", typeof(string));

			//add result to table
			DataRow dataRow;
			dataRow = dataTableResults.NewRow();

			dataRow["Photo File"] = "test 1";
			dataRow["Saved to Database"] = "test 2";
			dataRow["Not Saved to Database"] = "test 3";
			dataRow["Reason Not Saved to Database"] = "test 4";
			dataRow["Error"] = "test 5";
			dataRow["Asset Type"] = "test 6";
			dataRow["Discipline Type"] = "test 7";
			dataRow["Facility Id"] = "test 8";
			dataRow["Treatment Process Id"] = "test 9";
			dataRow["Major Component Id"] = "test 10";

			dataTableResults.Rows.Add(dataRow);

			MessageBox.Show(dataTableResults.Rows.Count.ToString());

			C1.Win.C1FlexGrid.C1FlexGrid c1FlexGrid = new C1.Win.C1FlexGrid.C1FlexGrid();
			c1FlexGrid.DataSource = dataTableResults;

			MessageBox.Show(c1FlexGrid.Rows.Count.ToString());
			MessageBox.Show(c1FlexGrid.DataSource.ToString());

			c1FlexGrid.SaveExcel(@"C:\marti\programming\Test12.xls");
		}

		private void SaveExportImportReportToExcel2()
		{
			C1.C1Excel.C1XLBook excelBook = new C1.C1Excel.C1XLBook();
			XLSheet sheet = excelBook.Sheets.Add();
			//ArrayList arrayListGrids = new ArrayList();
			C1FlexGrid grid = new C1FlexGrid();
			XLCell cell;
			//CellRange cellRange;
			XLStyle xsDefault = new XLStyle(excelBook);
			xsDefault.Font = new Font("Arial", 10, FontStyle.Regular);
			//bool isDiscipline = false;
			
			//sheet.Name = "Facility Export Import Report Test";
			sheet.Name = "Facility Export Import Test";
			sheet.Book.DefaultFont   = new Font("Arial", 10, FontStyle.Regular);

			cell = sheet[0, 0];
			cell.Value = "33333";

			excelBook.Save(@"C:\marti\programming\Test9.xls");
		}

		private void SaveExportImportReportToExcel1()
		{
			//for testing only!!!

			//NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			//if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ImportFormat)
			//{
				StringBuilder builder = new StringBuilder();
				builder.Append("SELECT ");
				builder.Append("0 AS NoExport_facility_id ");
				builder.Append(", -1 AS NoExport_facility_sortOrder ");
				builder.Append(", 'Facility Name' AS facility_name ");
				builder.Append(", 'Facility Current Year' AS facility_currentYear ");
				builder.Append(", 'Facility Criticality' AS FacilityCriticality ");
				builder.Append(", 'Custom ENR Table' AS CustomENRListID ");
				builder.Append(", 'Photo File Name 1' AS PhotoFileNameNorth ");
				builder.Append(", 'Photo File Name 2' AS PhotoFileNameSouth ");
				builder.Append(", 'Photo Caption 1' AS facility_captionNorth ");
				builder.Append(", 'Photo Caption 2' AS facility_captionSouth ");
				builder.Append(", 'Comments' AS facility_comments ");

				builder.Append("UNION SELECT ");
				builder.Append("facility_id  ");
				builder.Append(", facility_sortOrder ");
				builder.Append(", facility_name ");
				builder.Append(", CONVERT(VARCHAR(MAX), facility_currentYear) ");
				builder.Append(", CONVERT(VARCHAR(MAX), FacilityCriticality) ");
				builder.Append(", CONVERT(VARCHAR(MAX), CustomENRListID) ");
				builder.Append(", PhotoFileNameNorth ");
				builder.Append(", PhotoFileNameSouth ");
				builder.Append(", facility_captionNorth ");
				builder.Append(", facility_captionSouth ");
				builder.Append(", facility_comments ");
				builder.Append("FROM Facilities ");
				builder.Append("WHERE facility_id IN (1791, 1795) ");
				builder.Append("ORDER BY NoExport_facility_sortOrder, NoExport_facility_id ");

				WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
				DataTable dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());

				MessageBox.Show("dataTable.Rows.Count = " + dataTable.Rows.Count.ToString());

				//find the first data column
				int i = 0;
				while (dataTable.Columns[i].ColumnName.StartsWith("NoExport"))
				{
					i++;
				}
				//for (int i = 0; i < dataTable.Columns.Count; i++)
				//{
				//	if (dataTable.Columns[i].ColumnName.StartsWith("NoExport"))
				//	{
				//	}
				//}

				//for (int j = 0; j < i; j++)
				//{
				//}
				//for (int j = i; j < dataTable.Columns.Count; j++)
				//{
				//}
			//}

			try
			{
				string fileName = "";
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.DefaultExt = "xls";
				saveFileDialog.FileName = "*.xls";
				saveFileDialog.CheckPathExists = true;
				saveFileDialog.OverwritePrompt = true;
				saveFileDialog.Title = "Save Data to Excel";
				saveFileDialog.ValidateNames = true;
				saveFileDialog.ShowHelp = true;
				saveFileDialog.AddExtension = true;
				if (saveFileDialog.ShowDialog() != DialogResult.OK)
				{
					return;
				}
				if(saveFileDialog.FileName == "")
				{
					//no file name selected
					return;
				}
				fileName = saveFileDialog.FileName.ToString();

				//string tabText = radioButton1.Checked ? "Replacement and Rehab Years" : "Constraint Violations";
				string tabText = "Facility Export Import Test";

				this.Cursor = Cursors.WaitCursor;

				C1.Win.C1FlexGrid.C1FlexGrid c1FlexGrid = new C1.Win.C1FlexGrid.C1FlexGrid();
				c1FlexGrid.DataSource = dataTable;
				//c1FlexGrid.ForeColor = System.Drawing.Color.Black;
				//c1FlexGrid.Visible = true;
				//c1FlexGrid.Refresh();
				
				MessageBox.Show(c1FlexGrid[0, 0].ToString());
				c1FlexGrid[0, 0] = "testing";
				MessageBox.Show(c1FlexGrid[0, 0].ToString());

				//MessageBox.Show("c1FlexGrid.Rows.Count = " + c1FlexGrid.Rows.Count.ToString());
				//MessageBox.Show("dataTable.Rows.Count = " + dataTable.Rows.Count.ToString());

				//c1FlexGrid.SaveExcel(fileName, tabText, C1.Win.C1FlexGrid.FileFlags.IncludeFixedCells);
				c1FlexGrid.SaveExcel(fileName, tabText);

				this.Cursor = Cursors.Default;
				MessageBox.Show("The file has been saved successfully.", "Save to Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch(Exception ex)
			{
				this.Cursor = Cursors.Default;
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//mam 07072011 - let's commandeer this button and use it to export csv files without having to 
		//	suffer through loading the reports into the report viewer
		//(before now, this button has been invisible and unused)
		private void buttonExport_Click(object sender, System.EventArgs e)
		{
			//************************
			//for testing only!!!
			SaveExportImportReportToExcel();
			return;
			//************************

			try
			{
				this.Cursor = Cursors.WaitCursor;

				CreateReports(false, true);

				if (filteredItems.Count > 0)
				{
					ExportDirectlyToCsv();
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.ShowErrorMessage("ReportFilterForm.Export", ex.Message);
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}

		private void buttonPrint_Click(object sender, System.EventArgs e)
		{
			try
			{
				GetSortOrder();
				GetSelectedFilters();

				newTemplateNameFromForm = "";
				if (reportPrintStatusForm.IsDisposed || reportPrintStatusForm == null)
				{
					reportPrintStatusForm = new ReportPrintStatus();
				}

				timer.Enabled = true;
				reportPrintStatusForm.OnMessage += new ReportPrintStatus.Message(this.txtMessage);
				reportPrintStatusForm.ShowDialog();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred in ReportFilterForm.buttonPrint_Click: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void buttonPreview_Click(object sender, System.EventArgs e)
		{
			GetSortOrder();
			GetSelectedFilters();
			CreateReports(false, false);
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			//allowCheckDirty = false;
			DialogResult result = DialogResult.No;

			if (filterBuilderForm21.buttonCancelEdit.Visible == true)
				result = MessageBox.Show("Would you like to save the edited filter?", "Select Report Data", 
					MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

			if (result == DialogResult.Cancel)
				return;

			if (result == DialogResult.Yes)
			{
				filterBuilderForm21.buttonAddCriteria_Click(sender, e);
				AddFilter();
			}

			this.Close();
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void buttonNext_Click(object sender, System.EventArgs e)
		{
			DialogResult result = DialogResult.No;

			if (filterBuilderForm21.buttonCancelEdit.Visible == true)
				 result = MessageBox.Show("Would you like to save the edited filter?", "Select Report Data", 
					MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

			if (result == DialogResult.Cancel)
				return;

			if (result == DialogResult.Yes)
			{
				filterBuilderForm21.buttonAddCriteria_Click(sender, e);
				AddFilter();
			}

			GetSelectedTreeNodes();

			if (printItems.Count == 0 && reportTypeCount == 0)
			{
				MessageBox.Show("There are no  '" + comboBoxReportType.Text + "'  items.  Please select another type of report under Select Report Data.", "Select Report Data", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			else if (printItems.Count == 0 && reportTypeCount != 0)
			{
				MessageBox.Show("Please select at least one item under Select Report Data", "Select Report Data", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (mnuItemViewNormal.Checked)
			{
				nodesExpanded.Clear();
				RecordTreeExpandedState();
//				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
//				{
//					RecordTreeExpandedState(node);
//				}
			}

			ResetEditing(false);

			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;

			//mam - if report is a summary (matrix) report, disable Include Photos checkbox
			if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Standard)
				checkBoxIncludePhotos.Enabled = true;
			else
				checkBoxIncludePhotos.Enabled = false;

			//mam 03202012 - move the first section down
			//mam - there is no matrix report for the Asset report, so disable the report format combo box
			//if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ComponentAsset)
			//{
			//	comboBoxReportFormat.Enabled = false;
			//	checkBoxIncludePhotos.Enabled = false;
			//	groupBoxSortBy.Enabled = false;
			//}
			//else
			//{
				comboBoxReportFormat.Enabled = true;
				groupBoxSortBy.Enabled = true;
			//}

			//mam 03202012 - disable filter, report format combo, include photos checkbox, and the preview and print buttons for ImportFormat report
			bool enableReportControls = nodeTypeReport != NodeTypeHandler.NodeTypeReport.ImportFormat;
			//panelFilter.Enabled = enableReportControls;
			//panel4.Enabled = enableReportControls;
			comboBoxReportFormat.Enabled = enableReportControls;
			checkBoxIncludePhotos.Enabled = enableReportControls;
			//buttonPreview2.Enabled = enableReportControls;
			//buttonPrint2.Enabled = enableReportControls;

			//mam 03202012 - moved this down from above
			if (nodeTypeReport == NodeTypeHandler.NodeTypeReport.ComponentAsset)
			{
				comboBoxReportFormat.Enabled = false;
				checkBoxIncludePhotos.Enabled = false;
				groupBoxSortBy.Enabled = false;
			}

			//PopulateSortByCombos(nodeTypeReport);
			panelReportForm2.Visible = true;
			panelReportForm2.BringToFront();
			panelReportForm1.Visible = false;

			comboBoxReportFormat.Focus();
		}

		private void GetSelectedFilters()
		{
			//mam - note the selected filters so they can be displayed on the report
			selectedFilters = "";
			//selectedFiltersDetailCSV = "";

			if (radioFilterNo.Checked ||( listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string))
			{
				selectedFilters = "";
			}
			else
			{
				StringBuilder builder = new StringBuilder(200);
				StringBuilder builder2 = new StringBuilder(200);
				
				bool isMatrix = (ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix;
				string applyToType = "";
				string anyAll = "";
				string selChar = "";
				

				if (radioMatchAny.Checked)
					anyAll = "at least one";
				else
					anyAll = "ALL";

				if (listBoxCriteria.Items.Count == 1)
				{
					anyAll = "";
					selChar = "the following characteristic";
				}
				else
				{
					selChar = "of the following characteristics";
				}

				NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				switch (nodeTypeReport)
				{
					case WAM.UI.NodeTypeHandler.NodeTypeReport.Facility:
						applyToType = "Facility";
						break;
					case WAM.UI.NodeTypeHandler.NodeTypeReport.TreatmentProcess:
						applyToType = "Treatment Process";
						break;
					case WAM.UI.NodeTypeHandler.NodeTypeReport.MajorComponent:
						applyToType = "Component";
						break;
					case WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset:
						applyToType = "Asset";
						break;
					default:
						applyToType = "Discipline";
						break;
				}

				//if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
				if (isMatrix)
					builder.Append((char)34 + "Each   " + applyToType + "  in this report has " + anyAll + " " + selChar + ":" + (char)34 + "\r\n"); 
				else if (applyToType == "Discipline")
					builder.Append("This Discipline has " + anyAll + " " + selChar + ":\r\n"); 
				else
					builder.Append("The totals for this  " + applyToType + "  have " + anyAll + " " + selChar + ":\r\n"); 

				for (int i = 0; i < listBoxCriteria.Items.Count; i++)
				{
					if (treeViewCriteria.Nodes[i].Tag.ToString().ToUpper() == "DISABLED")
						continue;

					if (builder2.Length > 0)
					{
						builder2.Append("\r\n");
					}
					UnitFilter unitFilter = listBoxCriteria.Items[i] as UnitFilter;
					builder2.Append(unitFilter.Description.ToString());
				}
				if (builder2.Length == 0)
				{
					selectedFilters = "";
				}
				else
				{
					builder.Append(builder2.ToString());
					selectedFilters = builder.ToString();
				}
				System.Diagnostics.Debug.WriteLine(selectedFilters);
			}
		}

		#endregion /***** Navigation Buttons *****/

		#region /***** Template *****/

		private void txtMessage(string str)
		{
			newTemplateNameFromForm = str;
		}
//
//		private void messageOptions(int autoSave)
//		{
//			SavePreferences(autoSave);
//		}
//
//		private void messageOptionsDirty(int autoSave)
//		{
//			SavePreferences(autoSave);
//		}

		private void pictureBoxTemplateNew_Click(object sender, System.EventArgs e)
		{
			CheckDirty();

			newTemplateNameFromForm = "New Report Template";

			if (ReportTemplate.ShowForm(ref newTemplateNameFromForm, "New Report Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					ResetDirty();
					ResetTemplateValues();
					//panelReportForm1.BringToFront();
					if (!SaveReportTemplate(true, false, @newTemplateNameFromForm, false))
					{
						MessageBox.Show("An error has occurred.  The new report template was not created.", "New Report Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					panelReportForm1.Visible = true;
					panelReportForm1.BringToFront();
					panelReportForm2.Visible = false;
				}	
				else
					MessageBox.Show("The report template name contains no characters.", "New Report Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
			ResetDirty();
		}

		private void pictureBoxTemplateSave_Click(object sender, System.EventArgs e)
		{
			forceSave = true;

			if (comboBoxReportTemplate.Items.Count == 0)
			{
				pictureBoxTemplateSaveAs_Click(sender, e);
			}
			else
			{
				if (!SaveReportTemplate(false, false, comboBoxReportTemplate.Text, false))
					MessageBox.Show("An error has occurred.  The report template was not saved.", "Save Report Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			ResetDirty();
		}

		private void pictureBoxTemplateSaveAs_Click(object sender, System.EventArgs e)
		{
			if (comboBoxReportTemplate.Items.Count > 0)
				CheckDirty();

			forceSave = true;

			if (comboBoxReportTemplate.Items.Count > 0)
				newTemplateNameFromForm = string.Format("Copy of {0}", comboBoxReportTemplate.Text);
			else
				newTemplateNameFromForm = string.Format("New Report Template");

			if (ReportTemplate.ShowForm(ref newTemplateNameFromForm, "Report Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					if (!SaveReportTemplate(true, true, @newTemplateNameFromForm, false))
						MessageBox.Show("An error has occurred.  The report template was not saved.", "Save Report Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
					MessageBox.Show("The report template name contains no characters.", "New Report Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
			ResetDirty();
		}

		private void pictureBoxTemplateEdit_Click(object sender, System.EventArgs e)
		{
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				MessageBox.Show("There are no report templates to edit.", "Edit Report Template Name", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			newTemplateNameFromForm = comboBoxReportTemplate.Text;

			if (ReportTemplate.ShowForm(ref newTemplateNameFromForm, "Report Template Name:", this))
			{
				if (newTemplateNameFromForm.Length != 0)
				{
					if (!SaveReportTemplate(false, false, @newTemplateNameFromForm, true))
						MessageBox.Show("An error has occurred.  The report template name was not changed.", "Change Report Template Name", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				else
					MessageBox.Show("The report template name contains no characters.", "Report Template", 
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				//MessageBox.Show("Cancelled");
			}
		}

		private void pictureBoxTemplateDelete_Click(object sender, System.EventArgs e)
		{
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				MessageBox.Show("There are no report templates to delete.", "Delete Report Template", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			int templateID = 0;
			bool result = false;
			DialogResult dialogResult = DialogResult.No;

			if (comboBoxReportTemplate.SelectedIndex != -1)
			{
				dialogResult = MessageBox.Show("Would you like to delete report template  '" 
					+ comboBoxReportTemplate.Text + "'  ?", "Delete Report Template", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
			}

			if (dialogResult == DialogResult.Yes)
			{
				try
				{
					this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
					templateID = (int)comboBoxReportTemplate.SelectedValue;
					WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
					result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplate WHERE ReportTemplateID = " + templateID);
					if (result)
					{
						// delete successful
						int curSelIndex = comboBoxReportTemplate.SelectedIndex;

						savingTemplate = true;
						LoadTemplateCombo();
						SetReportTemplateSettings();
						savingTemplate = false;

						currentTemplateID = 0;
						if (comboBoxReportTemplate.Items.Count == 0)
						{
							ResetTemplateValues();
						}
						else
						{
							if (curSelIndex >= comboBoxReportTemplate.Items.Count)
								comboBoxReportTemplate.SelectedIndex = curSelIndex - 1;
							else
							{
								savingTemplate = true;
								comboBoxReportTemplate.SelectedIndex = curSelIndex;
								SetReportTemplateSettings();
								savingTemplate = false;
							}

							if (comboBoxReportTemplate.SelectedIndex > -1)
							{
								currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
							}
						}

						panelReportForm1.Visible = true;
						panelReportForm1.BringToFront();
						panelReportForm2.Visible = false;
					}
					else
					{
						MessageBox.Show("An error has occurred.  The report template was not deleted.", "Delete Report Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				finally
				{
					this.Cursor = System.Windows.Forms.Cursors.Default;
					ResetDirty();
				}
			}
		}

		private void pictureBoxTemplateOptions_Click(object sender, System.EventArgs e)
		{
			ReportTemplateOptions.ShowForm(ref optionAutoSave, "Report Preferences", "Automatically save report templates", this);
		}

//		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
//		{
//			// This event is raised when the F1 key is pressed or the Help cursor is clicked
//			hlpEvent.Handled = true;
//			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
//		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			if (panelReportForm1.Visible)
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
			else
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsReportFormatSortOrder.htm");
		}

		private void comboBoxReportTemplate_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (m_initialized && !savingTemplate)
			{
				//panelReportForm1.BringToFront();
				SetReportTemplateSettings();
				
				currentTemplateID = 0;
				if (comboBoxReportTemplate.SelectedIndex > -1)
				{
					currentTemplateID = (int)comboBoxReportTemplate.SelectedValue;
				}

				CountCheckedNodes();
				ResetDirty();
				panelReportForm1.Visible = true;
				panelReportForm1.BringToFront();
				panelReportForm2.Visible = false;
			}
		}

		private void SetReportTemplateSettings()
		{
			if (comboBoxReportTemplate.Items.Count == 0)
			{
				NodeTypeHandler.NodeTypeReport nodeTypeReport = 
					(NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;

				ConfigureTree(nodeTypeReport, true);
				treeViewSpecificUnits.Refresh();
				PopulateApplyToCombo(nodeTypeReport);
				SetCurrentNodeType();
				SetCurrentApplyFilterNodeType();

				return;
			}

			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			ArrayList ComboBoxItems = new ArrayList();
			StringBuilder builder = new StringBuilder(200);

			builder.AppendFormat(@"SELECT * FROM ReportTemplate WHERE ReportTemplateID = {0}", (int)comboBoxReportTemplate.SelectedValue);
			//dataSet = dataAccess.GetDisconnectedDataset(
			//	@"SELECT * FROM ReportTemplate WHERE ReportTemplateID = " 
			//	+ (int)comboBoxReportTemplate.SelectedValue);
			dataSet = dataAccess.GetDisconnectedDataset(builder.ToString());

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateSettings.");
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];

			if (dataTable == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateSettings.");
			}

			CheckNodesAll(false);
			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
//				if (dataRow["UserView"] == System.DBNull.Value)
//					SetCurrentView((int) 0);
//				else
//					SetCurrentView(Convert.ToInt32(dataRow["UserView"]));

				if (dataRow["ReportType"] == System.DBNull.Value)
					comboBoxReportType.SelectedIndex = 0;
				else
					comboBoxReportType.SelectedIndex = Convert.ToInt32(dataRow["ReportType"]);

				if (dataRow["ApplyFilter"] == System.DBNull.Value)
					comboBoxApplyFiltersTo.SelectedIndex = 0;
				else
					SetComboIndexEnum(comboBoxApplyFiltersTo, Convert.ToInt32(dataRow["ApplyFilter"]));

				if (dataRow["FilterOn"] == System.DBNull.Value)
					radioFilterYes.Checked = true;
				else if (Convert.ToInt32(dataRow["FilterOn"]) == 1)
					radioFilterYes.Checked = true;
				else
					radioFilterNo.Checked = true;

				if (dataRow["MatchAny"] == System.DBNull.Value)
					radioMatchAny.Checked = true;
				else if (Convert.ToInt32(dataRow["MatchAny"]) == 1)
					radioMatchAny.Checked = true;
				else
					radioMatchAllCriteria.Checked = true;

				if (dataRow["IncludePhotos"] == System.DBNull.Value)
					checkBoxIncludePhotos.Checked = false;
				else if (Convert.ToInt32(dataRow["IncludePhotos"]) == 1)
					checkBoxIncludePhotos.Checked = true;
				else
					checkBoxIncludePhotos.Checked = false;

				if (dataRow["DataTreeOrder"] == System.DBNull.Value)
					radioSortTree.Checked = true;
				else if (Convert.ToInt32(dataRow["DataTreeOrder"]) == 1)
					radioSortTree.Checked = true;
				else
					radioSortFields.Checked = true;

				if (dataRow["SortBy1"] == System.DBNull.Value)
				{
					SetComboIndexEnum(comboBoxSortBy1, (int)0);
					//selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
				}
				else
				{
					SetComboIndexEnum(comboBoxSortBy1, Convert.ToInt32(dataRow["SortBy1"]));
					//if (currentNodeType == WAM.UI.NodeType.AssetList)
					//	selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
				}

				if (dataRow["SortBy2"] == System.DBNull.Value)
				{
					SetComboIndexEnum(comboBoxSortBy2, (int)0);
					//selectedSortItem2 = comboBoxSortBy2.SelectedItem as ListItem;
				}
				else
				{
					SetComboIndexEnum(comboBoxSortBy2, Convert.ToInt32(dataRow["SortBy2"]));
					//if (currentNodeType != WAM.UI.NodeType.AssetList)
					//	selectedSortItem2 = comboBoxSortBy2.SelectedItem as ListItem;
				}
				
				if (dataRow["SortBy3"] == System.DBNull.Value)
				{
					SetComboIndexEnum(comboBoxSortBy3, (int)0);
					//selectedSortItem3 = comboBoxSortBy3.SelectedItem as ListItem;
				}
				else
				{
					SetComboIndexEnum(comboBoxSortBy3, Convert.ToInt32(dataRow["SortBy3"]));
					//if (currentNodeType != WAM.UI.NodeType.AssetList)
					//	selectedSortItem3 = comboBoxSortBy3.SelectedItem as ListItem;
				}

				if (dataRow["SortBy4"] == System.DBNull.Value)
				{
					SetComboIndexEnum(comboBoxSortBy4, (int)0);
					//selectedSortItem4 = comboBoxSortBy4.SelectedItem as ListItem;
				}
				else
				{
					SetComboIndexEnum(comboBoxSortBy4, Convert.ToInt32(dataRow["SortBy4"]));
					//if (currentNodeType != WAM.UI.NodeType.AssetList)
					//	selectedSortItem4 = comboBoxSortBy4.SelectedItem as ListItem;
				}

				if (dataRow["SortBy5"] == System.DBNull.Value)
				{
					SetComboIndexEnum(comboBoxSortBy5, (int)0);
					//selectedSortItem5 = comboBoxSortBy5.SelectedItem as ListItem;
				}
				else
				{
					SetComboIndexEnum(comboBoxSortBy5, Convert.ToInt32(dataRow["SortBy5"]));
					//if (currentNodeType != WAM.UI.NodeType.AssetList)
					//	selectedSortItem5 = comboBoxSortBy5.SelectedItem as ListItem;
				}

				if (dataRow["Ascending1"] == System.DBNull.Value)
					radioAsc1.Checked = true;
				else if (Convert.ToInt32(dataRow["Ascending1"]) == 1)
					radioAsc1.Checked = true;
				else
					radioDesc1.Checked = true;

				if (dataRow["Ascending2"] == System.DBNull.Value)
					radioAsc2.Checked = true;
				else if (Convert.ToInt32(dataRow["Ascending2"]) == 1)
					radioAsc2.Checked = true;
				else
					radioDesc2.Checked = true;

				if (dataRow["Ascending3"] == System.DBNull.Value)
					radioAsc3.Checked = true;
				else if (Convert.ToInt32(dataRow["Ascending3"]) == 1)
					radioAsc3.Checked = true;
				else
					radioDesc3.Checked = true;

				if (dataRow["Ascending4"] == System.DBNull.Value)
					radioAsc4.Checked = true;
				else if (Convert.ToInt32(dataRow["Ascending4"]) == 1)
					radioAsc4.Checked = true;
				else
					radioDesc4.Checked = true;

				if (dataRow["Ascending5"] == System.DBNull.Value)
					radioAsc5.Checked = true;
				else if (Convert.ToInt32(dataRow["Ascending5"]) == 1)
					radioAsc5.Checked = true;
				else
					radioDesc5.Checked = true;

				if (dataRow["ReportFormat"] == System.DBNull.Value)
					comboBoxReportFormat.SelectedIndex = 0;
				else
					comboBoxReportFormat.SelectedIndex = Convert.ToInt32(dataRow["ReportFormat"]);
			}

			SetCurrentNodeType();
			SetCurrentApplyFilterNodeType();
			SetReportTemplateCheckedNodes();
			SetReportTemplateFilters();
		}

		private void SetReportTemplateFilters()
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataTable dataTable;
			DataSet dataSet;
			int templateID = (int)comboBoxReportTemplate.SelectedValue;
			string queryString = "";
			NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxApplyFiltersTo.SelectedItem).Value;
			int valueApplyFilter = (int)nodeTypeReport;

			queryString = string.Format(@"SELECT * FROM ReportTemplateFilter WHERE ReportTemplateID = {0} ORDER BY ReportTemplateFilterID", templateID);

			listBoxCriteria.Items.Clear();
			treeViewCriteria.Nodes.Clear();
			ResetFilters();

			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateFilters.");
			}

			dataTable = dataSet.Tables[0];
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateFilters.");
			}
	
			foreach (DataRow dataRow in dataTable.Rows)
			{
				UnitFilter unitFilter = new UnitFilter();
				unitFilter.Source = (UnitFilter.FilterSource)Convert.ToInt32(dataRow["FilterSource"]);

				//this shouldn't happen:
				if (unitFilter.Source == UnitFilter.FilterSource.Undefined)
				{
					continue;
				}

				unitFilter.Operator = (UnitFilter.FilterOperator)Convert.ToInt32(dataRow["FilterOperator"]);
				unitFilter.Compare = (UnitFilter.FilterCompareTo)Convert.ToInt32(dataRow["FilterCompare"]);
				unitFilter.CompareVal1 = Convert.ToDecimal(dataRow["FilterTextCompare1"]);
				unitFilter.CompareVal2 = Convert.ToDecimal(dataRow["FilterTextCompare2"]);

				//mam 07072011
				unitFilter.CompareVal1String = dataRow["FilterTextCompare1String"] == DBNull.Value ? "" : dataRow["FilterTextCompare1String"].ToString();
				unitFilter.CompareVal2String = dataRow["FilterTextCompare2String"] == DBNull.Value ? "" : dataRow["FilterTextCompare2String"].ToString();

				listBoxCriteria.Items.Add(unitFilter);
				TreeNode node = new TreeNode();
				node.Text = unitFilter.Description.ToString();
				node.Tag = "ENABLED";
				node.ForeColor = Color.Black;
				node.ImageIndex = 6;
				node.SelectedImageIndex = 6;
				treeViewCriteria.Nodes.Add(node);
			}

			if (listBoxCriteria.Items.Count == 0)
				SetDefaultValue("Criteria");

			VerifyFilters();
		}

		private void SetReportTemplateCheckedNodes()
		{
			// Get the selected nodes from the database and set the tree accordingly

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataTable dataTable;
			DataSet dataSet;
			int templateID = (int)comboBoxReportTemplate.SelectedValue;
			string queryString = "";

			SelectedFac.Clear();
			SelectedProc.Clear();
			SelectedComp.Clear();
			//SelectedDiscAll.Clear();
			SelectedDiscAllLand.Clear();
			SelectedDiscAllMech.Clear();
			SelectedDiscAllStruct.Clear();
			SelectedDiscAllNode.Clear();
			SelectedDiscAllPipe.Clear();
			SelectedDiscLand.Clear();
			SelectedDiscMech.Clear();
			SelectedDiscStruct.Clear();
			SelectedDiscNode.Clear();
			SelectedDiscPipe.Clear();
			SelectedAsset.Clear();

			//mam 03202012
			SelectedFacImport.Clear();
			SelectedProcImport.Clear();
			SelectedCompImport.Clear();
			SelectedDiscLandImport.Clear();
			SelectedDiscMechImport.Clear();
			SelectedDiscStructImport.Clear();
			SelectedDiscNodeImport.Clear();
			SelectedDiscPipeImport.Clear();
			SelectedAssetImport.Clear();

			// Facility nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
	
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedFac.Add(CacheManager.GetFacility(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedFacImport.Add(CacheManager.GetFacility(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
				else
				{
					SelectedFac.Add(CacheManager.GetFacility(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
			}

			// Process nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedProc.Add(CacheManager.GetTreatmentProcess(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedProcImport.Add(CacheManager.GetTreatmentProcess(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
				else
				{
					SelectedProc.Add(CacheManager.GetTreatmentProcess(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
			}

			// Component nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedComp.Add(CacheManager.GetMajorComponent(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedCompImport.Add(CacheManager.GetMajorComponent(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
				else
				{
					SelectedComp.Add(CacheManager.GetMajorComponent(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
			}

			#region //***** DiscAll *****/

			// DiscAll nodes ******************************

				// Land
			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				SelectedDiscAllLand.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), 
					WAM.Data.DisciplineType.Land));
			}

				// Mech
			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				SelectedDiscAllMech.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), 
					WAM.Data.DisciplineType.Mechanical));
			}

				// Struct
			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				SelectedDiscAllStruct.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), 
					WAM.Data.DisciplineType.Structural));
			}

				// Node
			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				SelectedDiscAllNode.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), 
					WAM.Data.DisciplineType.Nodes));
			}

				// Pipe
			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				SelectedDiscAllPipe.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), 
					WAM.Data.DisciplineType.Pipes));
			}

			#endregion //***** DiscAll *****//

			// DiscLand nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedDiscLand.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Land));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedDiscLandImport.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Land));
				}
				else
				{
					SelectedDiscLand.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Land));
				}
			}

			// DiscMech nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedDiscMech.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Mechanical));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedDiscMechImport.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Mechanical));
				}
				else
				{
					SelectedDiscMech.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Mechanical));
				}
			}

			// DiscStruct nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedDiscStruct.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Structural));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedDiscStructImport.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Structural));
				}
				else
				{
					SelectedDiscStruct.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Structural));
				}
			}

			// DiscNode nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 30202012
				//SelectedDiscNode.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Nodes));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedDiscNodeImport.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Nodes));
				}
				else
				{
					SelectedDiscNode.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Nodes));
				}
			}

			// DiscPipe nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedDiscPipe.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Pipes));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedDiscPipeImport.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Pipes));
				}
				else
				{
					SelectedDiscPipe.Add(CacheManager.GetDiscipline(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"]), WAM.Data.DisciplineType.Pipes));
				}
			}

			// Asset nodes ******************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedAsset WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);

			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			}

			dataTable = dataSet.Tables[0];

			if (dataTable == null)
				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateCheckedNodes.");
			
			foreach (DataRow dataRow in dataTable.Rows)
			{
				//mam 03202012
				//SelectedAsset.Add(CacheManager.GetAsset(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				if (Convert.ToInt32(dataRow["ForImportFormat"]) == 1)
				{
					SelectedAssetImport.Add(CacheManager.GetAsset(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
				else
				{
					SelectedAsset.Add(CacheManager.GetAsset(InfoSet.CurrentID, Convert.ToInt32(dataRow["NodeID"])));
				}
			}

			//*******************************************

			//no need to call CheckNodesAll(false) because it was already called in the only routine that
			//	calls this routine
			//CheckNodesAll(false);

			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				ResurrectSelectedNodes(node);
			}

			// if the user is viewing only the selected items, 
			//	configure the tree to show only those items
			if (mnuItemViewSelected.Checked)
			{
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
				{
					ConfigureTreeSelectedNodes(treeNode);
				}
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
//			else if (mnuItemViewMainTree.Checked)
//			{
//				nodesExpandedResurrect = nodesExpandedMainForm;
//				treeViewSpecificUnits.CollapseAll();
//				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
//				{
//					ResurrectExpandedNodes(node);
//				}
//			}
		}

		private bool SaveReportTemplate(bool newTemplate, bool saveAs, string templateName, bool nameChangeOnly)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			savingTemplate = true;

			int valueReportType = 0;
			int valueApplyFilter = 0;
			int valueFilterOn = 0;
			int valueMatchAny = 0;
			int valueIncludePhotos = 0;
			int valueDataTreeOrder = 0;
			int valueSortBy1 = 0;
			int valueSortBy2 = 0;
			int valueSortBy3 = 0;
			int valueSortBy4 = 0;
			int valueSortBy5 = 0;
			int valueAscending1 = 0;
			int valueAscending2 = 0;
			int valueAscending3 = 0;
			int valueAscending4 = 0;
			int valueAscending5 = 0;
			int valueReportFormat = 0;

			int templateID = 0;
			if (!newTemplate)
			{
				//templateID = (int)comboBoxReportTemplate.SelectedValue;
				templateID = currentTemplateID;
			}

			if (templateID == 0)
			{
				//there is no existing template, and the app is trying to automatically
				//	save a template because the user has triggered the automatic save
				//	(by closing the form when it has unsaved data, for instance)
				newTemplate = true;
				saveAs = true;
			}
			
			if (templateName.Trim() == "")
				templateName = "Default Template";

			StringBuilder builder = new StringBuilder(200);

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			if (!nameChangeOnly)
			{
				// Report Type
				NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				valueReportType = (int)nodeTypeReport;

				// Apply filters to selection
				nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxApplyFiltersTo.SelectedItem).Value;
				valueApplyFilter = (int)nodeTypeReport;

				// Filter on/off
				if (radioFilterYes.Checked)
					valueFilterOn = 1;

				// Match any / match all
				if (radioMatchAny.Checked)
					valueMatchAny = 1;

				// Include photos
				if (checkBoxIncludePhotos.Checked)
					valueIncludePhotos = 1;

				// Sort by tree or fields
				if (radioSortTree.Checked)
					valueDataTreeOrder = 1;
					
				
//				if (nodeTypeReport == WAM.UI.NodeTypeHandler.NodeTypeReport.ComponentAsset)
//				{
//					//if the report is an Asset report, save the previously existing combo box selections
//					valueSortBy1 = (int)selectedSortItem1.Value;
//					valueSortBy2 = (int)selectedSortItem2.Value;
//					valueSortBy3 = (int)selectedSortItem3.Value;
//					valueSortBy4 = (int)selectedSortItem4.Value;
//					valueSortBy5 = (int)selectedSortItem5.Value;
//				}
//				else
				{
					//UnitFilter.FilterSourceSort nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy1.SelectedItem).Value;
					UnitFilter.FilterSourceSort nodeTypeSort = new WAM.Logic.UnitFilter.FilterSourceSort();

					nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy1.SelectedItem).Value;
					valueSortBy1 = (int)nodeTypeSort;

					nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy2.SelectedItem).Value;
					valueSortBy2 = (int)nodeTypeSort;

					nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy3.SelectedItem).Value;
					valueSortBy3 = (int)nodeTypeSort;

					nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy4.SelectedItem).Value;
					valueSortBy4 = (int)nodeTypeSort;

					nodeTypeSort = (UnitFilter.FilterSourceSort)((ListItem)comboBoxSortBy5.SelectedItem).Value;
					valueSortBy5 = (int)nodeTypeSort;
				}

				if (radioAsc1.Checked)
					valueAscending1 = 1;

				if (radioAsc2.Checked)
					valueAscending2 = 1;
			
				if (radioAsc3.Checked)
					valueAscending3 = 1;

				if (radioAsc4.Checked)
					valueAscending4 = 1;
			
				if (radioAsc5.Checked)
					valueAscending5 = 1;

				// Report Format
				ReportFormat reportFormat = (ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value;
				valueReportFormat = (int)reportFormat;
			}

			if (newTemplate)
			{
				builder.Append(@"INSERT INTO ReportTemplate (InfoSetID, ReportType, 
					TemplateName, ApplyFilter, FilterOn, MatchAny, IncludePhotos, DataTreeOrder, 
					SortBy1, SortBy2, SortBy3, SortBy4, SortBy5, Ascending1, Ascending2, Ascending3, Ascending4, Ascending5, ReportFormat)");
				builder.Append(" VALUES (");
				builder.Append(InfoSet.CurrentID);
				builder.Append(", ");
				builder.Append(valueReportType);
				builder.Append(", ");
				builder.Append("'");
				builder.Append(Drive.SQL.PadString(templateName));
				builder.Append("'");
				builder.Append(", ");
				builder.Append(valueApplyFilter);
				builder.Append(", ");
				builder.Append(valueFilterOn);
				builder.Append(", ");
				builder.Append(valueMatchAny);
				builder.Append(", ");
				builder.Append(valueIncludePhotos);
				builder.Append(", ");
				builder.Append(valueDataTreeOrder);
				builder.Append(", ");
				builder.Append(valueSortBy1);
				builder.Append(", ");
				builder.Append(valueSortBy2);
				builder.Append(", ");
				builder.Append(valueSortBy3);
				builder.Append(", ");
				builder.Append(valueSortBy4);
				builder.Append(", ");
				builder.Append(valueSortBy5);
				builder.Append(", ");
				builder.Append(valueAscending1);
				builder.Append(", ");
				builder.Append(valueAscending2);
				builder.Append(", ");
				builder.Append(valueAscending3);
				builder.Append(", ");
				builder.Append(valueAscending4);
				builder.Append(", ");
				builder.Append(valueAscending5);
				builder.Append(", ");
				builder.Append(valueReportFormat);
				builder.Append(")");

				templateID = dataAccess.ExecuteCommandReturnAutoID(builder.ToString());
				if (templateID == 0)
				{
					ResetDirty();
					this.Cursor = System.Windows.Forms.Cursors.Default;
					return false;
				}
				else
				{
					// carry on with saving

					if (saveAs)
					{
						//copy the existing node selections
						if (!SaveTemplateNodesChecked(templateID))
						{
							ResetDirty();
							this.Cursor = System.Windows.Forms.Cursors.Default;
							return false;
						}

						if (!SaveFilters(ref dataAccess, templateID))
						{
							ResetDirty();
							this.Cursor = System.Windows.Forms.Cursors.Default;
							return false;
						}
					}
				}
			}
			else if (nameChangeOnly)
			{
				builder.AppendFormat("UPDATE ReportTemplate SET TemplateName = '{0}'", Drive.SQL.PadString(templateName));
				builder.AppendFormat(" WHERE ReportTemplateID = {0}", templateID);

				if (!dataAccess.ExecuteCommand(builder.ToString()))
				{
					ResetDirty();
					this.Cursor = System.Windows.Forms.Cursors.Default;
					return false;
				}
			}
			else
			{
				// save existing template
				if (dirtyTemplate || forceSave)
				{
					builder.Append("UPDATE ReportTemplate SET InfoSetID = ");
					builder.Append(InfoSet.CurrentID);
					builder.Append(", ReportType = ");
					builder.Append(valueReportType);
					builder.Append(", TemplateName = '");
					builder.Append(Drive.SQL.PadString(templateName));
					builder.Append("'");
					builder.Append(", ApplyFilter = ");
					builder.Append(valueApplyFilter);
					builder.Append(", FilterOn = ");
					builder.Append(valueFilterOn);
					builder.Append(", MatchAny = ");
					builder.Append(valueMatchAny);
					builder.Append(", IncludePhotos = ");
					builder.Append(valueIncludePhotos);
					builder.Append(", DataTreeOrder = ");
					builder.Append(valueDataTreeOrder);
					builder.Append(", SortBy1 = ");
					builder.Append(valueSortBy1);
					builder.Append(", SortBy2 = ");
					builder.Append(valueSortBy2);
					builder.Append(", SortBy3 = ");
					builder.Append(valueSortBy3);
					builder.Append(", SortBy4 = ");
					builder.Append(valueSortBy4);
					builder.Append(", SortBy5 = ");
					builder.Append(valueSortBy5);
					builder.Append(", Ascending1 = ");
					builder.Append(valueAscending1);
					builder.Append(", Ascending2 = ");
					builder.Append(valueAscending2);
					builder.Append(", Ascending3 = ");
					builder.Append(valueAscending3);
					builder.Append(", Ascending4 = ");
					builder.Append(valueAscending4);
					builder.Append(", Ascending5 = ");
					builder.Append(valueAscending5);
					builder.Append(", ReportFormat = ");
					builder.Append(valueReportFormat);
					builder.Append(" WHERE ReportTemplateID = ");
					builder.Append(templateID);

					if (!dataAccess.ExecuteCommand(builder.ToString()))
					{
						ResetDirty();
						this.Cursor = System.Windows.Forms.Cursors.Default;
						return false;
					}
				}
					
				// carry on with saving

				if (dirtyNodes || forceSave)
				{
					//MessageBox.Show("Saving nodes");

					if (!SaveTemplateNodesChecked(templateID))
					{
						ResetDirty();
						this.Cursor = System.Windows.Forms.Cursors.Default;
						return false;
					}
				}

				if (dirtyFilters || forceSave)
				{
					if (!SaveFilters(ref dataAccess, templateID))
					{
						ResetDirty();
						this.Cursor = System.Windows.Forms.Cursors.Default;
						return false;
					}
				}
			}

			if (!nameChangeOnly)
				ResetDirty();

			if (newTemplate || nameChangeOnly)
			{
				LoadTemplateCombo();
				SetComboIndex(comboBoxReportTemplate, templateID);
				currentTemplateID = templateID;
			}

			this.Cursor = System.Windows.Forms.Cursors.Default;
			savingTemplate = false;
			//ResetDirty();
			return true;
		}

		private bool SaveFilters(ref WAM.Common.DataAccess dataAccess, int templateID)
		{
			bool result = false;
			string queryString = string.Format(@"SELECT * FROM ReportTemplateFilter WHERE ReportTemplateID = {0}", templateID);
				//WHERE ReportTemplateID = " + templateID + " AND ApplyFilter = " + valueApplyFilter;

			dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateFilter WHERE ReportTemplateID = " + templateID);

			if (listBoxCriteria.Items.Count == 1 && listBoxCriteria.Items[0] is string)
			{
				result = true;
			}
			else
			{
				DataSet dataSet = dataAccess.GetDisconnectedDataset(queryString);

				if (dataSet == null)
				{
					throw new Exception("Database Error.  ReportFilterForm.SaveFilters.");
				}

				for (int i = 0; i < listBoxCriteria.Items.Count; i++)
				{
					UnitFilter unitFilter = listBoxCriteria.Items[i] as UnitFilter;

//					int valueSource = (int)unitFilter.Source;
//					MessageBox.Show("Filter Source = " + valueSource.ToString());
//
//					int valueOperator = (int)unitFilter.Operator;
//					MessageBox.Show("Filter Source = " + valueOperator.ToString());
//
//					int valueCompare = (int)unitFilter.Compare;
//					MessageBox.Show("Filter Source = " + valueCompare.ToString());
//
//					decimal valueTextCompare1 = unitFilter.CompareVal1;
//					MessageBox.Show("Filter Source = " + valueTextCompare1.ToString());
//
//					decimal valueTextCompare2 = unitFilter.CompareVal2;
//					MessageBox.Show("Filter Source = " + valueTextCompare2.ToString());

					DataRow dataRow;
					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ReportTemplateID"] = templateID;
					dataRow["FilterSource"] = (int)unitFilter.Source;
					dataRow["FilterOperator"] = (int)unitFilter.Operator;
					dataRow["FilterCompare"] = (int)unitFilter.Compare;
					dataRow["FilterTextCompare1"] = (double)unitFilter.CompareVal1;
					dataRow["FilterTextCompare2"] = (double)unitFilter.CompareVal2;

					//mam 07072011
					dataRow["FilterTextCompare1String"] = unitFilter.CompareVal1String;
					dataRow["FilterTextCompare2String"] = unitFilter.CompareVal2String;

					dataSet.Tables[0].Rows.Add(dataRow);
				}

				//MessageBox.Show(dataSet.Tables[0].Rows[0]["FilterTextCompare1"].ToString());
				//System.Diagnostics.Debug.WriteLine(queryString.ToString());
				result = dataAccess.UpdateDatabase(dataSet, queryString);
			}
			return result;
		}

		private bool SaveTemplateNodesChecked(int templateID)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			DataSet dataSet = new DataSet();
			string queryString = "";
			bool result = false;

			result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = " + templateID);
			if (result)
				result = dataAccess.ExecuteCommand(@"DELETE FROM ReportTemplateNodesCheckedAsset WHERE ReportTemplateID = " + templateID);

			if (!result)
				return false;

			GetSelectedTreeNodes();

			//mam 03202012 - sort ImportFormat checked nodes as we'll save them, too
			//selNodesImport.Sort();

			// Facility nodes *************************

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedFac WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedFac.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((Facility)SelectedFac[i]).ID;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

			//dataRow["FilterReportLevelID"] = 0;
			dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedFacImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((Facility)SelectedFacImport[i]).ID;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// Process nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedProc WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedProc.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((TreatmentProcess)SelectedProc[i]).ID;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedProcImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((TreatmentProcess)SelectedProcImport[i]).ID;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);


			// Major Component nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedComp WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedComp.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((MajorComponent)SelectedComp[i]).ID;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mma 03202012
			for (int i = 0; i < SelectedCompImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((MajorComponent)SelectedCompImport[i]).ID;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			#region //***** DiscAll *****//

			// DiscAll nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllLand.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineLand)SelectedDiscAllLand[i]).ID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllMech.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineMech)SelectedDiscAllMech[i]).ID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllStruct.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineStruct)SelectedDiscAllStruct[i]).ID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllNode.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineNode)SelectedDiscAllNode[i]).ID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 1", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscAllPipe.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplinePipe)SelectedDiscAllPipe[i]).ID;
				dataRow["DiscAll"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}
			result = dataAccess.UpdateDatabase(dataSet, queryString);

			#endregion //***** DiscAll *****//

			// DiscLand nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscLand WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedDiscLand.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineLand)SelectedDiscLand[i]).ID;
				dataRow["DiscAll"] = 0;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedDiscLandImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineLand)SelectedDiscLandImport[i]).ID;
				dataRow["DiscAll"] = 0;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscMech nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscMech WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedDiscMech.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineMech)SelectedDiscMech[i]).ID;
				dataRow["DiscAll"] = 0;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedDiscMechImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineMech)SelectedDiscMechImport[i]).ID;
				dataRow["DiscAll"] = 0;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscStruct nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscStruct WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}
			
			for (int i = 0; i < SelectedDiscStruct.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineStruct)SelectedDiscStruct[i]).ID;
				dataRow["DiscAll"] = 0;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedDiscStructImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineStruct)SelectedDiscStructImport[i]).ID;
				dataRow["DiscAll"] = 0;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscNode nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscNode WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscNode.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineNode)SelectedDiscNode[i]).ID;
				dataRow["DiscAll"] = 0;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedDiscNodeImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplineNode)SelectedDiscNodeImport[i]).ID;
				dataRow["DiscAll"] = 0;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// DiscPipe nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedDiscPipe WHERE ReportTemplateID = {0} AND DiscAll = 0", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedDiscPipe.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplinePipe)SelectedDiscPipe[i]).ID;
				dataRow["DiscAll"] = 0;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedDiscPipeImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((DisciplinePipe)SelectedDiscPipeImport[i]).ID;
				dataRow["DiscAll"] = 0;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// Asset nodes *************************

			if (!result)
				return false;

			queryString = string.Format(@"SELECT * FROM ReportTemplateNodesCheckedAsset WHERE ReportTemplateID = {0}", templateID);
			dataSet = dataAccess.GetDisconnectedDataset(queryString);
			if (dataSet == null)
			{
				throw new Exception("Database Error.  ReportFilterForm.SaveTemplateNodesChecked.");
			}

			for (int i = 0; i < SelectedAsset.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((ComponentAsset)SelectedAsset[i]).ID;

				//mam 03202012
				dataRow["ForImportFormat"] = 0;

				dataSet.Tables[0].Rows.Add(dataRow);
			}

			//mam 03202012
			for (int i = 0; i < SelectedAssetImport.Count; i++)
			{
				DataRow dataRow;
				dataRow = dataSet.Tables[0].NewRow();
				dataRow["ReportTemplateID"] = templateID;
				dataRow["NodeID"] = ((ComponentAsset)SelectedAssetImport[i]).ID;
				dataRow["ForImportFormat"] = 1;
				dataSet.Tables[0].Rows.Add(dataRow);
			}

			result = dataAccess.UpdateDatabase(dataSet, queryString);

			// ***************************************

			return result;
		}

		private void ResetTemplateValues()
		{
			comboBoxReportType.SelectedIndex = 0;
			CheckNodesAll(false);
			ClearSelectedNodesArrays();

			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
				treeViewSpecificUnits.CollapseAll();

			radioFilterYes.Checked = true;

			filterBuilderForm21.ResetAll();
			this.listBoxCriteria.Items.Clear();
			treeViewCriteria.Nodes.Clear();
			SetDefaultValue("Criteria");
			ResetEditing(false);
			ResetFilters();
			radioMatchAny.Checked = true;

			checkBoxIncludePhotos.Checked = false;

			radioSortTree.Checked = true;
			comboBoxSortBy1.SelectedIndex = 0;
			comboBoxSortBy2.SelectedIndex = 0;
			comboBoxSortBy3.SelectedIndex = 0;
			comboBoxSortBy4.SelectedIndex = 0;
			comboBoxSortBy5.SelectedIndex = 0;

			radioAsc1.Checked = true;
			radioAsc2.Checked = true;
			radioAsc3.Checked = true;
			radioAsc4.Checked = true;
			radioAsc5.Checked = true;
		}

		//mam
		private void ClearSelectedNodesArrays()
		{
			SelectedFac.Clear();
			SelectedProc.Clear();
			SelectedComp.Clear();
			SelectedDiscMech.Clear();
			SelectedDiscStruct.Clear();
			SelectedDiscLand.Clear();
			SelectedDiscPipe.Clear();
			SelectedDiscNode.Clear();
			SelectedDiscAllLand.Clear();
			SelectedDiscAllMech.Clear();
			SelectedDiscAllStruct.Clear();
			SelectedDiscAllNode.Clear();
			SelectedDiscAllPipe.Clear();
			
			printItems.Clear();
			filteredItems.Clear();
			applyFilteredItems.Clear();
		}
		//</mam>

		private void comboBoxReportTemplate_DropDown(object sender, System.EventArgs e)
		{
			CheckDirty();
			return;
		}

		private void CheckDirty()
		{
			if (m_initialized && !savingTemplate)
			{
				bool saveData = true;

				//***************************
				//if dirty and not automatically saving, ask user whether or not to save changes
				if ((dirtyTemplate || dirtyNodes || dirtyFilters) && optionAutoSave == 0)
				{
					if (ReportTemplateDirty.ShowForm(ref optionAutoSave, "Save Report Template Changes", this))
					{
						//user pressed the Yes button
						saveData = true;
					}
					else
					{
						//user pressed the No button
						saveData = false;
					}
					SavePreferences();
				}

				if ((dirtyTemplate || dirtyNodes || dirtyFilters) && saveData) 
				{
					if (!SaveReportTemplate(false, false, comboBoxReportTemplate.Text, false))
						MessageBox.Show("An error has occurred.  The report template was not saved.", "Save Report Template", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}

				ResetDirty();
			}
		}

		
		#endregion /***** Template *****/

		#region /***** Common Tasks *****/

		//mam - set which item is displayed in the combo box
		private void SetComboIndex(ComboBox comboBox, int comboBoxID)
		{
			for (int i = 0; i < comboBox.Items.Count; i++)
				if (((WAM.Common.ComboBoxItem)comboBox.Items[i]).ItemID == comboBoxID)
				{
					comboBox.SelectedIndex = i;
					break;
				}
		}
		//</mam>

		//mam
		private void SetComboIndexEnum(ComboBox comboBox, int EnumID)
		{
			for (int i = 0; i < comboBox.Items.Count; i++)
				if ((int)(NodeTypeHandler.NodeTypeReport)((ListItem)comboBox.Items[i]).Value == EnumID)
				{
					comboBox.SelectedIndex = i;
					break;
				}
		}
		//</mam>

		//mam 07072011
		private void ExportDirectlyToCsv()
		{
			//MyReportDisplayer.filteredItemsReport = filteredItems;
			//MyReportDisplayer.selectedFiltersReport = selectedFilters;
			//MyReportDisplayer.selectedSortOrderReport = selectedSortOrder;

			WAM.Data.ReportFormat currentReportFormat;
			if ((ReportFormat)((ListItem)comboBoxReportFormat.SelectedItem).Value == ReportFormat.Matrix)
			{
				currentReportFormat = ReportFormat.Matrix;
			}
			else
			{
				currentReportFormat = ReportFormat.Standard;
			}

			string fileName = "";

			//open the file save dialog
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			//saveFileDialog.Filter = "Comma-Delimited (*.csv)|*.csv|Adobe pdf (*.pdf)|*.pdf|Word Rich Text Format (*.rtf)|*.rtf";
			saveFileDialog.Filter = "Comma-Delimited (*.csv)|*.csv";
			saveFileDialog.Title = "Save Reports to File";
			saveFileDialog.ValidateNames = true;
			saveFileDialog.OverwritePrompt = true;
			saveFileDialog.CheckPathExists = true;
			saveFileDialog.ShowHelp = true;
			saveFileDialog.AddExtension = true;
			//saveFileDialog.CreatePrompt = true;
			//saveFileDialog.DefaultExt = true;
			saveFileDialog.ShowDialog();
				
			if(saveFileDialog.FileName == "")
			{
				//no file name selected
				return;
			}
			else
			{
				fileName = saveFileDialog.FileName.ToString();
				switch (saveFileDialog.FilterIndex)
				{
					case 1:
						//csv
						//reportExtension = ".csv";
						if (!fileName.EndsWith(".csv"))
							fileName += ".csv";
						break;
				}
			}

			//reportfileName = fileName;
			this.Cursor = Cursors.WaitCursor;
			System.IO.FileStream fileStream = null;
			System.IO.StreamWriter streamWriter = null;
			string reportCSV = "";

			//mam 01222012
			GetSelectedFilters();

			if (filteredItems[0] is WAM.Data.Facility)
			{
				//01042012 - no changes to facility report for retired components
				WAM.Data.Facility facility = (WAM.Data.Facility)filteredItems[0];
				reportCSV = facility.GetCSVData(selectedFilters, selectedSortOrder, filteredItems, (currentReportFormat == WAM.Data.ReportFormat.Standard));
			}
			else if (filteredItems[0] is WAM.Data.TreatmentProcess)
			{
				//01042012 - changes to process detail report for retired components
				WAM.Data.TreatmentProcess process = (WAM.Data.TreatmentProcess)filteredItems[0];
				reportCSV = process.GetCSVData(selectedFilters, selectedSortOrder, filteredItems, (currentReportFormat == WAM.Data.ReportFormat.Standard));
			}
			else if (filteredItems[0] is WAM.Data.MajorComponent)
			{
				//01042012 - changes to component detail and summary reports for retired components
				WAM.Data.MajorComponent component = (WAM.Data.MajorComponent)filteredItems[0];
				reportCSV = component.GetCSVData(selectedFilters, selectedSortOrder, filteredItems, (currentReportFormat == WAM.Data.ReportFormat.Standard));
			}
			else if (filteredItems[0] is WAM.Data.Discipline)
			{
				//01042012 - changes to discipline detail and summary reports for retired components
				WAM.Data.Discipline discipline = (WAM.Data.Discipline)filteredItems[0];
				//if (discipline is WAM.Data.DisciplinePipe || discipline is WAM.Data.DisciplineNode)
				reportCSV = discipline.GetCSVData(selectedFilters, selectedSortOrder, filteredItems, (currentReportFormat == WAM.Data.ReportFormat.Standard));
				//else
				//	reportCSV = discipline.GetCSVData(selectedFilters, selectedSortOrder, filteredItems, false);
			}
			else if (filteredItems[0] is WAM.Data.ComponentAsset)
			{
				WAM.Data.ComponentAsset componentAsset = (WAM.Data.ComponentAsset)filteredItems[0];
				reportCSV = componentAsset.GetCSVData(selectedFilters, filteredItems);
			}	

			try
			{
				fileStream = new System.IO.FileStream(@fileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
				streamWriter = new System.IO.StreamWriter(fileStream);
				streamWriter.Write(reportCSV);

				this.Cursor = Cursors.Default;
				MessageBox.Show("The file has been saved successfully.", "Save Reports", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);

				streamWriter.Close();
				fileStream.Close();
				streamWriter = null;
				fileStream = null;
			}
			catch(Exception ex)
			{
				this.Cursor = Cursors.Default;
				MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally
			{
				this.Cursor = Cursors.Default;
				if (streamWriter != null)
					streamWriter.Close();
				else if (fileStream != null)
					fileStream.Close();
			}
		}

		#endregion /***** Common Tasks *****/

		#region /***** Unused Code *****/

		private void UnusedCode()
		{
//			//******************************
//			//{(ListItem)comboBox.Items[i]).Value == EnumID)
//			UnitFilter.FilterSourceSort[] sources = (UnitFilter.FilterSourceSort[])Enum.GetValues(typeof(UnitFilter.FilterSourceSort));
//			ArrayList arrayList = new ArrayList();
//			int pos;
//			for (pos = 0; pos < sources.Length; pos++)
//				//					if (UnitFilter.GetFilterSourceStringSort(sources[pos], nodeType) != "")
//			{
//				arrayList.Add(new ListItem(UnitFilter.GetFilterSourceStringSort(sources[pos]), sources[pos]));
//			}
//			//
//			ListItem[]		items = new ListItem[arrayList.Count];
//			for (pos = 0; pos < arrayList.Count; pos++)
//				items[pos] = (ListItem)arrayList[pos];
//			//******************************
//
//			if (dataRow["SortBy1"] == System.DBNull.Value)
//			{
//				SetComboIndexEnum(comboBoxSortBy1, (int)0);
//				selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
//			}
//			else
//			{
//				SetComboIndexEnum(comboBoxSortBy1, Convert.ToInt32(dataRow["SortBy1"]));
//				if (currentNodeType == WAM.UI.NodeType.AssetList)
//					selectedSortItem1 = comboBoxSortBy1.SelectedItem as ListItem;
//				else
//				{
//					pos = Convert.ToInt32(dataRow["SortBy1"]);
//					selectedSortItem1 = items[pos];
//				}
//			}
		}

		#endregion /***** Unused Code *****/

		private void treeViewSpecificUnits_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (nodeHitTest != null)
				CountCheckedNodes();
		}
		
	}
}