using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for FieldSheet1.
	/// </summary>
	public class FieldSheet1 : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		private System.Windows.Forms.Button buttonClearAll;
		private System.Windows.Forms.Button buttonSelectAll;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panelTree;
		private System.Windows.Forms.TreeView treeViewSpecificUnits;
		private System.Windows.Forms.Button buttonCancel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonPrint;
		private System.Windows.Forms.ImageList imageListTree;
		private C1.Win.C1Command.C1ContextMenu mnuContextMenu;
		private C1.Win.C1Command.C1CommandHolder CommandHolder;
		private C1.Win.C1Command.C1CommandLink mnuItemSelectAll;
		private C1.Win.C1Command.C1Command cmd_mnuItemSelectAll;
		private C1.Win.C1Command.C1CommandLink mnuItemClearAll;
		private C1.Win.C1Command.C1Command cmd_mnuItemClearAll;
		private C1.Win.C1Command.C1CommandLink menuItem3;
		private C1.Win.C1Command.C1CommandLink mnuItemSelectUnder;
		private C1.Win.C1Command.C1Command cmd_mnuItemSelectUnder;
		private C1.Win.C1Command.C1CommandLink mnuItemClearUnder;
		private C1.Win.C1Command.C1Command cmd_mnuItemClearUnder;
		private C1.Win.C1Command.C1CommandLink menuItem6;
		private C1.Win.C1Command.C1CommandLink mnuItemExpandAll;
		private C1.Win.C1Command.C1Command cmd_mnuItemExpandAll;
		private C1.Win.C1Command.C1CommandLink mnuItemCollapseAll;
		private C1.Win.C1Command.C1Command cmd_mnuItemCollapseAll;
		private C1.Win.C1Command.C1CommandLink menuItem9;
		private C1.Win.C1Command.C1CommandLink mnuItemView;
		private C1.Win.C1Command.C1CommandMenu sub_mnuItemView;
		private C1.Win.C1Command.C1CommandLink mnuItemViewNormal;
		private C1.Win.C1Command.C1Command cmd_mnuItemViewNormal;
		private C1.Win.C1Command.C1CommandLink mnuItemViewSelected;
		private C1.Win.C1Command.C1Command cmd_mnuItemViewSelected;
		private C1.Win.C1Command.C1CommandLink mnuItemViewReport;
		private C1.Win.C1Command.C1Command cmd_mnuItemViewReport;
		private C1.Win.C1Command.C1CommandLink mnuItemViewMainTree;
		private C1.Win.C1Command.C1Command cmd_mnuItemViewMainTree;
		private System.ComponentModel.IContainer components;

		private ArrayList nodesExpandedResurrect = new ArrayList();
		private ArrayList nodesExpanded = new ArrayList();
		private static ArrayList nodesExpandedMainForm = new ArrayList();
		private TreeNode nodeHitTest;
		private TreeNode nodeSelected;
		private NodeType currentNodeType = new NodeType();
		private ArrayList SelectedDiscMech = new ArrayList();
		private ArrayList SelectedDiscLand = new ArrayList();
		private ArrayList SelectedDiscStruct = new ArrayList();
		private ArrayList SelectedDiscPipe = new ArrayList();
		private ArrayList SelectedDiscNode = new ArrayList();
		//private ArrayList		SelectedDiscAll = new ArrayList();
		private ArrayList SelectedDiscAllLand = new ArrayList();
		private ArrayList SelectedDiscAllMech = new ArrayList();
		private ArrayList SelectedDiscAllStruct = new ArrayList();
		private ArrayList SelectedDiscAllNode = new ArrayList();
		private ArrayList SelectedDiscAllPipe = new ArrayList();
		private ArrayList SelectedAsset = new ArrayList();
		private bool autoChecking = false;
		private ArrayList printItems = new ArrayList();
		//private ArrayList		filteredItems = new ArrayList();
		//private ArrayList		applyFilteredItems = new ArrayList();
		private ArrayList currentReport = new ArrayList();
		private bool checkOnClick = false;
		private System.Drawing.Color colorDisabled = System.Drawing.Color.Gray;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public FieldSheet1()
		{
			//LoadSpecificUnitsTree
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FieldSheet));
			this.buttonClearAll = new System.Windows.Forms.Button();
			this.buttonSelectAll = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panelTree = new System.Windows.Forms.Panel();
			this.treeViewSpecificUnits = new System.Windows.Forms.TreeView();
			this.buttonPrint = new System.Windows.Forms.Button();
			this.buttonCancel1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.mnuContextMenu = new C1.Win.C1Command.C1ContextMenu();
			this.CommandHolder = new C1.Win.C1Command.C1CommandHolder();
			((System.ComponentModel.ISupportInitialize)(this.CommandHolder)).BeginInit();
			this.mnuItemSelectAll = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemSelectAll = new C1.Win.C1Command.C1Command();
			this.mnuItemClearAll = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemClearAll = new C1.Win.C1Command.C1Command();
			this.menuItem3 = new C1.Win.C1Command.C1CommandLink();
			this.mnuItemSelectUnder = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemSelectUnder = new C1.Win.C1Command.C1Command();
			this.mnuItemClearUnder = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemClearUnder = new C1.Win.C1Command.C1Command();
			this.menuItem6 = new C1.Win.C1Command.C1CommandLink();
			this.mnuItemExpandAll = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemExpandAll = new C1.Win.C1Command.C1Command();
			this.mnuItemCollapseAll = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemCollapseAll = new C1.Win.C1Command.C1Command();
			this.menuItem9 = new C1.Win.C1Command.C1CommandLink();
			this.mnuItemView = new C1.Win.C1Command.C1CommandLink();
			this.sub_mnuItemView = new C1.Win.C1Command.C1CommandMenu();
			this.mnuItemViewNormal = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemViewNormal = new C1.Win.C1Command.C1Command();
			this.mnuItemViewSelected = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemViewSelected = new C1.Win.C1Command.C1Command();
			this.mnuItemViewReport = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemViewReport = new C1.Win.C1Command.C1Command();
			this.mnuItemViewMainTree = new C1.Win.C1Command.C1CommandLink();
			this.cmd_mnuItemViewMainTree = new C1.Win.C1Command.C1Command();
			this.panelTree.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonClearAll
			// 
			this.buttonClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClearAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonClearAll.Location = new System.Drawing.Point(112, 448);
			this.buttonClearAll.Name = "buttonClearAll";
			this.buttonClearAll.Size = new System.Drawing.Size(88, 23);
			this.buttonClearAll.TabIndex = 71;
			this.buttonClearAll.Text = "&Clear All";
			// 
			// buttonSelectAll
			// 
			this.buttonSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSelectAll.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonSelectAll.Location = new System.Drawing.Point(8, 448);
			this.buttonSelectAll.Name = "buttonSelectAll";
			this.buttonSelectAll.Size = new System.Drawing.Size(88, 23);
			this.buttonSelectAll.TabIndex = 70;
			this.buttonSelectAll.Text = "&Select All";
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel2.Location = new System.Drawing.Point(0, 440);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(676, 2);
			this.panel2.TabIndex = 77;
			this.panel2.Visible = false;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel1.Location = new System.Drawing.Point(208, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(2, 444);
			this.panel1.TabIndex = 76;
			this.panel1.Visible = false;
			// 
			// panelTree
			// 
			this.panelTree.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelTree.Controls.Add(this.treeViewSpecificUnits);
			this.panelTree.Location = new System.Drawing.Point(8, 46);
			this.panelTree.Name = "panelTree";
			this.panelTree.Size = new System.Drawing.Size(368, 386);
			this.panelTree.TabIndex = 75;
			// 
			// treeViewSpecificUnits
			// 
			this.treeViewSpecificUnits.BackColor = System.Drawing.SystemColors.Window;
			this.treeViewSpecificUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.treeViewSpecificUnits.CheckBoxes = true;
			this.treeViewSpecificUnits.ImageIndex = -1;
			this.treeViewSpecificUnits.Location = new System.Drawing.Point(1, 1);
			this.treeViewSpecificUnits.Name = "treeViewSpecificUnits";
			this.treeViewSpecificUnits.SelectedImageIndex = -1;
			this.treeViewSpecificUnits.Size = new System.Drawing.Size(366, 384);
			this.treeViewSpecificUnits.TabIndex = 1;
			// 
			// buttonPrint
			// 
			this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrint.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonPrint.Location = new System.Drawing.Point(440, 448);
			this.buttonPrint.Name = "buttonPrint";
			this.buttonPrint.Size = new System.Drawing.Size(94, 23);
			this.buttonPrint.TabIndex = 72;
			this.buttonPrint.Text = "&Print";
			// 
			// buttonCancel1
			// 
			this.buttonCancel1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel1.Location = new System.Drawing.Point(544, 448);
			this.buttonCancel1.Name = "buttonCancel1";
			this.buttonCancel1.Size = new System.Drawing.Size(94, 23);
			this.buttonCancel1.TabIndex = 73;
			this.buttonCancel1.Text = "Close";
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.label1.Location = new System.Drawing.Point(11, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(189, 28);
			this.label1.TabIndex = 74;
			this.label1.Text = "Select Field Sheets";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// mnuContextMenu
			// 
						this.mnuContextMenu.CommandLinks.Add(this.mnuItemSelectAll);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemClearAll);
			this.mnuContextMenu.CommandLinks.Add(this.menuItem3);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemSelectUnder);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemClearUnder);
			this.mnuContextMenu.CommandLinks.Add(this.menuItem6);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemExpandAll);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemCollapseAll);
			this.mnuContextMenu.CommandLinks.Add(this.menuItem9);
			this.mnuContextMenu.CommandLinks.Add(this.mnuItemView);
// 
			// mnuItemSelectAll
			//
			//CommandHolder
			//
			this.CommandHolder.Commands.Add(this.mnuContextMenu);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemSelectAll);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemClearAll);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemSelectUnder);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemClearUnder);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemExpandAll);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemCollapseAll);
			this.CommandHolder.Commands.Add(this.sub_mnuItemView);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemViewNormal);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemViewSelected);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemViewReport);
			this.CommandHolder.Commands.Add(this.cmd_mnuItemViewMainTree);
			this.CommandHolder.Owner = this;
			// 
			this.mnuItemSelectAll.Command = this.cmd_mnuItemSelectAll;
			this.cmd_mnuItemSelectAll.Text = "&Select All";
			// 
			// mnuItemClearAll
			// 
			this.mnuItemClearAll.Command = this.cmd_mnuItemClearAll;
			this.cmd_mnuItemClearAll.Text = "&Clear All";
			// 
			// menuItem3
			// 
			this.menuItem3.Text = "-";
			// 
			// mnuItemSelectUnder
			// 
			this.mnuItemSelectUnder.Command = this.cmd_mnuItemSelectUnder;
			this.cmd_mnuItemSelectUnder.Text = "Select all items under";
			// 
			// mnuItemClearUnder
			// 
			this.mnuItemClearUnder.Command = this.cmd_mnuItemClearUnder;
			this.cmd_mnuItemClearUnder.Text = "Clear all items under";
			// 
			// menuItem6
			// 
			this.menuItem6.Text = "-";
			// 
			// mnuItemExpandAll
			// 
			this.mnuItemExpandAll.Command = this.cmd_mnuItemExpandAll;
			this.cmd_mnuItemExpandAll.Text = "E&xpand All";
			// 
			// mnuItemCollapseAll
			// 
			this.mnuItemCollapseAll.Command = this.cmd_mnuItemCollapseAll;
			this.cmd_mnuItemCollapseAll.Text = "C&ollapse All";
			// 
			// menuItem9
			// 
			this.menuItem9.Text = "-";
			// 
			// mnuItemView
			// 
			this.mnuItemView.Command = this.sub_mnuItemView;
						this.sub_mnuItemView.CommandLinks.Add(this.mnuItemViewNormal);
			this.sub_mnuItemView.CommandLinks.Add(this.mnuItemViewSelected);
			this.sub_mnuItemView.CommandLinks.Add(this.mnuItemViewReport);
			this.sub_mnuItemView.CommandLinks.Add(this.mnuItemViewMainTree);
			this.sub_mnuItemView.Text = "View";
			// 
			// mnuItemViewNormal
			// 
			this.cmd_mnuItemViewNormal.Checked = true;
			this.mnuItemViewNormal.Command = this.cmd_mnuItemViewNormal;
			this.cmd_mnuItemViewNormal.Text = "User View";
			// 
			// mnuItemViewSelected
			// 
			this.mnuItemViewSelected.Command = this.cmd_mnuItemViewSelected;
			this.cmd_mnuItemViewSelected.Text = "Selected items only";
			// 
			// mnuItemViewReport
			// 
			this.mnuItemViewReport.Command = this.cmd_mnuItemViewReport;
			this.cmd_mnuItemViewReport.Text = "Report Type items only";
			// 
			// mnuItemViewMainTree
			// 
			this.mnuItemViewMainTree.Command = this.cmd_mnuItemViewMainTree;
			this.cmd_mnuItemViewMainTree.Text = "Same as Main Data Tree";
			// 
			// FieldSheet
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(646, 480);
			this.Controls.Add(this.buttonClearAll);
			this.Controls.Add(this.buttonSelectAll);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panelTree);
			this.Controls.Add(this.buttonPrint);
			this.Controls.Add(this.buttonCancel1);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FieldSheet";
			this.Text = "FieldSheet";
			this.panelTree.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		protected override void OnLoad(EventArgs e)
		{
			this.SuspendLayout();

			//this.SuspendLayout();
			treeViewSpecificUnits.ImageList = this.imageListTree;
			treeViewSpecificUnits.ImageIndex = 9;
			treeViewSpecificUnits.SelectedImageIndex = 9;

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadSpecificUnitsTree(this.treeViewSpecificUnits, 7);

			//SetBitmaps();
			//SetToolTips();

			treeViewSpecificUnits.ContextMenu = mnuContextMenu;

			if (mnuItemViewMainTree.Checked)
			{
				nodesExpandedResurrect = nodesExpandedMainForm;
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ResurrectExpandedNodes(node);
				}
				treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}

			//ResetDirty();

			this.ResumeLayout();
			base.OnLoad(e);
		}

		private void panelToolbar_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void SetBitmaps()
		{
			//Bitmap b = (Bitmap)pictureBoxOpen.Image;
			//b.MakeTransparent(Color.Fuchsia);
			//pictureBoxOpen.Image = b;

			//b = (Bitmap)pictureBoxSave.Image;
			//b.MakeTransparent(Color.Fuchsia);
			//pictureBoxSave.Image = b;

			//b = (Bitmap)pictureBoxHelp.Image;
			//b.MakeTransparent(Color.Fuchsia);
			//pictureBoxHelp.Image = b;
		}

		private void SetToolTips()
		{
			// Create the ToolTip and associate with the Form container.
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			//toolTip.SetToolTip(this.comboBoxReportTemplate, "Report templates");
		}

		private void LoadContextMenu()
		{
			this.mnuContextMenu.Popup += new System.EventHandler(MyPopupEventHandler);
			this.mnuItemSelectAll.Click += new System.EventHandler(mnuItemSelectAll_OnClick);
			this.mnuItemClearAll.Click += new System.EventHandler(mnuItemClearAll_OnClick);
			this.mnuItemSelectUnder.Click += new System.EventHandler(mnuItemSelectUnder_OnClick);
			this.mnuItemClearUnder.Click += new System.EventHandler(mnuItemClearUnder_OnClick);
			this.mnuItemExpandAll.Click += new System.EventHandler(mnuItemExpandAll_OnClick);
			this.mnuItemCollapseAll.Click += new System.EventHandler(mnuItemCollapseAll_OnClick);
			this.mnuItemViewNormal.Click += new System.EventHandler(mnuItemViewNormal_OnClick);
			this.mnuItemViewSelected.Click += new System.EventHandler(mnuItemViewSelected_OnClick);
			this.mnuItemViewReport.Click += new System.EventHandler(mnuItemViewReport_OnClick);
			this.mnuItemViewMainTree.Click += new System.EventHandler(mnuItemViewMainTree_OnClick);
		}

		protected void MyPopupEventHandler(System.Object sender, System.EventArgs e)
		{
			string nodeText = "";
 
			if (nodeHitTest == null)
			{
				mnuContextMenu.MenuItems[2].Visible = false;
				mnuContextMenu.MenuItems[3].Visible = false;
				mnuContextMenu.MenuItems[4].Visible = false;
			}
			else
			{
				if (nodeHitTest.Nodes.Count == 0)
				{
					mnuContextMenu.MenuItems[2].Visible = false;
					mnuContextMenu.MenuItems[3].Visible = false;
					mnuContextMenu.MenuItems[4].Visible = false;
				}
				else if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
				{
					if (nodeHitTest.Parent != null)
					{
						mnuContextMenu.MenuItems[2].Visible = true;
						mnuContextMenu.MenuItems[3].Visible = true;
						mnuContextMenu.MenuItems[4].Visible = true;

						nodeText = nodeHitTest.Parent.Text;
						if (nodeText.Length > 25)
						{
							nodeText = nodeHitTest.Parent.Text.Substring(0, 25) + "...";
						}
					
						mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
						mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
					}
				}
				else
				{
					mnuContextMenu.MenuItems[2].Visible = true;
					mnuContextMenu.MenuItems[3].Visible = true;
					mnuContextMenu.MenuItems[4].Visible = true;

					nodeText = nodeHitTest.Text;
					if (nodeText.Length > 25)
					{
						nodeText = nodeHitTest.Text.Substring(0, 25) + "...";
					}
					
					mnuContextMenu.MenuItems[3].Text = "Select all items under " + nodeText;
					mnuContextMenu.MenuItems[4].Text = "Clear all items under " + nodeText;
				}
			}
		}

		#endregion /***** Load Chores *****/

		#region /***** Tree Handling Code *****/

		private void ResurrectExpandedNodes(TreeNode node)
		{
			//			if (nodesExpanded.Contains(node.Tag))
			//				node.Expand();
			//
			//			foreach (TreeNode nodeChild in node.Nodes)
			//				ResurrectExpandedNodes(nodeChild);

			if (nodesExpandedResurrect.Contains(node.Tag))
				node.Expand();

			foreach (TreeNode nodeChild in node.Nodes)
				ResurrectExpandedNodes(nodeChild);
		}

		private void ResurrectSelectedNodes(TreeNode node)
		{
			switch (currentNodeType)
			{
//				case WAM.UI.NodeType.Facility:
//					if (SelectedFac.Contains(node.Tag))
//						node.Checked = true;
//					break;
//
//				case WAM.UI.NodeType.TreatmentProcess:
//					if (SelectedProc.Contains(node.Tag))
//					{
//						node.Checked = true;
//					}
//					if (node.Tag is TreatmentProcess)
//					{
//						//if (node.NextNode != null)
//						//	ResurrectSelectedNodes(node.NextNode);
//					}
//					else
//					{
//						foreach (TreeNode nodeChild in node.Nodes)
//							ResurrectSelectedNodes(nodeChild);
//					}
//					break;
//
//				case WAM.UI.NodeType.MajorComponent:
//					if (node.Tag is MajorComponent)
//					{
//						if (SelectedComp.Contains(node.Tag))
//						{
//							node.Checked = true;
//						}
//					}
//					else
//					{
//						foreach (TreeNode nodeChild in node.Nodes)
//							ResurrectSelectedNodes(nodeChild);
//					}
//					break;

				case WAM.UI.NodeType.DisciplineMech:
					if (node.Tag is WAM.Data.DisciplineMech)
					{
						if (SelectedDiscMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineLand:
					if (node.Tag is WAM.Data.DisciplineLand)
					{
						if (SelectedDiscLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineStruct:
					if (node.Tag is WAM.Data.DisciplineStruct)
					{
						if (SelectedDiscStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplinePipe:
					if (node.Tag is WAM.Data.DisciplinePipe)
					{
						if (SelectedDiscPipe.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.DisciplineNode:
					if (node.Tag is WAM.Data.DisciplineNode)
					{
						if (SelectedDiscNode.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.NoneSelected:

					if (node.Tag is WAM.Data.DisciplineLand)
					{
						if (SelectedDiscAllLand.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is WAM.Data.DisciplineMech)
					{
						if (SelectedDiscAllMech.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is WAM.Data.DisciplineStruct)
					{
						if (SelectedDiscAllStruct.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is WAM.Data.DisciplineNode)
					{
						if (SelectedDiscAllNode.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else if (node.Tag is WAM.Data.DisciplinePipe)
					{
						if (SelectedDiscAllPipe.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;

				case WAM.UI.NodeType.AssetList:
					if (node.Tag is WAM.Data.ComponentAsset)
					{
						if (SelectedAsset.Contains(node.Tag))
						{
							node.Checked = true;
						}
					}
					else
					{
						foreach (TreeNode nodeChild in node.Nodes)
							ResurrectSelectedNodes(nodeChild);
					}
					break;
			}
		}

		private void CheckNodes(TreeNode nodeStart, NodeTypeHandler.NodeTypeReport nodeReportType, bool checkNode, bool checkNodeStart)
		{
			//check all nodes of a certain node type under nodeStart
			if (checkNodeStart)
			{
				if (nodeStart.Tag.ToString() == "WAM.Data." + nodeReportType.ToString())
				{
					//mam - for testing only!!!
					//if (!checkNode)
					//	MessageBox.Show("Clearing " + nodeStart.Text);

					nodeStart.Checked = checkNode;
				}
			}

			foreach(TreeNode nodeChild in nodeStart.Nodes)
			{
				if (nodeReportType == NodeTypeHandler.NodeTypeReport.Discipline
					&& nodeChild.Parent.Tag.ToString() == "WAM.Data.MajorComponent")
				{
					//mam - for testing only!!!
					//if (!checkNode)
					//	MessageBox.Show("Clearing " + nodeStart.Text);

					nodeChild.Checked = checkNode;
				}
				else if (nodeChild.Tag.ToString() == "WAM.Data." + nodeReportType.ToString())
				{
					//mam - for testing only!!!
					//if (!checkNode)
					//	MessageBox.Show("Clearing " + nodeStart.Text);

					nodeChild.Checked = checkNode;
					//break;
					//if (nodeChild.Nodes.Count > 0)
					//	CheckNodes(nodeChild, nodeTypeReport, checkNode);
				}
				if (nodeChild.Nodes.Count > 0)
					CheckNodes(nodeChild, nodeReportType, checkNode, checkNodeStart);
			}
		}
		//</mam>

		private void CheckNodesAll(bool checkNode)
		{
			//mam - for testing only!!!
			//return;
			//if (!checkNode)
			//	MessageBox.Show("Clearing nodes");

			autoChecking = true;
			//ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			foreach (TreeNode node in treeViewSpecificUnits.Nodes)
			{
				if (checkNode)
					//CheckNodes(node, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, true);
					CheckNodes(node, NodeTypeHandler.NodeTypeReport.Discipline, checkNode, true);
				else
					CheckNodesAll2(node, checkNode);
			}
			autoChecking = false;
		}

		private void CheckNodesAll2(TreeNode node, bool checkNode)
		{
			node.Checked = checkNode;
			if (node.Nodes.Count > 0)
			{
				foreach (TreeNode nodeChild in node.Nodes)
				{
					CheckNodesAll2(nodeChild, checkNode);
				}

			}
		}

		//mam
		private void SelectUnder(bool checkNode)
		{
			autoChecking = true;
			//ListItem reportType = comboBoxReportType.SelectedItem as ListItem;

			if (nodeHitTest.ForeColor == System.Drawing.Color.FromArgb(33, 78, 209))
			{
				if (nodeHitTest.Parent != null)
				{
					//CheckNodes(nodeHitTest.Parent, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
					CheckNodes(nodeHitTest.Parent, NodeTypeHandler.NodeTypeReport.Discipline, checkNode, false);
				}
			}
			else
			{
				//CheckNodes(nodeHitTest, (NodeTypeHandler.NodeTypeReport)reportType.Value, checkNode, false);
				CheckNodes(nodeHitTest, NodeTypeHandler.NodeTypeReport.Discipline, checkNode, false);
			}

			autoChecking = false;
		}
		//</mam>

		//mam - moved this code from above and made changes
		private void GetSelectedTreeNodes()
		{
			printItems.Clear();

			// Print the specific selected units
			foreach (TreeNode treeNode in treeViewSpecificUnits.Nodes)
			{
				if (treeNode.Checked)
				{
					//MessageBox.Show(treeNode.FullPath.ToString());
					printItems.Add(treeNode.Tag);
				}
				if (treeNode.Nodes.Count > 0)
				{
					//GetCheckedNodes(treeNode, printItems);
					GetCheckedNodes(treeNode);
				}
			}

			RecordSelectedNodes();
		}
		//</mam>

		//private void		GetCheckedNodes(TreeNode parent, ArrayList checkedNodes)
		private void		GetCheckedNodes(TreeNode parent)
		{
			TreeNode		node;

			for (int pos = 0; pos < parent.Nodes.Count; pos++)
			{
				node = parent.Nodes[pos];

				if (node.Checked)
				{
					//MessageBox.Show(node.FullPath.ToString());
					printItems.Add(node.Tag);
				}

				if (node.Nodes.Count > 0)
				{
					GetCheckedNodes(node);
				}
			}
		}

		//mam
		private void ConfigureTree(NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			//mam for testing only!!!
			//return;
			//cancelCheck = true;

			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				treeViewSpecificUnits.CollapseAll();
			}

			NodeTypeHandler.NodeTypeReport[] sources = (NodeTypeHandler.NodeTypeReport[])Enum.GetValues(typeof(NodeTypeHandler.NodeTypeReport));
			for (int i = 0; i < sources.Length; i++)
			{
				if (nodeTypeReport == sources[i])
				{
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						if (uncheckNodes == true)
						{
							node.Checked = false;
						}
						if (node.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString())
						{
							//node.ForeColor = System.Drawing.Color.Blue;
							node.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);
							node.ImageIndex = 0;
							node.SelectedImageIndex = 0;
						}
						else
						{
							node.ForeColor = System.Drawing.SystemColors.GrayText;
							node.ImageIndex = 1;
							node.SelectedImageIndex = 1;
						}

						ConfigureChildren(node, nodeTypeReport, uncheckNodes);
					}
				}
			}
			if (!mnuItemViewNormal.Checked && !mnuItemViewMainTree.Checked)
			{
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}

			//cancelCheck = false;
		}
		//</mam>

		//mam
		private void ConfigureChildren(TreeNode node, NodeTypeHandler.NodeTypeReport nodeTypeReport, bool uncheckNodes)
		{
			TreeNode nodeParent;
			int useImageIndex = 0;
			if (uncheckNodes == true)
			{
				node.Checked = false;
			}
			foreach(TreeNode nodeChild in node.Nodes)
			{
				if (uncheckNodes == true)
				{
					nodeChild.Checked = false;
				}
				if (nodeChild.Tag.ToString() == "WAM.Data." + nodeTypeReport.ToString()
					|| nodeChild.Tag.ToString().Substring(9).StartsWith(nodeTypeReport.ToString()))
				{
					//nodeChild.ForeColor = System.Drawing.Color.Blue;
					nodeChild.ForeColor = System.Drawing.Color.FromArgb(33, 78, 209);

					switch (nodeTypeReport.ToString())
					{
						case "TreatmentProcess":
						{
							useImageIndex = 3;
							break;
						}
						case "MajorComponent":
						{
							useImageIndex = 5;
							break;
						}
						case "Discipline":
						case "DisciplineMech":
						case "DisciplineStruct":
						case "DisciplineLand":
						case "DisciplinePipe":
						case "DisciplineNode":
						{
							useImageIndex = 7;
							break;
						}
						case "ComponentAsset":
						{
							useImageIndex = 9;
							break;
						}
					}

					//nodeChild.ImageIndex = 0;
					//nodeChild.SelectedImageIndex = 0;
					nodeChild.ImageIndex = useImageIndex;
					nodeChild.SelectedImageIndex = useImageIndex;

					if (mnuItemViewReport.Checked)
					{
						//expand all parents of nodeChild so that nodeChild is visible
						nodeParent = nodeChild.Parent;
						nodeParent.Expand();
						while (nodeParent.Parent != null)
						{
							nodeParent.Parent.Expand();
							nodeParent = nodeParent.Parent;
						}
					}

				}
				else
				{
					nodeChild.ForeColor = System.Drawing.SystemColors.GrayText;
					nodeChild.ImageIndex = 1;
					nodeChild.SelectedImageIndex = 1;
				}

				//				//MessageBox.Show(nodeChild.Text);
				//				if (nodeChild.Text == "Asset List")
				//				{
				//					System.Diagnostics.Debug.WriteLine("Test");
				//					MessageBox.Show("tag = " + nodeChild.Tag.ToString());
				//					MessageBox.Show("nodeTypeReport.ToString() = " + nodeTypeReport.ToString());
				//				}
					

				ConfigureChildren(nodeChild, nodeTypeReport, uncheckNodes);
			}
		}
		//</mam>

		//mam
		private void ConfigureTreeSelectedNodes(TreeNode node)
		{
			//mam - for testing only!!!
			//return;
			//cancelCheck = true;

			TreeNode nodeExpand = node;
			if (node.Checked == true)
				while (nodeExpand.Parent != null && nodeExpand.Parent.IsExpanded == false)
				{
					nodeExpand.Parent.Expand();
					nodeExpand = nodeExpand.Parent;
				}

			foreach (TreeNode nodeChild in node.Nodes)
			{
				ConfigureTreeSelectedNodes(nodeChild);
			}

			//cancelCheck = false;
		}
		//</mam>

		private void treeViewSpecificUnits_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick == true)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
				
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
			else
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor == System.Drawing.SystemColors.GrayText)
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				else
				{
					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
			}
		}

		private void treeViewSpecificUnits_Click(object sender, System.EventArgs e)
		{
			if (treeViewSpecificUnits.SelectedNode == null)
				return;

			if (nodeHitTest != null && nodeSelected != null && nodeHitTest == nodeSelected)
			{
				if (treeViewSpecificUnits.SelectedNode.ForeColor != System.Drawing.SystemColors.GrayText)
				{
					if (checkOnClick == true)
						treeViewSpecificUnits.SelectedNode.Checked = !treeViewSpecificUnits.SelectedNode.Checked;

					//treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 0;
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = treeViewSpecificUnits.SelectedNode.ImageIndex;
				}
				else
				{
					treeViewSpecificUnits.SelectedNode.SelectedImageIndex = 1;
				}
			}
		}

		private void treeViewSpecificUnits_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
			if (treeViewSpecificUnits.SelectedNode == null)
			{
				treeViewSpecificUnits.SelectedNode = treeViewSpecificUnits.Nodes[0];
				nodeSelected = treeViewSpecificUnits.SelectedNode;
			}
		}

		private void treeViewSpecificUnits_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			nodeHitTest = treeViewSpecificUnits.GetNodeAt(e.X, e.Y);
		}

		private void treeViewSpecificUnits_AfterCollapse(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeCollapse(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			nodeHitTest = null;
		}

		private void treeViewSpecificUnits_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
		}

		private void treeViewSpecificUnits_BeforeCheck(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (nodeHitTest == null || autoChecking == true)
				return;

			//if (cancelCheck)
			//	return;

			//MessageBox.Show(nodeHitTest.Text + " = " + nodeHitTest.ForeColor.ToString());
			if (nodeHitTest.ForeColor == System.Drawing.SystemColors.GrayText)
				e.Cancel = true;
		}

		//		private void RecordTreeExpandedState(TreeNode node)
		//		{
		//			if (node.IsExpanded)
		//			{
		//				nodesExpanded.Add(node.Tag);
		//			}
		//			foreach (TreeNode childNode in node.Nodes)
		//			{
		//				RecordTreeExpandedState(childNode);
		//			}
		//		}

		private void RecordTreeExpandedState()
		{
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();

			nodesExpanded.Clear();
			//return commonTasks.RecordTreeExpandedState(treeViewFacility);
			nodesExpanded = commonTasks.RecordTreeExpandedState(treeViewSpecificUnits);
			//MessageBox.Show("nodesExpanded.Count = " + nodesExpanded.Count.ToString());

			commonTasks = null;
		}

		private void RecordSelectedNodes()
		{
			// Add the nodes in printItems[] to the various array lists

			//NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
			switch (currentNodeType)
			{
//					//case NodeTypeHandler.NodeTypeReport.Facility:
//				case NodeType.Facility:
//				{
//					SelectedFac.Clear();
//					for (int i = 0; i < printItems.Count; i++)
//					{
//						SelectedFac.Add(printItems[i]);
//					}
//					break;
//				}
//					//case NodeTypeHandler.NodeTypeReport.TreatmentProcess:
//				case NodeType.TreatmentProcess:
//				{
//					SelectedProc.Clear();
//					for (int i = 0; i < printItems.Count; i++)
//					{
//						//SelectedProc.Add(((TreatmentProcess)printItems[i]).ID);
//						SelectedProc.Add(printItems[i]);
//					}
//					break;
//				}
//					//case NodeTypeHandler.NodeTypeReport.MajorComponent:
//				case NodeType.MajorComponent:
//				{
//					SelectedComp.Clear();
//					for (int i = 0; i < printItems.Count; i++)
//					{
//						//SelectedComp.Add(((MajorComponent)printItems[i]).ID);
//						SelectedComp.Add(printItems[i]);
//					}
//					break;
//				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineMech:
				case NodeType.DisciplineMech:
				{
					SelectedDiscMech.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscMech.Add(((DisciplineMech)printItems[i]).ID);
						SelectedDiscMech.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineLand:
				case NodeType.DisciplineLand:
				{
					SelectedDiscLand.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscLand.Add(((DisciplineLand)printItems[i]).ID);
						SelectedDiscLand.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineStruct:
				case NodeType.DisciplineStruct:
				{
					SelectedDiscStruct.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscStruct.Add(((DisciplineStruct)printItems[i]).ID);
						SelectedDiscStruct.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplinePipe:
				case NodeType.DisciplinePipe:
				{
					SelectedDiscPipe.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscPipe.Add(((DisciplinePipe)printItems[i]).ID);
						SelectedDiscPipe.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.DisciplineNode:
				case NodeType.DisciplineNode:
				{
					SelectedDiscNode.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscNode.Add(((DisciplineNode)printItems[i]).ID);
						SelectedDiscNode.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.Discipline:
				case NodeType.NoneSelected:
				{
					SelectedDiscAllLand.Clear();
					SelectedDiscAllMech.Clear();
					SelectedDiscAllStruct.Clear();
					SelectedDiscAllNode.Clear();
					SelectedDiscAllPipe.Clear();

					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedDiscAll.Add(printItems[i]);
						if (printItems[i] is WAM.Data.DisciplineLand)
							SelectedDiscAllLand.Add(printItems[i]);
						else if (printItems[i] is WAM.Data.DisciplineMech)
							SelectedDiscAllMech.Add(printItems[i]);
						else if (printItems[i] is WAM.Data.DisciplineStruct)
							SelectedDiscAllStruct.Add(printItems[i]);
						else if (printItems[i] is WAM.Data.DisciplineNode)
							SelectedDiscAllNode.Add(printItems[i]);
						else if (printItems[i] is WAM.Data.DisciplinePipe)
							SelectedDiscAllPipe.Add(printItems[i]);
					}
					break;
				}
					//case NodeTypeHandler.NodeTypeReport.ComponentAsset:
				case NodeType.AssetList:
				{
					SelectedAsset.Clear();
					for (int i = 0; i < printItems.Count; i++)
					{
						//SelectedAsset.Add(((ComponentAsset)printItems[i]).ID);
						SelectedAsset.Add(printItems[i]);
					}
					break;
				}
			}

		}

		#endregion /***** Tree Handling Code *****/

		#region /***** Click Events *****/

		protected void mnuItemSelectAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(true);
		}

		protected void mnuItemClearAll_OnClick(System.Object sender, System.EventArgs e)
		{
			CheckNodesAll(false);
		}

		protected void mnuItemExpandAll_OnClick(System.Object sender, System.EventArgs e)
		{
			treeViewSpecificUnits.ExpandAll();
		}

		protected void mnuItemCollapseAll_OnClick(System.Object sender, System.EventArgs e)
		{
			treeViewSpecificUnits.CollapseAll();
		}

		protected void mnuItemSelectUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(true);
		}

		protected void mnuItemClearUnder_OnClick(System.Object sender, System.EventArgs e)
		{
			SelectUnder(false);
		}

		protected void mnuItemView_OnClick(System.Object sender, System.EventArgs e)
		{
			//			MessageBox.Show("View click");
		}

		protected void mnuItemViewNormal_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
			try
			{
				if (!mnuItemViewNormal.Checked)
				{
					ResetViewItems();
					mnuItemViewNormal.Checked = true;
					SaveView();
					nodesExpandedResurrect = nodesExpanded;
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ResurrectExpandedNodes(node);
					}
				}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewSelected_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					//					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					//					{
					//						RecordTreeExpandedState(node);
					//					}
				}

				ResetViewItems();
				mnuItemViewSelected.Checked = true;
				SaveView();
				treeViewSpecificUnits.CollapseAll();
				foreach (TreeNode node in treeViewSpecificUnits.Nodes)
				{
					ConfigureTreeSelectedNodes(node);
				}
				if (treeViewSpecificUnits.Nodes.Count > 0)
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewReport_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
					//					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					//					{
					//						RecordTreeExpandedState(node);
					//					}
				}

				ResetViewItems();
				mnuItemViewReport.Checked = true;
				SaveView();
				
				//NodeTypeHandler.NodeTypeReport nodeTypeReport = (NodeTypeHandler.NodeTypeReport)((ListItem)comboBoxReportType.SelectedItem).Value;
				NodeTypeHandler.NodeTypeReport nodeTypeReport = NodeTypeHandler.NodeTypeReport.Discipline;
				
				ConfigureTree(nodeTypeReport, false);
				//PopulateApplyToCombo(nodeTypeReport);
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		protected void mnuItemViewMainTree_OnClick(System.Object sender, System.EventArgs e)
		{
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				if (mnuItemViewNormal.Checked)
				{
					nodesExpanded.Clear();
					RecordTreeExpandedState();
				}

				if (!mnuItemViewMainTree.Checked)
				{
					ResetViewItems();
					mnuItemViewMainTree.Checked = true;
					SaveView();
					nodesExpandedResurrect = nodesExpandedMainForm;
					treeViewSpecificUnits.CollapseAll();
					foreach (TreeNode node in treeViewSpecificUnits.Nodes)
					{
						ResurrectExpandedNodes(node);
					}
					treeViewSpecificUnits.Nodes[0].EnsureVisible();
				}
			}
			finally
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
		}

		private void buttonSelectAll_Click(object sender, System.EventArgs e)
		{
			mnuItemSelectAll_OnClick(sender, e);
		}

		private void buttonClearAll_Click(object sender, System.EventArgs e)
		{
			mnuItemClearAll_OnClick(sender, e);
		}

		#endregion /***** Click Events *****/

		#region /***** Methods *****/

		private void ResetViewItems()
		{
			mnuItemViewNormal.Checked = false;
			mnuItemViewSelected.Checked = false;
			mnuItemViewReport.Checked = false;
			mnuItemViewMainTree.Checked = false;
		}

		private int GetCurrentView()
		{
			if (mnuItemViewNormal.Checked)
				return 0;

			if (mnuItemViewSelected.Checked)
				return 1;

			if (mnuItemViewReport.Checked)
				return 2;

			if (mnuItemViewMainTree.Checked)
				return 3;

			return 0;
		}

		private void SetCurrentView(int curView)
		{
			ResetViewItems();

			switch (curView)
			{
				case 0:
					mnuItemViewNormal.Checked = true;
					break;
				case 1:
					mnuItemViewSelected.Checked = true;
					break;
				case 2:
					mnuItemViewReport.Checked = true;
					break;
				case 3:
					mnuItemViewMainTree.Checked = true;
					break;
				default:
					mnuItemViewNormal.Checked = true;
					break;
			}
		}

		protected bool SaveView()
		{
			//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			////return dataAccess.ExecuteCommand("UPDATE ReportTemplate SET UserView = " + (int)GetCurrentView());
			//return(dataAccess.ExecuteCommand(@"UPDATE Preference SET PreferenceValue = " + (int)GetCurrentView() 
			//	+ " WHERE PreferenceType = 'ReportTemplate' AND PreferenceText = 'UserView'"));
			//dataAccess = null;

			try
			{
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "ReportTemplateView", GetCurrentView().ToString());
			}
			catch
			{
				return false;
			}
			return true;
		}

		private bool SavePreferences(int autoSave)
		{
			return true;
		}

		#endregion /***** Methods *****/
	}
}
