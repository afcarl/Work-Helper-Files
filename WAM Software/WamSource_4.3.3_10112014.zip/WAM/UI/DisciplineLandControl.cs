using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using WAM.Data;
using Drive.Collections;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for DisciplineLandControl.
	/// </summary>
	public class DisciplineLandControl : System.Windows.Forms.UserControl
	{
		private DisciplineLand m_discipline = null;
		private Drive.Windows.Forms.DataChangeMonitor
							m_dataMonitor = null;
		private bool		m_suppressUpdate = false;

		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPageComponentInfo;
		private System.Windows.Forms.TextBox textBoxComments;
		private System.Windows.Forms.Label labelComments;
		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBoxDisciplineName;
		private WAM.UI.ItemStatusControl itemStatusSeveralPotholes;
		private WAM.UI.ItemStatusControl itemStatusExcessiveErosion;
		private WAM.UI.ItemStatusControl itemStatusSevereRoadDegradation;
		private WAM.UI.ItemStatusControl itemStatusSpaceForExpansion;
		private WAM.UI.ItemStatusControl itemStatusFunctionalGroundCover;
		private WAM.UI.ItemStatusControl itemStatusFencingAdequate;
		private WAM.UI.ItemStatusControl itemStatusFacilitiesSecure;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TextBox textBoxPhotoCaption1;
		private WAM.UI.PhotoControl photoControl1;
		private WAM.UI.PhotoControl photoControl2;
		private System.Windows.Forms.TextBox textBoxPhotoCaption2;
		private WAM.UI.PhotoControl photoControl3;
		private System.Windows.Forms.TextBox textBoxPhotoCaption3;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private System.Windows.Forms.Button buttonPhotoBrowse1;
		private System.Windows.Forms.Button buttonPhotoBrowse2;
		private System.Windows.Forms.Button buttonPhotoBrowse3;
		private System.Windows.Forms.CheckBox checkBoxOverrideAcquisitionCost;
		private System.Windows.Forms.Label label17;
		private WAM.UI.DollarTextBox textBoxReplacementValue;
		private System.Windows.Forms.ComboBox comboBoxConditionRanking;
		private System.Windows.Forms.Label label5;
		private WAM.UI.DollarTextBox textBoxAcquisitionCost;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.TextBox textBoxInstallYear;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxEvaluatedRemainingUL;
		private System.Windows.Forms.TextBox textBoxRemainingUL;
		private System.Windows.Forms.TextBox textBoxOriginalUL;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBoxRepairCostCurVal;
		private System.Windows.Forms.TextBox textBoxOrgCostCurVal;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBoxAssessedBy;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBoxBookValue;
		private System.Windows.Forms.Label label19;
		private C1.Win.C1Input.C1DateEdit dateInspect;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox textBoxEquipmentNumber;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox textBoxManufacturer;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBoxAnnualDepreciation;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox textBoxEvaluatedValue;
		private System.Windows.Forms.TextBox textBoxCumulativeDepreciation;
		private System.Windows.Forms.Label label22;
		private WAM.UI.NumberTextBox textBoxOriginalENR;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private WAM.UI.DollarTextBox textBoxSalvageValue;
		private WAM.UI.DollarTextBox textBoxAnnualMaintenanceCost;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox textBoxCurrentENR;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.TextBox textBoxLOS;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DisciplineLandControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.textBoxCumulativeDepreciation = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.checkBoxOverrideAcquisitionCost = new System.Windows.Forms.CheckBox();
			this.textBoxReplacementValue = new WAM.UI.DollarTextBox();
			this.comboBoxConditionRanking = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxAcquisitionCost = new WAM.UI.DollarTextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.textBoxInstallYear = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxEvaluatedRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxRemainingUL = new System.Windows.Forms.TextBox();
			this.textBoxOriginalUL = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxRepairCostCurVal = new System.Windows.Forms.TextBox();
			this.textBoxOrgCostCurVal = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBoxAssessedBy = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.textBoxBookValue = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.dateInspect = new C1.Win.C1Input.C1DateEdit();
			this.label11 = new System.Windows.Forms.Label();
			this.textBoxEquipmentNumber = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.textBoxManufacturer = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.textBoxAnnualDepreciation = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.textBoxOriginalENR = new WAM.UI.NumberTextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.textBoxSalvageValue = new WAM.UI.DollarTextBox();
			this.textBoxAnnualMaintenanceCost = new WAM.UI.DollarTextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.textBoxEvaluatedValue = new System.Windows.Forms.TextBox();
			this.tabPageComponentInfo = new System.Windows.Forms.TabPage();
			this.itemStatusSeveralPotholes = new WAM.UI.ItemStatusControl();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.labelComments = new System.Windows.Forms.Label();
			this.itemStatusExcessiveErosion = new WAM.UI.ItemStatusControl();
			this.itemStatusSevereRoadDegradation = new WAM.UI.ItemStatusControl();
			this.itemStatusSpaceForExpansion = new WAM.UI.ItemStatusControl();
			this.itemStatusFunctionalGroundCover = new WAM.UI.ItemStatusControl();
			this.itemStatusFencingAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusFacilitiesSecure = new WAM.UI.ItemStatusControl();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.buttonPhotoBrowse1 = new System.Windows.Forms.Button();
			this.photoControl1 = new WAM.UI.PhotoControl();
			this.textBoxPhotoCaption3 = new System.Windows.Forms.TextBox();
			this.photoControl3 = new WAM.UI.PhotoControl();
			this.textBoxPhotoCaption1 = new System.Windows.Forms.TextBox();
			this.textBoxPhotoCaption2 = new System.Windows.Forms.TextBox();
			this.photoControl2 = new WAM.UI.PhotoControl();
			this.buttonPhotoBrowse2 = new System.Windows.Forms.Button();
			this.buttonPhotoBrowse3 = new System.Windows.Forms.Button();
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxDisciplineName = new System.Windows.Forms.TextBox();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.textBoxCurrentENR = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.textBoxLOS = new System.Windows.Forms.TextBox();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).BeginInit();
			this.tabPageComponentInfo.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageComponentInfo);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.tabControl.Size = new System.Drawing.Size(680, 360);
			this.tabControl.TabIndex = 8;
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.label28);
			this.tabPageMain.Controls.Add(this.textBoxLOS);
			this.tabPageMain.Controls.Add(this.textBoxCumulativeDepreciation);
			this.tabPageMain.Controls.Add(this.label17);
			this.tabPageMain.Controls.Add(this.checkBoxOverrideAcquisitionCost);
			this.tabPageMain.Controls.Add(this.textBoxReplacementValue);
			this.tabPageMain.Controls.Add(this.comboBoxConditionRanking);
			this.tabPageMain.Controls.Add(this.label5);
			this.tabPageMain.Controls.Add(this.textBoxAcquisitionCost);
			this.tabPageMain.Controls.Add(this.label18);
			this.tabPageMain.Controls.Add(this.textBoxInstallYear);
			this.tabPageMain.Controls.Add(this.label16);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxRemainingUL);
			this.tabPageMain.Controls.Add(this.textBoxOriginalUL);
			this.tabPageMain.Controls.Add(this.label8);
			this.tabPageMain.Controls.Add(this.label9);
			this.tabPageMain.Controls.Add(this.label10);
			this.tabPageMain.Controls.Add(this.label7);
			this.tabPageMain.Controls.Add(this.textBoxRepairCostCurVal);
			this.tabPageMain.Controls.Add(this.textBoxOrgCostCurVal);
			this.tabPageMain.Controls.Add(this.label6);
			this.tabPageMain.Controls.Add(this.textBoxAssessedBy);
			this.tabPageMain.Controls.Add(this.label12);
			this.tabPageMain.Controls.Add(this.textBoxBookValue);
			this.tabPageMain.Controls.Add(this.label19);
			this.tabPageMain.Controls.Add(this.dateInspect);
			this.tabPageMain.Controls.Add(this.label11);
			this.tabPageMain.Controls.Add(this.textBoxEquipmentNumber);
			this.tabPageMain.Controls.Add(this.label13);
			this.tabPageMain.Controls.Add(this.textBoxManufacturer);
			this.tabPageMain.Controls.Add(this.label14);
			this.tabPageMain.Controls.Add(this.textBoxAnnualDepreciation);
			this.tabPageMain.Controls.Add(this.label20);
			this.tabPageMain.Controls.Add(this.label21);
			this.tabPageMain.Controls.Add(this.label22);
			this.tabPageMain.Controls.Add(this.textBoxOriginalENR);
			this.tabPageMain.Controls.Add(this.label23);
			this.tabPageMain.Controls.Add(this.label24);
			this.tabPageMain.Controls.Add(this.textBoxSalvageValue);
			this.tabPageMain.Controls.Add(this.textBoxAnnualMaintenanceCost);
			this.tabPageMain.Controls.Add(this.label25);
			this.tabPageMain.Controls.Add(this.textBoxEvaluatedValue);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.tabPageMain.Size = new System.Drawing.Size(672, 334);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// textBoxCumulativeDepreciation
			// 
			this.textBoxCumulativeDepreciation.Location = new System.Drawing.Point(488, 104);
			this.textBoxCumulativeDepreciation.Name = "textBoxCumulativeDepreciation";
			this.textBoxCumulativeDepreciation.ReadOnly = true;
			this.textBoxCumulativeDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxCumulativeDepreciation.TabIndex = 30;
			this.textBoxCumulativeDepreciation.Text = "";
			this.textBoxCumulativeDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(36, 34);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(108, 16);
			this.label17.TabIndex = 2;
			this.label17.Text = "&Replacement Value:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxOverrideAcquisitionCost
			// 
			this.checkBoxOverrideAcquisitionCost.Location = new System.Drawing.Point(220, 10);
			this.checkBoxOverrideAcquisitionCost.Name = "checkBoxOverrideAcquisitionCost";
			this.checkBoxOverrideAcquisitionCost.Size = new System.Drawing.Size(272, 16);
			this.checkBoxOverrideAcquisitionCost.TabIndex = 22;
			this.checkBoxOverrideAcquisitionCost.Text = "Override calculated acquisition cost";
			this.checkBoxOverrideAcquisitionCost.CheckedChanged += new System.EventHandler(this.checkBoxOverrideAcquisitionCost_CheckedChanged);
			// 
			// textBoxReplacementValue
			// 
			this.textBoxReplacementValue.Location = new System.Drawing.Point(144, 32);
			this.textBoxReplacementValue.MaxLength = 30;
			this.textBoxReplacementValue.Name = "textBoxReplacementValue";
			this.textBoxReplacementValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxReplacementValue.TabIndex = 3;
			this.textBoxReplacementValue.Text = "$0";
			this.textBoxReplacementValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxReplacementValue.Value = new System.Decimal(new int[] {
																				  0,
																				  0,
																				  0,
																				  0});
			this.textBoxReplacementValue.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// comboBoxConditionRanking
			// 
			this.comboBoxConditionRanking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxConditionRanking.Location = new System.Drawing.Point(144, 200);
			this.comboBoxConditionRanking.Name = "comboBoxConditionRanking";
			this.comboBoxConditionRanking.Size = new System.Drawing.Size(164, 21);
			this.comboBoxConditionRanking.TabIndex = 15;
			this.comboBoxConditionRanking.SelectedIndexChanged += new System.EventHandler(this.comboBoxConditionRanking_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(40, 202);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 14;
			this.label5.Text = "&Condition Ranking:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAcquisitionCost
			// 
			this.textBoxAcquisitionCost.Location = new System.Drawing.Point(144, 8);
			this.textBoxAcquisitionCost.MaxLength = 30;
			this.textBoxAcquisitionCost.Name = "textBoxAcquisitionCost";
			this.textBoxAcquisitionCost.ReadOnly = true;
			this.textBoxAcquisitionCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxAcquisitionCost.TabIndex = 1;
			this.textBoxAcquisitionCost.Text = "$0";
			this.textBoxAcquisitionCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAcquisitionCost.Value = new System.Decimal(new int[] {
																				 0,
																				 0,
																				 0,
																				 0});
			this.textBoxAcquisitionCost.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(36, 10);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(108, 16);
			this.label18.TabIndex = 0;
			this.label18.Text = "&Acquisition Cost:";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInstallYear
			// 
			this.textBoxInstallYear.Location = new System.Drawing.Point(144, 104);
			this.textBoxInstallYear.MaxLength = 4;
			this.textBoxInstallYear.Name = "textBoxInstallYear";
			this.textBoxInstallYear.Size = new System.Drawing.Size(72, 20);
			this.textBoxInstallYear.TabIndex = 9;
			this.textBoxInstallYear.Text = "";
			this.textBoxInstallYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxInstallYear.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(48, 106);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(96, 16);
			this.label16.TabIndex = 8;
			this.label16.Text = "Installation &Year:";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEvaluatedRemainingUL
			// 
			this.textBoxEvaluatedRemainingUL.Location = new System.Drawing.Point(488, 200);
			this.textBoxEvaluatedRemainingUL.Name = "textBoxEvaluatedRemainingUL";
			this.textBoxEvaluatedRemainingUL.ReadOnly = true;
			this.textBoxEvaluatedRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedRemainingUL.TabIndex = 38;
			this.textBoxEvaluatedRemainingUL.Text = "";
			this.textBoxEvaluatedRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxRemainingUL
			// 
			this.textBoxRemainingUL.Location = new System.Drawing.Point(488, 176);
			this.textBoxRemainingUL.Name = "textBoxRemainingUL";
			this.textBoxRemainingUL.ReadOnly = true;
			this.textBoxRemainingUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxRemainingUL.TabIndex = 36;
			this.textBoxRemainingUL.Text = "";
			this.textBoxRemainingUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOriginalUL
			// 
			this.textBoxOriginalUL.Location = new System.Drawing.Point(144, 152);
			this.textBoxOriginalUL.MaxLength = 4;
			this.textBoxOriginalUL.Name = "textBoxOriginalUL";
			this.textBoxOriginalUL.Size = new System.Drawing.Size(72, 20);
			this.textBoxOriginalUL.TabIndex = 13;
			this.textBoxOriginalUL.Text = "";
			this.textBoxOriginalUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxOriginalUL.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(40, 154);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(104, 16);
			this.label8.TabIndex = 12;
			this.label8.Text = "Original Useful &Life:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(368, 178);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(120, 16);
			this.label9.TabIndex = 35;
			this.label9.Text = "Remaining Useful Life:";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(312, 202);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(176, 16);
			this.label10.TabIndex = 37;
			this.label10.Text = "Evaluated Remaining Useful Life:";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(416, 154);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 16);
			this.label7.TabIndex = 33;
			this.label7.Text = "Repair Cost:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRepairCostCurVal
			// 
			this.textBoxRepairCostCurVal.Location = new System.Drawing.Point(488, 152);
			this.textBoxRepairCostCurVal.Name = "textBoxRepairCostCurVal";
			this.textBoxRepairCostCurVal.ReadOnly = true;
			this.textBoxRepairCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxRepairCostCurVal.TabIndex = 34;
			this.textBoxRepairCostCurVal.Text = "";
			this.textBoxRepairCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxOrgCostCurVal
			// 
			this.textBoxOrgCostCurVal.Location = new System.Drawing.Point(488, 32);
			this.textBoxOrgCostCurVal.Name = "textBoxOrgCostCurVal";
			this.textBoxOrgCostCurVal.ReadOnly = true;
			this.textBoxOrgCostCurVal.Size = new System.Drawing.Size(72, 20);
			this.textBoxOrgCostCurVal.TabIndex = 24;
			this.textBoxOrgCostCurVal.Text = "";
			this.textBoxOrgCostCurVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(408, 34);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(80, 16);
			this.label6.TabIndex = 23;
			this.label6.Text = "Current Value:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAssessedBy
			// 
			this.textBoxAssessedBy.Location = new System.Drawing.Point(488, 224);
			this.textBoxAssessedBy.Name = "textBoxAssessedBy";
			this.textBoxAssessedBy.Size = new System.Drawing.Size(104, 20);
			this.textBoxAssessedBy.TabIndex = 40;
			this.textBoxAssessedBy.Text = "";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(392, 226);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(96, 16);
			this.label12.TabIndex = 39;
			this.label12.Text = "Assessed &By:";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxBookValue
			// 
			this.textBoxBookValue.Location = new System.Drawing.Point(488, 56);
			this.textBoxBookValue.Name = "textBoxBookValue";
			this.textBoxBookValue.ReadOnly = true;
			this.textBoxBookValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxBookValue.TabIndex = 26;
			this.textBoxBookValue.Text = "";
			this.textBoxBookValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(408, 58);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(80, 16);
			this.label19.TabIndex = 25;
			this.label19.Text = "Book Value:";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// dateInspect
			// 
			this.dateInspect.AllowDbNull = false;
			this.dateInspect.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate;
			this.dateInspect.Location = new System.Drawing.Point(144, 224);
			this.dateInspect.Name = "dateInspect";
			this.dateInspect.Size = new System.Drawing.Size(104, 20);
			this.dateInspect.TabIndex = 17;
			this.dateInspect.Tag = null;
			this.dateInspect.Value = new System.DateTime(2003, 7, 31, 0, 0, 0, 0);
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(44, 226);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(100, 16);
			this.label11.TabIndex = 16;
			this.label11.Text = "&Date of Inspection:";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEquipmentNumber
			// 
			this.textBoxEquipmentNumber.Location = new System.Drawing.Point(144, 248);
			this.textBoxEquipmentNumber.MaxLength = 255;
			this.textBoxEquipmentNumber.Name = "textBoxEquipmentNumber";
			this.textBoxEquipmentNumber.Size = new System.Drawing.Size(136, 20);
			this.textBoxEquipmentNumber.TabIndex = 19;
			this.textBoxEquipmentNumber.Text = "";
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(36, 250);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(108, 16);
			this.label13.TabIndex = 18;
			this.label13.Text = "ID Num&ber:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxManufacturer
			// 
			this.textBoxManufacturer.Location = new System.Drawing.Point(144, 272);
			this.textBoxManufacturer.MaxLength = 255;
			this.textBoxManufacturer.Name = "textBoxManufacturer";
			this.textBoxManufacturer.Size = new System.Drawing.Size(216, 20);
			this.textBoxManufacturer.TabIndex = 21;
			this.textBoxManufacturer.Text = "";
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(68, 274);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(76, 16);
			this.label14.TabIndex = 20;
			this.label14.Text = "Manu&facturer:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxAnnualDepreciation
			// 
			this.textBoxAnnualDepreciation.Location = new System.Drawing.Point(488, 80);
			this.textBoxAnnualDepreciation.Name = "textBoxAnnualDepreciation";
			this.textBoxAnnualDepreciation.ReadOnly = true;
			this.textBoxAnnualDepreciation.Size = new System.Drawing.Size(72, 20);
			this.textBoxAnnualDepreciation.TabIndex = 28;
			this.textBoxAnnualDepreciation.Text = "";
			this.textBoxAnnualDepreciation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(376, 82);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(112, 16);
			this.label20.TabIndex = 27;
			this.label20.Text = "Annual Depreciation:";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(384, 130);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(104, 16);
			this.label21.TabIndex = 31;
			this.label21.Text = "Evaluated Value:";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(352, 106);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(136, 16);
			this.label22.TabIndex = 29;
			this.label22.Text = "Cumulative Depreciation:";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxOriginalENR
			// 
			this.textBoxOriginalENR.Location = new System.Drawing.Point(144, 128);
			this.textBoxOriginalENR.MaxLength = 4;
			this.textBoxOriginalENR.Name = "textBoxOriginalENR";
			this.textBoxOriginalENR.Size = new System.Drawing.Size(72, 20);
			this.textBoxOriginalENR.TabIndex = 11;
			this.textBoxOriginalENR.Text = "0";
			this.textBoxOriginalENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxOriginalENR.Value = ((long)(0));
			this.textBoxOriginalENR.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(40, 130);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(104, 16);
			this.label23.TabIndex = 10;
			this.label23.Text = "Original &ENR:";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(36, 58);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(108, 16);
			this.label24.TabIndex = 4;
			this.label24.Text = "&Salvage Value:";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxSalvageValue
			// 
			this.textBoxSalvageValue.Location = new System.Drawing.Point(144, 56);
			this.textBoxSalvageValue.MaxLength = 30;
			this.textBoxSalvageValue.Name = "textBoxSalvageValue";
			this.textBoxSalvageValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxSalvageValue.TabIndex = 5;
			this.textBoxSalvageValue.Text = "$0";
			this.textBoxSalvageValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxSalvageValue.Value = new System.Decimal(new int[] {
																			  0,
																			  0,
																			  0,
																			  0});
			this.textBoxSalvageValue.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// textBoxAnnualMaintenanceCost
			// 
			this.textBoxAnnualMaintenanceCost.Location = new System.Drawing.Point(144, 80);
			this.textBoxAnnualMaintenanceCost.MaxLength = 30;
			this.textBoxAnnualMaintenanceCost.Name = "textBoxAnnualMaintenanceCost";
			this.textBoxAnnualMaintenanceCost.Size = new System.Drawing.Size(72, 20);
			this.textBoxAnnualMaintenanceCost.TabIndex = 7;
			this.textBoxAnnualMaintenanceCost.Text = "$0";
			this.textBoxAnnualMaintenanceCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAnnualMaintenanceCost.Value = new System.Decimal(new int[] {
																					   0,
																					   0,
																					   0,
																					   0});
			this.textBoxAnnualMaintenanceCost.Leave += new System.EventHandler(this.OnDependentCalcField_Leave);
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(4, 82);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(140, 16);
			this.label25.TabIndex = 6;
			this.label25.Text = "Annual &Maintenance Cost:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxEvaluatedValue
			// 
			this.textBoxEvaluatedValue.Location = new System.Drawing.Point(488, 128);
			this.textBoxEvaluatedValue.Name = "textBoxEvaluatedValue";
			this.textBoxEvaluatedValue.ReadOnly = true;
			this.textBoxEvaluatedValue.Size = new System.Drawing.Size(72, 20);
			this.textBoxEvaluatedValue.TabIndex = 32;
			this.textBoxEvaluatedValue.Text = "";
			this.textBoxEvaluatedValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tabPageComponentInfo
			// 
			this.tabPageComponentInfo.Controls.Add(this.itemStatusSeveralPotholes);
			this.tabPageComponentInfo.Controls.Add(this.textBoxComments);
			this.tabPageComponentInfo.Controls.Add(this.labelComments);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusExcessiveErosion);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusSevereRoadDegradation);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusSpaceForExpansion);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusFunctionalGroundCover);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusFencingAdequate);
			this.tabPageComponentInfo.Controls.Add(this.itemStatusFacilitiesSecure);
			this.tabPageComponentInfo.Location = new System.Drawing.Point(4, 22);
			this.tabPageComponentInfo.Name = "tabPageComponentInfo";
			this.tabPageComponentInfo.Size = new System.Drawing.Size(672, 334);
			this.tabPageComponentInfo.TabIndex = 1;
			this.tabPageComponentInfo.Text = "Component Information";
			this.tabPageComponentInfo.Visible = false;
			// 
			// itemStatusSeveralPotholes
			// 
			this.itemStatusSeveralPotholes.Caption = "Several potholes?";
			this.itemStatusSeveralPotholes.Location = new System.Drawing.Point(8, 8);
			this.itemStatusSeveralPotholes.Name = "itemStatusSeveralPotholes";
			this.itemStatusSeveralPotholes.Size = new System.Drawing.Size(316, 16);
			this.itemStatusSeveralPotholes.Status = WAM.Data.ItemStatus.No;
			this.itemStatusSeveralPotholes.TabIndex = 6;
			// 
			// textBoxComments
			// 
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 164);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(664, 168);
			this.textBoxComments.TabIndex = 5;
			this.textBoxComments.Text = "";
			// 
			// labelComments
			// 
			this.labelComments.Location = new System.Drawing.Point(4, 148);
			this.labelComments.Name = "labelComments";
			this.labelComments.Size = new System.Drawing.Size(100, 16);
			this.labelComments.TabIndex = 4;
			this.labelComments.Text = "&Comments:";
			// 
			// itemStatusExcessiveErosion
			// 
			this.itemStatusExcessiveErosion.Caption = "Excessive erosion?";
			this.itemStatusExcessiveErosion.Location = new System.Drawing.Point(8, 28);
			this.itemStatusExcessiveErosion.Name = "itemStatusExcessiveErosion";
			this.itemStatusExcessiveErosion.Size = new System.Drawing.Size(316, 16);
			this.itemStatusExcessiveErosion.Status = WAM.Data.ItemStatus.No;
			this.itemStatusExcessiveErosion.TabIndex = 6;
			// 
			// itemStatusSevereRoadDegradation
			// 
			this.itemStatusSevereRoadDegradation.Caption = "Severe road degradation evident?";
			this.itemStatusSevereRoadDegradation.Location = new System.Drawing.Point(8, 48);
			this.itemStatusSevereRoadDegradation.Name = "itemStatusSevereRoadDegradation";
			this.itemStatusSevereRoadDegradation.Size = new System.Drawing.Size(316, 16);
			this.itemStatusSevereRoadDegradation.Status = WAM.Data.ItemStatus.No;
			this.itemStatusSevereRoadDegradation.TabIndex = 6;
			// 
			// itemStatusSpaceForExpansion
			// 
			this.itemStatusSpaceForExpansion.Caption = "Space for expansion?";
			this.itemStatusSpaceForExpansion.Location = new System.Drawing.Point(8, 68);
			this.itemStatusSpaceForExpansion.Name = "itemStatusSpaceForExpansion";
			this.itemStatusSpaceForExpansion.Size = new System.Drawing.Size(316, 16);
			this.itemStatusSpaceForExpansion.Status = WAM.Data.ItemStatus.No;
			this.itemStatusSpaceForExpansion.TabIndex = 6;
			// 
			// itemStatusFunctionalGroundCover
			// 
			this.itemStatusFunctionalGroundCover.Caption = "Functional ground cover?";
			this.itemStatusFunctionalGroundCover.Location = new System.Drawing.Point(8, 88);
			this.itemStatusFunctionalGroundCover.Name = "itemStatusFunctionalGroundCover";
			this.itemStatusFunctionalGroundCover.Size = new System.Drawing.Size(316, 16);
			this.itemStatusFunctionalGroundCover.Status = WAM.Data.ItemStatus.No;
			this.itemStatusFunctionalGroundCover.TabIndex = 6;
			// 
			// itemStatusFencingAdequate
			// 
			this.itemStatusFencingAdequate.Caption = "Fencing adequate and well maintained?";
			this.itemStatusFencingAdequate.Location = new System.Drawing.Point(8, 108);
			this.itemStatusFencingAdequate.Name = "itemStatusFencingAdequate";
			this.itemStatusFencingAdequate.Size = new System.Drawing.Size(316, 16);
			this.itemStatusFencingAdequate.Status = WAM.Data.ItemStatus.No;
			this.itemStatusFencingAdequate.TabIndex = 6;
			// 
			// itemStatusFacilitiesSecure
			// 
			this.itemStatusFacilitiesSecure.Caption = "Facilities adequately secured?";
			this.itemStatusFacilitiesSecure.Location = new System.Drawing.Point(8, 128);
			this.itemStatusFacilitiesSecure.Name = "itemStatusFacilitiesSecure";
			this.itemStatusFacilitiesSecure.Size = new System.Drawing.Size(316, 16);
			this.itemStatusFacilitiesSecure.Status = WAM.Data.ItemStatus.No;
			this.itemStatusFacilitiesSecure.TabIndex = 6;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.buttonPhotoBrowse1);
			this.tabPagePhoto.Controls.Add(this.photoControl1);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption3);
			this.tabPagePhoto.Controls.Add(this.photoControl3);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption1);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption2);
			this.tabPagePhoto.Controls.Add(this.photoControl2);
			this.tabPagePhoto.Controls.Add(this.buttonPhotoBrowse2);
			this.tabPagePhoto.Controls.Add(this.buttonPhotoBrowse3);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.tabPagePhoto.Size = new System.Drawing.Size(672, 334);
			this.tabPagePhoto.TabIndex = 2;
			this.tabPagePhoto.Text = "Photos";
			this.tabPagePhoto.Resize += new System.EventHandler(this.tabPagePhoto_Resize);
			// 
			// buttonPhotoBrowse1
			// 
			this.buttonPhotoBrowse1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonPhotoBrowse1.Location = new System.Drawing.Point(75, 304);
			this.buttonPhotoBrowse1.Name = "buttonPhotoBrowse1";
			this.buttonPhotoBrowse1.TabIndex = 14;
			this.buttonPhotoBrowse1.Text = "Browse";
			this.buttonPhotoBrowse1.Click += new System.EventHandler(this.buttonPhotoBrowse1_Click);
			// 
			// photoControl1
			// 
			this.photoControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.photoControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.photoControl1.Image = null;
			this.photoControl1.Location = new System.Drawing.Point(4, 4);
			this.photoControl1.Name = "photoControl1";
			this.photoControl1.Size = new System.Drawing.Size(216, 272);
			this.photoControl1.TabIndex = 12;
			this.photoControl1.Text = "photoControl1";
			// 
			// textBoxPhotoCaption3
			// 
			this.textBoxPhotoCaption3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption3.Location = new System.Drawing.Point(448, 280);
			this.textBoxPhotoCaption3.Name = "textBoxPhotoCaption3";
			this.textBoxPhotoCaption3.Size = new System.Drawing.Size(216, 20);
			this.textBoxPhotoCaption3.TabIndex = 13;
			this.textBoxPhotoCaption3.Text = "";
			this.textBoxPhotoCaption3.Leave += new System.EventHandler(this.textBoxPhotoCaption3_Leave);
			// 
			// photoControl3
			// 
			this.photoControl3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.photoControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.photoControl3.Image = null;
			this.photoControl3.Location = new System.Drawing.Point(448, 4);
			this.photoControl3.Name = "photoControl3";
			this.photoControl3.Size = new System.Drawing.Size(216, 272);
			this.photoControl3.TabIndex = 12;
			this.photoControl3.Text = "photoControl1";
			// 
			// textBoxPhotoCaption1
			// 
			this.textBoxPhotoCaption1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxPhotoCaption1.Location = new System.Drawing.Point(4, 280);
			this.textBoxPhotoCaption1.Name = "textBoxPhotoCaption1";
			this.textBoxPhotoCaption1.Size = new System.Drawing.Size(216, 20);
			this.textBoxPhotoCaption1.TabIndex = 13;
			this.textBoxPhotoCaption1.Text = "";
			this.textBoxPhotoCaption1.Leave += new System.EventHandler(this.textBoxPhotoCaption1_Leave);
			// 
			// textBoxPhotoCaption2
			// 
			this.textBoxPhotoCaption2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.textBoxPhotoCaption2.Location = new System.Drawing.Point(224, 280);
			this.textBoxPhotoCaption2.Name = "textBoxPhotoCaption2";
			this.textBoxPhotoCaption2.Size = new System.Drawing.Size(216, 20);
			this.textBoxPhotoCaption2.TabIndex = 13;
			this.textBoxPhotoCaption2.Text = "";
			this.textBoxPhotoCaption2.Leave += new System.EventHandler(this.textBoxPhotoCaption2_Leave);
			// 
			// photoControl2
			// 
			this.photoControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.photoControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.photoControl2.Image = null;
			this.photoControl2.Location = new System.Drawing.Point(224, 4);
			this.photoControl2.Name = "photoControl2";
			this.photoControl2.Size = new System.Drawing.Size(216, 272);
			this.photoControl2.TabIndex = 12;
			this.photoControl2.Text = "photoControl1";
			// 
			// buttonPhotoBrowse2
			// 
			this.buttonPhotoBrowse2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonPhotoBrowse2.Location = new System.Drawing.Point(295, 304);
			this.buttonPhotoBrowse2.Name = "buttonPhotoBrowse2";
			this.buttonPhotoBrowse2.TabIndex = 14;
			this.buttonPhotoBrowse2.Text = "Browse";
			this.buttonPhotoBrowse2.Click += new System.EventHandler(this.buttonPhotoBrowse2_Click);
			// 
			// buttonPhotoBrowse3
			// 
			this.buttonPhotoBrowse3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonPhotoBrowse3.Location = new System.Drawing.Point(519, 304);
			this.buttonPhotoBrowse3.Name = "buttonPhotoBrowse3";
			this.buttonPhotoBrowse3.TabIndex = 14;
			this.buttonPhotoBrowse3.Text = "Browse";
			this.buttonPhotoBrowse3.Click += new System.EventHandler(this.buttonPhotoBrowse3_Click);
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.ReadOnly = true;
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 5;
			this.textBoxComponentName.Text = "";
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 26;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(84, 90);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Discipline:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 4;
			this.label3.Text = "Component / Subasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxDisciplineName
			// 
			this.textBoxDisciplineName.Location = new System.Drawing.Point(216, 88);
			this.textBoxDisciplineName.Name = "textBoxDisciplineName";
			this.textBoxDisciplineName.ReadOnly = true;
			this.textBoxDisciplineName.Size = new System.Drawing.Size(228, 20);
			this.textBoxDisciplineName.TabIndex = 7;
			this.textBoxDisciplineName.Text = "Site Improvements / Landscaping / Other";
			// 
			// tabPage1
			// 
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(676, 334);
			this.tabPage1.TabIndex = 2;
			this.tabPage1.Text = "tabPage1";
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(528, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 30;
			this.textBoxCurrentYear.Text = "";
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(456, 6);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(72, 16);
			this.label27.TabIndex = 29;
			this.label27.Text = "Current Year:";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentENR
			// 
			this.textBoxCurrentENR.Location = new System.Drawing.Point(528, 32);
			this.textBoxCurrentENR.Name = "textBoxCurrentENR";
			this.textBoxCurrentENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentENR.TabIndex = 28;
			this.textBoxCurrentENR.Text = "";
			this.textBoxCurrentENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(456, 34);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(72, 16);
			this.label26.TabIndex = 27;
			this.label26.Text = "C&urrent ENR:";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label28
			// 
			this.label28.Location = new System.Drawing.Point(44, 178);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(100, 16);
			this.label28.TabIndex = 46;
			this.label28.Text = "Level of Service:";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxLOS
			// 
			this.textBoxLOS.Location = new System.Drawing.Point(144, 176);
			this.textBoxLOS.MaxLength = 4;
			this.textBoxLOS.Name = "textBoxLOS";
			this.textBoxLOS.ReadOnly = true;
			this.textBoxLOS.Size = new System.Drawing.Size(72, 20);
			this.textBoxLOS.TabIndex = 45;
			this.textBoxLOS.TabStop = false;
			this.textBoxLOS.Text = "";
			this.textBoxLOS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// DisciplineLandControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(616, 480);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.label27);
			this.Controls.Add(this.textBoxCurrentENR);
			this.Controls.Add(this.label26);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBoxDisciplineName);
			this.Name = "DisciplineLandControl";
			this.Size = new System.Drawing.Size(692, 480);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dateInspect)).EndInit();
			this.tabPageComponentInfo.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			LoadConditionRankBox();

			m_dataMonitor = 
				new Drive.Windows.Forms.DataChangeMonitor(this.Controls);
			base.OnLoad(e);
		}

		private void		LoadConditionRankBox()
		{
			comboBoxConditionRanking.BeginUpdate();
			comboBoxConditionRanking.DisplayMember = "DisplayMember";
			comboBoxConditionRanking.Items.Clear();
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.No),
				CondRank.No));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C0),
				CondRank.C0));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C1),
				CondRank.C1));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C2),
				CondRank.C2));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C3),
				CondRank.C3));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C4),
				CondRank.C4));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C5),
				CondRank.C5));
			comboBoxConditionRanking.EndUpdate();
		}

		public void			SetDiscipline(DisciplineLand disc)
		{
			if (m_discipline != null &&
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				SaveFormData();
			}
			m_discipline = disc;
			RefreshData();
		}

		protected override void OnVisibleChanged(EventArgs e)
		{
			if (this.Visible == false && m_discipline != null && 
				m_dataMonitor != null && m_dataMonitor.Dirty)
			{
				// Save outstanding data
				SaveFormData();
			}

			base.OnVisibleChanged(e);
		}

		private bool		SaveFormData()
		{
			if (m_discipline == null)
				return true;

			m_discipline.OrgUsefulLife = 
				Drive.Convert.StringToShort(textBoxOriginalUL.Text);

			// Main Tab
			// -- User modifiable
			if (m_discipline.OverrideAcquisitionCost)
				m_discipline.AcquisitionCost = textBoxAcquisitionCost.Value;
			m_discipline.OverrideAcquisitionCost = checkBoxOverrideAcquisitionCost.Checked;
			m_discipline.ReplacementValue = textBoxReplacementValue.Value;
			m_discipline.SalvageValue = textBoxSalvageValue.Value;
			m_discipline.AnnualMaintCost = textBoxAnnualMaintenanceCost.Value;
			m_discipline.OriginalENR = 
				Drive.Convert.StringToInt(textBoxOriginalENR.Text);
			m_discipline.CurrentENR = 
				Drive.Convert.StringToInt(textBoxCurrentENR.Text);

			// miscellaneous information
			m_discipline.DateInspected = ((DateTime)dateInspect.Value).Date;
			m_discipline.AssessedBy = textBoxAssessedBy.Text;
			m_discipline.EquipmentNumber = textBoxEquipmentNumber.Text;
			m_discipline.Manufacturer = textBoxManufacturer.Text;
			m_discipline.InstallationYear = 
				Drive.Convert.StringToShort(textBoxInstallYear.Text);

			// Photo captions
			m_discipline.CaptionPhoto1 = textBoxPhotoCaption1.Text;
			m_discipline.CaptionPhoto2 = textBoxPhotoCaption2.Text;
			m_discipline.CaptionPhoto3 = textBoxPhotoCaption3.Text;

			// Component Info tab
			m_discipline.SeveralPotholes = itemStatusSeveralPotholes.Status;
			m_discipline.ExcessiveErosion = itemStatusExcessiveErosion.Status;
			m_discipline.RoadDegradation = itemStatusSevereRoadDegradation.Status;
			m_discipline.ExpansionSpace = itemStatusSpaceForExpansion.Status;
			m_discipline.FunctionCover = itemStatusFunctionalGroundCover.Status;
			m_discipline.FencingAdequate = itemStatusFencingAdequate.Status;
			m_discipline.FacilitiesSecure = itemStatusFacilitiesSecure.Status;
			m_discipline.Comments = textBoxComments.Text;

			m_discipline.Save();
			m_dataMonitor.Dirty = false;
			return true;
		}

		private void		SelectConditionRank()
		{
			for (int pos = 0; pos < comboBoxConditionRanking.Items.Count; pos++)
			{
				if (m_discipline.ConditionRanking == 
					((CondRank)((ListItem)comboBoxConditionRanking.Items[pos]).Value))
				{
					comboBoxConditionRanking.SelectedIndex = pos;
					return;
				}
			}

			comboBoxConditionRanking.SelectedIndex = 0;
		}

		public void			RefreshData()
		{
			if (m_discipline == null)
				return;

			m_suppressUpdate = true;
			// Ignore UI change events
			m_dataMonitor.IgnoreChanges = true;
			tabControl.SelectedIndex = 0;

			MajorComponent component = MajorComponentCache.Cached.GetMajorComponent(m_discipline.ComponentID);
			TreatmentProcess process = TreatmentProcessCache.Cached.GetTreatmentProcess(component.ProcessID);
			Facility facility = FacilityCache.Cached.GetFacility(process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();
			textBoxLOS.Text = EnumHandlers.GetLOSShort(component.LOS);

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = component.Name;

			// Main tab
			// -- User modifiable
			textBoxAcquisitionCost.Value = m_discipline.AcquisitionCost;
			textBoxAcquisitionCost.ReadOnly = !m_discipline.OverrideAcquisitionCost;
			checkBoxOverrideAcquisitionCost.Checked = m_discipline.OverrideAcquisitionCost;
			textBoxReplacementValue.Value = m_discipline.ReplacementValue;
			textBoxSalvageValue.Value = m_discipline.SalvageValue;
			textBoxAnnualMaintenanceCost.Value = m_discipline.AnnualMaintCost;
			textBoxInstallYear.Text = m_discipline.InstallationYear.ToString();
			textBoxOriginalENR.Text = m_discipline.OriginalENR.ToString();
			textBoxCurrentENR.Text = m_discipline.CurrentENR.ToString();
			textBoxOriginalUL.Text = m_discipline.OrgUsefulLife.ToString();

			SelectConditionRank();

			dateInspect.Value = m_discipline.DateInspected;
			textBoxEquipmentNumber.Text = m_discipline.EquipmentNumber;
			textBoxManufacturer.Text = m_discipline.Manufacturer;
			textBoxAssessedBy.Text = m_discipline.AssessedBy;

			// Photo captions
			textBoxPhotoCaption1.Text = m_discipline.CaptionPhoto1;
			textBoxPhotoCaption2.Text = m_discipline.CaptionPhoto2;
			textBoxPhotoCaption3.Text = m_discipline.CaptionPhoto3;

			// -- calculated
			UpdateCalculatedProperties();

			// Component Info tab
			itemStatusSeveralPotholes.Status = m_discipline.SeveralPotholes;
			itemStatusExcessiveErosion.Status = m_discipline.ExcessiveErosion;
			itemStatusSevereRoadDegradation.Status = m_discipline.RoadDegradation;
			itemStatusSpaceForExpansion.Status = m_discipline.ExpansionSpace;
			itemStatusFunctionalGroundCover.Status = m_discipline.FunctionCover;
			itemStatusFencingAdequate.Status = m_discipline.FencingAdequate;
			itemStatusFacilitiesSecure.Status = m_discipline.FacilitiesSecure;
			textBoxComments.Text = m_discipline.Comments;

			m_dataMonitor.IgnoreChanges = false;
			m_dataMonitor.Dirty = false;
			m_suppressUpdate = false;
		}

		private void		UpdateCalculatedProperties()
		{
			textBoxOrgCostCurVal.Text = 
				m_discipline.GetCurrentValue().ToString("$#,##0");
			textBoxBookValue.Text = 
				m_discipline.GetBookValue().ToString("$#,##0");
			textBoxAnnualDepreciation.Text = 
				m_discipline.GetAnnualDepreciation().ToString("$#,##0");
			textBoxCumulativeDepreciation.Text = 
				m_discipline.GetCumulativeDepreciation().ToString("$#,##0");
			textBoxEvaluatedValue.Text = 
				m_discipline.GetEvaluatedValue().ToString("$#,##0");
			textBoxRepairCostCurVal.Text = 
				m_discipline.GetRepairCost().ToString("$#,##0");
			textBoxRemainingUL.Text = 
				m_discipline.GetRemainingUsefulLife().ToString();
			textBoxEvaluatedRemainingUL.Text = 
				m_discipline.GetEvaluatedRemainingUsefulLife().ToString();
		}

		private CondRank	GetSelectedConditionRanking()
		{
			ListItem		listItem = comboBoxConditionRanking.SelectedItem as ListItem;

			if (listItem == null)
				return CondRank.No;

			return (CondRank)listItem.Value;
		}

		private void comboBoxConditionRanking_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			// Update the condition ranking on the discipline object immediately
			m_discipline.ConditionRanking = GetSelectedConditionRanking();

			// Update calculated properties
			UpdateCalculatedProperties();
		}

		private void checkBoxOverrideAcquisitionCost_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			m_discipline.OverrideAcquisitionCost = 
				checkBoxOverrideAcquisitionCost.Checked;
			textBoxAcquisitionCost.ReadOnly = 
				!m_discipline.OverrideAcquisitionCost;
			UpdateCalculatedProperties();
		}

		private void OnDependentCalcField_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline == null || m_suppressUpdate)
				return;

			if (object.ReferenceEquals(sender, textBoxAcquisitionCost))
			{
				if (m_discipline.OverrideAcquisitionCost)
					m_discipline.AcquisitionCost = textBoxAcquisitionCost.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxReplacementValue))
			{
				m_discipline.ReplacementValue = textBoxReplacementValue.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxSalvageValue))
			{
				m_discipline.SalvageValue = textBoxSalvageValue.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxAnnualMaintenanceCost))
			{
				m_discipline.AnnualMaintCost = textBoxAnnualMaintenanceCost.Value;
			}
			else if (object.ReferenceEquals(sender, textBoxOriginalENR))
			{
				m_discipline.OriginalENR = 
					Drive.Convert.StringToInt(textBoxOriginalENR.Text);
				textBoxOriginalENR.Text = m_discipline.OriginalENR.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxCurrentENR))
			{
				m_discipline.CurrentENR = 
					Drive.Convert.StringToInt(textBoxCurrentENR.Text);
				textBoxCurrentENR.Text = m_discipline.CurrentENR.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxOriginalUL))
			{
				m_discipline.OrgUsefulLife = 
					Drive.Convert.StringToShort(textBoxOriginalUL.Text);
				textBoxOriginalUL.Text = m_discipline.OrgUsefulLife.ToString();
			}
			else if (object.ReferenceEquals(sender, textBoxInstallYear))
			{
				m_discipline.InstallationYear = 
					Drive.Convert.StringToShort(textBoxInstallYear.Text);
				textBoxInstallYear.Text = m_discipline.InstallationYear.ToString();
			}

			UpdateCalculatedProperties();
		}

		private void tabPagePhoto_Resize(object sender, System.EventArgs e)
		{
			// Need to move the photos around
			// Make the photos take up half the tab, in quarters
			int				photoAreaWidth = 
				(tabPagePhoto.ClientRectangle.Width - 18);
			int				photoWidth = photoAreaWidth / 3;
			int				buttonOffset = (photoWidth / 2) - (buttonPhotoBrowse1.Width / 2);

			photoControl1.Width = photoWidth;
			textBoxPhotoCaption1.Width = photoWidth;
			buttonPhotoBrowse1.Left = photoControl1.Left + buttonOffset;

			photoControl2.SuspendLayout();
			photoControl2.Left = photoControl1.Right + 4;
			photoControl2.Width = photoWidth;
			photoControl2.ResumeLayout(true);
			textBoxPhotoCaption2.SuspendLayout();
			textBoxPhotoCaption2.Left = photoControl2.Left;
			textBoxPhotoCaption2.Width = photoControl2.Width;
			textBoxPhotoCaption2.ResumeLayout(true);
			buttonPhotoBrowse2.Left = photoControl2.Left + buttonOffset;

			photoControl3.SuspendLayout();
			photoControl3.Left = photoControl2.Right + 4;
			photoControl3.Width = photoWidth;
			photoControl3.ResumeLayout(true);
			textBoxPhotoCaption3.SuspendLayout();
			textBoxPhotoCaption3.Left = photoControl3.Left;
			textBoxPhotoCaption3.Width = photoControl3.Width;
			textBoxPhotoCaption3.ResumeLayout(true);
			buttonPhotoBrowse3.Left = photoControl3.Left + buttonOffset;
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_discipline != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption1.Text = m_discipline.CaptionPhoto1;
					photoControl1.Image = m_discipline.GetPhoto(1);
					if (photoControl1.Image == null)
						buttonPhotoBrowse1.Text = "Browse";
					else
						buttonPhotoBrowse1.Text = "Delete";

					textBoxPhotoCaption2.Text = m_discipline.CaptionPhoto2;
					photoControl2.Image = m_discipline.GetPhoto(2);
					if (photoControl2.Image == null)
						buttonPhotoBrowse2.Text = "Browse";
					else
						buttonPhotoBrowse2.Text = "Delete";

					textBoxPhotoCaption3.Text = m_discipline.CaptionPhoto3;
					photoControl3.Image = m_discipline.GetPhoto(3);
					if (photoControl3.Image == null)
						buttonPhotoBrowse3.Text = "Browse";
					else
						buttonPhotoBrowse3.Text = "Delete";
				}
				else
				{
					textBoxPhotoCaption1.Text = "";
					photoControl1.Image = null;
					buttonPhotoBrowse1.Text = "Browse";

					textBoxPhotoCaption2.Text = "";
					photoControl2.Image = null;
					buttonPhotoBrowse2.Text = "Browse";

					textBoxPhotoCaption3.Text = "";
					photoControl3.Image = null;
					buttonPhotoBrowse3.Text = "Browse";
				}
			}
		}

		private void buttonPhotoBrowse1_Click(object sender, System.EventArgs e)
		{
			if (photoControl1.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_discipline.GetImagePath(1);

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_discipline.CaptionPhoto1 = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption1.Text = m_discipline.CaptionPhoto1;
					m_discipline.Save();
					buttonPhotoBrowse1.Text = "Delete";
					photoControl1.Image = m_discipline.GetPhoto(1);
				}
			}
			else
			{
				photoControl1.Image = null;
				string		targetPath = m_discipline.GetImagePath(1);

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_discipline.CaptionPhoto1 = "";
				textBoxPhotoCaption1.Text = "";
				buttonPhotoBrowse1.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption1_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline.CaptionPhoto1 != textBoxPhotoCaption1.Text)
			{
				m_discipline.CaptionPhoto1 = textBoxPhotoCaption1.Text;
				m_discipline.Save();
			}
		}

		private void buttonPhotoBrowse2_Click(object sender, System.EventArgs e)
		{
			if (photoControl2.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_discipline.GetImagePath(2);

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_discipline.CaptionPhoto2 = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption2.Text = m_discipline.CaptionPhoto2;
					m_discipline.Save();
					buttonPhotoBrowse2.Text = "Delete";
					photoControl2.Image = m_discipline.GetPhoto(2);
				}
			}
			else
			{
				photoControl2.Image = null;
				string		targetPath = m_discipline.GetImagePath(2);

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_discipline.CaptionPhoto2 = "";
				textBoxPhotoCaption2.Text = "";
				buttonPhotoBrowse2.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption2_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline.CaptionPhoto2 != textBoxPhotoCaption2.Text)
			{
				m_discipline.CaptionPhoto2 = textBoxPhotoCaption2.Text;
				m_discipline.Save();
			}
		}

		private void buttonPhotoBrowse3_Click(object sender, System.EventArgs e)
		{
			if (photoControl3.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_discipline.GetImagePath(3);

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_discipline.CaptionPhoto3 = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption3.Text = m_discipline.CaptionPhoto3;
					m_discipline.Save();
					buttonPhotoBrowse3.Text = "Delete";
					photoControl3.Image = m_discipline.GetPhoto(3);
				}
			}
			else
			{
				photoControl3.Image = null;
				string		targetPath = m_discipline.GetImagePath(3);

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_discipline.CaptionPhoto3 = "";
				textBoxPhotoCaption3.Text = "";
				buttonPhotoBrowse3.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption3_Leave(object sender, System.EventArgs e)
		{
			if (m_discipline.CaptionPhoto3 != textBoxPhotoCaption3.Text)
			{
				m_discipline.CaptionPhoto3 = textBoxPhotoCaption3.Text;
				m_discipline.Save();
			}
		}
	}
}
