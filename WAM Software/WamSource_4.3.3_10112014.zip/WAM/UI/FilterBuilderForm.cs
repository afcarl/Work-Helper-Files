using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Logic;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for FilterBuilderForm.
	/// </summary>
	public class FilterBuilderForm : System.Windows.Forms.Form
	{
		private UnitFilter	m_unitFilter = null;
		private bool		m_initialized = false;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboBoxSource;
		private System.Windows.Forms.Label labelOperator;
		private System.Windows.Forms.ComboBox comboBoxOperator;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox comboBoxFilterCompareTo;
		private System.Windows.Forms.Label labelSpecificValue;
		private System.Windows.Forms.TextBox textBoxFilterVal1;
		private System.Windows.Forms.TextBox textBoxFilterVal2;
		private System.Windows.Forms.Label labelFilterAnd;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FilterBuilderForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.comboBoxSource = new System.Windows.Forms.ComboBox();
			this.labelOperator = new System.Windows.Forms.Label();
			this.comboBoxOperator = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBoxFilterCompareTo = new System.Windows.Forms.ComboBox();
			this.labelSpecificValue = new System.Windows.Forms.Label();
			this.textBoxFilterVal1 = new System.Windows.Forms.TextBox();
			this.labelFilterAnd = new System.Windows.Forms.Label();
			this.textBoxFilterVal2 = new System.Windows.Forms.TextBox();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(4, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(180, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "1) Select a &field to filter by:";
			// 
			// comboBoxSource
			// 
			this.comboBoxSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxSource.Location = new System.Drawing.Point(20, 20);
			this.comboBoxSource.Name = "comboBoxSource";
			this.comboBoxSource.Size = new System.Drawing.Size(240, 21);
			this.comboBoxSource.TabIndex = 1;
			// 
			// labelOperator
			// 
			this.labelOperator.Location = new System.Drawing.Point(4, 48);
			this.labelOperator.Name = "labelOperator";
			this.labelOperator.Size = new System.Drawing.Size(180, 16);
			this.labelOperator.TabIndex = 2;
			this.labelOperator.Text = "2) Select a comparison &operator:";
			// 
			// comboBoxOperator
			// 
			this.comboBoxOperator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOperator.Location = new System.Drawing.Point(20, 64);
			this.comboBoxOperator.Name = "comboBoxOperator";
			this.comboBoxOperator.Size = new System.Drawing.Size(144, 21);
			this.comboBoxOperator.TabIndex = 3;
			this.comboBoxOperator.SelectedIndexChanged += new System.EventHandler(this.UpdateSpecificValueStatus);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(4, 92);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(172, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "3) Select the filter &value type:";
			// 
			// comboBoxFilterCompareTo
			// 
			this.comboBoxFilterCompareTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFilterCompareTo.Location = new System.Drawing.Point(20, 108);
			this.comboBoxFilterCompareTo.Name = "comboBoxFilterCompareTo";
			this.comboBoxFilterCompareTo.Size = new System.Drawing.Size(240, 21);
			this.comboBoxFilterCompareTo.TabIndex = 5;
			this.comboBoxFilterCompareTo.SelectedIndexChanged += new System.EventHandler(this.UpdateSpecificValueStatus);
			// 
			// labelSpecificValue
			// 
			this.labelSpecificValue.Location = new System.Drawing.Point(4, 136);
			this.labelSpecificValue.Name = "labelSpecificValue";
			this.labelSpecificValue.Size = new System.Drawing.Size(248, 16);
			this.labelSpecificValue.TabIndex = 6;
			this.labelSpecificValue.Text = "4) Enter the &specific value(s) to be filtered on:";
			// 
			// textBoxFilterVal1
			// 
			this.textBoxFilterVal1.Location = new System.Drawing.Point(20, 152);
			this.textBoxFilterVal1.Name = "textBoxFilterVal1";
			this.textBoxFilterVal1.TabIndex = 7;
			this.textBoxFilterVal1.Text = "";
			this.textBoxFilterVal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// labelFilterAnd
			// 
			this.labelFilterAnd.Location = new System.Drawing.Point(124, 154);
			this.labelFilterAnd.Name = "labelFilterAnd";
			this.labelFilterAnd.Size = new System.Drawing.Size(32, 16);
			this.labelFilterAnd.TabIndex = 8;
			this.labelFilterAnd.Text = "and";
			this.labelFilterAnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBoxFilterVal2
			// 
			this.textBoxFilterVal2.Location = new System.Drawing.Point(160, 152);
			this.textBoxFilterVal2.Name = "textBoxFilterVal2";
			this.textBoxFilterVal2.TabIndex = 9;
			this.textBoxFilterVal2.Text = "";
			this.textBoxFilterVal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// buttonSave
			// 
			this.buttonSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(36, 188);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 10;
			this.buttonSave.Text = "&Accept";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(148, 188);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 11;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// FilterBuilderForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(266, 220);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.labelFilterAnd);
			this.Controls.Add(this.textBoxFilterVal1);
			this.Controls.Add(this.textBoxFilterVal2);
			this.Controls.Add(this.labelSpecificValue);
			this.Controls.Add(this.comboBoxFilterCompareTo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.comboBoxOperator);
			this.Controls.Add(this.labelOperator);
			this.Controls.Add(this.comboBoxSource);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FilterBuilderForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Filter Builder";
			this.ResumeLayout(false);

		}
		#endregion

		public static bool	ShowForm(WAM.Logic.UnitFilter unitFilter, Form owner)
		{
			FilterBuilderForm form = new FilterBuilderForm();

			form.m_unitFilter = unitFilter;
			return form.ShowDialog(owner) == DialogResult.OK;
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			LoadSourceFilterList();
			LoadOperatorList();
			LoadCompareToList();

			m_initialized = true;
			textBoxFilterVal1.Text = m_unitFilter.CompareVal1.ToString();
			textBoxFilterVal2.Text = m_unitFilter.CompareVal2.ToString();
			UpdateSpecificValueStatus(null, null);
			base.OnLoad(e);
		}

		private void		LoadSourceFilterList()
		{
			UnitFilter.FilterSource[] sources = (UnitFilter.FilterSource[])Enum.GetValues(typeof(UnitFilter.FilterSource));
			ListItem[]		items = new ListItem[sources.Length];
			int				pos;
			int				selectedIndex = 0;

			for (pos = 0; pos < sources.Length; pos++)
				items[pos] = new ListItem(UnitFilter.GetFilterSourceString(sources[pos]), sources[pos]);

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			comboBoxSource.BeginUpdate();
			comboBoxSource.DisplayMember = "DisplayMember";
			comboBoxSource.Items.Clear();
			comboBoxSource.Items.AddRange(items);
			comboBoxSource.EndUpdate();

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterSource)items[pos].Value) == m_unitFilter.Source)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxSource.SelectedIndex = selectedIndex;
		}

		private void		LoadOperatorList()
		{
			UnitFilter.FilterOperator[] ops = (UnitFilter.FilterOperator[])Enum.GetValues(typeof(UnitFilter.FilterOperator));
			ListItem[]		items = new ListItem[ops.Length];
			int				pos;
			int				selectedIndex = 0;

			for (pos = 0; pos < ops.Length; pos++)
				items[pos] = new ListItem(UnitFilter.GetFilterOperatorString(ops[pos]), ops[pos]);

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			comboBoxOperator.BeginUpdate();
			comboBoxOperator.DisplayMember = "DisplayMember";
			comboBoxOperator.Items.Clear();
			comboBoxOperator.Items.AddRange(items);
			comboBoxOperator.EndUpdate();

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterOperator)items[pos].Value) == m_unitFilter.Operator)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxOperator.SelectedIndex = selectedIndex;
		}

		private void		LoadCompareToList()
		{
			UnitFilter.FilterCompareTo[] ops = (UnitFilter.FilterCompareTo[])Enum.GetValues(typeof(UnitFilter.FilterCompareTo));
			ListItem[]		items = new ListItem[ops.Length];
			int				pos;
			int				selectedIndex = 0;

			for (pos = 0; pos < ops.Length; pos++)
				items[pos] = new ListItem(UnitFilter.GetFilterCompareToString(ops[pos]), ops[pos]);

			//mam - commented for testing
			//mam - leave it commented because the combo box is sorted
			//Array.Sort(items);
			//</mam>

			comboBoxFilterCompareTo.BeginUpdate();
			comboBoxFilterCompareTo.DisplayMember = "DisplayMember";
			comboBoxFilterCompareTo.Items.Clear();
			comboBoxFilterCompareTo.Items.AddRange(items);
			comboBoxFilterCompareTo.EndUpdate();

			for (pos = 0; pos < items.Length; pos++)
			{
				if (((UnitFilter.FilterCompareTo)items[pos].Value) == m_unitFilter.Compare)
				{
					selectedIndex = pos;
					break;
				}
			}

			comboBoxFilterCompareTo.SelectedIndex = selectedIndex;
		}

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			// Save the selected values
			ListItem		sourceItem = comboBoxSource.SelectedItem as ListItem;
			ListItem		opItem = comboBoxOperator.SelectedItem as ListItem;
			ListItem		compItem = comboBoxFilterCompareTo.SelectedItem as ListItem;

			if ((UnitFilter.FilterSource)sourceItem.Value == UnitFilter.FilterSource.Undefined)
			{
				MessageBox.Show(this, "Please select a field to filter by.", "Select Filter Field");
				return;
			}

			m_unitFilter.Source = (UnitFilter.FilterSource)sourceItem.Value;
			m_unitFilter.Operator = (UnitFilter.FilterOperator)opItem.Value;
			m_unitFilter.Compare = (UnitFilter.FilterCompareTo)compItem.Value;

			m_unitFilter.CompareVal1 = Drive.Convert.StringToDecimal(textBoxFilterVal1.Text);
			m_unitFilter.CompareVal2 = Drive.Convert.StringToDecimal(textBoxFilterVal2.Text);

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void UpdateSpecificValueStatus(object sender, System.EventArgs e)
		{
			if (!m_initialized)
				return;

			ListItem		opItem = comboBoxOperator.SelectedItem as ListItem;
			ListItem		targItem = comboBoxFilterCompareTo.SelectedItem as ListItem;
			bool			enableVal1 = false, enableVal2 = false;
			bool			enableCompare = true;

			// Make sure that the specific values get enabled correctly based on
			// operator and target compare field
			if (opItem != null && targItem != null)
			{
				UnitFilter.FilterOperator op = (UnitFilter.FilterOperator)opItem.Value;
				UnitFilter.FilterCompareTo comp = (UnitFilter.FilterCompareTo)targItem.Value;

				if (op == UnitFilter.FilterOperator.Between || 
					op == UnitFilter.FilterOperator.OutsideOf)
				{
					// Disallow compare value to get set
					enableCompare = false;
				}

				if (comp == UnitFilter.FilterCompareTo.Value)
				{
					enableVal1 = true;

					if (op == UnitFilter.FilterOperator.Between || 
						op == UnitFilter.FilterOperator.OutsideOf)
					{
						enableVal2 = true;
					}
				}
			}

			textBoxFilterVal1.Enabled = enableVal1;
			labelFilterAnd.Enabled = enableVal2;
			textBoxFilterVal2.Enabled = enableVal2;

			comboBoxFilterCompareTo.Enabled = enableCompare;
			if (!enableCompare)
			{
				// Make sure that "< Specific Value(s) >" is selected
				if (comboBoxFilterCompareTo.SelectedIndex != 0)
					comboBoxFilterCompareTo.SelectedIndex = 0;
			}
		}
	}
}