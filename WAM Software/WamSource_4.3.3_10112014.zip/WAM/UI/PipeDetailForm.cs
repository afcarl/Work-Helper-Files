using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Data;

//mam 07072011
using WAM.Common;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for PipeDetailForm.
	/// </summary>
	public class PipeDetailForm : System.Windows.Forms.Form
	{
		#region /***** Variables *****/

		private PipeData	m_pipeData = null;
		private bool		m_suppressUpdates = false;

		//mam
		int selectedVulnerability;
		string allowedChar = "0123456789";
		string existingText = "";
		int currentPos = 0;
		//</mam>

		//mam 050806
		private decimal localRepairCost = 0.0M;
		private decimal localCurrentValue = 0.0M;
		private decimal localAcquisitionCost = 0.0M;
		private bool isInitialized = false;

		private System.Windows.Forms.Label label17;
		private WAM.UI.DollarTextBox textBoxReplacementValue;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label24;
		private WAM.UI.DollarTextBox textBoxSalvageValue;
		private WAM.UI.DollarTextBox textBoxAnnualMaintenanceCost;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label1;
		private WAM.UI.NumberTextBox textBoxInstallYear;
		private System.Windows.Forms.ComboBox comboBoxLOS;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBoxIDNumber;
		private WAM.UI.NumberTextBox textBoxOriginalUL;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.TextBox textBoxDescription;
		private System.Windows.Forms.TextBox textBoxType;
		private System.Windows.Forms.TextBox textBoxSize;
		private System.Windows.Forms.ComboBox comboBoxConditionRanking;
		private System.Windows.Forms.Label label15;
		private WAM.UI.DollarTextBox textBoxUnitCost;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label18;
		private WAM.UI.NumberTextBox textBoxLength;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox textBoxERUL;
		private C1.Win.C1Report.C1Report c1Report1;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox textBoxReplacementValueYear;
		private WAM.UI.DollarTextBox textBoxRepairCost;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.CheckBox checkBoxOverrideRepairCost;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private WAM.UI.DollarTextBox textBoxCurrentValue;
		private System.Windows.Forms.CheckBox checkBoxOverrideAcquisitionCost;
		private System.Windows.Forms.CheckBox checkBoxOverrideCurrentValue;
		private System.Windows.Forms.TextBox textBoxRedundantAssetCount;
		private System.Windows.Forms.Label label23;
		private WAM.UI.NumberTextBox textBoxReplacementENR;
		private System.Windows.Forms.Label label32;
		private WAM.UI.DollarTextBox textBoxRehabCost;
		private WAM.UI.DollarTextBox textBoxAcquisitionCostEscalated;
		private System.Windows.Forms.Label label31;
		private DollarTextBoxTwoDecimals.DollarTextBoxTwoDecimals textBoxAcquisitionCost;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.Label label36;
		private System.Windows.Forms.Label label38;
		private WAM.UI.NumberTextBox textBoxInstallYearENR;
		private System.Windows.Forms.Label labelCriticalityWeight6;
		private System.Windows.Forms.ComboBox comboBoxCriticality6;
		private System.Windows.Forms.Label labelCriticality6;
		private System.Windows.Forms.Label labelCriticalityWeight5;
		private System.Windows.Forms.Label labelCriticalityWeight4;
		private System.Windows.Forms.Label labelCriticalityWeight3;
		private System.Windows.Forms.Label labelCriticalityWeight2;
		private System.Windows.Forms.Label labelCriticalityWeight1;
		private System.Windows.Forms.ComboBox comboBoxCriticality5;
		private System.Windows.Forms.Label labelCriticality5;
		private System.Windows.Forms.ComboBox comboBoxCriticality4;
		private System.Windows.Forms.Label labelCriticality4;
		private System.Windows.Forms.ComboBox comboBoxCriticality3;
		private System.Windows.Forms.Label labelCriticality3;
		private System.Windows.Forms.ComboBox comboBoxCriticality2;
		private System.Windows.Forms.Label labelCriticality2;
		private System.Windows.Forms.ComboBox comboBoxCriticality1;
		private System.Windows.Forms.Label labelCriticality1;
		private System.Windows.Forms.TextBox textBoxCritTotal;
		private System.Windows.Forms.TextBox textBoxVulnerability;
		private System.Windows.Forms.TextBox textBoxRisk;
		private System.Windows.Forms.PictureBox pictureBoxVulnerabilitySelect;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.CheckBox checkBoxOverrideVulnerability;
		private System.Windows.Forms.Button buttonVulnerabilitySelect;
		private System.Windows.Forms.TextBox textBoxVulnerabilityBackground;
		private System.Windows.Forms.GroupBox groupBoxVulnRisk;
		private System.Windows.Forms.GroupBox groupBoxCriticality;
		private System.Windows.Forms.Label labelCritTotal;
		//private System.ComponentModel.IContainer components;
		private System.ComponentModel.Container components = null;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public PipeDetailForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.comboBoxLOS.SelectedIndexChanged += new System.EventHandler(this.OnChangeLOS);
			
			//this.textBoxERUL.MouseDown += new MouseEventHandler(WAM.UI.EquationViewerHandler.ShowEquation);

			WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
			equationViewerHandler.AssignMouseHandler(this);
			equationViewerHandler.AssignCursor(this);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PipeDetailForm));
			this.label17 = new System.Windows.Forms.Label();
			this.textBoxReplacementValue = new WAM.UI.DollarTextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.textBoxSalvageValue = new WAM.UI.DollarTextBox();
			this.textBoxAnnualMaintenanceCost = new WAM.UI.DollarTextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBoxInstallYear = new WAM.UI.NumberTextBox();
			this.comboBoxLOS = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxIDNumber = new System.Windows.Forms.TextBox();
			this.textBoxDescription = new System.Windows.Forms.TextBox();
			this.textBoxOriginalUL = new WAM.UI.NumberTextBox();
			this.textBoxType = new System.Windows.Forms.TextBox();
			this.textBoxSize = new System.Windows.Forms.TextBox();
			this.buttonSave = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.comboBoxConditionRanking = new System.Windows.Forms.ComboBox();
			this.label15 = new System.Windows.Forms.Label();
			this.textBoxUnitCost = new WAM.UI.DollarTextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxLength = new WAM.UI.NumberTextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.textBoxERUL = new System.Windows.Forms.TextBox();
			this.c1Report1 = new C1.Win.C1Report.C1Report();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.label30 = new System.Windows.Forms.Label();
			this.textBoxReplacementValueYear = new System.Windows.Forms.TextBox();
			this.textBoxRepairCost = new WAM.UI.DollarTextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.checkBoxOverrideRepairCost = new System.Windows.Forms.CheckBox();
			this.label21 = new System.Windows.Forms.Label();
			this.textBoxCurrentValue = new WAM.UI.DollarTextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.checkBoxOverrideAcquisitionCost = new System.Windows.Forms.CheckBox();
			this.checkBoxOverrideCurrentValue = new System.Windows.Forms.CheckBox();
			this.textBoxAcquisitionCost = new DollarTextBoxTwoDecimals.DollarTextBoxTwoDecimals();
			this.textBoxRedundantAssetCount = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.textBoxReplacementENR = new WAM.UI.NumberTextBox();
			this.label32 = new System.Windows.Forms.Label();
			this.textBoxRehabCost = new WAM.UI.DollarTextBox();
			this.textBoxAcquisitionCostEscalated = new WAM.UI.DollarTextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.textBoxInstallYearENR = new WAM.UI.NumberTextBox();
			this.label27 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.label36 = new System.Windows.Forms.Label();
			this.label38 = new System.Windows.Forms.Label();
			this.groupBoxCriticality = new System.Windows.Forms.GroupBox();
			this.labelCriticalityWeight6 = new System.Windows.Forms.Label();
			this.comboBoxCriticality6 = new System.Windows.Forms.ComboBox();
			this.labelCriticality6 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight5 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight4 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight3 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight2 = new System.Windows.Forms.Label();
			this.labelCriticalityWeight1 = new System.Windows.Forms.Label();
			this.comboBoxCriticality5 = new System.Windows.Forms.ComboBox();
			this.labelCriticality5 = new System.Windows.Forms.Label();
			this.comboBoxCriticality4 = new System.Windows.Forms.ComboBox();
			this.labelCriticality4 = new System.Windows.Forms.Label();
			this.comboBoxCriticality3 = new System.Windows.Forms.ComboBox();
			this.labelCriticality3 = new System.Windows.Forms.Label();
			this.comboBoxCriticality2 = new System.Windows.Forms.ComboBox();
			this.labelCriticality2 = new System.Windows.Forms.Label();
			this.comboBoxCriticality1 = new System.Windows.Forms.ComboBox();
			this.labelCriticality1 = new System.Windows.Forms.Label();
			this.textBoxCritTotal = new System.Windows.Forms.TextBox();
			this.labelCritTotal = new System.Windows.Forms.Label();
			this.textBoxVulnerability = new System.Windows.Forms.TextBox();
			this.textBoxRisk = new System.Windows.Forms.TextBox();
			this.pictureBoxVulnerabilitySelect = new System.Windows.Forms.PictureBox();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.checkBoxOverrideVulnerability = new System.Windows.Forms.CheckBox();
			this.buttonVulnerabilitySelect = new System.Windows.Forms.Button();
			this.textBoxVulnerabilityBackground = new System.Windows.Forms.TextBox();
			this.groupBoxVulnRisk = new System.Windows.Forms.GroupBox();
			((System.ComponentModel.ISupportInitialize)(this.c1Report1)).BeginInit();
			this.groupBoxCriticality.SuspendLayout();
			this.groupBoxVulnRisk.SuspendLayout();
			this.SuspendLayout();
			// 
			// label17
			// 
			this.label17.BackColor = System.Drawing.Color.Transparent;
			this.label17.Location = new System.Drawing.Point(30, 163);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(108, 16);
			this.label17.TabIndex = 17;
			this.label17.Text = "&Replacement Value:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxReplacementValue
			// 
			this.textBoxReplacementValue.Location = new System.Drawing.Point(138, 161);
			this.textBoxReplacementValue.MaxLength = 30;
			this.textBoxReplacementValue.Name = "textBoxReplacementValue";
			this.textBoxReplacementValue.Size = new System.Drawing.Size(80, 20);
			this.textBoxReplacementValue.TabIndex = 18;
			this.textBoxReplacementValue.Text = "$0";
			this.textBoxReplacementValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxReplacementValue.Value = new System.Decimal(new int[] {
																				  0,
																				  0,
																				  0,
																				  0});
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Location = new System.Drawing.Point(34, 338);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(104, 16);
			this.label8.TabIndex = 39;
			this.label8.Text = "Original Useful &Life:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label24
			// 
			this.label24.BackColor = System.Drawing.Color.Transparent;
			this.label24.Location = new System.Drawing.Point(30, 238);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(108, 16);
			this.label24.TabIndex = 28;
			this.label24.Text = "Sal&vage Value:";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxSalvageValue
			// 
			this.textBoxSalvageValue.Location = new System.Drawing.Point(138, 236);
			this.textBoxSalvageValue.MaxLength = 30;
			this.textBoxSalvageValue.Name = "textBoxSalvageValue";
			this.textBoxSalvageValue.Size = new System.Drawing.Size(80, 20);
			this.textBoxSalvageValue.TabIndex = 29;
			this.textBoxSalvageValue.Text = "$0";
			this.textBoxSalvageValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxSalvageValue.Value = new System.Decimal(new int[] {
																			  0,
																			  0,
																			  0,
																			  0});
			// 
			// textBoxAnnualMaintenanceCost
			// 
			this.textBoxAnnualMaintenanceCost.Location = new System.Drawing.Point(138, 286);
			this.textBoxAnnualMaintenanceCost.MaxLength = 30;
			this.textBoxAnnualMaintenanceCost.Name = "textBoxAnnualMaintenanceCost";
			this.textBoxAnnualMaintenanceCost.Size = new System.Drawing.Size(80, 20);
			this.textBoxAnnualMaintenanceCost.TabIndex = 34;
			this.textBoxAnnualMaintenanceCost.Text = "$0";
			this.textBoxAnnualMaintenanceCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAnnualMaintenanceCost.Value = new System.Decimal(new int[] {
																					   0,
																					   0,
																					   0,
																					   0});
			// 
			// label25
			// 
			this.label25.BackColor = System.Drawing.Color.Transparent;
			this.label25.Location = new System.Drawing.Point(-2, 288);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(140, 16);
			this.label25.TabIndex = 33;
			this.label25.Text = "Annual &Maintenance Cost:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(34, 313);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 16);
			this.label1.TabIndex = 35;
			this.label1.Text = "Installation &Year:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInstallYear
			// 
			this.textBoxInstallYear.Location = new System.Drawing.Point(138, 311);
			this.textBoxInstallYear.MaxLength = 4;
			this.textBoxInstallYear.Name = "textBoxInstallYear";
			this.textBoxInstallYear.Size = new System.Drawing.Size(80, 20);
			this.textBoxInstallYear.TabIndex = 36;
			this.textBoxInstallYear.Text = "0";
			this.textBoxInstallYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxInstallYear.Value = ((long)(0));
			// 
			// comboBoxLOS
			// 
			this.comboBoxLOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxLOS.Location = new System.Drawing.Point(420, 63);
			this.comboBoxLOS.Name = "comboBoxLOS";
			this.comboBoxLOS.Size = new System.Drawing.Size(240, 21);
			this.comboBoxLOS.TabIndex = 48;
			this.comboBoxLOS.SelectedIndexChanged += new System.EventHandler(this.OnChangeLOS);
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Location = new System.Drawing.Point(420, 46);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(96, 16);
			this.label6.TabIndex = 47;
			this.label6.Text = "Level of Service:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(34, 13);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.TabIndex = 0;
			this.label3.Text = "&ID Number:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Location = new System.Drawing.Point(38, 38);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 2;
			this.label4.Text = "&Description:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Location = new System.Drawing.Point(34, 63);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 4;
			this.label5.Text = "Type:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Location = new System.Drawing.Point(214, 63);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(76, 16);
			this.label7.TabIndex = 6;
			this.label7.Text = "Diameter (in):";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxIDNumber
			// 
			this.textBoxIDNumber.Location = new System.Drawing.Point(138, 11);
			this.textBoxIDNumber.MaxLength = 20;
			this.textBoxIDNumber.Name = "textBoxIDNumber";
			this.textBoxIDNumber.Size = new System.Drawing.Size(220, 20);
			this.textBoxIDNumber.TabIndex = 1;
			this.textBoxIDNumber.Text = "";
			// 
			// textBoxDescription
			// 
			this.textBoxDescription.Location = new System.Drawing.Point(138, 36);
			this.textBoxDescription.MaxLength = 255;
			this.textBoxDescription.Name = "textBoxDescription";
			this.textBoxDescription.Size = new System.Drawing.Size(220, 20);
			this.textBoxDescription.TabIndex = 3;
			this.textBoxDescription.Text = "";
			// 
			// textBoxOriginalUL
			// 
			this.textBoxOriginalUL.Location = new System.Drawing.Point(138, 336);
			this.textBoxOriginalUL.MaxLength = 4;
			this.textBoxOriginalUL.Name = "textBoxOriginalUL";
			this.textBoxOriginalUL.Size = new System.Drawing.Size(80, 20);
			this.textBoxOriginalUL.TabIndex = 40;
			this.textBoxOriginalUL.Text = "0";
			this.textBoxOriginalUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxOriginalUL.Value = ((long)(0));
			this.textBoxOriginalUL.TextChanged += new System.EventHandler(this.textBoxOriginalUL_TextChanged);
			// 
			// textBoxType
			// 
			this.textBoxType.Location = new System.Drawing.Point(138, 61);
			this.textBoxType.MaxLength = 255;
			this.textBoxType.Name = "textBoxType";
			this.textBoxType.Size = new System.Drawing.Size(80, 20);
			this.textBoxType.TabIndex = 5;
			this.textBoxType.Text = "";
			// 
			// textBoxSize
			// 
			this.textBoxSize.Location = new System.Drawing.Point(293, 61);
			this.textBoxSize.MaxLength = 255;
			this.textBoxSize.Name = "textBoxSize";
			this.textBoxSize.Size = new System.Drawing.Size(65, 20);
			this.textBoxSize.TabIndex = 7;
			this.textBoxSize.Text = "";
			this.textBoxSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// buttonSave
			// 
			this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Location = new System.Drawing.Point(498, 498);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.TabIndex = 56;
			this.buttonSave.Text = "&Save";
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(582, 498);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 57;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// comboBoxConditionRanking
			// 
			this.comboBoxConditionRanking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxConditionRanking.Location = new System.Drawing.Point(138, 386);
			this.comboBoxConditionRanking.Name = "comboBoxConditionRanking";
			this.comboBoxConditionRanking.Size = new System.Drawing.Size(264, 21);
			this.comboBoxConditionRanking.TabIndex = 44;
			this.comboBoxConditionRanking.SelectedIndexChanged += new System.EventHandler(this.comboBoxConditionRanking_SelectedIndexChanged);
			// 
			// label15
			// 
			this.label15.BackColor = System.Drawing.Color.Transparent;
			this.label15.Location = new System.Drawing.Point(34, 388);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(104, 16);
			this.label15.TabIndex = 43;
			this.label15.Text = "&Condition Ranking:";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxUnitCost
			// 
			this.textBoxUnitCost.Location = new System.Drawing.Point(304, 86);
			this.textBoxUnitCost.MaxLength = 30;
			this.textBoxUnitCost.Name = "textBoxUnitCost";
			this.textBoxUnitCost.Size = new System.Drawing.Size(54, 20);
			this.textBoxUnitCost.TabIndex = 11;
			this.textBoxUnitCost.Text = "$0";
			this.textBoxUnitCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxUnitCost.Value = new System.Decimal(new int[] {
																		  0,
																		  0,
																		  0,
																		  0});
			// 
			// label16
			// 
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.Location = new System.Drawing.Point(214, 88);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(91, 16);
			this.label16.TabIndex = 10;
			this.label16.Text = "&Unit Cost ($ / ft):";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxLength
			// 
			this.textBoxLength.Location = new System.Drawing.Point(138, 86);
			this.textBoxLength.MaxLength = 9;
			this.textBoxLength.Name = "textBoxLength";
			this.textBoxLength.Size = new System.Drawing.Size(80, 20);
			this.textBoxLength.TabIndex = 9;
			this.textBoxLength.Text = "0";
			this.textBoxLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxLength.Value = ((long)(0));
			// 
			// label18
			// 
			this.label18.BackColor = System.Drawing.Color.Transparent;
			this.label18.Location = new System.Drawing.Point(69, 88);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(68, 16);
			this.label18.TabIndex = 8;
			this.label18.Text = "Len&gth (ft):";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label19
			// 
			this.label19.BackColor = System.Drawing.Color.Transparent;
			this.label19.Location = new System.Drawing.Point(-6, 363);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(144, 16);
			this.label19.TabIndex = 41;
			this.label19.Text = "Eval. Remain. Useful Life:";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxERUL
			// 
			this.textBoxERUL.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.textBoxERUL.Location = new System.Drawing.Point(138, 361);
			this.textBoxERUL.MaxLength = 255;
			this.textBoxERUL.Name = "textBoxERUL";
			this.textBoxERUL.ReadOnly = true;
			this.textBoxERUL.Size = new System.Drawing.Size(80, 20);
			this.textBoxERUL.TabIndex = 42;
			this.textBoxERUL.TabStop = false;
			this.textBoxERUL.Tag = "ERUL";
			this.textBoxERUL.Text = "";
			this.textBoxERUL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// c1Report1
			// 
			this.c1Report1.ReportDefinition = @"<!--Report *** c1Report1 ***--><Report version=""2.5.20051.166""><Name>c1Report1</Name><DataSource /><Layout /><Font><Name>Arial</Name><Size>9</Size></Font><Groups /><Sections><Section><Name>Detail</Name><Type>0</Type><Visible>0</Visible></Section><Section><Name>Header</Name><Type>1</Type><Visible>0</Visible></Section><Section><Name>Footer</Name><Type>2</Type><Visible>0</Visible></Section><Section><Name>PageHeader</Name><Type>3</Type><Visible>0</Visible></Section><Section><Name>PageFooter</Name><Type>4</Type><Visible>0</Visible></Section></Sections><Fields /></Report>";
			this.c1Report1.ReportName = "c1Report1";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(638, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 99;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// label30
			// 
			this.label30.Location = new System.Drawing.Point(215, 163);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(36, 16);
			this.label30.TabIndex = 19;
			this.label30.Text = "Year:";
			this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxReplacementValueYear
			// 
			this.textBoxReplacementValueYear.Location = new System.Drawing.Point(251, 161);
			this.textBoxReplacementValueYear.MaxLength = 4;
			this.textBoxReplacementValueYear.Name = "textBoxReplacementValueYear";
			this.textBoxReplacementValueYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxReplacementValueYear.TabIndex = 20;
			this.textBoxReplacementValueYear.Text = "0";
			this.textBoxReplacementValueYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxRepairCost
			// 
			this.textBoxRepairCost.Location = new System.Drawing.Point(138, 261);
			this.textBoxRepairCost.MaxLength = 30;
			this.textBoxRepairCost.Name = "textBoxRepairCost";
			this.textBoxRepairCost.Size = new System.Drawing.Size(80, 20);
			this.textBoxRepairCost.TabIndex = 31;
			this.textBoxRepairCost.Tag = "RC";
			this.textBoxRepairCost.Text = "$0";
			this.textBoxRepairCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxRepairCost.Value = new System.Decimal(new int[] {
																			0,
																			0,
																			0,
																			0});
			// 
			// label20
			// 
			this.label20.BackColor = System.Drawing.Color.Transparent;
			this.label20.Location = new System.Drawing.Point(30, 263);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(108, 16);
			this.label20.TabIndex = 30;
			this.label20.Text = "Repair Cost:";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxOverrideRepairCost
			// 
			this.checkBoxOverrideRepairCost.BackColor = System.Drawing.SystemColors.Control;
			this.checkBoxOverrideRepairCost.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBoxOverrideRepairCost.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOverrideRepairCost.Location = new System.Drawing.Point(222, 264);
			this.checkBoxOverrideRepairCost.Name = "checkBoxOverrideRepairCost";
			this.checkBoxOverrideRepairCost.Size = new System.Drawing.Size(77, 16);
			this.checkBoxOverrideRepairCost.TabIndex = 32;
			this.checkBoxOverrideRepairCost.Text = "Override";
			this.checkBoxOverrideRepairCost.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBoxOverrideRepairCost.CheckedChanged += new System.EventHandler(this.checkBoxOverrideRepairCost_CheckedChanged);
			// 
			// label21
			// 
			this.label21.BackColor = System.Drawing.Color.Transparent;
			this.label21.Location = new System.Drawing.Point(30, 113);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(108, 16);
			this.label21.TabIndex = 12;
			this.label21.Text = "&Acquisition Cost:";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxCurrentValue
			// 
			this.textBoxCurrentValue.Location = new System.Drawing.Point(138, 186);
			this.textBoxCurrentValue.MaxLength = 30;
			this.textBoxCurrentValue.Name = "textBoxCurrentValue";
			this.textBoxCurrentValue.Size = new System.Drawing.Size(80, 20);
			this.textBoxCurrentValue.TabIndex = 24;
			this.textBoxCurrentValue.Tag = "CV";
			this.textBoxCurrentValue.Text = "$0";
			this.textBoxCurrentValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxCurrentValue.Value = new System.Decimal(new int[] {
																			  0,
																			  0,
																			  0,
																			  0});
			// 
			// label22
			// 
			this.label22.BackColor = System.Drawing.Color.Transparent;
			this.label22.Location = new System.Drawing.Point(29, 188);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(108, 16);
			this.label22.TabIndex = 23;
			this.label22.Text = "Current Value:";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxOverrideAcquisitionCost
			// 
			this.checkBoxOverrideAcquisitionCost.BackColor = System.Drawing.SystemColors.Control;
			this.checkBoxOverrideAcquisitionCost.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBoxOverrideAcquisitionCost.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOverrideAcquisitionCost.Location = new System.Drawing.Point(238, 112);
			this.checkBoxOverrideAcquisitionCost.Name = "checkBoxOverrideAcquisitionCost";
			this.checkBoxOverrideAcquisitionCost.Size = new System.Drawing.Size(77, 16);
			this.checkBoxOverrideAcquisitionCost.TabIndex = 14;
			this.checkBoxOverrideAcquisitionCost.Text = "Override";
			this.checkBoxOverrideAcquisitionCost.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBoxOverrideAcquisitionCost.CheckedChanged += new System.EventHandler(this.checkBoxOverrideAcquisitionCost_CheckedChanged);
			// 
			// checkBoxOverrideCurrentValue
			// 
			this.checkBoxOverrideCurrentValue.BackColor = System.Drawing.SystemColors.Control;
			this.checkBoxOverrideCurrentValue.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBoxOverrideCurrentValue.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOverrideCurrentValue.Location = new System.Drawing.Point(222, 189);
			this.checkBoxOverrideCurrentValue.Name = "checkBoxOverrideCurrentValue";
			this.checkBoxOverrideCurrentValue.Size = new System.Drawing.Size(77, 16);
			this.checkBoxOverrideCurrentValue.TabIndex = 25;
			this.checkBoxOverrideCurrentValue.Text = "Override";
			this.checkBoxOverrideCurrentValue.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBoxOverrideCurrentValue.CheckedChanged += new System.EventHandler(this.checkBoxOverrideCurrentValue_CheckedChanged);
			// 
			// textBoxAcquisitionCost
			// 
			this.textBoxAcquisitionCost.Location = new System.Drawing.Point(138, 111);
			this.textBoxAcquisitionCost.MaxLength = 30;
			this.textBoxAcquisitionCost.Name = "textBoxAcquisitionCost";
			this.textBoxAcquisitionCost.Size = new System.Drawing.Size(95, 20);
			this.textBoxAcquisitionCost.TabIndex = 13;
			this.textBoxAcquisitionCost.Tag = "AC";
			this.textBoxAcquisitionCost.Text = "$0.00";
			this.textBoxAcquisitionCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAcquisitionCost.Value = new System.Decimal(new int[] {
																				 0,
																				 0,
																				 0,
																				 0});
			// 
			// textBoxRedundantAssetCount
			// 
			this.textBoxRedundantAssetCount.Location = new System.Drawing.Point(536, 11);
			this.textBoxRedundantAssetCount.MaxLength = 4;
			this.textBoxRedundantAssetCount.Name = "textBoxRedundantAssetCount";
			this.textBoxRedundantAssetCount.Size = new System.Drawing.Size(30, 20);
			this.textBoxRedundantAssetCount.TabIndex = 46;
			this.textBoxRedundantAssetCount.Text = "";
			this.textBoxRedundantAssetCount.Leave += new System.EventHandler(this.textBoxRedundantAssetCount_Leave);
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(421, 6);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(121, 30);
			this.label23.TabIndex = 45;
			this.label23.Text = "Number of Assets with Similar Functionality";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBoxReplacementENR
			// 
			this.textBoxReplacementENR.Location = new System.Drawing.Point(333, 161);
			this.textBoxReplacementENR.MaxLength = 4;
			this.textBoxReplacementENR.Name = "textBoxReplacementENR";
			this.textBoxReplacementENR.ReadOnly = true;
			this.textBoxReplacementENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxReplacementENR.TabIndex = 22;
			this.textBoxReplacementENR.TabStop = false;
			this.textBoxReplacementENR.Text = "0";
			this.textBoxReplacementENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxReplacementENR.Value = ((long)(0));
			// 
			// label32
			// 
			this.label32.Location = new System.Drawing.Point(17, 213);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(120, 16);
			this.label32.TabIndex = 26;
			this.label32.Text = "Rehabilitation Cost:";
			this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxRehabCost
			// 
			this.textBoxRehabCost.Location = new System.Drawing.Point(138, 211);
			this.textBoxRehabCost.MaxLength = 30;
			this.textBoxRehabCost.Name = "textBoxRehabCost";
			this.textBoxRehabCost.Size = new System.Drawing.Size(80, 20);
			this.textBoxRehabCost.TabIndex = 27;
			this.textBoxRehabCost.Text = "$0";
			this.textBoxRehabCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxRehabCost.Value = new System.Decimal(new int[] {
																		   0,
																		   0,
																		   0,
																		   0});
			// 
			// textBoxAcquisitionCostEscalated
			// 
			this.textBoxAcquisitionCostEscalated.Location = new System.Drawing.Point(138, 136);
			this.textBoxAcquisitionCostEscalated.MaxLength = 30;
			this.textBoxAcquisitionCostEscalated.Name = "textBoxAcquisitionCostEscalated";
			this.textBoxAcquisitionCostEscalated.ReadOnly = true;
			this.textBoxAcquisitionCostEscalated.Size = new System.Drawing.Size(80, 20);
			this.textBoxAcquisitionCostEscalated.TabIndex = 16;
			this.textBoxAcquisitionCostEscalated.Tag = "EAC";
			this.textBoxAcquisitionCostEscalated.Text = "$0";
			this.textBoxAcquisitionCostEscalated.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxAcquisitionCostEscalated.Value = new System.Decimal(new int[] {
																						  0,
																						  0,
																						  0,
																						  0});
			// 
			// label31
			// 
			this.label31.Location = new System.Drawing.Point(-14, 138);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(152, 16);
			this.label31.TabIndex = 15;
			this.label31.Text = "Escalated Acquisition Cost:";
			this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(297, 163);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(36, 16);
			this.label26.TabIndex = 21;
			this.label26.Text = "ENR:";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInstallYearENR
			// 
			this.textBoxInstallYearENR.Location = new System.Drawing.Point(251, 311);
			this.textBoxInstallYearENR.MaxLength = 4;
			this.textBoxInstallYearENR.Name = "textBoxInstallYearENR";
			this.textBoxInstallYearENR.ReadOnly = true;
			this.textBoxInstallYearENR.Size = new System.Drawing.Size(48, 20);
			this.textBoxInstallYearENR.TabIndex = 38;
			this.textBoxInstallYearENR.TabStop = false;
			this.textBoxInstallYearENR.Text = "0";
			this.textBoxInstallYearENR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxInstallYearENR.Value = ((long)(0));
			// 
			// label27
			// 
			this.label27.Location = new System.Drawing.Point(215, 313);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(36, 16);
			this.label27.TabIndex = 37;
			this.label27.Text = "ENR:";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label29
			// 
			this.label29.BackColor = System.Drawing.Color.Transparent;
			this.label29.Location = new System.Drawing.Point(24, 263);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(108, 16);
			this.label29.TabIndex = 24;
			this.label29.Text = "Repair Cost:";
			this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label35
			// 
			this.label35.BackColor = System.Drawing.Color.Transparent;
			this.label35.Location = new System.Drawing.Point(-4, 288);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(140, 16);
			this.label35.TabIndex = 27;
			this.label35.Text = "Annual &Maintenance Cost:";
			this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label36
			// 
			this.label36.BackColor = System.Drawing.Color.Transparent;
			this.label36.Location = new System.Drawing.Point(24, 238);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(108, 16);
			this.label36.TabIndex = 22;
			this.label36.Text = "Sal&vage Value:";
			this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label38
			// 
			this.label38.BackColor = System.Drawing.Color.Transparent;
			this.label38.Location = new System.Drawing.Point(28, 313);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(104, 16);
			this.label38.TabIndex = 29;
			this.label38.Text = "Installation &Year:";
			this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBoxCriticality
			// 
			this.groupBoxCriticality.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight6);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality6);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality6);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight5);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight4);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight3);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight2);
			this.groupBoxCriticality.Controls.Add(this.labelCriticalityWeight1);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality5);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality5);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality4);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality4);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality3);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality3);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality2);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality2);
			this.groupBoxCriticality.Controls.Add(this.comboBoxCriticality1);
			this.groupBoxCriticality.Controls.Add(this.labelCriticality1);
			this.groupBoxCriticality.Controls.Add(this.textBoxCritTotal);
			this.groupBoxCriticality.Controls.Add(this.labelCritTotal);
			this.groupBoxCriticality.Location = new System.Drawing.Point(416, 90);
			this.groupBoxCriticality.Name = "groupBoxCriticality";
			this.groupBoxCriticality.Size = new System.Drawing.Size(249, 314);
			this.groupBoxCriticality.TabIndex = 103;
			this.groupBoxCriticality.TabStop = false;
			this.groupBoxCriticality.Text = "Criticality";
			// 
			// labelCriticalityWeight6
			// 
			this.labelCriticalityWeight6.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight6.Location = new System.Drawing.Point(211, 241);
			this.labelCriticalityWeight6.Name = "labelCriticalityWeight6";
			this.labelCriticalityWeight6.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight6.TabIndex = 90;
			this.labelCriticalityWeight6.Text = "0%";
			this.labelCriticalityWeight6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight6.Visible = false;
			// 
			// comboBoxCriticality6
			// 
			this.comboBoxCriticality6.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality6.Location = new System.Drawing.Point(7, 257);
			this.comboBoxCriticality6.Name = "comboBoxCriticality6";
			this.comboBoxCriticality6.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality6.TabIndex = 88;
			this.comboBoxCriticality6.Visible = false;
			// 
			// labelCriticality6
			// 
			this.labelCriticality6.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality6.Location = new System.Drawing.Point(7, 241);
			this.labelCriticality6.Name = "labelCriticality6";
			this.labelCriticality6.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality6.TabIndex = 89;
			this.labelCriticality6.Text = "Criticality 6";
			this.labelCriticality6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality6.Visible = false;
			// 
			// labelCriticalityWeight5
			// 
			this.labelCriticalityWeight5.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight5.Location = new System.Drawing.Point(211, 197);
			this.labelCriticalityWeight5.Name = "labelCriticalityWeight5";
			this.labelCriticalityWeight5.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight5.TabIndex = 87;
			this.labelCriticalityWeight5.Text = "0%";
			this.labelCriticalityWeight5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight5.Visible = false;
			// 
			// labelCriticalityWeight4
			// 
			this.labelCriticalityWeight4.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight4.Location = new System.Drawing.Point(211, 153);
			this.labelCriticalityWeight4.Name = "labelCriticalityWeight4";
			this.labelCriticalityWeight4.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight4.TabIndex = 86;
			this.labelCriticalityWeight4.Text = "0%";
			this.labelCriticalityWeight4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight4.Visible = false;
			// 
			// labelCriticalityWeight3
			// 
			this.labelCriticalityWeight3.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight3.Location = new System.Drawing.Point(211, 109);
			this.labelCriticalityWeight3.Name = "labelCriticalityWeight3";
			this.labelCriticalityWeight3.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight3.TabIndex = 85;
			this.labelCriticalityWeight3.Text = "0%";
			this.labelCriticalityWeight3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelCriticalityWeight3.Visible = false;
			// 
			// labelCriticalityWeight2
			// 
			this.labelCriticalityWeight2.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight2.Location = new System.Drawing.Point(211, 65);
			this.labelCriticalityWeight2.Name = "labelCriticalityWeight2";
			this.labelCriticalityWeight2.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight2.TabIndex = 84;
			this.labelCriticalityWeight2.Text = "0%";
			this.labelCriticalityWeight2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelCriticalityWeight1
			// 
			this.labelCriticalityWeight1.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticalityWeight1.Location = new System.Drawing.Point(211, 21);
			this.labelCriticalityWeight1.Name = "labelCriticalityWeight1";
			this.labelCriticalityWeight1.Size = new System.Drawing.Size(33, 16);
			this.labelCriticalityWeight1.TabIndex = 83;
			this.labelCriticalityWeight1.Text = "0%";
			this.labelCriticalityWeight1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// comboBoxCriticality5
			// 
			this.comboBoxCriticality5.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality5.Location = new System.Drawing.Point(7, 213);
			this.comboBoxCriticality5.Name = "comboBoxCriticality5";
			this.comboBoxCriticality5.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality5.TabIndex = 80;
			this.comboBoxCriticality5.Visible = false;
			// 
			// labelCriticality5
			// 
			this.labelCriticality5.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality5.Location = new System.Drawing.Point(7, 197);
			this.labelCriticality5.Name = "labelCriticality5";
			this.labelCriticality5.Size = new System.Drawing.Size(192, 16);
			this.labelCriticality5.TabIndex = 82;
			this.labelCriticality5.Text = "Criticality 5";
			this.labelCriticality5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality5.Visible = false;
			// 
			// comboBoxCriticality4
			// 
			this.comboBoxCriticality4.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality4.Location = new System.Drawing.Point(7, 169);
			this.comboBoxCriticality4.Name = "comboBoxCriticality4";
			this.comboBoxCriticality4.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality4.TabIndex = 79;
			this.comboBoxCriticality4.Visible = false;
			// 
			// labelCriticality4
			// 
			this.labelCriticality4.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality4.Location = new System.Drawing.Point(7, 153);
			this.labelCriticality4.Name = "labelCriticality4";
			this.labelCriticality4.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality4.TabIndex = 81;
			this.labelCriticality4.Text = "Criticality 4";
			this.labelCriticality4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality4.Visible = false;
			// 
			// comboBoxCriticality3
			// 
			this.comboBoxCriticality3.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality3.Location = new System.Drawing.Point(7, 125);
			this.comboBoxCriticality3.Name = "comboBoxCriticality3";
			this.comboBoxCriticality3.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality3.TabIndex = 77;
			this.comboBoxCriticality3.Visible = false;
			// 
			// labelCriticality3
			// 
			this.labelCriticality3.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality3.Location = new System.Drawing.Point(7, 109);
			this.labelCriticality3.Name = "labelCriticality3";
			this.labelCriticality3.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality3.TabIndex = 78;
			this.labelCriticality3.Text = "Criticality 3";
			this.labelCriticality3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelCriticality3.Visible = false;
			// 
			// comboBoxCriticality2
			// 
			this.comboBoxCriticality2.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality2.Location = new System.Drawing.Point(7, 81);
			this.comboBoxCriticality2.Name = "comboBoxCriticality2";
			this.comboBoxCriticality2.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality2.TabIndex = 74;
			// 
			// labelCriticality2
			// 
			this.labelCriticality2.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality2.Location = new System.Drawing.Point(7, 65);
			this.labelCriticality2.Name = "labelCriticality2";
			this.labelCriticality2.Size = new System.Drawing.Size(192, 16);
			this.labelCriticality2.TabIndex = 76;
			this.labelCriticality2.Text = "Criticality 2";
			this.labelCriticality2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxCriticality1
			// 
			this.comboBoxCriticality1.BackColor = System.Drawing.Color.White;
			this.comboBoxCriticality1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCriticality1.Location = new System.Drawing.Point(7, 37);
			this.comboBoxCriticality1.Name = "comboBoxCriticality1";
			this.comboBoxCriticality1.Size = new System.Drawing.Size(236, 21);
			this.comboBoxCriticality1.TabIndex = 73;
			// 
			// labelCriticality1
			// 
			this.labelCriticality1.BackColor = System.Drawing.Color.Transparent;
			this.labelCriticality1.Location = new System.Drawing.Point(7, 21);
			this.labelCriticality1.Name = "labelCriticality1";
			this.labelCriticality1.Size = new System.Drawing.Size(188, 16);
			this.labelCriticality1.TabIndex = 75;
			this.labelCriticality1.Text = "Criticality 1";
			this.labelCriticality1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// textBoxCritTotal
			// 
			this.textBoxCritTotal.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxCritTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.textBoxCritTotal.Location = new System.Drawing.Point(101, 287);
			this.textBoxCritTotal.Name = "textBoxCritTotal";
			this.textBoxCritTotal.ReadOnly = true;
			this.textBoxCritTotal.Size = new System.Drawing.Size(44, 20);
			this.textBoxCritTotal.TabIndex = 9;
			this.textBoxCritTotal.TabStop = false;
			this.textBoxCritTotal.Tag = "OCRIT";
			this.textBoxCritTotal.Text = "";
			// 
			// labelCritTotal
			// 
			this.labelCritTotal.BackColor = System.Drawing.Color.Transparent;
			this.labelCritTotal.Location = new System.Drawing.Point(4, 289);
			this.labelCritTotal.Name = "labelCritTotal";
			this.labelCritTotal.Size = new System.Drawing.Size(96, 16);
			this.labelCritTotal.TabIndex = 8;
			this.labelCritTotal.Text = "Overall Criticality:";
			this.labelCritTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxVulnerability
			// 
			this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxVulnerability.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxVulnerability.Cursor = System.Windows.Forms.Cursors.Help;
			this.textBoxVulnerability.Location = new System.Drawing.Point(113, 19);
			this.textBoxVulnerability.MaxLength = 4;
			this.textBoxVulnerability.Name = "textBoxVulnerability";
			this.textBoxVulnerability.Size = new System.Drawing.Size(28, 13);
			this.textBoxVulnerability.TabIndex = 52;
			this.textBoxVulnerability.Tag = "VULN";
			this.textBoxVulnerability.Text = "";
			this.textBoxVulnerability.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxVulnerability_KeyPress);
			this.textBoxVulnerability.TextChanged += new System.EventHandler(this.textBoxVulnerability_TextChanged);
			this.textBoxVulnerability.Leave += new System.EventHandler(this.textBoxVulnerability_Leave);
			// 
			// textBoxRisk
			// 
			this.textBoxRisk.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.textBoxRisk.Location = new System.Drawing.Point(101, 48);
			this.textBoxRisk.Name = "textBoxRisk";
			this.textBoxRisk.ReadOnly = true;
			this.textBoxRisk.Size = new System.Drawing.Size(44, 20);
			this.textBoxRisk.TabIndex = 55;
			this.textBoxRisk.TabStop = false;
			this.textBoxRisk.Tag = "RISK";
			this.textBoxRisk.Text = "";
			// 
			// pictureBoxVulnerabilitySelect
			// 
			this.pictureBoxVulnerabilitySelect.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxVulnerabilitySelect.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxVulnerabilitySelect.Image")));
			this.pictureBoxVulnerabilitySelect.Location = new System.Drawing.Point(149, 18);
			this.pictureBoxVulnerabilitySelect.Name = "pictureBoxVulnerabilitySelect";
			this.pictureBoxVulnerabilitySelect.Size = new System.Drawing.Size(16, 16);
			this.pictureBoxVulnerabilitySelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxVulnerabilitySelect.TabIndex = 93;
			this.pictureBoxVulnerabilitySelect.TabStop = false;
			this.pictureBoxVulnerabilitySelect.Click += new System.EventHandler(this.buttonVulnerabilitySelect_Click);
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Location = new System.Drawing.Point(19, 19);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(80, 16);
			this.label13.TabIndex = 50;
			this.label13.Text = "Vulnerability:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Location = new System.Drawing.Point(11, 48);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(80, 16);
			this.label14.TabIndex = 54;
			this.label14.Text = "Risk:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxOverrideVulnerability
			// 
			this.checkBoxOverrideVulnerability.BackColor = System.Drawing.SystemColors.Control;
			this.checkBoxOverrideVulnerability.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.checkBoxOverrideVulnerability.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOverrideVulnerability.Location = new System.Drawing.Point(173, 19);
			this.checkBoxOverrideVulnerability.Name = "checkBoxOverrideVulnerability";
			this.checkBoxOverrideVulnerability.Size = new System.Drawing.Size(61, 16);
			this.checkBoxOverrideVulnerability.TabIndex = 53;
			this.checkBoxOverrideVulnerability.Text = "Override";
			this.checkBoxOverrideVulnerability.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBoxOverrideVulnerability.CheckedChanged += new System.EventHandler(this.checkBoxOverrideVulnerability_CheckedChanged);
			// 
			// buttonVulnerabilitySelect
			// 
			this.buttonVulnerabilitySelect.BackColor = System.Drawing.SystemColors.Control;
			this.buttonVulnerabilitySelect.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.buttonVulnerabilitySelect.Location = new System.Drawing.Point(149, 18);
			this.buttonVulnerabilitySelect.Name = "buttonVulnerabilitySelect";
			this.buttonVulnerabilitySelect.Size = new System.Drawing.Size(16, 16);
			this.buttonVulnerabilitySelect.TabIndex = 43;
			this.buttonVulnerabilitySelect.Text = "n";
			this.buttonVulnerabilitySelect.Visible = false;
			this.buttonVulnerabilitySelect.Click += new System.EventHandler(this.buttonVulnerabilitySelect_Click);
			// 
			// textBoxVulnerabilityBackground
			// 
			this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxVulnerabilityBackground.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.textBoxVulnerabilityBackground.Location = new System.Drawing.Point(101, 16);
			this.textBoxVulnerabilityBackground.MaxLength = 4;
			this.textBoxVulnerabilityBackground.Name = "textBoxVulnerabilityBackground";
			this.textBoxVulnerabilityBackground.ReadOnly = true;
			this.textBoxVulnerabilityBackground.Size = new System.Drawing.Size(44, 20);
			this.textBoxVulnerabilityBackground.TabIndex = 51;
			this.textBoxVulnerabilityBackground.TabStop = false;
			this.textBoxVulnerabilityBackground.Text = "0.";
			this.textBoxVulnerabilityBackground.Enter += new System.EventHandler(this.textBoxVulnerabilityBackground_Enter);
			// 
			// groupBoxVulnRisk
			// 
			this.groupBoxVulnRisk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxVulnRisk.Controls.Add(this.textBoxVulnerability);
			this.groupBoxVulnRisk.Controls.Add(this.label13);
			this.groupBoxVulnRisk.Controls.Add(this.label14);
			this.groupBoxVulnRisk.Controls.Add(this.pictureBoxVulnerabilitySelect);
			this.groupBoxVulnRisk.Controls.Add(this.textBoxRisk);
			this.groupBoxVulnRisk.Controls.Add(this.checkBoxOverrideVulnerability);
			this.groupBoxVulnRisk.Controls.Add(this.buttonVulnerabilitySelect);
			this.groupBoxVulnRisk.Controls.Add(this.textBoxVulnerabilityBackground);
			this.groupBoxVulnRisk.Location = new System.Drawing.Point(416, 406);
			this.groupBoxVulnRisk.Name = "groupBoxVulnRisk";
			this.groupBoxVulnRisk.Size = new System.Drawing.Size(249, 78);
			this.groupBoxVulnRisk.TabIndex = 104;
			this.groupBoxVulnRisk.TabStop = false;
			// 
			// PipeDetailForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(669, 528);
			this.Controls.Add(this.groupBoxVulnRisk);
			this.Controls.Add(this.groupBoxCriticality);
			this.Controls.Add(this.textBoxRedundantAssetCount);
			this.Controls.Add(this.textBoxInstallYearENR);
			this.Controls.Add(this.textBoxReplacementENR);
			this.Controls.Add(this.textBoxReplacementValueYear);
			this.Controls.Add(this.textBoxReplacementValue);
			this.Controls.Add(this.textBoxInstallYear);
			this.Controls.Add(this.textBoxRehabCost);
			this.Controls.Add(this.textBoxAcquisitionCostEscalated);
			this.Controls.Add(this.textBoxAcquisitionCost);
			this.Controls.Add(this.textBoxCurrentValue);
			this.Controls.Add(this.textBoxRepairCost);
			this.Controls.Add(this.textBoxSize);
			this.Controls.Add(this.textBoxERUL);
			this.Controls.Add(this.textBoxSalvageValue);
			this.Controls.Add(this.textBoxAnnualMaintenanceCost);
			this.Controls.Add(this.textBoxIDNumber);
			this.Controls.Add(this.textBoxDescription);
			this.Controls.Add(this.textBoxOriginalUL);
			this.Controls.Add(this.textBoxType);
			this.Controls.Add(this.textBoxUnitCost);
			this.Controls.Add(this.textBoxLength);
			this.Controls.Add(this.label27);
			this.Controls.Add(this.label26);
			this.Controls.Add(this.label32);
			this.Controls.Add(this.label31);
			this.Controls.Add(this.label23);
			this.Controls.Add(this.checkBoxOverrideCurrentValue);
			this.Controls.Add(this.checkBoxOverrideAcquisitionCost);
			this.Controls.Add(this.label22);
			this.Controls.Add(this.label21);
			this.Controls.Add(this.checkBoxOverrideRepairCost);
			this.Controls.Add(this.label20);
			this.Controls.Add(this.label30);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.label19);
			this.Controls.Add(this.comboBoxConditionRanking);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.comboBoxLOS);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label24);
			this.Controls.Add(this.label25);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.label29);
			this.Controls.Add(this.label35);
			this.Controls.Add(this.label36);
			this.Controls.Add(this.label38);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "DataDefinitions.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "PipeDetailForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Pipe Information";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PipeDetailForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.PipeDetailForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.c1Report1)).EndInit();
			this.groupBoxCriticality.ResumeLayout(false);
			this.groupBoxVulnRisk.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		public static bool	ShowForm(PipeData pipeData, Form owner)
		{
			PipeDetailForm form = new PipeDetailForm();

			form.m_pipeData = (PipeData)pipeData.Clone();

			if (form.ShowDialog(owner) == DialogResult.OK)
			{
				pipeData.CopyFrom(form.m_pipeData);
				return true;
			}

			return false;
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			try
			{
				//mam 050806
				isInitialized = false;

				LoadConditionRankBox();
				LoadLOS();
				LoadCriticalityBoxes();

				//mam - removed Vulnerability combo box from form
				//LoadVulnerability();
				//</mam>

				textBoxIDNumber.Text = m_pipeData.IDNumber;
				textBoxDescription.Text = m_pipeData.Description;
				textBoxType.Text = m_pipeData.Type;
				textBoxSize.Text = m_pipeData.Size;
				textBoxLength.Value = m_pipeData.Length;
				textBoxUnitCost.Value = m_pipeData.UnitCost;
				textBoxReplacementValue.Value = m_pipeData.ReplacementValue;
				textBoxReplacementValueYear.Text = m_pipeData.ReplacementValueYear.ToString();
				textBoxSalvageValue.Value = m_pipeData.SalvageValue;
				textBoxAnnualMaintenanceCost.Value = m_pipeData.AnnualMaintCost;

				//mam
				checkBoxOverrideVulnerability.Checked = m_pipeData.OverrideVulnerability;
				//textBoxVulnerability.Text = m_pipeData.Vulnerability2.ToString();
				textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_pipeData.Vulnerability2.ToString());
				//</mam>

				//mam 050806
				textBoxReplacementENR.Value = m_pipeData.GetENRValueForYear(Convert.ToInt16(textBoxReplacementValueYear.Text));
				checkBoxOverrideRepairCost.Checked = m_pipeData.OverrideRepairCost;
				checkBoxOverrideAcquisitionCost.Checked = m_pipeData.OverrideAcquisitionCost;
				checkBoxOverrideCurrentValue.Checked = m_pipeData.OverrideCurrentValue;
				textBoxRedundantAssetCount.Text = m_pipeData.RedundantAssetCount.ToString("0");

				//mam 07072011 - move this down so it can be set after the InstallYear gets set
				//textBoxInstallYearENR.Value = m_pipeData.GetENRValueForYear(Convert.ToInt16(m_pipeData.InstallYear));

				//mam - use facility current year for install year on new pipe
				if (m_pipeData.ID == 0)
				{
					Discipline discipline = CacheManager.GetDiscipline(InfoSet.CurrentID, m_pipeData.DiscPipeID, DisciplineType.Pipes);
					Facility facility = discipline.GetFacility();
					textBoxInstallYear.Value = facility.CurrentYear;

					//mam 07072011 - if the m_pipeData.ID is 0, then this is not an existing pipe, so set the crits to the defaults in the combo boxes
					//	and populate the crit collection for this pipe
					SelectDefaultValuesInCritCombo();
					m_pipeData.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();
				}
					//</mam>
				else
				{
					textBoxInstallYear.Value = m_pipeData.InstallYear;
				}

				//mam 07072011 - install year may have changed, so set it in the pipe object
				m_pipeData.InstallYear = Convert.ToInt16(textBoxInstallYear.Value);

				//mam 07072011 - moved down from above
				textBoxInstallYearENR.Value = m_pipeData.GetENRValueForYear(Convert.ToInt16(m_pipeData.InstallYear));

				textBoxOriginalUL.Value = m_pipeData.OrgUsefulLife;

				//mam
				this.textBoxERUL.Text = m_pipeData.GetEvaluatedRemainingUsefulLife().ToString();
				//</mam>

				//mam 050806
				if (m_pipeData.ConditionRank == CondRank.No && !checkBoxOverrideRepairCost.Checked)
				{
					textBoxRepairCost.Text = "N/A";
				}
				else
				{
					textBoxRepairCost.Value = m_pipeData.GetRepairCost();
					localRepairCost = textBoxRepairCost.Value;
				}

				//mam 050806
				textBoxAcquisitionCost.Value = m_pipeData.AcquisitionCost;
				localAcquisitionCost = textBoxAcquisitionCost.Value;

				//mam 112806 - commented
				//textBoxCurrentValue.Value = m_pipeData.GetCurrentValue();
				//localCurrentValue = textBoxCurrentValue.Value;

				//mam 112806 - added
				if (m_pipeData.ConditionRank == CondRank.No && !checkBoxOverrideCurrentValue.Checked)
				{
					textBoxCurrentValue.Text = "N/A";
				}
				else
				{
					textBoxCurrentValue.Value = m_pipeData.GetCurrentValue();
					localCurrentValue = textBoxCurrentValue.Value;
				}

				textBoxRehabCost.Value = m_pipeData.RehabCost;
				textBoxAcquisitionCostEscalated.Value = m_pipeData.AcquisitionCostEscalated;

				SelectConditionRank();
				SelectLOS();
				SelectCriticality();

				//mam - removed Vulnerability combo box from form
				//SelectVulnerability();
				//</mam>

				//mam
				SetToolTips();
				SetBitmaps();
				SetHelp();

				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				commonTasks.LoadHelpImage(pictureBoxHelp);
				commonTasks = null;
				//</mam>

				m_suppressUpdates = false;
				UpdateCriticality();
				UpdateVulnerability();

				if (this.checkBoxOverrideVulnerability.Checked)
				{
					this.textBoxVulnerability.ReadOnly = false;
					this.buttonVulnerabilitySelect.Enabled = true;
					this.pictureBoxVulnerabilitySelect.Visible = true;

					//have to manually set the background color of the text box because
					//	the background color was set to 'Window' on the form, which is
					//	the default, but now the text box won't turn grey when it is read only
					textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
					textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;
				}
				else
				{
					this.textBoxVulnerability.ReadOnly = true;
					this.buttonVulnerabilitySelect.Enabled = false;
					this.pictureBoxVulnerabilitySelect.Visible = false;

					//have to manually set the background color of the text box because
					//	the background color was set to 'Window' on the form, which is
					//	the default, but now the text box won't turn grey when it is read only
					textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
					textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;
				}
				textBoxCritTotal.BackColor = System.Drawing.SystemColors.Control;

				//mam 050806
				if (this.checkBoxOverrideRepairCost.Checked)
				{
					this.textBoxRepairCost.ReadOnly = false;
					textBoxRepairCost.BackColor = System.Drawing.SystemColors.Window;
				}
				else
				{
					this.textBoxRepairCost.ReadOnly = true;
					textBoxRepairCost.BackColor = System.Drawing.SystemColors.Control;
				}

				//mam 050806
				if (this.checkBoxOverrideAcquisitionCost.Checked)
				{
					this.textBoxAcquisitionCost.ReadOnly = false;
					textBoxAcquisitionCost.BackColor = System.Drawing.SystemColors.Window;
				}
				else
				{
					this.textBoxAcquisitionCost.ReadOnly = true;
					textBoxAcquisitionCost.BackColor = System.Drawing.SystemColors.Control;
				}

				//mam 050806
				if (this.checkBoxOverrideCurrentValue.Checked)
				{
					this.textBoxCurrentValue.ReadOnly = false;
					textBoxCurrentValue.BackColor = System.Drawing.SystemColors.Window;
				}
				else
				{
					this.textBoxCurrentValue.ReadOnly = true;
					textBoxCurrentValue.BackColor = System.Drawing.SystemColors.Control;
				}

				//mam 12192011
				SetReadOnlyTextBoxBackgroundColor(textBoxVulnerability);
				SetReadOnlyTextBoxBackgroundColor(textBoxRepairCost);
				SetReadOnlyTextBoxBackgroundColor(textBoxAcquisitionCost);
				SetReadOnlyTextBoxBackgroundColor(textBoxCurrentValue);

				//mam 050806
				this.textBoxReplacementValue.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxReplacementValueYear.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxRepairCost.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxAcquisitionCost.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxCurrentValue.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxInstallYear.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxLength.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxUnitCost.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxRehabCost.Leave += new System.EventHandler(this.TextBoxLeave);
				this.textBoxInstallYear.Leave += new System.EventHandler(this.TextBoxLeave);

				//mam - disable controls if infoset is fixed
				SetControls();
				DisableControls();
				//</mam>

				//mam 050806
				textBoxIDNumber.Focus();
				textBoxIDNumber.SelectionLength = 0;

				//mam 07072011 - set the handler for the SelectedIndexChanged event for all crit dropdowns
				this.comboBoxCriticality1.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
				this.comboBoxCriticality2.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
				this.comboBoxCriticality3.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
				this.comboBoxCriticality4.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
				this.comboBoxCriticality5.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);
				this.comboBoxCriticality6.SelectedIndexChanged += new EventHandler(this.OnChangeCriticality);

				//mam 12192011
				//text boxes that are always read only - numeric
				if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
				{
					Color backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorNumeric;
					textBoxAcquisitionCostEscalated.BackColor = backgroundColor;
					textBoxReplacementENR.BackColor = backgroundColor;
					textBoxInstallYearENR.BackColor = backgroundColor;
					textBoxERUL.BackColor = backgroundColor;
					textBoxCritTotal.BackColor = backgroundColor;
					textBoxRisk.BackColor = backgroundColor;
				}

				//mam 12192011
				//text boxes that are always read only - asset names
				if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames)
				{
					Color backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames;
				}

				//mam 0122201 - let's not change the color of the screen - the result varies depending on the selected theme
				//mam 12192011
				//screen background
				//if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen)
				//{
				//	Color backgroundColor = WAM.Common.Globals.ReadOnlyBackgroundColorScreen;
				//	this.BackColor = backgroundColor;
				//}

				base.OnLoad(e);
			}
			catch
			{
			}
			finally
			{
				//mam 050806
				isInitialized = true;
			}
		}

		private void		LoadConditionRankBox()
		{
			comboBoxConditionRanking.BeginUpdate();
			comboBoxConditionRanking.DisplayMember = "DisplayMember";
			comboBoxConditionRanking.Items.Clear();

			//mam - include N/A option in Condition combo box
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.No),
				CondRank.No));
			//</mam>

			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C0),
				CondRank.C0));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C1),
				CondRank.C1));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C2),
				CondRank.C2));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C3),
				CondRank.C3));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C4),
				CondRank.C4));
			comboBoxConditionRanking.Items.Add(
				new ListItem(EnumHandlers.GetConditionRankString(CondRank.C5),
				CondRank.C5));
			comboBoxConditionRanking.EndUpdate();
		}

		private void		SelectConditionRank()
		{
			for (int pos = 0; pos < comboBoxConditionRanking.Items.Count; pos++)
			{
				if (m_pipeData.ConditionRank == 
					((CondRank)((ListItem)comboBoxConditionRanking.Items[pos]).Value))
				{
					comboBoxConditionRanking.SelectedIndex = pos;
					return;
				}
			}

			comboBoxConditionRanking.SelectedIndex = 0;
		}

		private CondRank	GetSelectedConditionRanking()
		{
			ListItem		listItem = comboBoxConditionRanking.SelectedItem as ListItem;

			if (listItem == null)
				//mam - return CondRank.No instead of CondRank.C0 when listItem is null
				//return CondRank.C0;
				return CondRank.No;
				//</mam>

			return (CondRank)listItem.Value;
		}

		private void		LoadLOS()
		{
			int				pos;
			LevelOfService[] losValues = 
				(LevelOfService[])Enum.GetValues(typeof(LevelOfService));

			comboBoxLOS.BeginUpdate();
			comboBoxLOS.DisplayMember = "DisplayMember";
			comboBoxLOS.Items.Clear();
			for (pos = 0; pos < losValues.Length; pos++)
			{
				//mam - include description with LOS number
				//original code:
				//comboBoxLOS.Items.Add(new ListItem(
				//	EnumHandlers.GetLOSShort(losValues[pos]),
				//	losValues[pos]));
				//new code:
				comboBoxLOS.Items.Add(new ListItem(
					EnumHandlers.GetLOSString(losValues[pos]),
					losValues[pos]));
				//</mam>
			}
			comboBoxLOS.EndUpdate();
		}

		private void		LoadCriticalityBoxes()
		{
			//mam 07072011
			WAM.Common.CommonTasks.LoadCriticalityComboBoxes(comboBoxCriticality1, comboBoxCriticality2
				, comboBoxCriticality3, comboBoxCriticality4, comboBoxCriticality5, comboBoxCriticality6
				, labelCriticality1, labelCriticality2, labelCriticality3
				, labelCriticality4, labelCriticality5, labelCriticality6
				, labelCriticalityWeight1, labelCriticalityWeight2, labelCriticalityWeight3
				, labelCriticalityWeight4, labelCriticalityWeight5, labelCriticalityWeight6);

			

			//mam 07072011 - no longer using four fixed crits
//			int pos;
//			// Public Health and Safety
//			CriticalityPublicHealth[] critHealthValues = 
//				(CriticalityPublicHealth[])Enum.GetValues(
//				typeof(CriticalityPublicHealth));
//			comboBoxCritHealth.BeginUpdate();
//			comboBoxCritHealth.DisplayMember = "DisplayMember";
//			comboBoxCritHealth.Items.Clear();
//			for (pos = 0; pos < critHealthValues.Length; pos++)
//			{
//				//mam - get AssocValue in addition to text description
//				//original code:
//				//comboBoxCritHealth.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritPublicHealthString(
//				//	critHealthValues[pos]),
//				//	critHealthValues[pos]));
//				//new code:
//				comboBoxCritHealth.Items.Add(new ListItem(
//					EnumHandlers.GetCritPublicHealthStringAssocValue(
//					critHealthValues[pos]),
//					critHealthValues[pos]));
//				//</mam>
//			}
//			comboBoxCritHealth.EndUpdate();
//
//			// Environmental
//			CriticalityEnvironmental[] critEnvValues = 
//				(CriticalityEnvironmental[])Enum.GetValues(
//				typeof(CriticalityEnvironmental));
//			comboBoxCritEnv.BeginUpdate();
//			comboBoxCritEnv.DisplayMember = "DisplayMember";
//			comboBoxCritEnv.Items.Clear();
//			for (pos = 0; pos < critEnvValues.Length; pos++)
//			{
//				//mam - get AssocValue in addition to text description
//				//original code:
//				//comboBoxCritEnv.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritEnvironmentalString(
//				//	critEnvValues[pos]),
//				//	critEnvValues[pos]));
//				//new code:
//				comboBoxCritEnv.Items.Add(new ListItem(
//					EnumHandlers.GetCritEnvironmentalStringAssocValue(
//					critEnvValues[pos]),
//					critEnvValues[pos]));
//				//</mam>
//			}
//			comboBoxCritEnv.EndUpdate();
//
//			// Cost of Repair
//			CriticalityRepairCost[] critRepairValues = 
//				(CriticalityRepairCost[])Enum.GetValues(
//				typeof(CriticalityRepairCost));
//			comboBoxCritRepairCost.BeginUpdate();
//			comboBoxCritRepairCost.DisplayMember = "DisplayMember";
//			comboBoxCritRepairCost.Items.Clear();
//			for (pos = 0; pos < critRepairValues.Length; pos++)
//			{
//				//mam - get AssocValue in addition to text description
//				//original code:
//				//comboBoxCritRepairCost.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritRepairCostString(
//				//	critRepairValues[pos]),
//				//	critRepairValues[pos]));
//				//new code:
//				comboBoxCritRepairCost.Items.Add(new ListItem(
//					EnumHandlers.GetCritRepairCostStringAssocValue(
//					critRepairValues[pos]),
//					critRepairValues[pos]));
//				//</mam>
//			}
//			comboBoxCritRepairCost.EndUpdate();
//
//			// Customer Effect
//			CriticalityCustomerEffect[] critCustEffectValues = 
//				(CriticalityCustomerEffect[])Enum.GetValues(
//				typeof(CriticalityCustomerEffect));
//			comboBoxCritCustEffect.BeginUpdate();
//			comboBoxCritCustEffect.DisplayMember = "DisplayMember";
//			comboBoxCritCustEffect.Items.Clear();
//			for (pos = 0; pos < critCustEffectValues.Length; pos++)
//			{
//				//mam - get AssocValue in addition to text description
//				//original code:
//				//comboBoxCritCustEffect.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritCustomerEffectString(
//				//	critCustEffectValues[pos]),
//				//	critCustEffectValues[pos]));
//				//new code:
//				comboBoxCritCustEffect.Items.Add(new ListItem(
//					EnumHandlers.GetCritCustomerEffectStringAssocValue(
//					critCustEffectValues[pos]),
//					critCustEffectValues[pos]));
//				//</mam>
//			}
//			comboBoxCritCustEffect.EndUpdate();
		}

		//mam - removed Vulnerability combo box from form
//		private void		LoadVulnerability()
//		{
//			int				pos;
//			Vulnerability[] vulnerabilityValues = 
//				(Vulnerability[])Enum.GetValues(typeof(Vulnerability));
//
//			// Add vulnerabilities
//			comboBoxVulnerability.BeginUpdate();
//			comboBoxVulnerability.DisplayMember = "DisplayMember";
//			comboBoxVulnerability.Items.Clear();
//			for (pos = 0; pos < vulnerabilityValues.Length; pos++)
//			{
//				//mam - get AssocValue in addition to text description
//				//original code:
//				//comboBoxVulnerability.Items.Add(new ListItem(
//				//	EnumHandlers.GetVulnerabilityString(vulnerabilityValues[pos]),
//				//	vulnerabilityValues[pos]));
//				//new code:
//				comboBoxVulnerability.Items.Add(new ListItem(
//					EnumHandlers.GetVulnerabilityStringAssocValue(vulnerabilityValues[pos]),
//					vulnerabilityValues[pos]));
//				//</mam>
//			}
//			comboBoxVulnerability.EndUpdate();
//		}
		//</mam>

		private void		SelectLOS()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxLOS.Items.Count; pos++)
			{
				item = comboBoxLOS.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((LevelOfService)item.Value == m_pipeData.LevelOfService)
				{
					comboBoxLOS.SelectedIndex = pos;
					return;
				}
			}
		}

		//mam 07072011 - new method
		//when the Add Pipe button is clicked, the Pipe screen opens, with the crit combo boxes already populated, but no selections made
		//select the default values so the user has something to start with
		private void SelectDefaultValuesInCritCombo()
		{
			ListItem item;

			if (comboBoxCriticality1.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality1.Items.Count; i++)
				{
					item = comboBoxCriticality1.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality1.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality2.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality2.Items.Count; i++)
				{
					item = comboBoxCriticality2.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality2.SelectedIndex = i;
						break;
					}
				}
			}
			if (comboBoxCriticality3.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality3.Items.Count; i++)
				{
					item = comboBoxCriticality3.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality3.SelectedIndex = i;
						break;
					}
				}
			}
			if (comboBoxCriticality4.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality4.Items.Count; i++)
				{
					item = comboBoxCriticality4.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality4.SelectedIndex = i;
						break;
					}
				}
			}
			if (comboBoxCriticality5.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality5.Items.Count; i++)
				{
					item = comboBoxCriticality5.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality5.SelectedIndex = i;
						break;
					}
				}
			}
			if (comboBoxCriticality6.Tag != null)
			{
				for (int i = 0; i < comboBoxCriticality6.Items.Count; i++)
				{
					item = comboBoxCriticality6.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).UseAsDefaultScore == true)
					{
						comboBoxCriticality6.SelectedIndex = i;
						break;
					}
				}
			}

			return;
			//******************************************************************
			
//			int critId = 0;
//			Common.Criticality selCritFactor = new Common.Criticality();
//			if (comboBoxCriticality1.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality1.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality1.Items.Count; i++)
//				{
//					item = comboBoxCriticality1.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality1.SelectedIndex = i;
//						break;
//					}
//				}
//			}
//
//			if (comboBoxCriticality2.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality2.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality2.Items.Count; i++)
//				{
//					item = comboBoxCriticality2.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality2.SelectedIndex = i;
//						break;
//					}
//				}
//			}
//
//			if (comboBoxCriticality3.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality3.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality3.Items.Count; i++)
//				{
//					item = comboBoxCriticality3.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality3.SelectedIndex = i;
//						break;
//					}
//				}
//			}
//
//			if (comboBoxCriticality4.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality4.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality4.Items.Count; i++)
//				{
//					item = comboBoxCriticality4.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality4.SelectedIndex = i;
//						break;
//					}
//				}
//			}
//
//			if (comboBoxCriticality5.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality5.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality5.Items.Count; i++)
//				{
//					item = comboBoxCriticality5.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality5.SelectedIndex = i;
//						break;
//					}
//				}
//			}
//
//			if (comboBoxCriticality6.Tag != null)
//			{
//				critId = ((Common.Criticality)comboBoxCriticality6.Tag).CriticalityId;
//				//selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
//				selCritFactor = Common.CommonTasks.Criticalities.ItemById(critId);
//				for (int i = 0; i < comboBoxCriticality6.Items.Count; i++)
//				{
//					item = comboBoxCriticality6.Items[i] as ListItem;
//					if (item == null)
//						continue;
//
//					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CriticalityFactors.GetDefaultFactorId())
//					{
//						comboBoxCriticality6.SelectedIndex = i;
//						break;
//					}
//				}
//			}
		}

		private void SelectCriticality()
		{
			//mam 07072011 - no longer using four fixed criticalities
			//SelectCritPublicHealthAndSafety();
			//SelectCritEnvironmental();
			//SelectCritCostOfRepair();
			//SelectCritEffectOnCustomers();

			//mam 07072011 - all code below is new to this method

			ListItem item;
			int critId = 0;
			Common.MajorComponentSelectedCriticalityFactors selCritFactor = new Common.MajorComponentSelectedCriticalityFactors();
			if (comboBoxCriticality1.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality1.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality1.Items.Count; i++)
				{
					item = comboBoxCriticality1.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality1.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality2.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality2.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality2.Items.Count; i++)
				{
					item = comboBoxCriticality2.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality2.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality3.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality3.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality3.Items.Count; i++)
				{
					item = comboBoxCriticality3.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality3.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality4.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality4.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality4.Items.Count; i++)
				{
					item = comboBoxCriticality4.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality4.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality5.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality5.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality5.Items.Count; i++)
				{
					item = comboBoxCriticality5.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality5.SelectedIndex = i;
						break;
					}
				}
			}

			if (comboBoxCriticality6.Tag != null)
			{
				critId = ((Common.Criticality)comboBoxCriticality6.Tag).CriticalityId;
				selCritFactor = m_pipeData.ComponentSelectedCriticalityFactorsCollection.ItemById(critId);
				for (int i = 0; i < comboBoxCriticality6.Items.Count; i++)
				{
					item = comboBoxCriticality6.Items[i] as ListItem;
					if (item == null)
						continue;

					if (((Common.CriticalityFactor)item.Value).FactorId == selCritFactor.CritFactor.FactorId)
					{
						comboBoxCriticality6.SelectedIndex = i;
						break;
					}
				}
			}
		}

		//mam 07072011 - no longer using four fixed crits
//		private void		SelectCritPublicHealthAndSafety()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			for (pos = 0; pos < comboBoxCritHealth.Items.Count; pos++)
//			{
//				item = comboBoxCritHealth.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityPublicHealth)item.Value == m_pipeData.CritPublicHealth)
//				{
//					comboBoxCritHealth.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using four fixed crits
//		private void		SelectCritEnvironmental()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			for (pos = 0; pos < comboBoxCritEnv.Items.Count; pos++)
//			{
//				item = comboBoxCritEnv.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityEnvironmental)item.Value == m_pipeData.CritEnvironmental)
//				{
//					comboBoxCritEnv.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using four fixed crits
//		private void		SelectCritCostOfRepair()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			for (pos = 0; pos < comboBoxCritRepairCost.Items.Count; pos++)
//			{
//				item = comboBoxCritRepairCost.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityRepairCost)item.Value == m_pipeData.CritRepair)
//				{
//					comboBoxCritRepairCost.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam 07072011 - no longer using four fixed crits
//		private void		SelectCritEffectOnCustomers()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			for (pos = 0; pos < comboBoxCritCustEffect.Items.Count; pos++)
//			{
//				item = comboBoxCritCustEffect.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((CriticalityCustomerEffect)item.Value == m_pipeData.CritCustEffect)
//				{
//					comboBoxCritCustEffect.SelectedIndex = pos;
//					return;
//				}
//			}
//		}

		//mam - removed Vulnerability combo box from form
//		private void		SelectVulnerability()
//		{
//			int				pos = 0;
//			ListItem		item;
//
//			for (pos = 0; pos < comboBoxVulnerability.Items.Count; pos++)
//			{
//				item = comboBoxVulnerability.Items[pos] as ListItem;
//				if (item == null)
//					continue;
//
//				if ((Vulnerability)item.Value == m_pipeData.Vulnerability)
//				{
//					comboBoxVulnerability.SelectedIndex = pos;
//					return;
//				}
//			}
//		}
		//</mam>

		//mam 050806
		private void UpdateAcquisitionCost()
		{
			if (!m_pipeData.OverrideAcquisitionCost)
			{
				textBoxAcquisitionCost.Value = m_pipeData.AcquisitionCost;
			}
			UpdateAcquisitionCostEscalated();
			UpdateCurrentValue();
		}

		//mam 050806
		private void UpdateAcquisitionCostEscalated()
		{
			textBoxAcquisitionCostEscalated.Value = m_pipeData.AcquisitionCostEscalated;
		}

		//mam 050806
		private void UpdateCurrentValue()
		{
			//mam 112806 - commented
			//if (!m_pipeData.OverrideCurrentValue)
			//{
			//	textBoxCurrentValue.Value = m_pipeData.GetCurrentValue();
			//}

			//mam 112806 - added
			if (!m_pipeData.OverrideCurrentValue)
			{
				if (m_pipeData.ConditionRank == CondRank.No)
				{
					textBoxCurrentValue.Text = "N/A";
				}
				else
				{
					textBoxCurrentValue.Value = m_pipeData.GetCurrentValue();
				}
			}

			UpdateRepairCost();
		}

		private void		UpdateCriticality()
		{
			if (m_pipeData == null)
				return;

			// Take the sum of the criticality items
			textBoxCritTotal.Text = m_pipeData.GetOverallCriticality().ToString();

			UpdateRisk();
		}

		private void		UpdateRisk()
		{
			if (m_pipeData.ConditionRank == CondRank.No && !m_pipeData.OverrideVulnerability)
			{
				textBoxRisk.Text = "N/A";
			}
			else
			{
				textBoxRisk.Text = string.Format("{0:F2}", m_pipeData.GetRisk());
			}
		}

		//mam 050806
		private void UpdateRepairCost()
		{
			if (m_pipeData.OverrideRepairCost)
				return;

			if (m_pipeData.ConditionRank == CondRank.No)
			{
				textBoxRepairCost.Text = "N/A";
			}
			else
			{
				textBoxRepairCost.Text = m_pipeData.GetRepairCost().ToString("$#,##0");
			}
		}

		//mam
		private void UpdateVulnerability()
		{
			//textBoxVulnerability.Text = string.Format("{0}", m_pipeData.GetVulnerability());
			if (m_pipeData.OverrideVulnerability)
				return;

			if (m_pipeData.ConditionRank == CondRank.No || textBoxERUL.Text == "0")
			{
				textBoxVulnerability.Text = "N/A";
				m_pipeData.Vulnerability2 = 0.0;

				//mam 07072011
				//textBoxVulnerability.Location = new System.Drawing.Point(495, textBoxVulnerabilityBackground.Location.Y + 3);
				textBoxVulnerability.Location = new System.Drawing.Point(textBoxVulnerabilityBackground.Location.X + 3, textBoxVulnerabilityBackground.Location.Y + 3);
			}
			else
			{
				double tempERUL = m_pipeData.GetEvaluatedRemainingUsefulLife();

				if (tempERUL <= 1)
					textBoxVulnerability.Text = "9";
				else if (tempERUL <= 2)
					textBoxVulnerability.Text = "7";
				else if (tempERUL <= 3)
					textBoxVulnerability.Text = "4";
				else if (tempERUL <= 5)
					textBoxVulnerability.Text = "2";
				else
				{
					textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_pipeData.GetVulnerability().ToString());
				}
				m_pipeData.Vulnerability2 = Convert.ToDouble("0." + textBoxVulnerability.Text);

				//mam 07072011
				//textBoxVulnerability.Location = new System.Drawing.Point(504, textBoxVulnerabilityBackground.Location.Y + 3);
				textBoxVulnerability.Location = new System.Drawing.Point(textBoxVulnerabilityBackground.Location.X + 12, textBoxVulnerabilityBackground.Location.Y + 3);
			}
			UpdateRisk();
		}
		//</mam>

		private void OnChangeCriticality(object sender, System.EventArgs e)
		{
			if (m_suppressUpdates)
				return;

			//mam 07072011 - no longer using four fixed crits
//			// Update public health
//			if (comboBoxCritHealth.SelectedItem != null)
//			{
//				CriticalityPublicHealth	health = (CriticalityPublicHealth)
//					((ListItem)comboBoxCritHealth.SelectedItem).Value;
//				m_pipeData.CritPublicHealth = health;
//			}

			//mam 07072011 - no longer using four fixed crits
//			// Update environmental
//			if (comboBoxCritEnv.SelectedItem != null)
//			{
//				CriticalityEnvironmental env = (CriticalityEnvironmental)
//					((ListItem)comboBoxCritEnv.SelectedItem).Value;
//				m_pipeData.CritEnvironmental = env;
//			}

			//mam 07072011 - no longer using four fixed crits
//			// Update crit cost of Repairs
//			if (comboBoxCritRepairCost.SelectedItem != null)
//			{
//				CriticalityRepairCost repair = (CriticalityRepairCost)
//					((ListItem)comboBoxCritRepairCost.SelectedItem).Value;
//				m_pipeData.CritRepair = repair;
//			}

			//mam 07072011 - no longer using four fixed crits
//			// Update Effect on Customers
//			if (comboBoxCritCustEffect.SelectedItem != null)
//			{
//				CriticalityCustomerEffect custEffect = (CriticalityCustomerEffect)
//					((ListItem)comboBoxCritCustEffect.SelectedItem).Value;
//				m_pipeData.CritCustEffect = custEffect;
//			}

			//mam 07072011 - new way to set crit values in component based on changes in combo box
			ComboBox curComboBox = (ComboBox)sender;
			ListItem listItem = (ListItem)curComboBox.SelectedItem;
			Common.Criticality curCrit = (Common.Criticality)curComboBox.Tag;
			Common.CriticalityFactor curCritFactor = (Common.CriticalityFactor)listItem.Value;

			for (int i = 0; i < m_pipeData.ComponentSelectedCriticalityFactorsCollection.Count; i++)
			{
				if (curCrit.CriticalityId == m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CriticalityId)
				{
					m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorId = curCritFactor.FactorId;
					m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorName = curCritFactor.FactorName;
					m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorOrderBy = curCritFactor.FactorOrderBy;
					m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.ScoreId = curCritFactor.ScoreId;
					m_pipeData.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.Score = curCritFactor.Score;

					break;
				}
			}

			UpdateCriticality();
		}

		private void OnChangeLOS(object sender, System.EventArgs e)
		{
			if (m_suppressUpdates)
				return;

			LevelOfService	los = (LevelOfService)((ListItem)comboBoxLOS.SelectedItem).Value;
			m_pipeData.LevelOfService = los;

			//mam 050806
			UpdateRepairCost();
		}

		//mam - removed Vulnerability combo box from form
//		private void OnChangeVulnerability(object sender, System.EventArgs e)
//		{
//			if (m_suppressUpdates)
//				return;
//
//			Vulnerability	vuln = (Vulnerability)((ListItem)comboBoxVulnerability.SelectedItem).Value;
//			m_pipeData.Vulnerability = vuln;
//
//			UpdateRisk();
//		}
		//</mam>

		private void buttonSave_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to save data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			m_pipeData.ConditionRank = GetSelectedConditionRanking();
			m_pipeData.IDNumber = textBoxIDNumber.Text;
			m_pipeData.Description = textBoxDescription.Text;
			m_pipeData.Type = textBoxType.Text;
			m_pipeData.Size = textBoxSize.Text;
			m_pipeData.Length = (int)textBoxLength.Value;
			m_pipeData.UnitCost = textBoxUnitCost.Value;
			m_pipeData.ReplacementValue = textBoxReplacementValue.Value;

			//mam 050806
			m_pipeData.ReplacementValueYear = textBoxReplacementValueYear.Text.Length > 0? Convert.ToInt32(textBoxReplacementValueYear.Text): 0;

			m_pipeData.SalvageValue = textBoxSalvageValue.Value;
			m_pipeData.AnnualMaintCost = textBoxAnnualMaintenanceCost.Value;
			m_pipeData.InstallYear = (short)textBoxInstallYear.Value;
			m_pipeData.OrgUsefulLife = (short)textBoxOriginalUL.Value;

			//mam
			//m_pipeData.Vulnerability2 = Convert.ToDouble(textBoxVulnerability.Text);
			if (textBoxVulnerability.Text == "N/A")
				m_pipeData.Vulnerability2 = 0.0;
			else
				m_pipeData.Vulnerability2 = Convert.ToDouble("0." + textBoxVulnerability.Text);
			//</mam>

			//mam 050806
			if (textBoxRepairCost.Text.Length == 0 || textBoxRepairCost.Text == "N/A")
				m_pipeData.RepairCost = 0.0M;
			else
				m_pipeData.RepairCost = textBoxRepairCost.Value;
			m_pipeData.AcquisitionCost = textBoxAcquisitionCost.Value;

			//mam 112806 - commented
			//m_pipeData.CurrentValue = textBoxCurrentValue.Value;

			//mam 112806 - added
			if (textBoxCurrentValue.Text.Length == 0 || textBoxCurrentValue.Text == "N/A")
				m_pipeData.CurrentValue = 0.0M;
			else
				m_pipeData.CurrentValue = textBoxCurrentValue.Value;

			m_pipeData.RehabCost = textBoxRehabCost.Value;

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		//mam
		private void textBoxVulnerability_TextChanged(object sender, System.EventArgs e)
		{
			if (m_suppressUpdates)
				return;

			//******************************
			bool changedText = false;
			string currentText = this.Text;
			string correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				if (allowedChar.IndexOf(currentText.Substring(i, 1)) == -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				this.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxVulnerability.SelectionStart = currentPos;
			}
			//******************************

			try    
			{
				m_pipeData.Vulnerability2 = Convert.ToDouble("0." + textBoxVulnerability.Text);
			}
			catch (FormatException)    
			{
				m_pipeData.Vulnerability2 = 0.0;
			}

			UpdateRisk();
		}
		//</mam>

		//mam
		private void textBoxVulnerability_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxVulnerability.SelectionStart;
			existingText = textBoxVulnerability.Text;

			if (allowedChar.IndexOf(e.KeyChar) < 0)
			{
				e.Handled = true;
			}
		}
		//</mam>

		//mam
		private void txtMessage(int selIndex)
		{
			selectedVulnerability = selIndex;
		}

		private void comboBoxConditionRanking_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			m_pipeData.ConditionRank = GetSelectedConditionRanking();
			if (m_pipeData.ConditionRank == CondRank.No)
			{
				this.textBoxERUL.Text = "N/A";
			}
			else
			{
				if (m_pipeData.OrgUsefulLife == 0)
					this.textBoxERUL.Text = "0";
				else
					this.textBoxERUL.Text = m_pipeData.GetEvaluatedRemainingUsefulLife().ToString();
			}
			
			UpdateVulnerability();
			UpdateRisk();

			//mam 050806
			UpdateAcquisitionCost();
			UpdateRepairCost();
		}

		private void SetReadOnlyProps(object sender, bool isReadOnly)
		{
			if (isReadOnly)
			{
				if (((CheckBox)sender).Name == checkBoxOverrideVulnerability.Name)
				{
					this.textBoxVulnerability.ReadOnly = true;
					this.buttonVulnerabilitySelect.Enabled = false;
					this.pictureBoxVulnerabilitySelect.Visible = false;
					this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
					this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;
					if (textBoxVulnerability.Text == "N/A")
					{
						//mam 07072011
						//this.textBoxVulnerability.Location = new System.Drawing.Point(495, textBoxVulnerabilityBackground.Location.Y + 3);
						this.textBoxVulnerability.Location = new System.Drawing.Point(textBoxVulnerabilityBackground.Location.X + 3, textBoxVulnerabilityBackground.Location.Y + 3);
					}
					else
					{
						//mam 07072011
						//this.textBoxVulnerability.Location = new System.Drawing.Point(504, textBoxVulnerabilityBackground.Location.Y + 3);
						this.textBoxVulnerability.Location = new System.Drawing.Point(textBoxVulnerabilityBackground.Location.X + 12, textBoxVulnerabilityBackground.Location.Y + 3);
					}

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxVulnerability);
				}
				else if (((CheckBox)sender).Name == checkBoxOverrideRepairCost.Name)
				{
					this.textBoxRepairCost.ReadOnly = true;
					this.textBoxRepairCost.BackColor = System.Drawing.SystemColors.Control;

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxRepairCost);
				}
				else if (((CheckBox)sender).Name == checkBoxOverrideAcquisitionCost.Name)
				{
					this.textBoxAcquisitionCost.ReadOnly = true;
					this.textBoxAcquisitionCost.BackColor = System.Drawing.SystemColors.Control;

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxAcquisitionCost);
				}				
				else if (((CheckBox)sender).Name == checkBoxOverrideCurrentValue.Name)
				{
					this.textBoxCurrentValue.ReadOnly = true;
					this.textBoxCurrentValue.BackColor = System.Drawing.SystemColors.Control;

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxCurrentValue);
				}
			}
			else
			{
				if (((CheckBox)sender).Name == checkBoxOverrideVulnerability.Name)
				{
					this.textBoxVulnerability.ReadOnly = false;
					this.buttonVulnerabilitySelect.Enabled = true;
					this.pictureBoxVulnerabilitySelect.Visible = true;
					this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Window;
					this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Window;

					//mam 07072011
					//this.textBoxVulnerability.Location = new System.Drawing.Point(504, textBoxVulnerabilityBackground.Location.Y + 3);
					this.textBoxVulnerability.Location = new System.Drawing.Point(textBoxVulnerabilityBackground.Location.X + 12, textBoxVulnerabilityBackground.Location.Y + 3);

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxVulnerability);
				}
				else if (((CheckBox)sender).Name == checkBoxOverrideRepairCost.Name)
				{
					this.textBoxRepairCost.ReadOnly = false;
					this.textBoxRepairCost.BackColor = System.Drawing.SystemColors.Window;
					
					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxRepairCost);
				}
				else if (((CheckBox)sender).Name == checkBoxOverrideAcquisitionCost.Name)
				{
					this.textBoxAcquisitionCost.ReadOnly = false;
					this.textBoxAcquisitionCost.BackColor = System.Drawing.SystemColors.Window;

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxAcquisitionCost);
				}				
				else if (((CheckBox)sender).Name == checkBoxOverrideCurrentValue.Name)
				{
					this.textBoxCurrentValue.ReadOnly = false;
					this.textBoxCurrentValue.BackColor = System.Drawing.SystemColors.Window;

					//mam 12192011
					SetReadOnlyTextBoxBackgroundColor(textBoxCurrentValue);
				}
			}

			//mam - disable controls if infoset is fixed
			//if (InfoSet.IsFixed)
				DisableControls();
			//</mam>
		}

		//mam 12192011
		private void SetReadOnlyTextBoxBackgroundColor(TextBox sender)
		{
			if (WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric)
			{
				sender.BackColor = sender.ReadOnly ? WAM.Common.Globals.ReadOnlyBackgroundColorNumeric : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				if (sender.Name == this.textBoxVulnerability.Name)
				{
					textBoxVulnerabilityBackground.BackColor = sender.ReadOnly ? WAM.Common.Globals.ReadOnlyBackgroundColorNumeric : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				}
			}
			//mam 01222012
			else
			{
				sender.BackColor = sender.ReadOnly ? Color.FromKnownColor(System.Drawing.KnownColor.Control) : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				if (sender.Name == this.textBoxVulnerability.Name)
				{
					textBoxVulnerabilityBackground.BackColor = sender.ReadOnly ? Color.FromKnownColor(System.Drawing.KnownColor.Control) : Color.FromKnownColor(System.Drawing.KnownColor.Window);
				}
			}
		}

		//mam 050806
		private void checkBoxOverrideRepairCost_CheckedChanged(object sender, System.EventArgs e)
		{
			if (!isInitialized)
			{
				return;
			}

			m_pipeData.OverrideRepairCost = checkBoxOverrideRepairCost.Checked;

			if (checkBoxOverrideRepairCost.Checked)
			{
				SetReadOnlyProps(sender, false);

				//if (textBoxRepairCost.Text == "N/A")
				//{
				//	//this.textBoxRepairCost.Text = "0";
					this.textBoxRepairCost.Text = localRepairCost.ToString("$#,##0");
				//}

				this.textBoxRepairCost.Focus();
			}
			else
			{
				try
				{
					if (m_pipeData.ConditionRank == CondRank.No)
					{
						textBoxRepairCost.Text = "N/A";
						//m_pipeData.Vulnerability2 = 0.0;
					}
					else
					{
						//MessageBox.Show("calculating Repair Cost");
						textBoxRepairCost.Text = m_pipeData.GetRepairCost().ToString("$#,##0");
					}
				}
				catch
				{
					this.textBoxRepairCost.Text = "N/A";
					//m_pipeData.Vulnerability2 = 0.0;
				}

				SetReadOnlyProps(sender, true);
			}
		}

		//mam 050806
		private void checkBoxOverrideAcquisitionCost_CheckedChanged(object sender, System.EventArgs e)
		{
			if (!isInitialized)
			{
				return;
			}

			m_pipeData.OverrideAcquisitionCost = checkBoxOverrideAcquisitionCost.Checked;

			if (checkBoxOverrideAcquisitionCost.Checked)
			{
				SetReadOnlyProps(sender, false);

				m_pipeData.AcquisitionCost = localAcquisitionCost;
				this.textBoxAcquisitionCost.Text = localAcquisitionCost.ToString("$#,##0.00");
				this.textBoxAcquisitionCost.Focus();
			}
			else
			{
				textBoxAcquisitionCost.Text = m_pipeData.AcquisitionCost.ToString("$#,##0.00");
				SetReadOnlyProps(sender, true);
			}
			UpdateAcquisitionCostEscalated();
			UpdateCurrentValue();
		}

		//mam 050806
		private void checkBoxOverrideCurrentValue_CheckedChanged(object sender, System.EventArgs e)
		{
			if (!isInitialized)
			{
				return;
			}

			m_pipeData.OverrideCurrentValue = checkBoxOverrideCurrentValue.Checked;

			if (checkBoxOverrideCurrentValue.Checked)
			{
				SetReadOnlyProps(sender, false);

				m_pipeData.CurrentValue = localCurrentValue;
				this.textBoxCurrentValue.Text = localCurrentValue.ToString("$#,##0");
				this.textBoxCurrentValue.Focus();
			}
			else
			{
				//mam 112806 - commented
				//textBoxCurrentValue.Text = m_pipeData.GetCurrentValue().ToString("$#,##0");

				//mam 112806 - added
				try
				{
					if (m_pipeData.ConditionRank == CondRank.No)
					{
						textBoxCurrentValue.Text = "N/A";
					}
					else
					{
						textBoxCurrentValue.Text = m_pipeData.GetCurrentValue().ToString("$#,##0");
					}
				}
				catch
				{
					this.textBoxCurrentValue.Text = "N/A";
				}

				SetReadOnlyProps(sender, true);
			}

			UpdateRepairCost();
		}

		private void checkBoxOverrideVulnerability_CheckedChanged(object sender, System.EventArgs e)
		{
			//mam 050806
			if (!isInitialized)
			{
				return;
			}

			m_pipeData.OverrideVulnerability = checkBoxOverrideVulnerability.Checked;

			if (checkBoxOverrideVulnerability.Checked)
			{
				SetReadOnlyProps(sender, false);

				if (textBoxVulnerability.Text == "N/A")
				{
					this.textBoxVulnerability.Text = "0";
					m_pipeData.Vulnerability2 = 0.0;
				}

				this.textBoxVulnerability.Focus();
			}
			else
			{
				try
				{
					//this.textBoxVulnerability.Text = Convert.ToString(Math.Round(1 / Convert.ToDouble(textBoxERUL.Text), 4));
					if (m_pipeData.GetEvaluatedRemainingUsefulLife() == 0)
					{
						textBoxVulnerability.Text = "N/A";
						m_pipeData.Vulnerability2 = 0.0;
					}
					else
					{
						string tempString = Convert.ToString(Math.Round(1 / Convert.ToDouble(textBoxERUL.Text), 4));
						this.textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(tempString);
						m_pipeData.Vulnerability2 = Convert.ToDouble("0." + textBoxVulnerability.Text);
					}
				}
				catch
				{
					this.textBoxVulnerability.Text = "N/A";
					m_pipeData.Vulnerability2 = 0.0;
				}

				SetReadOnlyProps(sender, true);
			}

			UpdateRisk();
		}

		private void buttonVulnerabilitySelect_Click(object sender, System.EventArgs e)
		{
			selectedVulnerability = -1;
			PipeDetailVulnerability pipeDetailVulnerability = new PipeDetailVulnerability();
			pipeDetailVulnerability.OnMessage += new PipeDetailVulnerability.Message(this.txtMessage);
			pipeDetailVulnerability.ShowDialog();

			if (pipeDetailVulnerability.DialogResult == DialogResult.OK)
			{
				//if (m_suppressUpdates)
				//	return;

				checkBoxOverrideVulnerability.Checked = true;
				//textBoxVulnerability.Text = (EnumHandlers.GetVulnerabilityValue((Vulnerability)selectedVulnerability)).ToString();
				string tempString = (EnumHandlers.GetVulnerabilityValue((Vulnerability)selectedVulnerability)).ToString();
				textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(tempString);
			}
		}
		//</mam>

		//mam - because ERUL is now shown on this form, it needs to be recalculated
		//	when the Original UL changes
		private void textBoxOriginalUL_TextChanged(object sender, System.EventArgs e)
		{
			try
			{
				m_pipeData.OrgUsefulLife = Convert.ToInt16(textBoxOriginalUL.Text);
			}
			catch
			{
				m_pipeData.OrgUsefulLife = 0;
			}

			if (m_pipeData.ConditionRank == CondRank.No)
			{
				this.textBoxERUL.Text = "N/A";
			}
			else
			{
				this.textBoxERUL.Text = m_pipeData.GetEvaluatedRemainingUsefulLife().ToString();
			}
			
			UpdateVulnerability();
		}

		//mam 050806
		private void TextBoxLeave(object sender, System.EventArgs e)
		{
			//mam 050806
			if (((TextBox)sender).Name == textBoxReplacementValue.Name)
			{
				//textBoxReplacementValue.Text = Drive.Convert.StringToShort(textBoxReplacementValue.Text.ToString()).ToString();
				textBoxReplacementValue.Text = textBoxReplacementValue.Value.ToString("$#,##0");
				m_pipeData.ReplacementValue = textBoxReplacementValue.Value;
				UpdateAcquisitionCost();
			}
			else if (((TextBox)sender).Name == textBoxReplacementValueYear.Name)
			{
				textBoxReplacementValueYear.Text = Drive.Convert.StringToShort(textBoxReplacementValueYear.Text.ToString()).ToString();
				m_pipeData.ReplacementValueYear = Convert.ToInt32(textBoxReplacementValueYear.Text);

				//mam 050806
				textBoxReplacementENR.Text = m_pipeData.GetENRValueForYear(
					Convert.ToInt16(m_pipeData.ReplacementValueYear)).ToString();

				UpdateAcquisitionCost();
			}
			else if (((TextBox)sender).Name == textBoxRepairCost.Name)
			{
				if (!textBoxRepairCost.ReadOnly)
				{
					localRepairCost = textBoxRepairCost.Value;
					m_pipeData.RepairCost = textBoxRepairCost.Value;
					textBoxRepairCost.Text = textBoxRepairCost.Value.ToString("$#,##0");
				}
			}
			else if (((TextBox)sender).Name == textBoxAcquisitionCost.Name)
			{
				if (!textBoxAcquisitionCost.ReadOnly)
				{
					localAcquisitionCost = textBoxAcquisitionCost.Value;
					textBoxAcquisitionCost.Text = textBoxAcquisitionCost.Value.ToString("$#,##0.00");
					m_pipeData.AcquisitionCost = textBoxAcquisitionCost.Value;
					UpdateAcquisitionCost();
				}
			}			

			//mam 050806
			else if (((TextBox)sender).Name == textBoxRehabCost.Name)
			{
				m_pipeData.RehabCost = textBoxRehabCost.Value;
				textBoxRehabCost.Text = textBoxRehabCost.Value.ToString("$#,##0");
				UpdateAcquisitionCost();
			}			

			else if (((TextBox)sender).Name == textBoxCurrentValue.Name)
			{
				if (!textBoxCurrentValue.ReadOnly)
				{
					localCurrentValue = textBoxCurrentValue.Value;
					textBoxCurrentValue.Text = textBoxCurrentValue.Value.ToString("$#,##0");
					m_pipeData.CurrentValue = textBoxCurrentValue.Value;
					UpdateRepairCost();
				}
			}
			else if (((TextBox)sender).Name == textBoxInstallYear.Name)
			{
				//mam 050806 - call Drive.Convert and then update textBoxInstallYearENR
				//m_pipeData.InstallYear = (short)textBoxInstallYear.Value;
				textBoxInstallYear.Text = Drive.Convert.StringToShort(textBoxInstallYear.Text.ToString()).ToString();
				m_pipeData.InstallYear = (short)textBoxInstallYear.Value;
				textBoxInstallYearENR.Text = m_pipeData.GetENRValueForYear(
					Convert.ToInt16(m_pipeData.InstallYear)).ToString();

				UpdateAcquisitionCost();
			}
			else if (((TextBox)sender).Name == textBoxLength.Name)
			{
				m_pipeData.Length = (int)textBoxLength.Value;
				UpdateAcquisitionCost();
			}			
			else if (((TextBox)sender).Name == textBoxUnitCost.Name)
			{
				m_pipeData.UnitCost = (decimal)textBoxUnitCost.Value;
				UpdateAcquisitionCost();
			}

			//mam 050806
			else if (((TextBox)sender).Name == textBoxRehabCost.Name)
			{
				m_pipeData.RehabCost = textBoxRehabCost.Value;
				UpdateCurrentValue();
			}
		}

		private void textBoxVulnerabilityBackground_Enter(object sender, System.EventArgs e)
		{
			textBoxVulnerability.Focus();
		}

		private void textBoxVulnerability_Leave(object sender, System.EventArgs e)
		{
			//mam - added N/A condition
			if (textBoxVulnerability.Text == "N/A")
				return;
			//</mam>

			if (textBoxVulnerability.Text == "" || Double.Parse(textBoxVulnerability.Text) == 0)
				m_pipeData.Vulnerability2 = 0.0;

			textBoxVulnerability.Text = WAM.Common.CommonTasks.SplitVulnerability(m_pipeData.Vulnerability2.ToString());
		}

		private void SetHelp()
		{
//			foreach (Control formControl in this.Controls)
//			{
//				//MessageBox.Show(formControl.Name.ToString());
//				if (formControl is TextBox)
//					//((TextBox)formControl).help
//					//textBoxIDNumber.h
//					
//				else if (formControl is CheckBox)
//					((CheckBox)formControl).Enabled = !isFixedInfoset;
//				else if (formControl is GroupBox)
//					((GroupBox)formControl).Enabled = !isFixedInfoset;
//				else if (formControl is ComboBox)
//					continue;
//				else if (formControl is TabControl)
//					continue;
//				else
//					formControl.Enabled = !isFixedInfoset;
//			}
		}

		private void SetToolTips()
		{
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			toolTip.AutoPopDelay = 2500;
			toolTip.InitialDelay = 500;
			toolTip.ReshowDelay = 0;

			//toolTip.AutoPopDelay = 0;
			//toolTip.InitialDelay = 0;
			//toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.checkBoxOverrideVulnerability, "Override calculated Vulnerability");
			toolTip.SetToolTip(this.buttonVulnerabilitySelect, "Select Vulnerability");
			toolTip.SetToolTip(this.pictureBoxVulnerabilitySelect, "Select Vulnerability");
		}

		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)pictureBoxVulnerabilitySelect.Image;
			//b.MakeTransparent(System.Drawing.Color.FromArgb(239, 237, 222));
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxVulnerabilitySelect.Image = b;
			//239,237,222
		}

		//mam
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;

			textBoxERUL.ReadOnly = true;
			textBoxRisk.ReadOnly = true;
			textBoxCritTotal.ReadOnly = true;

			//mam 050806
			textBoxAcquisitionCostEscalated.ReadOnly = true;
			textBoxReplacementENR.ReadOnly = true;
			
			buttonSave.Enabled = !isFixedInfoset;
			DisableControls();

			//mam 07072011
			//int critCount = ComponentSelectedCriticalityFactorsCollection.Count;
			int critCount = Common.CommonTasks.Criticalities.Count;
			int comboTop = ((critCount - 1) * 44) + 37;
			groupBoxCriticality.Height = comboTop + 57;
			labelCritTotal.Top = comboTop + 31;
			textBoxCritTotal.Top = comboTop + 29;
			groupBoxVulnRisk.Top = groupBoxCriticality.Bottom + 2;
			this.Height = groupBoxVulnRisk.Bottom + 76;
		}
		//</mam>

		//mam
		private void DisableControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;

			this.textBoxVulnerability.ReadOnly = isFixedInfoset;
			this.textBoxVulnerabilityBackground.ReadOnly = isFixedInfoset;
			this.pictureBoxVulnerabilitySelect.Visible = !isFixedInfoset;

			//mam 050806
			this.textBoxRepairCost.ReadOnly = isFixedInfoset;
			this.textBoxAcquisitionCost.ReadOnly = isFixedInfoset;
			this.textBoxCurrentValue.ReadOnly = isFixedInfoset;

			//mam 012307
			checkBoxOverrideRepairCost.Enabled = !isFixedInfoset;
			textBoxReplacementValueYear.ReadOnly = isFixedInfoset;
			this.textBoxRehabCost.ReadOnly = isFixedInfoset;

			if (isFixedInfoset)
			{
				this.textBoxVulnerability.BackColor = System.Drawing.SystemColors.Control;
				this.textBoxVulnerabilityBackground.BackColor = System.Drawing.SystemColors.Control;

				//mam 050806
				this.textBoxRepairCost.BackColor = System.Drawing.SystemColors.Control;
				this.textBoxAcquisitionCost.BackColor = System.Drawing.SystemColors.Control;
				this.textBoxCurrentValue.BackColor = System.Drawing.SystemColors.Control;
			}
		}
		//</mam>

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)MainForm.AppForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			//((MainForm)parentForm).PinEquation(eqn);
			((MainForm)MainForm.AppForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)MainForm.AppForm).ClearEquationTextBox();
		}

		private void PipeDetailForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "PipeDetail.htm");
		}
		//</mam>

		//mam
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "PipeDetail.htm");
		}

		private void PipeDetailForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				e.Handled = true;
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		//mam 050806
		private void textBoxRedundantAssetCount_Leave(object sender, System.EventArgs e)
		{
			int newValue = 1;
			try
			{
				newValue = Int32.Parse(textBoxRedundantAssetCount.Text, System.Globalization.NumberStyles.Integer);
			}
			catch
			{
			}

			if (newValue < 1)
			{
				newValue = 1;
			}

			textBoxRedundantAssetCount.Text = newValue.ToString("0");
			m_pipeData.RedundantAssetCount = newValue;
			//m_pipeData.Save();
			UpdateCriticality();
		}
		//</mam>

		#endregion /***** Methods *****/
	}
}