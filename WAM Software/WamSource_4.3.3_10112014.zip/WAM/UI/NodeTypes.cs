using System;
using WAM.Data;

namespace WAM.UI
{
	public enum			NodeType
	{
		InfoSet,
		Facility,
		TreatmentProcess,
		MajorComponent,
		DisciplineMech,
		DisciplineStruct,
		DisciplineLand,
		DisciplinePipe,
		DisciplineNode,
		AssetList,

		//mam 03202012
		ImportFormat,

		NoneSelected = 255,
	}

	//mam
	//class NodeTypeHandler
	public class NodeTypeHandler
	{
//		//mam
//		public enum			NodeTypeReport
//		{
//			Facility,
//			TreatmentProcess,
//			MajorComponent,
//			DisciplineMech,
//			DisciplineStruct,
//			DisciplineLand,
//			DisciplinePipe,
//			DisciplineNode,
//			ComponentAsset
//		}
//		//</mam>

		//mam
		public enum			NodeTypeReport
		{
			Facility = 0,
			TreatmentProcess = 1,
			MajorComponent = 2,
			Discipline = 3,
			DisciplineMech = 4,
			DisciplineStruct = 5,
			DisciplineLand = 6,
			DisciplinePipe = 7,
			DisciplineNode = 8,
			ComponentAsset = 9,

			//mam 03202012
			ImportFormat = 10,
		}
		//</mam>

//		//mam
//		public static string GetNodeTypeStringReport(NodeTypeReport rank)
//		{
//			switch (rank)
//			{
//				case NodeTypeReport.Facility:
//					return "Facility / System";
//				case NodeTypeReport.TreatmentProcess:
//					return "Process / Basin / Zone";
//				case NodeTypeReport.MajorComponent:
//					return "Component / Subbasin / Subzone";
//				case NodeTypeReport.DisciplineMech:
//					return "Mechanical / Electrical / Instrumentation / Piping";
//				case NodeTypeReport.DisciplineStruct:
//					return "Structural / Architectural";
//				case NodeTypeReport.DisciplineLand:
//					return "Site Improvements / Landscaping / Other";
//				case NodeTypeReport.DisciplinePipe:
//					return "Pipe";
//				case NodeTypeReport.DisciplineNode:
//					return "Nodes / Appurtenances";
//				case NodeTypeReport.ComponentAsset:
//					return "Asset List";
//			}
//
//			return "N/A";
//		}
//		//</mam>

		//mam
		public static string GetNodeTypeStringReport(NodeTypeReport rank)
		{
			switch (rank)
			{
				case NodeTypeReport.Facility:
					return "Facility / System";
				case NodeTypeReport.TreatmentProcess:
					return "Process / Basin / Zone";
				case NodeTypeReport.MajorComponent:
					return "Component / Subbasin / Subzone";
				case NodeTypeReport.Discipline:
					return "Discipline: All";
				case NodeTypeReport.DisciplineMech:
					//return "Mechanical / Electrical / Instrumentation / Piping";
					return "Discipline: Mech / Elec / Instr / Piping";
				case NodeTypeReport.DisciplineStruct:
					//return "Structural / Architectural";
					return "Discipline: Struct / Arch";
				case NodeTypeReport.DisciplineLand:
					//return "Site Improvements / Landscaping / Other";
					//return "Discipline: Site / Land / Other";
					return "Discipline: Civil / Sitework";
				case NodeTypeReport.DisciplinePipe:
					return "Discipline: Pipes";
				case NodeTypeReport.DisciplineNode:
					return "Discipline: Nodes / Appurtenances";
				case NodeTypeReport.ComponentAsset:
					return "Asset List";

				//mam 03202012
				case NodeTypeReport.ImportFormat:
					return "Excel Import Format";
			}

			return "N/A";
		}
		//</mam>

		public static string GetNodeTypeString(NodeType rank)
		{
			switch (rank)
			{
				case NodeType.InfoSet:
					return "InfoSet";
				case NodeType.Facility:
					return "Facility / System";
				case NodeType.TreatmentProcess:
					return "Process / Basin / Zone";
				case NodeType.MajorComponent:
					return "Component / Subbasin / Subzone";
				case NodeType.DisciplineMech:
					return "Mechanical / Electrical / Instrumentation / Piping";
				case NodeType.DisciplineStruct:
					return "Structural / Architectural";
				case NodeType.DisciplineLand:
					//return "Site Improvements / Landscaping / Other";
					return "Civil / Sitework";
				case NodeType.DisciplinePipe:
					//mam - changed from "Pipe" to "Pipes"
					return "Pipes";
				case NodeType.DisciplineNode:
					return "Nodes / Appurtenances";
				case NodeType.AssetList:
					return "Asset List";

				//mam 03202012
				case NodeType.ImportFormat:
					return "Excel Import Format";
			}

			return "N/A";
		}

		public static bool	IsNodeTypeSameAsDisciplineType(NodeType type, WAM.Data.DisciplineType discType)
		{
			if (type == NodeType.DisciplineMech && discType == DisciplineType.Mechanical)
				return true;
			if (type == NodeType.DisciplineStruct && discType == DisciplineType.Structural)
				return true;
			if (type == NodeType.DisciplineLand && discType == DisciplineType.Land)
				return true;
			if (type == NodeType.DisciplinePipe && discType == DisciplineType.Pipes)
				return true;
			if (type == NodeType.DisciplineNode && discType == DisciplineType.Nodes)
				return true;

			return false;
		}

		//mam
		public static string GetNodeType(string rank)
		{
			switch (rank)
			{
				case "InfoSet":
					return NodeType.InfoSet.ToString();
				case "Facility / System":
					return NodeType.Facility.ToString();
				case "Process / Basin / Zone":
					return NodeType.TreatmentProcess.ToString();
				case "Component / Subbasin / Subzone":
					return NodeType.MajorComponent.ToString();
				case "Mechanical / Electrical / Instrumentation / Piping":
					return NodeType.DisciplineMech.ToString();
				case "Structural / Architectural":
					return NodeType.DisciplineStruct.ToString();

				//case "Site Improvements / Landscaping / Other":
				case "Civil / Sitework":
					return NodeType.DisciplineLand.ToString();

				case "Pipes":
					//mam - changed case from "Pipe" to "Pipes"
					return NodeType.DisciplinePipe.ToString();
				case "Nodes / Appurtenances":
					return NodeType.DisciplineNode.ToString();
				case "Asset List":
					return NodeType.AssetList.ToString();

				//mam 03202012
				case "Excel Import Format":
					return NodeTypeReport.ImportFormat.ToString();
			}

			return NodeType.NoneSelected.ToString();
		}

		public static NodeType GetNodeType2(string rank)
		{
			switch (rank)
			{
				case "InfoSet":
					return NodeType.InfoSet;
				case "Facility":
					return NodeType.Facility;
				case "TreatmentProcess":
					return NodeType.TreatmentProcess;
				case "MajorComponent":
					return NodeType.MajorComponent;
				case "DisciplineMech":
					return NodeType.DisciplineMech;
				case "DisciplineStruct":
					return NodeType.DisciplineStruct;
				case "DisciplineLand":
					return NodeType.DisciplineLand;
				case "DisciplinePipe":
					return NodeType.DisciplinePipe;
				case "DisciplineNode":
					return NodeType.DisciplineNode;
				case "AssetList":
					return NodeType.AssetList;

				//mam 03202012
				case "ImportFormat":
					return NodeType.ImportFormat;
			}

			return NodeType.NoneSelected;
		}
		//</mam>

	}
}