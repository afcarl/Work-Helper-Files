using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ConstraintViewer.
	/// </summary>
	public class ConstraintViewer : System.Windows.Forms.Form
	{
		#region /***** Member variables *****/

		private int facilityId = 0;
		private int existingFacilityCurrentYear = 0;
		private string facilityName = "";

		private enum ConstraintType
		{
			RehabReplace,
			InstallYear
		}

		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridConstraintList;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Panel panel24;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Button buttonSaveToExcel;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.Label labelNoRecordsFound;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.PictureBox pictureBoxGo1;
		private System.Windows.Forms.Label labelCurrentYear;
		private System.Windows.Forms.PictureBox pictureBoxGoInstallYear;
		private System.Windows.Forms.Label labelConstraintInstallYear;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panelConstraintInstallYear;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label labelResult;
		private System.Windows.Forms.Panel panelConstraintRehab;
		private System.Windows.Forms.HelpProvider helpProvider1;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Member variables *****/

		#region /***** Construction and Disposal *****/

		public ConstraintViewer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public ConstraintViewer(int facilityId, int currentFacilityYear, string facilityName)
		{
			this.facilityId = facilityId;
			this.existingFacilityCurrentYear = currentFacilityYear;
			this.facilityName = facilityName;
			InitializeComponent();

			this.textBoxCurrentYear.Text = existingFacilityCurrentYear.ToString();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ConstraintViewer));
			this.c1FlexGridConstraintList = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.buttonOK = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.panel24 = new System.Windows.Forms.Panel();
			this.labelTitle = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonSaveToExcel = new System.Windows.Forms.Button();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.labelNoRecordsFound = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.labelCurrentYear = new System.Windows.Forms.Label();
			this.labelResult = new System.Windows.Forms.Label();
			this.pictureBoxGo1 = new System.Windows.Forms.PictureBox();
			this.pictureBoxGoInstallYear = new System.Windows.Forms.PictureBox();
			this.labelConstraintInstallYear = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.panelConstraintInstallYear = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.panelConstraintRehab = new System.Windows.Forms.Panel();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridConstraintList)).BeginInit();
			this.SuspendLayout();
			// 
			// c1FlexGridConstraintList
			// 
			this.c1FlexGridConstraintList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridConstraintList.AutoClipboard = true;
			this.c1FlexGridConstraintList.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.FixedSingle;
			this.c1FlexGridConstraintList.ColumnInfo = "2,1,0,0,0,85,Columns:0{Width:40;}\t";
			this.c1FlexGridConstraintList.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridConstraintList.Location = new System.Drawing.Point(8, 136);
			this.c1FlexGridConstraintList.Name = "c1FlexGridConstraintList";
			this.c1FlexGridConstraintList.Rows.Count = 2;
			this.c1FlexGridConstraintList.Size = new System.Drawing.Size(728, 280);
			this.c1FlexGridConstraintList.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.c1FlexGridConstraintList.TabIndex = 1;
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(664, 424);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 3;
			this.buttonOK.Text = "&Close";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(714, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 158;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(32, 291);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(656, 16);
			this.label2.TabIndex = 155;
			this.label2.Text = "label2";
			this.label2.Visible = false;
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// panel24
			// 
			this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel24.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(172)), ((System.Byte)(168)), ((System.Byte)(153)));
			this.panel24.Location = new System.Drawing.Point(0, 32);
			this.panel24.Name = "panel24";
			this.panel24.Size = new System.Drawing.Size(752, 2);
			this.panel24.TabIndex = 157;
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(744, 32);
			this.labelTitle.TabIndex = 156;
			this.labelTitle.Text = " Constraint  Viewer";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(32, 265);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(656, 16);
			this.label1.TabIndex = 154;
			this.label1.Text = "label1";
			this.label1.Visible = false;
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// buttonSaveToExcel
			// 
			this.buttonSaveToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonSaveToExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSaveToExcel.Location = new System.Drawing.Point(8, 424);
			this.buttonSaveToExcel.Name = "buttonSaveToExcel";
			this.buttonSaveToExcel.Size = new System.Drawing.Size(88, 23);
			this.buttonSaveToExcel.TabIndex = 2;
			this.buttonSaveToExcel.Text = "Save to Excel";
			this.buttonSaveToExcel.Click += new System.EventHandler(this.buttonSaveToExcel_Click);
			// 
			// radioButton1
			// 
			this.radioButton1.BackColor = System.Drawing.Color.Transparent;
			this.radioButton1.Location = new System.Drawing.Point(15, 267);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(16, 16);
			this.radioButton1.TabIndex = 160;
			this.radioButton1.Visible = false;
			this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(15, 293);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(16, 16);
			this.radioButton2.TabIndex = 161;
			this.radioButton2.Visible = false;
			// 
			// labelNoRecordsFound
			// 
			this.labelNoRecordsFound.BackColor = System.Drawing.Color.Transparent;
			this.labelNoRecordsFound.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelNoRecordsFound.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelNoRecordsFound.Location = new System.Drawing.Point(135, 206);
			this.labelNoRecordsFound.Name = "labelNoRecordsFound";
			this.labelNoRecordsFound.Size = new System.Drawing.Size(432, 88);
			this.labelNoRecordsFound.TabIndex = 162;
			this.labelNoRecordsFound.Text = "No Next Replacement Years or Next Rehabilitation Years in this Facility will be u" +
				"pdated to the proposed Facility Current Year";
			this.labelNoRecordsFound.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.labelNoRecordsFound.Visible = false;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBoxCurrentYear.Location = new System.Drawing.Point(237, 62);
			this.textBoxCurrentYear.MaxLength = 4;
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 22);
			this.textBoxCurrentYear.TabIndex = 0;
			this.textBoxCurrentYear.Text = "";
			// 
			// labelCurrentYear
			// 
			this.labelCurrentYear.BackColor = System.Drawing.Color.Transparent;
			this.labelCurrentYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelCurrentYear.Location = new System.Drawing.Point(38, 64);
			this.labelCurrentYear.Name = "labelCurrentYear";
			this.labelCurrentYear.Size = new System.Drawing.Size(192, 16);
			this.labelCurrentYear.TabIndex = 163;
			this.labelCurrentYear.Text = "Proposed Facility Current Year";
			this.labelCurrentYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelResult
			// 
			this.labelResult.BackColor = System.Drawing.Color.Transparent;
			this.labelResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelResult.Location = new System.Drawing.Point(11, 99);
			this.labelResult.Name = "labelResult";
			this.labelResult.Size = new System.Drawing.Size(693, 30);
			this.labelResult.TabIndex = 167;
			this.labelResult.Text = "If the Facility Current Year is changed to the proposed year, all of the Next Rep" +
				"lacement Years and Next Rehabilitation Years in the grid below will be changed t" +
				"o that proposed year.";
			this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pictureBoxGo1
			// 
			this.pictureBoxGo1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxGo1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGo1.Image")));
			this.pictureBoxGo1.Location = new System.Drawing.Point(292, 62);
			this.pictureBoxGo1.Name = "pictureBoxGo1";
			this.pictureBoxGo1.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxGo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxGo1.TabIndex = 168;
			this.pictureBoxGo1.TabStop = false;
			// 
			// pictureBoxGoInstallYear
			// 
			this.pictureBoxGoInstallYear.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxGoInstallYear.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGoInstallYear.Image")));
			this.pictureBoxGoInstallYear.Location = new System.Drawing.Point(15, 97);
			this.pictureBoxGoInstallYear.Name = "pictureBoxGoInstallYear";
			this.pictureBoxGoInstallYear.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxGoInstallYear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxGoInstallYear.TabIndex = 169;
			this.pictureBoxGoInstallYear.TabStop = false;
			this.pictureBoxGoInstallYear.Visible = false;
			// 
			// labelConstraintInstallYear
			// 
			this.labelConstraintInstallYear.BackColor = System.Drawing.Color.Transparent;
			this.labelConstraintInstallYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelConstraintInstallYear.Location = new System.Drawing.Point(40, 99);
			this.labelConstraintInstallYear.Name = "labelConstraintInstallYear";
			this.labelConstraintInstallYear.Size = new System.Drawing.Size(725, 16);
			this.labelConstraintInstallYear.TabIndex = 170;
			this.labelConstraintInstallYear.Text = "Display constraint violations for Installation Year <= Last Rehabilitation Year <" +
				"= Inspection Year <= Facility Current Year";
			this.labelConstraintInstallYear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelConstraintInstallYear.Visible = false;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(329, 64);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(399, 16);
			this.label6.TabIndex = 172;
			this.label6.Text = "(Clicking Go will NOT change the existing Facility Current Year)";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label6.Visible = false;
			// 
			// panelConstraintInstallYear
			// 
			this.panelConstraintInstallYear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelConstraintInstallYear.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelConstraintInstallYear.Location = new System.Drawing.Point(0, 123);
			this.panelConstraintInstallYear.Name = "panelConstraintInstallYear";
			this.panelConstraintInstallYear.Size = new System.Drawing.Size(752, 1);
			this.panelConstraintInstallYear.TabIndex = 173;
			this.panelConstraintInstallYear.Visible = false;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(11, 40);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(725, 16);
			this.label3.TabIndex = 174;
			this.label3.Text = "To see constraint violations for a proposed Facility Current Year, enter a year i" +
				"nto the box and click Go.";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelConstraintRehab
			// 
			this.panelConstraintRehab.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelConstraintRehab.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelConstraintRehab.Location = new System.Drawing.Point(0, 90);
			this.panelConstraintRehab.Name = "panelConstraintRehab";
			this.panelConstraintRehab.Size = new System.Drawing.Size(752, 1);
			this.panelConstraintRehab.TabIndex = 175;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// ConstraintViewer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(744, 454);
			this.Controls.Add(this.labelResult);
			this.Controls.Add(this.panelConstraintRehab);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.panelConstraintInstallYear);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.panel24);
			this.Controls.Add(this.pictureBoxGo1);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.c1FlexGridConstraintList);
			this.Controls.Add(this.labelCurrentYear);
			this.Controls.Add(this.labelNoRecordsFound);
			this.Controls.Add(this.buttonSaveToExcel);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.radioButton2);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.radioButton1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxGoInstallYear);
			this.Controls.Add(this.labelConstraintInstallYear);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ConstraintViewer";
			this.Text = "ConstraintViewer";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ConstraintViewer_Paint);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridConstraintList)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			InitializeControls();

			base.OnLoad(e);
		}

		private void InitializeControls()
		{
			try
			{
				this.Text = "Constraint Viewer";
				this.CenterToParent();
				labelTitle.Text = " Constraint Viewer for " + facilityName;

				this.pictureBoxGo1.Click += new System.EventHandler(this.pictureBoxGo1_Click);
				this.pictureBoxGoInstallYear.Click += new System.EventHandler(this.pictureBoxGoInstallYear_Click);
				//this.textBoxCurrentYear.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCurrentYear_KeyDown);
				this.textBoxCurrentYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCurrentYear_KeyPress);

				this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
				this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
				this.helpProvider1.SetHelpKeyword(this, "ConstraintViewer.htm");
				this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
				this.helpProvider1.SetShowHelp(this, true);

				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				commonTasks.LoadHelpImage(pictureBoxHelp);
				commonTasks.SetBitmap(pictureBoxHelp);
				commonTasks.SetBitmap(pictureBoxGo1);
				commonTasks.SetBitmap(pictureBoxGoInstallYear);
				commonTasks = null;

				buttonSaveToExcel.Enabled = false;
				pictureBoxHelp.Visible = true;
				labelResult.Visible = false;
				labelNoRecordsFound.Visible = false;
				c1FlexGridConstraintList.Visible = false;

				pictureBoxGoInstallYear.Visible = false;
				labelConstraintInstallYear.Visible = false;

				this.label1.Text = "Display user-entered Next Replacement Year and Next Rehabilitation Year values";
				this.label2.Text = "Display constraint violations for Installation Year <= Last Rehabilitation Year <= Inspection Year";
				//radioButton1.Checked = true;

				CheckConstraintDataInstall();
				//GetConstraintData(ConstraintType.RehabReplace, existingFacilityCurrentYear);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void CheckConstraintDataInstall()
		{
			try
			{
				WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
				DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetConstraints1", "@facilityId", facilityId);

				if (dataTable != null && dataTable.Rows.Count > 0)
				{
					labelConstraintInstallYear.Visible = true;
					pictureBoxGoInstallYear.Visible = true;
					panelConstraintInstallYear.Visible = true;
					labelConstraintInstallYear.BringToFront();
					pictureBoxGoInstallYear.BringToFront();
					panelConstraintInstallYear.BringToFront();
					c1FlexGridConstraintList.Size = new Size(c1FlexGridConstraintList.Width, 240);
					c1FlexGridConstraintList.Top = 176;
					labelResult.Top = 136;
				}
			}
			catch
			{
				//don't do anything - this is just a background check for data
				//MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void GetConstraintData(ConstraintType constraintType, int proposedYear)
		{
			try
			{
				labelNoRecordsFound.Visible = false;

				WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
				DataTable dataTable = null;

				if (constraintType == ConstraintType.RehabReplace)
				{
					dataTable = dataAccess.GetDisconnectedDataTableSP("GetConstraints2", "@facilityId", "@proposedFacilityYear", facilityId, proposedYear);
				}
				else
				{
					dataTable = dataAccess.GetDisconnectedDataTableSP("GetConstraints1", "@facilityId", facilityId);
				}

				if (dataTable == null)
				{
					labelNoRecordsFound.Text = "An error has occurred.  Data could not be found.";
					labelNoRecordsFound.Visible = true;
					buttonSaveToExcel.Enabled = false;
					return;
				}

				c1FlexGridConstraintList.DataSource = dataTable;
				c1FlexGridConstraintList.Visible = dataTable.Rows.Count != 0;
				labelNoRecordsFound.Visible = dataTable.Rows.Count == 0;
				labelResult.Visible = dataTable.Rows.Count != 0;
				buttonSaveToExcel.Enabled = dataTable.Rows.Count != 0;

				FormatGrid(constraintType, proposedYear);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void FormatGrid(ConstraintType constraintType, int proposedYear)
		{
			//buttonSaveToExcel.Enabled = !labelNoRecordsFound.Visible;

			if (labelNoRecordsFound.Visible)
			{
				if (constraintType == ConstraintType.InstallYear)
				{
					labelNoRecordsFound.Text = "There are no constraint violations for Installation Years, Last Rehabilitation Years, or Inspection Years in this Facility";
				}
				else
				{
					labelNoRecordsFound.Text = "There are no constraint violations for Next Replacement Years or Next Rehabilitation Years for Facility Current Year = " + textBoxCurrentYear.Text;
				}

				return;
			}

			c1FlexGridConstraintList.Cols.Fixed = 1;
			c1FlexGridConstraintList.Cols[0].WidthDisplay = 40;
			c1FlexGridConstraintList.AllowEditing = false;
			c1FlexGridConstraintList.ExtendLastCol = true;
			c1FlexGridConstraintList.Rows[0].HeightDisplay = 80;
			c1FlexGridConstraintList.AllowAddNew = false;
			c1FlexGridConstraintList.AllowDelete = false;
			c1FlexGridConstraintList.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			c1FlexGridConstraintList.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.SingleColumn;
			c1FlexGridConstraintList.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;

			for (int i = 1; i < c1FlexGridConstraintList.Cols.Count; i++)
			{
				c1FlexGridConstraintList.Cols[i].TextAlignFixed = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
				c1FlexGridConstraintList.Cols[i].WidthDisplay = 100;
			}

			string resultText = "";
			if (constraintType == ConstraintType.RehabReplace)
			{
				//populating the grid like this seemed like a good idea at the time...
				c1FlexGridConstraintList.Cols[6].Move(2);
				c1FlexGridConstraintList.Cols[7].Move(3);
				c1FlexGridConstraintList.Cols[8].Move(4);
				c1FlexGridConstraintList.Cols[9].Move(5);
				c1FlexGridConstraintList.Cols[1].Caption = "Overridden";
				c1FlexGridConstraintList.Cols[2].Caption = "Next\r\nReplacement\r\nYear";
				c1FlexGridConstraintList.Cols[3].Caption = "Next\r\nRehabilitation\r\nYear";
				c1FlexGridConstraintList.Cols[4].Caption = "Proposed\r\nFacility\r\nCurrent Year";
				c1FlexGridConstraintList.Cols[5].Caption = "Existing\r\nFacility\r\nCurrent Year";
				c1FlexGridConstraintList.Cols[7].Caption = "Treatment\r\nProcess";
				c1FlexGridConstraintList.Cols[8].Caption = "Major\r\nComponent";
				c1FlexGridConstraintList.Cols[9].Caption = "Discipline\r\nType";

				//c1FlexGridConstraintList.Cols.Insert(4);

				for (int i = 10; i < c1FlexGridConstraintList.Cols.Count; i++)
				{
					c1FlexGridConstraintList.Cols[i].Visible = false;
				}

				resultText = "If the Facility Current Year is changed to " + proposedYear.ToString() + ", all of the Next Replacement Years"
					+ " and Next Rehabilitation Years listed below will be changed to " + proposedYear.ToString() + "."; 
			}
			else
			{
				//populating the grid like this seemed like a good idea at the time...
				c1FlexGridConstraintList.Cols[9].Move(1);
				c1FlexGridConstraintList.Cols[10].Move(2);
				c1FlexGridConstraintList.Cols[11].Move(3);
				c1FlexGridConstraintList.Cols[1].Caption = "Installation Year\r\n<=\r\nLast\r\nRehabilitation Year";
				c1FlexGridConstraintList.Cols[2].Caption = "Last\r\nRehabilitation Year\r\n<=\r\nInspection Year";
				c1FlexGridConstraintList.Cols[3].Caption = "\r\nInspection Year\r\n<=\r\nFacility\r\nCurrent Year";
				c1FlexGridConstraintList.Cols[1].WidthDisplay = 110;
				c1FlexGridConstraintList.Cols[2].WidthDisplay = 110;
				c1FlexGridConstraintList.Cols[3].WidthDisplay = 110;
				c1FlexGridConstraintList.Cols[5].Caption = "Treatment\r\nProcess";
				c1FlexGridConstraintList.Cols[6].Caption = "Major\r\nComponent";
				c1FlexGridConstraintList.Cols[7].Caption = "Discipline\r\nType";
				c1FlexGridConstraintList.Cols[8].Caption = "Installation\r\nYear";
				c1FlexGridConstraintList.Cols[9].Caption = "Last\r\nRehabilitationYear";
				c1FlexGridConstraintList.Cols[10].Caption = "Inspection\r\nYear";
				c1FlexGridConstraintList.Cols[11].Caption = "Facility\r\nCurrent Year";

				for (int i = 12; i < c1FlexGridConstraintList.Cols.Count; i++)
				{
					c1FlexGridConstraintList.Cols[i].Visible = false;
				}

				resultText = "The following constraint violations exist for Installation Year, Last Rehabilitation Year,"
					+ " Inspection Year, and Current Facility Year:";
			}

			labelResult.Text = resultText;
			SetRowNumbersInGrid();
		}

		private void SetRowNumbersInGrid()
		{
			//add row numbers to the fixed column
			for (int i = 1; i < c1FlexGridConstraintList.Rows.Count; i++)
			{
				c1FlexGridConstraintList[i, 0] = i;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Event Handlers *****/

		private void buttonSaveToExcel_Click(object sender, System.EventArgs e)
		{
			try
			{
				string fileName = "";
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.DefaultExt = "xls";
				saveFileDialog.FileName = "*.xls";
				saveFileDialog.CheckPathExists = true;
				saveFileDialog.OverwritePrompt = true;
				saveFileDialog.Title = "Save Data to Excel";
				saveFileDialog.ValidateNames = true;
				saveFileDialog.ShowHelp = true;
				saveFileDialog.AddExtension = true;
				if (saveFileDialog.ShowDialog() != DialogResult.OK)
				{
					return;
				}
				if(saveFileDialog.FileName == "")
				{
					//no file name selected
					return;
				}
				fileName = saveFileDialog.FileName.ToString();

				//string tabText = radioButton1.Checked ? "Replacement and Rehab Years" : "Constraint Violations";
				string tabText = "Constraint Violations";

				this.Cursor = Cursors.WaitCursor;

				c1FlexGridConstraintList.SaveExcel(fileName, tabText, C1.Win.C1FlexGrid.FileFlags.IncludeFixedCells);

				this.Cursor = Cursors.Default;
				MessageBox.Show("The file has been saved successfully.", "Save to Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch(Exception ex)
			{
				this.Cursor = Cursors.Default;
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ConstraintViewer.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ConstraintViewer.htm");
		}

		private void ConstraintViewer_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
			//radioButton1.Checked = true;
		}

		private void label2_Click(object sender, System.EventArgs e)
		{
			//radioButton2.Checked = true;
		}

		private void radioButton1_CheckedChanged(object sender, System.EventArgs e)
		{
			//GetConstraintData();
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void pictureBoxGo1_Click(object sender, System.EventArgs e)
		{
			int proposedYear = 12345;
			try
			{
				proposedYear = int.Parse(textBoxCurrentYear.Text);
			}
			catch
			{
			}

			if (proposedYear == 12345)
			{
				MessageBox.Show("Please enter a numeric Proposed Current Facility Year", "Enter Numeric Proposed Current Facility Year", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			GetConstraintData(ConstraintType.RehabReplace, proposedYear);
		}

		private void pictureBoxGoInstallYear_Click(object sender, System.EventArgs e)
		{
			GetConstraintData(ConstraintType.InstallYear, 0);
		}

		//don't use key down to trap user hitting the return key because e.Handled isn't supressing the ding of the bell
		//private void textBoxCurrentYear_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		//{
		//	if (e.KeyCode == Keys.Return)
		//	{
		//		e.Handled = true;
		//		pictureBoxGo1_Click(null, null);
		//	}
		//}

		private void textBoxCurrentYear_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)13)
			{
				e.Handled = true;
				pictureBoxGo1_Click(null, null);
			}
		}

		#endregion /***** Event Handlers *****/
	}
}
