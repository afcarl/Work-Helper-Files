using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI.Grids
{
	/// <summary>
	/// Summary description for NodeAppurtenanceGrid.
	/// </summary>
	public class NodeAppurtenanceGrid : System.Windows.Forms.UserControl
	{
		#region /***** Enumerations *****/

		enum Columns
		{
			ID = 0,
			Description,
			Type,
			Size,
			InstallYear,
			OriginalENR,
			CWPValue,
			AcquisitionCost,
			CurrentValue,
			AcquisitionCostEscalated,
			ReplacementValue,
			ReplacementValueYear,
			ReplacementValueENR,
			RehabCost,
			BookValue,
			SalvageValue,
			AnnualDepreciation,
			CumulativeDepreciation,
			EvaluatedValue,
			RepairCost,
			AnnualMaintCost,
			Condition,

			//mam 050806
			RedundantAssets,

			//mam 07072011 - new crits
			Crit1,
			Crit2,
			Crit3,
			Crit4,
			Crit5,
			Crit6,

			//mam 07072011 - no longer using four fixed crits
			//CritHealth,
			//CritEnvironmental,
			//CritCostOfRepairs,
			//CritEffectOnCustomers,

			OverallCriticality,
			Vulnerability,
			Risk,
			LevelOfService,
			OrgUsefulLife,
			RemainingUL,
			EvalRemainingUL,
			EconomicUL,
		}

		#endregion /***** Enumerations *****/

		#region /***** Variables *****/

		private DisciplineNode	m_discNode = null;
		private C1.Win.C1FlexGrid.C1FlexGrid grid;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		//mam
		ArrayList colTag = new ArrayList();
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		//</mam>

		//mam 07072011
		ArrayList arrayListCrits = Common.CommonTasks.LoadCriticalitiesIntoArrayList();

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public NodeAppurtenanceGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			grid.Rows[1].HeightDisplay = 
				(int)(grid.Rows[1].HeightDisplay * 2.0);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grid = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// grid
			// 
			this.grid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.grid.AllowEditing = false;
			this.grid.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.grid.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.grid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.grid.ColumnInfo = "37,0,0,0,0,85,Columns:0{Width:65;Caption:\"ID Number\";AllowEditing:False;DataType:" +
				"System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t1{Width:100;Cap" +
				"tion:\"Description\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t2{Width:150;Caption:\"Type\";DataType:System.String;TextAlign:LeftCen" +
				"ter;TextAlignFixed:CenterCenter;}\t3{Width:65;Caption:\"Size (ft)\";DataType:System" +
				".String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t4{Width:60;Caption:\"" +
				"Installation Year\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:C" +
				"enterCenter;}\t5{Width:60;Caption:\"Original ENR\";DataType:System.String;TextAlign" +
				":RightCenter;TextAlignFixed:CenterCenter;}\t6{Width:75;Caption:\"Cost Weighted Per" +
				"centage of Asset Value (%)\";DataType:System.String;TextAlign:RightCenter;TextAli" +
				"gnFixed:CenterCenter;}\t7{Width:75;Caption:\"Acquisition Cost ($)\";DataType:System" +
				".String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t8{Width:75;Caption:\"" +
				"Current Value ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:C" +
				"enterCenter;}\t9{Width:75;Caption:\"Escalated Acquisition Cost\";DataType:System.St" +
				"ring;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t10{Width:75;Caption:\"Re" +
				"placement Value ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed" +
				":CenterCenter;}\t11{Width:75;Caption:\"Replacement Value Year\";DataType:System.Str" +
				"ing;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t12{Width:75;Caption:\"Rep" +
				"lacement Value Year ENR\";DataType:System.String;TextAlign:RightCenter;TextAlignF" +
				"ixed:CenterCenter;}\t13{Width:75;Caption:\"Rehabilitation Cost ($)\";DataType:Syste" +
				"m.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t14{Width:75;Caption" +
				":\"Book Value ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t15{Width:75;Caption:\"Salvage Value ($)\";DataType:System.String;Text" +
				"Align:RightCenter;TextAlignFixed:CenterCenter;}\t16{Width:75;Caption:\"Annual Depr" +
				"eciation ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Center" +
				"Center;}\t17{Width:75;Caption:\"Cumulative Depreciation ($)\";DataType:System.Strin" +
				"g;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t18{Width:75;Caption:\"Evalu" +
				"ated Value ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Cent" +
				"erCenter;}\t19{Width:75;Caption:\"Repair Cost ($)\";DataType:System.String;TextAlig" +
				"n:RightCenter;TextAlignFixed:CenterCenter;}\t20{Width:75;Caption:\"Annual Maintena" +
				"nce Cost ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Center" +
				"Center;}\t21{Width:55;Caption:\"Condition\";DataType:System.String;TextAlign:Center" +
				"Center;TextAlignFixed:CenterCenter;}\t22{Width:70;Caption:\"Number of Assets with " +
				"Similar Functionality\";DataType:System.String;TextAlign:RightCenter;TextAlignFix" +
				"ed:CenterCenter;}\t23{Width:125;Name:\"Crit1\";Caption:\"Criticality1\";DataType:Syst" +
				"em.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t24{Width:125;Name:\"" +
				"Crit2\";Caption:\"Criticality2\";DataType:System.String;TextAlign:LeftCenter;TextAl" +
				"ignFixed:CenterCenter;}\t25{Width:125;Name:\"Crit3\";Caption:\"Criticality3\";DataTyp" +
				"e:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t26{Width:125;" +
				"Name:\"Crit4\";Caption:\"Criticality4\";DataType:System.String;TextAlign:LeftCenter;" +
				"TextAlignFixed:CenterCenter;}\t27{Width:125;Name:\"Crit5\";Caption:\"Criticality5\";D" +
				"ataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t28{Widt" +
				"h:125;Name:\"Crit6\";Caption:\"Criticality6\";DataType:System.String;TextAlign:LeftC" +
				"enter;TextAlignFixed:CenterCenter;}\t29{Width:70;Caption:\"Overall Criticality\";Da" +
				"taType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t30{Widt" +
				"h:65;Caption:\"Vulnerability\";DataType:System.String;TextAlign:RightCenter;TextAl" +
				"ignFixed:CenterCenter;}\t31{Width:55;Caption:\"Risk\";DataType:System.String;TextAl" +
				"ign:RightCenter;TextAlignFixed:CenterCenter;}\t32{Width:70;Caption:\"Level of Serv" +
				"ice\";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFi" +
				"xed:CenterCenter;}\t33{Width:65;Caption:\"Original\";AllowEditing:False;DataType:Sy" +
				"stem.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t34{Width:65;Capt" +
				"ion:\"Remaining\";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;" +
				"TextAlignFixed:CenterCenter;}\t35{Width:65;Caption:\"Evaluated\";AllowEditing:False" +
				";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t36{W" +
				"idth:65;Caption:\"Economic\";AllowEditing:False;DataType:System.String;TextAlign:R" +
				"ightCenter;TextAlignFixed:CenterCenter;}\t";
			this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.grid.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.grid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.grid.Location = new System.Drawing.Point(0, 0);
			this.grid.Name = "grid";
			this.grid.Rows.Count = 3;
			this.grid.Rows.Fixed = 2;
			this.grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.RowRange;
			this.grid.ShowSort = false;
			this.grid.Size = new System.Drawing.Size(416, 150);
			this.grid.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.grid.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.grid.TabIndex = 1;
			// 
			// NodeAppurtenanceGrid
			// 
			this.Controls.Add(this.grid);
			this.Name = "NodeAppurtenanceGrid";
			this.Size = new System.Drawing.Size(416, 150);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			grid.Rows[0].AllowMerging = 
				grid.Rows[1].AllowMerging = true;

			foreach (Column col in grid.Cols)
			{
				col.AllowMerging = true;
				col.StyleFixedNew.TextAlign =
					C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
			}

			UpdateColumnTitles();

			//mam
			colTag.Add("");	//id number
			colTag.Add("");	//description
			colTag.Add("");	//type
			colTag.Add("");	//size
			colTag.Add("");	//installation year
			colTag.Add("");	//original enr
			colTag.Add("");	//cost-weighted %
			colTag.Add("NAC");
			colTag.Add("NCV");
			colTag.Add("NEAC");
			colTag.Add("");	//replacement value
			colTag.Add("");	//replacement value year
			colTag.Add("");	//replacement value year enr
			colTag.Add("");	//rehab cost
			colTag.Add("BV");
			colTag.Add("");	//salvage value
			colTag.Add("AD");
			colTag.Add("CD");
			colTag.Add("EV");
			colTag.Add("RC");
			colTag.Add("");	//annual maint cost
			colTag.Add("");	//condition
			colTag.Add("");	//redundant asset count

			//mam 07072011 - new crits
			colTag.Add("");	//crit 1
			colTag.Add("");	//crit 2
			colTag.Add("");	//crit 3
			colTag.Add("");	//crit 4
			colTag.Add("");	//crit 5
			colTag.Add("");	//crit 6

			//mam 07072011 - no longer using four fixed crits
			//colTag.Add("");	//crit public
			//colTag.Add("");	//crit environment
			//colTag.Add("");	//crit repairs
			//colTag.Add("");	//crit effect

			colTag.Add("OCRIT");
			colTag.Add("VULN");
			colTag.Add("RISK");
			colTag.Add("");	//los
			colTag.Add("");	//oul
			colTag.Add("RUL");
			colTag.Add("ERUL");

			//add new col ECUL for Economic UL
			colTag.Add("ECUL");

			SetEquationControls();
			//</mam>

			//mam 07072011 - hide unused criticality columns
			int numCrit = arrayListCrits.Count;
			for (int i = 1; i <= numCrit; i++)
			{
				grid.Cols["Crit" + i.ToString()].Visible = true;
			}
			for (int i = numCrit + 1; i <= 6; i++)
			{
				grid.Cols["Crit" + i.ToString()].Visible = false;
			}

			base.OnLoad(e);
		}

		private void		UpdateColumnTitles()
		{
			grid[0, (int)Columns.ID] = 
				grid[1, (int)Columns.ID] = "ID Number";
			grid[0, (int)Columns.Description] =
				grid[1, (int)Columns.Description] = "Description";
			grid[0, (int)Columns.Type] = 
				grid[1, (int)Columns.Type] = "Type";
			grid[0, (int)Columns.Size] =
				grid[1, (int)Columns.Size] = "Size (ft)";
			grid[0, (int)Columns.InstallYear] = 
				grid[1, (int)Columns.InstallYear] = "Installation Year";
			grid[0, (int)Columns.OriginalENR] = 
				grid[1, (int)Columns.OriginalENR] = "Original ENR";
			grid[0, (int)Columns.CWPValue] = 
				grid[1, (int)Columns.CWPValue] = "Cost Weighted\r\nPercentage of\r\nAsset Value (%)";
			grid[0, (int)Columns.AcquisitionCost] = 
				grid[1, (int)Columns.AcquisitionCost] = "Acquisition\r\nCost ($)";
			grid[0, (int)Columns.CurrentValue] = 
				grid[1, (int)Columns.CurrentValue] = "Current\r\nValue ($)";

			//mam 050806
			grid[0, (int)Columns.AcquisitionCostEscalated] = 
				grid[1, (int)Columns.AcquisitionCostEscalated] = "Escalated\r\nAcquisition\r\nCost ($)";
			grid[0, (int)Columns.ReplacementValueYear] = 
				grid[1, (int)Columns.ReplacementValueYear] = "Replacement\r\nValue Year";
			grid[0, (int)Columns.ReplacementValueENR] = 
				grid[1, (int)Columns.ReplacementValueENR] = "Replacement\r\nValue Year\r\nENR";

			grid[0, (int)Columns.RehabCost] = 
				grid[1, (int)Columns.RehabCost] = "Rehabilitation\r\n Cost ($)";

			grid[0, (int)Columns.ReplacementValue] = 
				grid[1, (int)Columns.ReplacementValue] = "Replacement\r\nValue ($)";
			grid[0, (int)Columns.BookValue] = 
				grid[1, (int)Columns.BookValue] = "Book\r\nValue ($)";
			grid[0, (int)Columns.SalvageValue] = 
				grid[1, (int)Columns.SalvageValue] = "Salvage\r\nValue ($)";
			grid[0, (int)Columns.AnnualDepreciation] = 
				grid[1, (int)Columns.AnnualDepreciation] = "Annual\r\nDepreciation ($)";
			grid[0, (int)Columns.CumulativeDepreciation] = 
				grid[1, (int)Columns.CumulativeDepreciation] = "Cumulative\r\nDepreciation ($)";
			grid[0, (int)Columns.EvaluatedValue] = 
				grid[1, (int)Columns.EvaluatedValue] = "Evaluated\r\nValue ($)";
			grid[0, (int)Columns.RepairCost] = 
				grid[1, (int)Columns.RepairCost] = "Repair\r\nCost ($)";
			grid[0, (int)Columns.AnnualMaintCost] = 
				grid[1, (int)Columns.AnnualMaintCost] = "Annual\r\nMaintenance\r\nCost ($)";
			grid[0, (int)Columns.Condition] = 
				grid[1, (int)Columns.Condition] = "Condition\r\nRanking";

			//mam 050806
			//grid[0, (int)Columns.RedundantAssets] = 
			//	grid[1, (int)Columns.RedundantAssets] = "Redundant\r\nAsset\r\nCount";

			//mam 112806
			grid[0, (int)Columns.RedundantAssets] = 
				grid[1, (int)Columns.RedundantAssets] = "Number of Assets with Similar Functionality";

			//mam 07072011 - new crits
			int colNumber = 0;
			string colName = "";
			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				colNumber = i + 1;
				colName = "Crit" + colNumber.ToString();
				grid[0, colName] = grid[1, colName] = "Criticality -\r\n" + ((Common.Criticality)arrayListCrits[i]).CriticalityName;
			}

			//mam 07072011 - no longer using four fixed crits
			//grid[0, (int)Columns.CritHealth] = grid[1, (int)Columns.CritHealth] = "Criticality -\r\nPublic Health\r\nand Safety";
			//grid[0, (int)Columns.CritEnvironmental] = grid[1, (int)Columns.CritEnvironmental] = "Criticality -\r\nEnvironmental";
			//grid[0, (int)Columns.CritCostOfRepairs] = grid[1, (int)Columns.CritCostOfRepairs] = "Criticality -\r\nCost of Repairs";
			//grid[0, (int)Columns.CritEffectOnCustomers] = grid[1, (int)Columns.CritEffectOnCustomers] = "Criticality -\r\nEffect On\r\nCustomers";

			grid[0, (int)Columns.OverallCriticality] = 
				grid[1, (int)Columns.OverallCriticality] = "Overall\r\nCriticality";
			grid[0, (int)Columns.Vulnerability] = 
				grid[1, (int)Columns.Vulnerability] = "Vulnerability";
			grid[0, (int)Columns.Risk] = 
				grid[1, (int)Columns.Risk] = "Risk";
			grid[0, (int)Columns.LevelOfService] = 
				grid[1, (int)Columns.LevelOfService] = "Level of\r\nService";
			grid[0, (int)Columns.OrgUsefulLife] = 
				grid[0, (int)Columns.RemainingUL] = 
				grid[0, (int)Columns.EvalRemainingUL] = 
				grid[0, (int)Columns.EconomicUL] = "Useful Life (Yrs)";
			grid[1, (int)Columns.OrgUsefulLife] = "Original";
			grid[1, (int)Columns.RemainingUL] = "Remaining";
			grid[1, (int)Columns.EvalRemainingUL] = "Evaluated Remaining";
			grid[1, (int)Columns.EconomicUL] = "Economic Remaining";
		}

		public void			SetDiscipline(DisciplineNode node)
		{
			m_discNode = node;
			LoadGrid();
		}

		private void		LoadGrid()
		{
			if (m_discNode == null)
			{
				grid.Rows.Count = 2;
				return;
			}

			m_discNode.InfoSetID = InfoSet.CurrentID;
			grid.Rows.Count = 2;

			// Load the process list
			NodeData[]		nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, m_discNode.ID);
			NodeData		node;
			int				row = 2;

			// Top fixed row and bottom totals row
			grid.Redraw = false;

			//mam 07072011 - the entire grid is reloaded when any change is made to a single node - why???!!!
			for (int pos = 0; pos < nodes.Length; pos++)
			{
				node = nodes[pos];
				grid.Rows.Add();
				grid.Rows[row].UserData = node;
				UpdateGridRow(row++, node);
			}

			//not necessary
//			//mam - disable editing in all columns if infoset is fixed
//			if (InfoSet.IsFixed)
//			{
//				foreach (Column col in grid.Cols)
//				{
//					col.AllowEditing = false;
//				}
//			}
//			//</mam>

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		public void			UpdateGridRow(int row, NodeData node)
		{
			grid.SetData(row, (int)Columns.ID, node.IDNumber);
			grid.SetData(row, (int)Columns.Description, node.Description);
			grid.SetData(row, (int)Columns.Type, node.Type);
			grid.SetData(row, (int)Columns.Size, node.Size);
			grid.SetData(row, (int)Columns.InstallYear, node.InstallYear);
			grid.SetData(row, (int)Columns.OriginalENR, node.OriginalENR);

			//mam - get unrounded CWP
			grid.SetData(row, (int)Columns.CWPValue, (node.GetCWP(false) * 100.0).ToString("F1"));

			grid.SetData(row, (int)Columns.AcquisitionCost, 
				node.AcquisitionCost.ToString("$#,##0"));

			//mam 112806
			//grid.SetData(row, (int)Columns.CurrentValue, node.GetCurrentValue().ToString("$#,##0"));

			//mam 050806
			if (node.ConditionRank.ToString() == "No" && !node.OverrideCurrentValue)
			{
				grid.SetData(row, (int)Columns.CurrentValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.CurrentValue, node.GetCurrentValue().ToString("$#,##0"));
			}
			//</mam>

			//mam 050806
			grid.SetData(row, (int)Columns.AcquisitionCostEscalated, 
				node.AcquisitionCostEscalated.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.ReplacementValueYear, node.ReplacementValueYear);
			grid.SetData(row, (int)Columns.ReplacementValueENR, 
				node.GetENRValueForYear((short)node.ReplacementValueYear));
			grid.SetData(row, (int)Columns.RehabCost, 
				node.RehabCost.ToString("$#,##0"));

			grid.SetData(row, (int)Columns.ReplacementValue, 
				node.ReplacementValue.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.BookValue, 
				node.GetBookValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.SalvageValue, 
				node.SalvageValue.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.AnnualDepreciation, 
				node.GetAnnualDepreciation().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.CumulativeDepreciation, 
				node.GetCumulativeDepreciation().ToString("$#,##0"));

			//mam - enter N/A into grid cell if Condition = N/A
			if (node.ConditionRank.ToString() == "No")
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, 
					node.GetEvaluatedValue().ToString("$#,##0"));
			}

			//mam 050806
			if (node.ConditionRank.ToString() == "No" && !node.OverrideRepairCost)
			{
				grid.SetData(row, (int)Columns.RepairCost, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.RepairCost, 
					node.GetRepairCost().ToString("$#,##0"));
			}
			//</mam>

			grid.SetData(row, (int)Columns.AnnualMaintCost, 
				node.AnnualMaintCost.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.Condition, 
				EnumHandlers.GetConditionRankShort(node.ConditionRank));

			//mam 050806
			grid.SetData(row, (int)Columns.RedundantAssets, 
				node.RedundantAssetCount.ToString("0"));

			//mam 07072011 - new crits
			int colNumber = 0;
			string colName = "";
			for (int i = 0; i < node.ComponentSelectedCriticalityFactorsCollection.Count; i++)
			{
				colNumber = i + 1;
				colName = "Crit" + colNumber.ToString();
				grid.SetData(row, colName, node.ComponentSelectedCriticalityFactorsCollection.Item(i).CritFactor.FactorName);
			}

			//mam 07072011 - no longer using four fixed crits
			//grid.SetData(row, (int)Columns.CritHealth, 
			//	EnumHandlers.GetCritPublicHealthShort(node.CritPublicHealth));
			//grid.SetData(row, (int)Columns.CritEnvironmental, 
			//	EnumHandlers.GetCritEnvironmentalShort(node.CritEnvironmental));

			////mam - get string rather than short string
			////grid.SetData(row, (int)Columns.CritCostOfRepairs, 
			////	EnumHandlers.GetCritRepairCostShort(node.CritRepair));
			//grid.SetData(row, (int)Columns.CritCostOfRepairs, 
			//	EnumHandlers.GetCritRepairCostString(node.CritRepair));
			////mam

			//grid.SetData(row, (int)Columns.CritEffectOnCustomers, 
			//	EnumHandlers.GetCritCustomerEffectShort(node.CritCustEffect));

			grid.SetData(row, (int)Columns.OverallCriticality, node.GetOverallCriticality());

			//mam - use probability
			//grid.SetData(row, (int)Columns.Vulnerability, 
			//	EnumHandlers.GetVulnerabilityShort(node.Vulnerability));
			//grid.SetData(row, (int)Columns.Risk, 
			//	node.GetRisk().ToString("F2"));
			if ((node.ConditionRank == CondRank.No || node.GetEvaluatedRemainingUsefulLife() == 0) 
				&& !node.OverrideVulnerability)
			{
				grid.SetData(row, (int)Columns.Vulnerability, "N/A");
				grid.SetData(row, (int)Columns.Risk, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.Vulnerability, node.GetVulnerability().ToString("F4"));
				grid.SetData(row, (int)Columns.Risk, node.GetRisk().ToString("F2"));
			}
			//</mam>


			grid.SetData(row, (int)Columns.LevelOfService, 
				EnumHandlers.GetLOSShort(node.LevelOfService));
			grid.SetData(row, (int)Columns.OrgUsefulLife, 
				node.OrgUsefulLife.ToString());
			grid.SetData(row, (int)Columns.RemainingUL, 
				string.Format("{0:F1}", node.GetRemainingUsefulLife()));

			//mam - enter N/A into grid cell if Condition = N/A
			if (node.ConditionRank.ToString() == "No")
			{
				grid.SetData(row, (int)Columns.EvalRemainingUL, "N/A");
				grid.SetData(row, (int)Columns.EconomicUL, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.EvalRemainingUL, 
					string.Format("{0:F1}", node.GetEvaluatedRemainingUsefulLife()));
				grid.SetData(row, (int)Columns.EconomicUL, 
					string.Format("{0:F1}", node.GetEconomicUsefulLife()));
			}
			//</mam>
		}

		public void			AddNode(NodeData node)
		{
			int				row = grid.Rows.Count;

			grid.Rows.Add().UserData = node;
			UpdateGridRow(row, node);
		}

		public void			GetSelectedRow(out int row, out NodeData node)
		{
			row = grid.Row;

			if (row < grid.Rows.Fixed)
				node = null;
			else
				node = grid.Rows[row].UserData as NodeData;
		}

		//mam 050806 - allow user to delete multiple, contiguous rows at once
		public void GetSelectedRows(out int row, ref ArrayList nodeRows)
		{
			NodeData node;
			row = grid.Row;

			grid.Selection.Normalize();
			foreach (C1.Win.C1FlexGrid.Row gridRow in grid.Rows)
			{
				if (grid.Selection.ContainsRow(gridRow.Index))
				{
					node = gridRow.UserData as NodeData;
					nodeRows.Add(node);
				}
			}
		}

		//mam - set the selected grid row
		public void SetSelectedRow(int row)
		{
			if (row > grid.Rows.Fixed - 1 && row < grid.Rows.Count)
				grid.Row = row;
			else if (grid.Rows.Count > grid.Rows.Fixed)
				grid.Row = grid.Rows.Count -1;
		}
		//</mam>

		//mam - set the selected grid row to the new (last) row
		public void SetSelectedRowNewRow()
		{
			if (grid.Rows.Count > grid.Rows.Fixed)
				grid.Row = grid.Rows.Count -1;
		}
		//</mam>

		public void			DeleteRow(int row)
		{
			if (row >= grid.Rows.Fixed)
				grid.RemoveItem(row);
		}

		public void			AddGridDoubleClick(System.EventHandler handler)
		{
			this.grid.DoubleClick += handler;
		}

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
		}

		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandlerGrid(grid, colTag);
		}
		//</mam>

	}
}