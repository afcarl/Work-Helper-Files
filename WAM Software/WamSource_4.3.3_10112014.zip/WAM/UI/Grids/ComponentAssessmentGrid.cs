using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI.Grids
{
	/// <summary>
	/// Summary description for ComponentAssessmentGrid.
	/// </summary>
	public class ComponentAssessmentGrid : System.Windows.Forms.UserControl
	{
		#region /***** Enumerations *****/

		enum Columns
		{
			Name = 0,
			ConditionRank,
			UsefulLifeOrg,
			UsefulLifeBook,
			UsefulLifeEval,
			UsefulLifeEconomic,
			LOS,
			OverallCriticality,
			Vulnerability,
			Risk,
		}

		#endregion /***** Enumerations *****/

		#region /***** Variables *****/

		private TreatmentProcess m_root = null;

		private C1.Win.C1FlexGrid.C1FlexGrid grid;

		//mam 050806
		//mam 112806 - don't use this variable
		//private bool discOverrideRepairCost = false;

		//mam 112806 - update - don't use this variable
		//private bool discOverrideCurrentValue = false;

		//mam
		ArrayList colTag = new ArrayList();
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		//</mam>

		private System.ComponentModel.Container components = null;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public ComponentAssessmentGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			grid.Rows[0].AllowMerging = 
				grid.Rows[1].AllowMerging = true;

			foreach (Column col in grid.Cols)
			{
				col.AllowMerging = true;
				col.StyleFixedNew.TextAlign =
					C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
			}

			grid[0, (int)Columns.ConditionRank] = 
				grid[1, (int)Columns.ConditionRank] = "Condition\r\nRanking";

			grid[0, (int)Columns.UsefulLifeOrg] = 
				grid[0, (int)Columns.UsefulLifeEval] = 
				grid[0, (int)Columns.UsefulLifeBook] = 
				grid[0, (int)Columns.UsefulLifeEconomic] = "Useful Life (Yrs)";
			grid[1, (int)Columns.UsefulLifeOrg] = "Original";
			grid[1, (int)Columns.UsefulLifeBook] = "Remaining";
			grid[1, (int)Columns.UsefulLifeEval] = "Evaluated\r\nRemaining";
			grid[1, (int)Columns.UsefulLifeEconomic] = "Economic\r\nRemaining";

			grid[0, (int)Columns.LOS] = 
				grid[1, (int)Columns.LOS] = "Level of\r\nService";
			grid[0, (int)Columns.OverallCriticality] = 
				grid[1, (int)Columns.OverallCriticality] = "Overall\r\nCriticality";
			grid[0, (int)Columns.Vulnerability] = 
				grid[1, (int)Columns.Vulnerability] = "Vulnerability";
			grid[0, (int)Columns.Risk] = 
				grid[1, (int)Columns.Risk] = "Risk";

			grid.Rows[1].HeightDisplay = 
				(int)(grid.Rows[1].HeightDisplay * 2.0);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grid = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// grid
			// 
			this.grid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.grid.AllowEditing = false;
			this.grid.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.grid.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.grid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.grid.ColumnInfo = @"10,0,0,0,0,85,Columns:0{Width:250;Caption:""Disciplines"";AllowEditing:False;DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	1{Width:70;Caption:""Condition Ranking"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	2{Width:65;Caption:""Original"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	3{Width:65;Caption:""Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	4{Width:65;Caption:""Evaluated Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	5{Width:65;Caption:""Economic Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	6{Width:65;Caption:""Level of Service"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	7{Width:65;Caption:""Overall Criticality"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	8{Width:65;Caption:""Vulnerability"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	9{Width:65;Caption:""Risk"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	";
			this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.grid.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.grid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.grid.Location = new System.Drawing.Point(0, 0);
			this.grid.Name = "grid";
			this.grid.Rows.Count = 3;
			this.grid.Rows.Fixed = 2;
			this.grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.grid.ShowSort = false;
			this.grid.Size = new System.Drawing.Size(388, 128);
			this.grid.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.grid.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.grid.TabIndex = 0;
			// 
			// ComponentAssessmentGrid
			// 
			this.Controls.Add(this.grid);
			this.Name = "ComponentAssessmentGrid";
			this.Size = new System.Drawing.Size(388, 128);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			UpdateColumnTitles();

			//mam
			colTag.Add("");
			colTag.Add("COND");
			colTag.Add("OUL");

			//colTag.Add("RUL");
			//colTag.Add("ERUL");

			colTag.Add("RRUL");
			colTag.Add("RERUL");

			//add new col ECUL for Economic UL
			colTag.Add("RECUL");

			colTag.Add("LOS");
			colTag.Add("CRIT");

			//colTag.Add("VULN");
			//colTag.Add("RISK");
			colTag.Add("VULNPN");
			colTag.Add("RISKPN");

			SetEquationControls();
			//</mam>

			base.OnLoad(e);
		}

		private void		UpdateColumnTitles()
		{
			grid[0, (int)Columns.Name] = 
				grid[1, (int)Columns.Name] = "Components / Subbasins / Subzones\r\nin this\r\nProcess / Basis / Zone";
		}

		public void			SetRootObject(TreatmentProcess obj)
		{
			m_root = obj;
			LoadGrid();
		}

		private void		LoadGrid()
		{
			if (m_root == null)
			{
				grid.Rows.Count = 2;
				return;
			}

			grid.Rows.Count = 2;

			LoadTreatmentProcessGrid();
		}

		private void		LoadTreatmentProcessGrid()
		{
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			// Load the process list
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, process.ID);
			MajorComponent component;
			int				row = 2;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (component.Retired)
					continue;

				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = component;
				UpdateComponentAssessmentGridRow(row++, component);
			}

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		private void		UpdateComponentAssessmentGridRow(int row, MajorComponent component)
		{
			grid.SetData(row, (int)Columns.Name, 
				component.Name);

			//mam
			//if Current Value is zero, set the following values to N/A
			if (component.GetCurrentValue() == 0)
			{
				grid.SetData(row, (int)Columns.UsefulLifeOrg, "N/A");
				grid.SetData(row, (int)Columns.LOS, "N/A");
				grid.SetData(row, (int)Columns.OverallCriticality, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeBook, "N/A");
				grid.SetData(row, (int)Columns.Vulnerability, "N/A");
				grid.SetData(row, (int)Columns.Risk, "N/A");
				grid.SetData(row, (int)Columns.ConditionRank, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.UsefulLifeOrg, 
					string.Format("{0:F1}", component.GetOrgUsefulLife()));
				grid.SetData(row, (int)Columns.LOS, component.GetLOS().ToString("0.0"));

				grid.SetData(row, (int)Columns.OverallCriticality, component.GetOverallCriticality().ToString("0.0"));

				grid.SetData(row, (int)Columns.UsefulLifeBook, 
					string.Format("{0:F1}", component.GetRemainingUsefulLife()));

				//if all ERUL values are zero and no Vulnerabilities are overridden, Vuln and Risk = N/A
				if (WAM.Common.CommonTasks.GetAllERULZero(InfoSet.CurrentID, component.ID) 
					&& !WAM.Common.CommonTasks.GetAnyVulnerabilityOverridden(InfoSet.CurrentID, component.ID))
				{
					grid.SetData(row, (int)Columns.Vulnerability, "N/A");
					grid.SetData(row, (int)Columns.Risk, "N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F2}", component.Vulnerability));
					grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F4}", component.Vulnerability));

					grid.SetData(row, (int)Columns.Risk, string.Format("{0:F2}", component.GetRisk()));
				}

				if (CheckIfAllNADiscipline(component.ID))
				{
					grid.SetData(row, (int)Columns.ConditionRank, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
				}
				else
				{
					grid.SetData(row, (int)Columns.ConditionRank, 
						string.Format("{0:F1}", component.GetRankPercentInterpolated()));
					grid.SetData(row, (int)Columns.UsefulLifeEval, 
						string.Format("{0:F1}", component.GetEvaluatedRemainingUsefulLife()));
					grid.SetData(row, (int)Columns.UsefulLifeEconomic, 
						string.Format("{0:F1}", component.GetEconomicUsefulLife()));
				}
			}
			//</mam

			//for MSL Process - set LOS, Overall Crit = values (rather than N/A) regardless of Total Current Value or Condition
			if (component.MechStructDisciplines)
			{
				grid.SetData(row, (int)Columns.LOS, component.GetLOS().ToString("0.0"));
				grid.SetData(row, (int)Columns.OverallCriticality, component.GetOverallCriticality().ToString("0.0"));
			}
		}

		//mam
		private bool CheckIfAllNADiscipline(int componentID)
		{
			//mam - check whether all pipes and nodes for this Discipline have Condition = N/A;

			bool AllNA = true;

			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, componentID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			//mam 050806
			//mam 112806 - don't use this variable
			//discOverrideRepairCost = false;

			////mam 112806
			//discOverrideCurrentValue = false;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllConditionNA())
					{
						AllNA = false;

						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (pipe.OverrideRepairCost)
					if (pipe.GetAnyRepairCostOverridden())
					{
						//mam 112806 - don't use this variable
						//discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					////mam 112806
					//if (pipe.GetAnyCurrentValueOverridden())
					//{
					//	discOverrideCurrentValue = true;
					//}
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllConditionNA())
					{
						AllNA = false;

						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (node.OverrideRepairCost)
					if (node.GetAnyRepairCostOverridden())
					{
						//mam 112806 - don't use this variable
						//discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					////mam 112806
					//if (node.GetAnyCurrentValueOverridden())
					//{
					//	discOverrideCurrentValue = true;
					//}
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					//mam 050806
					if (AllNA)
					{
						AllNA = (discipline.ConditionRanking == CondRank.No);
					}

					//mam 112806 - commented
					//if (!AllNA && discOverrideRepairCost)
					//{
					//	break;
					//}

					//mam 050806
					if (discipline.OverrideRepairCost)
					{
						//mam 112806 - don't use this variable
						//discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					////mam 112806
					//if (discipline.OverrideCurrentValue)
					//{
					//	discOverrideCurrentValue = true;
					//}
				}
			}

			return AllNA;
		}
		//</mam>

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
		}

		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandlerGrid(grid, colTag);
		}
		//</mam>

		#endregion /***** Methods *****/
	}
}