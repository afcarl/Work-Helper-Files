using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI.Grids
{
	/// <summary>
	/// Summary description for DisciplineAssessmentGrid.
	/// </summary>
	public class DisciplineAssessmentGrid : System.Windows.Forms.UserControl
	{
		enum Columns
		{
			Name = 0,
			ConditionRank,
			UsefulLifeOrg,
			UsefulLifeBook,
			UsefulLifeEval,

			//mam - added these
			UsefulLifeEconomic,
			LOS,
			OverallCriticality,
			Vulnerability,
			Risk,
			//</mam>
		}

		private MajorComponent m_root = null;

		private C1.Win.C1FlexGrid.C1FlexGrid grid;

		//mam
		ArrayList colTag = new ArrayList();
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		//</mam>

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DisciplineAssessmentGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			grid.Rows[0].AllowMerging = 
				grid.Rows[1].AllowMerging = true;

			foreach (Column col in grid.Cols)
			{
				col.AllowMerging = true;
				col.StyleFixedNew.TextAlign =
					C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
			}

			//grid[0, (int)Columns.ConditionRank] = 
			//	grid[1, (int)Columns.ConditionRank] = "Condition\r\nRanking";
			grid[0, (int)Columns.ConditionRank] = 
				grid[1, (int)Columns.ConditionRank] = "Condition\r\nRanking";

			grid[0, (int)Columns.UsefulLifeOrg] = 
				grid[0, (int)Columns.UsefulLifeEval] = 
				grid[0, (int)Columns.UsefulLifeBook] = 
				grid[0, (int)Columns.UsefulLifeEconomic] = "Useful Life (Yrs)";
			grid[1, (int)Columns.UsefulLifeOrg] = "Original";
			grid[1, (int)Columns.UsefulLifeBook] = "Remaining";
			grid[1, (int)Columns.UsefulLifeEval] = "Evaluated Remaining";
			grid[1, (int)Columns.UsefulLifeEconomic] = "Economic Remaining";

			//mam - added the following code
			grid[0, (int)Columns.LOS] = 
				grid[1, (int)Columns.LOS] = "Level of\r\nService";
			grid[0, (int)Columns.OverallCriticality] = 
				grid[1, (int)Columns.OverallCriticality] = "Overall\r\nCriticality";
			grid[0, (int)Columns.Vulnerability] = 
				grid[1, (int)Columns.Vulnerability] = "Vulnerability";
			grid[0, (int)Columns.Risk] = 
				grid[1, (int)Columns.Risk] = "Risk";
			//</mam>

			grid.Rows[1].HeightDisplay = 
				(int)(grid.Rows[1].HeightDisplay * 2.0);
		}

		//mam - set LOS, Crit, Vuln, and Risk visibility depending on whether
		//	a Mech/Land/Struct or Pipe/Node discipline grid is being viewed
		public void SetVisibilityColumns(bool isVisible)
		{
			grid.Cols[(int)Columns.LOS].Visible = isVisible;
			grid.Cols[(int)Columns.OverallCriticality].Visible = isVisible;
			grid.Cols[(int)Columns.Vulnerability].Visible = isVisible;
			grid.Cols[(int)Columns.Risk].Visible = isVisible;
		}
		//</mam>

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grid = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// grid
			// 
			this.grid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.grid.AllowEditing = false;
			this.grid.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.grid.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.grid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.grid.ColumnInfo = @"10,0,0,0,0,85,Columns:0{Width:250;Caption:""Disciplines"";AllowEditing:False;DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	1{Width:70;Caption:""Condition Ranking"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	2{Width:65;Caption:""Original"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	3{Width:65;Caption:""Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	4{Width:65;Caption:""Evaluated Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	5{Width:65;Caption:""Economic Remaining"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	6{Width:65;Caption:""Level of Service"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	7{Width:65;Caption:""Overall Criticality"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	8{Width:65;Caption:""Vulnerability"";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	9{Width:65;Caption:""Risk"";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	";
			this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.grid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.grid.Location = new System.Drawing.Point(0, 0);
			this.grid.Name = "grid";
			this.grid.Rows.Count = 3;
			this.grid.Rows.Fixed = 2;
			this.grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.grid.ShowSort = false;
			this.grid.Size = new System.Drawing.Size(388, 128);
			this.grid.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.grid.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.grid.TabIndex = 0;
			// 
			// DisciplineAssessmentGrid
			// 
			this.Controls.Add(this.grid);
			this.Name = "DisciplineAssessmentGrid";
			this.Size = new System.Drawing.Size(388, 128);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// create frozen area at the bottom, with 1 rows
			FlexFreezeBottom ffb = new FlexFreezeBottom(grid, 1);

			UpdateColumnTitles();

			base.OnLoad(e);
		}

		private void		UpdateColumnTitles()
		{
			grid[0, (int)Columns.Name] = 
				grid[1, (int)Columns.Name] = "Disciplines";
		}

		public void			SetRootObject(MajorComponent obj)
		{
			m_root = obj;
			LoadGrid();

			//mam
			if (m_root == null)
				return;

			colTag.Clear();

			colTag.Add("");

			//colTag.Add("COND");
			//colTag.Add("OUL");
			//colTag.Add("RUL");
			//colTag.Add("ERUL");
			//colTag.Add("ECUL");
			if (m_root.MechStructDisciplines)
			{
				colTag.Add("CONDASSESSMSL");
				colTag.Add("OULMSL");
				colTag.Add("RULMSL");
				colTag.Add("ERULMSL");
				colTag.Add("ECULMSL");
				colTag.Add("LOS");
				colTag.Add("CRIT");
				colTag.Add("VULN");
				colTag.Add("RISK");
			}
			else
			{
				colTag.Add("CONDASSESSPN");
				colTag.Add("OULPN");
				colTag.Add("RULPN");
				colTag.Add("ERULPN");
				colTag.Add("ECULPN");
				colTag.Add("LOS");
				colTag.Add("CRIT");
				colTag.Add("VULNPN");
				colTag.Add("RISKPN");
			}

			SetEquationControls();
			//</mam>
		}

		private void		LoadGrid()
		{
			if (m_root == null)
			{
				grid.Rows.Count = 3;
				return;
			}

			grid.Rows.Count = 3;
			LoadAssessmentGrid();
		}

		private void		LoadAssessmentGrid()
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			//----------------------
			//WAM.Logic.DisciplineTotals totals = component.GetDisciplineTotals();
			//decimal totalValue = totals.GetTotalCurrentValue();
			//----------------------

			// Load the process list
			Discipline[] disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
			Discipline discipline;
			int				row = 2;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				grid.Rows.Add();
				grid.Rows[row].UserData = discipline;
				UpdateDisciplineGridRow(row++, discipline);
			}

			UpdateDisciplineGridTotals();

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		//mam
		private bool CheckIfAllNADiscipline(Discipline discipline)
		{
			//mam - check whether all pipes and nodes for this Discipline
			//	have Condition = N/A;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			pipe = discipline as DisciplinePipe;
			node = discipline as DisciplineNode;
			bool AllNA = true;

			if (discipline.Type == DisciplineType.Pipes)
			{
				if (pipe != null)
					return pipe.GetAllConditionNA();
			}
			else if (discipline.Type == DisciplineType.Nodes)
			{
				if (node != null)
					return node.GetAllConditionNA();
			}

			else if (discipline.Type == DisciplineType.Mechanical 
				|| discipline.Type == DisciplineType.Structural
				|| discipline.Type == DisciplineType.Land)
			{
				if (discipline.ConditionRanking != CondRank.No)
				{
					AllNA = false;
				}
			}

			return AllNA;
		}
		//</mam>

		private void		UpdateDisciplineGridRow(int row, Discipline discipline)
		{
			//mam - reworked this whole method

			DisciplinePipe	pipe;
			DisciplineNode	node;

			grid.SetData(row, (int)Columns.Name, 
				discipline.Name);

			//********** set condition value

			//set condition value
			if (discipline.Type == DisciplineType.Nodes || discipline.Type == DisciplineType.Pipes)
			{
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					grid.SetData(row, (int)Columns.ConditionRank, string.Format("{0:F1}", node.GetAverageCondition()));
				}
				else
				{
					pipe = discipline as DisciplinePipe;
					grid.SetData(row, (int)Columns.ConditionRank, string.Format("{0:F1}", pipe.GetAverageCondition()));
				}
			}
			else
			{
				grid.SetData(row, (int)Columns.ConditionRank, 
					string.Format("{0:0}", (int)discipline.ConditionRanking));
			}

			//********** set useful life values

			//set useful life values
			grid.SetData(row, (int)Columns.UsefulLifeOrg, 
				string.Format("{0:F1}", discipline.OrgUsefulLife));
			grid.SetData(row, (int)Columns.UsefulLifeBook, 
				string.Format("{0:F1}", discipline.GetRemainingUsefulLife()));
			grid.SetData(row, (int)Columns.UsefulLifeEval, 
				string.Format("{0:F1}", discipline.GetEvaluatedRemainingUsefulLife()));
			grid.SetData(row, (int)Columns.UsefulLifeEconomic, 
				string.Format("{0:F1}", discipline.GetEconomicUsefulLife()));

			//********** set n/a values

			//set n/a values for pipes and nodes
			if (discipline.Type == DisciplineType.Pipes || discipline.Type == DisciplineType.Nodes)
			{
				//set pipes/nodes OUL and RUL to n/a if there are no individual pipes/nodes
				if (discipline.GetItemCount() == 0)
				{
					grid.SetData(row, (int)Columns.UsefulLifeOrg, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeBook, "N/A");
				}

				//set pipes/nodes condition, eval and econ UL to n/a if all pipes/nodes have condition = n/a
				if (CheckIfAllNADiscipline(discipline))
				{
					grid.SetData(row, (int)Columns.ConditionRank, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
				}

				//check Current Value for pipes and nodes because the Assessment grid shows average values
				//	based on Total Current Value
				if (discipline.GetCurrentValue() == 0)
				{
					grid.SetData(row, (int)Columns.ConditionRank, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeOrg, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeBook, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
				}
			}
			else
			//set n/a values for mech, struct, land disciplines
			{
				//if condition = n/a or zero, set n/a values
				//if (discipline.ConditionRanking == CondRank.No || discipline.ConditionRanking == CondRank.C0)
				if (discipline.ConditionRanking == CondRank.No)
				{
					//don't set OUL and RUL to N/A regardless of condition value
					//grid.SetData(row, (int)Columns.UsefulLifeOrg, "N/A");
					//grid.SetData(row, (int)Columns.UsefulLifeBook, "N/A");
					grid.SetData(row, (int)Columns.ConditionRank, "N/A");				
					grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
					grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
				}
			}

			//********** set LOS, Crit, Vuln Risk values

			//mam - data for the new columns LOS, Crit, Vuln, Risk
			decimal tempValue = 0m;
			pipe = discipline as DisciplinePipe;
			node = discipline as DisciplineNode;

			if (pipe != null)
			{
				//if any of the values are zero, this means that the CWP is zero,
				//	which means that the Current Value is zero
				tempValue = (decimal)pipe.GetAverageLOS();
				if (tempValue == 0)
					grid.SetData(row, (int)Columns.LOS, "N/A");
				else
					grid.SetData(row, (int)Columns.LOS, string.Format("{0:F1}", tempValue));

				tempValue = (decimal)pipe.GetAverageCriticality();
				if (tempValue == 0)
					grid.SetData(row, (int)Columns.OverallCriticality, "N/A");
				else
					grid.SetData(row, (int)Columns.OverallCriticality, string.Format("{0:F1}", tempValue));

				//mam - if CurrentValue is zero, Vuln and Risk = N/A
				tempValue = pipe.GetCurrentValue();
				if (tempValue == 0 || (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden()))
				{
					grid.SetData(row, (int)Columns.Vulnerability, "N/A");
					grid.SetData(row, (int)Columns.Risk, "N/A");
				}
				else
				{
					//mam - use probability
					//mam 090105 - round vuln to 4 decimals rather than 2
					//grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F2}", Math.Round(pipe.GetAverageVulnerability(), 4)));
					grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F4}", Math.Round(pipe.GetAverageVulnerability(), 4)));

					grid.SetData(row, (int)Columns.Risk, string.Format("{0:F2}", Math.Round((decimal)pipe.GetAverageRisk(), 2)));
				}
			}
			else if (node != null)
			{
				//if any of the values are zero, this means that the CWP is zero,
				//	which means that the Current Value is zero
				tempValue = node.GetAverageLOS();
				if (tempValue == 0)
					grid.SetData(row, (int)Columns.LOS, "N/A");
				else
					grid.SetData(row, (int)Columns.LOS, string.Format("{0:F1}", tempValue));

				tempValue = (decimal)node.GetAverageCriticality();
				if (tempValue == 0)
					grid.SetData(row, (int)Columns.OverallCriticality, "N/A");
				else
					grid.SetData(row, (int)Columns.OverallCriticality, string.Format("{0:F1}", tempValue));

				//mam - if CurrentValue is zero, Vuln and Risk = N/A
				tempValue = node.GetCurrentValue();
				if (tempValue == 0 || (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden()))
				{
					grid.SetData(row, (int)Columns.Vulnerability, "N/A");
					grid.SetData(row, (int)Columns.Risk, "N/A");
				}
				else
				{
					//mam - use probability
					//mam 090105 - round vuln to 4 decimals rather than 2
					//grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F2}", Math.Round(node.GetAverageVulnerability(), 4)));
					grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F4}", Math.Round(node.GetAverageVulnerability(), 4)));

					grid.SetData(row, (int)Columns.Risk, string.Format("{0:F2}", Math.Round((decimal)node.GetAverageRisk(), 2)));
				}
			}
		}

		private void		UpdateDisciplineGridTotals()
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			WAM.Logic.DisciplineTotals totals = 
				component.GetDisciplineTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");

			//mam - use interpolated value rather than enum to calculate Condition
			//double			rankPercent = totals.GetRankPercent();
			double rankPercent = totals.GetRankPercentInterpolated();
			//</mam>

			//mam - moved this code up from below 121405
			grid.SetData(row, (int)Columns.UsefulLifeOrg, 
				string.Format("{0:F1}", totals.GetTotalOrgUsefulLife()));
			grid.SetData(row, (int)Columns.UsefulLifeBook, 
				string.Format("{0:F1}", totals.GetTotalRemainingUsefulLife()));

			//mam - check the Condition rather than the rankPercent
			//original code:
			//if (rankPercent >= 1.0)
			//new code:
			if (totals.CheckIfAllNADiscipline(component.InfoSetID, component.ID))
			//</mam>
			{	
				grid.SetData(row, (int)Columns.ConditionRank, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.ConditionRank, 
					string.Format("{0:F1}", rankPercent));
				grid.SetData(row, (int)Columns.UsefulLifeEval, 
					string.Format("{0:F1}", totals.GetTotalEvaluatedRemainingUsefulLife()));
				grid.SetData(row, (int)Columns.UsefulLifeEconomic, 
					string.Format("{0:F1}", totals.GetTotalEconomicUsefulLife()));
			}

//			//mam - move this code up 121405
//			grid.SetData(row, (int)Columns.UsefulLifeOrg, 
//				string.Format("{0:F1}", totals.GetTotalOrgUsefulLife()));
//			grid.SetData(row, (int)Columns.UsefulLifeBook, 
//				string.Format("{0:F1}", totals.GetTotalRemainingUsefulLife()));

			//mam - add totals for LOS, Crit, Vuln, Risk
			grid.SetData(row, (int)Columns.LOS, 
				component.GetLOS().ToString("0.0"));

			grid.SetData(row, (int)Columns.OverallCriticality, component.GetOverallCriticality().ToString("0.0"));

			//mam - use probability
			//grid.SetData(row, (int)Columns.Vulnerability, 
			//	EnumHandlers.GetVulnerabilityShort(component.Vulnerability));
			if (totals.CheckIfAllNAVulnerability(component.InfoSetID, component.ID))
			{
				grid.SetData(row, (int)Columns.Vulnerability, "N/A");
				grid.SetData(row, (int)Columns.Risk, "N/A");
			}
			else
			{
				//mam 090105 - round vuln to 4 decimals rather than 2
				//grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F2}", component.Vulnerability));
				grid.SetData(row, (int)Columns.Vulnerability, string.Format("{0:F4}", component.Vulnerability));

				grid.SetData(row, (int)Columns.Risk, string.Format("{0:F2}", component.GetRisk()));
			}

			//mam - set OUL and RUL to N/A if total Current Value = zero
			if (component.GetCurrentValue() == 0)
			{
				grid.SetData(row, (int)Columns.UsefulLifeOrg, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeBook, "N/A");
				grid.SetData(row, (int)Columns.LOS, "N/A");
				grid.SetData(row, (int)Columns.OverallCriticality, "N/A");
				grid.SetData(row, (int)Columns.Vulnerability, "N/A");
				grid.SetData(row, (int)Columns.Risk, "N/A");

				//mam - added these 121504
				grid.SetData(row, (int)Columns.ConditionRank, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEval, "N/A");
				grid.SetData(row, (int)Columns.UsefulLifeEconomic, "N/A");
			}
			//</mam>
		}

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
		}

		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandlerGrid(grid, colTag);
		}
		//</mam>

	}
}