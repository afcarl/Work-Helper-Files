using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI.Grids
{
	/// <summary>
	/// Summary description for ComponentGrid.
	/// </summary>
	public class ComponentGrid : System.Windows.Forms.UserControl
	{
		#region /***** Enumerations *****/

		enum Columns
		{
			Name = 0,
			CWPValue,
			AcquisitionCost,
			CurrentValue,
			AcquisitionCostEscalated,
			ReplacementValue,

			//mam 050806
			ReplacementValueYearAverage,

			RehabCost,
			BookValue,
			SalvageValue,
			AnnualDepreciation,
			CumulativeDepreciation,
			EvaluatedValue,
			RepairCost,
			AnnualMaintenance,
		}

		public enum GridType
		{
			MajorComponents = 0,
			Disciplines
		}

		#endregion /***** Enumerations *****/

		#region /***** Variables *****/

		private object		m_root = null;
		private GridType	m_gridType = GridType.MajorComponents;

		//mam 050806
		private bool discOverrideRepairCost = false;

		//mam 112806
		private bool discOverrideCurrentValue = false;

		//mam
		ArrayList colTag = new ArrayList();
		WAM.UI.EquationViewerHandler equationViewerHandler = new EquationViewerHandler();
		//</mam>

		private C1.Win.C1FlexGrid.C1FlexGrid grid;
		private System.ComponentModel.Container components = null;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public ComponentGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

//			grid.Rows[0].AllowMerging = 
//				grid.Rows[1].AllowMerging = true;
//
//			foreach (Column col in grid.Cols)
//			{
//				col.AllowMerging = true;
//				col.StyleFixedNew.TextAlign =
//					C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
//			}

			//mam
			this.grid.AllowEditing = false;
			//</mam>

			grid.Rows[0].HeightDisplay = 
				(int)(grid.Rows[0].HeightDisplay * 3.0);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grid = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// grid
			// 
			this.grid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.grid.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.grid.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.grid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.grid.ColumnInfo = "15,0,0,0,0,85,Columns:0{Width:250;Caption:\"Disciplines\";AllowEditing:False;DataTy" +
				"pe:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t1{Width:75;C" +
				"aption:\"Cost Weighted Percentage of Asset Value\";DataType:System.Double;Format:\"" +
				"F1\";TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t2{Width:75;Caption:\"Acqu" +
				"isition Cost ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t3{Width:75;Caption:\"Current Value ($)\";DataType:System.String;TextA" +
				"lign:RightCenter;TextAlignFixed:CenterCenter;}\t4{Width:75;Caption:\"Escalated Acq" +
				"uisition Cost\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Cente" +
				"rCenter;}\t5{Width:75;Caption:\"Replacement Value ($)\";DataType:System.String;Text" +
				"Align:RightCenter;TextAlignFixed:CenterCenter;}\t6{Width:75;Caption:\"Average Repl" +
				"acement Value Year\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:" +
				"CenterCenter;}\t7{Width:75;Caption:\"Rehabilitation Cost ($)\";DataType:System.Stri" +
				"ng;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t8{Width:75;Caption:\"Book " +
				"Value ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCen" +
				"ter;}\t9{Width:75;Caption:\"Salvage Value ($)\";DataType:System.String;TextAlign:Ri" +
				"ghtCenter;TextAlignFixed:CenterCenter;}\t10{Width:75;Caption:\"Annual Depreciation" +
				" ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}" +
				"\t11{Width:75;Caption:\"Cumulative Depreciation ($)\";DataType:System.String;TextAl" +
				"ign:RightCenter;TextAlignFixed:CenterCenter;}\t12{Width:75;Caption:\"Evaluated Val" +
				"ue ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter" +
				";}\t13{Width:75;Caption:\"Repair Cost ($)\";DataType:System.String;TextAlign:RightC" +
				"enter;TextAlignFixed:CenterCenter;}\t14{Width:75;Caption:\"Annual Maintenance Cost" +
				" ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}" +
				"\t";
			this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.grid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.grid.Location = new System.Drawing.Point(0, 0);
			this.grid.Name = "grid";
			this.grid.Rows.Count = 2;
			this.grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.grid.ShowSort = false;
			this.grid.Size = new System.Drawing.Size(388, 128);
			this.grid.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.grid.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.grid.TabIndex = 0;
			this.grid.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.grid_AfterEdit);
			this.grid.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.grid_StartEdit);
			// 
			// ComponentGrid
			// 
			this.Controls.Add(this.grid);
			this.Name = "ComponentGrid";
			this.Size = new System.Drawing.Size(388, 128);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			// create frozen area at the bottom, with 1 rows
			FlexFreezeBottom ffb = new FlexFreezeBottom(grid, 1);

			UpdateColumnTitles();

			//mam
			SetEquationControls();
			//</mam>

			base.OnLoad(e);
		}

		//mam
		private void AssignEquationViewerTags()
		{
			try
			{
				colTag.Clear();

				colTag.Add("");	//component
				colTag.Add("");	//cost-weighted %
				colTag.Add("AC");	//acquisition cost
				colTag.Add("CV");	//current value
				colTag.Add("EAC");	//escalated acquisition cost
				colTag.Add("");	//replacement value

				//mam 112806
				if (m_root != null)
				{
					if (m_root is TreatmentProcess)
					{
						colTag.Add("RRVY");	//replacement value year
					}
					else
					{
						if (((MajorComponent)m_root).MechStructDisciplines)
							colTag.Add("RVY");	//replacement value year
						else
							colTag.Add("ARRVY");	//replacement value year
					}
				}
				else
				{
					colTag.Add("");	//replacement value year
				}

				colTag.Add("");	//rehab cost
				colTag.Add("BV");	//book value
				colTag.Add("");	//salvage value
				colTag.Add("AD");	//annual depreciation
				colTag.Add("CD");	//cumulative depreciation
			
				colTag.Add("EV");
				//colTag.Add("REV");

				colTag.Add("RC");
				colTag.Add("");	//annual maint cost
			}
			catch
			{
			}
		}

		private void		UpdateColumnTitles()
		{
			if (m_gridType == GridType.MajorComponents)
			{
				grid[0, (int)Columns.Name] =
					"Components / Subbasins / Subzones\r\nin this\r\nProcess / Basis / Zone";
			}
			else if (m_gridType == GridType.Disciplines)
			{
				grid[0, (int)Columns.Name] = "Disciplines";

				//mam 112806 - add "Average" to column caption as necessary
				if (((MajorComponent)m_root).MechStructDisciplines)
				{
					grid[0, (int)Columns.ReplacementValueYearAverage] = 
						grid[1, (int)Columns.ReplacementValueYearAverage] = "Replacement\r\nValue Year";
				}
				else
				{
					grid[0, (int)Columns.ReplacementValueYearAverage] = 
						grid[1, (int)Columns.ReplacementValueYearAverage] = "Average\r\nReplacement\r\nValue Year";
				}
			}

			grid[0, (int)Columns.CWPValue] =
				"Cost Weighted\r\nPercentage of\r\nAsset Value";
		}

		public GridType		GridStyle
		{
			get { return m_gridType; }
			set 
			{ 
				m_gridType = value;
				UpdateColumnTitles();
			}
		}

		public void			SetRootObject(object obj)
		{
			m_root = obj;

			//mam - m_gridtype is initialized as GridType.MajorComponents
			//	but is never set to the proper type
			if (m_root is TreatmentProcess)
				m_gridType = GridType.MajorComponents;
			else if (m_root is MajorComponent)
				m_gridType = GridType.Disciplines;
			//</mam>

			LoadGrid();
			AssignEquationViewerTags();
		}

		private void		LoadGrid()
		{
			if (m_root == null)
			{
				grid.Rows.Count = 2;
				return;
			}

			grid.Rows.Count = 2;

			//mam - column headers are never set for the current tree node type
			UpdateColumnTitles();
			//</mam>

			if (m_root is TreatmentProcess)
				LoadTreatmentProcessGrid();
			else if (m_root is MajorComponent)
				LoadMajorComponentGrid();
		}

		private void		LoadTreatmentProcessGrid()
		{
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			// Load the process list
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, process.ID);
			MajorComponent component;
			int				row = 1;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (component.Retired)
					continue;

				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = component;
				UpdateComponentGridRow(row++, component);
			}

			UpdateComponentGridTotals();

			//mam - adjust CWPValue percentages so that they total exactly 100.0 (rather than 100.1, or 99.9, etc.)
			AdjustCWPValuesTreatment();
			
			//mam
			PerformRounding();
			//</mam>

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		private void		LoadMajorComponentGrid()
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			// Load the process list
			Discipline[] disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
			Discipline discipline;
			int				row = 1;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = discipline;
				UpdateDisciplineGridRow(row++, discipline);
			}

			UpdateDisciplineGridTotals();

			//mam - adjust CWPValue percentages so that they total exactly 100.0 (rather than 100.1, or 99.9, etc.)
			AdjustCWPValuesComponent();

			//mam
			PerformRounding();
			//</mam>

			// Set the data in the totals columns
			grid.Redraw = true;
		}
		
		//mam
		private void PerformRounding()
		{
			ArrayList roundingColExceptions = new ArrayList();
			roundingColExceptions.Add((int)Columns.ReplacementValueYearAverage);

			//MessageBox.Show("row count = " + c1FlexGridProcesses.Rows.Count.ToString());
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			WAMRounding.PerformRounding(1, 2, grid, roundingColExceptions);
			//WAMRounding.PerformRounding(3, 4, grid);
		}
		//</mam>

		//mam
		private void AdjustCWPValuesTreatment()
		{
			//mam 112806 - calling AdjustCWPValues() overwrites the values set in UpdateGridRow for column CWPValue

			//adjust CWPValue percentages so that they total exactly 100.0 (rather than 100.1, or 99.9, etc.)
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			//mam 091607 - get rounded values so the error explained in AdjustCWPValues won't occur
			//WAM.Logic.MajorComponentTotals totals = process.GetComponentTotals();
			WAM.Logic.MajorComponentTotals totals = process.GetComponentTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal totalValue = totals.GetTotalCurrentValue();
			decimal totalValue = totals.GetTotalAcquisitionCostRoundIndividualValues();

			AdjustCWPValues(totalValue);
		}
		//</mam>

		//mam
		private void AdjustCWPValuesComponent()
		{
			//mam 112806 - calling AdjustCWPValues() overwrites the values set in UpdateGridRow for column CWPValue

			//adjust CWPValue percentages so that they total exactly 100.0 (rather than 100.1, or 99.9, etc.)
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			WAM.Logic.DisciplineTotals totals = component.GetDisciplineTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal totalValue = totals.GetTotalCurrentValue();
			decimal totalValue = totals.GetTotalAcquisitionCostRoundIndividualValues();

			AdjustCWPValues(totalValue);
		}
		//</mam>

		//mam
		private void AdjustCWPValues(decimal totalValue)
		{
			try
			{
				//mam 112806 - calling AdjustCWPValues() overwrites the values set in UpdateGridRow for column CWPValue

				//mam 091607 - round incoming totalValue because an error is occurring whenever 
				//	rounded AC is <= 99.7% of totalValue (totalValue is the unrounded AC)
				//it takes the right combination ENR values and a very low AC value (approx $100 or less) to cause this problem
				//for instance, for Replacement Value = $100, Replacement Value Year = 2006, Replacement Year ENR = 7751,
				//	Installation Year = 2000, and Original ENR = 7939, the AC calc would be as follows:
				//	AC = RC * Original ENR / Replacement Year ENR --> AC = 100 * 7939 / 7751 = 102.43
				//when the CWP is calculated, below, is looks at totalValue (unrounded AC) and calculated AC ( 
				//	102 / 102.43 = 99.58, truncated to 99.5, multiplied by 10, to get 995 (trueValue)
				//then, totalAdjustmentsRequired = 1000 minus trueValue --> 1000 - 995 = 5
				//	the code thinks 5 adjustments need to be made, but an error occurs on adjustment 4 because
				//	there are only 3 elements in cwpArray, but the loop wants to count to 5 (totalAdjustmentsRequired)
				//	(see "error occurs here because cwpArray has fewer members than the value of totalAdjustmentsRequired", below)
				//	the adjustment code should not run in this instance, because the need for adjustment is not legitimate
				//	-- rather, it is caused by comparing a rounded number with an unrounded number
				//solution:  round incoming totalValue to zero decimals
				//note:  this problem has not been observed before now because there haven't been any very low AC values

				totalValue = Math.Round(totalValue, 0);

				//correct CWP values on when the Current Value total > 0
				if (totalValue > 0)
				{
					int RowDataStarts = 1;
					int ArrayLength = grid.Rows.Count-(RowDataStarts + 1);

					decimal trueValue = 0;
					decimal[] cwpArrayTruncValue = new decimal[ArrayLength];
					decimal[] cwpArrayErrorValue = new decimal[ArrayLength];
					decimal[,] bubbleList = new decimal[ArrayLength, 2];
					decimal tempItem = 0;
					long totalTruncValue = 0;
					bool bubbleSorted = false;
					long totalAdjustmentsRequired = 0;

					grid.Redraw = false;
					for (int row=RowDataStarts; row < grid.Rows.Count-1; row++)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue, which makes this N/A check unnecessary
						////mam 112806
						//if (grid.GetData(row, (int)Columns.CurrentValue).ToString() == "N/A")
						//{
						//	continue;
						//}

						//divide CurrentValue for this row by the total of the Current Value column

						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//trueValue = Decimal.Parse((grid.GetData(row, (int)Columns.CurrentValue).ToString()),
						//	System.Globalization.NumberStyles.Currency) / totalValue * 100m;
						trueValue = Decimal.Parse((grid.GetData(row, (int)Columns.AcquisitionCost).ToString()),
							System.Globalization.NumberStyles.Currency) / totalValue * 100m;

						//truncate trueValue after the first decimal place
						cwpArrayTruncValue[row-RowDataStarts] = (Decimal.Truncate(trueValue * 10m)) / 10m;

						//calculate error value
						cwpArrayErrorValue[row-RowDataStarts] = trueValue - cwpArrayTruncValue[row-RowDataStarts];

						//multiply truncated value by 10 to work in whole numbers
						totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[row-RowDataStarts] * 10m);
					}

					//populate bubbleList array
					bubbleSorted = false;
					for (int i = 0; i < ArrayLength; i++)
					{
						//assign the counter
						bubbleList[i, 0] = i;
						//assign the error value
						bubbleList[i, 1] = cwpArrayErrorValue[i];
					}

					//sort the bubbleList from highest to lowest Error Value
					bubbleSorted = false;
					do
					{
						bubbleSorted=true;
						for (int i = 0; i < ArrayLength-1; i++)
						{
							if (bubbleList[i,1] < bubbleList[i+1,1])
							{
								bubbleSorted = false;

								//switch the order of the two items
								tempItem = bubbleList[i,1];
								bubbleList[i,1] = bubbleList[i+1,1];
								bubbleList[i+1,1] = tempItem;

								tempItem = bubbleList[i,0];
								bubbleList[i,0] = bubbleList[i+1,0];
								bubbleList[i+1,0] = tempItem;
							}
						}
					}
					while (!bubbleSorted);
					//				for (int i=0; i<ArrayLength; i++)
					//				{
					//					System.Diagnostics.Debug.WriteLine("bubbleList[" + i + "] = " + bubbleList[i,0]);
					//				}
					//adjust the truncated values, as necessary
					totalAdjustmentsRequired = 1000 - totalTruncValue;
					for (int i = 0; i < totalAdjustmentsRequired; i++)
					{
						//error occurs here because cwpArray has fewer members than the value of totalAdjustmentsRequired
						cwpArrayTruncValue[Convert.ToInt32(bubbleList[i, 0])] += 0.1m;
					}

					//write the adjusted CPW values to the grid
					tempItem = 0;
					for (int row=RowDataStarts; row < grid.Rows.Count-1; row++)
					{
						grid.SetData(row, (int)Columns.CWPValue, (double)cwpArrayTruncValue[row-RowDataStarts]);
						tempItem += cwpArrayTruncValue[row-RowDataStarts];
					}

					//update CPWValues total in the grid
					grid.SetData(grid.Rows.Count - 1, (int)Columns.CWPValue, tempItem);

					grid.Redraw = true;
				}
			}
			catch
			{
			}
		}
		//</mam>

		private void		UpdateComponentGridRow(int row, MajorComponent component)
		{
			//you are here
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			WAM.Logic.MajorComponentTotals totals = process.GetComponentTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalCurrentValue = totals.GetTotalCurrentValue();
			decimal			totalCurrentValue = totals.GetTotalAcquisitionCost();


			grid.SetData(row, (int)Columns.Name, component.Name);

			if (totalCurrentValue != 0)
			{
				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//double		val = Math.Round((double)(component.GetCurrentValue() / totalCurrentValue) * 100.0, 1);
				double		val = Math.Round((double)(component.GetAcquisitionCost() / totalCurrentValue) * 100.0, 1);

				grid.SetData(row, (int)Columns.CWPValue, val);
			}
			else
			{
				grid.SetData(row, (int)Columns.CWPValue, 0.0);
			}

			grid.SetData(row, (int)Columns.AcquisitionCost, 
				component.GetAcquisitionCost().ToString("$#,##0"));

			//mam 112806 - commented
			//grid.SetData(row, (int)Columns.CurrentValue, component.GetCurrentValue().ToString("$#,##0"));

			//mam 112806 - added
			bool allDiscNA = CheckIfAllNADiscipline(component.ID);
			if (allDiscNA && !discOverrideCurrentValue)
			{
				grid.SetData(row, (int)Columns.CurrentValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.CurrentValue, component.GetCurrentValue().ToString("$#,##0"));
			}


			//mam 050806
			grid.SetData(row, (int)Columns.AcquisitionCostEscalated, 
				component.GetAcquisitionCostEscalated().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.RehabCost, 
				component.GetRehabCost().ToString("$#,##0"));

			grid.SetData(row, (int)Columns.ReplacementValue, 
				component.GetReplacementValue().ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.ReplacementValueYearAverage,
				component.GetReplacementValueYear().ToString("0"));

			grid.SetData(row, (int)Columns.BookValue, 
				component.GetBookValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.SalvageValue, 
				component.GetSalvageValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.AnnualDepreciation, 
				component.GetAnnualDepreciation().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.CumulativeDepreciation, 
				component.GetCumulativeDepreciation().ToString("$#,##0"));

			//mam - check whether EvaluatedValue and RepairCost totals should be N/A
			//bool allDiscNA = CheckIfAllNADiscipline(component.ID);
			if (allDiscNA)
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, "N/A");
			}
			else
			{
			//</mam>
				grid.SetData(row, (int)Columns.EvaluatedValue, 
					component.GetEvaluatedValue().ToString("$#,##0"));
			//mam
			}

			//mam 050806
//			bool useNA = false;
//			if (component. MechStructDisciplines)
//			{
//				if (allDiscNA && !discipline.OverrideRepairCost)
//				{
//					useNA = true;
//				}
//			}
//			else if (allDiscNA && !discOverrideRepairCost)
//			{
//				useNA = true;
//			}
			if (allDiscNA && !discOverrideRepairCost)
			{
				grid.SetData(row, (int)Columns.RepairCost, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.RepairCost, 
					component.GetRepairCost().ToString("$#,##0"));
			}

			//</mam>

			grid.SetData(row, (int)Columns.AnnualMaintenance, 
				component.GetAnnualMaintenanceCost().ToString("$#,##0"));

		}

		private void		UpdateComponentGridTotals()
		{
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			WAM.Logic.MajorComponentTotals totals = 
				process.GetComponentTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");
			grid.SetData(row, (int)Columns.CWPValue, totals.GetCalcTotalCWP());
			grid.SetData(row, (int)Columns.AcquisitionCost, totals.GetTotalAcquisitionCost().ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.AcquisitionCostEscalated, 
				totals.GetTotalAcquisitionCostEscalated().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.RehabCost, 
				totals.GetTotalRehabCost().ToString("$#,##0"));

			//mam 112806 - commented
			//grid.SetData(row, (int)Columns.CurrentValue, totals.GetTotalCurrentValue().ToString("$#,##0"));

			grid.SetData(row, (int)Columns.ReplacementValue, 
				totals.GetTotalReplacementValue().ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.ReplacementValueYearAverage,
				totals.GetAverageReplacementValueYear().ToString("0"));

			grid.SetData(row, (int)Columns.BookValue, 
				totals.GetTotalBookValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.SalvageValue, 
				totals.GetTotalSalvageValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.AnnualDepreciation, 
				totals.GetTotalAnnualDepreciation().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.CumulativeDepreciation, 
				totals.GetTotalCumulativeDepreciation().ToString("$#,##0"));
			
			//mam - comment four lines
			//grid.SetData(row, (int)Columns.EvaluatedValue, 
			//	totals.GetTotalEvaluatedValue().ToString("$#,##0"));
			//grid.SetData(row, (int)Columns.RepairCost, 
			//	totals.GetTotalRepairCost().ToString("$#,##0"));
			//</mam>

			//mam - add amounts in the EvaluatedValue and RepairCost columns to arrive at the Total, 
			//	rather than calling the methods commented above
			decimal tempTotalEvaluatedValue = 0;
			decimal tempTotalRepairCost = 0;
			bool useNAEvalValue = true;
			bool useNARepairCost = true;

			decimal tempTotalCurrentValue = 0;
			bool useNACurrentValue = true;

			for (int i = 1; i < grid.Rows.Count - 1; i++)
			{
				if (grid.GetData(i, (int)Columns.EvaluatedValue).ToString() != "N/A")
				{
					useNAEvalValue = false;
					tempTotalEvaluatedValue += Decimal.Parse((grid.GetData(i, (int)Columns.EvaluatedValue).ToString()),
						System.Globalization.NumberStyles.Currency);
				}
				if (grid.GetData(i, (int)Columns.RepairCost).ToString() != "N/A")
				{
					useNARepairCost = false;
					tempTotalRepairCost += Decimal.Parse((grid.GetData(i, (int)Columns.RepairCost).ToString()),
						System.Globalization.NumberStyles.Currency);
				}

				//mam 112806
				if (grid.GetData(i, (int)Columns.CurrentValue).ToString() != "N/A")
				{
					useNACurrentValue = false;
					tempTotalCurrentValue += Decimal.Parse((grid.GetData(i, (int)Columns.CurrentValue).ToString()),
						System.Globalization.NumberStyles.Currency);
				}
			}

			//if total EV or total RC is zero, this means that the CWP is zero,
			//	which means that the Current Value is zero, so use N/A
			//if (tempTotalEvaluatedValue == 0)
			if (useNAEvalValue)
				grid.SetData(row, (int)Columns.EvaluatedValue, "N/A");
			else
				grid.SetData(row, (int)Columns.EvaluatedValue, tempTotalEvaluatedValue.ToString("$#,##0"));

			//if (tempTotalRepairCost == 0)
			if (useNARepairCost)
				grid.SetData(row, (int)Columns.RepairCost, "N/A");
			else
				grid.SetData(row, (int)Columns.RepairCost, tempTotalRepairCost.ToString("$#,##0"));
			//</mam>

			//mam 112806
			if (useNACurrentValue)
				grid.SetData(row, (int)Columns.CurrentValue, "N/A");
			else
				grid.SetData(row, (int)Columns.CurrentValue, tempTotalCurrentValue.ToString("$#,##0"));

			grid.SetData(row, (int)Columns.AnnualMaintenance, 
				totals.GetTotalAnnualMaintenanceCost().ToString("$#,##0"));
		}

		private void		UpdateDisciplineGridRow(int row, Discipline discipline)
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			WAM.Logic.DisciplineTotals totals = 
				component.GetDisciplineTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalCurrentValue = totals.GetTotalCurrentValue();
			decimal			totalCurrentValue = totals.GetTotalAcquisitionCost();

			grid.SetData(row, (int)Columns.Name, discipline.Name);

			if (totalCurrentValue != 0)
			{
				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//double		val = Math.Round((double)(discipline.GetCurrentValue() / totalCurrentValue) * 100.0, 1);
				double		val = Math.Round((double)(discipline.AcquisitionCost / totalCurrentValue) * 100.0, 1);

				grid.SetData(row, (int)Columns.CWPValue, val);
			}
			else
			{
				grid.SetData(row, (int)Columns.CWPValue, 0.0);
			}

			grid.SetData(row, (int)Columns.AcquisitionCost, 
				discipline.AcquisitionCost.ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.AcquisitionCostEscalated, 
				discipline.AcquisitionCostEscalated.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.RehabCost, 
				discipline.RehabCost.ToString("$#,##0"));

			//mam 112806 - commented
			//grid.SetData(row, (int)Columns.CurrentValue, discipline.GetCurrentValue().ToString("$#,##0"));

			//mam 112806 - added
			bool allDiscNA = CheckIfAllNADiscipline(component.ID, discipline.ID);
			if (allDiscNA && !discOverrideCurrentValue)
			{
				grid.SetData(row, (int)Columns.CurrentValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.CurrentValue, discipline.GetCurrentValue().ToString("$#,##0"));
			}

			grid.SetData(row, (int)Columns.ReplacementValue, 
				discipline.ReplacementValue.ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.ReplacementValueYearAverage,
				discipline.ReplacementValueYear.ToString("0"));

			grid.SetData(row, (int)Columns.BookValue, 
				discipline.GetBookValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.SalvageValue, 
				discipline.SalvageValue.ToString("$#,##0"));
			grid.SetData(row, (int)Columns.AnnualDepreciation, 
				discipline.GetAnnualDepreciation().ToString("$#,##0"));

			//mam 07072011 - rounding issue!!!
			//ToString() rounds away from zero, while Math.Round rounds towards the even number
			//this can cause a discrepancy from one screen to another, or from display to report, if a value falls at exactly five tenths of a point
			//(ToString is used in WAM when displaying values in text boxes or grids, while Math.Round is used elsewhere)
			//this situation doesn't occur often, and the difference is only 1, but it's irritatingly wrong
			//the solution would be to use Math.Round before calling ToString() when presenting data for display (but don't round when that data will
			//	be used in further calculations)
			//this is a simple enough solution, but it is far reaching, as there are hundreds of occurrences, and much testing would be required
			//ask if it is worth it
			//ToString rounds 32.5 to 33, 33.5 to 34, etc.
			//Math.Round rounds 32.5 to 32, 33.5 to 34, etc.

			grid.SetData(row, (int)Columns.CumulativeDepreciation, 
				discipline.GetCumulativeDepreciation().ToString("$#,##0"));

			//mam - don't check ConditionRanking to determine all Cond values are N/A
			//original code:
			//if (discipline.ConditionRanking != CondRank.No)
			//new code:
			//Update: add check for CondRank.No to the if statement
			//if (CheckIfAllNADiscipline(component.ID, discipline.ID))

			//mam 050806
			//bool allDiscNA = CheckIfAllNADiscipline(component.ID, discipline.ID);
			//if (discipline.ConditionRanking == CondRank.No || CheckIfAllNADiscipline(component.ID, discipline.ID))
			if (allDiscNA)
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, 
					discipline.GetEvaluatedValue().ToString("$#,##0"));
			}

			//mam 050806
//			bool useNA = false;
//			if (component.MechStructDisciplines)
//			{
//				if (allDiscNA && !discipline.OverrideRepairCost)
//				{
//					useNA = true;
//				}
//			}
//			else if (allDiscNA && !discOverrideRepairCost)
//			{
//				useNA = true;
//			}
			if (allDiscNA && !discOverrideRepairCost)
			{
				grid.SetData(row, (int)Columns.RepairCost, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.RepairCost, 
					discipline.GetRepairCost().ToString("$#,##0"));
			}

			grid.SetData(row, (int)Columns.AnnualMaintenance, 
				discipline.AnnualMaintCost.ToString("$#,##0"));
		}

		private void		UpdateDisciplineGridTotals()
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			WAM.Logic.DisciplineTotals totals = 
				component.GetDisciplineTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");
			grid.SetData(row, (int)Columns.CWPValue, totals.GetCalcTotalCWP());
			grid.SetData(row, (int)Columns.AcquisitionCost, totals.GetTotalAcquisitionCost().ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.AcquisitionCostEscalated, 
				totals.GetTotalAcquisitionCostEscalated().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.RehabCost, 
				totals.GetTotalRehabCost().ToString("$#,##0"));

			//mam 112806 - commented
			//grid.SetData(row, (int)Columns.CurrentValue, totals.GetTotalCurrentValue().ToString("$#,##0"));

			//mam 112806 - added
			bool allDiscNA = CheckIfAllNADiscipline();
			if (allDiscNA && !discOverrideCurrentValue)
			{
				grid.SetData(row, (int)Columns.CurrentValue, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.CurrentValue, totals.GetTotalCurrentValue().ToString("$#,##0"));
			}


			grid.SetData(row, (int)Columns.ReplacementValue, 
				totals.GetTotalReplacementValue().ToString("$#,##0"));

			//mam 050806
			grid.SetData(row, (int)Columns.ReplacementValueYearAverage, 
				totals.GetAverageReplacementValueYear().ToString("0"));

			grid.SetData(row, (int)Columns.BookValue, 
				totals.GetTotalBookValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.SalvageValue, 
				totals.GetTotalSalvageValue().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.AnnualDepreciation, 
				totals.GetTotalAnnualDepreciation().ToString("$#,##0"));
			grid.SetData(row, (int)Columns.CumulativeDepreciation, 
				totals.GetTotalCumulativeDepreciation().ToString("$#,##0"));

			//mam 050806
			//bool allDiscNA = CheckIfAllNADiscipline();

			//mam - check whether EvaluatedValue and RepairCost totals should be N/A
			//mam 050806
			//if (CheckIfAllNADiscipline())
			if (allDiscNA)
			{
				grid.SetData(row, (int)Columns.EvaluatedValue, "N/A");
			}
			else
			{
			//</mam>

				grid.SetData(row, (int)Columns.EvaluatedValue, 
					totals.GetTotalEvaluatedValue().ToString("$#,##0"));

			//mam
			}
			//</mam>

			//mam 050806
//			bool useNA = false;
//			if (component.MechStructDisciplines)
//			{
//				if (allDiscNA && !discipline.OverrideRepairCost)
//				{
//					useNA = true;
//				}
//			}
//			else if (allDiscNA && !discOverrideRepairCost)
//			{
//				useNA = true;
//			}

			if (allDiscNA && !discOverrideRepairCost)
			{
				grid.SetData(row, (int)Columns.RepairCost, "N/A");
			}
			else
			{
				grid.SetData(row, (int)Columns.RepairCost, 
					totals.GetTotalRepairCost().ToString("$#,##0"));
			}

			grid.SetData(row, (int)Columns.AnnualMaintenance, 
				totals.GetTotalAnnualMaintCost().ToString("$#,##0"));
		}

		//mam
		private bool CheckIfAllNADiscipline()
		{
			//mam - check whether all Disciplines for this Component
			//	have Condition = N/A;

			bool AllNA = true;

			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return true;

			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			discOverrideRepairCost = false;

			//mam 112806
			discOverrideCurrentValue = false;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllConditionNA())
					{
						AllNA = false;

						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (pipe.OverrideRepairCost)
					if (pipe.GetAnyRepairCostOverridden())
					{
						discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (pipe.GetAnyCurrentValueOverridden())
					{
						discOverrideCurrentValue = true;
					}
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllConditionNA())
					{
						AllNA = false;

						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (node.OverrideRepairCost)
					if (node.GetAnyRepairCostOverridden())
					{
						discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (node.GetAnyCurrentValueOverridden())
					{
						discOverrideCurrentValue = true;
					}
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					//mam 050806
					if (AllNA)
					{
						AllNA = (discipline.ConditionRanking == CondRank.No);
					}

					//mam 112806 - commented
					//if (!AllNA && discOverrideRepairCost)
					//{
					//	break;
					//}

					//mam 050806
					if (discipline.OverrideRepairCost)
					{
						discOverrideRepairCost = true;

						//mam 112806 - comented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (discipline.OverrideCurrentValue)
					{
						discOverrideCurrentValue = true;
					}
				}
			}

			return AllNA;
		}
		//</mam>

		//mam
		private bool CheckIfAllNADiscipline(int componentID, int disciplineID)
		{
			//mam - check whether all Disciplines for this Component
			//	have Condition = N/A;

			bool AllNA = true;

			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return true;

			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			discOverrideRepairCost = false;

			//mam 112806
			discOverrideCurrentValue = false;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.ID == disciplineID)
				{
					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = discipline as DisciplinePipe;
						if (!pipe.GetAllConditionNA())
						{
							AllNA = false;

							//mam 112806 - commented
							//mam 050806
							//if (discOverrideRepairCost)
							//{
							//	break;
							//}
						}

						//mam 050806
						//if (pipe.OverrideRepairCost)
						if (pipe.GetAnyRepairCostOverridden())
						{
							discOverrideRepairCost = true;

							//mam 112806 - commented
							//if (!AllNA)
							//{
							//	break;
							//}
						}

						//mam 112806
						if (pipe.GetAnyCurrentValueOverridden())
						{
							discOverrideCurrentValue = true;
						}
					}
					if (discipline.Type == DisciplineType.Nodes)
					{
						node = discipline as DisciplineNode;
						if (!node.GetAllConditionNA())
						{
							AllNA = false;

							//mam 112806 - commented
							//mam 050806
							//if (discOverrideRepairCost)
							//{
							//	break;
							//}
						}

						//mam 050806
						//if (node.OverrideRepairCost)
						if (node.GetAnyRepairCostOverridden())
						{
							discOverrideRepairCost = true;

							//mam 112806 - commented
							//if (!AllNA)
							//{
							//	break;
							//}
						}

						//mam 112806
						if (node.GetAnyCurrentValueOverridden())
						{
							discOverrideCurrentValue = true;
						}
					}
					if (discipline.Type == DisciplineType.Mechanical 
						|| discipline.Type == DisciplineType.Structural
						|| discipline.Type == DisciplineType.Land)
					{
						//mam 050806
						if (AllNA)
						{
							AllNA = (discipline.ConditionRanking == CondRank.No);
						}

						//mam 112806 - commented
						//if (!AllNA && discOverrideRepairCost)
						//{
						//	break;
						//}

						//mam 050806
						if (discipline.OverrideRepairCost)
						{
							discOverrideRepairCost = true;

							//mam 112806 - commented
							//if (!AllNA)
							//{
							//	break;
							//}
						}

						//mam 112806
						if (discipline.OverrideCurrentValue)
						{
							discOverrideCurrentValue = true;
						}
					}
				}
			}

			return AllNA;
		}
		//</mam>

		//mam
		private bool CheckIfAllNADiscipline(int componentID)
		{
			//mam - check whether all Disciplines for this Component
			//	have Condition = N/A;

			bool AllNA = true;

			//MajorComponent component = m_root as MajorComponent;
			//if (component == null)
			//	return true;

			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, componentID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			//mam 050806
			discOverrideRepairCost = false;

			//mam 112806
			discOverrideCurrentValue = false;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllConditionNA())
					{
						AllNA = false;

						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (pipe.OverrideRepairCost)
					if (pipe.GetAnyRepairCostOverridden())
					{
						discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (pipe.GetAnyCurrentValueOverridden())
					{
						discOverrideCurrentValue = true;
					}
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllConditionNA())
					{
						AllNA = false;
						
						//mam 112806 - commented
						//mam 050806
						//if (discOverrideRepairCost)
						//{
						//	break;
						//}
					}

					//mam 050806
					//if (node.OverrideRepairCost)
					if (node.GetAnyRepairCostOverridden())
					{
						discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (node.GetAnyCurrentValueOverridden())
					{
						discOverrideCurrentValue = true;
					}
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					//mam 050806
					if (AllNA)
					{
						AllNA = (discipline.ConditionRanking == CondRank.No);
					}

					//mam 112806 - commented
					//if (!AllNA && discOverrideRepairCost)
					//{
					//	break;
					//}

					//mam 050806
					if (discipline.OverrideRepairCost)
					{
						discOverrideRepairCost = true;

						//mam 112806 - commented
						//if (!AllNA)
						//{
						//	break;
						//}
					}

					//mam 112806
					if (discipline.OverrideCurrentValue)
					{
						discOverrideCurrentValue = true;
					}
				}
			}

			return AllNA;
		}
		//</mam>

		private void grid_StartEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row == grid.Rows.Count - 1 || e.Row < grid.Rows.Fixed)
			{
				e.Cancel = true;
				return;
			}

			// Disallow edit of CWP column for Nodes / Piping component 
			// (it is a calculated value for this type of component)
			if (m_root is MajorComponent && e.Col == (int)Columns.CWPValue)
			{
				MajorComponent component = (MajorComponent)m_root;

				if (!component.MechStructDisciplines)
				{
					e.Cancel = true;
					return;
				}
			}
		}

		private void grid_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row < grid.Rows.Fixed)
				return;

			MajorComponent	component = grid.Rows[e.Row].UserData as MajorComponent;
			Discipline		discipline = grid.Rows[e.Row].UserData as Discipline;
			object			val = grid[e.Row, e.Col];
			bool			dirty = false;

			if (component == null && discipline == null)
				return;

			switch (e.Col)
			{
				case (int)Columns.CWPValue:
					if (component != null)
					{
						if (Math.Round(component.CWPValue, 3) != 
							Math.Round(((double)val) / 100.0, 3))
						{
							component.CWPValue = (double)((double)val / 100.0);
							dirty = true;
						}
					}
					else if (discipline != null)
					{
						if (Math.Round(discipline.CWPAssetValue, 3) != 
							Math.Round(((double)val) / 100.0, 3))
						{
							discipline.CWPAssetValue = (double)((double)val / 100.0);
							dirty = true;
						}
					}
					break;
				default:
					break;
			}

			// Save the process record if anything changed
			if (dirty)
			{
				if (component != null)
				{
					component.Save();
					UpdateComponentGridRow(e.Row, component);
					UpdateComponentGridTotals();
				}
				else if (discipline != null)
				{
					discipline.Save();
					UpdateDisciplineGridRow(e.Row, discipline);
					UpdateDisciplineGridTotals();
				}
			}
		}

		//mam
		public void ShowEquation(string eqn)
		{
			((MainForm)ParentForm).ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			((MainForm)ParentForm).PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			((MainForm)ParentForm).ClearEquationTextBox();
		}

		public void SetEquationControls()
		{
			equationViewerHandler.AssignMouseHandlerGrid(grid, colTag);
		}
		//</mam>

		#endregion /***** Methods *****/
	}
}
