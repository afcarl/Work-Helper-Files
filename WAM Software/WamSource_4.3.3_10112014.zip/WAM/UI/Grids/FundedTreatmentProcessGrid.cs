using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for FundedTreatmentProcessGrid.
	/// </summary>
	public class FundedTreatmentProcessGrid : System.Windows.Forms.UserControl
	{
		enum ProcessColumns
		{
			ProcessName,
			PercentFunded,
			CWPValue,
			AcquisitionCost,
			CurrentValue,

			//mam 050806
			AcquisitionCostEscalated,
			
			ReplacementValue,

			//mam 050806
			ReplacementValueYearAverage,

			//mam 050806
			RehabCost,

			BookValue,
			SalvageValue,
			AnnualDepreciation,
			CumulativeDepreciation,
			EvaluatedValue,
			RepairCost,
			AnnualMaintenanceCost,
		}

		private Facility	m_facility = null;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridProcesses;

		//mam - add bool to determine whether grid is loading
		private bool isLoading = false;
		//</mam>

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FundedTreatmentProcessGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			c1FlexGridProcesses.Rows[0].AllowMerging = 
				c1FlexGridProcesses.Rows[1].AllowMerging = true;

			c1FlexGridProcesses.Rows[0].HeightDisplay = 
				(int)(c1FlexGridProcesses.Rows[0].HeightDisplay * 2.0);

			foreach (Column col in c1FlexGridProcesses.Cols)
			{
				col.AllowMerging = true;
				col.StyleFixedNew.TextAlign =
					C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
			}

			c1FlexGridProcesses[0, (int)ProcessColumns.ProcessName] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.ProcessName] = "Treatment Processes / Basins / Zones\r\nin this Facility / System";
			c1FlexGridProcesses[0, (int)ProcessColumns.PercentFunded] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.PercentFunded] = "Percent\r\nFunded";
			c1FlexGridProcesses[0, (int)ProcessColumns.CWPValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.CWPValue] = "Cost Weighted\r\nPercentage of\r\nAsset Value (%)";
			c1FlexGridProcesses[0, (int)ProcessColumns.AcquisitionCost] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.AcquisitionCost] = "Acquisition\r\nCost ($)";

			//mam 050806
			c1FlexGridProcesses[0, (int)ProcessColumns.AcquisitionCostEscalated] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.AcquisitionCostEscalated] = "Escalated\r\nAcquisition\r\nCost ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.RehabCost] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.RehabCost] = "Rehabilitation\r\nCost ($)";

			c1FlexGridProcesses[0, (int)ProcessColumns.CurrentValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.CurrentValue] = "Current\r\nValue ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.ReplacementValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.ReplacementValue] = "Replacement\r\nValue ($)";

			//mam 050806
			//mam 112806 - added "Average"
			c1FlexGridProcesses[0, (int)ProcessColumns.ReplacementValueYearAverage] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.ReplacementValueYearAverage] = "Average\r\nReplacement\r\nValue Year";

			c1FlexGridProcesses[0, (int)ProcessColumns.BookValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.BookValue] = "Book\r\nValue ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.SalvageValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.SalvageValue] = "Salvage\r\nValue ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.AnnualDepreciation] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.AnnualDepreciation] = "Annual\r\nDepreciation ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.CumulativeDepreciation] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.CumulativeDepreciation] = "Cumulative\r\nDepreciation ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.EvaluatedValue] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.EvaluatedValue] = "Evaluated\r\nValue ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.CumulativeDepreciation] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.CumulativeDepreciation] = "Cumulative\r\nDepreciation ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.RepairCost] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.RepairCost] = "Repair\r\nCost ($)";
			c1FlexGridProcesses[0, (int)ProcessColumns.AnnualMaintenanceCost] = 
				c1FlexGridProcesses[1, (int)ProcessColumns.AnnualMaintenanceCost] = "Annual\r\nMaintenance\r\nCost ($)";
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.c1FlexGridProcesses = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridProcesses)).BeginInit();
			this.SuspendLayout();
			// 
			// c1FlexGridProcesses
			// 
			this.c1FlexGridProcesses.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridProcesses.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridProcesses.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridProcesses.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.c1FlexGridProcesses.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.c1FlexGridProcesses.ColumnInfo = "16,0,0,0,0,85,Columns:0{Width:315;Caption:\"Treatment Processes / Basins / Zones  " +
				" in this  Facility / System\";AllowEditing:False;DataType:System.String;TextAlign" +
				":LeftCenter;TextAlignFixed:CenterCenter;}\t1{Width:65;Caption:\"Percent Funded\";Da" +
				"taType:System.Double;Format:\"F1\";TextAlign:RightCenter;TextAlignFixed:CenterCent" +
				"er;}\t2{Width:75;Caption:\"Cost Weighted Percentage of Asset Value (%)\";AllowEditi" +
				"ng:False;DataType:System.Double;Format:\"F1\";TextAlign:RightCenter;TextAlignFixed" +
				":CenterCenter;}\t3{Width:75;Caption:\"Acquisition Cost ($)\";AllowEditing:False;Dat" +
				"aType:System.String;Format:\"$#,##0\";TextAlign:RightCenter;TextAlignFixed:CenterC" +
				"enter;}\t4{Width:70;Caption:\"Current Value ($)\";AllowEditing:False;DataType:Syste" +
				"m.String;Format:\"F1\";TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t5{Width" +
				":75;Caption:\"Escalated Acquisition Cost\";DataType:System.String;TextAlign:RightC" +
				"enter;TextAlignFixed:CenterCenter;}\t6{Width:70;Caption:\"Replacement Value ($)\";A" +
				"llowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t7{Width:75;Caption:\"Replacement Value Year\";DataType:System.String;" +
				"TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t8{Width:75;Caption:\"Rehabili" +
				"tation Cost ($)\";DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Cen" +
				"terCenter;}\t9{Width:70;Caption:\"Book Value ($)\";AllowEditing:False;DataType:Syst" +
				"em.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t10{Width:70;Captio" +
				"n:\"Salvage Value ($)\";AllowEditing:False;DataType:System.String;TextAlign:RightC" +
				"enter;TextAlignFixed:CenterCenter;}\t11{Width:70;Caption:\"Annual Depreciation ($)" +
				"\";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed" +
				":CenterCenter;}\t12{Width:70;Caption:\"Cumulative Depreciation ($)\";AllowEditing:F" +
				"alse;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t" +
				"13{Width:70;Caption:\"Evaluated Value ($)\";AllowEditing:False;DataType:System.Str" +
				"ing;TextAlign:RightCenter;TextAlignFixed:CenterCenter;}\t14{Width:70;Caption:\"Rep" +
				"air Cost ($)\";AllowEditing:False;DataType:System.String;TextAlign:RightCenter;Te" +
				"xtAlignFixed:CenterCenter;}\t15{Width:70;Caption:\"Annual Maintenance Cost ($)\";Al" +
				"lowEditing:False;DataType:System.String;TextAlign:RightCenter;TextAlignFixed:Cen" +
				"terCenter;}\t";
			this.c1FlexGridProcesses.Dock = System.Windows.Forms.DockStyle.Fill;
			this.c1FlexGridProcesses.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridProcesses.Location = new System.Drawing.Point(0, 0);
			this.c1FlexGridProcesses.Name = "c1FlexGridProcesses";
			this.c1FlexGridProcesses.Rows.Count = 3;
			this.c1FlexGridProcesses.Rows.Fixed = 2;
			this.c1FlexGridProcesses.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.c1FlexGridProcesses.ShowSort = false;
			this.c1FlexGridProcesses.Size = new System.Drawing.Size(384, 100);
			this.c1FlexGridProcesses.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.c1FlexGridProcesses.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridProcesses.TabIndex = 2;
			this.c1FlexGridProcesses.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridProcesses_AfterEdit);
			this.c1FlexGridProcesses.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridProcesses_StartEdit);
			// 
			// FundedTreatmentProcessGrid
			// 
			this.Controls.Add(this.c1FlexGridProcesses);
			this.Name = "FundedTreatmentProcessGrid";
			this.Size = new System.Drawing.Size(384, 100);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridProcesses)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// create frozen area at the bottom, with 1 rows
			FlexFreezeBottom ffb = new FlexFreezeBottom(c1FlexGridProcesses, 1);

			base.OnLoad (e);
		}

		public void			SetFacility(Facility facility)
		{
			m_facility = facility;
			LoadGrid();
		}

		private void		LoadGrid()
		{
			//mam
			isLoading = true;
			//</mam>

			if (m_facility == null)
			{
				c1FlexGridProcesses.Rows.Count = 3;
				return;
			}

			c1FlexGridProcesses.Rows.Count = 3;

			// Load the process list
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
			TreatmentProcess process;
			int				row = 2;

			// Top fixed row and bottom totals row
			c1FlexGridProcesses.Redraw = false;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (!process.IsFunded)
					continue;

				c1FlexGridProcesses.Rows.Add();
				c1FlexGridProcesses.Rows[row].Style = c1FlexGridProcesses.Styles["Normal"];
				c1FlexGridProcesses.Rows[row].UserData = process;
				UpdateGridRow(row++, process);
			}

			UpdateGridTotals();

			//mam
			//PerformRounding();
			//</mam>

			// Set the data in the totals columns
			c1FlexGridProcesses.Redraw = true;

			//mam - disable editing in all columns if infoset is fixed
			bool infoSetFixed = InfoSet.IsFixed;
			//if (infoSetFixed)
			//{
			//	foreach (Column col in c1FlexGridProcesses.Cols)
			//	{
			//		col.AllowEditing = false;
			//	}
			//}
			c1FlexGridProcesses.Cols[1].AllowEditing = !infoSetFixed;
			//</mam>

			//mam
			isLoading = false;
			//</mam>
		}

		//mam
		private void PerformRounding()
		{
			ArrayList roundingColExceptions = new ArrayList();
			roundingColExceptions.Add((int)ProcessColumns.ReplacementValueYearAverage);

			//MessageBox.Show("row count = " + c1FlexGridProcesses.Rows.Count.ToString());
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			WAMRounding.PerformRounding(2, 3, c1FlexGridProcesses, roundingColExceptions);
		}
		//</mam>

		//mam
		private void AdjustCWPValues()
		{
			try
			{
				//mam 112806 - calling AdjustCWPValues() overwrites the values set in UpdateGridRow for column CWPValue

				//adjust CWPValue percentages so that they total exactly 100.0 (rather than 100.1, or 99.9, etc.)
				WAM.Logic.TreatmentProcessTotals processTotals = m_facility.GetProcessTotals();

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//decimal totalValue = processTotals.GetFundedTotalCurrentValue();
				decimal totalValue = processTotals.GetFundedTotalAcquisitionCostRoundIndividualValues();

				//correct CWP values on when the Current Value total > 0
				if (totalValue > 0)
				{
					int RowDataStarts = 2;
					int ArrayLength = c1FlexGridProcesses.Rows.Count-(RowDataStarts + 1);

					decimal trueValue = 0;
					decimal[] cwpArrayTruncValue = new decimal[ArrayLength];
					decimal[] cwpArrayErrorValue = new decimal[ArrayLength];
					decimal[,] bubbleList = new decimal[ArrayLength, 2];
					decimal tempItem = 0;
					long totalTruncValue = 0;
					bool bubbleSorted = false;
					long totalAdjustmentsRequired = 0;

					c1FlexGridProcesses.Redraw = false;

					for (int row=RowDataStarts; row < c1FlexGridProcesses.Rows.Count-1; row++)
					{
						TreatmentProcess process = c1FlexGridProcesses.Rows[row].UserData as TreatmentProcess;
						if (process == null)
							continue;
						//divide CurrentValue for this row by the total of the Current Value column
						//trueValue = Decimal.Parse((c1FlexGridProcesses.GetData(row, (int)ProcessColumns.CurrentValue).ToString()),
						//	System.Globalization.NumberStyles.Currency) / totalValue * 100m;

						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//trueValue = (process.GetCurrentValue() * (decimal)process.PctFunded) / totalValue * 100m;
						trueValue = (process.GetAcquisitionCostRoundIndividualValues() * (decimal)process.PctFunded) / totalValue * 100m;

						//truncate trueValue after the first decimal place
						cwpArrayTruncValue[row-RowDataStarts] = (Decimal.Truncate(trueValue * 10m)) / 10m;

						//calculate error value
						cwpArrayErrorValue[row-RowDataStarts] = trueValue - cwpArrayTruncValue[row-RowDataStarts];

						//multiply truncated value by 10 to work in whole numbers
						totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[row-RowDataStarts] * 10m);
					}
	
					//populate bubbleList array
					bubbleSorted = false;
					for (int i = 0; i < ArrayLength; i++)
					{
						//assign the counter
						bubbleList[i, 0] = i;
						//assign the error value
						bubbleList[i, 1] = cwpArrayErrorValue[i];
					}

					//sort the bubbleList from highest to lowest Error Value
					bubbleSorted = false;
					do
					{
						bubbleSorted=true;
						for (int i = 0; i < ArrayLength-1; i++)
						{
							if (bubbleList[i,1] < bubbleList[i+1,1])
							{
								bubbleSorted = false;

								//switch the order of the two items
								tempItem = bubbleList[i,1];
								bubbleList[i,1] = bubbleList[i+1,1];
								bubbleList[i+1,1] = tempItem;

								tempItem = bubbleList[i,0];
								bubbleList[i,0] = bubbleList[i+1,0];
								bubbleList[i+1,0] = tempItem;
							}
						}
					}
					while (!bubbleSorted);

					//adjust the truncated values, as necessary
					totalAdjustmentsRequired = 1000 - totalTruncValue;

					for (int i = 0; i < totalAdjustmentsRequired; i++)
					{
						cwpArrayTruncValue[Convert.ToInt32(bubbleList[i, 0])] += 0.1m;
					}

					//write the adjusted CPW values to the grid
					tempItem = 0;
					for (int row=RowDataStarts; row < c1FlexGridProcesses.Rows.Count-1; row++)
					{
						c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, (double)cwpArrayTruncValue[row-RowDataStarts]);
						tempItem += cwpArrayTruncValue[row-RowDataStarts];
					}

					//update CPWValues total in the grid
					c1FlexGridProcesses.SetData(c1FlexGridProcesses.Rows.Count - 1, (int)ProcessColumns.CWPValue, tempItem);

					c1FlexGridProcesses.Redraw = true;
				}
			}
			catch
			{
			}
		}
		//</mam>

		private void		UpdateGridRow(int row, TreatmentProcess process)
		{
			WAM.Logic.TreatmentProcessTotals processTotals = 
				m_facility.GetProcessTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalValue = processTotals.GetFundedTotalCurrentValue();
			decimal			totalValue = processTotals.GetFundedTotalAcquisitionCost();

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ProcessName, 
				process.Name);

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.PercentFunded, 
				process.PctFunded * 100.0);

			if (totalValue != 0)
			{

				//mam - multiply Current Value by percent funded

				//original code:
				//// CWP Value = process value / total value
				//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, 
				//	Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1));

				//new code:
				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, 
				//	Math.Round((double)(process.GetCurrentValue() * (decimal)process.PctFunded / totalValue) * 100.0, 1));
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, 
					Math.Round((double)(process.GetAcquisitionCost() * (decimal)process.PctFunded / totalValue) * 100.0, 1));
				//</mam>
			}
			else
			{
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, 0.0);
			}

			//mam - multiply each value by percent funded
			//	added "* (decimal)process.PctFunded" to the code for each value
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AcquisitionCost, 
				(process.GetAcquisitionCost() * (decimal)process.PctFunded).ToString("$#,##0"));

			//mam 050806
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AcquisitionCostEscalated, 
				process.GetAcquisitionCostEscalated().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RehabCost, 
				process.GetRehabCost().ToString("$#,##0"));

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, 
				(process.GetCurrentValue() * (decimal)process.PctFunded).ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ReplacementValue, 
				(process.GetReplacementValue() * (decimal)process.PctFunded).ToString("$#,##0"));

			//mam 050806
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ReplacementValueYearAverage,
				process.GetReplacementValueYear().ToString("0"));

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.BookValue, 
				(process.GetBookValue() * (decimal)process.PctFunded).ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.SalvageValue, 
				(process.GetSalvageValue() * (decimal)process.PctFunded).ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AnnualDepreciation, 
				(process.GetAnnualDepreciation() * (decimal)process.PctFunded).ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CumulativeDepreciation, 
				(process.GetCumulativeDepreciation() * (decimal)process.PctFunded).ToString("$#,##0"));

			//mam - comment four lines
			//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, 
			//	(process.GetEvaluatedValue() * (decimal)process.PctFunded).ToString("$#,##0"));
			//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, 
			//	(process.GetRepairCost() * (decimal)process.PctFunded).ToString("$#,##0"));

			//mam - add amounts in the EvaluatedValue and RepairCost columns to arrive at the Total, 
			//	rather than calling the methods commented above
			CheckIfAllNAComponent(process.ID, row, process);
			//</mam>

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AnnualMaintenanceCost, 
				(process.GetAnnualMaintenanceCost() * (decimal)process.PctFunded).ToString("$#,##0"));
			//</mam>

			//mam - update the CWP values for the remaining grid rows
			//UpdateCWP(totalValue);
			//</mam>
		}

		//mam
		private void CheckIfAllNAComponent(int processID, int row, TreatmentProcess process)
		{
			decimal tempTotalEvaluatedValue = 0;
			decimal tempTotalRepairCost = 0;
			bool useNAEvalValue = true;
			bool useNARepairCost = true;
			bool isNA = false;

			//mam 112806
			decimal tempTotalCurrentValue = 0;
			bool useNACurrentValue = true;

			MajorComponent[] components =  CacheManager.GetComponents(InfoSet.CurrentID, processID);
			MajorComponent component;

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];

				Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
				Discipline discipline;

				DisciplinePipe	pipe;
				DisciplineNode	node;

				for (int posDisc = 0; posDisc < disciplines.Length; posDisc++)
				{
					discipline = disciplines[posDisc];
					if (discipline.Type == DisciplineType.Pipes
						|| discipline.Type == DisciplineType.Nodes)
					{
						if (discipline.Type == DisciplineType.Pipes)
						{
							pipe = discipline as DisciplinePipe;
							isNA = pipe.GetAllConditionNA();

							//mam 050806
							if (!isNA)
							{
								useNAEvalValue = false;
								tempTotalEvaluatedValue += discipline.GetEvaluatedValue();
							}
							if (!isNA || pipe.GetAnyRepairCostOverridden())
							{
								useNARepairCost = false;
								tempTotalRepairCost += discipline.GetRepairCost();
							}

							//mam 112806
							if (!isNA || pipe.GetAnyCurrentValueOverridden())
							{
								useNACurrentValue = false;
								tempTotalCurrentValue += discipline.GetCurrentValue();
							}
						}
						if (discipline.Type == DisciplineType.Nodes)
						{
							node = discipline as DisciplineNode;
							isNA = node.GetAllConditionNA();

							//mam 050806
							if (!isNA)
							{
								useNAEvalValue = false;
								tempTotalEvaluatedValue += discipline.GetEvaluatedValue();
							}
							if (!isNA || node.GetAnyRepairCostOverridden())
							{
								useNARepairCost = false;
								tempTotalRepairCost += discipline.GetRepairCost();
							}

							//mam 112806
							if (!isNA || node.GetAnyCurrentValueOverridden())
							{
								useNACurrentValue = false;
								tempTotalCurrentValue += discipline.GetCurrentValue();
							}
						}
					}
					else
					{
						//mam 050806
						if (discipline.ConditionRanking != CondRank.No)
						{
							useNAEvalValue = false;
							tempTotalEvaluatedValue += discipline.GetEvaluatedValue();
						}
						if (discipline.ConditionRanking != CondRank.No || discipline.OverrideRepairCost)
						{
							useNARepairCost = false;
							tempTotalRepairCost += discipline.GetRepairCost();
						}

						//mam 112806
						if (discipline.ConditionRanking != CondRank.No || discipline.OverrideCurrentValue)
						{
							useNACurrentValue = false;
							tempTotalCurrentValue += discipline.GetCurrentValue();
						}
					}
				}
			}

			//if (tempTotalEvaluatedValue == 0)
			if (useNAEvalValue)
			{
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, "N/A");
			}
			else
			{
				tempTotalEvaluatedValue *= (decimal)process.PctFunded;
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, tempTotalEvaluatedValue.ToString("$#,##0"));
			}

			//if (tempTotalRepairCost == 0)
			if (useNARepairCost)
			{
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, "N/A");
			}
			else
			{
				tempTotalRepairCost *= (decimal)process.PctFunded;
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, tempTotalRepairCost.ToString("$#,##0"));
			}

			//mam 112806
			if (useNACurrentValue)
			{
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, "N/A");
			}
			else
			{
				tempTotalCurrentValue *= (decimal)process.PctFunded;
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, tempTotalCurrentValue.ToString("$#,##0"));
			}
		}
		//</mam>

		//mam - need to recalculate the CWP values in other rows so that the CWP column totals 100
		private void UpdateCWP(decimal totalValue)
		{
			//don't allow this code to run if the grid is loading
			if (!isLoading)
			{
				double newCPWValue = 0;
				decimal tempDecimal = 0;

				c1FlexGridProcesses.Redraw = false;
				for (int row=2; row < c1FlexGridProcesses.Rows.Count-1; row++)
				{
					//CPWValue = CurrentValue * PercentFunded / TotalCurrentValue * 100
					//the CurrentValue in the grid has already been multiplied by PercentFunded

					//mam 112806 - use AcquisitionCost instead of CurrentValue
					//tempDecimal = Decimal.Parse((c1FlexGridProcesses.GetData(row, (int)ProcessColumns.CurrentValue).ToString()),
					//	System.Globalization.NumberStyles.Currency);
					tempDecimal = Decimal.Parse((c1FlexGridProcesses.GetData(row, (int)ProcessColumns.AcquisitionCost).ToString()),
						System.Globalization.NumberStyles.Currency);
					if (totalValue > 0)
					{
						newCPWValue = Math.Round((double)(tempDecimal / totalValue) * 100.0, 1);
					}
					c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, newCPWValue);
				}
				c1FlexGridProcesses.Redraw = true;
			}
		}
		//</mam>

		private void		UpdateGridTotals()
		{
			WAM.Logic.TreatmentProcessTotals processTotals = 
				m_facility.GetProcessTotals();
			int				row = c1FlexGridProcesses.Rows.Count - 1;

			c1FlexGridProcesses.Rows[row].Style = c1FlexGridProcesses.Styles["GrandTotal"];
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ProcessName, "Total");
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CWPValue, 
				processTotals.GetFundedCalcTotalCWP());
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AcquisitionCost, 
				processTotals.GetFundedTotalAcquisitionCost().ToString("$#,##0"));

			//mam 050806
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AcquisitionCostEscalated, 
				processTotals.GetFundedTotalAcquisitionCostEscalated().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RehabCost, 
				processTotals.GetFundedTotalRehabCost().ToString("$#,##0"));

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, 
				processTotals.GetFundedTotalCurrentValue().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ReplacementValue, 
				processTotals.GetFundedTotalReplacementValue().ToString("$#,##0"));

			//mam 050806
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.ReplacementValueYearAverage,
				processTotals.GetAverageReplacementValueYear().ToString("0"));

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.BookValue, 
				processTotals.GetFundedTotalBookValue().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.SalvageValue, 
				processTotals.GetFundedTotalSalvageValue().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AnnualDepreciation, 
				processTotals.GetFundedTotalAnnualDepreciation().ToString("$#,##0"));
			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CumulativeDepreciation, 
				processTotals.GetFundedTotalCumulativeDepreciation().ToString("$#,##0"));

			//mam - comment four lines
			//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, 
			//	processTotals.GetFundedTotalEvaluatedValue().ToString("$#,##0"));
			//c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, 
			//	processTotals.GetFundedTotalRepairCost().ToString("$#,##0"));
			//</mam>

			//mam - add amounts in the EvaluatedValue and RepairCost columns to arrive at the Total, 
			//	rather than calling the methods commented above
			decimal tempTotalEvaluatedValue = 0;
			decimal tempTotalRepairCost = 0;
			bool useNAEvalValue = true;
			bool useNARepairCost = true;

			//mam 112806
			decimal tempTotalCurrentValue = 0;
			bool useNACurrentValue = true;

			for (int i=2; i<c1FlexGridProcesses.Rows.Count-1; i++)
			{
				if (c1FlexGridProcesses.GetData(i, (int)ProcessColumns.EvaluatedValue).ToString() != "N/A")
				{
					useNAEvalValue = false;
					tempTotalEvaluatedValue += Decimal.Parse((c1FlexGridProcesses.GetData(i, (int)ProcessColumns.EvaluatedValue).ToString()),
						System.Globalization.NumberStyles.Currency);
				}
				if (c1FlexGridProcesses.GetData(i, (int)ProcessColumns.RepairCost).ToString() != "N/A")
				{
					useNARepairCost = false;
					tempTotalRepairCost += Decimal.Parse((c1FlexGridProcesses.GetData(i, (int)ProcessColumns.RepairCost).ToString()),
						System.Globalization.NumberStyles.Currency);
				}

				//mam 112806
				if (c1FlexGridProcesses.GetData(i, (int)ProcessColumns.CurrentValue).ToString() != "N/A")
				{
					useNACurrentValue = false;
					tempTotalCurrentValue += Decimal.Parse((c1FlexGridProcesses.GetData(i, (int)ProcessColumns.CurrentValue).ToString()),
						System.Globalization.NumberStyles.Currency);
				}
			}
			//if (tempTotalEvaluatedValue == 0)
			if (useNAEvalValue)
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, "N/A");
			else
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.EvaluatedValue, tempTotalEvaluatedValue.ToString("$#,##0"));

			//if (tempTotalRepairCost == 0)
			if (useNARepairCost)
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, "N/A");
			else
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.RepairCost, tempTotalRepairCost.ToString("$#,##0"));
			//</mam>

			//mam 112806
			if (useNACurrentValue)
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, "N/A");
			else
				c1FlexGridProcesses.SetData(row, (int)ProcessColumns.CurrentValue, tempTotalCurrentValue.ToString("$#,##0"));

			c1FlexGridProcesses.SetData(row, (int)ProcessColumns.AnnualMaintenanceCost, 
				processTotals.GetFundedTotalAnnualMaintenanceCost().ToString("$#,##0"));

			//mam
			AdjustCWPValues();
			//</mam>

			//mam
			PerformRounding();
			//</mam>
		}

		private void c1FlexGridProcesses_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row < 1)
				return;

			TreatmentProcess process = c1FlexGridProcesses.Rows[e.Row].UserData as TreatmentProcess;
			object			val = c1FlexGridProcesses[e.Row, e.Col];
			bool			dirty = false;

			if (process == null)
				return;

			switch (e.Col)
			{
				case (int)ProcessColumns.PercentFunded:
					if (Math.Round(process.PctFunded, 3) != 
						Math.Round(((double)val) / 100.0, 3))
					{
						process.PctFunded = (double)((double)val / 100.0);
						dirty = true;
					}
					break;
				default:
					break;
			}

			// Save the process record if anything changed
			if (dirty)
			{
				process.Save();
				UpdateGridRow(e.Row, process);
				UpdateGridTotals();

				//mam
				AdjustCWPValues();
				PerformRounding();
				//</mam>
			}
		}

		private void c1FlexGridProcesses_StartEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row == c1FlexGridProcesses.Rows.Count - 1 || 
				e.Row < 1 ||
				e.Col != (int)ProcessColumns.PercentFunded)
			{
				e.Cancel = true;
				return;
			}
		}
	}
}
