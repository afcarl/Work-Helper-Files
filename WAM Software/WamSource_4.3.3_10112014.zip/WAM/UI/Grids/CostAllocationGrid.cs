using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using WAM.Data;

namespace WAM.UI.Grids
{
	/// <summary>
	/// Summary description for CostAllocationGrid.
	/// </summary>
	public class CostAllocationGrid : System.Windows.Forms.UserControl
	{
		enum Columns
		{
			Name = 0,
			CWPValue,
			CurrentValue,
		}

		public enum GridType
		{
			TreatmentProcesses = 0,
			MajorComponents,
			Disciplines
		}

		private object		m_root = null;

		private GridType	m_gridType = GridType.MajorComponents;

		private C1.Win.C1FlexGrid.C1FlexGrid grid;

		//mam - add bool to determine whether grid is loading
		private bool isLoading = false;
		//</mam>

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CostAllocationGrid()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			grid.Rows[0].HeightDisplay = 
				(int)(grid.Rows[0].HeightDisplay * 3.0);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grid = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// grid
			// 
			this.grid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.grid.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.grid.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.grid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.None;
			this.grid.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.grid.ColumnInfo = @"3,0,0,0,0,85,Columns:0{Width:250;Caption:""Disciplines"";AllowEditing:False;DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	1{Width:75;Caption:""Cost Weighted Percentage of Asset Value (%)"";DataType:System.Double;Format:""F1"";TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	2{Width:75;Caption:""Current Value ($)"";DataType:System.Decimal;Format:""$#,##0"";TextAlign:RightCenter;TextAlignFixed:CenterCenter;}	";
			this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.grid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.grid.Location = new System.Drawing.Point(0, 0);
			this.grid.Name = "grid";
			this.grid.Rows.Count = 2;
			this.grid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.grid.ShowSort = false;
			this.grid.Size = new System.Drawing.Size(388, 128);
			this.grid.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Display:Stack;Format:""$#,##0"";BackColor:Highlight;ForeColor:HighlightText;TextAlign:GeneralCenter;TextEffect:Flat;ImageAlign:LeftCenter;ImageSpacing:2;Trimming:None;WordWrap:False;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.grid.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.grid.TabIndex = 0;
			this.grid.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.grid_AfterEdit);
			this.grid.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.grid_StartEdit);
			// 
			// CostAllocationGrid
			// 
			this.Controls.Add(this.grid);
			this.Name = "CostAllocationGrid";
			this.Size = new System.Drawing.Size(388, 128);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// create frozen area at the bottom, with 1 rows
			FlexFreezeBottom ffb = new FlexFreezeBottom(grid, 1);

			UpdateColumnTitles();

			base.OnLoad(e);
		}

		private void		UpdateColumnTitles()
		{
			if (m_gridType == GridType.TreatmentProcesses)
			{
				grid[0, (int)Columns.Name] = "Treatment Processes / Basins / Zones\r\nin this\r\nFacility / System";
			}
			if (m_gridType == GridType.MajorComponents)
			{
				grid[0, (int)Columns.Name] = "Components / Subbasins / Subzones\r\nin this\r\nProcess / Basis / Zone";
			}
			else if (m_gridType == GridType.Disciplines)
			{
				grid[0, (int)Columns.Name] = "Disciplines";
			}

			grid[0, (int)Columns.CWPValue] = "Cost Weighted\r\nPercentage of\r\nAsset Value (%)";
			grid[0, (int)Columns.CurrentValue] = "Current Value ($)";
		}

		public GridType		GridStyle
		{
			get { return m_gridType; }
			set 
			{ 
				m_gridType = value;
				UpdateColumnTitles();
			}
		}

		public void			SetRootObject(object obj)
		{
			m_root = obj;

			//mam - m_gridtype is initialized as GridType.MajorComponents
			//	but is never set to the proper type
			if (m_root is Facility)
				m_gridType = GridType.TreatmentProcesses;
			else if (m_root is TreatmentProcess)
				m_gridType = GridType.MajorComponents;
			else if (m_root is MajorComponent)
				m_gridType = GridType.Disciplines;
			//</mam>

			LoadGrid();
		}

		private void		LoadGrid()
		{
			if (m_root == null)
			{
				grid.Rows.Count = 2;
				return;
			}

			grid.Rows.Count = 2;

			//mam - column headers are never set for the current tree node type
			UpdateColumnTitles();
			//</mam>

			if (m_root is Facility)
				LoadFacilityGrid();
			else if (m_root is TreatmentProcess)
				LoadTreatmentProcessGrid();
			else if (m_root is MajorComponent)
				LoadMajorCostAllocationGrid();
		}

		private void		LoadFacilityGrid()
		{
			//mam
			isLoading = true;
			//</mam>

			Facility		facility = m_root as Facility;
			if (facility == null)
				return;

			// Load the process list
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(InfoSet.CurrentID, facility.ID);
			TreatmentProcess process;
			int				row = 1;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = process;
				UpdateProcessGridRow(row++, process);
			}

			UpdateProcessGridTotals();

			//mam
			isLoading = false;
			AdjustCWPValues();

			SetEditing();

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		private void		LoadTreatmentProcessGrid()
		{
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			// Load the process list
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, process.ID);
			MajorComponent component;
			int				row = 1;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (component.Retired)
					continue;

				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = component;
				UpdateComponentGridRow(row++, component);
			}

			UpdateComponentGridTotals(false);

			SetEditing();

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		private void		LoadMajorCostAllocationGrid()
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			// Load the process list
			Discipline[] disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
			Discipline discipline;
			int				row = 1;

			// Top fixed row and bottom totals row
			grid.Redraw = false;
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				grid.Rows.Add();
				grid.Rows[row].Style = grid.Styles["Normal"];
				grid.Rows[row].UserData = discipline;
				UpdateDisciplineGridRow(row++, discipline);
			}

			UpdateDisciplineGridTotals(false);
			SetEditing();

			// Set the data in the totals columns
			grid.Redraw = true;
		}

		//mam
		private void AdjustCWPValues()
		{
			try
			{
				Facility facility = m_root as Facility;
				if (facility == null)
					return;
				if (isLoading)
					return;

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				decimal totalValue = facility.GetOrgCost();
				//decimal totalValue = facility.GetAcquisitionCost();

				//correct CWP values on when the Current Value total > 0
				if (totalValue > 0)
				{
					int RowDataStarts = 1;
					int ArrayLength = grid.Rows.Count-(RowDataStarts + 1);

					decimal trueValue = 0;
					decimal[] cwpArrayTruncValue = new decimal[ArrayLength];
					decimal[] cwpArrayErrorValue = new decimal[ArrayLength];
					decimal[,] bubbleList = new decimal[ArrayLength, 2];
					decimal tempItem = 0;
					long totalTruncValue = 0;
					bool bubbleSorted = false;
					long totalAdjustmentsRequired = 0;

					grid.Redraw = false;

					for (int row=RowDataStarts; row < grid.Rows.Count-1; row++)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue, making this N/A check unnecessary
						//mam 112806
						if (grid.GetData(row, (int)Columns.CurrentValue).ToString() == "N/A")
						{
							continue;
						}

						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//divide CurrentValue for this row by the total of the Current Value column
						trueValue = Decimal.Parse((grid.GetData(row, (int)Columns.CurrentValue).ToString()),
							System.Globalization.NumberStyles.Currency) / totalValue * 100m;
						//trueValue = Decimal.Parse((grid.GetData(row, "AcquisitionCost").ToString()),
						//	System.Globalization.NumberStyles.Currency) / totalValue * 100m;

						//truncate trueValue after the first decimal place
						cwpArrayTruncValue[row-RowDataStarts] = (Decimal.Truncate(trueValue * 10m)) / 10m;

						//calculate error value
						cwpArrayErrorValue[row-RowDataStarts] = trueValue - cwpArrayTruncValue[row-RowDataStarts];

						//multiply truncated value by 10 to work in whole numbers
						totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[row-RowDataStarts] * 10m);
					}
	
					//populate bubbleList array
					bubbleSorted = false;
					for (int i = 0; i < ArrayLength; i++)
					{
						//assign the counter
						bubbleList[i, 0] = i;
						//assign the error value
						bubbleList[i, 1] = cwpArrayErrorValue[i];
					}

					//sort the bubbleList from highest to lowest Error Value
					bubbleSorted = false;
					do
					{
						bubbleSorted=true;
						for (int i = 0; i < ArrayLength-1; i++)
						{
							if (bubbleList[i,1] < bubbleList[i+1,1])
							{
								bubbleSorted = false;

								//switch the order of the two items
								tempItem = bubbleList[i,1];
								bubbleList[i,1] = bubbleList[i+1,1];
								bubbleList[i+1,1] = tempItem;

								tempItem = bubbleList[i,0];
								bubbleList[i,0] = bubbleList[i+1,0];
								bubbleList[i+1,0] = tempItem;
							}
						}
					}
					while (!bubbleSorted);

					//adjust the truncated values, as necessary
					totalAdjustmentsRequired = 1000 - totalTruncValue;
					for (int i = 0; i < totalAdjustmentsRequired; i++)
						cwpArrayTruncValue[Convert.ToInt32(bubbleList[i, 0])] += 0.1m;

					//write the adjusted CPW values to the grid
					tempItem = 0;
					for (int row=RowDataStarts; row < grid.Rows.Count-1; row++)
					{
						grid.SetData(row, (int)Columns.CWPValue, (double)cwpArrayTruncValue[row-RowDataStarts]);
						tempItem += cwpArrayTruncValue[row-RowDataStarts];
					}

					//update CPWValues total in the grid
					grid.SetData(grid.Rows.Count - 1, (int)Columns.CWPValue, tempItem);

					grid.Redraw = true;
				}
			}
			catch
			{
			}
		}
		//</mam>

		private void		UpdateProcessGridRow(int row, TreatmentProcess process)
		{
			Facility		facility = m_root as Facility;
			decimal			totalOrgCost = 0;
			if (facility == null)
				return;

			totalOrgCost = facility.GetOrgCost();
			grid.SetData(row, (int)Columns.Name, process.Name);

			// the CWP value is % of total
			if (totalOrgCost != 0)
			{
				grid.SetData(row, (int)Columns.CWPValue, 
					Math.Round((double)(process.OrgCost / totalOrgCost) * 100.0, 1));
			}
			else
				grid.SetData(row, (int)Columns.CWPValue, 0.0);

			// Allocation is based on actual CWP (user entered)
			grid.SetData(row, (int)Columns.CurrentValue, process.OrgCost);
		}

		private void		UpdateProcessGridTotals()
		{
			Facility		facility = m_root as Facility;
			if (facility == null)
				return;

			WAM.Logic.TreatmentProcessTotals totals = 
				facility.GetProcessTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");
			grid.SetData(row, (int)Columns.CWPValue, 
				totals.GetTotalCWPValue() * 100.0);
			grid.SetData(row, (int)Columns.CurrentValue, 
				totals.GetTotalOrgCost());

			//mam
			AdjustCWPValues();
			//</mam>
		}

		private void		UpdateComponentGridRow(int row, MajorComponent component)
		{
			grid.SetData(row, (int)Columns.Name, 
				component.Name);
			grid.SetData(row, (int)Columns.CWPValue, 
				component.CWPValue * 100.0);

			decimal			allocation = component.GetComponentCost();

			// Allocation is based on actual CWP (user entered)
			grid.SetData(row, (int)Columns.CurrentValue, allocation);
		}

		private void		UpdateComponentGridTotals(bool checkTotalPct)
		{
			TreatmentProcess process = m_root as TreatmentProcess;
			if (process == null)
				return;

			WAM.Logic.MajorComponentTotals totals = process.GetComponentTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");
			grid.SetData(row, (int)Columns.CWPValue, totals.GetTotalCWPValue() * 100.0);
			grid.SetData(row, (int)Columns.CurrentValue, totals.GetTotalOrgCost());

			//mam - changed from "< 100.0" to "!= 100.0" and commented so message doesn't show
			/*if (checkTotalPct && (totals.GetTotalCWPValue() * 100.0) != 100.0)
			{
				MessageBox.Show(this,
					"The Total Cost Weighted Percentage of Asset Value does not total 100 percent.",
					"");
			}*/
		}

		private void		UpdateDisciplineGridRow(int row, Discipline discipline)
		{
			grid.SetData(row, (int)Columns.Name, 
				discipline.Name);
			grid.SetData(row, (int)Columns.CWPValue, 
				discipline.CWPAssetValue * 100.0);

			//			if (discipline.ConditionRanking == CondRank.No)
			//			{
			//				grid.SetData(row, (int)Columns.CurrentValue, 0);
			//			}
			//			else
		{
			grid.SetData(row, (int)Columns.CurrentValue, 
				discipline.GetDisciplineCost());
		}
		}

		private void		UpdateDisciplineGridTotals(bool checkTotalPct)
		{
			MajorComponent component = m_root as MajorComponent;
			if (component == null)
				return;

			WAM.Logic.DisciplineTotals totals = 
				component.GetDisciplineTotals();
			int				row = grid.Rows.Count - 1;

			grid.Rows[row].Style = grid.Styles["GrandTotal"];
			grid.SetData(row, (int)Columns.Name, "Total");
			grid.SetData(row, (int)Columns.CWPValue, 
				totals.GetTotalCWPValue() * 100.0);
			grid.SetData(row, (int)Columns.CurrentValue, 
				totals.GetTotalOrgCost());

			//mam - changed from "< 100.0" to "!= 100.0" and commented so message doesn't show
			/*if (checkTotalPct && (totals.GetTotalCWPValue() * 100.0) != 100.0)
			{
				MessageBox.Show(this,
					"The Total Cost Weighted Percentage of Asset Value does not total 100 percent.",
					"");
			}*/
		}

		private void grid_StartEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row == grid.Rows.Count - 1 || e.Row < grid.Rows.Fixed)
			{
				e.Cancel = true;
				return;
			}

			switch (e.Col)
			{
				case (int)Columns.CWPValue:
					// Disallow edit of CWP on facility
					if (m_root is Facility)
					{
						e.Cancel = true;
						return;
					}
					break;
				case (int)Columns.CurrentValue:
					// Disallow edit of current value on non-facility
					if (!(m_root is Facility))
					{
						e.Cancel = true;
						return;
					}
					break;
			}
		}

		private void grid_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			if (e.Row < grid.Rows.Fixed)
				return;

			TreatmentProcess process = grid.Rows[e.Row].UserData as TreatmentProcess;
			MajorComponent	component = grid.Rows[e.Row].UserData as MajorComponent;
			Discipline		discipline = grid.Rows[e.Row].UserData as Discipline;
			object			val = grid[e.Row, e.Col];
			bool			dirty = false;

			if (process == null && component == null && discipline == null)
				return;

			switch (e.Col)
			{
				case (int)Columns.CWPValue:
					if (process != null)
					{
						e.Cancel = true;
						break;
					}
					else if (component != null)
					{
						if (Math.Round(component.CWPValue, 3) != 
							Math.Round(((double)val) / 100.0, 3))
						{
							component.CWPValue = (double)((double)val / 100.0);
							dirty = true;
						}
					}
					else if (discipline != null)
					{
						if (Math.Round(discipline.CWPAssetValue, 3) != 
							Math.Round(((double)val) / 100.0, 3))
						{
							discipline.CWPAssetValue = (double)((double)val / 100.0);
							dirty = true;
						}
					}
					break;
				case (int)Columns.CurrentValue:
					// Only allow edit on TreatmentProcess
					if (process == null)
					{
						e.Cancel = true;
						break;
					}

					decimal newVal = 
						Drive.Convert.DollarStringToDecimal(val.ToString());

					if (newVal != process.OrgCost)
					{
						process.OrgCost = newVal;
						dirty = true;
					}
					break;

				default:
					break;
			}

			// Save the process record if anything changed
			if (dirty)
			{
				if (process != null)
				{
					process.Save();

					// Update the percentages on each row
					for (int pos = grid.Rows.Fixed; pos < grid.Rows.Count - 1; pos++)
						UpdateProcessGridRow(pos, grid.Rows[pos].UserData as TreatmentProcess);

					UpdateProcessGridTotals();
				}
				else if (component != null)
				{
					component.Save();
					UpdateComponentGridRow(e.Row, component);
					UpdateComponentGridTotals(true);
				}
				else if (discipline != null)
				{
					discipline.Save();
					UpdateDisciplineGridRow(e.Row, discipline);
					UpdateDisciplineGridTotals(true);
				}
			}
		}

		private void SetEditing()
		{
			//mam - disable editing in all columns if infoset is fixed
			bool infoSetFixed = InfoSet.IsFixed;
			//if (infoSetFixed)
			//{
			//foreach (Column col in grid.Cols)
			//{
			//	col.AllowEditing = false;
			//}
			//MessageBox.Show(grid.Cols[1].Caption + "; " + grid.Cols[2].Caption);
			grid.Cols[1].AllowEditing = !infoSetFixed;
			grid.Cols[2].AllowEditing = !infoSetFixed;
			//}
			//</mam>
		}
	}
}