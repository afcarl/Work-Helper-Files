using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for TestForm.
	/// </summary>
	public class TestForm : System.Windows.Forms.Form
	{
		public delegate void SelectedDatabase(string selectedDB);
		public event SelectedDatabase OnSelectedDatabase;

		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.ComboBox comboBoxDatabase;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		protected override void OnLoad(EventArgs e)
		{
//			this.Text = "Load Database";
//			this.buttonOK.Enabled = false;
//			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();
//			//System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(@"E:\Projects\WAM\WAM\bin\Debug");
//			System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(@Drive.IO.Directory.GetApplicationPath());
//
//			foreach (System.IO.FileInfo f in dir.GetFiles("*.mdb"))
//			{
//				if (verify.VerifyTables(f.Name))
//					comboBoxDatabase.Items.Add(f.Name);
//			}
//			if (comboBoxDatabase.Items.Count > 0)
//			{
//				this.buttonOK.Enabled = true;
//				comboBoxDatabase.SelectedIndex = 0;
//			}
//			else
//			{
//				comboBoxDatabase.Text = "There are no databases to load";
//			}
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestForm));
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.comboBoxDatabase = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(266, 12);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(16, 16);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 99;
			this.pictureBoxHelp.TabStop = false;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(10, 11);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(215, 24);
			this.label1.TabIndex = 98;
			this.label1.Text = "Select a database to load";
			// 
			// buttonOK
			// 
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(130, 114);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 96;
			this.buttonOK.Text = "&OK";
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(211, 114);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 97;
			this.buttonCancel.Text = "Cancel";
			// 
			// comboBoxDatabase
			// 
			this.comboBoxDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxDatabase.DropDownWidth = 273;
			this.comboBoxDatabase.Location = new System.Drawing.Point(14, 40);
			this.comboBoxDatabase.Name = "comboBoxDatabase";
			this.comboBoxDatabase.Size = new System.Drawing.Size(270, 21);
			this.comboBoxDatabase.TabIndex = 95;
			// 
			// TestForm
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(292, 144);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.comboBoxDatabase);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.HelpButton = true;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "TestForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "TestForm";
			this.ResumeLayout(false);

		}
		#endregion

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (comboBoxDatabase.Items.Count > 0)
				this.OnSelectedDatabase(comboBoxDatabase.Text);
			else
				this.OnSelectedDatabase("");

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void DatabaseLoad_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the
			// Help cursor is clicked on any of the address fields.
			// The Help text for the field is in the control's
			// Tag property. It is retrieved and displayed in the label.

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void pictureBoxHelp_Click_1(object sender, System.EventArgs e)
		{
			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
	}
}
