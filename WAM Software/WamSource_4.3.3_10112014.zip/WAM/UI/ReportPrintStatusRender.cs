using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportPrintStatus.
	/// </summary>
	public class ReportPrintStatusRender : System.Windows.Forms.Form
	{
		public delegate void Message(string str);
		public event Message OnMessage;
		public bool userCancelPreview = false;
		private ReportUpdateHandler	m_reportUpdateDelegate = null;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.Timer timer;
		private System.Windows.Forms.PictureBox pictureBoxStop;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.ComponentModel.IContainer components;

		public ReportPrintStatusRender()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_reportUpdateDelegate = new ReportUpdateHandler(this.UpdateStatus);
			AddCacheEventHandler(m_reportUpdateDelegate);

			this.Text = "Saving Reports";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}

				if (m_reportUpdateDelegate != null)
				{
					RemoveCacheEventHandler(m_reportUpdateDelegate);
					m_reportUpdateDelegate = null; 
				}

			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportPrintStatusRender));
			this.pictureBoxStop = new System.Windows.Forms.PictureBox();
			this.labelStatus = new System.Windows.Forms.Label();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.labelTitle = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// pictureBoxStop
			// 
			this.pictureBoxStop.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxStop.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStop.Image")));
			this.pictureBoxStop.Location = new System.Drawing.Point(16, 120);
			this.pictureBoxStop.Name = "pictureBoxStop";
			this.pictureBoxStop.Size = new System.Drawing.Size(16, 16);
			this.pictureBoxStop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxStop.TabIndex = 93;
			this.pictureBoxStop.TabStop = false;
			this.pictureBoxStop.Visible = false;
			this.pictureBoxStop.Click += new System.EventHandler(this.pictureBoxStop_Click);
			// 
			// labelStatus
			// 
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Location = new System.Drawing.Point(20, 51);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(248, 24);
			this.labelStatus.TabIndex = 94;
			// 
			// timer
			// 
			this.timer.Interval = 250;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(261, 12);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 96;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(10, 11);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(198, 24);
			this.labelTitle.TabIndex = 1;
			this.labelTitle.Text = "Saving Reports";
			// 
			// buttonCancel
			// 
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.buttonCancel.Image = ((System.Drawing.Image)(resources.GetObject("buttonCancel.Image")));
			this.buttonCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonCancel.Location = new System.Drawing.Point(211, 114);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 0;
			this.buttonCancel.TabStop = false;
			this.buttonCancel.Text = "     Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.pictureBoxStop_Click);
			// 
			// ReportPrintStatusRender
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 144);
			this.ControlBox = false;
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.labelStatus);
			this.Controls.Add(this.pictureBoxStop);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "ReportPrintStatusRender";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ReportPrintStatus";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Properties *****/

		//mam
		public bool CancelPreview
		{
			get { return userCancelPreview; }
			set { userCancelPreview = value; }
		}
		//</mam>

		#endregion /***** Properties *****/


//		public static void	ShowForm(Form owner)
//		{
//			ReportPrintStatus form = new ReportPrintStatus();
//
//			//form.m_infoSetID = infoSetID;
//			form.ShowDialog();
//		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		protected override void OnLoad(EventArgs e)
		{
			SetBitmaps();

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			timer.Enabled = true;
			base.OnLoad(e);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		private void UpdateStatus(object sender, ReportUpdateEventArgs e)
		{
			if (this.IsDisposed)
				return;
			else
			{
				this.labelStatus.Text = e.Status;
				Application.DoEvents();
			}
		}

		private void timer_Tick(object sender, System.EventArgs e)
		{
			//CacheManager.GetCacheForInfoSetID(m_infoSetID);
			//ReportFilterForm.CreateReports2();
			this.OnMessage("CreateReports");
			timer.Enabled = false;
			//this.Close();
		}

		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)buttonCancel.Image;
			b.MakeTransparent(Color.Fuchsia);
			buttonCancel.Image = b;

			b = (Bitmap)pictureBoxStop.Image;
			b.MakeTransparent(Color.Fuchsia);
			pictureBoxStop.Image = b;

			//b = (Bitmap)pictureBoxHelp.Image;
			//b.MakeTransparent(Color.Fuchsia);
			//pictureBoxHelp.Image = b;
		}

		//mam
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
		//</mam>

		#region /****** Event Handling ******/

		public delegate void ReportUpdateHandler(object sender, ReportUpdateEventArgs e);
		private static event ReportUpdateHandler CacheUpdate;

		public static void	AddCacheEventHandler(ReportUpdateHandler handler)
		{
			// example: 
			// ReportUpdateHandler handler = new CacheBuildStatusControl.ReportUpdateHandler(myClass.DataChanged)
			// CacheBuildStatusControl.AddCacheEventHandler(handler);

			// Declare method as:
			// private void UpdateStatus(object sender, ReportUpdateEventArgs e)
			CacheUpdate += handler;
		}

		public static void	RemoveCacheEventHandler(ReportUpdateHandler handler)
		{
			CacheUpdate -= handler;
		}

		public static void	InvokeUpdateEvent(object sender, ReportUpdateEventArgs e)
		{
			if (CacheUpdate != null)
				CacheUpdate(sender, e);
		}

		private void pictureBoxStop_Click(object sender, System.EventArgs e)
		{
			CancelPreview = true;
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		public class ReportUpdateEventArgs : EventArgs
		{
			public ReportUpdateEventArgs()
			{
				m_status = "";
			}

			public string	Status
			{
				get { return m_status; }
				set { m_status = value; }
			}

			private string	m_status;
		}

		#endregion //****** Event Handling ******/

	}
}
