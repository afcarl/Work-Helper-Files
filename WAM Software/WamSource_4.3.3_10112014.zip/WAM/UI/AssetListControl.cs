using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for AssetListControl.
	/// </summary>
	public class AssetListControl : System.Windows.Forms.UserControl
	{
		private MajorComponent m_component = null;

		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonAddAsset;
		private System.Windows.Forms.Button buttonEditAsset;
		private System.Windows.Forms.Button buttonDeleteAsset;
		private C1.Win.C1FlexGrid.C1FlexGrid gridAssets;
		private System.Windows.Forms.Panel panelLocked;
		private System.Windows.Forms.Label labelLocked;
		private System.Windows.Forms.HelpProvider helpProvider1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AssetListControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.buttonAddAsset = new System.Windows.Forms.Button();
			this.buttonEditAsset = new System.Windows.Forms.Button();
			this.buttonDeleteAsset = new System.Windows.Forms.Button();
			this.gridAssets = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.panelLocked = new System.Windows.Forms.Panel();
			this.labelLocked = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.gridAssets)).BeginInit();
			this.panelLocked.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.ReadOnly = true;
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 13;
			this.textBoxComponentName.Text = "";
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 9;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 8;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 15;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 29);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 26);
			this.label2.TabIndex = 10;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 11;
			this.textBoxProcessName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 12;
			this.label3.Text = "Component / Subbasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// buttonAddAsset
			// 
			this.buttonAddAsset.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddAsset.Location = new System.Drawing.Point(452, 4);
			this.buttonAddAsset.Name = "buttonAddAsset";
			this.buttonAddAsset.Size = new System.Drawing.Size(80, 23);
			this.buttonAddAsset.TabIndex = 16;
			this.buttonAddAsset.Text = "Add Asset";
			this.buttonAddAsset.Click += new System.EventHandler(this.buttonAddAsset_Click);
			// 
			// buttonEditAsset
			// 
			this.buttonEditAsset.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditAsset.Location = new System.Drawing.Point(452, 32);
			this.buttonEditAsset.Name = "buttonEditAsset";
			this.buttonEditAsset.Size = new System.Drawing.Size(80, 23);
			this.buttonEditAsset.TabIndex = 17;
			this.buttonEditAsset.Text = "Edit Asset";
			this.buttonEditAsset.Click += new System.EventHandler(this.buttonEditAsset_Click);
			// 
			// buttonDeleteAsset
			// 
			this.buttonDeleteAsset.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonDeleteAsset.Location = new System.Drawing.Point(452, 60);
			this.buttonDeleteAsset.Name = "buttonDeleteAsset";
			this.buttonDeleteAsset.Size = new System.Drawing.Size(80, 23);
			this.buttonDeleteAsset.TabIndex = 18;
			this.buttonDeleteAsset.Text = "Delete Asset";
			this.buttonDeleteAsset.Click += new System.EventHandler(this.buttonDeleteAsset_Click);
			// 
			// gridAssets
			// 
			this.gridAssets.AllowEditing = false;
			this.gridAssets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAssets.BackColor = System.Drawing.SystemColors.Window;
			this.gridAssets.ColumnInfo = @"4,0,0,0,0,85,Columns:0{Width:100;Caption:""Asset ID Number"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:LeftCenter;}	1{Width:210;Caption:""Description"";DataType:System.String;TextAlign:LeftCenter;}	2{Width:100;Caption:""Condition Ranking"";DataType:System.Byte;TextAlign:RightCenter;TextAlignFixed:RightCenter;}	3{Width:100;Caption:""Replacement Cost"";DataType:System.Decimal;Format:""$#,##0"";TextAlign:RightCenter;TextAlignFixed:RightCenter;}	";
			this.gridAssets.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridAssets.ForeColor = System.Drawing.SystemColors.WindowText;
			this.helpProvider1.SetHelpKeyword(this.gridAssets, "AssetList.htm");
			this.helpProvider1.SetHelpNavigator(this.gridAssets, System.Windows.Forms.HelpNavigator.Topic);
			this.gridAssets.Location = new System.Drawing.Point(4, 116);
			this.gridAssets.Name = "gridAssets";
			this.gridAssets.Rows.Count = 1;
			this.gridAssets.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.helpProvider1.SetShowHelp(this.gridAssets, true);
			this.gridAssets.Size = new System.Drawing.Size(532, 276);
			this.gridAssets.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridAssets.TabIndex = 19;
			this.gridAssets.DoubleClick += new System.EventHandler(this.gridAssets_DoubleClick);
			this.gridAssets.AfterSelChange += new C1.Win.C1FlexGrid.RangeEventHandler(this.gridAssets_AfterSelChange);
			// 
			// panelLocked
			// 
			this.panelLocked.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelLocked.Controls.Add(this.labelLocked);
			this.panelLocked.Location = new System.Drawing.Point(145, 90);
			this.panelLocked.Name = "panelLocked";
			this.panelLocked.Size = new System.Drawing.Size(215, 20);
			this.panelLocked.TabIndex = 20;
			// 
			// labelLocked
			// 
			this.labelLocked.BackColor = System.Drawing.Color.White;
			this.labelLocked.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelLocked.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.labelLocked.Location = new System.Drawing.Point(1, 1);
			this.labelLocked.Name = "labelLocked";
			this.labelLocked.Size = new System.Drawing.Size(213, 18);
			this.labelLocked.TabIndex = 16;
			this.labelLocked.Text = "All Data is Locked";
			this.labelLocked.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// AssetListControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(540, 396);
			this.Controls.Add(this.panelLocked);
			this.Controls.Add(this.gridAssets);
			this.Controls.Add(this.buttonDeleteAsset);
			this.Controls.Add(this.buttonEditAsset);
			this.Controls.Add(this.buttonAddAsset);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label3);
			this.helpProvider1.SetHelpKeyword(this, "AssetList.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Name = "AssetListControl";
			this.helpProvider1.SetShowHelp(this, true);
			this.Size = new System.Drawing.Size(540, 396);
			((System.ComponentModel.ISupportInitialize)(this.gridAssets)).EndInit();
			this.panelLocked.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			base.OnLoad(e);
		}

		public void			SetComponent(MajorComponent component)
		{
			m_component = component;
			RefreshData();
		}

		public void			RefreshData()
		{
			// Load the grid
			LoadGrid();

			if (m_component == null)
				return;

			m_component.InfoSetID = InfoSet.CurrentID;

			TreatmentProcess process = 
				CacheManager.GetTreatmentProcess(InfoSet.CurrentID, m_component.ProcessID);
			Facility facility = 
				CacheManager.GetFacility(InfoSet.CurrentID, process.FacilityID);

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = m_component.Name;

			//mam - disable controls if infoset is fixed
			if (InfoSet.IsFixed)
			{
				this.buttonAddAsset.Enabled = false;
				this.buttonEditAsset.Enabled = false;
				this.buttonDeleteAsset.Enabled = false;
			}
			panelLocked.Visible = InfoSet.IsFixed;
			//</mam>
		}

		private void		LoadGrid()
		{
			gridAssets.Rows.Count = 1;
			if (m_component == null)
				return;

			ComponentAsset[] assets = ComponentAsset.LoadAll(m_component.ID);
			ComponentAsset	asset;
			int				row = 1;

			gridAssets.Redraw = false;
			for (int pos = 0; pos < assets.Length; pos++)
			{
				asset = assets[pos];
				gridAssets.Rows.Add().UserData = asset;
				gridAssets.SetData(row, 0, asset.Name);
				gridAssets.SetData(row, 1, asset.Description);
				gridAssets.SetData(row, 2, (byte)asset.ConditionRanking);
				gridAssets.SetData(row, 3, asset.ReplacementCost);
				row++;
			}
			gridAssets.Redraw = true;

			gridAssets_AfterSelChange(null, null);

			//mam - disable controls if infoset is fixed
			if (InfoSet.IsFixed)
			{
				foreach (C1.Win.C1FlexGrid.Column col in gridAssets.Cols)
				{
					col.AllowEditing = false;
				}
			}
			//</mam>
		}

		private void buttonAddAsset_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (m_component == null || m_component.ID == 0)
				return;

			ComponentAsset asset = new ComponentAsset(0);

			asset.ComponentID = m_component.ID;
			if (AssetDetailForm.ShowForm(asset, (Form)this.TopLevelControl))
			{
				int			row = gridAssets.Rows.Count;

				gridAssets.Rows.Add().UserData = asset;
				gridAssets.SetData(row, 0, asset.Name);
				gridAssets.SetData(row, 1, asset.Description);
				gridAssets.SetData(row, 2, (byte)asset.ConditionRanking);
				gridAssets.SetData(row, 3, asset.ReplacementCost);
				gridAssets_AfterSelChange(null, null);
			}
		}

		private void buttonEditAsset_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			int				row = gridAssets.Row;

			if (row < gridAssets.Rows.Fixed)
				return;

			ComponentAsset asset = gridAssets.Rows[row].UserData as ComponentAsset;

			if (AssetDetailForm.ShowForm(asset, (Form)this.TopLevelControl))
			{
				gridAssets.SetData(row, 0, asset.Name);
				gridAssets.SetData(row, 1, asset.Description);
				gridAssets.SetData(row, 2, (byte)asset.ConditionRanking);
				gridAssets.SetData(row, 3, asset.ReplacementCost);
			}
		}

		private void buttonDeleteAsset_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			int				row = gridAssets.Row;

			if (row < gridAssets.Rows.Fixed)
				return;

			ComponentAsset asset = gridAssets.Rows[row].UserData as ComponentAsset;

			if (MessageBox.Show(this, 
				"Are you sure that you want to delete this asset?",
				"Delete Asset", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button1) == DialogResult.Yes)
			{
				if (asset.Delete())
				{
					gridAssets.RemoveItem(row);
					gridAssets_AfterSelChange(null, null);
				}
			}
		}

		private void gridAssets_AfterSelChange(object sender, C1.Win.C1FlexGrid.RangeEventArgs e)
		{
			bool			enabled;

			enabled = (m_component != null && m_component.ID != 0) && 
				(gridAssets.Row >= gridAssets.Rows.Fixed);

			//mam - enable buttons only if infoset is not fixed
			if (!InfoSet.IsFixed)
			//</mam>
			{
				buttonAddAsset.Enabled = (m_component != null && m_component.ID != 0);
				buttonEditAsset.Enabled = enabled;
				buttonDeleteAsset.Enabled = enabled;
			}
			
		}

		private void gridAssets_DoubleClick(object sender, System.EventArgs e)
		{
			//mam - click button only if infoset is not fixed
			if (!InfoSet.IsFixed)
			//</mam>
				buttonEditAsset_Click(null, null);
		}

	}
}
