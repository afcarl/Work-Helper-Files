using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Text;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for InfoSetControl.
	/// </summary>
	public class InfoSetControl : System.Windows.Forms.UserControl
	{
		private InfoSet		m_infoSet = null;


		private System.Windows.Forms.Label labelInfoSet;
		private System.Windows.Forms.Button buttonAddFacility;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public InfoSetControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.labelInfoSet = new System.Windows.Forms.Label();
			this.buttonAddFacility = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// labelInfoSet
			// 
			this.labelInfoSet.Location = new System.Drawing.Point(4, 4);
			this.labelInfoSet.Name = "labelInfoSet";
			this.labelInfoSet.Size = new System.Drawing.Size(388, 56);
			this.labelInfoSet.TabIndex = 0;
			this.labelInfoSet.Click += new System.EventHandler(this.labelInfoSet_Click);
			// 
			// buttonAddFacility
			// 
			this.buttonAddFacility.Location = new System.Drawing.Point(161, 64);
			this.buttonAddFacility.Name = "buttonAddFacility";
			this.buttonAddFacility.TabIndex = 1;
			this.buttonAddFacility.Text = "&Add Facility";
			this.buttonAddFacility.Click += new System.EventHandler(this.buttonAddFacility_Click);
			// 
			// InfoSetControl
			// 
			this.Controls.Add(this.buttonAddFacility);
			this.Controls.Add(this.labelInfoSet);
			this.Name = "InfoSetControl";
			this.Size = new System.Drawing.Size(396, 92);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			buttonAddFacility.Visible = false;
			base.OnLoad(e);
		}

		public void			SetInfoSet(InfoSet infoSet)
		{
			m_infoSet = infoSet;
			UpdateScreen();
		}

		private void		UpdateScreen()
		{
			if (m_infoSet != null)
			{
				StringBuilder builder = new StringBuilder(150);

				builder.AppendFormat("You are currently working with the '{0}' data set. ",
					m_infoSet.Name);
				builder.Append("You may add a facility, or select an item in the list to the left to see its details.");

				labelInfoSet.Text = builder.ToString();
				buttonAddFacility.Visible = true;
			}
			else
			{
				labelInfoSet.Text = "You do not have a data set selected. You will need to select a data set in order to continue.";
				buttonAddFacility.Visible = false;
			}
		}

		private void buttonAddFacility_Click(object sender, System.EventArgs e)
		{
			MainForm form = this.TopLevelControl as MainForm;

			if (form != null)
			{
				form.AddFacility();
			}
		}

		private void labelInfoSet_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
