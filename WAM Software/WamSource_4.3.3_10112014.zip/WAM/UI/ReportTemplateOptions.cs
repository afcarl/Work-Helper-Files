using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportTemplate.
	/// </summary>
	public class ReportTemplateOptions : System.Windows.Forms.Form
	{
		//public delegate void Message(int autoSave);
		//public event Message OnMessage;
		//public int autoSaveOption = 1;
		private int autoSaveOption = 1;
		private string formText = "";
		private string labelText = "";
		private System.Windows.Forms.CheckBox checkBoxAutomaticSave;
		private System.Windows.Forms.Label labelAutomaticSave;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label labelTitle;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ReportTemplateOptions()
		{
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportTemplateOptions));
			this.labelTitle = new System.Windows.Forms.Label();
			this.checkBoxAutomaticSave = new System.Windows.Forms.CheckBox();
			this.labelAutomaticSave = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.SuspendLayout();
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(10, 11);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(198, 24);
			this.labelTitle.TabIndex = 75;
			this.labelTitle.Text = "Report Preferences";
			// 
			// checkBoxAutomaticSave
			// 
			this.checkBoxAutomaticSave.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxAutomaticSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxAutomaticSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.checkBoxAutomaticSave.Location = new System.Drawing.Point(32, 46);
			this.checkBoxAutomaticSave.Name = "checkBoxAutomaticSave";
			this.checkBoxAutomaticSave.Size = new System.Drawing.Size(12, 13);
			this.checkBoxAutomaticSave.TabIndex = 1;
			// 
			// labelAutomaticSave
			// 
			this.labelAutomaticSave.BackColor = System.Drawing.Color.Transparent;
			this.labelAutomaticSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAutomaticSave.Location = new System.Drawing.Point(48, 44);
			this.labelAutomaticSave.Name = "labelAutomaticSave";
			this.labelAutomaticSave.Size = new System.Drawing.Size(232, 16);
			this.labelAutomaticSave.TabIndex = 0;
			this.labelAutomaticSave.Text = "Automatically save report templates";
			this.labelAutomaticSave.Click += new System.EventHandler(this.labelAutomaticSave_Click);
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(130, 114);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&OK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(211, 114);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(263, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 93;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// ReportTemplateOptions
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(292, 144);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelAutomaticSave);
			this.Controls.Add(this.checkBoxAutomaticSave);
			this.Controls.Add(this.labelTitle);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "Reports.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportTemplateOptions";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ReportTemplate";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReportTemplateOptions_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		public static bool ShowForm(ref int autoSaveOption, string formText, string labelText, Form owner)
		{
			ReportTemplateOptions form = new ReportTemplateOptions();
			bool success;

			form.autoSaveOption = autoSaveOption;
			form.formText = formText;
			form.labelText = labelText;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			if (success)
			{
				autoSaveOption = form.autoSaveOption;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			//this.Text = "Report Preferences";
			this.Text = formText;
			this.labelTitle.Text = formText;
			this.labelAutomaticSave.Text = labelText;

			if (autoSaveOption == 1)
				this.checkBoxAutomaticSave.Checked = true;
			else
				this.checkBoxAutomaticSave.Checked = false;

			base.OnLoad(e);
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (this.checkBoxAutomaticSave.Checked)
				autoSaveOption = 1;
			else
				autoSaveOption = 0;

			//this.OnMessage(autoSaveOption);
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void labelAutomaticSave_Click(object sender, System.EventArgs e)
		{
			checkBoxAutomaticSave.Checked = !checkBoxAutomaticSave.Checked;
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			if (this.Text.IndexOf("Graph") > -1)
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphingNewOverview.htm");
			else
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "Reports.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			if (this.Text.IndexOf("Graph") > -1)
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphingNewOverview.htm");
			else
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "Reports.htm");
		}

		private void ReportTemplateOptions_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

	}

}
