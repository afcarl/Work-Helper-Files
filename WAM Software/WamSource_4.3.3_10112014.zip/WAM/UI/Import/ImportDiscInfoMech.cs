using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportDiscInfoMech.
	/// </summary>
	public class ImportDiscInfoMech : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/

		//private WAM.UI.ItemStatusControl itemStatusMechExcessiveVibration;
		private WAM.UI.ItemStatusControl itemStatusControl4;
		private System.Windows.Forms.GroupBox groupBox4;
		private WAM.UI.ItemStatusControl itemStatusPipingExcessiveLeaks;
		private WAM.UI.ItemStatusControl itemStatusPipingPaintGood;
		private WAM.UI.ItemStatusControl itemStatusPipingExcessiveCorrosion;
		private System.Windows.Forms.GroupBox groupBox3;
		private WAM.UI.ItemStatusControl itemStatusElecPartsAvailable;
		private WAM.UI.ItemStatusControl itemStatusElecCleanContacts;
		private WAM.UI.ItemStatusControl itemStatusElecExcessiveCorrosion;
		private System.Windows.Forms.GroupBox groupBox2;
		private WAM.UI.ItemStatusControl itemStatusInstrAlarmsFunctional;
		private WAM.UI.ItemStatusControl itemStatusInstrPartsAvailable;
		private WAM.UI.ItemStatusControl itemStatusInstrSystemsFunctional;
		private WAM.UI.ItemStatusControl itemStatusInstrPartsMissing;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel1;
		private WAM.UI.ItemStatusControl itemStatusMechAdequate;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveLeaks;
		private WAM.UI.ItemStatusControl itemStatusMechMotorAmps;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveCorrosion;
		private WAM.UI.ItemStatusControl itemStatusMechSupportFunctional;
		private WAM.UI.ItemStatusControl itemStatusMechCanRun;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveNoise;
		private WAM.UI.ItemStatusControl itemStatusMechExcessiveVibration;
		private WAM.UI.ItemStatusControl itemStatusMechPartsMissing;
		private WAM.UI.ItemStatusControl itemStatusMechRunningHot;
		private WAM.UI.ItemStatusControl itemStatusMechPartsAvailable;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.Panel panel9;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportDiscInfoMech()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.itemStatusControl4 = new WAM.UI.ItemStatusControl();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.itemStatusPipingExcessiveLeaks = new WAM.UI.ItemStatusControl();
			this.itemStatusPipingPaintGood = new WAM.UI.ItemStatusControl();
			this.itemStatusPipingExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.itemStatusElecPartsAvailable = new WAM.UI.ItemStatusControl();
			this.itemStatusElecCleanContacts = new WAM.UI.ItemStatusControl();
			this.itemStatusElecExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.itemStatusInstrAlarmsFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrPartsAvailable = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrSystemsFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusInstrPartsMissing = new WAM.UI.ItemStatusControl();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.itemStatusMechAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveLeaks = new WAM.UI.ItemStatusControl();
			this.itemStatusMechMotorAmps = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveCorrosion = new WAM.UI.ItemStatusControl();
			this.itemStatusMechSupportFunctional = new WAM.UI.ItemStatusControl();
			this.itemStatusMechCanRun = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveNoise = new WAM.UI.ItemStatusControl();
			this.itemStatusMechExcessiveVibration = new WAM.UI.ItemStatusControl();
			this.itemStatusMechRunningHot = new WAM.UI.ItemStatusControl();
			this.itemStatusMechPartsMissing = new WAM.UI.ItemStatusControl();
			this.itemStatusMechPartsAvailable = new WAM.UI.ItemStatusControl();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// itemStatusControl4
			// 
			this.itemStatusControl4.Caption = "";
			this.itemStatusControl4.Location = new System.Drawing.Point(0, 0);
			this.itemStatusControl4.Name = "itemStatusControl4";
			this.itemStatusControl4.Size = new System.Drawing.Size(196, 16);
			this.itemStatusControl4.Status = WAM.Data.ItemStatus.No;
			this.itemStatusControl4.TabIndex = 0;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.itemStatusPipingExcessiveLeaks);
			this.groupBox4.Controls.Add(this.itemStatusPipingPaintGood);
			this.groupBox4.Controls.Add(this.itemStatusPipingExcessiveCorrosion);
			this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox4.Location = new System.Drawing.Point(294, 217);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(296, 68);
			this.groupBox4.TabIndex = 3;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Piping";
			// 
			// itemStatusPipingExcessiveLeaks
			// 
			this.itemStatusPipingExcessiveLeaks.Caption = "Excessive leaks?";
			this.itemStatusPipingExcessiveLeaks.Location = new System.Drawing.Point(8, 32);
			this.itemStatusPipingExcessiveLeaks.Name = "itemStatusPipingExcessiveLeaks";
			this.itemStatusPipingExcessiveLeaks.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingExcessiveLeaks.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusPipingExcessiveLeaks.TabIndex = 1;
			// 
			// itemStatusPipingPaintGood
			// 
			this.itemStatusPipingPaintGood.Caption = "Paint in good condition?";
			this.itemStatusPipingPaintGood.Location = new System.Drawing.Point(8, 48);
			this.itemStatusPipingPaintGood.Name = "itemStatusPipingPaintGood";
			this.itemStatusPipingPaintGood.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingPaintGood.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusPipingPaintGood.TabIndex = 2;
			// 
			// itemStatusPipingExcessiveCorrosion
			// 
			this.itemStatusPipingExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusPipingExcessiveCorrosion.Location = new System.Drawing.Point(8, 16);
			this.itemStatusPipingExcessiveCorrosion.Name = "itemStatusPipingExcessiveCorrosion";
			this.itemStatusPipingExcessiveCorrosion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusPipingExcessiveCorrosion.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusPipingExcessiveCorrosion.TabIndex = 0;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.itemStatusElecPartsAvailable);
			this.groupBox3.Controls.Add(this.itemStatusElecCleanContacts);
			this.groupBox3.Controls.Add(this.itemStatusElecExcessiveCorrosion);
			this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox3.Location = new System.Drawing.Point(294, 135);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(296, 72);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Electrical";
			// 
			// itemStatusElecPartsAvailable
			// 
			this.itemStatusElecPartsAvailable.Caption = "Parts available for maintenance?";
			this.itemStatusElecPartsAvailable.Location = new System.Drawing.Point(8, 52);
			this.itemStatusElecPartsAvailable.Name = "itemStatusElecPartsAvailable";
			this.itemStatusElecPartsAvailable.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecPartsAvailable.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusElecPartsAvailable.TabIndex = 2;
			// 
			// itemStatusElecCleanContacts
			// 
			this.itemStatusElecCleanContacts.Caption = "Clean, well-maintained contacts?";
			this.itemStatusElecCleanContacts.Location = new System.Drawing.Point(8, 36);
			this.itemStatusElecCleanContacts.Name = "itemStatusElecCleanContacts";
			this.itemStatusElecCleanContacts.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecCleanContacts.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusElecCleanContacts.TabIndex = 1;
			// 
			// itemStatusElecExcessiveCorrosion
			// 
			this.itemStatusElecExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusElecExcessiveCorrosion.Location = new System.Drawing.Point(8, 20);
			this.itemStatusElecExcessiveCorrosion.Name = "itemStatusElecExcessiveCorrosion";
			this.itemStatusElecExcessiveCorrosion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusElecExcessiveCorrosion.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusElecExcessiveCorrosion.TabIndex = 0;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.itemStatusInstrAlarmsFunctional);
			this.groupBox2.Controls.Add(this.itemStatusInstrPartsAvailable);
			this.groupBox2.Controls.Add(this.itemStatusInstrSystemsFunctional);
			this.groupBox2.Controls.Add(this.itemStatusInstrPartsMissing);
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Location = new System.Drawing.Point(294, 38);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(296, 88);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Instrumentation";
			// 
			// itemStatusInstrAlarmsFunctional
			// 
			this.itemStatusInstrAlarmsFunctional.Caption = "Alarms functional?";
			this.itemStatusInstrAlarmsFunctional.Location = new System.Drawing.Point(8, 36);
			this.itemStatusInstrAlarmsFunctional.Name = "itemStatusInstrAlarmsFunctional";
			this.itemStatusInstrAlarmsFunctional.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrAlarmsFunctional.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusInstrAlarmsFunctional.TabIndex = 1;
			// 
			// itemStatusInstrPartsAvailable
			// 
			this.itemStatusInstrPartsAvailable.Caption = "Parts available for maintenance?";
			this.itemStatusInstrPartsAvailable.Location = new System.Drawing.Point(8, 68);
			this.itemStatusInstrPartsAvailable.Name = "itemStatusInstrPartsAvailable";
			this.itemStatusInstrPartsAvailable.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrPartsAvailable.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusInstrPartsAvailable.TabIndex = 3;
			// 
			// itemStatusInstrSystemsFunctional
			// 
			this.itemStatusInstrSystemsFunctional.Caption = "All critical indications functioning?";
			this.itemStatusInstrSystemsFunctional.Location = new System.Drawing.Point(8, 20);
			this.itemStatusInstrSystemsFunctional.Name = "itemStatusInstrSystemsFunctional";
			this.itemStatusInstrSystemsFunctional.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrSystemsFunctional.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusInstrSystemsFunctional.TabIndex = 0;
			// 
			// itemStatusInstrPartsMissing
			// 
			this.itemStatusInstrPartsMissing.Caption = "Equipment or parts missing?";
			this.itemStatusInstrPartsMissing.Location = new System.Drawing.Point(8, 52);
			this.itemStatusInstrPartsMissing.Name = "itemStatusInstrPartsMissing";
			this.itemStatusInstrPartsMissing.Size = new System.Drawing.Size(284, 16);
			this.itemStatusInstrPartsMissing.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusInstrPartsMissing.TabIndex = 2;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.panel11);
			this.groupBox1.Controls.Add(this.panel10);
			this.groupBox1.Controls.Add(this.panel8);
			this.groupBox1.Controls.Add(this.panel7);
			this.groupBox1.Controls.Add(this.panel6);
			this.groupBox1.Controls.Add(this.panel5);
			this.groupBox1.Controls.Add(this.panel4);
			this.groupBox1.Controls.Add(this.panel3);
			this.groupBox1.Controls.Add(this.panel2);
			this.groupBox1.Controls.Add(this.panel1);
			this.groupBox1.Controls.Add(this.itemStatusMechAdequate);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveLeaks);
			this.groupBox1.Controls.Add(this.itemStatusMechMotorAmps);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveCorrosion);
			this.groupBox1.Controls.Add(this.itemStatusMechSupportFunctional);
			this.groupBox1.Controls.Add(this.itemStatusMechCanRun);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveNoise);
			this.groupBox1.Controls.Add(this.itemStatusMechExcessiveVibration);
			this.groupBox1.Controls.Add(this.itemStatusMechRunningHot);
			this.groupBox1.Controls.Add(this.itemStatusMechPartsMissing);
			this.groupBox1.Controls.Add(this.itemStatusMechPartsAvailable);
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(10, 38);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(280, 246);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Mechanical";
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel11.Location = new System.Drawing.Point(0, 150);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(280, 1);
			this.panel11.TabIndex = 19;
			this.panel11.Visible = false;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel10.Location = new System.Drawing.Point(0, 133);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(280, 1);
			this.panel10.TabIndex = 18;
			this.panel10.Visible = false;
			// 
			// panel8
			// 
			this.panel8.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel8.Location = new System.Drawing.Point(0, 104);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(280, 1);
			this.panel8.TabIndex = 17;
			this.panel8.Visible = false;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel7.Location = new System.Drawing.Point(0, 87);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(280, 1);
			this.panel7.TabIndex = 16;
			this.panel7.Visible = false;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel6.Location = new System.Drawing.Point(0, 70);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(280, 1);
			this.panel6.TabIndex = 15;
			this.panel6.Visible = false;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel5.Location = new System.Drawing.Point(0, 53);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(280, 1);
			this.panel5.TabIndex = 14;
			this.panel5.Visible = false;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel4.Location = new System.Drawing.Point(0, 36);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(280, 1);
			this.panel4.TabIndex = 13;
			this.panel4.Visible = false;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel3.Location = new System.Drawing.Point(0, 225);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(280, 1);
			this.panel3.TabIndex = 12;
			this.panel3.Visible = false;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel2.Location = new System.Drawing.Point(0, 167);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(280, 1);
			this.panel2.TabIndex = 11;
			this.panel2.Visible = false;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel1.Location = new System.Drawing.Point(0, 196);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(280, 1);
			this.panel1.TabIndex = 6;
			this.panel1.Visible = false;
			// 
			// itemStatusMechAdequate
			// 
			this.itemStatusMechAdequate.Caption = "Adequate for intended service?";
			this.itemStatusMechAdequate.Location = new System.Drawing.Point(8, 197);
			this.itemStatusMechAdequate.Name = "itemStatusMechAdequate";
			this.itemStatusMechAdequate.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechAdequate.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechAdequate.TabIndex = 9;
			// 
			// itemStatusMechExcessiveLeaks
			// 
			this.itemStatusMechExcessiveLeaks.Caption = "Excessive leaks?";
			this.itemStatusMechExcessiveLeaks.Location = new System.Drawing.Point(8, 71);
			this.itemStatusMechExcessiveLeaks.Name = "itemStatusMechExcessiveLeaks";
			this.itemStatusMechExcessiveLeaks.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveLeaks.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechExcessiveLeaks.TabIndex = 3;
			// 
			// itemStatusMechMotorAmps
			// 
			this.itemStatusMechMotorAmps.Caption = "Motor amps within ratings?";
			this.itemStatusMechMotorAmps.Location = new System.Drawing.Point(8, 226);
			this.itemStatusMechMotorAmps.Name = "itemStatusMechMotorAmps";
			this.itemStatusMechMotorAmps.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechMotorAmps.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechMotorAmps.TabIndex = 10;
			// 
			// itemStatusMechExcessiveCorrosion
			// 
			this.itemStatusMechExcessiveCorrosion.BackColor = System.Drawing.Color.White;
			this.itemStatusMechExcessiveCorrosion.Caption = "Excessive corrosion?";
			this.itemStatusMechExcessiveCorrosion.Location = new System.Drawing.Point(8, 54);
			this.itemStatusMechExcessiveCorrosion.Name = "itemStatusMechExcessiveCorrosion";
			this.itemStatusMechExcessiveCorrosion.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveCorrosion.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechExcessiveCorrosion.TabIndex = 2;
			// 
			// itemStatusMechSupportFunctional
			// 
			this.itemStatusMechSupportFunctional.Caption = "Support equipment functional?";
			this.itemStatusMechSupportFunctional.Location = new System.Drawing.Point(8, 134);
			this.itemStatusMechSupportFunctional.Name = "itemStatusMechSupportFunctional";
			this.itemStatusMechSupportFunctional.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechSupportFunctional.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechSupportFunctional.TabIndex = 6;
			// 
			// itemStatusMechCanRun
			// 
			this.itemStatusMechCanRun.Caption = "Capable of running when inspected?";
			this.itemStatusMechCanRun.Location = new System.Drawing.Point(8, 105);
			this.itemStatusMechCanRun.Name = "itemStatusMechCanRun";
			this.itemStatusMechCanRun.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechCanRun.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechCanRun.TabIndex = 5;
			// 
			// itemStatusMechExcessiveNoise
			// 
			this.itemStatusMechExcessiveNoise.Caption = "Excessive noise?";
			this.itemStatusMechExcessiveNoise.Location = new System.Drawing.Point(8, 37);
			this.itemStatusMechExcessiveNoise.Name = "itemStatusMechExcessiveNoise";
			this.itemStatusMechExcessiveNoise.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveNoise.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechExcessiveNoise.TabIndex = 1;
			// 
			// itemStatusMechExcessiveVibration
			// 
			this.itemStatusMechExcessiveVibration.BackColor = System.Drawing.Color.White;
			this.itemStatusMechExcessiveVibration.Caption = "Excessive vibration?";
			this.itemStatusMechExcessiveVibration.Location = new System.Drawing.Point(8, 20);
			this.itemStatusMechExcessiveVibration.Name = "itemStatusMechExcessiveVibration";
			this.itemStatusMechExcessiveVibration.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechExcessiveVibration.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechExcessiveVibration.TabIndex = 0;
			// 
			// itemStatusMechRunningHot
			// 
			this.itemStatusMechRunningHot.BackColor = System.Drawing.Color.White;
			this.itemStatusMechRunningHot.Caption = "Running hot?";
			this.itemStatusMechRunningHot.Location = new System.Drawing.Point(8, 88);
			this.itemStatusMechRunningHot.Name = "itemStatusMechRunningHot";
			this.itemStatusMechRunningHot.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechRunningHot.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechRunningHot.TabIndex = 4;
			// 
			// itemStatusMechPartsMissing
			// 
			this.itemStatusMechPartsMissing.Caption = "Equipment or parts missing?";
			this.itemStatusMechPartsMissing.Location = new System.Drawing.Point(8, 151);
			this.itemStatusMechPartsMissing.Name = "itemStatusMechPartsMissing";
			this.itemStatusMechPartsMissing.Size = new System.Drawing.Size(268, 16);
			this.itemStatusMechPartsMissing.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechPartsMissing.TabIndex = 7;
			// 
			// itemStatusMechPartsAvailable
			// 
			this.itemStatusMechPartsAvailable.Caption = "Parts for maintenance available?";
			this.itemStatusMechPartsAvailable.Location = new System.Drawing.Point(8, 168);
			this.itemStatusMechPartsAvailable.Name = "itemStatusMechPartsAvailable";
			this.itemStatusMechPartsAvailable.Size = new System.Drawing.Size(268, 28);
			this.itemStatusMechPartsAvailable.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMechPartsAvailable.TabIndex = 8;
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(600, 32);
			this.labelTitle.TabIndex = 94;
			this.labelTitle.Text = "  Component Info -  Mechanical / Electrical / Instrumentation / Piping";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(600, 2);
			this.panelSeparator.TabIndex = 96;
			// 
			// panel9
			// 
			this.panel9.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel9.Location = new System.Drawing.Point(0, 295);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(600, 2);
			this.panel9.TabIndex = 98;
			// 
			// ImportDiscInfoMech
			// 
			this.BackColor = System.Drawing.Color.White;
			this.Controls.Add(this.panel9);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "ImportDiscInfoMech";
			this.Size = new System.Drawing.Size(600, 297);
			this.groupBox4.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		public void LoadDataMech(ImportFromTextFileDiscipline discipline)
		{
			this.Location = new Point(0, 0);
			this.Size = new Size(600, 297);
			this.Parent.Size = new Size(605, 372);
			this.Visible = true;

			itemStatusMechExcessiveVibration.Status = discipline.MechExcessiveVibration;
			itemStatusMechExcessiveNoise.Status = discipline.MechExcessiveNoise;
			itemStatusMechExcessiveCorrosion.Status = discipline.MechExcessiveCorrosion;
			itemStatusMechExcessiveLeaks.Status = discipline.MechExcessiveLeaks;
			itemStatusMechRunningHot.Status = discipline.MechRunningHot;
			itemStatusMechCanRun.Status = discipline.MechCanRunWhenInspected;
			itemStatusMechSupportFunctional.Status = discipline.MechSupportIsFunctional;
			itemStatusMechPartsMissing.Status = discipline.MechPartsMissing;
			itemStatusMechPartsAvailable.Status = discipline.MechPartsAvailable;
			itemStatusMechAdequate.Status = discipline.MechAdequate;
			itemStatusMechMotorAmps.Status = discipline.MechMotorAmps;
			itemStatusInstrSystemsFunctional.Status = discipline.InstrIndicationFunctional;
			itemStatusInstrAlarmsFunctional.Status = discipline.InstrAlarmFunctional;
			itemStatusInstrPartsMissing.Status = discipline.InstrPartsMissing;
			itemStatusInstrPartsAvailable.Status = discipline.InstrPartsAvailable;
			itemStatusElecExcessiveCorrosion.Status = discipline.ElecExcessiveCorrosion;
			itemStatusElecCleanContacts.Status = discipline.ElecCleanContacts;
			itemStatusElecPartsAvailable.Status = discipline.ElecPartsAvailable;
			itemStatusPipingExcessiveCorrosion.Status = discipline.PipeExcessiveCorrosion;
			itemStatusPipingExcessiveLeaks.Status = discipline.PipeExcessiveLeaks;
			itemStatusPipingPaintGood.Status = discipline.PipePaintGood;
		}

		public void SaveDataMech(ImportFromTextFileDiscipline discipline)
		{
			discipline.MechExcessiveVibration = itemStatusMechExcessiveVibration.Status;
			discipline.MechExcessiveNoise = itemStatusMechExcessiveNoise.Status;
			discipline.MechExcessiveCorrosion = itemStatusMechExcessiveCorrosion.Status;
			discipline.MechExcessiveLeaks = itemStatusMechExcessiveLeaks.Status;
			discipline.MechRunningHot = itemStatusMechRunningHot.Status;
			discipline.MechCanRunWhenInspected = itemStatusMechCanRun.Status;
			discipline.MechSupportIsFunctional = itemStatusMechSupportFunctional.Status;
			discipline.MechPartsMissing = itemStatusMechPartsMissing.Status;
			discipline.MechPartsAvailable = itemStatusMechPartsAvailable.Status;
			discipline.MechAdequate = itemStatusMechAdequate.Status;
			discipline.MechMotorAmps = itemStatusMechMotorAmps.Status;
			discipline.InstrIndicationFunctional = itemStatusInstrSystemsFunctional.Status;
			discipline.InstrAlarmFunctional = itemStatusInstrAlarmsFunctional.Status;
			discipline.InstrPartsMissing = itemStatusInstrPartsMissing.Status;
			discipline.InstrPartsAvailable = itemStatusInstrPartsAvailable.Status;
			discipline.ElecExcessiveCorrosion = itemStatusElecExcessiveCorrosion.Status;
			discipline.ElecCleanContacts = itemStatusElecCleanContacts.Status;
			discipline.ElecPartsAvailable = itemStatusElecPartsAvailable.Status;
			discipline.PipeExcessiveCorrosion = itemStatusPipingExcessiveCorrosion.Status;
			discipline.PipeExcessiveLeaks = itemStatusPipingExcessiveLeaks.Status;
			discipline.PipePaintGood = itemStatusPipingPaintGood.Status;
		}

		#endregion /***** Methods *****/
	}
}
