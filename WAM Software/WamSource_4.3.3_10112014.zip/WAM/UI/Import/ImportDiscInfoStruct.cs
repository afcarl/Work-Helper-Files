using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportDiscInfoStruct.
	/// </summary>
	public class ImportDiscInfoStruct : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/

		private WAM.UI.ItemStatusControl itemStatusSpallingConcrete;
		private WAM.UI.ItemStatusControl itemStatusExcessiveCorrosionStructure;
		private WAM.UI.ItemStatusControl itemStatusExcessiveCorrosionMembers;
		private WAM.UI.ItemStatusControl itemStatusCorrosionCoatingIntact;
		private WAM.UI.ItemStatusControl itemStatusPaintGoodCondition;
		private WAM.UI.ItemStatusControl itemStatusVisibleDeformities;
		private WAM.UI.ItemStatusControl itemStatusSettingEvident;
		private WAM.UI.ItemStatusControl itemStatusMajorCracks;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.Panel panel1;
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportDiscInfoStruct()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.itemStatusSpallingConcrete = new WAM.UI.ItemStatusControl();
			this.itemStatusExcessiveCorrosionStructure = new WAM.UI.ItemStatusControl();
			this.itemStatusExcessiveCorrosionMembers = new WAM.UI.ItemStatusControl();
			this.itemStatusCorrosionCoatingIntact = new WAM.UI.ItemStatusControl();
			this.itemStatusPaintGoodCondition = new WAM.UI.ItemStatusControl();
			this.itemStatusVisibleDeformities = new WAM.UI.ItemStatusControl();
			this.itemStatusSettingEvident = new WAM.UI.ItemStatusControl();
			this.itemStatusMajorCracks = new WAM.UI.ItemStatusControl();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// itemStatusSpallingConcrete
			// 
			this.itemStatusSpallingConcrete.Caption = "Spalling concrete?";
			this.itemStatusSpallingConcrete.Location = new System.Drawing.Point(8, 43);
			this.itemStatusSpallingConcrete.Name = "itemStatusSpallingConcrete";
			this.itemStatusSpallingConcrete.Size = new System.Drawing.Size(304, 16);
			this.itemStatusSpallingConcrete.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusSpallingConcrete.TabIndex = 0;
			// 
			// itemStatusExcessiveCorrosionStructure
			// 
			this.itemStatusExcessiveCorrosionStructure.Caption = "Excessive corrosion to structure?";
			this.itemStatusExcessiveCorrosionStructure.Location = new System.Drawing.Point(8, 62);
			this.itemStatusExcessiveCorrosionStructure.Name = "itemStatusExcessiveCorrosionStructure";
			this.itemStatusExcessiveCorrosionStructure.Size = new System.Drawing.Size(304, 16);
			this.itemStatusExcessiveCorrosionStructure.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusExcessiveCorrosionStructure.TabIndex = 1;
			// 
			// itemStatusExcessiveCorrosionMembers
			// 
			this.itemStatusExcessiveCorrosionMembers.Caption = "Excessive corrosion to members?";
			this.itemStatusExcessiveCorrosionMembers.Location = new System.Drawing.Point(8, 81);
			this.itemStatusExcessiveCorrosionMembers.Name = "itemStatusExcessiveCorrosionMembers";
			this.itemStatusExcessiveCorrosionMembers.Size = new System.Drawing.Size(304, 16);
			this.itemStatusExcessiveCorrosionMembers.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusExcessiveCorrosionMembers.TabIndex = 2;
			// 
			// itemStatusCorrosionCoatingIntact
			// 
			this.itemStatusCorrosionCoatingIntact.Caption = "Corrosion coating intact and in place?";
			this.itemStatusCorrosionCoatingIntact.Location = new System.Drawing.Point(8, 100);
			this.itemStatusCorrosionCoatingIntact.Name = "itemStatusCorrosionCoatingIntact";
			this.itemStatusCorrosionCoatingIntact.Size = new System.Drawing.Size(304, 16);
			this.itemStatusCorrosionCoatingIntact.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusCorrosionCoatingIntact.TabIndex = 3;
			// 
			// itemStatusPaintGoodCondition
			// 
			this.itemStatusPaintGoodCondition.Caption = "Paint in good condition?";
			this.itemStatusPaintGoodCondition.Location = new System.Drawing.Point(8, 119);
			this.itemStatusPaintGoodCondition.Name = "itemStatusPaintGoodCondition";
			this.itemStatusPaintGoodCondition.Size = new System.Drawing.Size(304, 16);
			this.itemStatusPaintGoodCondition.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusPaintGoodCondition.TabIndex = 4;
			// 
			// itemStatusVisibleDeformities
			// 
			this.itemStatusVisibleDeformities.Caption = "Visible structural deformities?";
			this.itemStatusVisibleDeformities.Location = new System.Drawing.Point(8, 138);
			this.itemStatusVisibleDeformities.Name = "itemStatusVisibleDeformities";
			this.itemStatusVisibleDeformities.Size = new System.Drawing.Size(304, 16);
			this.itemStatusVisibleDeformities.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusVisibleDeformities.TabIndex = 5;
			// 
			// itemStatusSettingEvident
			// 
			this.itemStatusSettingEvident.Caption = "Foundation settling evident?";
			this.itemStatusSettingEvident.Location = new System.Drawing.Point(8, 157);
			this.itemStatusSettingEvident.Name = "itemStatusSettingEvident";
			this.itemStatusSettingEvident.Size = new System.Drawing.Size(304, 16);
			this.itemStatusSettingEvident.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusSettingEvident.TabIndex = 6;
			// 
			// itemStatusMajorCracks
			// 
			this.itemStatusMajorCracks.Caption = "Major cracks?";
			this.itemStatusMajorCracks.Location = new System.Drawing.Point(8, 176);
			this.itemStatusMajorCracks.Name = "itemStatusMajorCracks";
			this.itemStatusMajorCracks.Size = new System.Drawing.Size(304, 16);
			this.itemStatusMajorCracks.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusMajorCracks.TabIndex = 7;
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(352, 32);
			this.labelTitle.TabIndex = 95;
			this.labelTitle.Text = "  Component Info - Structural / Architectural";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(352, 2);
			this.panelSeparator.TabIndex = 96;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 198);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(352, 2);
			this.panel1.TabIndex = 98;
			// 
			// ImportDiscInfoStruct
			// 
			this.BackColor = System.Drawing.Color.White;
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.itemStatusSpallingConcrete);
			this.Controls.Add(this.itemStatusExcessiveCorrosionStructure);
			this.Controls.Add(this.itemStatusExcessiveCorrosionMembers);
			this.Controls.Add(this.itemStatusCorrosionCoatingIntact);
			this.Controls.Add(this.itemStatusPaintGoodCondition);
			this.Controls.Add(this.itemStatusVisibleDeformities);
			this.Controls.Add(this.itemStatusSettingEvident);
			this.Controls.Add(this.itemStatusMajorCracks);
			this.Name = "ImportDiscInfoStruct";
			this.Size = new System.Drawing.Size(352, 200);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		public void LoadDataStruct(ImportFromTextFileDiscipline discipline)
		{
			this.Location = new Point(0, 0);
			this.Size = new Size(352, 200);
			this.Parent.Size = new Size(357, 275);
			this.Visible = true;

			itemStatusSpallingConcrete.Status = discipline.ConcreteSpalling;
			itemStatusExcessiveCorrosionStructure.Status = discipline.StructExcessiveCorrosion;
			itemStatusExcessiveCorrosionMembers.Status = discipline.MembExcessiveCorrosion;
			itemStatusCorrosionCoatingIntact.Status = discipline.CorrosionCoating;
			itemStatusPaintGoodCondition.Status = discipline.PaintGood;
			itemStatusVisibleDeformities.Status = discipline.VisibleDeformities;
			itemStatusSettingEvident.Status = discipline.SettingEvident;
			itemStatusMajorCracks.Status = discipline.MajorCracks;
		}

		public void SaveDataStruct(ImportFromTextFileDiscipline discipline)
		{
			discipline.ConcreteSpalling = itemStatusSpallingConcrete.Status;
			discipline.StructExcessiveCorrosion = itemStatusExcessiveCorrosionStructure.Status;
			discipline.MembExcessiveCorrosion = itemStatusExcessiveCorrosionMembers.Status;
			discipline.CorrosionCoating = itemStatusCorrosionCoatingIntact.Status;
			discipline.PaintGood = itemStatusPaintGoodCondition.Status;
			discipline.VisibleDeformities = itemStatusVisibleDeformities.Status;
			discipline.SettingEvident = itemStatusSettingEvident.Status;
			discipline.MajorCracks = itemStatusMajorCracks.Status;
		}

		#endregion /***** Methods *****/

	}
}
