using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using WAM.Data;
using WAM.Data.Import;

//mam 102309
using System.Data.SqlClient;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromWWAMForm.
	/// </summary>
	public class ImportFromWWAMForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxInfoSet;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.Button buttonImport;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.TextBox textBoxFilePath;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.ProgressBar progressBar;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ImportFromWWAMForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ImportFromWWAMForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxInfoSet = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxFilePath = new System.Windows.Forms.TextBox();
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.buttonImport = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.labelStatus = new System.Windows.Forms.Label();
			this.progressBar = new System.Windows.Forms.ProgressBar();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(312, 40);
			this.label1.TabIndex = 0;
			this.label1.Text = "To import data from Version 1.0,  enter the name of an InfoSet to be created to h" +
				"old the data, and then browse for the database to import.";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(4, 55);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "InfoSet:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxInfoSet
			// 
			this.textBoxInfoSet.Location = new System.Drawing.Point(60, 52);
			this.textBoxInfoSet.MaxLength = 255;
			this.textBoxInfoSet.Name = "textBoxInfoSet";
			this.textBoxInfoSet.Size = new System.Drawing.Size(312, 20);
			this.textBoxInfoSet.TabIndex = 2;
			this.textBoxInfoSet.Text = "";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(12, 83);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 16);
			this.label3.TabIndex = 3;
			this.label3.Text = "Source:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxFilePath
			// 
			this.textBoxFilePath.Location = new System.Drawing.Point(60, 81);
			this.textBoxFilePath.Name = "textBoxFilePath";
			this.textBoxFilePath.ReadOnly = true;
			this.textBoxFilePath.Size = new System.Drawing.Size(240, 20);
			this.textBoxFilePath.TabIndex = 4;
			this.textBoxFilePath.Text = "";
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowse.Location = new System.Drawing.Point(304, 80);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.Size = new System.Drawing.Size(68, 23);
			this.buttonBrowse.TabIndex = 5;
			this.buttonBrowse.Text = "Browse";
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// buttonImport
			// 
			this.buttonImport.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonImport.Location = new System.Drawing.Point(210, 223);
			this.buttonImport.Name = "buttonImport";
			this.buttonImport.TabIndex = 9;
			this.buttonImport.Text = "&Import";
			this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(295, 223);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 10;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// labelStatus
			// 
			this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Location = new System.Drawing.Point(31, 143);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(324, 33);
			this.labelStatus.TabIndex = 8;
			// 
			// progressBar
			// 
			this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.progressBar.Location = new System.Drawing.Point(28, 181);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(328, 23);
			this.progressBar.TabIndex = 7;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Location = new System.Drawing.Point(368, 118);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(2, 94);
			this.panel4.TabIndex = 18;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Location = new System.Drawing.Point(14, 118);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(2, 92);
			this.panel3.TabIndex = 17;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel2.Location = new System.Drawing.Point(14, 118);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(354, 2);
			this.panel2.TabIndex = 16;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(14, 210);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(354, 2);
			this.panel1.TabIndex = 15;
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Location = new System.Drawing.Point(20, 124);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(84, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "Import Status:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(351, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 101;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// ImportFromWWAMForm
			// 
			this.AcceptButton = this.buttonImport;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(382, 252);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.labelStatus);
			this.Controls.Add(this.progressBar);
			this.Controls.Add(this.buttonImport);
			this.Controls.Add(this.buttonBrowse);
			this.Controls.Add(this.textBoxFilePath);
			this.Controls.Add(this.textBoxInfoSet);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "ImportingData.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ImportFromWWAMForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Import WWAM 1.0 Data";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ImportFromWWAMForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ImportFromWWAMForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowForm(Form owner)
		{
			ImportFromWWAMForm form = new ImportFromWWAMForm();

			form.ShowDialog(owner);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			base.OnLoad(e);
		}

		private void buttonBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();

			ofd.Filter = "WWAM data files (*.mdb)|*.mdb|All files (*.*)|*.*" ;
			ofd.CheckFileExists = true;
			ofd.CheckPathExists = true;
			ofd.FileName = "WWAM.mdb";
			ofd.DefaultExt = "mdb";

			if(ofd.ShowDialog() == DialogResult.OK)
				textBoxFilePath.Text = ofd.FileName;
		}

		private void buttonImport_Click(object sender, System.EventArgs e)
		{
			if (textBoxFilePath.Text.Length == 0 || 
				!System.IO.File.Exists(textBoxFilePath.Text))
			{
				MessageBox.Show(this,
					"Please enter a valid file name for the existing database.",
					"Invalid Path", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			else if (textBoxInfoSet.Text.Length == 0)
			{
				MessageBox.Show(this,
					"Please enter a name for the Information Set that will be built for the imported data.",
					"Invalid InfoSet", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			else
			{
				WAM.Data.InfoSet[] infoSets = WAM.Data.InfoSet.LoadAll();

				for (int pos = 0; pos < infoSets.Length; pos++)
				{
					if (string.Compare(infoSets[pos].Name, textBoxInfoSet.Text) == 0)
					{
						MessageBox.Show(this, 
							"An InfoSet already exists with the specified name.",
							"Invalid InfoSet", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						return;
					}
				}
			}

			Drive.Data.OleDb.Jet40DataSource source = 
				new Drive.Data.OleDb.Jet40DataSource(textBoxFilePath.Text);

			//mam 102309
			//System.Data.OleDb.OleDbConnection connection = null;
			SqlConnection connection = null;

			bool			success = true;
			WAM.Data.InfoSet infoSet = new WAM.Data.InfoSet(0);

			//mam
			buttonImport.Enabled = false;
			//</mam>

			buttonCancel.Enabled = false;
			buttonBrowse.Enabled = false;

			try
			{
				//mam 102309
				//connection = new System.Data.OleDb.OleDbConnection(source.ConnectionString);
				connection = new SqlConnection(source.ConnectionString);

				connection.Open();

				// Get the total record counts
				int			recordCount = 0;

				recordCount = WAM.Data.Import.ImportFacility.GetRecordCount(connection);
				recordCount += WAM.Data.Import.ImportTreatmentProcess.GetRecordCount(connection);
				recordCount += WAM.Data.Import.ImportMajorComponent.GetRecordCount(connection);

				if (recordCount == 0)
				{
					MessageBox.Show(this,
						"There are no importable records in the selected database.",
						"Invalid Source", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}

				progressBar.Maximum = recordCount;
				progressBar.Step = 1;

				// Create an infoset for all of the imported facilities
				infoSet.Name = textBoxInfoSet.Text;
				infoSet.Save();

				success = ImportFacilities(infoSet.ID, connection);
				if (!success)
					infoSet.Delete();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
				success = false;
				if (infoSet.ID != 0)
					infoSet.Delete();
			}
			finally
			{
				buttonCancel.Enabled = true;
				buttonImport.Enabled = true;
				buttonBrowse.Enabled = true;
				if (connection != null)
					connection.Dispose();
			}

			if (!success)
			{
				MessageBox.Show(this, "Unable to import from the specified database.", "Import Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			MessageBox.Show(this, "Import complete!", "Import Complete", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		//mam 102309
		//private bool ImportFacilities(int infoSetID, System.Data.OleDb.OleDbConnection importDB)
		private bool ImportFacilities(int infoSetID, SqlConnection importDB)
		{
			WAM.Data.Facility facility;
			WAM.Data.Import.ImportFacility[] importFacilities;
			string			sourcePath;
			string			targetPath;

			importFacilities = WAM.Data.Import.ImportFacility.LoadAll(importDB);
			for (int pos = 0; pos < importFacilities.Length; pos++)
			{
				facility = importFacilities[pos].GetFacility(infoSetID);
				labelStatus.Text = string.Format("Importing facility: {0}", 
					facility.Name);
				Application.DoEvents();
				if (!facility.Save())
					return false;

				// Copy the facility images
				// Image 1
				sourcePath = importFacilities[pos].GetImage1Path();
				targetPath = facility.GetImage1Path();

				if (sourcePath.Length > 0 && System.IO.File.Exists(sourcePath))
					System.IO.File.Copy(sourcePath, targetPath, true);

				// Image 2
				sourcePath = importFacilities[pos].GetImage2Path();
				targetPath = facility.GetImage2Path();

				if (sourcePath.Length > 0 && System.IO.File.Exists(sourcePath))
					System.IO.File.Copy(sourcePath, targetPath, true);

				if (!ImportTreatmentProcesses(facility, importFacilities[pos].ID, importDB))
					return false;

				progressBar.PerformStep();
			}

			return true;
		}

		//mam 102309
		//private bool ImportTreatmentProcesses(Facility newFacility, int importID, 
		//	System.Data.OleDb.OleDbConnection importDB)
		private bool ImportTreatmentProcesses(Facility newFacility, int importID, SqlConnection importDB)
		{
			WAM.Data.TreatmentProcess process;
			WAM.Data.Import.ImportTreatmentProcess[] importProcesses;
			string			sourcePath;
			string			targetPath;

			importProcesses = WAM.Data.Import.ImportTreatmentProcess.LoadAll(importDB, importID);
			for (int pos = 0; pos < importProcesses.Length; pos++)
			{
				process = importProcesses[pos].GetProcess(newFacility.ID);
				process.InfoSetID = newFacility.InfoSetID;
				labelStatus.Text = string.Format("Importing process: {0}", 
					process.Name);
				Application.DoEvents();
				if (!process.Save())
					return false;

				// Copy the process image
				sourcePath = importProcesses[pos].GetImagePath();
				targetPath = process.GetImagePath();

				if (sourcePath.Length > 0 && System.IO.File.Exists(sourcePath))
					System.IO.File.Copy(sourcePath, targetPath, true);

				if (!ImportMajorComponents(process, importProcesses[pos].ID, importDB))
					return false;

				progressBar.PerformStep();
			}

			return true;
		}

		//mam 102309
		//private bool ImportMajorComponents(TreatmentProcess newProcess, int importID, 
		//	System.Data.OleDb.OleDbConnection importDB)
		private bool ImportMajorComponents(TreatmentProcess newProcess, int importID, SqlConnection importDB)
		{
			WAM.Data.MajorComponent component;
			WAM.Data.Import.ImportMajorComponent[] importComponents;
			string			sourcePath;
			string			targetPath;

			importComponents = WAM.Data.Import.ImportMajorComponent.LoadAll(importDB, importID);
			for (int pos = 0; pos < importComponents.Length; pos++)
			{
				component = importComponents[pos].GetComponent(newProcess.ID);
				component.InfoSetID = newProcess.InfoSetID;
				labelStatus.Text = string.Format("Importing component: {0}", 
					component.Name);
				Application.DoEvents();
				if (!component.Save())
					return false;

				// Copy the component image
				sourcePath = importComponents[pos].GetImagePath();
				targetPath = component.GetImagePath();

				if (sourcePath.Length > 0 && System.IO.File.Exists(sourcePath))
					System.IO.File.Copy(sourcePath, targetPath, true);

				if (!ImportDisciplines(component, importComponents[pos].ID, importDB))
					return false;

				if (!ImportAssets(component, importComponents[pos].ID, importDB))
					return false;

				progressBar.PerformStep();
			}

			return true;
		}

		//mam 102309
		//private bool ImportDisciplines(MajorComponent newComponent, int importID, 
		//	System.Data.OleDb.OleDbConnection importDB)
		private bool ImportDisciplines(MajorComponent newComponent, int importID, 
			SqlConnection importDB)
			{
			WAM.Data.Discipline discipline;
			WAM.Data.Import.ImportDiscipline[] importDisciplines;

			importDisciplines = WAM.Data.Import.ImportDisciplineLoader.LoadForComponent(importDB, importID);
			for (int pos = 0; pos < importDisciplines.Length; pos++)
			{
				if (importDisciplines[pos].ID == 0)
					continue;

				discipline = importDisciplines[pos].GetDiscipline(newComponent.ID);
				discipline.InfoSetID = newComponent.InfoSetID;
				if (!discipline.Save())
					return false;

				importDisciplines[pos].CopyImages(discipline);
			}

			return true;
		}

		//mam 102309
		//private bool ImportAssets(MajorComponent newComponent, int importID, 
		//	System.Data.OleDb.OleDbConnection importDB)
		private bool ImportAssets(MajorComponent newComponent, int importID, SqlConnection importDB)
		{
			WAM.Data.ComponentAsset asset;
			WAM.Data.Import.ImportComponentAsset[] importAssets;

			importAssets = WAM.Data.Import.ImportComponentAsset.LoadAll(importDB, importID);
			for (int pos = 0; pos < importAssets.Length; pos++)
			{
				asset = importAssets[pos].GetAsset(newComponent.ID);
				asset.InfoSetID = newComponent.InfoSetID;
				if (!asset.Save())
					return false;
			}

			return true;
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ImportFromWWAMForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingData.htm");
		}

		//mam
		private void ImportFromWWAMForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
		//</mam>
	}
}