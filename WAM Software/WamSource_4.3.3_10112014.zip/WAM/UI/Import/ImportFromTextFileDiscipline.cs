using System;
using WAM.Data;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFileDiscipline.
	/// </summary>
	public class ImportFromTextFileDiscipline
	{
		#region /***** Member Variables *****/

		private int		infoSetID = 0;
		private int		existingID = 0;
		private int		tempID = 0;
		private int		componentID = 0;
		//private int		componentType = 0;
		private short	currentYear = (short)DateTime.Now.Year;
		private bool	importThisItem = false;
		//private bool	retired = false;
		private string	itemName = "New Discipline";
		private string	comments = "";
		private			LevelOfService los = LevelOfService.LOS1;
		private bool	mechStructDisc = true;
		private WAM.UI.NodeType disciplineType = WAM.UI.NodeType.DisciplineMech;

		private decimal	acquisitionCost = 0.0m;
		private decimal	currentValue = 0.0m;
		private bool	overrideCurrentValue = false;
		private decimal	rehabCost = 0.0m;
		private decimal	replacementValue = 0.0m;
		//private int		replacementValueYear = DateTime.Now.Year;
		private int		replacementValueYear = 0;

		//mam 07072011
		private int nextReplacementYear = 0;
		private int rehabCostYear = 0;
		private int rehabYearLast = 0;
		private decimal rehabInterval = 0.0m;

		private decimal	salvageValue = 0.0m;
		private decimal	annualMaintCost = 0.0m;
		private int		installationYear = DateTime.Now.Year;
		private int		originalUsefulLife = 20;
		private CondRank	condition = CondRank.No;
		private decimal	repairCost = 0.0m;

		//mech struct civil
		private DateTime	inspectionDate = DateTime.Now.Date;
		private string		equipmentIDNumber = "";
		private string		assessedBy = "";
		private string		manufacturer = "";
		private decimal		runHours = 0.0m;
		//private string		m_comments = "";
		private bool		runningAtInspection = false;
		//private string		photoCaption = "";
		private bool		parentExists = false;

		//mam 112806
		private string loadedFacName = "";
		private string loadedProcName = "";
		private string loadedCompName = "";

		//mam 03202012
		private string photoFileName = "";
		private string photoCaption = "";

		//mech disclipline 
		private ItemStatus	m_mechExcessiveVibration = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveNoise = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveLeaks = ItemStatus.NotApplicable;
		private ItemStatus	m_mechRunningHot = ItemStatus.NotApplicable;
		private ItemStatus	m_mechCanRunWhenInspected = ItemStatus.NotApplicable;
		private ItemStatus	m_mechSupportIsFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_mechPartsMissing = ItemStatus.NotApplicable;
		private ItemStatus	m_mechPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_mechAdequate = ItemStatus.NotApplicable;
		private ItemStatus	m_mechMotorAmps = ItemStatus.NotApplicable;
		private ItemStatus	m_instrIndicationFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_instrAlarmFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_instrPartsMissing = ItemStatus.NotApplicable;
		private ItemStatus	m_instrPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_instrSpareCapacity = ItemStatus.NotApplicable;
		private ItemStatus	m_elecExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_elecCleanContacts = ItemStatus.NotApplicable;
		private ItemStatus	m_elecPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_elecSpareCapacity = ItemStatus.NotApplicable;
		private ItemStatus	m_pipeExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_pipeExcessiveLeaks = ItemStatus.NotApplicable;
		private ItemStatus	m_pipePaintGood = ItemStatus.NotApplicable;

		//land discipline
		private ItemStatus m_severalPotholes = ItemStatus.NotApplicable;
		private ItemStatus m_excessiveErosion = ItemStatus.NotApplicable;
		private ItemStatus m_roadDegradation = ItemStatus.NotApplicable;
		private ItemStatus m_expansionSpace = ItemStatus.NotApplicable;
		private ItemStatus m_functionCover = ItemStatus.NotApplicable;
		private ItemStatus m_fencingAdequate = ItemStatus.NotApplicable;
		private ItemStatus m_facilitiesSecure = ItemStatus.NotApplicable;
		private ItemStatus m_landAppClayLiner = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBermErosionInterior = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBermErosionBermExterior = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBermVegetation = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBermSettlement = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBermSeepage = ItemStatus.NotApplicable;
		private ItemStatus m_landAppBurrowHoles = ItemStatus.NotApplicable;
		private ItemStatus m_landAppErosionProtectionPresent = ItemStatus.NotApplicable;
		private ItemStatus m_landAppErosionProtectionAdequate = ItemStatus.NotApplicable;
		private ItemStatus m_landAppAlgalBlooms = ItemStatus.NotApplicable;
		private ItemStatus m_landAppDrainageAdequate = ItemStatus.NotApplicable;

		//struct discipline
		private ItemStatus m_concSpalling = ItemStatus.NotApplicable;
		private ItemStatus m_structExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus m_membExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus m_corrosionCoating = ItemStatus.NotApplicable;
		private ItemStatus m_paintGood = ItemStatus.NotApplicable;
		private ItemStatus m_visibleDeformities = ItemStatus.NotApplicable;
		private ItemStatus m_settingEvident = ItemStatus.NotApplicable;
		private ItemStatus m_roofExcessiveDegradation = ItemStatus.NotApplicable;
		private ItemStatus m_majorCracks = ItemStatus.NotApplicable;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportFromTextFileDiscipline()
		{
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Properties *****/

		public int InfoSetID
		{
			get { return infoSetID; }
			set { infoSetID = value; }
		}

		public int ExistingID
		{
			get { return existingID; }
			set { existingID = value; }
		}

		public int TempID
		{
			get { return tempID; }
			set { tempID = value; }
		}

		public int ComponentID
		{
			get { return componentID; }
			set { componentID = value; }
		}

		//public int ComponentType
		//{
		//	get { return componentType; }
		//	set { componentType = value; }
		//}

		public string ItemName
		{
			get { return itemName; }
			set
			{
				if (value.Length > 255)
				{
					itemName = value.Substring(255);
				}
				else
				{
					itemName = value;
				}
			}
		}

//		public short CurrentYear
//		{
//			get { return currentYear; }
//			set { currentYear = value; }
//		}

		public string		Comments
		{
			get { return comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
				{
					comments = value.Substring(Int16.MaxValue);
				}
				else
				{
					comments = value;
				}
			}
		}

		public bool ImportThisItem
		{
			get { return importThisItem; }
			set { importThisItem = value; }
		}

		//public bool Retired
		//{
		//	get { return retired; }
		//	set { retired = value; }
		//}

		public LevelOfService LOS
		{
			get
			{ 
				//if (MechStructDisciplines)
				{
					return los;
				}
			}
			set
			{
				if (MechStructDisciplines)
				{
					los = value;
				}
			}
		}

//		public CriticalityPublicHealth CritPublic
//		{
//			get { return critPublic; }
//			set { critPublic = value; }
//		}
//
//		public CriticalityEnvironmental CritEnvironment
//		{
//			get { return critEnvironment; }
//			set { critEnvironment = value; }
//		}
//
//		public CriticalityRepairCost CritRepair
//		{
//			get { return critRepair; }
//			set { critRepair = value; }
//		}
//
//		public CriticalityCustomerEffect CritEffect
//		{
//			get { return critEffect; }
//			set { critEffect = value; }
//		}

//		public double Vulnerability
//		{
//			get
//			{
//				//if (MechStructDisciplines)
//				{
//					return vulnerability;
//				}
//			}
//			set
//			{
//				if (MechStructDisciplines)
//				{
//					vulnerability = value;
//				}
//			}
//		}

		public bool MechStructDisciplines
		{
			get { return mechStructDisc; }
			set { mechStructDisc = value; }
		}

		public bool OverrideCurrentValue
		{
			get { return overrideCurrentValue; }
			set { overrideCurrentValue = value; }
		}

		public decimal AcquisitionCost
		{
			get { return acquisitionCost; }
			set { acquisitionCost = value; }
		}

		public decimal ReplacementValue
		{
			get { return replacementValue; }
			set { replacementValue = value; }
		}

		public int ReplacementValueYear
		{
			get { return replacementValueYear; }
			set { replacementValueYear = value; }
		}

		//mam 07072011
		public int NextReplacementYear
		{
			get { return nextReplacementYear; }
			set { nextReplacementYear = value; }
		}

		public decimal SalvageValue
		{
			get { return salvageValue; }
			set { salvageValue = value; }
		}

		public decimal AnnualMaintCost
		{
			get { return annualMaintCost; }
			set { annualMaintCost = value; }
		}

		public int InstallationYear
		{
			get { return installationYear; }
			set { installationYear = value; }
		}

		public int OriginalUsefulLife
		{
			get { return originalUsefulLife; }
			set { originalUsefulLife = value; }
		}

		public CondRank Condition
		{
			get { return condition; }
			set { condition = value; }
		}
		public DateTime InspectionDate
		{
			get { return inspectionDate; }
			set { inspectionDate = value; }
		}

		public string EquipmentIDNumber
		{
			get { return equipmentIDNumber; }
			set { equipmentIDNumber = value; }
		}

		public string Manufacturer
		{
			get { return manufacturer; }
			set { manufacturer = value; }
		}

		public decimal RunHours
		{
			get { return runHours; }
			set { runHours = value; }
		}

		public bool RunningAtInspection
		{
			get { return runningAtInspection; }
			set { runningAtInspection = value; }
		}

		public decimal CurrentValue
		{
			get { return currentValue; }
			set { currentValue = value; }
		}

		public decimal RehabCost
		{
			get { return rehabCost; }
			set { rehabCost = value; }
		}

		//mam 07072011
		public int RehabCostYear
		{
			get { return rehabCostYear; }
			set { rehabCostYear = value; }
		}

		//mam 07072011
		public decimal RehabInterval
		{
			get { return rehabInterval; }
			set { rehabInterval = value; }
		}

		//mam 07072011
		public int RehabYearLast
		{
			get { return rehabYearLast; }
			set { rehabYearLast = value; }
		}

		public decimal RepairCost
		{
			get { return repairCost; }
			set { repairCost = value; }
		}

		public string AssessedBy
		{
			get { return assessedBy; }
			set { assessedBy = value; }
		}

		public WAM.UI.NodeType DisciplineType
		{
			get { return disciplineType; }
			set { disciplineType = value; }
		}

		public bool ParentExists
		{
			get { return parentExists; }
			set { parentExists = value; }
		}

		//mam 112806
		public string LoadedFacName
		{
			get { return loadedFacName; }
			set { loadedFacName = value; }
		}
		public string LoadedProcName
		{
			get { return loadedProcName; }
			set { loadedProcName = value; }
		}
		public string LoadedCompName
		{
			get { return loadedCompName; }
			set { loadedCompName = value; }
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return photoFileName; }
			set
			{
				if (value.Length > 255)
				{
					photoFileName = value.Substring(255);
				}
				else
				{
					photoFileName = value;
				}
			}
		}

		//mam 03202012
		public string PhotoCaption
		{
			get { return photoCaption; }
			set
			{
				if (value.Length > 255)
				{
					photoCaption = value.Substring(255);
				}
				else
				{
					photoCaption = value;
				}
			}
		}

		#endregion /***** Properties *****/

		#region /***** Properties Mech *****/

		public ItemStatus	MechExcessiveVibration
		{
			get { return m_mechExcessiveVibration; }
			set { m_mechExcessiveVibration = value; }
		}

		public ItemStatus	MechExcessiveNoise
		{
			get { return m_mechExcessiveNoise; }
			set { m_mechExcessiveNoise = value; }
		}

		public ItemStatus	MechExcessiveCorrosion
		{
			get { return m_mechExcessiveCorrosion; }
			set { m_mechExcessiveCorrosion = value; }
		}

		public ItemStatus	MechExcessiveLeaks
		{
			get { return m_mechExcessiveLeaks; }
			set { m_mechExcessiveLeaks = value; }
		}

		public ItemStatus	MechRunningHot
		{
			get { return m_mechRunningHot; }
			set { m_mechRunningHot = value; }
		}

		public ItemStatus	MechCanRunWhenInspected
		{
			get { return m_mechCanRunWhenInspected; }
			set { m_mechCanRunWhenInspected = value; }
		}

		public ItemStatus	MechSupportIsFunctional
		{
			get { return m_mechSupportIsFunctional; }
			set { m_mechSupportIsFunctional = value; }
		}

		public ItemStatus	MechPartsMissing
		{
			get { return m_mechPartsMissing; }
			set { m_mechPartsMissing = value; }
		}

		public ItemStatus	MechPartsAvailable
		{
			get { return m_mechPartsAvailable; }
			set { m_mechPartsAvailable = value; }
		}

		public ItemStatus	MechAdequate
		{
			get { return m_mechAdequate; }
			set { m_mechAdequate = value; }
		}

		public ItemStatus	MechMotorAmps
		{
			get { return m_mechMotorAmps; }
			set { m_mechMotorAmps = value; }
		}

		public ItemStatus	InstrIndicationFunctional
		{
			get { return m_instrIndicationFunctional; }
			set { m_instrIndicationFunctional = value; }
		}

		public ItemStatus	InstrAlarmFunctional
		{
			get { return m_instrAlarmFunctional; }
			set { m_instrAlarmFunctional = value; }
		}

		public ItemStatus	InstrPartsMissing
		{
			get { return m_instrPartsMissing; }
			set { m_instrPartsMissing = value; }
		}

		public ItemStatus	InstrPartsAvailable
		{
			get { return m_instrPartsAvailable; }
			set { m_instrPartsAvailable = value; }
		}

		public ItemStatus	InstrSpareCapacity
		{
			get { return m_instrSpareCapacity; }
			set { m_instrSpareCapacity = value; }
		}

		public ItemStatus	ElecExcessiveCorrosion
		{
			get { return m_elecExcessiveCorrosion; }
			set { m_elecExcessiveCorrosion = value; }
		}

		public ItemStatus	ElecCleanContacts
		{
			get { return m_elecCleanContacts; }
			set { m_elecCleanContacts = value; }
		}

		public ItemStatus	ElecPartsAvailable
		{
			get { return m_elecPartsAvailable; }
			set { m_elecPartsAvailable = value; }
		}

		public ItemStatus	ElecSpareCapacity
		{
			get { return m_elecSpareCapacity; }
			set { m_elecSpareCapacity = value; }
		}

		public ItemStatus	PipeExcessiveCorrosion
		{
			get { return m_pipeExcessiveCorrosion; }
			set { m_pipeExcessiveCorrosion = value; }
		}

		public ItemStatus	PipeExcessiveLeaks
		{
			get { return m_pipeExcessiveLeaks; }
			set { m_pipeExcessiveLeaks = value; }
		}

		public ItemStatus	PipePaintGood
		{
			get { return m_pipePaintGood; }
			set { m_pipePaintGood = value; }
		}

		#endregion /***** Properties Mech *****/

		#region /***** Properties Land *****/

		public ItemStatus	SeveralPotholes
		{
			get { return m_severalPotholes; }
			set { m_severalPotholes = value; }
		}

		public ItemStatus	ExcessiveErosion
		{
			get { return m_excessiveErosion; }
			set { m_excessiveErosion = value; }
		}

		public ItemStatus	RoadDegradation
		{
			get { return m_roadDegradation; }
			set { m_roadDegradation = value; }
		}

		public ItemStatus	ExpansionSpace
		{
			get { return m_expansionSpace; }
			set { m_expansionSpace = value; }
		}

		public ItemStatus	FunctionCover
		{
			get { return m_functionCover; }
			set { m_functionCover = value; }
		}

		public ItemStatus	FencingAdequate
		{
			get { return m_fencingAdequate; }
			set { m_fencingAdequate = value; }
		}

		public ItemStatus	FacilitiesSecure
		{
			get { return m_facilitiesSecure; }
			set { m_facilitiesSecure = value; }
		}

		public ItemStatus LandAppClayLiner
		{
			get { return m_landAppClayLiner; }
			set { m_landAppClayLiner = value; }
		}
		public ItemStatus LandAppBermErosionInterior
		{
			get { return m_landAppBermErosionInterior; }
			set { m_landAppBermErosionInterior = value; }
		}
		public ItemStatus LandAppBermErosionBermExterior
		{
			get { return m_landAppBermErosionBermExterior; }
			set { m_landAppBermErosionBermExterior = value; }
		}
		public ItemStatus LandAppBermVegetation
		{
			get { return m_landAppBermVegetation; }
			set { m_landAppBermVegetation = value; }
		}
		public ItemStatus LandAppBermSettlement
		{
			get { return m_landAppBermSettlement; }
			set { m_landAppBermSettlement = value; }
		}
		public ItemStatus LandAppBermSeepage
		{
			get { return m_landAppBermSeepage; }
			set { m_landAppBermSeepage = value; }
		}
		public ItemStatus LandAppBurrowHoles
		{
			get { return m_landAppBurrowHoles; }
			set { m_landAppBurrowHoles = value; }
		}
		public ItemStatus LandAppErosionProtectionPresent
		{
			get { return m_landAppErosionProtectionPresent; }
			set { m_landAppErosionProtectionPresent = value; }
		}
		public ItemStatus LandAppErosionProtectionAdequate
		{
			get { return m_landAppErosionProtectionAdequate; }
			set { m_landAppErosionProtectionAdequate = value; }
		}
		public ItemStatus LandAppAlgalBlooms
		{
			get { return m_landAppAlgalBlooms; }
			set { m_landAppAlgalBlooms = value; }
		}
		public ItemStatus LandAppDrainageAdequate
		{
			get { return m_landAppDrainageAdequate; }
			set { m_landAppDrainageAdequate = value; }
		}

		#endregion /***** Properties Land *****/

		#region /***** Properties Struct *****/

		public ItemStatus	ConcreteSpalling
		{
			get { return m_concSpalling; }
			set { m_concSpalling = value; }
		}

		public ItemStatus	StructExcessiveCorrosion
		{
			get { return m_structExcessiveCorrosion; }
			set { m_structExcessiveCorrosion = value; }
		}

		public ItemStatus	MembExcessiveCorrosion
		{
			get { return m_membExcessiveCorrosion; }
			set { m_membExcessiveCorrosion = value; }
		}

		public ItemStatus	CorrosionCoating
		{
			get { return m_corrosionCoating; }
			set { m_corrosionCoating = value; }
		}

		public ItemStatus	PaintGood
		{
			get { return m_paintGood; }
			set { m_paintGood = value; }
		}

		public ItemStatus	VisibleDeformities
		{
			get { return m_visibleDeformities; }
			set { m_visibleDeformities = value; }
		}

		public ItemStatus	SettingEvident
		{
			get { return m_settingEvident; }
			set { m_settingEvident = value; }
		}

		public ItemStatus	RoofExcessiveDegradation
		{
			get { return m_roofExcessiveDegradation; }
			set { m_roofExcessiveDegradation = value; }
		}

		public ItemStatus	MajorCracks
		{
			get { return m_majorCracks; }
			set { m_majorCracks = value; }
		}

		#endregion /***** Properties Struct *****/

		#region /***** Methods *****/

		public override string ToString()
		{
			return this.itemName;
		}

		public void CopyDisciplineMech(ImportFromTextFileDiscipline copyTo)
		{
			copyTo.MechExcessiveVibration = this.MechExcessiveVibration;
			copyTo.MechExcessiveNoise = this.MechExcessiveNoise;
			copyTo.MechExcessiveCorrosion = this.MechExcessiveCorrosion;
			copyTo.MechExcessiveLeaks = this.MechExcessiveLeaks;
			copyTo.MechRunningHot = this.MechRunningHot;
			copyTo.MechCanRunWhenInspected = this.MechCanRunWhenInspected;
			copyTo.MechSupportIsFunctional = this.MechSupportIsFunctional;
			copyTo.MechPartsMissing = this.MechPartsMissing;
			copyTo.MechPartsAvailable = this.MechPartsAvailable;
			copyTo.MechAdequate = this.MechAdequate;
			copyTo.MechMotorAmps = this.MechMotorAmps;
			copyTo.InstrIndicationFunctional = this.InstrIndicationFunctional;
			copyTo.InstrAlarmFunctional = this.InstrAlarmFunctional;
			copyTo.InstrPartsMissing = this.InstrPartsMissing;
			copyTo.InstrPartsAvailable = this.InstrPartsAvailable;
			copyTo.ElecExcessiveCorrosion = this.ElecExcessiveCorrosion;
			copyTo.ElecCleanContacts = this.ElecCleanContacts;
			copyTo.ElecPartsAvailable = this.ElecPartsAvailable;
			copyTo.PipeExcessiveCorrosion = this.PipeExcessiveCorrosion;
			copyTo.PipeExcessiveLeaks = this.PipeExcessiveLeaks;
			copyTo.PipePaintGood = this.PipePaintGood;
		}

		public void CopyDisciplineStruct(ImportFromTextFileDiscipline copyTo)
		{
			copyTo.ConcreteSpalling = this.ConcreteSpalling;
			copyTo.StructExcessiveCorrosion = this.StructExcessiveCorrosion;
			copyTo.MembExcessiveCorrosion = this.MembExcessiveCorrosion;
			copyTo.CorrosionCoating = this.CorrosionCoating;
			copyTo.PaintGood = this.PaintGood;
			copyTo.VisibleDeformities = this.VisibleDeformities;
			copyTo.SettingEvident = this.SettingEvident;
			copyTo.MajorCracks = this.MajorCracks;
		}

		public void CopyDisciplineLand(ImportFromTextFileDiscipline copyTo)
		{
			copyTo.SeveralPotholes = this.SeveralPotholes;
			copyTo.ExcessiveErosion = this.ExcessiveErosion;
			copyTo.RoadDegradation = this.RoadDegradation;
			copyTo.ExpansionSpace = this.ExpansionSpace;
			copyTo.FunctionCover = this.FunctionCover;
			copyTo.FencingAdequate = this.FencingAdequate;
			copyTo.FacilitiesSecure = this.FacilitiesSecure;
			copyTo.LandAppClayLiner = this.LandAppClayLiner;
			copyTo.LandAppBermErosionInterior = this.LandAppBermErosionInterior;
			copyTo.LandAppBermErosionBermExterior = this.LandAppBermErosionBermExterior;
			copyTo.LandAppBermVegetation = this.LandAppBermVegetation;
			copyTo.LandAppBermSettlement = this.LandAppBermSettlement;
			copyTo.LandAppBermSeepage = this.LandAppBermSeepage;
			copyTo.LandAppBurrowHoles = this.LandAppBurrowHoles;
			copyTo.LandAppErosionProtectionPresent = this.LandAppErosionProtectionPresent;
			copyTo.LandAppErosionProtectionAdequate = this.LandAppErosionProtectionAdequate;
			copyTo.LandAppAlgalBlooms = this.LandAppAlgalBlooms;
			copyTo.LandAppDrainageAdequate = this.LandAppDrainageAdequate;
		}

		#endregion /***** Methods *****/

	}
}
