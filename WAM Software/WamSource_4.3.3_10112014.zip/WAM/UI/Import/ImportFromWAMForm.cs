using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;

//mam 102309 - leave it
using System.Data.OleDb;

using System.Text;
using System.Windows.Forms;
using Drive.Data.OleDb;
using WAM.Data;

//mam 102309
using System.Data.SqlClient;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromWAMForm.
	/// </summary>
	public class ImportFromWAMForm : System.Windows.Forms.Form
	{
		//mam 102309
		//private InfoSet[]	m_importInfoSets = null;
		private InfoSetOriginal[]	m_importInfoSets = null;

		private string		m_currentInfoSet = "";
		private string		m_currentFacility = "";
		private string		m_currentProcess = "";
		private string		m_currentComponent = "";

		//mam
		ArrayList arrayListCustomerENRListIDs1 = new ArrayList();
		ArrayList arrayListCustomerENRListIDs2 = new ArrayList();
		bool copyPhoto = false;
		private short m_importFacilityCurrentYear = 0;
		private string loadDatabaseFileNameWithPath = "";
		string sourceInfoSetImagePath = "";
		string newInfoSetImagePath = "";
		//</mam>

		//mam 102309
		private string photoPath = "";

		private StringBuilder m_statusBuilder = new StringBuilder();
		private System.Windows.Forms.Button buttonImport;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.TextBox textBoxFilePath;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button buttonBrowsePhotos;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBoxPhotoPath;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ImportFromWAMForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ImportFromWAMForm));
			this.buttonImport = new System.Windows.Forms.Button();
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.textBoxFilePath = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.labelStatus = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.buttonBrowsePhotos = new System.Windows.Forms.Button();
			this.textBoxPhotoPath = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// buttonImport
			// 
			this.buttonImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonImport.Enabled = false;
			this.buttonImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonImport.Location = new System.Drawing.Point(295, 230);
			this.buttonImport.Name = "buttonImport";
			this.buttonImport.TabIndex = 6;
			this.buttonImport.Text = "&Import";
			this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowse.Location = new System.Drawing.Point(387, 44);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.Size = new System.Drawing.Size(68, 23);
			this.buttonBrowse.TabIndex = 3;
			this.buttonBrowse.Text = "Browse";
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// textBoxFilePath
			// 
			this.textBoxFilePath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxFilePath.Location = new System.Drawing.Point(87, 45);
			this.textBoxFilePath.Name = "textBoxFilePath";
			this.textBoxFilePath.ReadOnly = true;
			this.textBoxFilePath.Size = new System.Drawing.Size(295, 20);
			this.textBoxFilePath.TabIndex = 2;
			this.textBoxFilePath.TabStop = false;
			this.textBoxFilePath.Text = "";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(12, 47);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 16);
			this.label3.TabIndex = 1;
			this.label3.Text = "Database:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(380, 230);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 7;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// checkBox1
			// 
			this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBox1.Location = new System.Drawing.Point(16, 200);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(240, 44);
			this.checkBox1.TabIndex = 4;
			this.checkBox1.Text = "Check if you would you like to import the photos (takes longer, and may not be ne" +
				"cessary)";
			this.checkBox1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.checkBox1.Visible = false;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(416, 32);
			this.label1.TabIndex = 0;
			this.label1.Text = "Browse for a WAM database and photo folder, and click the Import button to select" +
				" the InfoSets to import.";
			// 
			// labelStatus
			// 
			this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Location = new System.Drawing.Point(20, 150);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(424, 60);
			this.labelStatus.TabIndex = 8;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(14, 126);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 16);
			this.label2.TabIndex = 9;
			this.label2.Text = "Import Status:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(8, 212);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(445, 2);
			this.panel1.TabIndex = 10;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel2.Location = new System.Drawing.Point(8, 120);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(445, 2);
			this.panel2.TabIndex = 11;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel3.Location = new System.Drawing.Point(8, 120);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(2, 92);
			this.panel3.TabIndex = 12;
			// 
			// panel4
			// 
			this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Location = new System.Drawing.Point(453, 120);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(2, 94);
			this.panel4.TabIndex = 13;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(433, 9);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 100;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// buttonBrowsePhotos
			// 
			this.buttonBrowsePhotos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonBrowsePhotos.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowsePhotos.Location = new System.Drawing.Point(387, 70);
			this.buttonBrowsePhotos.Name = "buttonBrowsePhotos";
			this.buttonBrowsePhotos.Size = new System.Drawing.Size(68, 23);
			this.buttonBrowsePhotos.TabIndex = 103;
			this.buttonBrowsePhotos.Text = "Browse";
			this.buttonBrowsePhotos.Click += new System.EventHandler(this.buttonBrowsePhotos_Click);
			// 
			// textBoxPhotoPath
			// 
			this.textBoxPhotoPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoPath.Location = new System.Drawing.Point(87, 71);
			this.textBoxPhotoPath.Name = "textBoxPhotoPath";
			this.textBoxPhotoPath.ReadOnly = true;
			this.textBoxPhotoPath.Size = new System.Drawing.Size(295, 20);
			this.textBoxPhotoPath.TabIndex = 102;
			this.textBoxPhotoPath.TabStop = false;
			this.textBoxPhotoPath.Text = "";
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Location = new System.Drawing.Point(12, 73);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 16);
			this.label4.TabIndex = 101;
			this.label4.Text = "Photo Folder:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Location = new System.Drawing.Point(87, 91);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(280, 16);
			this.label5.TabIndex = 104;
			this.label5.Text = "(Leave Photo Folder blank if not importing photos)";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ImportFromWAMForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(462, 260);
			this.Controls.Add(this.buttonBrowsePhotos);
			this.Controls.Add(this.textBoxPhotoPath);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.labelStatus);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.checkBox1);
			this.Controls.Add(this.buttonImport);
			this.Controls.Add(this.buttonBrowse);
			this.Controls.Add(this.textBoxFilePath);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.label5);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "ImportingData.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ImportFromWAMForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Import From WAM 2.0, 2.1 or 3.0 Database";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ImportFromWAMForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ImportFromWAMForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowForm(Form owner)
		{
			ImportFromWAMForm form = new ImportFromWAMForm();

			form.ShowDialog(owner);
		}

		private void buttonBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog fileDialog = new OpenFileDialog();
			fileDialog.InitialDirectory = Application.StartupPath;
			fileDialog.Filter = "WAM database files (*.mdb)|*.mdb|All files (*.*)|*.*" ;
			fileDialog.CheckFileExists = true;
			fileDialog.CheckPathExists = true;
			fileDialog.DefaultExt = "mdb";

			//mam 102309
			//fileDialog.FileName = "WAM.mdb";
			if (loadDatabaseFileNameWithPath != "")
			{
				fileDialog.InitialDirectory = Drive.IO.Directory.GetFilePath(loadDatabaseFileNameWithPath);
			}
			else
			{
				fileDialog.InitialDirectory = Application.StartupPath;
			}
			fileDialog.Multiselect = false;
			//fileDialog.RestoreDirectory = true;
			
			//mam
			textBoxFilePath.Text = "";
			buttonImport.Enabled = false;
			//</mam>

			if (fileDialog.ShowDialog() == DialogResult.OK)
			{
				//mam - save database name
				loadDatabaseFileNameWithPath = fileDialog.FileName;
				//</mam>

				if (!VerifyAndUpdateDatabase())
					return;

				textBoxFilePath.Text = loadDatabaseFileNameWithPath;
				buttonImport.Enabled = true;
			}
		}

		private void buttonBrowsePhotos_Click(object sender, System.EventArgs e)
		{
			FolderBrowserDialog folderDialog = new FolderBrowserDialog();
			folderDialog.ShowNewFolderButton = false;

			if (loadDatabaseFileNameWithPath != "")
			{
				folderDialog.SelectedPath = Drive.IO.Directory.GetFilePath(loadDatabaseFileNameWithPath);
			}
			else
			{
				folderDialog.SelectedPath = Application.StartupPath;
			}

			if (folderDialog.ShowDialog(this) == DialogResult.OK)
			{
				photoPath = folderDialog.SelectedPath;
				this.textBoxPhotoPath.Text = photoPath;
			}
		}

		//mam - new method
		private bool VerifyAndUpdateDatabase()
		{
			// Retrieve a list of the InfoSets in the database
			Jet40DataSource dataSource = new Jet40DataSource(loadDatabaseFileNameWithPath);
			dataSource.Provider = WAM.Data.WamSourceOleDb.CheckSourceConnection(dataSource.ConnectionString, dataSource.Provider);

			Drive.Configuration.AppSettings.Settings.SetSetting("DBConnection", "LastSource", loadDatabaseFileNameWithPath);
			Drive.Configuration.AppSettings.Settings.Save();

			//check that the database is a WAM database so that it can be updated before data is imported
			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();
			if (!verify.VerifyTableNamesAndFields(loadDatabaseFileNameWithPath))
			{
				MessageBox.Show(this, "The database is not a WAM Version 2 or 3 database.", "Import", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			try
			{
				WAM.Common.Update4 update4 = new WAM.Common.Update4(loadDatabaseFileNameWithPath);
				bool resultUpdate4 = update4.PerformUpdate();
				update4 = null;
			}
			catch
			{
			}

			//mam - perform database updates on database to be imported from
			bool resultUpdate = false;
			WAM.Common.Update1 update1 = new WAM.Common.Update1(dataSource.ConnectionString);
			resultUpdate = update1.PerformUpdate();
			update1 = null;
			if (!resultUpdate)
			{
				MessageBox.Show(this, "There has been an error reading the database.", "Import", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			resultUpdate = false;
			WAM.Common.Update2 update2 = new WAM.Common.Update2(dataSource.ConnectionString);
			resultUpdate = update2.PerformUpdate();
			update2 = null;
			if (!resultUpdate)
			{
				MessageBox.Show(this, "There has been an error reading the database.", "Import", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			resultUpdate = false;
			WAM.Common.Update3 update3 = new WAM.Common.Update3(dataSource.ConnectionString);
			resultUpdate = update3.PerformUpdate();
			update3 = null;
			if (!resultUpdate)
			{
				MessageBox.Show(this, "There has been an error reading the database.", "Import", 
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			return true;
		}
		//</mam>

		private bool SelectInfosets()
		{
			//mam 102309
			Drive.Configuration.AppSettings.Settings.SetSetting("DBConnection", "LastSource", loadDatabaseFileNameWithPath);
			Drive.Configuration.AppSettings.Settings.Save();

			WamSourceOleDb.CurrentSource = new Jet40DataSource(loadDatabaseFileNameWithPath);

			// Retrieve a list of the InfoSets in the database
			Jet40DataSource dataSource = new Jet40DataSource(loadDatabaseFileNameWithPath);

			//mam - add password to dataSource, if necessary
			dataSource.Provider = WAM.Data.WamSourceOleDb.CheckSourceConnection(dataSource.ConnectionString, dataSource.Provider);
			//</mam>

			InfoSetOriginal[]	infoSets = null;

			m_importInfoSets = null;

			//mam - comment
			//textBoxFilePath.Text = "";

			//mam - do this in the import button click event
			// Make sure that the import button is disabled
			//buttonImport.Enabled = false;

			try
			{
				infoSets = InfoSetOriginal.LoadAll(dataSource.ConnectionString);
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);

				//mam 102309
				//infoSets = new InfoSet[0];
				infoSets = new InfoSetOriginal[0];
			}

			if (infoSets == null)
			{
				//MessageBox.Show(this, "An error has occurred.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			if (infoSets.Length == 1)
			{
				// Import the only infoset in the specified database
				textBoxFilePath.Text = loadDatabaseFileNameWithPath;
				m_importInfoSets = infoSets;
				buttonImport.Enabled = true;
			}
			else if (infoSets.Length > 0)
			{
				// Allow the user to select which infosets they would like 
				// to import.
				m_importInfoSets = SelectImportInfoSetsForm.ShowForm(infoSets, this);
				if (m_importInfoSets.Length > 0)
				{
					textBoxFilePath.Text = loadDatabaseFileNameWithPath;
					buttonImport.Enabled = true;
				}
				else
				{
					m_importInfoSets = null;

					//mam
					//buttonImport.Enabled = false;
					return false;
					//</mam>
				}
			}
			else
			{
				MessageBox.Show(this,
					"No InfoSets were found in the specified file.  Make sure that the file is not read-only, and is a WAM 2.0 database.",
					"Invalid Import File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

				//mam
				return false;
				//</mam>
			}

			return true;
		}

		private void buttonImport_Click(object sender, System.EventArgs e)
		{
			if (!SelectInfosets())
				return;

			if (m_importInfoSets == null)
				return;

			Jet40DataSource dataSource = new Jet40DataSource(textBoxFilePath.Text);
			//mam - add password to dataSource, if necessary
			dataSource.Provider = WAM.Data.WamSourceOleDb.CheckSourceConnection(dataSource.ConnectionString, dataSource.Provider);
			//</mam>

			//mam 102309 - leave it
			OleDbConnection connection = null;
			//SqlConnection connection = null;

			//mam 102309
			InfoSet			newSet;
			//InfoSet			orgSet;
			//InfoSetOriginal			newSet;
			InfoSetOriginal			orgSet;

			MainForm.currentlyImporting = true;
			buttonCancel.Enabled = false;
			buttonImport.Enabled = false;
			buttonBrowse.Enabled = false;

			//mam 102309
			buttonBrowsePhotos.Enabled = false;

			try
			{
				//mam
				copyPhoto = true;
				//</mam>

				connection = new OleDbConnection(dataSource.ConnectionString);
				connection.Open();

				// Import the info set
				for (int setPos = 0; setPos < m_importInfoSets.Length; setPos++)
				{
					orgSet = m_importInfoSets[setPos];

					//mam 102309
					newSet = new InfoSet(0);
					//newSet = new InfoSetOriginal(0);

					newSet.Name = GetNewInfoSetName(orgSet);
					orgSet.CopyTo(newSet);
					newSet.Save();
					m_currentInfoSet = orgSet.Name;
					ImportFacilities(orgSet, newSet, connection);
				}

				connection.Close();
				connection = null;

				m_currentInfoSet = "Complete!";
				UpdateStatus();
				MessageBox.Show(this, 
					"Import Complete!", "Import Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message.ToString());
				MessageBox.Show(this,
					"There was an error importing the selected InfoSets.",
					"Import Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally
			{
				MainForm.currentlyImporting = false;
				copyPhoto = false;
				buttonCancel.Enabled = true;
				buttonImport.Enabled = true;
				buttonBrowse.Enabled = true;

				//mam 102309
				buttonBrowsePhotos.Enabled = true;

				if (connection != null)
					connection.Close();
			}
		}

		private void		UpdateStatus()
		{
			m_statusBuilder.Length = 0;

			if (m_currentInfoSet.Length > 0)
				m_statusBuilder.Append(m_currentInfoSet);
			
			if (m_currentFacility.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentFacility);
			}

			if (m_currentProcess.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentProcess);
			}

			if (m_currentComponent.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentComponent);
			}

			labelStatus.Text = m_statusBuilder.ToString();
			Application.DoEvents();
		}

		//mam 102309
		private string CreateImagesFolder(string assetName)
		{
			string curDate = DateTime.Now.Ticks.ToString();
			string curPath = WAM.Common.Globals.WamPhotoPath;
			string imagePathCopyTo = curPath + "\\" + assetName;
			bool successCreatePhotoFolder = false;

			if (System.IO.Directory.Exists(imagePathCopyTo))
			{
				successCreatePhotoFolder = true;
			}
			else
			{
				try
				{
					System.IO.Directory.CreateDirectory(imagePathCopyTo);
					successCreatePhotoFolder = true;
				}
				catch
				{
				}
			}

//			if (!successCreatePhotoFolder)
//			{
//				try
//				{
//					imagePathCopyTo = curDate;
//					System.IO.Directory.CreateDirectory(imagePathCopyTo);
//					successCreatePhotoFolder = true;
//				}
//				catch
//				{
//				}
//			}

			return successCreatePhotoFolder ? imagePathCopyTo : "";
		}

		//mam 11142011
		Hashtable hashTableFactorIdToFactor = new Hashtable();

		//mam 102309
		//private bool ImportFacilities(InfoSet orgSet, InfoSet newSet, OleDbConnection sourceConnection)
		private bool ImportFacilities(InfoSetOriginal orgSet, InfoSet newSet, OleDbConnection sourceConnection)
		{
			//mam 11142011
			hashTableFactorIdToFactor.Clear();
			foreach (Common.Criticality crit in Common.CommonTasks.Criticalities)
			{
				foreach (Common.CriticalityFactor factor in crit.CriticalityFactors)
				{
					hashTableFactorIdToFactor.Add(factor.FactorId, factor);
				}
			}

			//mam 102309
			SqlConnection sqlConnection = new SqlConnection(WAM.Common.Globals.WamSqlConnectionString);
			sqlConnection.Open();

			Facility[]		sourceFacilities = Facility.LoadAllOleDb(sourceConnection, orgSet.ID);
			Facility		source;
			Facility		newFacility;

			//mam - need to read DatabaseInfo table in source database to determine image folder name
			//if DatabaseInfo table doesn't exist, the image folder name is the name of the infoset
			//if the table does exist, but the DatabaseImageFolder field is blank, the image folder name is the name of the infoset
			//if the table does exist and the DatabaseImageFolder has a value, that value, along with the name of the infoset, make up the name of the image folder

			//sourceInfoSetImagePath = orgSet.GetImagePath();

			//mam 102309
			//newInfoSetImagePath = newSet.GetImagePath();
			newInfoSetImagePath = CreateImagesFolder(newSet.Name);
			//WAM.Common.CommonTasks.SetInfosetImagePath(newSet.ID, newInfoSetImagePath);

			//mam 102309 - use the source photo path that the user has selected
			sourceInfoSetImagePath = photoPath;
//			//check the database to see if it contains the image folder name
//			sourceInfoSetImagePath = "";
//			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
//			System.Data.DataTable dataTable = new System.Data.DataTable();
//
//			dataTable = dataAccess.GetDisconnectedDataTable(
//				"SELECT DatabaseImageFolder FROM DatabaseInfo", sourceConnection.ConnectionString);
//			if (dataTable != null)
//			{
//				if (dataTable.Rows.Count > 0)
//				{
//					if (dataTable.Rows[0]["DatabaseImageFolder"] != null)
//					{
//						//sourceInfoSetImagePath = dataRow["DatabaseImageFolder"].ToString();
//						sourceInfoSetImagePath = dataTable.Rows[0]["DatabaseImageFolder"].ToString();
//					}
//				}
//			}
//			if (sourceInfoSetImagePath == "")
//			{
//				sourceInfoSetImagePath = Drive.IO.Directory.GetFilePath(loadDatabaseFileNameWithPath) 
//					+ @"\Images\" + orgSet.Name;
//			}
//			else
//			{
//				sourceInfoSetImagePath = Drive.IO.Directory.GetFilePath(loadDatabaseFileNameWithPath) 
//					+ @"\Images\" + sourceInfoSetImagePath + @"\" + orgSet.Name;
//			}
			//</mam>

			for (int pos = 0; pos < sourceFacilities.Length; pos++)
			{
				source = sourceFacilities[pos];
				m_currentFacility = source.Name;

				//mam - store source current year for use by disciplines
				m_importFacilityCurrentYear = source.CurrentYear;
				//</mam>

				UpdateStatus();

				newFacility = new Facility(0);
				source.CopyTo(newFacility);
				newFacility.InfoSetID = newSet.ID;

				//mam - set the CustomENRListID = 0 because we don't know what it is yet
				newFacility.CustomENRListID = 0;
				//</mam>

				newFacility.Save();
				if (source.UsesCustomENRTable)
				{
					if (arrayListCustomerENRListIDs1.Contains(source.CustomENRListID))
					{
						for (int i = 0; i < arrayListCustomerENRListIDs1.Count; i++)
						{
							if (arrayListCustomerENRListIDs1[i].Equals(source.CustomENRListID))
							{
								//mam 102309
								//source.CopyENRTable(newFacility, sourceConnection, (int)arrayListCustomerENRListIDs2[i]);
								source.CopyENRTable(newFacility, sqlConnection, (int)arrayListCustomerENRListIDs2[i]);
							}
						}
					}
					else
					{
						//mam 102309
						//source.CopyENRTable(newFacility, sourceConnection);
						source.CopyENRTable(newFacility, sourceConnection, sqlConnection);

						arrayListCustomerENRListIDs1.Add(source.CustomENRListID);
						arrayListCustomerENRListIDs2.Add(newFacility.CustomENRListID);
					}

					//ENRCustom.LoadForFacility(sourceConnection, 
				}

				//mam - copy photos
				if (sourceInfoSetImagePath != "" && copyPhoto)
				{
					string copyPhoto1From = string.Format(
						@"{0}\{1:D4}-N.jpg", @sourceInfoSetImagePath, source.ID);
					string copyPhoto1To = string.Format(
						@"{0}\{1:D4}-N.jpg", @newInfoSetImagePath, newFacility.ID);

					string copyPhoto2From = string.Format(
						@"{0}\{1:D4}-S.jpg", @sourceInfoSetImagePath, source.ID);
					string copyPhoto2To = string.Format(
						@"{0}\{1:D4}-S.jpg", @newInfoSetImagePath, newFacility.ID);

					try
					{
						if (System.IO.File.Exists(copyPhoto1From))
							System.IO.File.Copy(copyPhoto1From, copyPhoto1To, true);
					}
					catch
					{
					}

					try
					{
						if (System.IO.File.Exists(copyPhoto2From))
							System.IO.File.Copy(copyPhoto2From, copyPhoto2To, true);
					}
					catch
					{
					}
				}
				//</mam>

				//mam - additional parameters
				//ImportProcesses(source, newFacility, sourceConnection);
				ImportProcesses(source, newFacility, sourceConnection, orgSet.ID);
			}

			m_currentFacility = "";
			UpdateStatus();
			return true;
		}

		//mam - additional parameters
		//private bool ImportProcesses(Facility sourceFacility, Facility newFacility, OleDbConnection sourceConnection)
		//mam 102309 - leave as is for importing treatment processes
		private bool ImportProcesses(Facility sourceFacility, Facility newFacility, OleDbConnection sourceConnection, int orgSetID)
		//private bool ImportProcesses(Facility sourceFacility, Facility newFacility, SqlConnection sourceConnection, int orgSetID)
		{
			TreatmentProcess[] sourceProcesses = TreatmentProcess.LoadAllOleDb(sourceConnection, sourceFacility.ID);
			TreatmentProcess sourceProcess;
			TreatmentProcess newProcess;

			for (int pos = 0; pos < sourceProcesses.Length; pos++)
			{
				sourceProcess = sourceProcesses[pos];
				m_currentProcess = sourceProcess.Name;
				UpdateStatus();

				newProcess = new TreatmentProcess(0);
				sourceProcess.CopyTo(newProcess);
				newProcess.FacilityID = newFacility.ID;
				newProcess.Save();

				//mam - copy photo
				if (copyPhoto)
				{
					string copyPhotoFrom = string.Format(
						@"{0}\{1:D4}-{2:D4}.jpg", @sourceInfoSetImagePath,
						sourceFacility.ID, sourceProcess.ID);
					string copyPhotoTo = string.Format(
						@"{0}\{1:D4}-{2:D4}.jpg", @newInfoSetImagePath,
						newFacility.ID, newProcess.ID);

					try
					{
						if (System.IO.File.Exists(copyPhotoFrom))
							System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
					}
					catch
					{
					}
				}
				//</mam>

				//mam - additional parameters
				//ImportComponents(sourceProcess, newProcess, sourceConnection);
				ImportComponents(sourceProcess, newProcess, sourceConnection, orgSetID);
			}

			m_currentProcess = "";
			UpdateStatus();
			return true;
		}

		//mam - additional parameters
		//private bool ImportComponents(TreatmentProcess sourceProcess, TreatmentProcess newProcess, OleDbConnection sourceConnection)
		//mam 102309 - leave as is for importing major components
		private bool ImportComponents(TreatmentProcess sourceProcess, TreatmentProcess newProcess, 
								OleDbConnection sourceConnection, int orgSetID)
		//private bool ImportComponents(TreatmentProcess sourceProcess, TreatmentProcess newProcess, 
		//	SqlConnection sourceConnection, int orgSetID)
			{
			MajorComponent[] sourceComponents = MajorComponent.LoadAllOleDb(sourceConnection, sourceProcess.ID);
			MajorComponent sourceComponent;
			MajorComponent newComponent;

			for (int pos = 0; pos < sourceComponents.Length; pos++)
			{
				sourceComponent = sourceComponents[pos];
				m_currentComponent = sourceComponent.Name;
				UpdateStatus();

				newComponent = new MajorComponent(0);
				sourceComponent.CopyTo(newComponent);
				newComponent.ProcessID = newProcess.ID;

				newComponent.Save();

				//mam 11142011 - should we do this? - no - rather than assigning the default crit values to all imported Access components, 
				//	let's allow the user to map Access crits to SQL crits - that way we won't lose the Access crit data
				//if (newComponent.MechStructDisciplines)
				//{
				//	newComponent.InsertCriticalityValuesAllDefault();
				//}

				//mam 11142011 - assign each factor
				if (newComponent.MechStructDisciplines)
				{
					newComponent.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();
					foreach (WAM.Common.MajorComponentSelectedCriticalityFactors critFactor in newComponent.ComponentSelectedCriticalityFactorsCollection)
					{
						int factorId = 0;
						if (critFactor.CriticalityId == Common.Globals.CritMapperPublicHealth.CriticalityId)
						{
							//get scoreId for Access public health crit value
							factorId = (int)Common.Globals.CritMapperPublicHealth.HashTableAccessToFactorId[(int)sourceComponent.CritPublicHealth];

							//int factorId = hashTableFactorScoreIdToFactorId(scoreId);
						}
						else if (critFactor.CriticalityId == Common.Globals.CritMapperFinancial.CriticalityId)
						{
							factorId = (int)Common.Globals.CritMapperFinancial.HashTableAccessToFactorId[(int)sourceComponent.CritRepair];
						}
						else if (critFactor.CriticalityId == Common.Globals.CritMapperEnvironmental.CriticalityId)
						{
							factorId = (int)Common.Globals.CritMapperEnvironmental.HashTableAccessToFactorId[(int)sourceComponent.CritEnvironmental];
						}
						else if (critFactor.CriticalityId == Common.Globals.CritMapperCustomerEffect.CriticalityId)
						{
							factorId = (int)Common.Globals.CritMapperCustomerEffect.HashTableAccessToFactorId[(int)sourceComponent.CritCustEffect];
						}

						if (factorId != 0)
						{
							Common.CriticalityFactor factor = (Common.CriticalityFactor)hashTableFactorIdToFactor[factorId];
							critFactor.CritFactor = factor;
						}
					}

					newComponent.SaveCriticalityValuesAll();
				}
				//</mam>

				//mam - copy photo
				if (sourceInfoSetImagePath != "" && copyPhoto)
				{
					string copyPhotoFrom = string.Format(
						@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @sourceInfoSetImagePath,
						sourceProcess.FacilityID, sourceProcess.ID, sourceComponent.ID);
					string copyPhotoTo = string.Format(
						@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @newInfoSetImagePath,
						newProcess.FacilityID, newProcess.ID, newComponent.ID);

					try
					{
						if (System.IO.File.Exists(copyPhotoFrom))
							System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
					}
					catch
					{
					}
				}
				//</mam>

				//mam - additional parameters
				//ImportDisciplines(sourceComponent, newComponent, sourceConnection);
				ImportDisciplines(sourceComponent, newComponent, sourceConnection, orgSetID, 
					sourceProcess.ID, newProcess.ID, sourceProcess.FacilityID, newProcess.FacilityID);
			}

			m_currentComponent = "";
			UpdateStatus();
			return true;
		}

		//mam - additional parameters
		//private bool ImportDisciplines(MajorComponent sourceComponent, MajorComponent newComponent, 
		//						OleDbConnection sourceConnection)
		//mam 102309 - leave as is for importing from Access databases
		private bool ImportDisciplines(MajorComponent sourceComponent, MajorComponent newComponent, 
			OleDbConnection sourceConnection, int orgSetID, 
			int sourceProcessID, int newProcessID, int sourceFacilityID, int newFacilityID)
		//private bool ImportDisciplines(MajorComponent sourceComponent, MajorComponent newComponent, 
		//	SqlConnection sourceConnection, int orgSetID, 
		//	int sourceProcessID, int newProcessID, int sourceFacilityID, int newFacilityID)
			{

			//mam 11142011 - pass in source component
			//Discipline[]	disciplines = DisciplineLoader.LoadForComponent(sourceConnection, sourceComponent.ID);
			Discipline[]	disciplines = DisciplineLoader.LoadForComponent(sourceConnection, sourceComponent.ID, sourceComponent);

			Discipline		newDiscipline = null;
			bool			importAssetList = false;
			bool			importPipeData = false;
			bool			importNodeData = false;
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				// Skip non-existent disciplines
				//mam - don't skip the Mech Disc because it may have assets
				//mam - in fact, don't skip any of the disciplines, because they may have photos
				//if (disciplines[pos].ConditionRanking == CondRank.No)
				//	continue;
				//</mam>

				//mam 012307 - we need to skip the disciplines that don't exist in the source component
				//	- check the discipline id - if it's zero, the discipline doesn't exist
				if (disciplines[pos].ID == 0)
				{
					continue;
				}

				importAssetList = false;
				importPipeData = false;
				importNodeData = false;

				switch (disciplines[pos].Type)
				{
					case DisciplineType.Mechanical:
						newDiscipline = new DisciplineMech(0);
						importAssetList = true;
						break;
					case DisciplineType.Structural:
						newDiscipline = new DisciplineStruct(0);
						break;
					case DisciplineType.Land:
						newDiscipline = new DisciplineLand(0);
						break;
					case DisciplineType.Pipes:
						newDiscipline = new DisciplinePipe(0);
						importPipeData = true;
						break;
					case DisciplineType.Nodes:
						newDiscipline = new DisciplineNode(0);
						importNodeData = true;
						break;
					default:
						continue;
				}

				disciplines[pos].CopyTo(newDiscipline);
				newDiscipline.ComponentID = newComponent.ID;
				//newDiscipline.InfoSetID = orgSetID;
				//disciplines[pos].CopyTo(newDiscipline);

				//mam 07072011
				newDiscipline.RehabYearLast = newDiscipline.GetRehabYearLastDefault();

				newDiscipline.Save();

				//mam - copy photos
				if (sourceInfoSetImagePath != "" && copyPhoto)
				{
					switch (disciplines[pos].Type)
					{
						case DisciplineType.Mechanical:
						case DisciplineType.Structural:
						{
							string copyPhotoFrom = string.Format(
								@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @sourceInfoSetImagePath,
								sourceFacilityID, sourceProcessID, sourceComponent.ID, (int)disciplines[pos].Type);
							string copyPhotoTo = string.Format(
								@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @newInfoSetImagePath,
								newFacilityID, newProcessID, newComponent.ID, (int)newDiscipline.Type);

							try
							{
								if (System.IO.File.Exists(copyPhotoFrom))
									System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
							}
							catch
							{
							}
						}
							break;
						case DisciplineType.Land:
						{
							for (int i = 1; i <= 3; i++)
							{
								string copyPhotoFrom = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @sourceInfoSetImagePath,
									sourceFacilityID, sourceProcessID, sourceComponent.ID, (int)disciplines[pos].Type, i);
								string copyPhotoTo = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @newInfoSetImagePath,
									newFacilityID, newProcessID, newComponent.ID, (int)newDiscipline.Type, i);

								try
								{
									if (System.IO.File.Exists(copyPhotoFrom))
										System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
								}
								catch
								{
								}
							}
							break;
						}
						
						default:
							//continue;
							break;
					}
				}
				//</mam>

				if (importAssetList)
					ImportAssetListOleDb(sourceComponent, newComponent, sourceConnection);
				else if (importPipeData)
					ImportPipeDataOleDb(disciplines[pos], newDiscipline, sourceConnection);
				else if (importNodeData)
					ImportNodeDataOleDb(disciplines[pos], newDiscipline, sourceConnection);
			}

			m_currentComponent = "";
			UpdateStatus();
			return true;
		}

		#region /***** OleDb Methods *****/
		//mam 102309
		private bool ImportAssetListOleDb(MajorComponent sourceComponent, MajorComponent newComponent, OleDbConnection sourceConnection)
		//private bool ImportAssetList(MajorComponent sourceComponent, MajorComponent newComponent, SqlConnection sourceConnection)
		{
			ComponentAsset[] sourceAssets = ComponentAsset.LoadAllOleDb(sourceConnection, sourceComponent.ID);
			ComponentAsset	sourceAsset = null;
			ComponentAsset	newAsset = null;

			for (int pos = 0; pos < sourceAssets.Length; pos++)
			{
				sourceAsset = sourceAssets[pos];

				newAsset = new ComponentAsset(0);
				sourceAsset.CopyTo(newAsset);
				newAsset.ComponentID = newComponent.ID;
				newAsset.Save();
			}

			return true;
		}

		//mam 102309
		private bool ImportPipeDataOleDb(Discipline sourceDiscipline, Discipline newDiscipline, OleDbConnection sourceConnection)
		//private bool ImportPipeData(Discipline sourceDiscipline, Discipline newDiscipline, SqlConnection sourceConnection)
		{
			PipeData[]		sourceRecords = PipeData.LoadForDisciplineOleDb(sourceConnection, sourceDiscipline.ID);
			PipeData		sourceRec = null;
			PipeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new PipeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscPipeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011
				SavePipeCrits(sourceRec, newRec);
			}

			return true;
		}

		//mam 11142011 - new method
		private void SavePipeCrits(PipeData sourceRec, PipeData newRec)
		{
			//mam 11142011 - assign each factor
			newRec.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();
			foreach (WAM.Common.MajorComponentSelectedCriticalityFactors critFactor in newRec.ComponentSelectedCriticalityFactorsCollection)
			{
				int factorId = 0;
				if (critFactor.CriticalityId == Common.Globals.CritMapperPublicHealth.CriticalityId)
				{
					//get scoreId for Access public health crit value
					factorId = (int)Common.Globals.CritMapperPublicHealth.HashTableAccessToFactorId[(int)sourceRec.CritPublicHealth];

					//int factorId = hashTableFactorScoreIdToFactorId(scoreId);
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperFinancial.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperFinancial.HashTableAccessToFactorId[(int)sourceRec.CritRepair];
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperEnvironmental.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperEnvironmental.HashTableAccessToFactorId[(int)sourceRec.CritEnvironmental];
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperCustomerEffect.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperCustomerEffect.HashTableAccessToFactorId[(int)sourceRec.CritCustEffect];
				}

				if (factorId != 0)
				{
					Common.CriticalityFactor factor = (Common.CriticalityFactor)hashTableFactorIdToFactor[factorId];
					critFactor.CritFactor = factor;
				}

				newRec.SaveCriticalityValuesAll();
			}
			//</mam>
		}

		//mam 11142011 - new method
		private void SaveNodeCrits(NodeData sourceRec, NodeData newRec)
		{
			//mam 11142011 - assign each factor
			newRec.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();
			foreach (WAM.Common.MajorComponentSelectedCriticalityFactors critFactor in newRec.ComponentSelectedCriticalityFactorsCollection)
			{
				int factorId = 0;
				if (critFactor.CriticalityId == Common.Globals.CritMapperPublicHealth.CriticalityId)
				{
					//get scoreId for Access public health crit value
					factorId = (int)Common.Globals.CritMapperPublicHealth.HashTableAccessToFactorId[(int)sourceRec.CritPublicHealth];

					//int factorId = hashTableFactorScoreIdToFactorId(scoreId);
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperFinancial.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperFinancial.HashTableAccessToFactorId[(int)sourceRec.CritRepair];
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperEnvironmental.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperEnvironmental.HashTableAccessToFactorId[(int)sourceRec.CritEnvironmental];
				}
				else if (critFactor.CriticalityId == Common.Globals.CritMapperCustomerEffect.CriticalityId)
				{
					factorId = (int)Common.Globals.CritMapperCustomerEffect.HashTableAccessToFactorId[(int)sourceRec.CritCustEffect];
				}

				if (factorId != 0)
				{
					Common.CriticalityFactor factor = (Common.CriticalityFactor)hashTableFactorIdToFactor[factorId];
					critFactor.CritFactor = factor;
				}

				newRec.SaveCriticalityValuesAll();
			}
			//</mam>
		}

		//mam 102309
		private bool ImportNodeDataOleDb(Discipline sourceDiscipline, Discipline newDiscipline, OleDbConnection sourceConnection)
		//private bool ImportNodeData(Discipline sourceDiscipline, Discipline newDiscipline, SqlConnection sourceConnection)
		{
			NodeData[]		sourceRecords = NodeData.LoadForDisciplineOleDb(sourceConnection, sourceDiscipline.ID);
			NodeData		sourceRec = null;
			NodeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new NodeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscNodeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011
				SaveNodeCrits(sourceRec, newRec);
			}

			return true;
		}
		#endregion /***** OleDb Methods *****/

		#region /***** SQL Methods *****/
		//mam 102309
		//private bool ImportAssetList(MajorComponent sourceComponent, MajorComponent newComponent, OleDbConnection sourceConnection)
		private bool ImportAssetList(MajorComponent sourceComponent, MajorComponent newComponent, SqlConnection sourceConnection)
		{
			ComponentAsset[] sourceAssets = ComponentAsset.LoadAll(sourceConnection, sourceComponent.ID);
			ComponentAsset	sourceAsset = null;
			ComponentAsset	newAsset = null;

			for (int pos = 0; pos < sourceAssets.Length; pos++)
			{
				sourceAsset = sourceAssets[pos];

				newAsset = new ComponentAsset(0);
				sourceAsset.CopyTo(newAsset);
				newAsset.ComponentID = newComponent.ID;
				newAsset.Save();
			}

			return true;
		}

		//mam 102309
		//private bool ImportPipeData(Discipline sourceDiscipline, Discipline newDiscipline, OleDbConnection sourceConnection)
		private bool ImportPipeData(Discipline sourceDiscipline, Discipline newDiscipline, SqlConnection sourceConnection)
		{
			PipeData[]		sourceRecords = PipeData.LoadForDiscipline(sourceConnection, sourceDiscipline.ID);
			PipeData		sourceRec = null;
			PipeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new PipeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscPipeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011 - this routine isn't used, but add this line to save crits anyway
				newRec.SaveCriticalityValuesAll();
			}

			return true;
		}

		//mam 102309
		//private bool ImportNodeData(Discipline sourceDiscipline, Discipline newDiscipline, OleDbConnection sourceConnection)
		private bool ImportNodeData(Discipline sourceDiscipline, Discipline newDiscipline, SqlConnection sourceConnection)
		{
			NodeData[]		sourceRecords = NodeData.LoadForDiscipline(sourceConnection, sourceDiscipline.ID);
			NodeData		sourceRec = null;
			NodeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new NodeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscNodeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011 - this routine isn't used, but add this line to save crits anyway
				newRec.SaveCriticalityValuesAll();
			}

			return true;
		}
		#endregion /***** SQL Methods *****/

		//mam 102309
		//private string		GetNewInfoSetName(InfoSet importSet)
		private string		GetNewInfoSetName(InfoSetOriginal importSet)
		{
			InfoSet[]		existingSets = InfoSet.LoadAll();

			string			curName = importSet.Name;
			string			orgName = importSet.Name;
			int				attempts = 0;

			// Iterate through the info sets to be imported; don't duplicate info 
			// set names (append a rev # on the end; user may rename later)
			for (int pos = 0; pos < existingSets.Length; pos++)
			{
				if (string.Compare(curName, existingSets[pos].Name) == 0)
				{
					attempts++;
					curName = string.Format("{0} {1}", orgName, attempts);
					// Start the loop back over so that we can try the new name
					pos = -1;
				}
			}

			return curName;
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ImportFromWAMForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingData.htm");
		}

		//mam
		private void ImportFromWAMForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
		//</mam>
	}
}