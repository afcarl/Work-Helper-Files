using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;

//mam 102309
//using System.Data.OleDb;

using System.IO;
using System.Windows.Forms;
using WAM.Data;
using C1.Win.C1FlexGrid;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportPipeNodeForm.
	/// </summary>
	public class ImportPipeNodeForm : System.Windows.Forms.Form
	{
		private enum		PipeColumns
		{
			Facility,
			Process,
			Component,
			IDNumber,
			Description,
			Type,
			Size,
			Length,
			UnitCost,
			InstallYear,
			//OriginalENR, - mam removed
			ReplaceVal,
			SalvageVal,
			AnnualMaintCost,
			ConditionRank,

			//mam 07072011
			Crit1,
			Crit2,
			Crit3,
			Crit4,
			Crit5,
			Crit6,

			//mam 07072011 - no longer using four fixed crits
			//CritHealth,
			//CritEnv,
			//CritCost,
			//CritCustEffect,

			Vulnerability,
			LevelOfService,
			OriginalUL,

			//mam 050806
			AcquisitionCost,
			CurrentValue,
			ReplacementValueYear,
			RehabCost,
			RepairCost,
			RedundantAssets,
		}

		private enum		NodeColumns
		{
			Facility,
			Process,
			Component,
			IDNumber,
			Description,
			Type,
			Size,
			InstallYear,
			//OriginalENR, - mam removed
			AcquisitionCost,
			ReplaceVal,
			SalvageVal,
			AnnualMaintCost,
			ConditionRank,

			//mam 07072011
			Crit1,
			Crit2,
			Crit3,
			Crit4,
			Crit5,
			Crit6,

			//mam 07072011 - no longer using four fixed crits
			//CritHealth,
			//CritEnv,
			//CritCost,
			//CritCustEffect,

			Vulnerability,
			LevelOfService,
			OriginalUL,

			//mam 050806
			CurrentValue,
			ReplacementValueYear,
			RehabCost,
			RepairCost,
			RedundantAssets,
		}

		private bool		m_isPipe = true;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.Button buttonImport;
		private System.Windows.Forms.TextBox textBoxSource;

		//mam
		private System.Text.StringBuilder builder = new System.Text.StringBuilder(100);
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private C1.Win.C1FlexGrid.C1FlexGrid gridTest;
		//</mam>

		//mam 07072011
		private ArrayList arrayListCriticalities = new ArrayList();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ImportPipeNodeForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ImportPipeNodeForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxSource = new System.Windows.Forms.TextBox();
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.buttonImport = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.gridTest = new C1.Win.C1FlexGrid.C1FlexGrid();
			((System.ComponentModel.ISupportInitialize)(this.gridTest)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 4);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(300, 28);
			this.label1.TabIndex = 0;
			this.label1.Text = "Select the tab-delimited text file containing the records to be imported and pres" +
				"s the \"Import\" button.";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(4, 42);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "&Select File:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxSource
			// 
			this.textBoxSource.Location = new System.Drawing.Point(68, 40);
			this.textBoxSource.Name = "textBoxSource";
			this.textBoxSource.Size = new System.Drawing.Size(216, 20);
			this.textBoxSource.TabIndex = 2;
			this.textBoxSource.Text = "";
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowse.Location = new System.Drawing.Point(288, 39);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.TabIndex = 3;
			this.buttonBrowse.Text = "&Browse...";
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// buttonImport
			// 
			this.buttonImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonImport.Location = new System.Drawing.Point(147, 75);
			this.buttonImport.Name = "buttonImport";
			this.buttonImport.TabIndex = 4;
			this.buttonImport.Text = "&Import";
			this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(341, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 102;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// gridTest
			// 
			this.gridTest.ColumnInfo = "10,1,0,0,0,85,Columns:";
			this.gridTest.Location = new System.Drawing.Point(16, 120);
			this.gridTest.Name = "gridTest";
			this.gridTest.Size = new System.Drawing.Size(688, 328);
			this.gridTest.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.gridTest.TabIndex = 103;
			// 
			// ImportPipeNodeForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 104);
			this.Controls.Add(this.gridTest);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonImport);
			this.Controls.Add(this.buttonBrowse);
			this.Controls.Add(this.textBoxSource);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "ImportingData.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ImportPipeNodeForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Import Pipe Data";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ImportPipeNodeForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ImportPipeNodeForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.gridTest)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ImportDataFile(bool showPipe, Form owner)
		{
			ImportPipeNodeForm form = new ImportPipeNodeForm();

			form.m_isPipe = showPipe;
			form.ShowDialog(owner);
		}

		protected override void OnLoad(EventArgs e)
		{
			if (m_isPipe)
				this.Text = "Import Pipe Data";
			else
				this.Text = "Import Node / Appurtenance Data";

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			base.OnLoad(e);
		}

		private void buttonBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog fileDlg = new OpenFileDialog();
			fileDlg.InitialDirectory = Application.StartupPath;
			fileDlg.Filter = "Tab Delimited Text Files (*.txt)|*.txt";
			fileDlg.CheckFileExists = true;

			if (textBoxSource.Text.Length > 0)
				fileDlg.FileName = textBoxSource.Text;

			if (fileDlg.ShowDialog(this) == DialogResult.OK)
				textBoxSource.Text = fileDlg.FileName;
		}

		//mam 050806
		private void PopulateGridRow(ref C1.Win.C1FlexGrid.C1FlexGrid gridReasons, string lineNumber, 
			string reasonText, string idNumber)
		{
			C1.Win.C1FlexGrid.Row newRow = gridReasons.Rows.Add();
			gridReasons.SetData(newRow.Index, "LineNumber", lineNumber.ToString());
			gridReasons.SetData(newRow.Index, "Reason", reasonText);
			gridReasons.SetData(newRow.Index, "IDNumber", idNumber.ToString());
		}

		//mam 07072011 - create a list of the text values (as opposed to the enum values) for PipeColumn
		private ArrayList GetPipeColumnTextList()
		{
			ArrayList arrayListPipeColumnText = new ArrayList();

			arrayListPipeColumnText.Add("Facility");
			arrayListPipeColumnText.Add("Process");
			arrayListPipeColumnText.Add("Component");
			arrayListPipeColumnText.Add("ID Number");
			arrayListPipeColumnText.Add("Description");
			arrayListPipeColumnText.Add("Type");
			arrayListPipeColumnText.Add("Diameter");
			arrayListPipeColumnText.Add("Length");
			arrayListPipeColumnText.Add("Unit Cost");
			arrayListPipeColumnText.Add("Installation Year");
			arrayListPipeColumnText.Add("Replacement Value");
			arrayListPipeColumnText.Add("Salvage Value");
			arrayListPipeColumnText.Add("Annual Maint");
			arrayListPipeColumnText.Add("Condition");

			//add existing criticalities to the array list
			int counter = 0;
			foreach (Criticality crit in Common.CommonTasks.Criticalities)
			{
				counter++;
				arrayListPipeColumnText.Add(crit.CriticalityName);
			}

			//add unused criticalities to the array list
			for (int i = counter + 1; i <= 6; i++)
			{
				arrayListPipeColumnText.Add("Crit" + i.ToString());
			}

			arrayListPipeColumnText.Add("Vulnerability");
			arrayListPipeColumnText.Add("Level Of Service");
			arrayListPipeColumnText.Add("Original Useful");

			arrayListPipeColumnText.Add("Acquisition Cost");
			arrayListPipeColumnText.Add("Current Value");
			arrayListPipeColumnText.Add("Replacement Value Year");
			arrayListPipeColumnText.Add("Rehabilitation Cost");
			arrayListPipeColumnText.Add("Repair Cost");
			arrayListPipeColumnText.Add("Redundant Assets");

			return arrayListPipeColumnText;
		}

		//mam 07072011 - create a list of the text values (as opposed to the enum values) for NodeColumn
		private ArrayList GetNodeColumnTextList()
		{
			ArrayList arrayListNodeColumnText = new ArrayList();

			arrayListNodeColumnText.Add("Facility");
			arrayListNodeColumnText.Add("Process");
			arrayListNodeColumnText.Add("Component");
			arrayListNodeColumnText.Add("ID Number");
			arrayListNodeColumnText.Add("Description");
			arrayListNodeColumnText.Add("Type");
			arrayListNodeColumnText.Add("Size");
			arrayListNodeColumnText.Add("Installation Year");
			arrayListNodeColumnText.Add("Acquisition Cost");
			arrayListNodeColumnText.Add("Replacement Value");
			arrayListNodeColumnText.Add("Salvage Value");
			arrayListNodeColumnText.Add("Annual Maint");
			arrayListNodeColumnText.Add("Condition");

			//add existing criticalities to the array list
			int counter = 0;
			foreach (Criticality crit in Common.CommonTasks.Criticalities)
			{
				counter++;
				arrayListNodeColumnText.Add(crit.CriticalityName);
			}

			//add unused criticalities to the array list
			for (int i = counter + 1; i <= 6; i++)
			{
				arrayListNodeColumnText.Add("Crit" + i.ToString());
			}

			arrayListNodeColumnText.Add("Vulnerability");
			arrayListNodeColumnText.Add("Level Of Service");
			arrayListNodeColumnText.Add("Original Useful");
			arrayListNodeColumnText.Add("Current Value");
			arrayListNodeColumnText.Add("Replacement Value Year");
			arrayListNodeColumnText.Add("Rehabilitation Cost");
			arrayListNodeColumnText.Add("Repair Cost");
			arrayListNodeColumnText.Add("Redundant Assets");

			return arrayListNodeColumnText;
		}

		//mam 07072011 - new method
		private bool GetDataFromImportFile()
		{
			FileStream file = null;
			StreamReader reader = null;
			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);
			string[] dataFields;
			string curLine;
			char[] delimiter = new char[1] { '\t' };
			Column newGridCol;

			//see if the file exists
			if (!File.Exists(textBoxSource.Text))
			{
				MessageBox.Show(this, "Unable to locate the import file.", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			//open file and get data
			try
			{
				file = new FileStream(textBoxSource.Text, FileMode.Open, FileAccess.Read);
				reader = new StreamReader(file);

				//get a list of the PipeColumn (or NodeColumn) text values (as opposed to the enum values)
				//	for use in comparing import file columns with PipeColumns (NodeColumns)
				//ArrayList arrayListPipeNodeColumnText = GetPipeColumnTextList();
				ArrayList arrayListPipeNodeColumnText = new ArrayList();

				if (m_isPipe)
				{
					arrayListPipeNodeColumnText = GetPipeColumnTextList();
				}
				else
				{
					arrayListPipeNodeColumnText = GetNodeColumnTextList();
				}

				// Attempt to open the database
				sqlConnection.Open();

				//set the first two grid rows as fixed
				gridTest.Rows.Count = 2;
				gridTest.Rows.Fixed = 2;
				gridTest.Cols.Count = 0;

				//put PipeColumn/NodeColumn values into the grid			
				int totalColsSystem = 0;
				string[] colNames;

				if (m_isPipe)
				{
					totalColsSystem = Enum.GetValues(typeof(PipeColumns)).Length;
					colNames = Enum.GetNames(typeof(PipeColumns));
				}
				else
				{
					totalColsSystem = Enum.GetValues(typeof(NodeColumns)).Length;
					colNames = Enum.GetNames(typeof(NodeColumns));
				}

				//create columns in the grid from the PipeColumn/NodeColumn values (including all six crits)
				for (int i = 0; i < totalColsSystem; i++)
				{
					newGridCol = gridTest.Cols.Add();
					newGridCol.Name	= colNames[i].ToString();
					gridTest[0, newGridCol.Index] = newGridCol.Name;
				}

				//change the crits from "Crit1", etc., to the proper crit names in the first fixed row in the grid
				int counter = 0;
				foreach (Criticality crit in Common.CommonTasks.Criticalities)
				{
					counter++;
					gridTest[0, "Crit" + counter.ToString()] = crit.CriticalityName;
				}

				//read the first row from the import file
				curLine = reader.ReadLine();
				dataFields = curLine.Split(delimiter);
				ArrayList arraylistCritColumns = new ArrayList();
				ArrayList arrayListImportDataGridCol = new ArrayList();

				//determine if first row is header row
				if (dataFields[0].Trim().ToLower() == "facility/system"
					&& (dataFields[1].Trim().ToLower() == "process/basin/zone" 
					|| dataFields[1].Trim().ToLower() == "process/basin/ zone")
					&& dataFields[2].Trim().ToLower() == "component/subasin/subzone"
					&& dataFields[3].Trim().ToLower() == "id number")
				{
					//header row

					//match up the the col headers from the import file with the columns in the grid
					bool found = false;
					for (int i = 0; i < dataFields.Length; i++)
					{
						found = false;
						for (int j = 0; j < arrayListPipeNodeColumnText.Count; j++)
						{
							if (dataFields[i].ToString().ToUpper().IndexOf(arrayListPipeNodeColumnText[j].ToString().ToUpper()) > -1)
							{
								//differentiate between Replacement Value and Replacement Value Year
								if (dataFields[i].ToString().ToUpper().IndexOf("YEAR") > -1 
									&& arrayListPipeNodeColumnText[j].ToString().ToUpper().IndexOf("YEAR") < 0)
								{
									continue;
								}
								gridTest[1, j] = dataFields[i].ToString();
								arrayListImportDataGridCol.Add(j);
								found = true;
								break;
							}
						}
						if (!found)
						{
							//if there is no match for the import col in the grid, assign -1 to the column
							//	so that it won't be imported into the grid
							arrayListImportDataGridCol.Add(-1);
						}
					}

					//load the import file data into the grid
					while (curLine != null)
					{
						curLine = reader.ReadLine();
						if (curLine == null)
						{
							break;
						}
						dataFields = curLine.Split(delimiter);
						Row newRow = gridTest.Rows.Add();
						for (int i = 0; i < dataFields.Length; i++)
						{
							if ((int)arrayListImportDataGridCol[i] > -1)
							{
								gridTest.SetData(newRow.Index, (int)arrayListImportDataGridCol[i], dataFields[i].ToString());
							}
						}
					}
				}
				else
				{
					//don't import file if there is no header row 
					//	or a required column is missing (Facility, Process, Component, ID Number)
					string msg = "The data cannot be imported for one or both of the following reasons:" + Environment.NewLine + Environment.NewLine;
					msg += "1.  The file contains no header row." + Environment.NewLine;
					msg += "2.  The Facility, Process, Component, or ID Number columns are missing.";
					MessageBox.Show(this, msg, "Cannot Import Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			return true;
		}

		//mam 07072011 - reworked this method extensively
		private void buttonImport_Click(object sender, System.EventArgs e)
		{
			//mam 07072011 - load the invisible grid with data to be imported from the import file
			if (!GetDataFromImportFile())
			{
				return;
			}

			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(WAMSource.CurrentSource.ConnectionString);
			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);

			Facility[]		facilities = null;
			TreatmentProcess[] processes = null;
			MajorComponent[] components = null;
			char[]			delimiter = new char[1] { '\t' };
			int				skipCount = 0;
			bool			success = false;
			int				successCount = 0;

			//mam 050806
			int lineNumber = 0;
			string skipReason = string.Empty;
			string itemType = m_isPipe? "Pipe": "Node";
			C1FlexGrid gridReasons = new C1FlexGrid();
			gridReasons.Cols.Count = 4;
			gridReasons.Cols.Fixed = 1;
			gridReasons.Rows.Count = 1;
			gridReasons.Rows.Fixed = 1;
			gridReasons.Cols[1].Name = "LineNumber";
			gridReasons.Cols[2].Name = "Reason";
			gridReasons.Cols[3].Name = "IDNumber";

			//mam 07072011
			arrayListCriticalities = Common.CommonTasks.LoadCriticalitiesIntoArrayList();
			arrayListCriticalities.Sort();

			try
			{
				//file = new FileStream(textBoxSource.Text, FileMode.Open, FileAccess.Read);
				//reader = new StreamReader(file);

				// Attempt to open the database
				sqlConnection.Open();

				//gridTest contains the data from the import file

				//				curLine = reader.ReadLine();
				//				while (curLine != null)
				//				{
				//					//mam 050806
				//					lineNumber++;
				//					skipReason = string.Empty;
				//					
				//					// Separate the line into fields
				//					//the last column is the Redundant Assets column, which may be blank, causing the curLine string to end in \t rather
				//					//	than a value; if the string ends in \t, append a 1 for Redundant Asset count
				//					if (curLine != null && curLine.EndsWith("\t"))
				//					{
				//						curLine += "1";
				//					}
				//
				//					dataFields = curLine.Split(delimiter);
				//
				//					// Read the next line
				//					curLine = reader.ReadLine();
				//					if (curLine != null && curLine.EndsWith("\t"))
				//					{
				//						curLine += "1";
				//					}
				//
				//					//mam 050806 - determine if first row is a header row
				//					if (lineNumber == 1)
				//					{
				//						//mam 112806 - check for null value in dataFields[]
				//						if (dataFields[0].Trim().ToLower() == "facility/system"
				//							&& (dataFields[1].Trim().ToLower() == "process/basin/zone" 
				//							|| dataFields[1].Trim().ToLower() == "process/basin/ zone")
				//							&& dataFields[2].Trim().ToLower() == "component/subasin/subzone"
				//							&& dataFields[3].Trim().ToLower() == "id number")
				//						{
				//							//the first row is a header row - don't try to import it
				//							continue;
				//						}
				//					}

				for (int i = gridTest.Rows.Fixed; i < gridTest.Rows.Count; i++)
				{
					Row gridRow = gridTest.Rows[i];
					lineNumber = i - gridTest.Rows.Fixed + 1;

					//mam 07072011
					string idNumberText = gridRow[(int)PipeColumns.IDNumber].ToString();

					//mam 07072011 - it's OK to use PipeColumns exclusively in the rows below (checking Facility, Process, Component, ID Number)
					//	instead of checking whether NodeColumns should be used because the column numbers are the same for both
					//	the pipe import file and the node import file

					// Try to find a facility that matches the name in the file
					//mam 07072011 - use grid row instead of import file row
					//facilities = Facility.LoadForFacilityName(dataFields[0], InfoSet.CurrentID, sqlConnection);
					string colName = PipeColumns.Facility.ToString();
					string itemName = gridRow[colName].ToString();
					facilities = Facility.LoadForFacilityName(itemName, InfoSet.CurrentID, sqlConnection);
					if (facilities.Length != 1)
					{
						skipCount++;

						//mam 050806 -- added skipReason
						//mam 07072011 - use grid instead of import file
						//skipReason = "Facility '" + dataFields[0].ToString() + "' not found";
						skipReason = "Facility '" + itemName + "' not found";

						//mam 112806 - check for null value in dataFields[3]
						//mam 07072011 - use grid instead of import file
						//PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, (dataFields.Length > 3? dataFields[3].ToString(): ""));
						PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, idNumberText);

						continue;
					}

					// Find a process that matches the facility and process name
					//mam 07072011 - use grid row instead of import file row
					//processes = TreatmentProcess.LoadForProcessName(dataFields[1], facilities[0].ID, sqlConnection);
					colName = PipeColumns.Process.ToString();
					itemName = gridRow[colName].ToString();
					processes = TreatmentProcess.LoadForProcessName(itemName, facilities[0].ID, sqlConnection);

					if (processes.Length != 1)
					{
						skipCount++;

						//mam 050806 -- added skipReason
						//mam 07072011 - use grid instead of import file
						//skipReason = "Treatment Process '" + dataFields[1].ToString() + "' not found";
						skipReason = "Treatment Process '" + itemName + "' not found";

						//mam 112806 - check for null value in dataFields[3]
						//mam 07072011 - use grid instead of import file
						//PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, (dataFields.Length > 3? dataFields[3].ToString(): ""));
						PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, idNumberText);

						continue;
					}

					// Find a component that matches the process and component name
					//mam 07072011 - use grid row instead of import file row
					//components = MajorComponent.LoadForComponentName(dataFields[2], processes[0].ID, sqlConnection);
					colName = PipeColumns.Component.ToString();
					itemName = gridRow[colName].ToString();
					components = MajorComponent.LoadForComponentName(itemName, processes[0].ID, sqlConnection);
					if (components.Length != 1 || components[0].MechStructDisciplines) // make sure it is pipe / node
					{
						skipCount++;

						//mam 050806 -- added skipReason
						//mam 07072011 - use grid instead of import file
						//skipReason = "Major Component '" + dataFields[2].ToString() + "' not found";
						skipReason = "Major Component '" + itemName + "' not found";

						//mam 112806 - check for null value in dataFields[3]
						//mam 07072011 - use grid instead of import file
						//PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, (dataFields.Length > 3? dataFields[3].ToString(): ""));
						PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, idNumberText);

						continue;
					}
				

					//mam 050806 - added skipReason
					if (m_isPipe)
					{
						//mam 07072011 - use grid row instead of import file row
						//success = ImportPipeLine(dataFields, components[0].ID, sqlConnection, ref skipReason);
						success = ImportPipeLine(gridRow, components[0].ID, sqlConnection, ref skipReason);
					}
					else
					{
						//mam 07072011 - use grid row instead of import file row
						//success = ImportNodeLine(dataFields, components[0].ID, sqlConnection, ref skipReason);
						success = ImportNodeLine(gridRow, components[0].ID, sqlConnection, ref skipReason);
					}

					if (!success)
					{
						//mam 050806 -- added skipReason

						//mam 112806 - check for null value in dataFields[3]
						PopulateGridRow(ref gridReasons, lineNumber.ToString(), skipReason, idNumberText);

						skipCount++;
					}
					else
						successCount++;
				}

				//mam 050806 - modified message again
				//mam - modified the text of the message
				//MessageBox.Show(this,
				//	string.Format("File imported; {0} lines imported; {1} lines ignored (do not match to components or are duplicates).\n\n(Note: The column heading line will not match to components.)", successCount, skipCount),
				//	"Import Complete");

				string messageText1 = "";
				string messageText2 = "";

				//mam 050806
				if (skipCount == 0)
				{
					if (successCount == 0)
					{
						messageText1 = string.Format("There were no " + itemType + "s to import.", successCount);
					}
					else if (successCount == 1)
					{
						messageText1 = string.Format("There was one " + itemType + " in the file.  It was imported.", successCount);
					}
					else
					{
						messageText1 = string.Format("All  {0}  " + itemType + "s were imported.", successCount);
					}
					MessageBox.Show(this, messageText1, "Import Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					if (successCount != 1 && skipCount != 1)
					{
						messageText1 = string.Format("{0}  " + itemType + "s were imported.", successCount);
						messageText2 = string.Format("{0}  " + itemType + "s were not imported:", skipCount);
					}
					else if (successCount == 1 && skipCount == 1)
					{
						messageText1 = string.Format("1  " + itemType + " was imported.");
						messageText2 = string.Format("1  " + itemType + " was not imported:");
					}
					else if (successCount == 1 && skipCount != 1)
					{
						messageText1 = string.Format("{0}  " + itemType + " was imported.", successCount);
						messageText2 = string.Format("{0}  " + itemType + "s were not imported:", skipCount);
					}
					else if (successCount != 1 && skipCount == 1)
					{
						messageText1 = string.Format("{0}  " + itemType + "s were imported.", successCount);
						messageText2 = string.Format("{0}  " + itemType + " was not imported:", skipCount);
					}

					//messageText = string.Format("Import operation complete.\r\n{0} lines were imported.\r\n{1} lines were not imported.", successCount, skipCount);

					//mam 050806 - rather than showing a message, show a pop-up form with a list of reasons why
					//	some items weren't imported, along with the message
					//MessageBox.Show(this, messageText, "Import Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ImportPipeNodeResultMessage importResult = new ImportPipeNodeResultMessage(gridReasons, messageText1, messageText2, itemType);
					importResult.ShowDialog(this);
					//</mam>
				}
				this.Close();
			}
			catch (Exception ex)
			{
				//MessageBox.Show(lineNumber.ToString());
				MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally 
			{
				// Clean up
				if (sqlConnection != null)
					sqlConnection.Dispose();
				//if (reader != null)
				//	reader.Close();
			}
		}

		//mam 07072011 - reworked this method to use grid row instead of pipeFields array
		//private bool ImportPipeLine(string[] pipeFields, int componentID, SqlConnection connection, ref string skipReason)
		private bool ImportPipeLine(Row gridRow, int componentID, SqlConnection connection, ref string skipReason)
		{
			Discipline[]	disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, componentID);
			DisciplinePipe	pipeDisc = null;
			PipeData		pipeData;
			int				numCols = Enum.GetValues(typeof(PipeColumns)).Length;
			int				val;
			PipeData[]		duplicates = null;

			if (disciplines[0] is DisciplinePipe)
				pipeDisc = (DisciplinePipe)disciplines[0];
			else
				pipeDisc = disciplines[1] as DisciplinePipe;

			if (pipeDisc == null)
			{
				//mam 050806 - added skipReason
				skipReason = "WAM was unable to create the pipe in the database";

				return false;
			}

			if (pipeDisc.ID == 0)
			{
				pipeDisc.InfoSetID = InfoSet.CurrentID;
				pipeDisc.ComponentID = componentID;
				pipeDisc.Save();
			}

			pipeData = new PipeData(0);
			pipeData.InfoSetID = InfoSet.CurrentID;
			pipeData.DiscPipeID = pipeDisc.ID;

			//mam 07072011 - load the default crits into the pipe
			pipeData.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();

			//mam 07072011
			string curValueString = string.Empty;

			//mam 07072011 - throw an error to test error handling
			//int testInt = 0;
			//double throwError = 1 / testInt;

			//for (int col = 0; col < numCols; col++)
			for (int col = 0; col < gridTest.Cols.Count; col++)
			{
				//mam 07072011
				curValueString = gridRow[col] == null ? "" : gridRow[col].ToString();

				switch (col)
				{
					case (int)PipeColumns.IDNumber:
						pipeData.IDNumber = gridRow[col].ToString();
						break;
					case (int)PipeColumns.Description:
						pipeData.Description = gridRow[col].ToString();
						break;
					case (int)PipeColumns.Type:
						pipeData.Type = gridRow[col].ToString();
						break;
					case (int)PipeColumns.Size:
						pipeData.Size = gridRow[col].ToString();
						break;
					case (int)PipeColumns.Length:
						pipeData.Length = Drive.Convert.StringToInt(gridRow[col].ToString());
						break;
					case (int)PipeColumns.UnitCost:
						pipeData.UnitCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 2);
						break;
					case (int)PipeColumns.InstallYear:
						pipeData.InstallYear = Drive.Convert.StringToShort(gridRow[col].ToString());
						break;

						//mam - no longer need this as OriginalENR is calculated based on installation year
						//case (int)PipeColumns.OriginalENR:
						//	pipeData.OriginalENR = Drive.Convert.StringToInt(pipeFields[col]);
						//	break;
						//</mam>

					case (int)PipeColumns.ReplaceVal:
						pipeData.ReplacementValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)PipeColumns.SalvageVal:
						pipeData.SalvageValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)PipeColumns.AnnualMaintCost:
						pipeData.AnnualMaintCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)PipeColumns.ConditionRank:
						//mam - added N/A
						if (gridRow[col].ToString().ToUpper() == "N/A" || gridRow[col].ToString().ToUpper() == "NA")
						{
							val = -1;
							pipeData.ConditionRank = (CondRank)val;
						}
						else
							//</mam>
						{
							val = Drive.Convert.StringToInt(gridRow[col].ToString());
							if (val > 5)
								val = 5;
							if (val < 0)
								val = 0;
							pipeData.ConditionRank = (CondRank)val;
						}
						break;

						//mam 07072011
					case (int)PipeColumns.Crit1:
					{
						if (curValueString == "" || arrayListCriticalities.Count < 1)
						{
							//there is no value to import, or there is no criticality at the number 1 position
							//the default criticality factor value will be used if there is a criticality 1
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(1, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								//string test = pipeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor.Score.ToString();
								//test = pipeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor.ScoreId.ToString();
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor = critFactor;
								//test = pipeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor.Score.ToString();
								//test = pipeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor.ScoreId.ToString();
							}
						}
						
						break;
					}
					case (int)PipeColumns.Crit2:
//						critScore = GetCritScoreFromImportData(2, curValueString, ref isValid);
//						if (isValid && critScore == -1)
//						{
//						}
//						else if (isValid)
//						{
//							pipeData.Crit2 = critScore;
//						}
//						else
//						{
//							skipReason = "Invalid Criticality value";
//							return false;
//						}
//						break;
						if (curValueString == "" || arrayListCriticalities.Count < 2)
						{
							//there is no value to import, or there is no criticality at the number 2 position
							//the default criticality factor value will be used if there is a criticality 2
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(2, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(1).CritFactor = critFactor;
							}
						}
						break;
					case (int)PipeColumns.Crit3:
						if (curValueString == "" || arrayListCriticalities.Count < 3)
						{
							//there is no value to import, or there is no criticality at the number 3 position
							//the default criticality factor value will be used if there is a criticality 3
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(3, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(2).CritFactor = critFactor;
							}
						}
						break;
					case (int)PipeColumns.Crit4:
						if (curValueString == "" || arrayListCriticalities.Count < 4)
						{
							//there is no value to import, or there is no criticality at the number 4 position
							//the default criticality factor value will be used if there is a criticality 4
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(4, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(3).CritFactor = critFactor;
							}
						}
						break;
					case (int)PipeColumns.Crit5:
						if (curValueString == "" || arrayListCriticalities.Count < 5)
						{
							//there is no value to import, or there is no criticality at the number 5 position
							//the default criticality factor value will be used if there is a criticality 5
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(5, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(4).CritFactor = critFactor;
							}
						}
						break;
					case (int)PipeColumns.Crit6:
						if (curValueString == "" || arrayListCriticalities.Count < 6)
						{
							//there is no value to import, or there is no criticality at the number 6 position
							//the default criticality factor value will be used if there is a criticality 6
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(6, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								pipeData.ComponentSelectedCriticalityFactorsCollection.Item(5).CritFactor = critFactor;
							}
						}
						break;
						//</mam>

						//mam 07072011 - no longer using four fixed crits
						//case (int)PipeColumns.CritHealth:
						//	//mam - added Trim()
						//	pipeData.CritPublicHealth = EnumHandlers.CritHealthFromString(pipeFields[col].Trim());
						//	break;
						//case (int)PipeColumns.CritEnv:
						//	//mam - added Trim()
						//	pipeData.CritEnvironmental = EnumHandlers.CritEnvFromString(pipeFields[col].Trim());
						//	break;
						//case (int)PipeColumns.CritCost:
						//	//mam
						//	//original code:
						//	//pipeData.CritRepair = EnumHandlers.CritRepairCostFromString(pipeFields[col]);
						//	//new code:
						//	tempString = pipeFields[col].Trim();
						//	if (builder.Length != 0)
						//	{
						//		builder.Remove(0, builder.Length);
						//	}
						//	if (tempString.Substring(0, 1) == "\"")
						//	{
						//		builder.Append(tempString.Substring(1, tempString.Length - 1));
						//	}
						//	if (tempString.Substring(tempString.Length-1, 1) == "\"")
						//	{
						//		builder.Remove(builder.Length-1, 1);
						//	}
						//	pipeData.CritRepair = EnumHandlers.CritRepairCostFromString(builder.ToString());
						//	//</mam>
						//	break;
						//case (int)PipeColumns.CritCustEffect:
						//	//mam - added Trim()
						//	pipeData.CritCustEffect = EnumHandlers.CritCustEffectFromString(pipeFields[col].Trim());
						//	break;

					case (int)PipeColumns.Vulnerability:
						//mam - vulnerability has been changed from a year to a probability.
						//	If the value to be imported is a year, convert it into a probability

						//original code:
						//pipeData.Vulnerability = EnumHandlers.VulnerabilityFromShort(
						//	Drive.Convert.StringToShort(pipeFields[col]));

						//new code:
						double tempVuln = Drive.Convert.StringToDouble(gridRow[col].ToString());

						//if vulnerability is blank, then it will be calculated automatically (i.e., override = false)
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							pipeData.OverrideVulnerability = false;
						}
						else
						{
							//vulnerability has a value, so use it instead of the automatic calculation
							pipeData.OverrideVulnerability = true;

							if (tempVuln < 1)
							{
								//the value is zero or is a probability
								pipeData.Vulnerability2 = Math.Round(tempVuln, 4);
							}
							else
							{
								//the value is >= 1, so it is a year; convert it to the associated probability
								pipeData.Vulnerability2 = EnumHandlers.GetVulnerabilityValue(
									EnumHandlers.VulnerabilityFromShort(
									Drive.Convert.StringToShort(gridRow[col].ToString())));
							}
						}
						break;
					case (int)PipeColumns.LevelOfService:
						val = Drive.Convert.StringToInt(gridRow[col].ToString());
						if (val > 5)
							val = 5;
						if (val < 0)
							val = 0;
						pipeData.LevelOfService = (LevelOfService)val;
						break;
					case (int)PipeColumns.OriginalUL:
						pipeData.OrgUsefulLife = Drive.Convert.StringToShort(gridRow[col].ToString());
						break;

						//mam 050806 - added AC, CV, Repl Value Year, Rehab, Repair, Redundant Assets
					case (int)PipeColumns.AcquisitionCost:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							pipeData.OverrideAcquisitionCost = false;
						}
						else
						{
							pipeData.OverrideAcquisitionCost = true;
							pipeData.AcquisitionCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;
					case (int)PipeColumns.CurrentValue:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							pipeData.OverrideCurrentValue = false;
						}
						else
						{
							pipeData.OverrideCurrentValue = true;
							pipeData.CurrentValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;
					case (int)PipeColumns.ReplacementValueYear:
						if (gridRow[col].ToString().Trim().ToString() != "")
						{
							pipeData.ReplacementValueYear = Drive.Convert.StringToShort(gridRow[col].ToString());
						}
						break;
					case (int)PipeColumns.RehabCost:
						pipeData.RehabCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)PipeColumns.RepairCost:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							pipeData.OverrideRepairCost = false;
						}
						else
						{
							pipeData.OverrideRepairCost = true;
							pipeData.RepairCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;
					case (int)PipeColumns.RedundantAssets:
						//if (pipeFields[col].Trim().ToString() == "" || Drive.Convert.StringToInt == 0)
						//{
						//	pipeData.RedundantAssetCount = 1;
						//}
						//else
						//{
						pipeData.RedundantAssetCount = Drive.Convert.StringToInt(gridRow[col].ToString());
						//}
						if (pipeData.RedundantAssetCount == 0)
						{
							pipeData.RedundantAssetCount = 1;
						}
						break;
				}
			}

			//mam - if vulnerability is not overridden, calculate it
			if (!pipeData.OverrideVulnerability)
			{
				pipeData.Vulnerability2 = pipeData.GetVulnerability();
			}
			//</mam>

			// Check for duplicates
			if (pipeData.IDNumber.Length > 0)
			{
				duplicates = PipeData.LoadForDisciplineAndPipeID(
					pipeData.DiscPipeID, pipeData.IDNumber);

				if (duplicates.Length > 0)
				{
					//mam 050806 - added skipReason
					skipReason = "Duplicate";

					// duplicate; ignore (return none found)
					return false;
				}
			}

			if (pipeData.Save())
			{
				//mam 07072011
				return pipeData.SaveCriticalityValuesAll();
			}

			return false;
		}

		//mam 07072011
		private CriticalityFactor ValidateCriticality(int critNumber, string curValueString)
		{
			CriticalityFactor critFactor = null;
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				if (((Criticality)arrayListCriticalities[i]).CriticalityNumber == critNumber)
				{
					Criticality crit = (Criticality)arrayListCriticalities[i];

					//check whether curValueString is an integer
					if (Common.CommonTasks.IsNumericInteger(curValueString))
					{
						//the value is a factor score
						int curValueInt = Convert.ToInt32(curValueString);

						//see if it is matches a criticality factor score
						critFactor = crit.CriticalityFactors.ItemByScoreNotCopy(curValueInt);
					}
					else
					{
						//the value is a factor name
						//see if it is matches a criticality factor name
						critFactor = crit.CriticalityFactors.ItemByNameNotCopy(curValueString);
					}

					break;
				}
			}

			return critFactor;
		}

		//mam 07072011 - new method - decided not to use it
//		private int GetCritScoreFromImportData(int critNumber, string critValue, ref bool isValid)
//		{
//			isValid = true;
//			//Criticality crit = Common.CommonTasks.Criticalities.Item(critNumber);
//			Criticality crit = Common.CommonTasks.Criticalities.GetCriticalityByNumber(critNumber);
//
//			if (crit == null)
//			{
//				return -1;
//			}
//			
//			int defaultScore = crit.CriticalityFactors.GetDefaultScore();
//
//			//if the crit value is blank, return the default score
//			if (critValue == "")
//			{
//				return defaultScore;
//			}
//
//			//check whether curValueString is an integer
//			if (Common.CommonTasks.IsNumericInteger(critValue))
//			{
//				int critValueInt = Convert.ToInt32(critValue);
//				if (crit.CriticalityFactors.GetListScores().Contains(critValueInt))
//				{
//					return critValueInt;
//				}
//			}
//			else
//			{
//				//curValueString is not an integer - compare it to the crit factor names
//				foreach (CriticalityFactor factor in crit.CriticalityFactors)
//				{
//					//if (valueToTest == comboBoxValue
//					//	|| (comboBoxValue.Length >= valueToTest.Length 
//					//	&& valueToTest == comboBoxValue.Substring(0, valueToTest.Length)))
//					if (string.Compare(critValue, factor.FactorName, true) == 0)
//					{
//						return factor.Score;
//					}
//				}
//			}
//
//			isValid = false;
//			return defaultScore;
//		}

		//mam 050806 - added ref string skipReason
		//mam 102309
		//mam 07072011 - reworked this method to use grid row instead of nodeFields array
		//private bool ImportNodeLine(string[] nodeFields, int componentID, SqlConnection connection, ref string skipReason)
		private bool ImportNodeLine(Row gridRow, int componentID, SqlConnection connection, ref string skipReason)
			{
			Discipline[]	disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, componentID);
			DisciplineNode	nodeDisc = null;
			NodeData		nodeData;
			int				numCols = Enum.GetValues(typeof(NodeColumns)).Length;
			int				val;
			NodeData[]		duplicates = null;

			if (disciplines[0] is DisciplineNode)
				nodeDisc = (DisciplineNode)disciplines[0];
			else
				nodeDisc = disciplines[1] as DisciplineNode;

			if (nodeDisc == null)
			{
				//mam 050806 - added skipReason
				skipReason = "WAM was unable to create the node in the database";

				return false;
			}

			if (nodeDisc.ID == 0)
			{
				nodeDisc.InfoSetID = InfoSet.CurrentID;
				nodeDisc.ComponentID = componentID;
				nodeDisc.Save();
			}

			nodeData = new NodeData(0);
			nodeData.InfoSetID = InfoSet.CurrentID;
			nodeData.DiscNodeID = nodeDisc.ID;

			//mam 07072011 - load the default crits into the pipe
			nodeData.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesDefaultIntoCollection();

			//mam 07072011
			string curValueString = string.Empty;

			//mam 07072011 - throw an error to test error handling
			//int testInt = 0;
			//double throwError = 1 / testInt;

			//for (int col = 0; col < numCols; col++)
			for (int col = 0; col < gridTest.Cols.Count; col++)
			{
				//mam 07072011
				curValueString = gridRow[col] == null ? "" : gridRow[col].ToString();

				switch (col)
				{
					case (int)NodeColumns.IDNumber:
						nodeData.IDNumber = gridRow[col].ToString();
						break;
					case (int)NodeColumns.Description:
						nodeData.Description = gridRow[col].ToString();
						break;
					case (int)NodeColumns.Type:
						nodeData.Type = gridRow[col].ToString();
						break;
					case (int)NodeColumns.Size:
						nodeData.Size = gridRow[col].ToString();
						break;
					case (int)NodeColumns.InstallYear:
						nodeData.InstallYear = Drive.Convert.StringToShort(gridRow[col].ToString());
						break;

					//mam - no longer need this as OriginalENR is calculated based on installation year
					//case (int)NodeColumns.OriginalENR:
					//	nodeData.OriginalENR = Drive.Convert.StringToInt(gridRow[col].ToString());
					//	break;
					//</mam>

					//mam 050806 - changed Acquisition Cost
					//case (int)NodeColumns.AcquisitionCost:
					//	nodeData.AcquisitionCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
					//	break;

					case (int)NodeColumns.AcquisitionCost:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							nodeData.OverrideAcquisitionCost = false;
						}
						else
						{
							nodeData.OverrideAcquisitionCost = true;
							nodeData.AcquisitionCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;

					case (int)NodeColumns.ReplaceVal:
						nodeData.ReplacementValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)NodeColumns.SalvageVal:
						nodeData.SalvageValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)NodeColumns.AnnualMaintCost:
						nodeData.AnnualMaintCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)NodeColumns.ConditionRank:
						//mam - added N/A
						if (gridRow[col].ToString().ToUpper() == "N/A" || gridRow[col].ToString().ToUpper() == "NA")
						{
							val = -1;
							nodeData.ConditionRank = (CondRank)val;
						}
						else
						//</mam>
						{
							val = Drive.Convert.StringToInt(gridRow[col].ToString());
							if (val > 5)
								val = 5;
							if (val < 0)
								val = 0;
							nodeData.ConditionRank = (CondRank)val;
						}
						break;

					//mam 07072011
					case (int)NodeColumns.Crit1:
					{
						if (curValueString == "" || arrayListCriticalities.Count < 1)
						{
							//there is no value to import, or there is no criticality at the number 1 position
							//the default criticality factor value will be used if there is a criticality 1
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(1, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(0).CritFactor = critFactor;
							}
						}
						
						break;
					}
					case (int)NodeColumns.Crit2:
						if (curValueString == "" || arrayListCriticalities.Count < 2)
						{
							//there is no value to import, or there is no criticality at the number 2 position
							//the default criticality factor value will be used if there is a criticality 2
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(2, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(1).CritFactor = critFactor;
							}
						}
						break;
					case (int)NodeColumns.Crit3:
						if (curValueString == "" || arrayListCriticalities.Count < 3)
						{
							//there is no value to import, or there is no criticality at the number 3 position
							//the default criticality factor value will be used if there is a criticality 3
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(3, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(2).CritFactor = critFactor;
							}
						}
						break;
					case (int)NodeColumns.Crit4:
						if (curValueString == "" || arrayListCriticalities.Count < 4)
						{
							//there is no value to import, or there is no criticality at the number 4 position
							//the default criticality factor value will be used if there is a criticality 4
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(4, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(3).CritFactor = critFactor;
							}
						}
						break;
					case (int)NodeColumns.Crit5:
						if (curValueString == "" || arrayListCriticalities.Count < 5)
						{
							//there is no value to import, or there is no criticality at the number 5 position
							//the default criticality factor value will be used if there is a criticality 5
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(5, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(4).CritFactor = critFactor;
							}
						}
						break;
					case (int)NodeColumns.Crit6:
						if (curValueString == "" || arrayListCriticalities.Count < 6)
						{
							//there is no value to import, or there is no criticality at the number 6 position
							//the default criticality factor value will be used if there is a criticality 6
							//otherwise, no value will be imported
						}
						else
						{
							CriticalityFactor critFactor = ValidateCriticality(6, curValueString);

							//if the value to import is valid, set the imported crit factor as the selected crit factor
							if (critFactor == null)
							{
								skipReason = "Invalid Criticality value";
								return false;
							}
							else
							{
								nodeData.ComponentSelectedCriticalityFactorsCollection.Item(5).CritFactor = critFactor;
							}
						}
						break;
						//</mam>

					//mam 07072011 - no longer using four fixed crits
					//case (int)NodeColumns.CritHealth:
					//	//mam - added Trim()
					//	nodeData.CritPublicHealth = EnumHandlers.CritHealthFromString(gridRow[col].ToString().Trim());
					//	break;
					//case (int)NodeColumns.CritEnv:
					//	//mam - added Trim()
					//	nodeData.CritEnvironmental = EnumHandlers.CritEnvFromString(gridRow[col].ToString().Trim());
					//	break;
					//case (int)NodeColumns.CritCost:
					//	//mam
					//	//original code:
					//	//nodeData.CritRepair = EnumHandlers.CritRepairCostFromString(gridRow[col].ToString());
					//	//new code:
					//	tempString = gridRow[col].ToString().Trim();
					//	if (builder.Length != 0)
					//	{
					//		builder.Remove(0, builder.Length);
					//	}
					//
					//	if (tempString.Substring(0, 1) == "\"")
					//	{
					//		builder.Append(tempString.Substring(1, tempString.Length - 1));
					//	}
					//	if (tempString.Substring(tempString.Length-1, 1) == "\"")
					//	{
					//		builder.Remove(builder.Length-1, 1);
					//	}
					//	nodeData.CritRepair = EnumHandlers.CritRepairCostFromString(builder.ToString());
					//	//</mam>
					//	break;
					//case (int)NodeColumns.CritCustEffect:
					//	//mam - added Trim()
					//	nodeData.CritCustEffect = EnumHandlers.CritCustEffectFromString(gridRow[col].ToString().Trim());
					//	break;

					case (int)NodeColumns.Vulnerability:
						//mam - vulnerability has been changed from a year to a probability.
						//	If the value to be imported is a year, convert it into a probability

						//original code:
						//nodeData.Vulnerability = EnumHandlers.VulnerabilityFromShort(
						//	Drive.Convert.StringToShort(gridRow[col].ToString()));

						//new code:
						double tempVuln = Drive.Convert.StringToDouble(gridRow[col].ToString());

						//if vulnerability is blank, then it will be calculated automatically (i.e., override = false)
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							nodeData.OverrideVulnerability = false;
						}
						else
						{
							//vulnerability has a value, so use it instead of the automatic calculation
							nodeData.OverrideVulnerability = true;

							if (tempVuln < 1)
							{
								//the value is zero or is a probability
								nodeData.Vulnerability2 = Math.Round(tempVuln, 4);
							}
							else
							{
								//the value is >= 1, so it is a year; convert it to the associated probability
								nodeData.Vulnerability2 = EnumHandlers.GetVulnerabilityValue(
									EnumHandlers.VulnerabilityFromShort(
									Drive.Convert.StringToShort(gridRow[col].ToString())));
							}
						}
						break;
					case (int)NodeColumns.LevelOfService:
						val = Drive.Convert.StringToInt(gridRow[col].ToString());
						if (val > 5)
							val = 5;
						if (val < 0)
							val = 0;
						nodeData.LevelOfService = (LevelOfService)val;
						break;
					case (int)NodeColumns.OriginalUL:
						nodeData.OrgUsefulLife = Drive.Convert.StringToShort(gridRow[col].ToString());
						break;

					//mam 050806 - added CV, Repl Value Year, Rehab, Repair, Redundant Assets
					case (int)NodeColumns.CurrentValue:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							nodeData.OverrideCurrentValue = false;
						}
						else
						{
							nodeData.OverrideCurrentValue = true;
							nodeData.CurrentValue = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;
					case (int)NodeColumns.ReplacementValueYear:
						if (gridRow[col].ToString().Trim().ToString() != "")
						{
							nodeData.ReplacementValueYear = Drive.Convert.StringToShort(gridRow[col].ToString());
						}
						break;
					case (int)NodeColumns.RehabCost:
						nodeData.RehabCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						break;
					case (int)NodeColumns.RepairCost:
						if (gridRow[col].ToString().Trim().ToString() == "")
						{
							nodeData.OverrideRepairCost = false;
						}
						else
						{
							nodeData.OverrideRepairCost = true;
							nodeData.RepairCost = Math.Round(Drive.Convert.DollarStringToDecimal(gridRow[col].ToString()), 0);
						}
						break;
					case (int)NodeColumns.RedundantAssets:
						nodeData.RedundantAssetCount = Drive.Convert.StringToInt(gridRow[col].ToString());
						if (nodeData.RedundantAssetCount == 0)
						{
							nodeData.RedundantAssetCount = 1;
						}
						break;
				}
			}

			//mam - if vulnerability is not overridden, calculate it
			if (!nodeData.OverrideVulnerability)
			{
				nodeData.Vulnerability2 = nodeData.GetVulnerability();
			}
			//</mam>

			// Check for duplicates
			if (nodeData.IDNumber.Length > 0)
			{
				duplicates = NodeData.LoadForDisciplineAndNodeID(
					nodeData.DiscNodeID, nodeData.IDNumber);

				if (duplicates.Length > 0)
				{
					//mam 050806 - added skipReason
					skipReason = "Duplicate";

					// duplicate; ignore (return none found)
					return false;
				}
			}

			//mam 07072011
			//return nodeData.Save();
			if (nodeData.Save())
			{
				return nodeData.SaveCriticalityValuesAll();
			}

			return false;
		}


		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingData.htm");
		}

		private void ImportPipeNodeForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		//mam
		private void ImportPipeNodeForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				e.Handled = true;
				this.Close();
			}
		}
		//</mam>
	}
}