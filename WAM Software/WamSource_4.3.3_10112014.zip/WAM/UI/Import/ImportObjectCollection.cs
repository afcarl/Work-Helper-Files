using System;
using System.Collections;
using System.Collections.Specialized;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFileCollection.
	/// </summary>
	public class ImportFromTextFileCollection : CollectionBase
	{
		public ListDictionary listFacility = new ListDictionary();
		public ListDictionary listProcess = new ListDictionary();
		public ListDictionary listComponent = new ListDictionary();
		public ListDictionary listComponentPN = new ListDictionary();
		public ListDictionary listDiscipline = new ListDictionary();
		//public ArrayList arrayListTest = new ArrayList();

		public ImportFromTextFileCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public virtual int Add(ImportFromTextFileFacility facility)
		{
//			//forward our Add method on to CollectionBase.IList.Add   
//			this.List.Add(facility);
//			//return this.Count;
//			return this.List.Count - 1;

			//forward our Add method on to CollectionBase.IList.Add   
			this.List.Add(facility);
			listFacility.Add(facility.TempID, facility);
			return listFacility.Count - 1;
		}

		public virtual int RemoveFacility(int tempIDKey)
		{
			listFacility.Remove(tempIDKey);
			return listFacility.Count - 1;
		}

		public virtual int Add(ImportFromTextFileProcess process)
		{
//			//forward our Add method on to CollectionBase.IList.Add   
//			this.List.Add(process);
//			//return this.Count;
//			return this.List.Count - 1;

			//forward our Add method on to CollectionBase.IList.Add   
			//this.List.Add(process);
			listProcess.Add(process.TempID, process);
			return listProcess.Count - 1;
		}

		public virtual int RemoveProcess(int tempIDKey)
		{
			listProcess.Remove(tempIDKey);
			return listProcess.Count - 1;
		}

		//this is the indexer (readonly)
		public virtual ImportFromTextFileFacility this[int Index]
		{
			get
			{
				//return the item at IList[Index]
				return (ImportFromTextFileFacility)this.List[Index];
			}
		}
	}
}
