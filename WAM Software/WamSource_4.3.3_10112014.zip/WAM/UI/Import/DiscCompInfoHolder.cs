using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for DiscCompInfoHolder.
	/// </summary>
	public class DiscCompInfoHolder : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		private WAM.UI.Import.ImportDiscInfoMech importDiscInfoMech1;
		private System.Windows.Forms.Button buttonOK;
		private ImportFromTextFileDiscipline discipline;
		private WAM.UI.Import.ImportDiscInfoLand importDiscInfoLand1;
		private WAM.UI.Import.ImportDiscInfoStruct importDiscInfoStruct1;
		private System.Windows.Forms.Button buttonCancel;
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public DiscCompInfoHolder()
		{
			InitializeComponent();
		}

//		public DiscCompInfoHolder(WAM.Data.DisciplineMech disciplineMech)
//		{
//			InitializeComponent();
//			this.disciplineMech = disciplineMech;
//		}
		public DiscCompInfoHolder(ImportFromTextFileDiscipline discipline)
		{
			InitializeComponent();
			this.discipline = discipline;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(DiscCompInfoHolder));
			this.importDiscInfoMech1 = new WAM.UI.Import.ImportDiscInfoMech();
			this.buttonOK = new System.Windows.Forms.Button();
			this.importDiscInfoLand1 = new WAM.UI.Import.ImportDiscInfoLand();
			this.importDiscInfoStruct1 = new WAM.UI.Import.ImportDiscInfoStruct();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// importDiscInfoMech1
			// 
			this.importDiscInfoMech1.BackColor = System.Drawing.Color.White;
			this.importDiscInfoMech1.Location = new System.Drawing.Point(0, 0);
			this.importDiscInfoMech1.Name = "importDiscInfoMech1";
			this.importDiscInfoMech1.Size = new System.Drawing.Size(112, 88);
			this.importDiscInfoMech1.TabIndex = 0;
			this.importDiscInfoMech1.Visible = false;
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.Location = new System.Drawing.Point(425, 303);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "Save";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// importDiscInfoLand1
			// 
			this.importDiscInfoLand1.BackColor = System.Drawing.Color.White;
			this.importDiscInfoLand1.Location = new System.Drawing.Point(128, 8);
			this.importDiscInfoLand1.Name = "importDiscInfoLand1";
			this.importDiscInfoLand1.Size = new System.Drawing.Size(112, 104);
			this.importDiscInfoLand1.TabIndex = 3;
			this.importDiscInfoLand1.Visible = false;
			// 
			// importDiscInfoStruct1
			// 
			this.importDiscInfoStruct1.BackColor = System.Drawing.Color.White;
			this.importDiscInfoStruct1.Location = new System.Drawing.Point(40, 136);
			this.importDiscInfoStruct1.Name = "importDiscInfoStruct1";
			this.importDiscInfoStruct1.Size = new System.Drawing.Size(312, 136);
			this.importDiscInfoStruct1.TabIndex = 4;
			this.importDiscInfoStruct1.Visible = false;
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(512, 303);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 5;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// DiscCompInfoHolder
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(600, 334);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.importDiscInfoStruct1);
			this.Controls.Add(this.importDiscInfoLand1);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.importDiscInfoMech1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "DiscCompInfoHolder";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "DiscCompInfoHolder";
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Tasks *****/
		
		protected override void OnLoad(EventArgs e)
		{
			this.Text = "Discipline Component Info";

			if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
			{
				importDiscInfoMech1.LoadDataMech(discipline);
			}
			else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
			{
				importDiscInfoLand1.LoadDataLand(discipline);
			}
			else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
			{
				importDiscInfoStruct1.LoadDataStruct(discipline);
			}

			base.OnLoad(e);
		}

		#endregion /***** Load Tasks *****/

		#region /***** Methods *****/

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
			{
				importDiscInfoMech1.SaveDataMech(discipline);
			}
			else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
			{
				importDiscInfoLand1.SaveDataLand(discipline);
			}
			else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
			{
				importDiscInfoStruct1.SaveDataStruct(discipline);
			}

			this.Close();
		}

		#endregion /***** Methods *****/

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
