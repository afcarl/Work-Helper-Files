using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ProgressDisplayLoadExcel.
	/// </summary>
	public class ProgressDisplayLoadExcel : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		private Form parentForm = new Form();
		private double secondsRequired = 0;
		private double minutesRequired = 0;
		private int totalRowCount = 0;
		private int gridRowCount = 0;
		private System.Windows.Forms.TextBox textBoxProgressRowCount;
		private System.Windows.Forms.TextBox textBoxProgressTime;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Button buttonCancelImport;
		private System.Windows.Forms.Label labelProgressTotalTime;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBoxProgress;
		
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ProgressDisplayLoadExcel(Form parentForm, int totalRowCount, double secondsRequired, double minutesRequired)
		{
			this.parentForm = parentForm;
			this.totalRowCount = totalRowCount;
			this.secondsRequired = secondsRequired;
			this.minutesRequired = minutesRequired;
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ProgressDisplayLoadExcel));
			this.textBoxProgressRowCount = new System.Windows.Forms.TextBox();
			this.textBoxProgressTime = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.buttonCancelImport = new System.Windows.Forms.Button();
			this.labelTitle = new System.Windows.Forms.Label();
			this.labelProgressTotalTime = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxProgress = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// textBoxProgressRowCount
			// 
			this.textBoxProgressRowCount.Location = new System.Drawing.Point(154, 45);
			this.textBoxProgressRowCount.Name = "textBoxProgressRowCount";
			this.textBoxProgressRowCount.Size = new System.Drawing.Size(75, 20);
			this.textBoxProgressRowCount.TabIndex = 0;
			this.textBoxProgressRowCount.TabStop = false;
			this.textBoxProgressRowCount.Text = "";
			// 
			// textBoxProgressTime
			// 
			this.textBoxProgressTime.Location = new System.Drawing.Point(154, 69);
			this.textBoxProgressTime.Name = "textBoxProgressTime";
			this.textBoxProgressTime.Size = new System.Drawing.Size(75, 20);
			this.textBoxProgressTime.TabIndex = 1;
			this.textBoxProgressTime.TabStop = false;
			this.textBoxProgressTime.Text = "";
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label1.Location = new System.Drawing.Point(24, 46);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 15);
			this.label1.TabIndex = 174;
			this.label1.Text = "Rows Loaded:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label2.Location = new System.Drawing.Point(24, 70);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 15);
			this.label2.TabIndex = 175;
			this.label2.Text = "Time Elapsed:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// buttonCancelImport
			// 
			this.buttonCancelImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancelImport.Location = new System.Drawing.Point(87, 110);
			this.buttonCancelImport.Name = "buttonCancelImport";
			this.buttonCancelImport.Size = new System.Drawing.Size(120, 24);
			this.buttonCancelImport.TabIndex = 2;
			this.buttonCancelImport.Text = "Stop Loading Data";
			this.buttonCancelImport.Click += new System.EventHandler(this.buttonCancelImport_Click);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(294, 32);
			this.labelTitle.TabIndex = 177;
			this.labelTitle.Text = "Data Loading Progress";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelProgressTotalTime
			// 
			this.labelProgressTotalTime.BackColor = System.Drawing.Color.Transparent;
			this.labelProgressTotalTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelProgressTotalTime.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelProgressTotalTime.Location = new System.Drawing.Point(6, 120);
			this.labelProgressTotalTime.Name = "labelProgressTotalTime";
			this.labelProgressTotalTime.Size = new System.Drawing.Size(280, 15);
			this.labelProgressTotalTime.TabIndex = 179;
			this.labelProgressTotalTime.Text = "Total Time Required:";
			this.labelProgressTotalTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.labelProgressTotalTime.Visible = false;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(294, 3);
			this.panelSeparator.TabIndex = 180;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label3.Location = new System.Drawing.Point(6, 102);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(280, 15);
			this.label3.TabIndex = 181;
			this.label3.Text = "Total Time Required:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label3.Visible = false;
			// 
			// textBoxProgress
			// 
			this.textBoxProgress.Location = new System.Drawing.Point(11, 42);
			this.textBoxProgress.Multiline = true;
			this.textBoxProgress.Name = "textBoxProgress";
			this.textBoxProgress.Size = new System.Drawing.Size(272, 56);
			this.textBoxProgress.TabIndex = 182;
			this.textBoxProgress.TabStop = false;
			this.textBoxProgress.Text = "";
			// 
			// ProgressDisplayLoadExcel
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(294, 152);
			this.ControlBox = false;
			this.Controls.Add(this.textBoxProgress);
			this.Controls.Add(this.buttonCancelImport);
			this.Controls.Add(this.labelProgressTotalTime);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBoxProgressTime);
			this.Controls.Add(this.textBoxProgressRowCount);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ProgressDisplayLoadExcel";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ProgressDisplayLoadExcel";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ProgressDisplayLoadExcel_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{
			this.CenterToParent();
			this.Text = "Loading Progress";

			gridRowCount = 0;
			labelProgressTotalTime.Text = string.Format("{0}  minutes  {1}  seconds", minutesRequired.ToString(), secondsRequired.ToString());

			//let's comment these so they don't get used
			//((ImportFromTextFile)parentForm).StartImportThreadExcelLoad();
			//((ImportFromTextFile)parentForm).LoadExcelFileThread();

			textBoxProgressRowCount.ReadOnly = true;
			textBoxProgressTime.ReadOnly = true;
			textBoxProgressRowCount.BackColor = SystemColors.Window;
			textBoxProgressTime.BackColor = SystemColors.Window;

			textBoxProgress.ReadOnly = true;
			textBoxProgress.BackColor = SystemColors.Window;

			//buttonCancelImport.Focus();

			base.OnLoad(e);
		}

		public void UpdateCounter(TimeSpan elapsedTime)
		{
			textBoxProgress.Visible = false;
			gridRowCount++;
			textBoxProgressRowCount.Text = string.Format("{0} of {1}", gridRowCount.ToString(), totalRowCount.ToString());
			textBoxProgressTime.Text = string.Format("{0}:{1}", elapsedTime.Minutes.ToString(), elapsedTime.Seconds.ToString().PadLeft(2, '0'));
			this.Refresh();
		}

		public void UpdateText(string progressMessage)
		{
			textBoxProgress.Visible = true;
			textBoxProgress.Text = progressMessage;
			this.Refresh();
		}

		private void buttonCancelImport_Click(object sender, System.EventArgs e)
		{
			DialogResult dialogResult = DialogResult.No;
			try
			{
				dialogResult = MessageBox.Show("Stop loading data?", "Stop Loading Data?", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
					
				if (dialogResult == DialogResult.Yes)
				{
					((ImportFromTextFile)parentForm).CancelImport();
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred while stopping the loading of data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally
			{
				if (dialogResult == DialogResult.Yes)
				{
					this.Close();
				}
			}
		}

		private void ProgressDisplayLoadExcel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
	}
}
