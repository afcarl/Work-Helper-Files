using System;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFileProcess.
	/// </summary>
	public class ImportFromTextFileProcess
	{
		#region /***** Member Variables *****/

		private int		infoSetID = 0;
		private int		existingID = 0;
		private int		tempID = 0;
		private int		facilityID = 0;
		private bool	importThisItem = false;
		private string	itemName = "New Process";
		private string	comments = "";
		private bool	parentExists = false;

		//mam 03202012
		private string photoFileName = "";
		private string photoCaption = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportFromTextFileProcess()
		{
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Properties *****/

		public int InfoSetID
		{
			get { return infoSetID; }
			set { infoSetID = value; }
		}

		public int ExistingID
		{
			get { return existingID; }
			set { existingID = value; }
		}

		public int TempID
		{
			get { return tempID; }
			set { tempID = value; }
		}

		public int FacilityID
		{
			get { return facilityID; }
			set { facilityID = value; }
		}

		public string ItemName
		{
			get { return itemName; }
			set
			{
				if (value.Length > 255)
					itemName = value.Substring(255);
				else
					itemName = value;
			}
		}

		public string		Comments
		{
			get { return comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					comments = value.Substring(Int16.MaxValue);
				else
					comments = value;
			}
		}

		public bool ImportThisItem
		{
			get { return importThisItem; }
			set { importThisItem = value; }
		}

		public bool ParentExists
		{
			get { return parentExists; }
			set { parentExists = value; }
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return photoFileName; }
			set
			{
				if (value.Length > 255)
				{
					photoFileName = value.Substring(255);
				}
				else
				{
					photoFileName = value;
				}
			}
		}

		//mam 03202012
		public string PhotoCaption
		{
			get { return photoCaption; }
			set
			{
				if (value.Length > 255)
				{
					photoCaption = value.Substring(255);
				}
				else
				{
					photoCaption = value;
				}
			}
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		public override string ToString()
		{
			return this.itemName;
		}

		#endregion /***** Methods *****/

	}
}
