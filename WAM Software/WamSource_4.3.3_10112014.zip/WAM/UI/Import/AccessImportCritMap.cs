using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Configuration;
using Drive.Collections;
using System.Data;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for AccessImportCritMap.
	/// </summary>
	public class AccessImportCritMap : System.Windows.Forms.Form
	{
		//private MainForm.ContinueAccessImport continueAccessImport;
		public delegate void AccessImportDelegate(bool test);
		public event AccessImportDelegate AllowAccessImport;
		//private int[] scores = new int[] {1, 4, 7, 10};

		#region /***** Windows Variables *****/

		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Panel panelTitle;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.ComboBox comboBoxPublicHealth;
		private System.Windows.Forms.Label labelAccessPublicHealth;
		private System.Windows.Forms.Label labelAccessPublicHealth1;
		private System.Windows.Forms.Label labelAccessPublicHealth2;
		private System.Windows.Forms.Label labelAccessPublicHealth3;
		private System.Windows.Forms.Label labelAccessPublicHealth4;
		private System.Windows.Forms.ComboBox comboBoxPublicHealth1;
		private System.Windows.Forms.ComboBox comboBoxPublicHealth2;
		private System.Windows.Forms.ComboBox comboBoxPublicHealth3;
		private System.Windows.Forms.ComboBox comboBoxPublicHealth4;
		private System.Windows.Forms.ComboBox comboBoxEnvironmental3;
		private System.Windows.Forms.ComboBox comboBoxEnvironmental2;
		private System.Windows.Forms.ComboBox comboBoxEnvironmental1;
		private System.Windows.Forms.Label labelAccessEnvironmental3;
		private System.Windows.Forms.Label labelAccessEnvironmental2;
		private System.Windows.Forms.Label labelAccessEnvironmental1;
		private System.Windows.Forms.Label labelAccessEnvironmental;
		private System.Windows.Forms.ComboBox comboBoxEnvironmental;
		private System.Windows.Forms.ComboBox comboBoxFinancial4;
		private System.Windows.Forms.ComboBox comboBoxFinancial3;
		private System.Windows.Forms.ComboBox comboBoxFinancial2;
		private System.Windows.Forms.ComboBox comboBoxFinancial1;
		private System.Windows.Forms.Label labelAccessFinancial4;
		private System.Windows.Forms.Label labelAccessFinancial3;
		private System.Windows.Forms.Label labelAccessFinancial2;
		private System.Windows.Forms.Label labelAccessFinancial1;
		private System.Windows.Forms.Label labelAccessFinancial;
		private System.Windows.Forms.ComboBox comboBoxFinancial;
		private System.Windows.Forms.ComboBox comboBoxCustomerEffect3;
		private System.Windows.Forms.ComboBox comboBoxCustomerEffect2;
		private System.Windows.Forms.ComboBox comboBoxCustomerEffect1;
		private System.Windows.Forms.Label labelAccessCustomerEffect3;
		private System.Windows.Forms.Label labelAccessCustomerEffect2;
		private System.Windows.Forms.Label labelAccessCustomerEffect1;
		private System.Windows.Forms.Label labelAccessCustomerEffect;
		private System.Windows.Forms.ComboBox comboBoxCustomerEffect;
		private System.Windows.Forms.Label labelInstructions1;
		private System.Windows.Forms.Label labelInstructions2;
		private System.Windows.Forms.Label labelInstructions3;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.Panel panel17;
		private System.Windows.Forms.Panel panel18;
		private System.Windows.Forms.Panel panel19;
		private System.Windows.Forms.Panel panel20;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Windows Variables *****/

		public AccessImportCritMap()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		//public static void ShowForm(MainForm owner)
		//{
		//	AccessImportCritMap form = new AccessImportCritMap();
		//	form.ShowDialog(owner);
		//}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AccessImportCritMap));
			this.labelTitle = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.panelTitle = new System.Windows.Forms.Panel();
			this.comboBoxPublicHealth = new System.Windows.Forms.ComboBox();
			this.labelAccessPublicHealth = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.labelAccessPublicHealth1 = new System.Windows.Forms.Label();
			this.labelAccessPublicHealth2 = new System.Windows.Forms.Label();
			this.labelAccessPublicHealth3 = new System.Windows.Forms.Label();
			this.labelAccessPublicHealth4 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.comboBoxPublicHealth1 = new System.Windows.Forms.ComboBox();
			this.comboBoxPublicHealth2 = new System.Windows.Forms.ComboBox();
			this.comboBoxPublicHealth3 = new System.Windows.Forms.ComboBox();
			this.comboBoxPublicHealth4 = new System.Windows.Forms.ComboBox();
			this.comboBoxEnvironmental3 = new System.Windows.Forms.ComboBox();
			this.comboBoxEnvironmental2 = new System.Windows.Forms.ComboBox();
			this.comboBoxEnvironmental1 = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.labelAccessEnvironmental3 = new System.Windows.Forms.Label();
			this.labelAccessEnvironmental2 = new System.Windows.Forms.Label();
			this.labelAccessEnvironmental1 = new System.Windows.Forms.Label();
			this.labelAccessEnvironmental = new System.Windows.Forms.Label();
			this.comboBoxEnvironmental = new System.Windows.Forms.ComboBox();
			this.comboBoxFinancial4 = new System.Windows.Forms.ComboBox();
			this.comboBoxFinancial3 = new System.Windows.Forms.ComboBox();
			this.comboBoxFinancial2 = new System.Windows.Forms.ComboBox();
			this.comboBoxFinancial1 = new System.Windows.Forms.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.labelAccessFinancial4 = new System.Windows.Forms.Label();
			this.labelAccessFinancial3 = new System.Windows.Forms.Label();
			this.labelAccessFinancial2 = new System.Windows.Forms.Label();
			this.labelAccessFinancial1 = new System.Windows.Forms.Label();
			this.labelAccessFinancial = new System.Windows.Forms.Label();
			this.comboBoxFinancial = new System.Windows.Forms.ComboBox();
			this.comboBoxCustomerEffect3 = new System.Windows.Forms.ComboBox();
			this.comboBoxCustomerEffect2 = new System.Windows.Forms.ComboBox();
			this.comboBoxCustomerEffect1 = new System.Windows.Forms.ComboBox();
			this.label20 = new System.Windows.Forms.Label();
			this.labelAccessCustomerEffect3 = new System.Windows.Forms.Label();
			this.labelAccessCustomerEffect2 = new System.Windows.Forms.Label();
			this.labelAccessCustomerEffect1 = new System.Windows.Forms.Label();
			this.labelAccessCustomerEffect = new System.Windows.Forms.Label();
			this.comboBoxCustomerEffect = new System.Windows.Forms.ComboBox();
			this.labelInstructions1 = new System.Windows.Forms.Label();
			this.labelInstructions2 = new System.Windows.Forms.Label();
			this.labelInstructions3 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel13 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.panel15 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel16 = new System.Windows.Forms.Panel();
			this.panel17 = new System.Windows.Forms.Panel();
			this.panel18 = new System.Windows.Forms.Panel();
			this.panel19 = new System.Windows.Forms.Panel();
			this.panel20 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(752, 32);
			this.labelTitle.TabIndex = 149;
			this.labelTitle.Text = " Criticality Mapping";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.Location = new System.Drawing.Point(559, 574);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(84, 23);
			this.buttonOK.TabIndex = 150;
			this.buttonOK.Text = "&OK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(655, 574);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(84, 23);
			this.buttonCancel.TabIndex = 151;
			this.buttonCancel.Text = "&Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// panelTitle
			// 
			this.panelTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelTitle.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelTitle.Location = new System.Drawing.Point(0, 32);
			this.panelTitle.Name = "panelTitle";
			this.panelTitle.Size = new System.Drawing.Size(760, 2);
			this.panelTitle.TabIndex = 152;
			// 
			// comboBoxPublicHealth
			// 
			this.comboBoxPublicHealth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxPublicHealth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxPublicHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxPublicHealth.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxPublicHealth.Location = new System.Drawing.Point(460, 148);
			this.comboBoxPublicHealth.Name = "comboBoxPublicHealth";
			this.comboBoxPublicHealth.Size = new System.Drawing.Size(264, 24);
			this.comboBoxPublicHealth.TabIndex = 153;
			// 
			// labelAccessPublicHealth
			// 
			this.labelAccessPublicHealth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessPublicHealth.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessPublicHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAccessPublicHealth.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelAccessPublicHealth.Location = new System.Drawing.Point(17, 148);
			this.labelAccessPublicHealth.Name = "labelAccessPublicHealth";
			this.labelAccessPublicHealth.Size = new System.Drawing.Size(167, 24);
			this.labelAccessPublicHealth.TabIndex = 154;
			this.labelAccessPublicHealth.Text = "Public Health and Safety";
			this.labelAccessPublicHealth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label2.Location = new System.Drawing.Point(17, 112);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 17);
			this.label2.TabIndex = 155;
			this.label2.Text = "Criticalities from Access Database";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label3.Location = new System.Drawing.Point(460, 112);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(208, 17);
			this.label3.TabIndex = 156;
			this.label3.Text = "New Criticalities";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessPublicHealth1
			// 
			this.labelAccessPublicHealth1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessPublicHealth1.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessPublicHealth1.Location = new System.Drawing.Point(32, 171);
			this.labelAccessPublicHealth1.Name = "labelAccessPublicHealth1";
			this.labelAccessPublicHealth1.Size = new System.Drawing.Size(152, 21);
			this.labelAccessPublicHealth1.TabIndex = 157;
			this.labelAccessPublicHealth1.Text = "Multiple illness or injury  (15)";
			this.labelAccessPublicHealth1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessPublicHealth2
			// 
			this.labelAccessPublicHealth2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessPublicHealth2.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessPublicHealth2.Location = new System.Drawing.Point(32, 191);
			this.labelAccessPublicHealth2.Name = "labelAccessPublicHealth2";
			this.labelAccessPublicHealth2.Size = new System.Drawing.Size(232, 21);
			this.labelAccessPublicHealth2.TabIndex = 158;
			this.labelAccessPublicHealth2.Text = "Illness or injury due to seasonal effects  (10)";
			this.labelAccessPublicHealth2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessPublicHealth3
			// 
			this.labelAccessPublicHealth3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessPublicHealth3.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessPublicHealth3.Location = new System.Drawing.Point(32, 211);
			this.labelAccessPublicHealth3.Name = "labelAccessPublicHealth3";
			this.labelAccessPublicHealth3.Size = new System.Drawing.Size(140, 21);
			this.labelAccessPublicHealth3.TabIndex = 159;
			this.labelAccessPublicHealth3.Text = "Single illness or injury  (5)";
			this.labelAccessPublicHealth3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessPublicHealth4
			// 
			this.labelAccessPublicHealth4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessPublicHealth4.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessPublicHealth4.Location = new System.Drawing.Point(32, 231);
			this.labelAccessPublicHealth4.Name = "labelAccessPublicHealth4";
			this.labelAccessPublicHealth4.Size = new System.Drawing.Size(72, 21);
			this.labelAccessPublicHealth4.TabIndex = 160;
			this.labelAccessPublicHealth4.Text = "No effect  (0)";
			this.labelAccessPublicHealth4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label8
			// 
			this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label8.Location = new System.Drawing.Point(8, 148);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(16, 24);
			this.label8.TabIndex = 161;
			this.label8.Text = "1.";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label8.Visible = false;
			// 
			// comboBoxPublicHealth1
			// 
			this.comboBoxPublicHealth1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxPublicHealth1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxPublicHealth1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxPublicHealth1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxPublicHealth1.Location = new System.Drawing.Point(475, 171);
			this.comboBoxPublicHealth1.Name = "comboBoxPublicHealth1";
			this.comboBoxPublicHealth1.Size = new System.Drawing.Size(249, 21);
			this.comboBoxPublicHealth1.TabIndex = 162;
			// 
			// comboBoxPublicHealth2
			// 
			this.comboBoxPublicHealth2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxPublicHealth2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxPublicHealth2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxPublicHealth2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxPublicHealth2.Location = new System.Drawing.Point(475, 191);
			this.comboBoxPublicHealth2.Name = "comboBoxPublicHealth2";
			this.comboBoxPublicHealth2.Size = new System.Drawing.Size(249, 21);
			this.comboBoxPublicHealth2.TabIndex = 163;
			// 
			// comboBoxPublicHealth3
			// 
			this.comboBoxPublicHealth3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxPublicHealth3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxPublicHealth3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxPublicHealth3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxPublicHealth3.Location = new System.Drawing.Point(475, 211);
			this.comboBoxPublicHealth3.Name = "comboBoxPublicHealth3";
			this.comboBoxPublicHealth3.Size = new System.Drawing.Size(249, 21);
			this.comboBoxPublicHealth3.TabIndex = 164;
			// 
			// comboBoxPublicHealth4
			// 
			this.comboBoxPublicHealth4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxPublicHealth4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxPublicHealth4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxPublicHealth4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxPublicHealth4.Location = new System.Drawing.Point(475, 231);
			this.comboBoxPublicHealth4.Name = "comboBoxPublicHealth4";
			this.comboBoxPublicHealth4.Size = new System.Drawing.Size(249, 21);
			this.comboBoxPublicHealth4.TabIndex = 165;
			// 
			// comboBoxEnvironmental3
			// 
			this.comboBoxEnvironmental3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxEnvironmental3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxEnvironmental3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxEnvironmental3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxEnvironmental3.Location = new System.Drawing.Point(475, 439);
			this.comboBoxEnvironmental3.Name = "comboBoxEnvironmental3";
			this.comboBoxEnvironmental3.Size = new System.Drawing.Size(249, 21);
			this.comboBoxEnvironmental3.TabIndex = 175;
			// 
			// comboBoxEnvironmental2
			// 
			this.comboBoxEnvironmental2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxEnvironmental2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxEnvironmental2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxEnvironmental2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxEnvironmental2.Location = new System.Drawing.Point(475, 419);
			this.comboBoxEnvironmental2.Name = "comboBoxEnvironmental2";
			this.comboBoxEnvironmental2.Size = new System.Drawing.Size(249, 21);
			this.comboBoxEnvironmental2.TabIndex = 174;
			// 
			// comboBoxEnvironmental1
			// 
			this.comboBoxEnvironmental1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxEnvironmental1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxEnvironmental1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxEnvironmental1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxEnvironmental1.Location = new System.Drawing.Point(475, 399);
			this.comboBoxEnvironmental1.Name = "comboBoxEnvironmental1";
			this.comboBoxEnvironmental1.Size = new System.Drawing.Size(249, 21);
			this.comboBoxEnvironmental1.TabIndex = 173;
			// 
			// label9
			// 
			this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label9.BackColor = System.Drawing.Color.Transparent;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label9.Location = new System.Drawing.Point(8, 376);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(16, 24);
			this.label9.TabIndex = 172;
			this.label9.Text = "3.";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label9.Visible = false;
			// 
			// labelAccessEnvironmental3
			// 
			this.labelAccessEnvironmental3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessEnvironmental3.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessEnvironmental3.Location = new System.Drawing.Point(32, 439);
			this.labelAccessEnvironmental3.Name = "labelAccessEnvironmental3";
			this.labelAccessEnvironmental3.Size = new System.Drawing.Size(72, 21);
			this.labelAccessEnvironmental3.TabIndex = 170;
			this.labelAccessEnvironmental3.Text = "No effect  (0)";
			this.labelAccessEnvironmental3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessEnvironmental2
			// 
			this.labelAccessEnvironmental2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessEnvironmental2.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessEnvironmental2.Location = new System.Drawing.Point(32, 419);
			this.labelAccessEnvironmental2.Name = "labelAccessEnvironmental2";
			this.labelAccessEnvironmental2.Size = new System.Drawing.Size(56, 21);
			this.labelAccessEnvironmental2.TabIndex = 169;
			this.labelAccessEnvironmental2.Text = "Minor  (4)";
			this.labelAccessEnvironmental2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessEnvironmental1
			// 
			this.labelAccessEnvironmental1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessEnvironmental1.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessEnvironmental1.Location = new System.Drawing.Point(32, 399);
			this.labelAccessEnvironmental1.Name = "labelAccessEnvironmental1";
			this.labelAccessEnvironmental1.Size = new System.Drawing.Size(56, 21);
			this.labelAccessEnvironmental1.TabIndex = 168;
			this.labelAccessEnvironmental1.Text = "Major  (8)";
			this.labelAccessEnvironmental1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessEnvironmental
			// 
			this.labelAccessEnvironmental.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessEnvironmental.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessEnvironmental.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAccessEnvironmental.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelAccessEnvironmental.Location = new System.Drawing.Point(17, 376);
			this.labelAccessEnvironmental.Name = "labelAccessEnvironmental";
			this.labelAccessEnvironmental.Size = new System.Drawing.Size(103, 24);
			this.labelAccessEnvironmental.TabIndex = 167;
			this.labelAccessEnvironmental.Text = "Environmental";
			this.labelAccessEnvironmental.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxEnvironmental
			// 
			this.comboBoxEnvironmental.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxEnvironmental.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxEnvironmental.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxEnvironmental.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxEnvironmental.Location = new System.Drawing.Point(460, 376);
			this.comboBoxEnvironmental.Name = "comboBoxEnvironmental";
			this.comboBoxEnvironmental.Size = new System.Drawing.Size(264, 24);
			this.comboBoxEnvironmental.TabIndex = 166;
			// 
			// comboBoxFinancial4
			// 
			this.comboBoxFinancial4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxFinancial4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFinancial4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxFinancial4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxFinancial4.Location = new System.Drawing.Point(475, 345);
			this.comboBoxFinancial4.Name = "comboBoxFinancial4";
			this.comboBoxFinancial4.Size = new System.Drawing.Size(249, 21);
			this.comboBoxFinancial4.TabIndex = 186;
			// 
			// comboBoxFinancial3
			// 
			this.comboBoxFinancial3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxFinancial3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFinancial3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxFinancial3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxFinancial3.Location = new System.Drawing.Point(475, 325);
			this.comboBoxFinancial3.Name = "comboBoxFinancial3";
			this.comboBoxFinancial3.Size = new System.Drawing.Size(249, 21);
			this.comboBoxFinancial3.TabIndex = 185;
			// 
			// comboBoxFinancial2
			// 
			this.comboBoxFinancial2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxFinancial2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFinancial2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxFinancial2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxFinancial2.Location = new System.Drawing.Point(475, 305);
			this.comboBoxFinancial2.Name = "comboBoxFinancial2";
			this.comboBoxFinancial2.Size = new System.Drawing.Size(249, 21);
			this.comboBoxFinancial2.TabIndex = 184;
			// 
			// comboBoxFinancial1
			// 
			this.comboBoxFinancial1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxFinancial1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFinancial1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxFinancial1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxFinancial1.Location = new System.Drawing.Point(475, 285);
			this.comboBoxFinancial1.Name = "comboBoxFinancial1";
			this.comboBoxFinancial1.Size = new System.Drawing.Size(249, 21);
			this.comboBoxFinancial1.TabIndex = 183;
			// 
			// label10
			// 
			this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label10.BackColor = System.Drawing.Color.Transparent;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label10.Location = new System.Drawing.Point(8, 262);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(16, 24);
			this.label10.TabIndex = 182;
			this.label10.Text = "2.";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label10.Visible = false;
			// 
			// labelAccessFinancial4
			// 
			this.labelAccessFinancial4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessFinancial4.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessFinancial4.Location = new System.Drawing.Point(32, 345);
			this.labelAccessFinancial4.Name = "labelAccessFinancial4";
			this.labelAccessFinancial4.Size = new System.Drawing.Size(112, 21);
			this.labelAccessFinancial4.TabIndex = 181;
			this.labelAccessFinancial4.Text = "Less than $5,000  (0)";
			this.labelAccessFinancial4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessFinancial3
			// 
			this.labelAccessFinancial3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessFinancial3.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessFinancial3.Location = new System.Drawing.Point(32, 325);
			this.labelAccessFinancial3.Name = "labelAccessFinancial3";
			this.labelAccessFinancial3.Size = new System.Drawing.Size(172, 21);
			this.labelAccessFinancial3.TabIndex = 180;
			this.labelAccessFinancial3.Text = "Between $5,000 and $30,000  (2)";
			this.labelAccessFinancial3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessFinancial2
			// 
			this.labelAccessFinancial2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessFinancial2.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessFinancial2.Location = new System.Drawing.Point(32, 305);
			this.labelAccessFinancial2.Name = "labelAccessFinancial2";
			this.labelAccessFinancial2.Size = new System.Drawing.Size(184, 21);
			this.labelAccessFinancial2.TabIndex = 179;
			this.labelAccessFinancial2.Text = "Between $30,000 and $100,000  (4)";
			this.labelAccessFinancial2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessFinancial1
			// 
			this.labelAccessFinancial1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessFinancial1.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessFinancial1.Location = new System.Drawing.Point(32, 285);
			this.labelAccessFinancial1.Name = "labelAccessFinancial1";
			this.labelAccessFinancial1.Size = new System.Drawing.Size(128, 21);
			this.labelAccessFinancial1.TabIndex = 178;
			this.labelAccessFinancial1.Text = "More than $100,000  (6)";
			this.labelAccessFinancial1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessFinancial
			// 
			this.labelAccessFinancial.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessFinancial.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessFinancial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAccessFinancial.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelAccessFinancial.Location = new System.Drawing.Point(17, 262);
			this.labelAccessFinancial.Name = "labelAccessFinancial";
			this.labelAccessFinancial.Size = new System.Drawing.Size(103, 24);
			this.labelAccessFinancial.TabIndex = 177;
			this.labelAccessFinancial.Text = "Cost of Repair";
			this.labelAccessFinancial.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxFinancial
			// 
			this.comboBoxFinancial.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxFinancial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFinancial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxFinancial.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxFinancial.Location = new System.Drawing.Point(460, 262);
			this.comboBoxFinancial.Name = "comboBoxFinancial";
			this.comboBoxFinancial.Size = new System.Drawing.Size(264, 24);
			this.comboBoxFinancial.TabIndex = 176;
			// 
			// comboBoxCustomerEffect3
			// 
			this.comboBoxCustomerEffect3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxCustomerEffect3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCustomerEffect3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxCustomerEffect3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxCustomerEffect3.Location = new System.Drawing.Point(475, 533);
			this.comboBoxCustomerEffect3.Name = "comboBoxCustomerEffect3";
			this.comboBoxCustomerEffect3.Size = new System.Drawing.Size(249, 21);
			this.comboBoxCustomerEffect3.TabIndex = 195;
			// 
			// comboBoxCustomerEffect2
			// 
			this.comboBoxCustomerEffect2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxCustomerEffect2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCustomerEffect2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxCustomerEffect2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxCustomerEffect2.Location = new System.Drawing.Point(475, 513);
			this.comboBoxCustomerEffect2.Name = "comboBoxCustomerEffect2";
			this.comboBoxCustomerEffect2.Size = new System.Drawing.Size(249, 21);
			this.comboBoxCustomerEffect2.TabIndex = 194;
			// 
			// comboBoxCustomerEffect1
			// 
			this.comboBoxCustomerEffect1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxCustomerEffect1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCustomerEffect1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxCustomerEffect1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxCustomerEffect1.Location = new System.Drawing.Point(475, 493);
			this.comboBoxCustomerEffect1.Name = "comboBoxCustomerEffect1";
			this.comboBoxCustomerEffect1.Size = new System.Drawing.Size(249, 21);
			this.comboBoxCustomerEffect1.TabIndex = 193;
			// 
			// label20
			// 
			this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label20.BackColor = System.Drawing.Color.Transparent;
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label20.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label20.Location = new System.Drawing.Point(8, 470);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(16, 24);
			this.label20.TabIndex = 192;
			this.label20.Text = "4.";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.label20.Visible = false;
			// 
			// labelAccessCustomerEffect3
			// 
			this.labelAccessCustomerEffect3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessCustomerEffect3.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessCustomerEffect3.Location = new System.Drawing.Point(32, 533);
			this.labelAccessCustomerEffect3.Name = "labelAccessCustomerEffect3";
			this.labelAccessCustomerEffect3.Size = new System.Drawing.Size(72, 21);
			this.labelAccessCustomerEffect3.TabIndex = 191;
			this.labelAccessCustomerEffect3.Text = "No effect  (0)";
			this.labelAccessCustomerEffect3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessCustomerEffect2
			// 
			this.labelAccessCustomerEffect2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessCustomerEffect2.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessCustomerEffect2.Location = new System.Drawing.Point(32, 513);
			this.labelAccessCustomerEffect2.Name = "labelAccessCustomerEffect2";
			this.labelAccessCustomerEffect2.Size = new System.Drawing.Size(56, 21);
			this.labelAccessCustomerEffect2.TabIndex = 190;
			this.labelAccessCustomerEffect2.Text = "Minor  (5)";
			this.labelAccessCustomerEffect2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessCustomerEffect1
			// 
			this.labelAccessCustomerEffect1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessCustomerEffect1.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessCustomerEffect1.Location = new System.Drawing.Point(32, 493);
			this.labelAccessCustomerEffect1.Name = "labelAccessCustomerEffect1";
			this.labelAccessCustomerEffect1.Size = new System.Drawing.Size(176, 21);
			this.labelAccessCustomerEffect1.TabIndex = 189;
			this.labelAccessCustomerEffect1.Text = "Major or Repeat Occurrence  (10)";
			this.labelAccessCustomerEffect1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelAccessCustomerEffect
			// 
			this.labelAccessCustomerEffect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAccessCustomerEffect.BackColor = System.Drawing.Color.Transparent;
			this.labelAccessCustomerEffect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAccessCustomerEffect.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelAccessCustomerEffect.Location = new System.Drawing.Point(17, 470);
			this.labelAccessCustomerEffect.Name = "labelAccessCustomerEffect";
			this.labelAccessCustomerEffect.Size = new System.Drawing.Size(138, 24);
			this.labelAccessCustomerEffect.TabIndex = 188;
			this.labelAccessCustomerEffect.Text = "Effect on Customers";
			this.labelAccessCustomerEffect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxCustomerEffect
			// 
			this.comboBoxCustomerEffect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.comboBoxCustomerEffect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCustomerEffect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBoxCustomerEffect.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.comboBoxCustomerEffect.Location = new System.Drawing.Point(460, 470);
			this.comboBoxCustomerEffect.Name = "comboBoxCustomerEffect";
			this.comboBoxCustomerEffect.Size = new System.Drawing.Size(264, 24);
			this.comboBoxCustomerEffect.TabIndex = 187;
			// 
			// labelInstructions1
			// 
			this.labelInstructions1.BackColor = System.Drawing.Color.Transparent;
			this.labelInstructions1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(50)), ((System.Byte)(50)), ((System.Byte)(50)));
			this.labelInstructions1.Location = new System.Drawing.Point(8, 42);
			this.labelInstructions1.Name = "labelInstructions1";
			this.labelInstructions1.Size = new System.Drawing.Size(740, 21);
			this.labelInstructions1.TabIndex = 197;
			this.labelInstructions1.Text = "Instructions";
			// 
			// labelInstructions2
			// 
			this.labelInstructions2.BackColor = System.Drawing.Color.Transparent;
			this.labelInstructions2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(50)), ((System.Byte)(50)), ((System.Byte)(50)));
			this.labelInstructions2.Location = new System.Drawing.Point(8, 62);
			this.labelInstructions2.Name = "labelInstructions2";
			this.labelInstructions2.Size = new System.Drawing.Size(740, 21);
			this.labelInstructions2.TabIndex = 198;
			this.labelInstructions2.Text = "Instructions";
			// 
			// labelInstructions3
			// 
			this.labelInstructions3.BackColor = System.Drawing.Color.Transparent;
			this.labelInstructions3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(50)), ((System.Byte)(50)), ((System.Byte)(50)));
			this.labelInstructions3.Location = new System.Drawing.Point(8, 82);
			this.labelInstructions3.Name = "labelInstructions3";
			this.labelInstructions3.Size = new System.Drawing.Size(740, 21);
			this.labelInstructions3.TabIndex = 199;
			this.labelInstructions3.Text = "Instructions";
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel1.Location = new System.Drawing.Point(18, 171);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(310, 1);
			this.panel1.TabIndex = 200;
			this.panel1.Visible = false;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel2.Location = new System.Drawing.Point(32, 191);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(295, 1);
			this.panel2.TabIndex = 201;
			this.panel2.Visible = false;
			// 
			// panel3
			// 
			this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel3.Location = new System.Drawing.Point(32, 211);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(295, 1);
			this.panel3.TabIndex = 202;
			this.panel3.Visible = false;
			// 
			// panel4
			// 
			this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel4.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel4.Location = new System.Drawing.Point(32, 231);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(295, 1);
			this.panel4.TabIndex = 203;
			this.panel4.Visible = false;
			// 
			// panel5
			// 
			this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel5.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel5.Location = new System.Drawing.Point(32, 251);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(295, 1);
			this.panel5.TabIndex = 204;
			this.panel5.Visible = false;
			// 
			// panel6
			// 
			this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel6.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel6.Location = new System.Drawing.Point(32, 365);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(295, 1);
			this.panel6.TabIndex = 209;
			this.panel6.Visible = false;
			// 
			// panel7
			// 
			this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel7.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel7.Location = new System.Drawing.Point(32, 345);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(295, 1);
			this.panel7.TabIndex = 208;
			this.panel7.Visible = false;
			// 
			// panel8
			// 
			this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel8.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel8.Location = new System.Drawing.Point(32, 325);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(295, 1);
			this.panel8.TabIndex = 207;
			this.panel8.Visible = false;
			// 
			// panel9
			// 
			this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel9.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel9.Location = new System.Drawing.Point(32, 305);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(295, 1);
			this.panel9.TabIndex = 206;
			this.panel9.Visible = false;
			// 
			// panel10
			// 
			this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel10.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel10.Location = new System.Drawing.Point(17, 285);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(310, 1);
			this.panel10.TabIndex = 205;
			this.panel10.Visible = false;
			// 
			// panel12
			// 
			this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel12.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel12.Location = new System.Drawing.Point(32, 459);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(295, 1);
			this.panel12.TabIndex = 213;
			this.panel12.Visible = false;
			// 
			// panel13
			// 
			this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel13.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel13.Location = new System.Drawing.Point(32, 439);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(295, 1);
			this.panel13.TabIndex = 212;
			this.panel13.Visible = false;
			// 
			// panel14
			// 
			this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel14.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel14.Location = new System.Drawing.Point(32, 419);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(295, 1);
			this.panel14.TabIndex = 211;
			this.panel14.Visible = false;
			// 
			// panel15
			// 
			this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel15.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel15.Location = new System.Drawing.Point(17, 399);
			this.panel15.Name = "panel15";
			this.panel15.Size = new System.Drawing.Size(310, 1);
			this.panel15.TabIndex = 210;
			this.panel15.Visible = false;
			// 
			// panel11
			// 
			this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel11.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel11.Location = new System.Drawing.Point(32, 553);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(295, 1);
			this.panel11.TabIndex = 217;
			this.panel11.Visible = false;
			// 
			// panel16
			// 
			this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel16.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel16.Location = new System.Drawing.Point(32, 533);
			this.panel16.Name = "panel16";
			this.panel16.Size = new System.Drawing.Size(295, 1);
			this.panel16.TabIndex = 216;
			this.panel16.Visible = false;
			// 
			// panel17
			// 
			this.panel17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel17.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel17.Location = new System.Drawing.Point(32, 513);
			this.panel17.Name = "panel17";
			this.panel17.Size = new System.Drawing.Size(295, 1);
			this.panel17.TabIndex = 215;
			this.panel17.Visible = false;
			// 
			// panel18
			// 
			this.panel18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panel18.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel18.Location = new System.Drawing.Point(17, 493);
			this.panel18.Name = "panel18";
			this.panel18.Size = new System.Drawing.Size(310, 1);
			this.panel18.TabIndex = 214;
			this.panel18.Visible = false;
			// 
			// panel19
			// 
			this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel19.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel19.Location = new System.Drawing.Point(-4, 134);
			this.panel19.Name = "panel19";
			this.panel19.Size = new System.Drawing.Size(760, 2);
			this.panel19.TabIndex = 218;
			// 
			// panel20
			// 
			this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel20.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel20.Location = new System.Drawing.Point(0, 106);
			this.panel20.Name = "panel20";
			this.panel20.Size = new System.Drawing.Size(760, 2);
			this.panel20.TabIndex = 219;
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
			this.label4.Location = new System.Drawing.Point(69, 171);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(400, 21);
			this.label4.TabIndex = 221;
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
			this.label5.Location = new System.Drawing.Point(69, 191);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(400, 21);
			this.label5.TabIndex = 222;
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label6
			// 
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
			this.label6.Location = new System.Drawing.Point(55, 151);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(401, 21);
			this.label6.TabIndex = 223;
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Image = ((System.Drawing.Image)(resources.GetObject("label7.Image")));
			this.label7.Location = new System.Drawing.Point(69, 211);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(400, 21);
			this.label7.TabIndex = 224;
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label11
			// 
			this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label11.BackColor = System.Drawing.Color.Transparent;
			this.label11.Image = ((System.Drawing.Image)(resources.GetObject("label11.Image")));
			this.label11.Location = new System.Drawing.Point(69, 231);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(400, 21);
			this.label11.TabIndex = 225;
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
			this.label1.Location = new System.Drawing.Point(55, 265);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(401, 21);
			this.label1.TabIndex = 226;
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label12
			// 
			this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Image = ((System.Drawing.Image)(resources.GetObject("label12.Image")));
			this.label12.Location = new System.Drawing.Point(55, 379);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(401, 21);
			this.label12.TabIndex = 227;
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label13
			// 
			this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
			this.label13.Location = new System.Drawing.Point(55, 473);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(401, 21);
			this.label13.TabIndex = 228;
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label14
			// 
			this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Image = ((System.Drawing.Image)(resources.GetObject("label14.Image")));
			this.label14.Location = new System.Drawing.Point(69, 305);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(400, 21);
			this.label14.TabIndex = 230;
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label15
			// 
			this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label15.BackColor = System.Drawing.Color.Transparent;
			this.label15.Image = ((System.Drawing.Image)(resources.GetObject("label15.Image")));
			this.label15.Location = new System.Drawing.Point(69, 325);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(400, 21);
			this.label15.TabIndex = 231;
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label16
			// 
			this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.Image = ((System.Drawing.Image)(resources.GetObject("label16.Image")));
			this.label16.Location = new System.Drawing.Point(69, 345);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(400, 21);
			this.label16.TabIndex = 232;
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label17
			// 
			this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label17.BackColor = System.Drawing.Color.Transparent;
			this.label17.Image = ((System.Drawing.Image)(resources.GetObject("label17.Image")));
			this.label17.Location = new System.Drawing.Point(69, 285);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(400, 21);
			this.label17.TabIndex = 229;
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label18
			// 
			this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label18.BackColor = System.Drawing.Color.Transparent;
			this.label18.Image = ((System.Drawing.Image)(resources.GetObject("label18.Image")));
			this.label18.Location = new System.Drawing.Point(69, 419);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(400, 21);
			this.label18.TabIndex = 234;
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label19
			// 
			this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label19.BackColor = System.Drawing.Color.Transparent;
			this.label19.Image = ((System.Drawing.Image)(resources.GetObject("label19.Image")));
			this.label19.Location = new System.Drawing.Point(69, 439);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(400, 21);
			this.label19.TabIndex = 235;
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label21
			// 
			this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label21.BackColor = System.Drawing.Color.Transparent;
			this.label21.Image = ((System.Drawing.Image)(resources.GetObject("label21.Image")));
			this.label21.Location = new System.Drawing.Point(69, 399);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(400, 21);
			this.label21.TabIndex = 233;
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label22
			// 
			this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label22.BackColor = System.Drawing.Color.Transparent;
			this.label22.Image = ((System.Drawing.Image)(resources.GetObject("label22.Image")));
			this.label22.Location = new System.Drawing.Point(69, 513);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(400, 21);
			this.label22.TabIndex = 237;
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label23
			// 
			this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label23.BackColor = System.Drawing.Color.Transparent;
			this.label23.Image = ((System.Drawing.Image)(resources.GetObject("label23.Image")));
			this.label23.Location = new System.Drawing.Point(69, 533);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(400, 21);
			this.label23.TabIndex = 238;
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label24
			// 
			this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label24.BackColor = System.Drawing.Color.Transparent;
			this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
			this.label24.Location = new System.Drawing.Point(69, 493);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(400, 21);
			this.label24.TabIndex = 236;
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// AccessImportCritMap
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(752, 606);
			this.Controls.Add(this.labelAccessFinancial);
			this.Controls.Add(this.panel20);
			this.Controls.Add(this.panel19);
			this.Controls.Add(this.panel11);
			this.Controls.Add(this.panel16);
			this.Controls.Add(this.panel17);
			this.Controls.Add(this.panel18);
			this.Controls.Add(this.panel12);
			this.Controls.Add(this.panel13);
			this.Controls.Add(this.panel14);
			this.Controls.Add(this.panel15);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel7);
			this.Controls.Add(this.panel8);
			this.Controls.Add(this.panel9);
			this.Controls.Add(this.panel10);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.labelInstructions3);
			this.Controls.Add(this.labelInstructions2);
			this.Controls.Add(this.labelInstructions1);
			this.Controls.Add(this.comboBoxCustomerEffect3);
			this.Controls.Add(this.comboBoxCustomerEffect2);
			this.Controls.Add(this.comboBoxCustomerEffect1);
			this.Controls.Add(this.labelAccessCustomerEffect3);
			this.Controls.Add(this.labelAccessCustomerEffect2);
			this.Controls.Add(this.labelAccessCustomerEffect1);
			this.Controls.Add(this.labelAccessCustomerEffect);
			this.Controls.Add(this.comboBoxCustomerEffect);
			this.Controls.Add(this.comboBoxFinancial4);
			this.Controls.Add(this.comboBoxFinancial3);
			this.Controls.Add(this.comboBoxFinancial2);
			this.Controls.Add(this.comboBoxFinancial1);
			this.Controls.Add(this.labelAccessFinancial4);
			this.Controls.Add(this.labelAccessFinancial3);
			this.Controls.Add(this.labelAccessFinancial2);
			this.Controls.Add(this.labelAccessFinancial1);
			this.Controls.Add(this.comboBoxFinancial);
			this.Controls.Add(this.comboBoxEnvironmental3);
			this.Controls.Add(this.comboBoxEnvironmental2);
			this.Controls.Add(this.comboBoxEnvironmental1);
			this.Controls.Add(this.labelAccessEnvironmental3);
			this.Controls.Add(this.labelAccessEnvironmental2);
			this.Controls.Add(this.labelAccessEnvironmental1);
			this.Controls.Add(this.labelAccessEnvironmental);
			this.Controls.Add(this.comboBoxEnvironmental);
			this.Controls.Add(this.comboBoxPublicHealth4);
			this.Controls.Add(this.comboBoxPublicHealth3);
			this.Controls.Add(this.comboBoxPublicHealth2);
			this.Controls.Add(this.comboBoxPublicHealth1);
			this.Controls.Add(this.labelAccessPublicHealth4);
			this.Controls.Add(this.labelAccessPublicHealth3);
			this.Controls.Add(this.labelAccessPublicHealth2);
			this.Controls.Add(this.labelAccessPublicHealth1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.labelAccessPublicHealth);
			this.Controls.Add(this.comboBoxPublicHealth);
			this.Controls.Add(this.panelTitle);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.label20);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.label22);
			this.Controls.Add(this.label23);
			this.Controls.Add(this.label24);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.label19);
			this.Controls.Add(this.label21);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AccessImportCritMap";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Criticality Mapping for Access Data";
			this.Load += new System.EventHandler(this.AccessImportCritMap_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.AccessImportCritMap_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		private void AccessImportCritMap_Load(object sender, System.EventArgs e)
		{
			try
			{
				this.comboBoxPublicHealth.SelectedIndexChanged += new System.EventHandler(this.comboBoxPublicHealth_SelectedIndexChanged);
				this.comboBoxFinancial.SelectedIndexChanged += new System.EventHandler(this.comboBoxFinancial_SelectedIndexChanged);
				this.comboBoxEnvironmental.SelectedIndexChanged += new System.EventHandler(this.comboBoxEnvironmental_SelectedIndexChanged);
				this.comboBoxCustomerEffect.SelectedIndexChanged += new System.EventHandler(this.comboBoxCustomerEffect_SelectedIndexChanged);

				//GetScores();
				SetControlProperties();
				SetTagData();
				PopulateCritComboBoxes();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// this assumes that the scores are the same for each criticality, which they may not be
		// the scores arraylist is used only to populate the combo boxes when the user selects a criticality - let's just
		//	get the scores for each criticality at the time we need it (in the selected index changed handler for the combos)
		private ArrayList GetScores(int critNumber)
		{
			ArrayList arrayListScores = new ArrayList();
			Common.Criticality crit = Common.CommonTasks.Criticalities.GetCriticalityByNumber(critNumber);
			foreach (Common.CriticalityFactor factor in crit.CriticalityFactors)
			{
				arrayListScores.Add(factor.Score);
			}
			arrayListScores.Sort();

			return arrayListScores;

			//for (int i = 0; i < arrayListScores.Count; i++)
			//{
			//	scores[i] = Convert.ToInt32(arrayListScores[i]);
			//}
		}

		private void SetControlProperties()
		{
			labelInstructions1.Text = "Before importing from the Access database, the Access Criticalities must be"
				+ " mapped to the new Criticalities.";
			labelInstructions2.Text = "Select the best match for each Criticality from the drop-down boxes.";
			labelInstructions3.Text = "If a drop-down box is left blank, the values for that Criticality will not"
				+ " be imported from Access.  The Criticality will be set to its default value.";

			comboBoxPublicHealth.DisplayMember = "DisplayMember";
			comboBoxPublicHealth1.DisplayMember = "DisplayMember";
			comboBoxPublicHealth2.DisplayMember = "DisplayMember";
			comboBoxPublicHealth3.DisplayMember = "DisplayMember";
			comboBoxPublicHealth4.DisplayMember = "DisplayMember";

			comboBoxFinancial.DisplayMember = "DisplayMember";
			comboBoxFinancial1.DisplayMember = "DisplayMember";
			comboBoxFinancial2.DisplayMember = "DisplayMember";
			comboBoxFinancial3.DisplayMember = "DisplayMember";
			comboBoxFinancial4.DisplayMember = "DisplayMember";

			comboBoxEnvironmental.DisplayMember = "DisplayMember";
			comboBoxEnvironmental1.DisplayMember = "DisplayMember";
			comboBoxEnvironmental2.DisplayMember = "DisplayMember";
			comboBoxEnvironmental3.DisplayMember = "DisplayMember";

			comboBoxCustomerEffect.DisplayMember = "DisplayMember";
			comboBoxCustomerEffect1.DisplayMember = "DisplayMember";
			comboBoxCustomerEffect2.DisplayMember = "DisplayMember";
			comboBoxCustomerEffect3.DisplayMember = "DisplayMember";
		}

		private void SetTagData()
		{
			string configVal = System.Configuration.ConfigurationSettings.AppSettings["AccessPublicHealth"];
			labelAccessPublicHealth.Tag = configVal == null ? "" : configVal.Trim();

			configVal = System.Configuration.ConfigurationSettings.AppSettings["AccessCostOfRepair"];
			labelAccessFinancial.Tag = configVal == null ? "" : configVal.Trim();

			configVal = System.Configuration.ConfigurationSettings.AppSettings["AccessEnvironmental"];
			labelAccessEnvironmental.Tag = configVal == null ? "" : configVal.Trim();

			configVal = System.Configuration.ConfigurationSettings.AppSettings["AccessEffectOnCustomers"];
			labelAccessCustomerEffect.Tag = configVal == null ? "" : configVal.Trim();
		}

		private void PopulateCritComboBoxes()
		{
			ClearCritComboBoxes();

			comboBoxPublicHealth.Items.Add(new ListItem("", null));
			comboBoxFinancial.Items.Add(new ListItem("", null));
			comboBoxEnvironmental.Items.Add(new ListItem("", null));
			comboBoxCustomerEffect.Items.Add(new ListItem("", null));

			comboBoxPublicHealth.SelectedIndex = 0;
			comboBoxFinancial.SelectedIndex = 0;
			comboBoxEnvironmental.SelectedIndex = 0;
			comboBoxCustomerEffect.SelectedIndex = 0;

			foreach (Common.Criticality crit in Common.CommonTasks.Criticalities)
			{
				comboBoxPublicHealth.Items.Add(new ListItem(crit.CriticalityName, crit));
				comboBoxFinancial.Items.Add(new ListItem(crit.CriticalityName, crit));
				comboBoxEnvironmental.Items.Add(new ListItem(crit.CriticalityName, crit));
				comboBoxCustomerEffect.Items.Add(new ListItem(crit.CriticalityName, crit));

				if (string.Compare(crit.CriticalityName, labelAccessPublicHealth.Tag.ToString(), true) == 0)
				{
					comboBoxPublicHealth.SelectedItem = comboBoxPublicHealth.Items[comboBoxPublicHealth.Items.Count - 1];
				}
				if (string.Compare(crit.CriticalityName, labelAccessFinancial.Tag.ToString(), true) == 0)
				{
					comboBoxFinancial.SelectedItem = comboBoxFinancial.Items[comboBoxFinancial.Items.Count - 1];
				}
				if (string.Compare(crit.CriticalityName, labelAccessEnvironmental.Tag.ToString(), true) == 0)
				{
					comboBoxEnvironmental.SelectedItem = comboBoxEnvironmental.Items[comboBoxEnvironmental.Items.Count - 1];
				}
				if (string.Compare(crit.CriticalityName, labelAccessCustomerEffect.Tag.ToString(), true) == 0)
				{
					comboBoxCustomerEffect.SelectedItem = comboBoxCustomerEffect.Items[comboBoxCustomerEffect.Items.Count - 1];
				}
			}
		}

		private void ClearCritComboBoxes()
		{
			comboBoxPublicHealth.Items.Clear();
			comboBoxFinancial.Items.Clear();
			comboBoxEnvironmental.Items.Clear();
			comboBoxCustomerEffect.Items.Clear();

			comboBoxPublicHealth.Text = "";
			comboBoxFinancial.Text = "";
			comboBoxEnvironmental.Text = "";
			comboBoxCustomerEffect.Text = "";
		}

		private void comboBoxPublicHealth_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				comboBoxPublicHealth1.Items.Clear();
				comboBoxPublicHealth2.Items.Clear();
				comboBoxPublicHealth3.Items.Clear();
				comboBoxPublicHealth4.Items.Clear();

				comboBoxPublicHealth1.Text = "";
				comboBoxPublicHealth2.Text = "";
				comboBoxPublicHealth3.Text = "";
				comboBoxPublicHealth4.Text = "";

				if (comboBoxPublicHealth.SelectedIndex == 0)
				{
					return;
				}

				ListItem selectedItem = comboBoxPublicHealth.SelectedItem as ListItem;
				Common.Criticality crit = selectedItem.Value as Common.Criticality;
				Common.CriticalityFactorCollection critFactors = crit.CriticalityFactors;
				ArrayList arrayListScores = GetScores(crit.CriticalityNumber);
				foreach (Common.CriticalityFactor critFactor in critFactors)
				{
					comboBoxPublicHealth1.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxPublicHealth2.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxPublicHealth3.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxPublicHealth4.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));

					//if (critFactor.Score == scores[3])
					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[arrayListScores.Count - 1])
					{
						comboBoxPublicHealth1.SelectedItem = comboBoxPublicHealth1.Items[comboBoxPublicHealth1.Items.Count - 1];
					}
					//else if (critFactor.Score == scores[2])
					else if (arrayListScores.Count > 2 && critFactor.Score == (int)arrayListScores[2])
					{
						comboBoxPublicHealth2.SelectedItem = comboBoxPublicHealth2.Items[comboBoxPublicHealth2.Items.Count - 1];
					}
					//else if (critFactor.Score == scores[1])
					else if (arrayListScores.Count > 1 && critFactor.Score == (int)arrayListScores[1])
					{
						comboBoxPublicHealth3.SelectedItem = comboBoxPublicHealth3.Items[comboBoxPublicHealth3.Items.Count - 1];
					}
					//else if (critFactor.Score == scores[0])
					else if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[0])
					{
						comboBoxPublicHealth4.SelectedItem = comboBoxPublicHealth4.Items[comboBoxPublicHealth4.Items.Count - 1];
					}
				}

				if (comboBoxPublicHealth4.SelectedIndex == -1)
				{
					comboBoxPublicHealth4.SelectedIndex = 0;
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void comboBoxFinancial_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				comboBoxFinancial1.Items.Clear();
				comboBoxFinancial2.Items.Clear();
				comboBoxFinancial3.Items.Clear();
				comboBoxFinancial4.Items.Clear();

				comboBoxFinancial1.Text = "";
				comboBoxFinancial2.Text = "";
				comboBoxFinancial3.Text = "";
				comboBoxFinancial4.Text = "";

				if (comboBoxFinancial.SelectedIndex == 0)
				{
					return;
				}

				ListItem selectedItem = comboBoxFinancial.SelectedItem as ListItem;
				Common.Criticality crit = selectedItem.Value as Common.Criticality;
				Common.CriticalityFactorCollection critFactors = crit.CriticalityFactors;
				ArrayList arrayListScores = GetScores(crit.CriticalityNumber);
				foreach (Common.CriticalityFactor critFactor in critFactors)
				{
					comboBoxFinancial1.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxFinancial2.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxFinancial3.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxFinancial4.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));

					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[arrayListScores.Count - 1])
					{
						comboBoxFinancial1.SelectedItem = comboBoxFinancial1.Items[comboBoxFinancial1.Items.Count - 1];
					}
					if (arrayListScores.Count > 2 && critFactor.Score == (int)arrayListScores[2])
					{
						comboBoxFinancial2.SelectedItem = comboBoxFinancial2.Items[comboBoxFinancial2.Items.Count - 1];
					}
					if (arrayListScores.Count > 1 && critFactor.Score == (int)arrayListScores[1])
					{
						comboBoxFinancial3.SelectedItem = comboBoxFinancial3.Items[comboBoxFinancial3.Items.Count - 1];
					}
					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[0])
					{
						comboBoxFinancial4.SelectedItem = comboBoxFinancial4.Items[comboBoxFinancial4.Items.Count - 1];
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void comboBoxEnvironmental_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				comboBoxEnvironmental1.Items.Clear();
				comboBoxEnvironmental2.Items.Clear();
				comboBoxEnvironmental3.Items.Clear();

				comboBoxEnvironmental1.Text = "";
				comboBoxEnvironmental2.Text = "";
				comboBoxEnvironmental3.Text = "";

				if (comboBoxEnvironmental.SelectedIndex == 0)
				{
					return;
				}

				ListItem selectedItem = comboBoxEnvironmental.SelectedItem as ListItem;
				Common.Criticality crit = selectedItem.Value as Common.Criticality;
				Common.CriticalityFactorCollection critFactors = crit.CriticalityFactors;
				ArrayList arrayListScores = GetScores(crit.CriticalityNumber);
				foreach (Common.CriticalityFactor critFactor in critFactors)
				{
					comboBoxEnvironmental1.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxEnvironmental2.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxEnvironmental3.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));

					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[arrayListScores.Count - 1])
					{
						comboBoxEnvironmental1.SelectedItem = comboBoxEnvironmental1.Items[comboBoxEnvironmental1.Items.Count - 1];
					}
					if (arrayListScores.Count > 1 && critFactor.Score == (int)arrayListScores[1])
					{
						comboBoxEnvironmental2.SelectedItem = comboBoxEnvironmental2.Items[comboBoxEnvironmental2.Items.Count - 1];
					}
					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[0])
					{
						comboBoxEnvironmental3.SelectedItem = comboBoxEnvironmental3.Items[comboBoxEnvironmental3.Items.Count - 1];
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void comboBoxCustomerEffect_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				comboBoxCustomerEffect1.Items.Clear();
				comboBoxCustomerEffect2.Items.Clear();
				comboBoxCustomerEffect3.Items.Clear();

				comboBoxCustomerEffect1.Text = "";
				comboBoxCustomerEffect2.Text = "";
				comboBoxCustomerEffect3.Text = "";

				if (comboBoxCustomerEffect.SelectedIndex == 0)
				{
					return;
				}

				ListItem selectedItem = comboBoxCustomerEffect.SelectedItem as ListItem;
				Common.Criticality crit = selectedItem.Value as Common.Criticality;
				Common.CriticalityFactorCollection critFactors = crit.CriticalityFactors;
				ArrayList arrayListScores = GetScores(crit.CriticalityNumber);
				foreach (Common.CriticalityFactor critFactor in critFactors)
				{
					comboBoxCustomerEffect1.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxCustomerEffect2.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));
					comboBoxCustomerEffect3.Items.Add(new ListItem(critFactor.FactorName + "  (" + critFactor.Score + ")", critFactor));

					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[arrayListScores.Count - 1])
					{
						comboBoxCustomerEffect1.SelectedItem = comboBoxCustomerEffect1.Items[comboBoxCustomerEffect1.Items.Count - 1];
					}
					if (arrayListScores.Count > 1 && critFactor.Score == (int)arrayListScores[1])
					{
						comboBoxCustomerEffect2.SelectedItem = comboBoxCustomerEffect2.Items[comboBoxCustomerEffect2.Items.Count - 1];
					}
					if (arrayListScores.Count > 0 && critFactor.Score == (int)arrayListScores[0])
					{
						comboBoxCustomerEffect3.SelectedItem = comboBoxCustomerEffect3.Items[comboBoxCustomerEffect3.Items.Count - 1];
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private bool VerifyComboBoxSelections()
		{
			string factorBlank = string.Empty;
			if (comboBoxPublicHealth.SelectedIndex != 0)
			{
				if (comboBoxPublicHealth1.SelectedIndex == -1
					|| comboBoxPublicHealth2.SelectedIndex == -1
					|| comboBoxPublicHealth3.SelectedIndex == -1
					|| comboBoxPublicHealth4.SelectedIndex == -1)
				{
					factorBlank = comboBoxPublicHealth.Text;
				}
			}
			if (factorBlank == string.Empty && comboBoxFinancial.SelectedIndex != 0)
			{
				if (comboBoxFinancial1.SelectedIndex == -1
					|| comboBoxFinancial2.SelectedIndex == -1
					|| comboBoxFinancial3.SelectedIndex == -1
					|| comboBoxFinancial4.SelectedIndex == -1)
				{
					factorBlank = comboBoxFinancial.Text;
				}
			}
			if (factorBlank == string.Empty && comboBoxEnvironmental.SelectedIndex != 0)
			{
				if (comboBoxEnvironmental1.SelectedIndex == -1
					|| comboBoxEnvironmental2.SelectedIndex == -1
					|| comboBoxEnvironmental3.SelectedIndex == -1)
				{
					factorBlank = comboBoxEnvironmental.Text;
				}
			}
			if (factorBlank == string.Empty && comboBoxCustomerEffect.SelectedIndex != 0)
			{
				if (comboBoxCustomerEffect1.SelectedIndex == -1
					|| comboBoxCustomerEffect2.SelectedIndex == -1
					|| comboBoxCustomerEffect3.SelectedIndex == -1)
				{
					factorBlank = comboBoxCustomerEffect.Text;
				}
			}

			if (factorBlank != string.Empty)
			{
				MessageBox.Show(this, "Please make a selection in each drop-down box for " + factorBlank + ".", "Criticality Mapping", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			bool dup = false;
			string selectedIndices = string.Empty;
			ArrayList arrayListDupCrits = new ArrayList();

			if (comboBoxPublicHealth.SelectedIndex > 0)
			{
				selectedIndices = comboBoxPublicHealth.SelectedIndex.ToString();
				//arrayListDupCrits.Add(comboBoxPublicHealth.Text);
			}

			if (comboBoxFinancial.SelectedIndex > 0)
			{
				if (selectedIndices.IndexOf(comboBoxFinancial.SelectedIndex.ToString()) > -1)
				{
					dup = true;
					arrayListDupCrits.Add(comboBoxFinancial.Text);
				}
				else
				{
					selectedIndices += comboBoxFinancial.SelectedIndex.ToString();
				}
			}

			if (comboBoxEnvironmental.SelectedIndex > 0)
			{
				if (selectedIndices.IndexOf(comboBoxEnvironmental.SelectedIndex.ToString()) > -1)
				{
					dup = true;
					if (!arrayListDupCrits.Contains(comboBoxEnvironmental.Text))
					{
						arrayListDupCrits.Add(comboBoxEnvironmental.Text);
					}
				}
				else
				{
					selectedIndices += comboBoxEnvironmental.SelectedIndex.ToString();
				}
			}

			if (comboBoxCustomerEffect.SelectedIndex > 0)
			{
				if (selectedIndices.IndexOf(comboBoxCustomerEffect.SelectedIndex.ToString()) > -1)
				{
					dup = true;
					if (!arrayListDupCrits.Contains(comboBoxCustomerEffect.Text))
					{
						arrayListDupCrits.Add(comboBoxCustomerEffect.Text);
					}
				}
			}

			string message = string.Empty;
			if (arrayListDupCrits.Count == 1)
			{
				message = arrayListDupCrits[0] + " can be mapped only once.";
			}
			if (arrayListDupCrits.Count > 1)
			{
				string dupCrits = string.Empty;
				for (int i = 0; i < arrayListDupCrits.Count; i++)
				{
					dupCrits += dupCrits == string.Empty ? arrayListDupCrits[i] : Environment.NewLine + arrayListDupCrits[i];
				}
				message = "Criticalities can be mapped only once.  The following Criticalities are mapped more than once:"
					+ Environment.NewLine + Environment.NewLine + dupCrits;
			}

			if (message != string.Empty)
			{
				MessageBox.Show(this, message, "Multiple Criticality Mapping", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}

			return !dup;
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (!VerifyComboBoxSelections())
				{
					return;
				}

				Common.CommonTasks.CritMapper critMapper = new WAM.Common.CommonTasks.CritMapper();

				Hashtable hashTablePublicHealth = new Hashtable();
				Hashtable hashTableFinancial = new Hashtable();
				Hashtable hashTableEnvironmental = new Hashtable();
				Hashtable hashTableCustomerEffect = new Hashtable();

				if (comboBoxPublicHealth.SelectedIndex == 0)
				{
					critMapper.CriticalityId = 0;
				}
				else
				{
					hashTablePublicHealth.Add(0, ((Common.CriticalityFactor)((ListItem)comboBoxPublicHealth1.SelectedItem).Value).FactorId);
					hashTablePublicHealth.Add(1, ((Common.CriticalityFactor)((ListItem)comboBoxPublicHealth2.SelectedItem).Value).FactorId);
					hashTablePublicHealth.Add(2, ((Common.CriticalityFactor)((ListItem)comboBoxPublicHealth3.SelectedItem).Value).FactorId);
					hashTablePublicHealth.Add(3, ((Common.CriticalityFactor)((ListItem)comboBoxPublicHealth4.SelectedItem).Value).FactorId);
					critMapper.CriticalityId = ((Common.Criticality)((ListItem)comboBoxPublicHealth.SelectedItem).Value).CriticalityId;
				}
				critMapper.HashTableAccessToFactorId = hashTablePublicHealth;
				Common.Globals.CritMapperPublicHealth = critMapper;

				critMapper = new WAM.Common.CommonTasks.CritMapper();
				if (comboBoxFinancial.SelectedIndex == 0)
				{
					critMapper.CriticalityId = 0;
				}
				else
				{
					hashTableFinancial.Add(0, ((Common.CriticalityFactor)((ListItem)comboBoxFinancial1.SelectedItem).Value).FactorId);
					hashTableFinancial.Add(1, ((Common.CriticalityFactor)((ListItem)comboBoxFinancial2.SelectedItem).Value).FactorId);
					hashTableFinancial.Add(2, ((Common.CriticalityFactor)((ListItem)comboBoxFinancial3.SelectedItem).Value).FactorId);
					hashTableFinancial.Add(3, ((Common.CriticalityFactor)((ListItem)comboBoxFinancial4.SelectedItem).Value).FactorId);
					critMapper.CriticalityId = ((Common.Criticality)((ListItem)comboBoxFinancial.SelectedItem).Value).CriticalityId;
				}
				critMapper.HashTableAccessToFactorId = hashTableFinancial;
				Common.Globals.CritMapperFinancial = critMapper;

				critMapper = new WAM.Common.CommonTasks.CritMapper();
				if (comboBoxEnvironmental.SelectedIndex == 0)
				{
					critMapper.CriticalityId = 0;
				}
				else
				{
					hashTableEnvironmental.Add(0, ((Common.CriticalityFactor)((ListItem)comboBoxEnvironmental1.SelectedItem).Value).FactorId);
					hashTableEnvironmental.Add(1, ((Common.CriticalityFactor)((ListItem)comboBoxEnvironmental2.SelectedItem).Value).FactorId);
					hashTableEnvironmental.Add(2, ((Common.CriticalityFactor)((ListItem)comboBoxEnvironmental3.SelectedItem).Value).FactorId);
					critMapper.CriticalityId = ((Common.Criticality)((ListItem)comboBoxEnvironmental.SelectedItem).Value).CriticalityId;
				}
				critMapper.HashTableAccessToFactorId = hashTableEnvironmental;
				Common.Globals.CritMapperEnvironmental = critMapper;

				critMapper = new WAM.Common.CommonTasks.CritMapper();
				if (comboBoxCustomerEffect.SelectedIndex == 0)
				{
					critMapper.CriticalityId = 0;
				}
				else
				{
					hashTableCustomerEffect.Add(0, ((Common.CriticalityFactor)((ListItem)comboBoxCustomerEffect1.SelectedItem).Value).FactorId);
					hashTableCustomerEffect.Add(1, ((Common.CriticalityFactor)((ListItem)comboBoxCustomerEffect2.SelectedItem).Value).FactorId);
					hashTableCustomerEffect.Add(2, ((Common.CriticalityFactor)((ListItem)comboBoxCustomerEffect3.SelectedItem).Value).FactorId);
					critMapper.CriticalityId = ((Common.Criticality)((ListItem)comboBoxCustomerEffect.SelectedItem).Value).CriticalityId;
				}
				critMapper.HashTableAccessToFactorId = hashTableCustomerEffect;
				Common.Globals.CritMapperCustomerEffect = critMapper;

				AllowAccessImport(true);
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			try
			{
				AllowAccessImport(false);
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error has occurred:  " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			
			this.Close();
		}

		private void AccessImportCritMap_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
	}
}
