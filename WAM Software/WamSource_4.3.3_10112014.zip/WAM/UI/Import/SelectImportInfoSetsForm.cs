using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for SelectImportInfoSetsForm.
	/// </summary>
	public class SelectImportInfoSetsForm : System.Windows.Forms.Form
	{
		//mam 102309
		//private InfoSet[]	m_infoSets = null;
		private InfoSetOriginal[]	m_infoSets = null;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckedListBox checkedListBoxInfoSets;
		private System.Windows.Forms.Button buttonAccept;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SelectImportInfoSetsForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SelectImportInfoSetsForm));
			this.label1 = new System.Windows.Forms.Label();
			this.checkedListBoxInfoSets = new System.Windows.Forms.CheckedListBox();
			this.buttonAccept = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(4, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Select the InfoSets that you would like to import:";
			// 
			// checkedListBoxInfoSets
			// 
			this.checkedListBoxInfoSets.CheckOnClick = true;
			this.checkedListBoxInfoSets.Location = new System.Drawing.Point(4, 31);
			this.checkedListBoxInfoSets.Name = "checkedListBoxInfoSets";
			this.checkedListBoxInfoSets.Size = new System.Drawing.Size(332, 184);
			this.checkedListBoxInfoSets.TabIndex = 1;
			// 
			// buttonAccept
			// 
			this.buttonAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAccept.Location = new System.Drawing.Point(174, 223);
			this.buttonAccept.Name = "buttonAccept";
			this.buttonAccept.TabIndex = 2;
			this.buttonAccept.Text = "&Accept";
			this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(259, 223);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.helpProvider1.SetHelpKeyword(this.pictureBoxHelp, "ImportingData.htm");
			this.helpProvider1.SetHelpNavigator(this.pictureBoxHelp, System.Windows.Forms.HelpNavigator.Topic);
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(316, 5);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.helpProvider1.SetShowHelp(this.pictureBoxHelp, true);
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 103;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// SelectImportInfoSetsForm
			// 
			this.AcceptButton = this.buttonAccept;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(342, 252);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonAccept);
			this.Controls.Add(this.checkedListBoxInfoSets);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SelectImportInfoSetsForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Select InfoSets";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SelectImportInfoSetsForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.SelectImportInfoSetsForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		//mam 102309
		//public static InfoSet[] ShowForm(InfoSet[] selectable, Form owner)
		public static InfoSetOriginal[] ShowForm(InfoSetOriginal[] selectable, Form owner)
		{
			SelectImportInfoSetsForm form = new SelectImportInfoSetsForm();

			try
			{
				form.m_infoSets = selectable;
				if (form.ShowDialog(owner) == DialogResult.OK)
					return form.m_infoSets;
			}
			finally
			{
				form.Dispose(true);
			}

			//mam 102309
			//return new InfoSet[0];
			return new InfoSetOriginal[0];
		}

		protected override void OnLoad(EventArgs e)
		{
			LoadInfoSetsCheckListBox();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			base.OnLoad(e);
		}

		private void		LoadInfoSetsCheckListBox()
		{
			checkedListBoxInfoSets.BeginUpdate();
			checkedListBoxInfoSets.Items.Clear();
			checkedListBoxInfoSets.DisplayMember = "Name";
			checkedListBoxInfoSets.Items.AddRange(m_infoSets);
			checkedListBoxInfoSets.EndUpdate();
		}

		private void buttonAccept_Click(object sender, System.EventArgs e)
		{
			ArrayList		selected = new ArrayList();

			for (int pos = 0; pos < checkedListBoxInfoSets.Items.Count; pos++)
			{
				if (checkedListBoxInfoSets.GetItemCheckState(pos) == CheckState.Checked)
					selected.Add(checkedListBoxInfoSets.Items[pos]);
			}

			if (selected.Count == 0)
			{
				MessageBox.Show(this,
					"No InfoSets were selected. Please select at least one InfoSet to import.",
					"No InfoSet Selected", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam 102309
			//m_infoSets = new InfoSet[selected.Count];
			m_infoSets = new InfoSetOriginal[selected.Count];

			selected.CopyTo(m_infoSets);

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		//mam
		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingData.htm");
		}
		//</mam>

		//mam
		private void SelectImportInfoSetsForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
		//</mam>

		//mam
		private void SelectImportInfoSetsForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
		//</mam>
	}
}
