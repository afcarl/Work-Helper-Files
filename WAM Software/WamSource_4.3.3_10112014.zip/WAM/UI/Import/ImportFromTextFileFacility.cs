using System;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFileFacility.
	/// </summary>
	public class ImportFromTextFileFacility
	{
		#region /***** Member Variables *****/

		private int		infoSetID = 0;
		private int		existingID = 0;
		private int		tempID = 0;
		private int		customENRListID = 0;
		private short	currentYear = (short)DateTime.Now.Year;
		private bool	usesCustomENR = false;
		private bool	importThisItem = false;
		private bool	isNew = true;
		private string	itemName = "New Facility";
		private string	customENRTableName = "";
		private string	comments = "";
		//private bool	parentExists = false;

		//mam 01222012
		private decimal m_facilityCriticality = 1M;

		//mam 03202012
		private string photoFileNameNorth = "";
		private string photoFileNameSouth = "";
		private string photoCaptionNorth = "";
		private string photoCaptionSouth = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportFromTextFileFacility()
		{
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Properties *****/

		public int InfoSetID
		{
			get { return infoSetID; }
			set { infoSetID = value; }
		}

		public int ExistingID
		{
			get { return existingID; }
			set { existingID = value; }
		}

		public int TempID
		{
			get { return tempID; }
			set { tempID = value; }
		}

		public string ItemName
		{
			get { return itemName; }
			set
			{
				if (value.Length > 255)
					itemName = value.Substring(255);
				else
					itemName = value;
			}
		}

		public short CurrentYear
		{
			get { return currentYear; }
			set { currentYear = value; }
		}

		public string CustomENRTableName
		{
			get { return customENRTableName; }
			set
			{
				if (value.Length > Int16.MaxValue)
					customENRTableName = value.Substring(Int16.MaxValue);
				else
					customENRTableName = value;
			}
		}

		public string		Comments
		{
			get { return comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					comments = value.Substring(Int16.MaxValue);
				else
					comments = value;
			}
		}

		public bool UsesCustomENRTable
		{
			get { return usesCustomENR; }
			set { usesCustomENR = value; }
		}

		public bool ImportThisItem
		{
			get { return importThisItem; }
			set { importThisItem = value; }
		}

		public bool IsNew
		{
			get { return isNew; }
			set { isNew = value; }
		}

		public int CustomENRListID
		{
			get { return customENRListID; }
			set { customENRListID = value; }
		}

//		public bool ParentExists
//		{
//			get { return parentExists; }
//			set { parentExists = value; }
//		}

		//mam 01222012
		public decimal FacilityCriticality
		{
			get { return m_facilityCriticality; }
			set { m_facilityCriticality = value; }
		}

		//mam 03202012
		public string PhotoFileNameNorth
		{
			get { return photoFileNameNorth; }
			set
			{
				if (value.Length > 255)
				{
					photoFileNameNorth = value.Substring(255);
				}
				else
				{
					photoFileNameNorth = value;
				}
			}
		}

		//mam 03202012
		public string PhotoFileNameSouth
		{
			get { return photoFileNameSouth; }
			set
			{
				if (value.Length > 255)
				{
					photoFileNameSouth = value.Substring(255);
				}
				else
				{
					photoFileNameSouth = value;
				}
			}
		}

		//mam 03202012
		public string PhotoCaptionNorth
		{
			get { return photoCaptionNorth; }
			set
			{
				if (value.Length > 255)
				{
					photoCaptionNorth = value.Substring(255);
				}
				else
				{
					photoCaptionNorth = value;
				}
			}
		}

		//mam 03202012
		public string PhotoCaptionSouth
		{
			get { return photoCaptionSouth; }
			set
			{
				if (value.Length > 255)
				{
					photoCaptionSouth = value.Substring(255);
				}
				else
				{
					photoCaptionSouth = value;
				}
			}
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		public override string ToString()
		{
			return this.itemName;
		}

		#endregion /***** Methods *****/

	}
}
