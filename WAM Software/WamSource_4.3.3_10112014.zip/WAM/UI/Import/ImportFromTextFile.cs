using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using C1.Win.C1FlexGrid;
using C1.C1Excel;
using WAM.Data;

//mam 102309
using WAM.Common;


namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFile.
	/// </summary>
	public class ImportFromTextFile : System.Windows.Forms.Form
	{
		#region /***** Enumerations *****/

		private enum DataTableFieldName
		{
			ItemType,
			//ItemID,
			TempID,
			ItemName,
			ParentName,
			SelectedFacID,
			SelectedProcID,
			SelectedCompID,
		}

		private enum GridColumnName
		{
			//don't change the order of the captions without also changing the order in LoadColumnNames!!!

			Import = 0,
			Type,
			//Name,
			FacilityName,
			ProcessName,
			ComponentName,

			//mam 03202012
			RenameExistingFacility,
			RenameExistingProcess,
			RenameExistingComponent,

			FacilityCurrentYear,

			//mam 01222012
			FacilityCriticality,

			CustomENRTable,
			Retired,
			LOS,

			//mam 07072011
			Crit1,
			Crit2,
			Crit3,
			Crit4,
			Crit5,
			Crit6,

			//mam 07072011 - no longer using four fixed crits
			//CritPublic,
			//CritEnvironment,
			//CritRepair,
			//CritEffect,

			Vulnerability,
			Comments,
			//DisciplineType,
			AcquisitionCost,
			CurrentValue,
			RehabCost,

			//mam 01222012
			RehabCostDesc,

			//mam 07072011
			RehabCostYear,
			RehabInterval,
			RehabYearLast,
			//mam 01222012
			//RehabNext,

			//mam 01222012
			RehabYearNext,

			RepairCost,
			ReplacementValue,

			//mam 01222012
			ReplacementValueDesc,

			ReplacementValueYear,

			//mam 07072011
			NextReplacementYear,

			SalvageValue,
			AnnualMaintCost,
			InstallationYear,
			OriginalUsefulLife,
			Condition,
			InspectionDate,
			EquipmentIDNumber,
			Manufacturer,
			RunHours,
			RunningAtInspection,
			AssessedBy,
			RedundantAssets,

			//mam 07072011
			CipPlanningMode,
			AssetClass,

			DiscComponentInfo,

			//mam 03202012
			//PhotoFileNameNorth,
			//PhotoCaptionNorth,
			//PhotoFileNameSouth,
			//PhotoCaptionSouth,
			//PhotoFileName,
			//PhotoCaption,

			FacilityPhotoFileNameNorth,
			FacilityPhotoCaptionNorth,
			FacilityPhotoFileNameSouth,
			FacilityPhotoCaptionSouth,
			ProcessPhotoFileName,
			ProcessPhotoCaption,
			ComponentPhotoFileName,
			ComponentPhotoCaption,
			DisciplinePhotoFileName,
			DisciplinePhotoCaption,

			//DisciplineMechPhotoFile,
			//DisciplineMechPhotoCaption,
			//DisciplineStructPhotoFile,
			//DisciplineStructPhotoCaption,
			//DisciplineLandPhotoFile,
			//DisciplineLandPhotoCaption,
		}

		#endregion /***** Enumerations *****/

		#region /***** Member Variables *****/

		//mam 07072011
		int defaultCipId = Common.CommonTasks.DefaultCipPlanningId;
		int zeroRehabCostCipPlanningId = Common.CommonTasks.ZeroRehabCostCipPlanningId;
		int nonZeroRehabCostCipPlanningId = Common.CommonTasks.GetCipNonZeroRehabCostId();
		ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage();
		MajorComponent component = new MajorComponent(0);

		private Form parentForm = new Form();

		//mam 07072011 - commented for testing only
		//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
		//mam 03202012 - call it from the ui thread
		private ProgressDisplay progressDisplay;
		private ProgressDisplayLoadExcel progressDisplayLoadExcel;

		private ToolTip toolTip = new ToolTip();
		private C1.C1Excel.C1XLBook excelBook = new C1XLBook();
		private C1.C1Excel.C1XLBook excelBookSampleData = new C1XLBook();
		private C1.C1Excel.C1XLBook excelBookExport = new C1XLBook();
		private ImportFromTextFileCollection importCollection = new ImportFromTextFileCollection();
		private DataTable dataTableOriginalDataFromSpreadsheet = new DataTable();
		private DataTable dataTableColNames = new DataTable();
		private DataTable dataTableDiscCompInfo = new DataTable();
		private ArrayList arrayListSpreadsheetGrids = new ArrayList();
		private Hashtable _styles;
		private ListDictionary listDictColNamesDontExport = new ListDictionary();
		private ListDictionary listDictFacilityNames = new ListDictionary();
		private ListDictionary listDictFacilityNamesAll = new ListDictionary();
		private ListDictionary listDictFacilityNamesImportCheckBox = new ListDictionary();
		private ListDictionary listDictProcessNames = new ListDictionary();
		private ListDictionary listDictProcessNamesAll = new ListDictionary();
		private ListDictionary listDictProcessNamesImportCheckBox = new ListDictionary();
		private ListDictionary listDictProcessNamesForComponent = new ListDictionary();
		private ListDictionary listDictComponentNames = new ListDictionary();
		private ListDictionary listDictComponentNamesAll = new ListDictionary();
		private ListDictionary listDictComponentNamesImportCheckBox = new ListDictionary();
		private ListDictionary listDictComponentNamesDiscCombo = new ListDictionary();
		private ListDictionary listDictDisciplineNames = new ListDictionary();
		private ListDictionary listDictDisciplineNamesAll = new ListDictionary();
		private ListDictionary listDictDisciplineNamesImportCheckBox = new ListDictionary();
		private ListDictionary listDictionaryComponentType = new ListDictionary();
		private ListDictionary listDictionaryDisciplineType = new ListDictionary();
		private ListDictionary listDictionaryLOS = new ListDictionary();
		private ListDictionary listDictionaryCondition = new ListDictionary();

		//mam 07072011 - no longer using four fixed crits
		//private ListDictionary listDictionaryCritPublic = new ListDictionary();
		//private ListDictionary listDictionaryCritEnvironment = new ListDictionary();
		//private ListDictionary listDictionaryCritRepair = new ListDictionary();
		//private ListDictionary listDictionaryCritEffect = new ListDictionary();

		//mam 07072011
		//private ListDictionary listDictionaryCip = new ListDictionary();
		private SortedList sortedListCip = new SortedList();

		private ListDictionary listDictionaryCustomENRTable = new ListDictionary();
		private ListDictionary listColsNoCheckMark = new ListDictionary();
		private ListDictionary listColsCheckMarkRow1 = new ListDictionary();

		private WAM.Common.GridEventsCopyPaste gridEventsCopyPaste = new WAM.Common.GridEventsCopyPaste();
		private Thread importThread;

		//mam 03202012
		//let's comment this so it doesn't get used
		//private Thread excelLoadThread;

		//mam 03202012
		//using the progressPanel and DoEvents is just not acceptable - WAM still seems unresponsive
		//a separate thread should be used instead of DoEvents, but it would require too much testing at this point
		private bool useProgressPanel = false;

		//double secondsRequired = 0;
		//double minutesRequired = 0;

		private bool stopImportingData = false;
		private bool allowContinuousValidation = false;

		//private CellRange cellRangeUserData;

		//private CellStyle csFacCombo;
		//private CellStyle csFacComboForCompGrid;
		//private CellStyle csProcCombo;
		//private CellStyle csCompCombo;
		private CellStyle cellStyleError;
		private CellStyle cellStyleValid;
		private CellStyle cellStyleBlackout;
		private CellStyle cellStyleDontImport;

		//mam 07072011
		private CellStyle cellStyleDefaultValue;
		private CellStyle cellStyleDontImportDefaultValue;

		//mam 03202012
		private CellStyle cellStyleCheckBox;

		private CellStyle cellStyleErrorFac;
		private CellStyle cellStyleErrorProc;
		private CellStyle cellStyleErrorCompPN;
		private CellStyle cellStyleErrorDisc;

		private CellStyle cellStyleValidFac;
		private CellStyle cellStyleValidProc;
		private CellStyle cellStyleValidCompPN;
		private CellStyle cellStyleValidDisc;

		private CellStyle cellStyleBlackoutFac;
		private CellStyle cellStyleBlackoutProc;
		private CellStyle cellStyleBlackoutCompPN;
		private CellStyle cellStyleBlackoutDisc;

		private CellStyle cellStyleDontImportFac;
		private CellStyle cellStyleDontImportProc;
		private CellStyle cellStyleDontImportCompPN;
		private CellStyle cellStyleDontImportDisc;

		//mam 07072011
		private CellStyle cellStyleDefaultValueFac;
		private CellStyle cellStyleDefaultValueProc;
		private CellStyle cellStyleDefaultValueCompPN;
		private CellStyle cellStyleDefaultValueDisc;
		private CellStyle cellStyleDontImportDefaultValueFac;
		private CellStyle cellStyleDontImportDefaultValueProc;
		private CellStyle cellStyleDontImportDefaultValueCompPN;
		private CellStyle cellStyleDontImportDefaultValueDisc;

		//mam 03202012
		private CellStyle cellStyleCheckBoxFac;
		private CellStyle cellStyleCheckBoxProc;
		private CellStyle cellStyleCheckBoxCompPn;

		//private CellStyle csLOS;
		//private CellStyle csCritPublic;
		//private CellStyle csCritEnvironment;
		//private CellStyle csCritRepair;
		//private CellStyle csCritEffect;

		private const int colIndicesCount = -44;
		private int errorCountFac = 0;
		private int errorCountProc = 0;
		private int errorCountComp = 0;
		private int errorCountCompPN = 0;
		private int errorCountDisc = 0;

		//private double currencyMax = 922337203685477;
		private double currencyMax = 1000000000000;
		private int infoSetID = 0;
		private int errorCount = 0;
		private int errorCountByCellErrorStyle = 0;
		private int errorCountUnknownError = 0;
		private int errorInSetError = 0;
		private int colIndexType = -1;
		//private int colIndexName = -1;
		//private int colIndexParent = -1;
		private int colIndexCustomENR = -1;
		private int colIndexFac = -1;
		private int colIndexProc = -1;
		private int colIndexComp = -1;

		private int colIndexFacilityCurrentYear = -1;

		//mam 01222012
		private int colIndexFacilityCriticality = -1;

		private int colIndexRetired = -1;
		private int colIndexLOS = -1;
		private int colIndexRedundant = -1;

		//mam 07072011
		private int colIndexCipPlanningMode = -1;
		private int colIndexAssetClass = -1;

		//mam 07072011
		private int colIndexCrit1 = -1;
		private int colIndexCrit2 = -1;
		private int colIndexCrit3 = -1;
		private int colIndexCrit4 = -1;
		private int colIndexCrit5 = -1;
		private int colIndexCrit6 = -1;

		//mam 07072011 - no longer using four fixed crits
		//private int colIndexCritPublic = -1;
		//private int colIndexCritEnvironment = -1;
		//private int colIndexCritRepair = -1;
		//private int colIndexCritEffect = -1;

		private int colIndexVuln = -1;

		//discipline columns
		private int colIndexAcquisitionCost = -1;
		private int colIndexCurrentValue = -1;
		private int colIndexRehabCost = -1;

		//mam 07072011
		private int colIndexRehabCostYear = -1;
		private int colIndexRehabInterval = -1;
		private int colIndexRehabYearLast = -1;
		//mam 01222012
		//private int colIndexRehabNext = -1;

		//mam 01222012
		private int colIndexRehabYearNext = -1;

		private int colIndexRepairCost = -1;
		private int colIndexReplacementValue = -1;
		private int colIndexReplacementValueYear = -1;

		//mam 07072011
		private int colIndexNextReplacementYear = -1;

		private int colIndexSalvageValue = -1;
		private int colIndexAnnualMaintCost = -1;
		private int colIndexInstallationYear = -1;
		private int colIndexOriginalUsefulLife = -1;
		private int colIndexCondition = -1;
		private int colIndexInspectionDate = -1;
		private int colIndexEquipmentIDNumber = -1;
		private int colIndexManufacturer = -1;
		private int colIndexRunHours = -1;
		private int colIndexRunningAtInspection = -1;
		private int colIndexAssessedBy = -1;
		
		private int colIndexComments = -1;

		//mam 01222012
		private int colIndexReplacementValueDesc = -1;
		private int colIndexRehabCostDesc = -1;

		//mam 03202012
		private int colIndexFacilityPhotoFileNorth = -1;
		private int colIndexFacilityPhotoFileSouth = -1;
		private int colIndexFacilityPhotoCaptionNorth = -1;
		private int colIndexFacilityPhotoCaptionSouth = -1;
		private int colIndexProcessPhotoFile = -1;
		private int colIndexProcessPhotoCaption = -1;
		private int colIndexComponentPhotoFile = -1;
		private int colIndexComponentPhotoCaption = -1;
		private int colIndexDisciplinePhotoFile = -1;
		private int colIndexDisciplinePhotoCaption = -1;
		//private int colIndexDisciplineMechPhotoFile = -1;
		//private int colIndexDisciplineMechPhotoCaption = -1;
		//private int colIndexDisciplineStructPhotoFile = -1;
		//private int colIndexDisciplineStructPhotoCaption = -1;
		//private int colIndexDisciplineLandPhotoFile = -1;
		//private int colIndexDisciplineLandPhotoCaption = -1;

		private int curMouseX = 0;
		private int curMouseY = 0;
		private int curMouseRow = 0;

		private bool isInitialized = false;
		private bool codeHasRun = false;

		private string errorTipCombo = "Select an item from the drop-down list";
		private const string errorTipMessage = "Hold mouse over grid cell to see error message";
		private const string generalTipMessage = "Hold mouse over grid column for information";
		private const string importPipeNodedataMessage = "Data for individual pipes and nodes cannot be imported here.  To import data for Pipes and Nodes, use the Import Pipes or Import Nodes functions on the File > Import menu.";

		//mam 07072011
		private ArrayList arrayListCriticalities = new ArrayList();
		private ArrayList arrayListCip = new ArrayList();

		//mam 03202012
		private delegate void DelegateProgressUpdate(TimeSpan t);
		private delegate void DelegateProgressClose();
		private delegate void DelegateProgressErrorMessage(string message);
		private delegate void DelegateProgressMessage(string message);

		//mam 03202012
		private delegate void DelegateProgressUpdateText(string message);

		//mam 03202012
		private string renameExistingAppendage = "_OLD";
		//private string multiSheetNameFacility = "WAM System Facility";
		//private string multiSheetNameProcess = "WAM System Process";
		//private string multiSheetNameComponentMsc = "WAM System Component MSC";
		//private string multiSheetNameComponentPn = "WAM System Component PN";
		//private string multiSheetNameDiscMech = "WAM System Discipline Mech";
		//private string multiSheetNameDiscStruct = "WAM System Discipline Struct";
		//private string multiSheetNameDiscCivil = "WAM System Discipline Civil";
		private string multiSheetNameFacility = "WAM Facility";
		private string multiSheetNameProcess = "WAM Process";
		private string multiSheetNameComponentMsc = "WAM Comp MSC";
		private string multiSheetNameComponentPn = "WAM Comp PN";
		private string multiSheetNameDiscMech = "WAM Disc Mech";
		private string multiSheetNameDiscStruct = "WAM Disc Struct";
		private string multiSheetNameDiscCivil = "WAM Disc Civil";

		//mam 03202012
		private string wamMultipleSpreadsheetName = "WAM Combined Spreadsheet";

		private System.Windows.Forms.TabPage tabPageDiscipline;
		private System.Windows.Forms.PictureBox pictureBoxToolbarHelp;
		private System.Windows.Forms.TabPage tabPageComponent;
		private System.Windows.Forms.TabPage tabPageProcess;
		private System.Windows.Forms.TabPage tabPageFacility;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridFacility;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridProcess;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridComponent;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridDiscipline;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.PictureBox pictureBoxToolbarSelectFile;
		private System.Windows.Forms.PictureBox pictureBoxToolbarExport;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.TabPage tabPageSpreadsheetData;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridSpreadsheetData;
		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.TabControl tabControlImport;
		private System.Windows.Forms.Button buttonValidate;
		private System.Windows.Forms.TabPage tabPageComponentPN;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridComponentPN;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAddGridRow;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label labelErrorCountDisc;
		private System.Windows.Forms.Label labelErrorCountCompPN;
		private System.Windows.Forms.Label labelErrorCountComp;
		private System.Windows.Forms.Label labelErrorCountProc;
		private System.Windows.Forms.Label labelErrorCountFac;
		private System.Windows.Forms.Label labelErrorCount;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panelErrors;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.PictureBox pictureBoxToolbarPopulateTabs;
		private System.Windows.Forms.PictureBox pictureBoxToolbarDeleteGridRow;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panelFacGrid;
		private System.Windows.Forms.Panel panelCompGrid;
		private System.Windows.Forms.Panel panelProcGrid;
		private System.Windows.Forms.Panel panelCompPNGrid;
		private System.Windows.Forms.Panel panelDiscGrid;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panelSpreadsheetGrid;
		private System.Windows.Forms.TabPage tabPageSampleData;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridSampleData;
		private System.Windows.Forms.Panel panelSampleGrid;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Panel panelOpenForm;
		private System.Windows.Forms.CheckBox checkBoxOpenForm;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCheckAll;
		private System.Windows.Forms.PictureBox pictureBoxInstructionAddGridRow;
		private System.Windows.Forms.PictureBox pictureBoxInstructionSelectFile;
		private System.Windows.Forms.PictureBox pictureBoxPopulateTabsSpreadsheet;
		private System.Windows.Forms.PictureBox pictureBoxPopulateTabsSample;
		private System.Windows.Forms.ComboBox comboBoxSheet;
		private System.Windows.Forms.PictureBox pictureBoxSelectFileSpreadsheet;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label labelErrorTip;
		private System.Windows.Forms.Panel panelErrorMessage;
		private System.Windows.Forms.Panel panelOpenForm2;
		private System.Windows.Forms.Panel panelOpenFormHolder;
		private System.Windows.Forms.Panel panelSpreadsheetToolbarOutline;
		private System.Windows.Forms.Panel panelSpreadsheetToolbarInterior;
		private System.Windows.Forms.Panel panelSampleToolbarOutline;
		private System.Windows.Forms.Panel panelSampleToolbarInterior;
		private System.Windows.Forms.PictureBox pictureBoxLoadSampleData;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.LinkLabel linkLabelErrorFac;
		private System.Windows.Forms.LinkLabel linkLabelErrorProc;
		private System.Windows.Forms.LinkLabel linkLabelErrorComp;
		private System.Windows.Forms.LinkLabel linkLabelErrorCompPN;
		private System.Windows.Forms.LinkLabel linkLabelErrorDisc;
		private System.Windows.Forms.TabPage tabPageOverview;
		private System.Windows.Forms.Panel panelGridOverview;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridOverview;
		private System.Windows.Forms.Label labelSheet;
		private System.Windows.Forms.Panel panelGeneralMessage;
		private System.Windows.Forms.Label labelGeneralMessage;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label labelGeneralMessageBackground;
		private System.Windows.Forms.Label labelErrorTipBackground;
		private System.Windows.Forms.PictureBox pictureBoxToolbarClearAll;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.CheckBox checkBoxContinuousValidation;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button buttonCancelImport;
		private System.Windows.Forms.TextBox textBoxProgressTime;
		private System.Windows.Forms.TextBox textBoxProgressRowCount;
		private System.Windows.Forms.Panel panelProgressDisplay;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.RadioButton radioButtonTabSingle;
		private System.Windows.Forms.RadioButton radioButtonTabMultiple;
		private System.Windows.Forms.Panel panelProgress;
		private System.Windows.Forms.Label labelProgress;
		private System.Windows.Forms.Button buttonStopLoadingExcel;
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportFromTextFile(Form parentForm, int infoSetID)
		{
			this.parentForm = parentForm;
			this.infoSetID = infoSetID;
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ImportFromTextFile));
			this.tabControlImport = new System.Windows.Forms.TabControl();
			this.tabPageSpreadsheetData = new System.Windows.Forms.TabPage();
			this.panelSpreadsheetGrid = new System.Windows.Forms.Panel();
			this.panelSpreadsheetToolbarOutline = new System.Windows.Forms.Panel();
			this.panelSpreadsheetToolbarInterior = new System.Windows.Forms.Panel();
			this.pictureBoxSelectFileSpreadsheet = new System.Windows.Forms.PictureBox();
			this.pictureBoxPopulateTabsSpreadsheet = new System.Windows.Forms.PictureBox();
			this.c1FlexGridSpreadsheetData = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageProcess = new System.Windows.Forms.TabPage();
			this.panelProcGrid = new System.Windows.Forms.Panel();
			this.c1FlexGridProcess = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageComponentPN = new System.Windows.Forms.TabPage();
			this.panelCompPNGrid = new System.Windows.Forms.Panel();
			this.c1FlexGridComponentPN = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageComponent = new System.Windows.Forms.TabPage();
			this.panelCompGrid = new System.Windows.Forms.Panel();
			this.c1FlexGridComponent = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageDiscipline = new System.Windows.Forms.TabPage();
			this.panelDiscGrid = new System.Windows.Forms.Panel();
			this.c1FlexGridDiscipline = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageSampleData = new System.Windows.Forms.TabPage();
			this.panelSampleGrid = new System.Windows.Forms.Panel();
			this.panelSampleToolbarOutline = new System.Windows.Forms.Panel();
			this.panelSampleToolbarInterior = new System.Windows.Forms.Panel();
			this.pictureBoxLoadSampleData = new System.Windows.Forms.PictureBox();
			this.pictureBoxPopulateTabsSample = new System.Windows.Forms.PictureBox();
			this.c1FlexGridSampleData = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageFacility = new System.Windows.Forms.TabPage();
			this.panelFacGrid = new System.Windows.Forms.Panel();
			this.c1FlexGridFacility = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.tabPageOverview = new System.Windows.Forms.TabPage();
			this.panelGridOverview = new System.Windows.Forms.Panel();
			this.c1FlexGridOverview = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.comboBoxSheet = new System.Windows.Forms.ComboBox();
			this.pictureBoxToolbarSelectFile = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarExport = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarHelp = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAddGridRow = new System.Windows.Forms.PictureBox();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonTest = new System.Windows.Forms.Button();
			this.buttonValidate = new System.Windows.Forms.Button();
			this.panelErrors = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.labelErrorCountDisc = new System.Windows.Forms.Label();
			this.labelErrorCountCompPN = new System.Windows.Forms.Label();
			this.labelErrorCountComp = new System.Windows.Forms.Label();
			this.labelErrorCountProc = new System.Windows.Forms.Label();
			this.labelErrorCountFac = new System.Windows.Forms.Label();
			this.labelErrorCount = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.linkLabelErrorFac = new System.Windows.Forms.LinkLabel();
			this.linkLabelErrorProc = new System.Windows.Forms.LinkLabel();
			this.linkLabelErrorComp = new System.Windows.Forms.LinkLabel();
			this.linkLabelErrorCompPN = new System.Windows.Forms.LinkLabel();
			this.linkLabelErrorDisc = new System.Windows.Forms.LinkLabel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.pictureBoxToolbarDeleteGridRow = new System.Windows.Forms.PictureBox();
			this.panel9 = new System.Windows.Forms.Panel();
			this.pictureBoxToolbarCheckAll = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarPopulateTabs = new System.Windows.Forms.PictureBox();
			this.panelOpenForm = new System.Windows.Forms.Panel();
			this.label14 = new System.Windows.Forms.Label();
			this.checkBoxOpenForm = new System.Windows.Forms.CheckBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.pictureBoxInstructionAddGridRow = new System.Windows.Forms.PictureBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.pictureBoxInstructionSelectFile = new System.Windows.Forms.PictureBox();
			this.labelErrorTip = new System.Windows.Forms.Label();
			this.panelErrorMessage = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.labelErrorTipBackground = new System.Windows.Forms.Label();
			this.panelOpenForm2 = new System.Windows.Forms.Panel();
			this.panelOpenFormHolder = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.labelSheet = new System.Windows.Forms.Label();
			this.panelGeneralMessage = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.labelGeneralMessage = new System.Windows.Forms.Label();
			this.labelGeneralMessageBackground = new System.Windows.Forms.Label();
			this.pictureBoxToolbarClearAll = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.checkBoxContinuousValidation = new System.Windows.Forms.CheckBox();
			this.panelProgressDisplay = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.buttonCancelImport = new System.Windows.Forms.Button();
			this.panel4 = new System.Windows.Forms.Panel();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.textBoxProgressTime = new System.Windows.Forms.TextBox();
			this.textBoxProgressRowCount = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.radioButtonTabSingle = new System.Windows.Forms.RadioButton();
			this.radioButtonTabMultiple = new System.Windows.Forms.RadioButton();
			this.panelProgress = new System.Windows.Forms.Panel();
			this.buttonStopLoadingExcel = new System.Windows.Forms.Button();
			this.labelProgress = new System.Windows.Forms.Label();
			this.tabControlImport.SuspendLayout();
			this.tabPageSpreadsheetData.SuspendLayout();
			this.panelSpreadsheetGrid.SuspendLayout();
			this.panelSpreadsheetToolbarOutline.SuspendLayout();
			this.panelSpreadsheetToolbarInterior.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridSpreadsheetData)).BeginInit();
			this.tabPageProcess.SuspendLayout();
			this.panelProcGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridProcess)).BeginInit();
			this.tabPageComponentPN.SuspendLayout();
			this.panelCompPNGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridComponentPN)).BeginInit();
			this.tabPageComponent.SuspendLayout();
			this.panelCompGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridComponent)).BeginInit();
			this.tabPageDiscipline.SuspendLayout();
			this.panelDiscGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridDiscipline)).BeginInit();
			this.tabPageSampleData.SuspendLayout();
			this.panelSampleGrid.SuspendLayout();
			this.panelSampleToolbarOutline.SuspendLayout();
			this.panelSampleToolbarInterior.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridSampleData)).BeginInit();
			this.tabPageFacility.SuspendLayout();
			this.panelFacGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridFacility)).BeginInit();
			this.tabPageOverview.SuspendLayout();
			this.panelGridOverview.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridOverview)).BeginInit();
			this.panelErrors.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panelOpenForm.SuspendLayout();
			this.panelErrorMessage.SuspendLayout();
			this.panelOpenFormHolder.SuspendLayout();
			this.panelGeneralMessage.SuspendLayout();
			this.panelProgressDisplay.SuspendLayout();
			this.panelProgress.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControlImport
			// 
			this.tabControlImport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControlImport.Controls.Add(this.tabPageSpreadsheetData);
			this.tabControlImport.Controls.Add(this.tabPageProcess);
			this.tabControlImport.Controls.Add(this.tabPageComponentPN);
			this.tabControlImport.Controls.Add(this.tabPageComponent);
			this.tabControlImport.Controls.Add(this.tabPageDiscipline);
			this.tabControlImport.Controls.Add(this.tabPageSampleData);
			this.tabControlImport.Controls.Add(this.tabPageFacility);
			this.tabControlImport.Controls.Add(this.tabPageOverview);
			this.tabControlImport.HotTrack = true;
			this.tabControlImport.ItemSize = new System.Drawing.Size(90, 24);
			this.tabControlImport.Location = new System.Drawing.Point(0, 32);
			this.tabControlImport.Name = "tabControlImport";
			this.tabControlImport.SelectedIndex = 0;
			this.tabControlImport.Size = new System.Drawing.Size(724, 304);
			this.tabControlImport.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControlImport.TabIndex = 0;
			this.tabControlImport.SelectedIndexChanged += new System.EventHandler(this.tabControlImport_SelectedIndexChanged);
			// 
			// tabPageSpreadsheetData
			// 
			this.tabPageSpreadsheetData.Controls.Add(this.panelSpreadsheetGrid);
			this.tabPageSpreadsheetData.Location = new System.Drawing.Point(4, 28);
			this.tabPageSpreadsheetData.Name = "tabPageSpreadsheetData";
			this.tabPageSpreadsheetData.Size = new System.Drawing.Size(716, 272);
			this.tabPageSpreadsheetData.TabIndex = 4;
			this.tabPageSpreadsheetData.Text = "Spreadsheet";
			// 
			// panelSpreadsheetGrid
			// 
			this.panelSpreadsheetGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSpreadsheetGrid.BackColor = System.Drawing.Color.White;
			this.panelSpreadsheetGrid.Controls.Add(this.panelSpreadsheetToolbarOutline);
			this.panelSpreadsheetGrid.Controls.Add(this.c1FlexGridSpreadsheetData);
			this.panelSpreadsheetGrid.Location = new System.Drawing.Point(0, 3);
			this.panelSpreadsheetGrid.Name = "panelSpreadsheetGrid";
			this.panelSpreadsheetGrid.Size = new System.Drawing.Size(715, 268);
			this.panelSpreadsheetGrid.TabIndex = 4;
			// 
			// panelSpreadsheetToolbarOutline
			// 
			this.panelSpreadsheetToolbarOutline.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSpreadsheetToolbarOutline.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSpreadsheetToolbarOutline.Controls.Add(this.panelSpreadsheetToolbarInterior);
			this.panelSpreadsheetToolbarOutline.Location = new System.Drawing.Point(1, 0);
			this.panelSpreadsheetToolbarOutline.Name = "panelSpreadsheetToolbarOutline";
			this.panelSpreadsheetToolbarOutline.Size = new System.Drawing.Size(713, 32);
			this.panelSpreadsheetToolbarOutline.TabIndex = 182;
			// 
			// panelSpreadsheetToolbarInterior
			// 
			this.panelSpreadsheetToolbarInterior.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSpreadsheetToolbarInterior.BackColor = System.Drawing.Color.White;
			this.panelSpreadsheetToolbarInterior.Controls.Add(this.pictureBoxSelectFileSpreadsheet);
			this.panelSpreadsheetToolbarInterior.Controls.Add(this.pictureBoxPopulateTabsSpreadsheet);
			this.panelSpreadsheetToolbarInterior.Location = new System.Drawing.Point(1, 1);
			this.panelSpreadsheetToolbarInterior.Name = "panelSpreadsheetToolbarInterior";
			this.panelSpreadsheetToolbarInterior.Size = new System.Drawing.Size(711, 30);
			this.panelSpreadsheetToolbarInterior.TabIndex = 183;
			// 
			// pictureBoxSelectFileSpreadsheet
			// 
			this.pictureBoxSelectFileSpreadsheet.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxSelectFileSpreadsheet.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxSelectFileSpreadsheet.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSelectFileSpreadsheet.Image")));
			this.pictureBoxSelectFileSpreadsheet.Location = new System.Drawing.Point(8, 5);
			this.pictureBoxSelectFileSpreadsheet.Name = "pictureBoxSelectFileSpreadsheet";
			this.pictureBoxSelectFileSpreadsheet.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxSelectFileSpreadsheet.TabIndex = 148;
			this.pictureBoxSelectFileSpreadsheet.TabStop = false;
			this.pictureBoxSelectFileSpreadsheet.Click += new System.EventHandler(this.pictureBoxSelectFileSpreadsheet_Click);
			// 
			// pictureBoxPopulateTabsSpreadsheet
			// 
			this.pictureBoxPopulateTabsSpreadsheet.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxPopulateTabsSpreadsheet.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxPopulateTabsSpreadsheet.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPopulateTabsSpreadsheet.Image")));
			this.pictureBoxPopulateTabsSpreadsheet.Location = new System.Drawing.Point(32, 5);
			this.pictureBoxPopulateTabsSpreadsheet.Name = "pictureBoxPopulateTabsSpreadsheet";
			this.pictureBoxPopulateTabsSpreadsheet.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxPopulateTabsSpreadsheet.TabIndex = 147;
			this.pictureBoxPopulateTabsSpreadsheet.TabStop = false;
			this.pictureBoxPopulateTabsSpreadsheet.Click += new System.EventHandler(this.pictureBoxPopulateTabsSpreadsheet_Click);
			// 
			// c1FlexGridSpreadsheetData
			// 
			this.c1FlexGridSpreadsheetData.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridSpreadsheetData.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridSpreadsheetData.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
			this.c1FlexGridSpreadsheetData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridSpreadsheetData.AutoResize = false;
			this.c1FlexGridSpreadsheetData.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridSpreadsheetData.ColumnInfo = "1,1,0,0,0,85,Columns:0{Width:35;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridSpreadsheetData.ExtendLastCol = true;
			this.c1FlexGridSpreadsheetData.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridSpreadsheetData.Location = new System.Drawing.Point(1, 32);
			this.c1FlexGridSpreadsheetData.Name = "c1FlexGridSpreadsheetData";
			this.c1FlexGridSpreadsheetData.Rows.Count = 1;
			this.c1FlexGridSpreadsheetData.ShowSort = false;
			this.c1FlexGridSpreadsheetData.Size = new System.Drawing.Size(713, 238);
			this.c1FlexGridSpreadsheetData.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridSpreadsheetData.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridSpreadsheetData.TabIndex = 0;
			// 
			// tabPageProcess
			// 
			this.tabPageProcess.BackColor = System.Drawing.Color.White;
			this.tabPageProcess.Controls.Add(this.panelProcGrid);
			this.tabPageProcess.Location = new System.Drawing.Point(4, 28);
			this.tabPageProcess.Name = "tabPageProcess";
			this.tabPageProcess.Size = new System.Drawing.Size(716, 272);
			this.tabPageProcess.TabIndex = 1;
			this.tabPageProcess.Text = "Process";
			this.tabPageProcess.Visible = false;
			// 
			// panelProcGrid
			// 
			this.panelProcGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelProcGrid.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelProcGrid.Controls.Add(this.c1FlexGridProcess);
			this.panelProcGrid.Location = new System.Drawing.Point(0, 3);
			this.panelProcGrid.Name = "panelProcGrid";
			this.panelProcGrid.Size = new System.Drawing.Size(715, 268);
			this.panelProcGrid.TabIndex = 4;
			// 
			// c1FlexGridProcess
			// 
			this.c1FlexGridProcess.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridProcess.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridProcess.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridProcess.AutoResize = false;
			this.c1FlexGridProcess.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridProcess.ColumnInfo = @"10,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:""RowSelector"";AllowDragging:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}	1{Name:""TempID"";Caption:""TempID"";AllowEditing:False;DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	2{Width:75;Name:""Import"";Caption:""Import this Process"";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:CenterCenter;}	3{Width:45;Name:""IsNew"";Caption:""New"";Visible:False;DataType:System.Boolean;TextAlign:CenterCenter;TextAlignFixed:CenterCenter;ImageAlign:CenterCenter;}	4{Width:200;Name:""FacilityName"";Caption:""Facility Name"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	5{Width:200;Name:""ProcessName"";Caption:""Process / Basin / Zone Name"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	6{Width:100;Name:""RenameExistingProcess"";Caption:""Rename Existing Process"";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:CenterCenter;}	7{Width:100;Name:""ProcessPhotoFileName"";Caption:""Process Photo File"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	8{Width:100;Name:""ProcessPhotoCaption"";Caption:""Process Photo Caption"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	9{Width:200;Name:""Comments"";Caption:""Comments"";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}	";
			this.c1FlexGridProcess.ExtendLastCol = true;
			this.c1FlexGridProcess.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridProcess.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridProcess.Name = "c1FlexGridProcess";
			this.c1FlexGridProcess.Rows.Count = 1;
			this.c1FlexGridProcess.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridProcess.ShowSort = false;
			this.c1FlexGridProcess.Size = new System.Drawing.Size(713, 266);
			this.c1FlexGridProcess.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridProcess.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridProcess.TabIndex = 2;
			this.c1FlexGridProcess.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridProcess_AfterEdit);
			this.c1FlexGridProcess.ValidateEdit += new C1.Win.C1FlexGrid.ValidateEditEventHandler(this.c1FlexGridProcess_ValidateEdit);
			// 
			// tabPageComponentPN
			// 
			this.tabPageComponentPN.BackColor = System.Drawing.Color.White;
			this.tabPageComponentPN.Controls.Add(this.panelCompPNGrid);
			this.tabPageComponentPN.Location = new System.Drawing.Point(4, 28);
			this.tabPageComponentPN.Name = "tabPageComponentPN";
			this.tabPageComponentPN.Size = new System.Drawing.Size(716, 272);
			this.tabPageComponentPN.TabIndex = 5;
			this.tabPageComponentPN.Text = "Component PN";
			// 
			// panelCompPNGrid
			// 
			this.panelCompPNGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelCompPNGrid.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelCompPNGrid.Controls.Add(this.c1FlexGridComponentPN);
			this.panelCompPNGrid.Location = new System.Drawing.Point(0, 3);
			this.panelCompPNGrid.Name = "panelCompPNGrid";
			this.panelCompPNGrid.Size = new System.Drawing.Size(715, 268);
			this.panelCompPNGrid.TabIndex = 6;
			// 
			// c1FlexGridComponentPN
			// 
			this.c1FlexGridComponentPN.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridComponentPN.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridComponentPN.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridComponentPN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridComponentPN.AutoResize = false;
			this.c1FlexGridComponentPN.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridComponentPN.ColumnInfo = "13,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDragg" +
				"ing:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t1" +
				"{Name:\"TempID\";Caption:\"TempID\";AllowEditing:False;DataType:System.Int32;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t2{Width:75;Name:\"Import\";Caption:\"Im" +
				"port this Component\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAl" +
				"ign:CenterCenter;}\t3{Width:45;Name:\"IsNew\";Caption:\"New\";Visible:False;DataType:" +
				"System.Boolean;TextAlign:CenterCenter;TextAlignFixed:CenterCenter;ImageAlign:Cen" +
				"terCenter;}\t4{Width:100;Name:\"FacilityName\";Caption:\"Facility\";DataType:System.S" +
				"tring;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t5{Width:100;Name:\"Proce" +
				"ssName\";Caption:\"Process\";DataType:System.String;TextAlign:LeftCenter;TextAlignF" +
				"ixed:CenterCenter;}\t6{Width:206;Name:\"ComponentName\";Caption:\"Component / Subbas" +
				"in / Subzone Name\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t7{Width:100;Name:\"RenameExistingComponent\";Caption:\"Rename Existing" +
				" Component\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:Cente" +
				"rCenter;}\t8{Name:\"ComponentType\";Caption:\"Component Type\";DataType:System.String" +
				";TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t9{Width:60;Name:\"Retired\";Ca" +
				"ption:\"Retired\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:C" +
				"enterCenter;}\t10{Width:100;Name:\"ComponentPhotoFileName\";Caption:\"Component Phot" +
				"o File\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;" +
				"}\t11{Width:100;Name:\"ComponentPhotoCaption\";Caption:\"Component Photo Caption\";Da" +
				"taType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t12{Width" +
				":189;Name:\"Comments\";Caption:\"Comments\";DataType:System.String;TextAlign:LeftCen" +
				"ter;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridComponentPN.ExtendLastCol = true;
			this.c1FlexGridComponentPN.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridComponentPN.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridComponentPN.Name = "c1FlexGridComponentPN";
			this.c1FlexGridComponentPN.Rows.Count = 2;
			this.c1FlexGridComponentPN.Rows.Fixed = 2;
			this.c1FlexGridComponentPN.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridComponentPN.ShowSort = false;
			this.c1FlexGridComponentPN.Size = new System.Drawing.Size(713, 266);
			this.c1FlexGridComponentPN.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridComponentPN.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridComponentPN.TabIndex = 4;
			this.c1FlexGridComponentPN.SetupEditor += new C1.Win.C1FlexGrid.RowColEventHandler(this.ComponentGrid_SetupEditor);
			this.c1FlexGridComponentPN.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.ComponentGrid_AfterEdit);
			this.c1FlexGridComponentPN.ValidateEdit += new C1.Win.C1FlexGrid.ValidateEditEventHandler(this.ComponentGrid_ValidateEdit);
			// 
			// tabPageComponent
			// 
			this.tabPageComponent.BackColor = System.Drawing.Color.White;
			this.tabPageComponent.Controls.Add(this.panelCompGrid);
			this.tabPageComponent.Location = new System.Drawing.Point(4, 28);
			this.tabPageComponent.Name = "tabPageComponent";
			this.tabPageComponent.Size = new System.Drawing.Size(716, 272);
			this.tabPageComponent.TabIndex = 3;
			this.tabPageComponent.Text = "Component MSC";
			this.tabPageComponent.Visible = false;
			// 
			// panelCompGrid
			// 
			this.panelCompGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelCompGrid.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelCompGrid.Controls.Add(this.c1FlexGridComponent);
			this.panelCompGrid.Location = new System.Drawing.Point(0, 3);
			this.panelCompGrid.Name = "panelCompGrid";
			this.panelCompGrid.Size = new System.Drawing.Size(715, 268);
			this.panelCompGrid.TabIndex = 5;
			// 
			// c1FlexGridComponent
			// 
			this.c1FlexGridComponent.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridComponent.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridComponent.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridComponent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridComponent.AutoResize = false;
			this.c1FlexGridComponent.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridComponent.ColumnInfo = "24,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDragg" +
				"ing:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t1" +
				"{Name:\"TempID\";Caption:\"TempID\";AllowEditing:False;DataType:System.Int32;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t2{Width:75;Name:\"Import\";Caption:\"Im" +
				"port this Comopnent\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAl" +
				"ign:CenterCenter;}\t3{Width:45;Name:\"IsNew\";Caption:\"New\";Visible:False;DataType:" +
				"System.Boolean;TextAlign:CenterCenter;TextAlignFixed:CenterCenter;ImageAlign:Cen" +
				"terCenter;}\t4{Width:100;Name:\"FacilityName\";Caption:\"Facility\";DataType:System.S" +
				"tring;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t5{Width:120;Name:\"Proce" +
				"ssName\";Caption:\"Process\";DataType:System.String;TextAlign:LeftCenter;TextAlignF" +
				"ixed:CenterCenter;}\t6{Width:206;Name:\"ComponentName\";Caption:\"Component / Subbas" +
				"in / Subzone Name\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:Ce" +
				"nterCenter;}\t7{Width:100;Name:\"RenameExistingComponent\";Caption:\"Rename Existing" +
				" Component\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:Cente" +
				"rCenter;}\t8{Name:\"ComponentType\";Caption:\"Component Type\";DataType:System.String" +
				";TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t9{Width:60;Name:\"Retired\";Ca" +
				"ption:\"Retired\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:C" +
				"enterCenter;}\t10{Name:\"LOS\";Caption:\"Level of Service\";DataType:System.String;Te" +
				"xtAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t11{Name:\"RedundantAssets\";Capti" +
				"on:\"Number of Assets with Similar Functionality\";DataType:System.String;TextAlig" +
				"n:LeftCenter;TextAlignFixed:CenterCenter;}\t12{Name:\"CipPlanningMode\";Caption:\"Pl" +
				"anning Mode\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCe" +
				"nter;}\t13{Name:\"AssetClass\";Caption:\"Asset Class\";DataType:System.String;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t14{Name:\"Crit1\";Caption:\"Criticality" +
				"1\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t15{" +
				"Name:\"Crit2\";Caption:\"Criticality2\";DataType:System.String;TextAlign:LeftCenter;" +
				"TextAlignFixed:CenterCenter;}\t16{Name:\"Crit3\";Caption:\"Criticality3\";DataType:Sy" +
				"stem.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t17{Name:\"Crit4\";C" +
				"aption:\"Criticality4\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed" +
				":CenterCenter;}\t18{Name:\"Crit5\";Caption:\"Criticality5\";DataType:System.String;Te" +
				"xtAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t19{Name:\"Crit6\";Caption:\"Critic" +
				"ality6\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;" +
				"}\t20{Name:\"Vulnerability\";Caption:\"Vulnerability\";DataType:System.String;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t21{Width:100;Name:\"ComponentPhotoFil" +
				"eName\";Caption:\"Component Photo File\";DataType:System.String;TextAlign:LeftCente" +
				"r;TextAlignFixed:CenterCenter;}\t22{Width:100;Name:\"ComponentPhotoCaption\";Captio" +
				"n:\"Component Photo Caption\";DataType:System.String;TextAlign:LeftCenter;TextAlig" +
				"nFixed:CenterCenter;}\t23{Width:189;Name:\"Comments\";Caption:\"Comments\";DataType:S" +
				"ystem.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridComponent.ExtendLastCol = true;
			this.c1FlexGridComponent.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridComponent.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridComponent.Name = "c1FlexGridComponent";
			this.c1FlexGridComponent.Rows.Count = 2;
			this.c1FlexGridComponent.Rows.Fixed = 2;
			this.c1FlexGridComponent.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridComponent.ShowSort = false;
			this.c1FlexGridComponent.Size = new System.Drawing.Size(713, 266);
			this.c1FlexGridComponent.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridComponent.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridComponent.TabIndex = 3;
			this.c1FlexGridComponent.SetupEditor += new C1.Win.C1FlexGrid.RowColEventHandler(this.ComponentGrid_SetupEditor);
			this.c1FlexGridComponent.ComboDropDown += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridComponent_ComboDropDown);
			this.c1FlexGridComponent.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.ComponentGrid_AfterEdit);
			this.c1FlexGridComponent.ValidateEdit += new C1.Win.C1FlexGrid.ValidateEditEventHandler(this.ComponentGrid_ValidateEdit);
			this.c1FlexGridComponent.ChangeEdit += new System.EventHandler(this.c1FlexGridComponent_ChangeEdit);
			this.c1FlexGridComponent.ComboCloseUp += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridComponent_ComboCloseUp);
			this.c1FlexGridComponent.CellButtonClick += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridComponent_CellButtonClick);
			// 
			// tabPageDiscipline
			// 
			this.tabPageDiscipline.BackColor = System.Drawing.Color.White;
			this.tabPageDiscipline.Controls.Add(this.panelDiscGrid);
			this.tabPageDiscipline.Location = new System.Drawing.Point(4, 28);
			this.tabPageDiscipline.Name = "tabPageDiscipline";
			this.tabPageDiscipline.Size = new System.Drawing.Size(716, 272);
			this.tabPageDiscipline.TabIndex = 2;
			this.tabPageDiscipline.Text = "Discipline";
			this.tabPageDiscipline.Visible = false;
			// 
			// panelDiscGrid
			// 
			this.panelDiscGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelDiscGrid.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelDiscGrid.Controls.Add(this.c1FlexGridDiscipline);
			this.panelDiscGrid.Location = new System.Drawing.Point(0, 3);
			this.panelDiscGrid.Name = "panelDiscGrid";
			this.panelDiscGrid.Size = new System.Drawing.Size(715, 268);
			this.panelDiscGrid.TabIndex = 5;
			// 
			// c1FlexGridDiscipline
			// 
			this.c1FlexGridDiscipline.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridDiscipline.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridDiscipline.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridDiscipline.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridDiscipline.AutoResize = false;
			this.c1FlexGridDiscipline.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridDiscipline.ColumnInfo = "14,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDragg" +
				"ing:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t1" +
				"{Name:\"TempID\";Caption:\"TempID\";AllowEditing:False;DataType:System.Int32;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t2{Width:100;Name:\"LoadedFacilityName" +
				"\";Caption:\"Fac Name Hidden\";AllowEditing:False;DataType:System.String;TextAlign:" +
				"LeftCenter;TextAlignFixed:CenterCenter;}\t3{Width:100;Name:\"LoadedProcessName\";Ca" +
				"ption:\"Proc Name Hidden\";AllowEditing:False;DataType:System.String;TextAlign:Lef" +
				"tCenter;TextAlignFixed:CenterCenter;}\t4{Width:100;Name:\"LoadedComponentName\";Cap" +
				"tion:\"Comp Name Hidden\";AllowEditing:False;DataType:System.String;TextAlign:Left" +
				"Center;TextAlignFixed:CenterCenter;}\t5{Width:75;Name:\"Import\";Caption:\"Import th" +
				"is Discipline\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAlign:Ce" +
				"nterCenter;}\t6{Width:45;Name:\"IsNew\";Caption:\"New\";Visible:False;DataType:System" +
				".Boolean;TextAlign:CenterCenter;TextAlignFixed:CenterCenter;ImageAlign:CenterCen" +
				"ter;}\t7{Width:100;Name:\"FacilityName\";Caption:\"Facility\";AllowEditing:False;Data" +
				"Type:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t8{Width:10" +
				"0;Name:\"ProcessName\";Caption:\"Process\";AllowEditing:False;DataType:System.String" +
				";TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t9{Width:100;Name:\"ComponentN" +
				"ame\";Caption:\"Component\";DataType:System.String;TextAlign:LeftCenter;TextAlignFi" +
				"xed:CenterCenter;}\t10{Width:100;Name:\"DisciplineType\";Caption:\"Discipline Type\";" +
				"DataType:System.Int32;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t11{Widt" +
				"h:100;Name:\"DisciplinePhotoFileName\";Caption:\"Discipline Photo File\";DataType:Sy" +
				"stem.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t12{Width:100;Name" +
				":\"DisciplinePhotoCaption\";Caption:\"Discipline Photo Caption\";DataType:System.Str" +
				"ing;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t13{Width:189;Name:\"Commen" +
				"ts\";Caption:\"Comments\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixe" +
				"d:CenterCenter;}\t";
			this.c1FlexGridDiscipline.ExtendLastCol = true;
			this.c1FlexGridDiscipline.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridDiscipline.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridDiscipline.Name = "c1FlexGridDiscipline";
			this.c1FlexGridDiscipline.Rows.Count = 1;
			this.c1FlexGridDiscipline.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridDiscipline.ShowSort = false;
			this.c1FlexGridDiscipline.Size = new System.Drawing.Size(713, 266);
			this.c1FlexGridDiscipline.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridDiscipline.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridDiscipline.TabIndex = 5;
			this.c1FlexGridDiscipline.SetupEditor += new C1.Win.C1FlexGrid.RowColEventHandler(this.DisciplineGrid_SetupEditor);
			this.c1FlexGridDiscipline.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridDiscipline_AfterEdit);
			this.c1FlexGridDiscipline.ValidateEdit += new C1.Win.C1FlexGrid.ValidateEditEventHandler(this.DisciplineGrid_ValidateEdit);
			this.c1FlexGridDiscipline.CellButtonClick += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridDiscipline_CellButtonClick);
			// 
			// tabPageSampleData
			// 
			this.tabPageSampleData.BackColor = System.Drawing.SystemColors.Control;
			this.tabPageSampleData.Controls.Add(this.panelSampleGrid);
			this.tabPageSampleData.Location = new System.Drawing.Point(4, 28);
			this.tabPageSampleData.Name = "tabPageSampleData";
			this.tabPageSampleData.Size = new System.Drawing.Size(716, 272);
			this.tabPageSampleData.TabIndex = 7;
			this.tabPageSampleData.Text = "Sample Data";
			// 
			// panelSampleGrid
			// 
			this.panelSampleGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSampleGrid.BackColor = System.Drawing.Color.White;
			this.panelSampleGrid.Controls.Add(this.panelSampleToolbarOutline);
			this.panelSampleGrid.Controls.Add(this.c1FlexGridSampleData);
			this.panelSampleGrid.Location = new System.Drawing.Point(0, 3);
			this.panelSampleGrid.Name = "panelSampleGrid";
			this.panelSampleGrid.Size = new System.Drawing.Size(715, 268);
			this.panelSampleGrid.TabIndex = 7;
			// 
			// panelSampleToolbarOutline
			// 
			this.panelSampleToolbarOutline.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSampleToolbarOutline.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSampleToolbarOutline.Controls.Add(this.panelSampleToolbarInterior);
			this.panelSampleToolbarOutline.Location = new System.Drawing.Point(1, 0);
			this.panelSampleToolbarOutline.Name = "panelSampleToolbarOutline";
			this.panelSampleToolbarOutline.Size = new System.Drawing.Size(713, 32);
			this.panelSampleToolbarOutline.TabIndex = 183;
			// 
			// panelSampleToolbarInterior
			// 
			this.panelSampleToolbarInterior.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelSampleToolbarInterior.BackColor = System.Drawing.Color.White;
			this.panelSampleToolbarInterior.Controls.Add(this.pictureBoxLoadSampleData);
			this.panelSampleToolbarInterior.Controls.Add(this.pictureBoxPopulateTabsSample);
			this.panelSampleToolbarInterior.Location = new System.Drawing.Point(1, 1);
			this.panelSampleToolbarInterior.Name = "panelSampleToolbarInterior";
			this.panelSampleToolbarInterior.Size = new System.Drawing.Size(711, 30);
			this.panelSampleToolbarInterior.TabIndex = 183;
			// 
			// pictureBoxLoadSampleData
			// 
			this.pictureBoxLoadSampleData.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxLoadSampleData.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxLoadSampleData.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLoadSampleData.Image")));
			this.pictureBoxLoadSampleData.Location = new System.Drawing.Point(8, 5);
			this.pictureBoxLoadSampleData.Name = "pictureBoxLoadSampleData";
			this.pictureBoxLoadSampleData.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxLoadSampleData.TabIndex = 149;
			this.pictureBoxLoadSampleData.TabStop = false;
			this.pictureBoxLoadSampleData.Click += new System.EventHandler(this.pictureBoxLoadSampleData_Click);
			// 
			// pictureBoxPopulateTabsSample
			// 
			this.pictureBoxPopulateTabsSample.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxPopulateTabsSample.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxPopulateTabsSample.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPopulateTabsSample.Image")));
			this.pictureBoxPopulateTabsSample.Location = new System.Drawing.Point(32, 5);
			this.pictureBoxPopulateTabsSample.Name = "pictureBoxPopulateTabsSample";
			this.pictureBoxPopulateTabsSample.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxPopulateTabsSample.TabIndex = 147;
			this.pictureBoxPopulateTabsSample.TabStop = false;
			this.pictureBoxPopulateTabsSample.Click += new System.EventHandler(this.pictureBoxPopulateTabsSample_Click);
			// 
			// c1FlexGridSampleData
			// 
			this.c1FlexGridSampleData.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridSampleData.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridSampleData.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridSampleData.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
			this.c1FlexGridSampleData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridSampleData.AutoResize = false;
			this.c1FlexGridSampleData.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridSampleData.ColumnInfo = "1,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDraggi" +
				"ng:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridSampleData.ExtendLastCol = true;
			this.c1FlexGridSampleData.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridSampleData.Location = new System.Drawing.Point(1, 32);
			this.c1FlexGridSampleData.Name = "c1FlexGridSampleData";
			this.c1FlexGridSampleData.Rows.Count = 1;
			this.c1FlexGridSampleData.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridSampleData.ShowSort = false;
			this.c1FlexGridSampleData.Size = new System.Drawing.Size(713, 238);
			this.c1FlexGridSampleData.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridSampleData.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridSampleData.TabIndex = 6;
			// 
			// tabPageFacility
			// 
			this.tabPageFacility.BackColor = System.Drawing.Color.White;
			this.tabPageFacility.Controls.Add(this.panelFacGrid);
			this.tabPageFacility.Location = new System.Drawing.Point(4, 28);
			this.tabPageFacility.Name = "tabPageFacility";
			this.tabPageFacility.Size = new System.Drawing.Size(716, 272);
			this.tabPageFacility.TabIndex = 0;
			this.tabPageFacility.Text = "Facility";
			// 
			// panelFacGrid
			// 
			this.panelFacGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelFacGrid.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelFacGrid.Controls.Add(this.c1FlexGridFacility);
			this.panelFacGrid.Location = new System.Drawing.Point(0, 3);
			this.panelFacGrid.Name = "panelFacGrid";
			this.panelFacGrid.Size = new System.Drawing.Size(715, 268);
			this.panelFacGrid.TabIndex = 3;
			// 
			// c1FlexGridFacility
			// 
			this.c1FlexGridFacility.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridFacility.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridFacility.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridFacility.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridFacility.AutoResize = false;
			this.c1FlexGridFacility.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridFacility.ColumnInfo = "14,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDragg" +
				"ing:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t1" +
				"{Name:\"TempID\";Caption:\"TempID\";AllowEditing:False;DataType:System.Int32;TextAli" +
				"gn:LeftCenter;TextAlignFixed:CenterCenter;}\t2{Width:75;Name:\"Import\";Caption:\"Im" +
				"port this Facility\";DataType:System.Boolean;TextAlignFixed:CenterCenter;ImageAli" +
				"gn:CenterCenter;}\t3{Width:45;Name:\"IsNew\";Caption:\"New\";Visible:False;DataType:S" +
				"ystem.Boolean;TextAlign:CenterCenter;TextAlignFixed:CenterCenter;ImageAlign:Cent" +
				"erCenter;}\t4{Width:206;Name:\"FacilityName\";Caption:\"Facility / System Name\";Data" +
				"Type:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t5{Width:10" +
				"0;Name:\"RenameExistingFacility\";Caption:\"Rename Existing Facility\";DataType:Syst" +
				"em.Boolean;TextAlignFixed:CenterCenter;ImageAlign:CenterCenter;}\t6{Name:\"Facilit" +
				"yCurrentYear\";Caption:\"Facility Year\";DataType:System.String;TextAlign:LeftCente" +
				"r;TextAlignFixed:CenterCenter;}\t7{Name:\"FacilityCriticality\";Caption:\"Facility C" +
				"riticality\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCen" +
				"ter;}\t8{Width:131;Name:\"CustomENRTable\";Caption:\"Custom ENR Table\";DataType:Syst" +
				"em.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t9{Width:100;Name:\"F" +
				"acilityPhotoFileNameNorth\";Caption:\"Facility Photo File 1\";DataType:System.Strin" +
				"g;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t10{Width:100;Name:\"Facility" +
				"PhotoCaptionNorth\";Caption:\"Facility Photo Caption 1\";DataType:System.String;Tex" +
				"tAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t11{Width:100;Name:\"FacilityPhoto" +
				"FileNameSouth\";Caption:\"Facility Photo File 2\";DataType:System.String;TextAlign:" +
				"LeftCenter;TextAlignFixed:CenterCenter;}\t12{Width:100;Name:\"FacilityPhotoCaption" +
				"South\";Caption:\"Facility Photo Caption 2\";DataType:System.String;TextAlign:LeftC" +
				"enter;TextAlignFixed:CenterCenter;}\t13{Width:189;Name:\"Comments\";Caption:\"Commen" +
				"ts\";DataType:System.String;TextAlign:LeftCenter;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridFacility.ExtendLastCol = true;
			this.c1FlexGridFacility.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridFacility.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridFacility.Name = "c1FlexGridFacility";
			this.c1FlexGridFacility.Rows.Count = 1;
			this.c1FlexGridFacility.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridFacility.ShowSort = false;
			this.c1FlexGridFacility.Size = new System.Drawing.Size(712, 266);
			this.c1FlexGridFacility.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridFacility.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridFacility.TabIndex = 1;
			this.c1FlexGridFacility.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridFacility_AfterEdit);
			// 
			// tabPageOverview
			// 
			this.tabPageOverview.BackColor = System.Drawing.Color.White;
			this.tabPageOverview.Controls.Add(this.panelGridOverview);
			this.tabPageOverview.Location = new System.Drawing.Point(4, 28);
			this.tabPageOverview.Name = "tabPageOverview";
			this.tabPageOverview.Size = new System.Drawing.Size(716, 272);
			this.tabPageOverview.TabIndex = 8;
			this.tabPageOverview.Text = "Summary";
			// 
			// panelGridOverview
			// 
			this.panelGridOverview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelGridOverview.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelGridOverview.Controls.Add(this.c1FlexGridOverview);
			this.panelGridOverview.Location = new System.Drawing.Point(0, 3);
			this.panelGridOverview.Name = "panelGridOverview";
			this.panelGridOverview.Size = new System.Drawing.Size(715, 268);
			this.panelGridOverview.TabIndex = 4;
			// 
			// c1FlexGridOverview
			// 
			this.c1FlexGridOverview.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.c1FlexGridOverview.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
			this.c1FlexGridOverview.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
			this.c1FlexGridOverview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridOverview.AutoResize = false;
			this.c1FlexGridOverview.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridOverview.ColumnInfo = "1,1,0,0,0,85,Columns:0{Width:20;AllowSorting:False;Name:\"RowSelector\";AllowDraggi" +
				"ng:False;AllowResizing:False;AllowEditing:False;TextAlignFixed:CenterCenter;}\t";
			this.c1FlexGridOverview.ExtendLastCol = true;
			this.c1FlexGridOverview.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcross;
			this.c1FlexGridOverview.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridOverview.Name = "c1FlexGridOverview";
			this.c1FlexGridOverview.Rows.Count = 1;
			this.c1FlexGridOverview.ShowButtons = C1.Win.C1FlexGrid.ShowButtonsEnum.Always;
			this.c1FlexGridOverview.ShowSort = false;
			this.c1FlexGridOverview.Size = new System.Drawing.Size(712, 266);
			this.c1FlexGridOverview.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 7pt;BackColor:Control;ForeColor:ControlText;TextAlign:CenterCenter;Trimming:EllipsisCharacter;WordWrap:True;Border:Flat,1,ControlDark,Both;}	Highlight{Format:""F1"";BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:ControlDark;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:PaleTurquoise;ForeColor:Black;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	HighlightLeft{BackColor:Highlight;ForeColor:HighlightText;TextAlign:LeftCenter;}	");
			this.c1FlexGridOverview.SubtotalPosition = C1.Win.C1FlexGrid.SubtotalPositionEnum.BelowData;
			this.c1FlexGridOverview.TabIndex = 1;
			// 
			// comboBoxSheet
			// 
			this.comboBoxSheet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxSheet.Location = new System.Drawing.Point(445, 6);
			this.comboBoxSheet.MaxDropDownItems = 20;
			this.comboBoxSheet.Name = "comboBoxSheet";
			this.comboBoxSheet.Size = new System.Drawing.Size(190, 21);
			this.comboBoxSheet.TabIndex = 181;
			this.comboBoxSheet.TabStop = false;
			this.comboBoxSheet.SelectedIndexChanged += new System.EventHandler(this.comboBoxSheet_SelectedIndexChanged);
			// 
			// pictureBoxToolbarSelectFile
			// 
			this.pictureBoxToolbarSelectFile.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarSelectFile.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarSelectFile.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarSelectFile.Image")));
			this.pictureBoxToolbarSelectFile.Location = new System.Drawing.Point(132, 7);
			this.pictureBoxToolbarSelectFile.Name = "pictureBoxToolbarSelectFile";
			this.pictureBoxToolbarSelectFile.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarSelectFile.TabIndex = 147;
			this.pictureBoxToolbarSelectFile.TabStop = false;
			this.pictureBoxToolbarSelectFile.Click += new System.EventHandler(this.pictureBoxToolbarSelectFile_Click);
			// 
			// pictureBoxToolbarExport
			// 
			this.pictureBoxToolbarExport.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarExport.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarExport.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarExport.Image")));
			this.pictureBoxToolbarExport.Location = new System.Drawing.Point(266, 7);
			this.pictureBoxToolbarExport.Name = "pictureBoxToolbarExport";
			this.pictureBoxToolbarExport.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarExport.TabIndex = 146;
			this.pictureBoxToolbarExport.TabStop = false;
			this.pictureBoxToolbarExport.Click += new System.EventHandler(this.pictureBoxToolbarExport_Click);
			// 
			// pictureBoxToolbarHelp
			// 
			this.pictureBoxToolbarHelp.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarHelp.Image")));
			this.pictureBoxToolbarHelp.Location = new System.Drawing.Point(352, 7);
			this.pictureBoxToolbarHelp.Name = "pictureBoxToolbarHelp";
			this.pictureBoxToolbarHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarHelp.TabIndex = 145;
			this.pictureBoxToolbarHelp.TabStop = false;
			this.pictureBoxToolbarHelp.Click += new System.EventHandler(this.pictureBoxToolbarHelp_Click);
			// 
			// pictureBoxToolbarAddGridRow
			// 
			this.pictureBoxToolbarAddGridRow.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAddGridRow.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAddGridRow.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAddGridRow.Image")));
			this.pictureBoxToolbarAddGridRow.Location = new System.Drawing.Point(175, 7);
			this.pictureBoxToolbarAddGridRow.Name = "pictureBoxToolbarAddGridRow";
			this.pictureBoxToolbarAddGridRow.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAddGridRow.TabIndex = 142;
			this.pictureBoxToolbarAddGridRow.TabStop = false;
			this.pictureBoxToolbarAddGridRow.Click += new System.EventHandler(this.pictureBoxToolbarAddGridRow_Click);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(722, 32);
			this.labelTitle.TabIndex = 148;
			this.labelTitle.Text = " Import Data";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(722, 4);
			this.panelSeparator.TabIndex = 149;
			this.panelSeparator.Visible = false;
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.Location = new System.Drawing.Point(539, 486);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(84, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&Import Data";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(630, 486);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(84, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Close";
			// 
			// buttonTest
			// 
			this.buttonTest.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(100)), ((System.Byte)(100)));
			this.buttonTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.buttonTest.Location = new System.Drawing.Point(8, 488);
			this.buttonTest.Name = "buttonTest";
			this.buttonTest.TabIndex = 153;
			this.buttonTest.Text = "test";
			this.buttonTest.Visible = false;
			this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
			// 
			// buttonValidate
			// 
			this.buttonValidate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonValidate.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonValidate.Location = new System.Drawing.Point(448, 486);
			this.buttonValidate.Name = "buttonValidate";
			this.buttonValidate.Size = new System.Drawing.Size(84, 23);
			this.buttonValidate.TabIndex = 1;
			this.buttonValidate.Text = "&Validate Data";
			this.buttonValidate.Click += new System.EventHandler(this.buttonValidate_Click);
			// 
			// panelErrors
			// 
			this.panelErrors.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panelErrors.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelErrors.Controls.Add(this.panel8);
			this.panelErrors.Location = new System.Drawing.Point(5, 344);
			this.panelErrors.Name = "panelErrors";
			this.panelErrors.Size = new System.Drawing.Size(168, 112);
			this.panelErrors.TabIndex = 171;
			// 
			// panel8
			// 
			this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel8.BackColor = System.Drawing.Color.White;
			this.panel8.Controls.Add(this.label2);
			this.panel8.Controls.Add(this.labelErrorCountDisc);
			this.panel8.Controls.Add(this.labelErrorCountCompPN);
			this.panel8.Controls.Add(this.labelErrorCountComp);
			this.panel8.Controls.Add(this.labelErrorCountProc);
			this.panel8.Controls.Add(this.labelErrorCountFac);
			this.panel8.Controls.Add(this.labelErrorCount);
			this.panel8.Controls.Add(this.label1);
			this.panel8.Controls.Add(this.linkLabelErrorFac);
			this.panel8.Controls.Add(this.linkLabelErrorProc);
			this.panel8.Controls.Add(this.linkLabelErrorComp);
			this.panel8.Controls.Add(this.linkLabelErrorCompPN);
			this.panel8.Controls.Add(this.linkLabelErrorDisc);
			this.panel8.Location = new System.Drawing.Point(1, 1);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(166, 110);
			this.panel8.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.label2.Location = new System.Drawing.Point(7, 2);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(49, 15);
			this.label2.TabIndex = 185;
			this.label2.Text = "Errors:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelErrorCountDisc
			// 
			this.labelErrorCountDisc.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCountDisc.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCountDisc.Location = new System.Drawing.Point(137, 66);
			this.labelErrorCountDisc.Name = "labelErrorCountDisc";
			this.labelErrorCountDisc.Size = new System.Drawing.Size(24, 14);
			this.labelErrorCountDisc.TabIndex = 184;
			this.labelErrorCountDisc.Text = "0";
			this.labelErrorCountDisc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelErrorCountCompPN
			// 
			this.labelErrorCountCompPN.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCountCompPN.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCountCompPN.Location = new System.Drawing.Point(137, 50);
			this.labelErrorCountCompPN.Name = "labelErrorCountCompPN";
			this.labelErrorCountCompPN.Size = new System.Drawing.Size(24, 14);
			this.labelErrorCountCompPN.TabIndex = 182;
			this.labelErrorCountCompPN.Text = "0";
			this.labelErrorCountCompPN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelErrorCountComp
			// 
			this.labelErrorCountComp.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCountComp.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCountComp.Location = new System.Drawing.Point(137, 34);
			this.labelErrorCountComp.Name = "labelErrorCountComp";
			this.labelErrorCountComp.Size = new System.Drawing.Size(24, 15);
			this.labelErrorCountComp.TabIndex = 180;
			this.labelErrorCountComp.Text = "0";
			this.labelErrorCountComp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelErrorCountProc
			// 
			this.labelErrorCountProc.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCountProc.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCountProc.Location = new System.Drawing.Point(137, 18);
			this.labelErrorCountProc.Name = "labelErrorCountProc";
			this.labelErrorCountProc.Size = new System.Drawing.Size(24, 15);
			this.labelErrorCountProc.TabIndex = 178;
			this.labelErrorCountProc.Text = "0";
			this.labelErrorCountProc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelErrorCountFac
			// 
			this.labelErrorCountFac.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCountFac.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCountFac.Location = new System.Drawing.Point(137, 2);
			this.labelErrorCountFac.Name = "labelErrorCountFac";
			this.labelErrorCountFac.Size = new System.Drawing.Size(24, 15);
			this.labelErrorCountFac.TabIndex = 176;
			this.labelErrorCountFac.Text = "0";
			this.labelErrorCountFac.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelErrorCount
			// 
			this.labelErrorCount.BackColor = System.Drawing.Color.Transparent;
			this.labelErrorCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelErrorCount.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorCount.Location = new System.Drawing.Point(137, 90);
			this.labelErrorCount.Name = "labelErrorCount";
			this.labelErrorCount.Size = new System.Drawing.Size(24, 15);
			this.labelErrorCount.TabIndex = 174;
			this.labelErrorCount.Text = "0";
			this.labelErrorCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.label1.Location = new System.Drawing.Point(7, 90);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 15);
			this.label1.TabIndex = 173;
			this.label1.Text = "Total Errors:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// linkLabelErrorFac
			// 
			this.linkLabelErrorFac.ActiveLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorFac.DisabledLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorFac.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorFac.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkLabelErrorFac.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorFac.Location = new System.Drawing.Point(87, 2);
			this.linkLabelErrorFac.Name = "linkLabelErrorFac";
			this.linkLabelErrorFac.Size = new System.Drawing.Size(48, 15);
			this.linkLabelErrorFac.TabIndex = 188;
			this.linkLabelErrorFac.TabStop = true;
			this.linkLabelErrorFac.Tag = "Fac";
			this.linkLabelErrorFac.Text = "Facility:";
			this.linkLabelErrorFac.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.linkLabelErrorFac.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			// 
			// linkLabelErrorProc
			// 
			this.linkLabelErrorProc.ActiveLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorProc.DisabledLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorProc.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorProc.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkLabelErrorProc.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorProc.Location = new System.Drawing.Point(87, 18);
			this.linkLabelErrorProc.Name = "linkLabelErrorProc";
			this.linkLabelErrorProc.Size = new System.Drawing.Size(48, 15);
			this.linkLabelErrorProc.TabIndex = 189;
			this.linkLabelErrorProc.TabStop = true;
			this.linkLabelErrorProc.Tag = "Proc";
			this.linkLabelErrorProc.Text = "Process:";
			this.linkLabelErrorProc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.linkLabelErrorProc.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			// 
			// linkLabelErrorComp
			// 
			this.linkLabelErrorComp.ActiveLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorComp.DisabledLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorComp.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorComp.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkLabelErrorComp.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorComp.Location = new System.Drawing.Point(-17, 34);
			this.linkLabelErrorComp.Name = "linkLabelErrorComp";
			this.linkLabelErrorComp.Size = new System.Drawing.Size(152, 15);
			this.linkLabelErrorComp.TabIndex = 190;
			this.linkLabelErrorComp.TabStop = true;
			this.linkLabelErrorComp.Tag = "Comp";
			this.linkLabelErrorComp.Text = "Major Component (MSC):";
			this.linkLabelErrorComp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.linkLabelErrorComp.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			// 
			// linkLabelErrorCompPN
			// 
			this.linkLabelErrorCompPN.ActiveLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorCompPN.DisabledLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorCompPN.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorCompPN.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkLabelErrorCompPN.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorCompPN.Location = new System.Drawing.Point(7, 50);
			this.linkLabelErrorCompPN.Name = "linkLabelErrorCompPN";
			this.linkLabelErrorCompPN.Size = new System.Drawing.Size(128, 15);
			this.linkLabelErrorCompPN.TabIndex = 191;
			this.linkLabelErrorCompPN.TabStop = true;
			this.linkLabelErrorCompPN.Tag = "CompPN";
			this.linkLabelErrorCompPN.Text = "Major Component (PN):";
			this.linkLabelErrorCompPN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.linkLabelErrorCompPN.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			// 
			// linkLabelErrorDisc
			// 
			this.linkLabelErrorDisc.ActiveLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorDisc.DisabledLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorDisc.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorDisc.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkLabelErrorDisc.LinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.linkLabelErrorDisc.Location = new System.Drawing.Point(79, 66);
			this.linkLabelErrorDisc.Name = "linkLabelErrorDisc";
			this.linkLabelErrorDisc.Size = new System.Drawing.Size(56, 15);
			this.linkLabelErrorDisc.TabIndex = 192;
			this.linkLabelErrorDisc.TabStop = true;
			this.linkLabelErrorDisc.Tag = "Disc";
			this.linkLabelErrorDisc.Text = "Discipline:";
			this.linkLabelErrorDisc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.linkLabelErrorDisc.VisitedLinkColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel7.Location = new System.Drawing.Point(0, 335);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(730, 4);
			this.panel7.TabIndex = 177;
			this.panel7.Visible = false;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel5.Location = new System.Drawing.Point(297, 7);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(1, 20);
			this.panel5.TabIndex = 184;
			// 
			// pictureBoxToolbarDeleteGridRow
			// 
			this.pictureBoxToolbarDeleteGridRow.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarDeleteGridRow.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarDeleteGridRow.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarDeleteGridRow.Image")));
			this.pictureBoxToolbarDeleteGridRow.Location = new System.Drawing.Point(199, 7);
			this.pictureBoxToolbarDeleteGridRow.Name = "pictureBoxToolbarDeleteGridRow";
			this.pictureBoxToolbarDeleteGridRow.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarDeleteGridRow.TabIndex = 143;
			this.pictureBoxToolbarDeleteGridRow.TabStop = false;
			this.pictureBoxToolbarDeleteGridRow.Click += new System.EventHandler(this.pictureBoxToolbarDeleteGridRow_Click);
			// 
			// panel9
			// 
			this.panel9.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel9.Location = new System.Drawing.Point(254, 7);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(1, 20);
			this.panel9.TabIndex = 181;
			// 
			// pictureBoxToolbarCheckAll
			// 
			this.pictureBoxToolbarCheckAll.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCheckAll.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCheckAll.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCheckAll.Image")));
			this.pictureBoxToolbarCheckAll.Location = new System.Drawing.Point(223, 7);
			this.pictureBoxToolbarCheckAll.Name = "pictureBoxToolbarCheckAll";
			this.pictureBoxToolbarCheckAll.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCheckAll.TabIndex = 182;
			this.pictureBoxToolbarCheckAll.TabStop = false;
			this.pictureBoxToolbarCheckAll.Click += new System.EventHandler(this.pictureBoxToolbarCheckAll_Click);
			// 
			// pictureBoxToolbarPopulateTabs
			// 
			this.pictureBoxToolbarPopulateTabs.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarPopulateTabs.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarPopulateTabs.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarPopulateTabs.Image")));
			this.pictureBoxToolbarPopulateTabs.Location = new System.Drawing.Point(104, 7);
			this.pictureBoxToolbarPopulateTabs.Name = "pictureBoxToolbarPopulateTabs";
			this.pictureBoxToolbarPopulateTabs.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarPopulateTabs.TabIndex = 148;
			this.pictureBoxToolbarPopulateTabs.TabStop = false;
			this.pictureBoxToolbarPopulateTabs.Visible = false;
			this.pictureBoxToolbarPopulateTabs.Click += new System.EventHandler(this.pictureBoxToolbarPopulateTabs_Click);
			// 
			// panelOpenForm
			// 
			this.panelOpenForm.BackColor = System.Drawing.Color.White;
			this.panelOpenForm.Controls.Add(this.label14);
			this.panelOpenForm.Controls.Add(this.checkBoxOpenForm);
			this.panelOpenForm.Controls.Add(this.label10);
			this.panelOpenForm.Controls.Add(this.label12);
			this.panelOpenForm.Controls.Add(this.pictureBoxInstructionAddGridRow);
			this.panelOpenForm.Controls.Add(this.label6);
			this.panelOpenForm.Controls.Add(this.label4);
			this.panelOpenForm.Controls.Add(this.pictureBoxInstructionSelectFile);
			this.panelOpenForm.Location = new System.Drawing.Point(4, 4);
			this.panelOpenForm.Name = "panelOpenForm";
			this.panelOpenForm.Size = new System.Drawing.Size(272, 126);
			this.panelOpenForm.TabIndex = 181;
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label14.Location = new System.Drawing.Point(4, 4);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(100, 32);
			this.label14.TabIndex = 155;
			this.label14.Text = " To begin:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// checkBoxOpenForm
			// 
			this.checkBoxOpenForm.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxOpenForm.Location = new System.Drawing.Point(12, 122);
			this.checkBoxOpenForm.Name = "checkBoxOpenForm";
			this.checkBoxOpenForm.Size = new System.Drawing.Size(248, 24);
			this.checkBoxOpenForm.TabIndex = 154;
			this.checkBoxOpenForm.Text = "Show this message when the Import form opens";
			this.checkBoxOpenForm.Visible = false;
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(93, 83);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(152, 23);
			this.label10.TabIndex = 153;
			this.label10.Text = "to add rows to the grid";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(24, 83);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(32, 23);
			this.label12.TabIndex = 152;
			this.label12.Text = "or";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxInstructionAddGridRow
			// 
			this.pictureBoxInstructionAddGridRow.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxInstructionAddGridRow.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxInstructionAddGridRow.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxInstructionAddGridRow.Image")));
			this.pictureBoxInstructionAddGridRow.Location = new System.Drawing.Point(64, 84);
			this.pictureBoxInstructionAddGridRow.Name = "pictureBoxInstructionAddGridRow";
			this.pictureBoxInstructionAddGridRow.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxInstructionAddGridRow.TabIndex = 151;
			this.pictureBoxInstructionAddGridRow.TabStop = false;
			this.pictureBoxInstructionAddGridRow.Click += new System.EventHandler(this.pictureBoxInstructionAddGridRow_Click);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(93, 46);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(152, 23);
			this.label6.TabIndex = 150;
			this.label6.Text = "to load an Excel spreadsheet";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(24, 46);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(32, 23);
			this.label4.TabIndex = 149;
			this.label4.Text = "Click";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxInstructionSelectFile
			// 
			this.pictureBoxInstructionSelectFile.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxInstructionSelectFile.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxInstructionSelectFile.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxInstructionSelectFile.Image")));
			this.pictureBoxInstructionSelectFile.Location = new System.Drawing.Point(64, 47);
			this.pictureBoxInstructionSelectFile.Name = "pictureBoxInstructionSelectFile";
			this.pictureBoxInstructionSelectFile.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxInstructionSelectFile.TabIndex = 148;
			this.pictureBoxInstructionSelectFile.TabStop = false;
			this.pictureBoxInstructionSelectFile.Click += new System.EventHandler(this.pictureBoxInstructionSelectFile_Click);
			// 
			// labelErrorTip
			// 
			this.labelErrorTip.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelErrorTip.BackColor = System.Drawing.Color.White;
			this.labelErrorTip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelErrorTip.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelErrorTip.Location = new System.Drawing.Point(6, 17);
			this.labelErrorTip.Name = "labelErrorTip";
			this.labelErrorTip.Size = new System.Drawing.Size(257, 118);
			this.labelErrorTip.TabIndex = 185;
			this.labelErrorTip.Text = "Hold mouse over grid cell to see error message";
			this.labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panelErrorMessage
			// 
			this.panelErrorMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panelErrorMessage.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelErrorMessage.Controls.Add(this.label3);
			this.panelErrorMessage.Controls.Add(this.labelErrorTip);
			this.panelErrorMessage.Controls.Add(this.labelErrorTipBackground);
			this.panelErrorMessage.Location = new System.Drawing.Point(179, 344);
			this.panelErrorMessage.Name = "panelErrorMessage";
			this.panelErrorMessage.Size = new System.Drawing.Size(264, 136);
			this.panelErrorMessage.TabIndex = 186;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.White;
			this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.label3.Location = new System.Drawing.Point(1, 1);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(262, 15);
			this.label3.TabIndex = 186;
			this.label3.Text = " Error Description:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelErrorTipBackground
			// 
			this.labelErrorTipBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelErrorTipBackground.BackColor = System.Drawing.Color.White;
			this.labelErrorTipBackground.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelErrorTipBackground.Location = new System.Drawing.Point(1, 17);
			this.labelErrorTipBackground.Name = "labelErrorTipBackground";
			this.labelErrorTipBackground.Size = new System.Drawing.Size(215, 118);
			this.labelErrorTipBackground.TabIndex = 189;
			this.labelErrorTipBackground.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelOpenForm2
			// 
			this.panelOpenForm2.BackColor = System.Drawing.Color.SteelBlue;
			this.panelOpenForm2.Location = new System.Drawing.Point(9, 10);
			this.panelOpenForm2.Name = "panelOpenForm2";
			this.panelOpenForm2.Size = new System.Drawing.Size(272, 126);
			this.panelOpenForm2.TabIndex = 187;
			// 
			// panelOpenFormHolder
			// 
			this.panelOpenFormHolder.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelOpenFormHolder.Controls.Add(this.panelOpenForm);
			this.panelOpenFormHolder.Controls.Add(this.panelOpenForm2);
			this.panelOpenFormHolder.Location = new System.Drawing.Point(219, 147);
			this.panelOpenFormHolder.Name = "panelOpenFormHolder";
			this.panelOpenFormHolder.Size = new System.Drawing.Size(288, 144);
			this.panelOpenFormHolder.TabIndex = 182;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(163, 7);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1, 20);
			this.panel1.TabIndex = 187;
			// 
			// labelSheet
			// 
			this.labelSheet.Location = new System.Drawing.Point(380, 5);
			this.labelSheet.Name = "labelSheet";
			this.labelSheet.Size = new System.Drawing.Size(64, 21);
			this.labelSheet.TabIndex = 188;
			this.labelSheet.Text = "Worksheet:";
			this.labelSheet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panelGeneralMessage
			// 
			this.panelGeneralMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panelGeneralMessage.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelGeneralMessage.Controls.Add(this.label5);
			this.panelGeneralMessage.Controls.Add(this.labelGeneralMessage);
			this.panelGeneralMessage.Controls.Add(this.labelGeneralMessageBackground);
			this.panelGeneralMessage.Location = new System.Drawing.Point(449, 344);
			this.panelGeneralMessage.Name = "panelGeneralMessage";
			this.panelGeneralMessage.Size = new System.Drawing.Size(264, 136);
			this.panelGeneralMessage.TabIndex = 190;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.White;
			this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.label5.Location = new System.Drawing.Point(1, 1);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(262, 15);
			this.label5.TabIndex = 187;
			this.label5.Text = " Information:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelGeneralMessage
			// 
			this.labelGeneralMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelGeneralMessage.BackColor = System.Drawing.Color.White;
			this.labelGeneralMessage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelGeneralMessage.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(25)), ((System.Byte)(25)), ((System.Byte)(25)));
			this.labelGeneralMessage.Location = new System.Drawing.Point(6, 17);
			this.labelGeneralMessage.Name = "labelGeneralMessage";
			this.labelGeneralMessage.Size = new System.Drawing.Size(257, 118);
			this.labelGeneralMessage.TabIndex = 185;
			this.labelGeneralMessage.Text = "Hold mouse over grid cell to see message";
			this.labelGeneralMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// labelGeneralMessageBackground
			// 
			this.labelGeneralMessageBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelGeneralMessageBackground.BackColor = System.Drawing.Color.White;
			this.labelGeneralMessageBackground.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelGeneralMessageBackground.Location = new System.Drawing.Point(1, 17);
			this.labelGeneralMessageBackground.Name = "labelGeneralMessageBackground";
			this.labelGeneralMessageBackground.Size = new System.Drawing.Size(215, 118);
			this.labelGeneralMessageBackground.TabIndex = 188;
			this.labelGeneralMessageBackground.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pictureBoxToolbarClearAll
			// 
			this.pictureBoxToolbarClearAll.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarClearAll.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarClearAll.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarClearAll.Image")));
			this.pictureBoxToolbarClearAll.Location = new System.Drawing.Point(309, 7);
			this.pictureBoxToolbarClearAll.Name = "pictureBoxToolbarClearAll";
			this.pictureBoxToolbarClearAll.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarClearAll.TabIndex = 191;
			this.pictureBoxToolbarClearAll.TabStop = false;
			this.pictureBoxToolbarClearAll.Click += new System.EventHandler(this.pictureBoxToolbarClearAll_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel2.Location = new System.Drawing.Point(340, 8);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1, 20);
			this.panel2.TabIndex = 192;
			// 
			// checkBoxContinuousValidation
			// 
			this.checkBoxContinuousValidation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.checkBoxContinuousValidation.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxContinuousValidation.Location = new System.Drawing.Point(312, 490);
			this.checkBoxContinuousValidation.Name = "checkBoxContinuousValidation";
			this.checkBoxContinuousValidation.Size = new System.Drawing.Size(136, 16);
			this.checkBoxContinuousValidation.TabIndex = 193;
			this.checkBoxContinuousValidation.Text = "Continuous Validation";
			this.checkBoxContinuousValidation.CheckedChanged += new System.EventHandler(this.checkBoxContinuousValidation_CheckedChanged);
			// 
			// panelProgressDisplay
			// 
			this.panelProgressDisplay.BackColor = System.Drawing.SystemColors.Control;
			this.panelProgressDisplay.Controls.Add(this.panel12);
			this.panelProgressDisplay.Controls.Add(this.panel11);
			this.panelProgressDisplay.Controls.Add(this.panel10);
			this.panelProgressDisplay.Controls.Add(this.panel6);
			this.panelProgressDisplay.Controls.Add(this.panel3);
			this.panelProgressDisplay.Controls.Add(this.buttonCancelImport);
			this.panelProgressDisplay.Controls.Add(this.panel4);
			this.panelProgressDisplay.Controls.Add(this.label8);
			this.panelProgressDisplay.Controls.Add(this.label9);
			this.panelProgressDisplay.Controls.Add(this.textBoxProgressTime);
			this.panelProgressDisplay.Controls.Add(this.textBoxProgressRowCount);
			this.panelProgressDisplay.Controls.Add(this.label7);
			this.panelProgressDisplay.Location = new System.Drawing.Point(211, 132);
			this.panelProgressDisplay.Name = "panelProgressDisplay";
			this.panelProgressDisplay.Size = new System.Drawing.Size(300, 165);
			this.panelProgressDisplay.TabIndex = 194;
			this.panelProgressDisplay.Visible = false;
			// 
			// panel12
			// 
			this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel12.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel12.Location = new System.Drawing.Point(0, 37);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(304, 3);
			this.panel12.TabIndex = 193;
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel11.Location = new System.Drawing.Point(2, 3);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(296, 2);
			this.panel11.TabIndex = 192;
			this.panel11.Visible = false;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel10.Location = new System.Drawing.Point(2, 163);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(296, 2);
			this.panel10.TabIndex = 191;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel6.Location = new System.Drawing.Point(0, 3);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(2, 162);
			this.panel6.TabIndex = 190;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel3.Location = new System.Drawing.Point(298, 3);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(2, 162);
			this.panel3.TabIndex = 189;
			// 
			// buttonCancelImport
			// 
			this.buttonCancelImport.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancelImport.Location = new System.Drawing.Point(90, 118);
			this.buttonCancelImport.Name = "buttonCancelImport";
			this.buttonCancelImport.Size = new System.Drawing.Size(120, 24);
			this.buttonCancelImport.TabIndex = 183;
			this.buttonCancelImport.Text = "Stop Importing Data";
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(300, 3);
			this.panel4.TabIndex = 187;
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label8.Location = new System.Drawing.Point(27, 78);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(128, 15);
			this.label8.TabIndex = 185;
			this.label8.Text = "Time Elapsed:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label9
			// 
			this.label9.BackColor = System.Drawing.Color.Transparent;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label9.Location = new System.Drawing.Point(27, 54);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(128, 15);
			this.label9.TabIndex = 184;
			this.label9.Text = "Rows Imported:";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProgressTime
			// 
			this.textBoxProgressTime.Location = new System.Drawing.Point(157, 77);
			this.textBoxProgressTime.Name = "textBoxProgressTime";
			this.textBoxProgressTime.Size = new System.Drawing.Size(75, 20);
			this.textBoxProgressTime.TabIndex = 182;
			this.textBoxProgressTime.TabStop = false;
			this.textBoxProgressTime.Text = "";
			// 
			// textBoxProgressRowCount
			// 
			this.textBoxProgressRowCount.Location = new System.Drawing.Point(157, 53);
			this.textBoxProgressRowCount.Name = "textBoxProgressRowCount";
			this.textBoxProgressRowCount.Size = new System.Drawing.Size(75, 20);
			this.textBoxProgressRowCount.TabIndex = 181;
			this.textBoxProgressRowCount.TabStop = false;
			this.textBoxProgressRowCount.Text = "";
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.label7.Location = new System.Drawing.Point(0, 4);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(300, 32);
			this.label7.TabIndex = 186;
			this.label7.Text = " Import Data Progress";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// radioButtonTabSingle
			// 
			this.radioButtonTabSingle.Location = new System.Drawing.Point(640, 1);
			this.radioButtonTabSingle.Name = "radioButtonTabSingle";
			this.radioButtonTabSingle.Size = new System.Drawing.Size(104, 16);
			this.radioButtonTabSingle.TabIndex = 195;
			this.radioButtonTabSingle.Text = "Single Tab";
			this.radioButtonTabSingle.Visible = false;
			// 
			// radioButtonTabMultiple
			// 
			this.radioButtonTabMultiple.Location = new System.Drawing.Point(640, 16);
			this.radioButtonTabMultiple.Name = "radioButtonTabMultiple";
			this.radioButtonTabMultiple.Size = new System.Drawing.Size(104, 16);
			this.radioButtonTabMultiple.TabIndex = 196;
			this.radioButtonTabMultiple.Text = "WAM Tabs";
			this.radioButtonTabMultiple.Visible = false;
			// 
			// panelProgress
			// 
			this.panelProgress.BackColor = System.Drawing.Color.White;
			this.panelProgress.Controls.Add(this.buttonStopLoadingExcel);
			this.panelProgress.Controls.Add(this.labelProgress);
			this.panelProgress.Location = new System.Drawing.Point(161, 111);
			this.panelProgress.Name = "panelProgress";
			this.panelProgress.Size = new System.Drawing.Size(400, 296);
			this.panelProgress.TabIndex = 197;
			this.panelProgress.Visible = false;
			// 
			// buttonStopLoadingExcel
			// 
			this.buttonStopLoadingExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonStopLoadingExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonStopLoadingExcel.Location = new System.Drawing.Point(160, 184);
			this.buttonStopLoadingExcel.Name = "buttonStopLoadingExcel";
			this.buttonStopLoadingExcel.Size = new System.Drawing.Size(84, 23);
			this.buttonStopLoadingExcel.TabIndex = 2;
			this.buttonStopLoadingExcel.Text = "Stop";
			this.buttonStopLoadingExcel.Click += new System.EventHandler(this.buttonStopLoadingExcel_Click);
			// 
			// labelProgress
			// 
			this.labelProgress.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelProgress.Location = new System.Drawing.Point(43, 68);
			this.labelProgress.Name = "labelProgress";
			this.labelProgress.Size = new System.Drawing.Size(333, 40);
			this.labelProgress.TabIndex = 0;
			this.labelProgress.Text = "progress message";
			this.labelProgress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ImportFromTextFile
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(722, 518);
			this.Controls.Add(this.panelProgress);
			this.Controls.Add(this.panelOpenFormHolder);
			this.Controls.Add(this.radioButtonTabMultiple);
			this.Controls.Add(this.radioButtonTabSingle);
			this.Controls.Add(this.panelProgressDisplay);
			this.Controls.Add(this.buttonValidate);
			this.Controls.Add(this.checkBoxContinuousValidation);
			this.Controls.Add(this.pictureBoxToolbarHelp);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.pictureBoxToolbarClearAll);
			this.Controls.Add(this.panelGeneralMessage);
			this.Controls.Add(this.comboBoxSheet);
			this.Controls.Add(this.labelSheet);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panelErrorMessage);
			this.Controls.Add(this.pictureBoxToolbarAddGridRow);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.pictureBoxToolbarDeleteGridRow);
			this.Controls.Add(this.panel9);
			this.Controls.Add(this.pictureBoxToolbarCheckAll);
			this.Controls.Add(this.pictureBoxToolbarExport);
			this.Controls.Add(this.pictureBoxToolbarSelectFile);
			this.Controls.Add(this.pictureBoxToolbarPopulateTabs);
			this.Controls.Add(this.panel7);
			this.Controls.Add(this.panelErrors);
			this.Controls.Add(this.buttonTest);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.tabControlImport);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(400, 0);
			this.Name = "ImportFromTextFile";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ImportFromTextFile";
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ImportFromTextFile_MouseMove);
			this.tabControlImport.ResumeLayout(false);
			this.tabPageSpreadsheetData.ResumeLayout(false);
			this.panelSpreadsheetGrid.ResumeLayout(false);
			this.panelSpreadsheetToolbarOutline.ResumeLayout(false);
			this.panelSpreadsheetToolbarInterior.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridSpreadsheetData)).EndInit();
			this.tabPageProcess.ResumeLayout(false);
			this.panelProcGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridProcess)).EndInit();
			this.tabPageComponentPN.ResumeLayout(false);
			this.panelCompPNGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridComponentPN)).EndInit();
			this.tabPageComponent.ResumeLayout(false);
			this.panelCompGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridComponent)).EndInit();
			this.tabPageDiscipline.ResumeLayout(false);
			this.panelDiscGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridDiscipline)).EndInit();
			this.tabPageSampleData.ResumeLayout(false);
			this.panelSampleGrid.ResumeLayout(false);
			this.panelSampleToolbarOutline.ResumeLayout(false);
			this.panelSampleToolbarInterior.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridSampleData)).EndInit();
			this.tabPageFacility.ResumeLayout(false);
			this.panelFacGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridFacility)).EndInit();
			this.tabPageOverview.ResumeLayout(false);
			this.panelGridOverview.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridOverview)).EndInit();
			this.panelErrors.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panelOpenForm.ResumeLayout(false);
			this.panelErrorMessage.ResumeLayout(false);
			this.panelOpenFormHolder.ResumeLayout(false);
			this.panelGeneralMessage.ResumeLayout(false);
			this.panelProgressDisplay.ResumeLayout(false);
			this.panelProgress.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Tasks *****/

		protected override void OnLoad(EventArgs e)
		{
			isInitialized = false;
			this.Text = "Import Data";

			//add tabs to the tab control
			tabControlImport.TabPages.Clear();
			//tabControlImport.TabPages.Add(tabPageSpreadsheetData);
			tabControlImport.TabPages.Add(tabPageFacility);
			tabControlImport.TabPages.Add(tabPageProcess);
			tabControlImport.TabPages.Add(tabPageComponent);
			tabControlImport.TabPages.Add(tabPageComponentPN);
			tabControlImport.TabPages.Add(tabPageDiscipline);
			tabControlImport.TabPages.Add(tabPageOverview);
			tabControlImport.TabPages.Add(tabPageSampleData);

			SetBitmaps();
			SetToolTips();
			ConfigureDataTable();
			ConfigureGrid();
			AssignCellStyles();
			PopulateCustomEnrComboBox();
			PopulateCompTypeComboBox();
			PopulateLosComboBox(c1FlexGridComponent);

			//mam 07072011
			PopulateCipComboBox(c1FlexGridComponent);

			PopulateCritComboBox();
			//PopulateLosComboBox(c1FlexGridDiscipline);
			PopulateConditionComboBox(c1FlexGridDiscipline);
			PopulateDiscTypeComboBox();

			AddExistingFacilitiesToCombo();
			AddExistingProcessesToCombo();
			AddExistingComponentsToCombo();
			AddExistingDisciplinesToCombo();

			AssignCellStyles();
			InitializeVariables();
			InitializeControls();

			checkBoxOpenForm.Checked = true;

			c1FlexGridFacility.AllowAddNew = false;
			c1FlexGridProcess.AllowAddNew = false;
			c1FlexGridComponent.AllowAddNew = false;
			c1FlexGridComponentPN.AllowAddNew = false;
			c1FlexGridDiscipline.AllowAddNew = false;
			c1FlexGridSpreadsheetData.AllowAddNew = false;
			c1FlexGridSampleData.AllowAddNew = false;

			c1FlexGridFacility.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridProcess.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridComponent.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridComponentPN.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridDiscipline.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridSpreadsheetData.AllowFreezing = AllowFreezingEnum.Both;
			c1FlexGridSampleData.AllowFreezing = AllowFreezingEnum.Both;

			AssignDataMapProcessGrid();
			AssignDataMapComponentGrid(c1FlexGridComponent);
			AssignDataMapComponentGrid(c1FlexGridComponentPN);
			AssignDataMapDisciplineGrid();

			SetGridFixedRowCheckMarkImages();

			try
			{
				//load sample data
				LoadSampleData();
			}
			catch
			{
			}

			LoadColumnNames();
			LoadDiscCompInfoTable();

			//LoadBlankSpreadsheet();
			panelOpenForm2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			panelOpenFormHolder.Visible = true;
			//panelOpenFormHolder.Visible = false;

			//mam03202012 - changed to false
			//mam 112806
			checkBoxContinuousValidation.Checked = false;
			SetContinuousValidateProps();

			isInitialized = true;
			SetToolbarButtonState();

			//mam 07072011 - hide the unused crit columns in the Summary tab
			HideUnusedCritColumns(c1FlexGridOverview);

			//mam 07072011 - need to do this here so CipPlanningMode column will behave properly (allow a string to be set as the grid cell data)
			c1FlexGridComponent.Cols["CipPlanningMode"].DataType = typeof(string);

			base.OnLoad(e);
		}

		protected override void OnClosing(CancelEventArgs e) 
		{
			try
			{
				//mam 07072011
				errorDisplay.Close();
				errorDisplay = null;
			}
			catch
			{
			}
		}

		private void LoadColumnNames()
		{
			DataColumn newCol = new DataColumn();
			
			ArrayList arrayListColCaptions = new ArrayList();
			dataTableColNames.Columns.Clear();

			foreach (string colName in Enum.GetNames(typeof(GridColumnName)))
			{
				newCol = dataTableColNames.Columns.Add("NewCol", typeof(string));
				newCol.ColumnName = colName;
			}

			//don't change the order of the captions without also changing the order in the GridColumnName enum!!!

			arrayListColCaptions.Add("Import");
			arrayListColCaptions.Add("Type");
			arrayListColCaptions.Add("Facility Name");
			arrayListColCaptions.Add("Process Name");
			arrayListColCaptions.Add("Component Name");

			//mam 03202012
			arrayListColCaptions.Add("Rename Existing Facility");
			arrayListColCaptions.Add("Rename Existing Process");
			arrayListColCaptions.Add("Rename Existing Component");

			arrayListColCaptions.Add("Facility Current Year");

			//mam 01222012
			arrayListColCaptions.Add("Facility Criticality");

			arrayListColCaptions.Add("Custom ENR Table");
			arrayListColCaptions.Add("Retired");
			arrayListColCaptions.Add("Level of Service");

			//mam 07072011
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				arrayListColCaptions.Add(((CriticalityForImport)arrayListCriticalities[i]).CriticalityName);
			}
			for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
			{
				//let's not put the unused criticalities into the arraylist; also, let's remove them from dataTableColNames
				//no - leave as is
				arrayListColCaptions.Add("Criticality " + i.ToString());
				//dataTableColNames.Columns.Remove("Crit" + i.ToString());
			}
			//</mam>

			//mam 07072011 - no longer using four fixed crits
			//arrayListColCaptions.Add("Criticality - Public");
			//arrayListColCaptions.Add("Criticality - Environment");
			//arrayListColCaptions.Add("Criticality - Repair");
			//arrayListColCaptions.Add("Criticality - Effect");

			arrayListColCaptions.Add("Vulnerability");
			arrayListColCaptions.Add("Comments");
			//arrayListColCaptions.Add("Discipline Type");
			arrayListColCaptions.Add("Acquisition Cost");
			arrayListColCaptions.Add("Current Value");
			arrayListColCaptions.Add("Rehabilitation Cost");

			//mam 01222012
			arrayListColCaptions.Add("Rehabilitation Cost Source/Description");

			//mam 07072011
			arrayListColCaptions.Add("Rehabilitation Cost Year");
			arrayListColCaptions.Add("Rehabilitation Interval");
			arrayListColCaptions.Add("Last Rehabilitation Year");
			//mam 01222012
			//arrayListColCaptions.Add("Time to Next Rehabilitation");

			//mam 01222012
			arrayListColCaptions.Add("Next Rehabilitation Year");

			arrayListColCaptions.Add("Repair Cost");
			arrayListColCaptions.Add("Replacement Value");

			//mam 01222012
			arrayListColCaptions.Add("Replacement Value Source/Description");

			arrayListColCaptions.Add("Replacement Value Year");

			//mam 07072011
			arrayListColCaptions.Add("Next Replacement Year");

			arrayListColCaptions.Add("Salvage Value");
			arrayListColCaptions.Add("Annual Maintenance Cost");
			arrayListColCaptions.Add("Installation Year");
			arrayListColCaptions.Add("Original Useful Life");
			arrayListColCaptions.Add("Condition");
			arrayListColCaptions.Add("Inspection Date");
			arrayListColCaptions.Add("Equipment ID Number");
			arrayListColCaptions.Add("Manufacturer");
			arrayListColCaptions.Add("Run Hours");
			arrayListColCaptions.Add("Running at Inspection");
			arrayListColCaptions.Add("Assessed By");
			//arrayListColCaptions.Add("Redundant Assets");
			arrayListColCaptions.Add("Number of Assets with Similar Functionality");

			//mam 07072011
			arrayListColCaptions.Add("Planning Mode");
			arrayListColCaptions.Add("Asset Class");

			arrayListColCaptions.Add("Component Info");

			//mam 03202012
			//arrayListColCaptions.Add("Photo File 1");
			//arrayListColCaptions.Add("Photo Caption 1");
			//arrayListColCaptions.Add("Photo File 2");
			//arrayListColCaptions.Add("Photo Caption 2");
			//arrayListColCaptions.Add("Photo File");
			//arrayListColCaptions.Add("Photo Caption");

			arrayListColCaptions.Add("Facility Photo File 1");
			arrayListColCaptions.Add("Facility Photo Caption 1");
			arrayListColCaptions.Add("Facility Photo File 2");
			arrayListColCaptions.Add("Facility Photo Caption 2");
			arrayListColCaptions.Add("Process Photo File");
			arrayListColCaptions.Add("Process Photo Caption");
			arrayListColCaptions.Add("Component Photo File");
			arrayListColCaptions.Add("Component Photo Caption");
			arrayListColCaptions.Add("Discipline Photo File");
			arrayListColCaptions.Add("Discipline Photo Caption");

			//arrayListColCaptions.Add("Discipline Mech Photo File");
			//arrayListColCaptions.Add("Discipline Mech Photo Caption");
			//arrayListColCaptions.Add("Discipline Struct Photo File");
			//arrayListColCaptions.Add("Discipline Struct Photo Caption");
			//arrayListColCaptions.Add("Discipline Civil Photo File");
			//arrayListColCaptions.Add("Discipline Civil Photo Caption");

			for (int i = 0; i < arrayListColCaptions.Count; i++)
			{
				dataTableColNames.Columns[i].Caption = arrayListColCaptions[i].ToString();
			}
		}

		private void LoadDiscCompInfoTable()
		{
			DataColumn newCol = new DataColumn();
			
			dataTableDiscCompInfo.Rows.Clear();
			dataTableDiscCompInfo.Columns.Clear();
			
			newCol = dataTableDiscCompInfo.Columns.Add("DiscCompInfo", typeof(string));
			newCol = dataTableDiscCompInfo.Columns.Add("DisplayText", typeof(string));

			//mech
			AddDiscCompInfoTableRow("MechExcessiveVibration", "Mech Excessive Vibration");
			AddDiscCompInfoTableRow("MechExcessiveNoise", "Mech Excessive Noise");
			AddDiscCompInfoTableRow("MechExcessiveCorrosion", "Mech Excessive Corrosion");
			AddDiscCompInfoTableRow("MechExcessiveLeaks", "Mech Excessive Leaks");
			AddDiscCompInfoTableRow("MechRunningHot", "Mech Running Hot");
			AddDiscCompInfoTableRow("MechCanRunWhenInspected", "Mech Can Run When Inspected");
			AddDiscCompInfoTableRow("MechSupportIsFunctional", "Mech Support Equipment Functional");
			AddDiscCompInfoTableRow("MechPartsMissing", "Mech Parts Missing");
			AddDiscCompInfoTableRow("MechPartsAvailable", "Mech Parts Available");
			AddDiscCompInfoTableRow("MechAdequate", "Mech Adequate");
			AddDiscCompInfoTableRow("MechMotorAmps", "Mech Motor Amps");
			AddDiscCompInfoTableRow("InstrIndicationFunctional", "Mech Instrument Indication Functional");
			AddDiscCompInfoTableRow("InstrAlarmFunctional", "Mech Instrument Alarms Functional");
			AddDiscCompInfoTableRow("InstrPartsMissing", "Mech Instrument Parts Missing");
			AddDiscCompInfoTableRow("InstrPartsAvailable", "Mech Instrument Parts Available");
			AddDiscCompInfoTableRow("ElecExcessiveCorrosion", "Mech Electrical Excessive Corrosion");
			AddDiscCompInfoTableRow("ElecCleanContacts", "Mech Electrical Clean Contacts");
			AddDiscCompInfoTableRow("ElecPartsAvailable", "Mech Electrical Parts Available");
			AddDiscCompInfoTableRow("PipeExcessiveCorrosion", "Mech Piping Excessive Corrosion");
			AddDiscCompInfoTableRow("PipeExcessiveLeaks", "Mech Piping Excessive Leaks");
			AddDiscCompInfoTableRow("PipePaintGood", "Mech Piping Paint Good");

			//struct
			AddDiscCompInfoTableRow("ConcreteSpalling", "Struct Concrete Spalling");
			AddDiscCompInfoTableRow("StructExcessiveCorrosion", "Struct Excessive Corrosion");
			AddDiscCompInfoTableRow("MembExcessiveCorrosion", "Struct Member Excessive Corrosion");
			AddDiscCompInfoTableRow("CorrosionCoating", "Struct Corrosion Coating");
			AddDiscCompInfoTableRow("PaintGood", "Struct Paint Good");
			AddDiscCompInfoTableRow("VisibleDeformities", "Struct Visible Deformities");
			AddDiscCompInfoTableRow("SettingEvident", "Struct Settling Evident");
			AddDiscCompInfoTableRow("MajorCracks", "Struct Major Cracks");

			//civil
			AddDiscCompInfoTableRow("SeveralPotholes", "Civil Several Potholes");
			AddDiscCompInfoTableRow("ExcessiveErosion", "Civil Excessive Erosion");
			AddDiscCompInfoTableRow("RoadDegradation", "Civil Road Degradation");
			AddDiscCompInfoTableRow("ExpansionSpace", "Civil Expansion Space");
			AddDiscCompInfoTableRow("FunctionCover", "Civil Functional Ground Cover");
			AddDiscCompInfoTableRow("FencingAdequate", "Civil Fencing Adequate");
			AddDiscCompInfoTableRow("FacilitiesSecure", "Civil Facilities Secure");
			AddDiscCompInfoTableRow("LandAppClayLiner", "Civil Clay Liner");
			AddDiscCompInfoTableRow("LandAppBermErosionInterior", "Civil Berm Erosion Interior");
			AddDiscCompInfoTableRow("LandAppBermErosionBermExterior", "Civil Berm Erosion Exterior");
			AddDiscCompInfoTableRow("LandAppBermVegetation", "Civil Berm Vegetation");
			AddDiscCompInfoTableRow("LandAppBermSettlement", "Civil Berm Settlement");
			AddDiscCompInfoTableRow("LandAppBermSeepage", "Civil Berm Seepage");
			AddDiscCompInfoTableRow("LandAppBurrowHoles", "Civil Burrow Holes");
			AddDiscCompInfoTableRow("LandAppErosionProtectionPresent", "Civil Erosion Protection Present");
			AddDiscCompInfoTableRow("LandAppErosionProtectionAdequate", "Civil Erosion Protection Adequate");
			AddDiscCompInfoTableRow("LandAppAlgalBlooms", "Civil Algal Blooms");
			AddDiscCompInfoTableRow("LandAppDrainageAdequate", "Civil Drainage Adequate");

			//add columns to Overview grid
			Column newGridCol;
			foreach (DataColumn dataColumn in dataTableColNames.Columns)
			{
				newGridCol = c1FlexGridOverview.Cols.Add();
				newGridCol.Name	= dataColumn.ColumnName;
				newGridCol.Caption = dataColumn.Caption;
			}

			//mam 07072011 - prepend "Criticality - " to each crit column caption in the Summary grid
			string newColCaption = "";
			for (int i = 1; i <= arrayListCriticalities.Count ; i++)
			{
				newColCaption = "Criticality - " + c1FlexGridOverview.Cols["Crit" + i.ToString()].Caption;
				c1FlexGridOverview.Cols["Crit" + i.ToString()].Caption = newColCaption;
			}
			//</mam>

			//mam 07072011 - increase the height of the fixed row
			//c1FlexGridOverview.Rows[0].HeightDisplay = (int)2.5 * c1FlexGridOverview.Rows[0].HeightDisplay;
			c1FlexGridOverview.Rows[0].HeightDisplay = (int)3.5 * c1FlexGridOverview.Rows[0].HeightDisplay;

			//mam 07072011 - increase the height of the discpline fixed row to accomodate Next Rehabilitation Year
			c1FlexGridDiscipline.Rows[0].HeightDisplay = 2 * c1FlexGridDiscipline.Rows[0].HeightDisplay;

			//add Disc Comp Info columns to Overview grid
			foreach (DataRow dataRow in dataTableDiscCompInfo.Rows)
			{
				newGridCol = c1FlexGridOverview.Cols.Add();
				newGridCol.Name	= dataRow[0].ToString();
				newGridCol.Caption = dataRow[1].ToString();
			}
		}

		private void AddDiscCompInfoTableRow(string dataValue1, string dataValue2)
		{
			DataRow dataRow = dataTableDiscCompInfo.NewRow();
			dataRow[0] = dataValue1;
			dataRow[1] = dataValue2;
			dataTableDiscCompInfo.Rows.Add(dataRow);
		}

		//mam 03202012 - this method is never called
		//private void LoadBlankSpreadsheet()
		//{
		//	//Column newCol = c1FlexGridSpreadsheetData.Cols.Add();
		//	Column newGridCol;
		//
		//	foreach (DataColumn dataColumn in dataTableColNames.Columns)
		//	{
		//		//c1FlexGridSpreadsheetData.Cols.Add();
		//		newGridCol = c1FlexGridSpreadsheetData.Cols.Add();
		//		newGridCol.Name	= dataColumn.ColumnName;
		//		newGridCol.Caption = dataColumn.Caption;
		//	}
		//
		//	for (int i = 0; i < 20; i++)
		//	{
		//		c1FlexGridSpreadsheetData.Rows.Add();
		//	}
		//
		//	c1FlexGridSpreadsheetData.Rows[0].HeightDisplay = 40;
		//	c1FlexGridSpreadsheetData[1, 1] = "Facility";
		//	c1FlexGridSpreadsheetData[2, 1] = "Process";
		//	c1FlexGridSpreadsheetData[3, 1] = "CompMSC";
		//	c1FlexGridSpreadsheetData[4, 1] = "CompPN";
		//	c1FlexGridSpreadsheetData[5, 1] = "Mech";
		//	c1FlexGridSpreadsheetData[6, 1] = "Struct";
		//	c1FlexGridSpreadsheetData[7, 1] = "Civil";
		//	c1FlexGridSpreadsheetData[8, 1] = "Pipe";
		//	c1FlexGridSpreadsheetData[9, 1] = "Node";
		//}

		private void InitializeVariables()
		{
			listDictColNamesDontExport.Add("DisciplineType", "DisciplineType");
		}

		private void InitializeControls()
		{
			//this.buttonValidate.Visible = false;
			AddDiscCompInfoButtonImage();

			//			//add user data to cols, to be used in the General Message display
			//			c1FlexGridFacility.Cols["CustomENRTable"].UserData = "Leave the Custom ENR Table grid cell blank and WAM will automatically use the default ENR values";
			//			c1FlexGridDiscipline.Cols["AcquisitionCost"].UserData = "Leave the Acquisition Cost grid cell blank and WAM will automatically calculate the value after the data is imported";
			//			c1FlexGridDiscipline.Cols["CurrentValue"].UserData = "Leave the Current Value grid cell blank and WAM will automatically calculate the value after the data is imported";
			//			c1FlexGridDiscipline.Cols["RepairCost"].UserData = "Leave the Repair Cost grid cell blank and WAM will automatically calculate the value after the data is imported";
			//			c1FlexGridComponent.Cols["Vulnerability"].UserData = "Leave the Vulnerability grid cell blank and WAM will automatically calculate the value after the data is imported";
			//			c1FlexGridDiscipline.Cols["DisciplineType"].UserData = "Changing the Discipline Type will reset the Original Useful Life to its default value";
			//			c1FlexGridDiscipline.Cols["OriginalUsefulLife"].UserData = "Original Useful Life default values:\r\n     Mechanical: 20 years\r\n     Structural: 50 years\r\n     Civil: 50 years\r\n";

			//mam 03202012 - these are for the new panel progress updater, but are now unnecessary as we are using the old progress updater form
			//this.Resize += new System.EventHandler(this.ImportFromTextFile_Resize);
			//this.panelProgressDisplay.Paint += new System.Windows.Forms.PaintEventHandler(this.panelProgressDisplay_Paint);
			//this.buttonCancelImport.Click += new System.EventHandler(this.buttonCancelImport_Click);

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);

			this.c1FlexGridFacility.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GridMouseMove);
			this.c1FlexGridProcess.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GridMouseMove);
			this.c1FlexGridComponent.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GridMouseMove);
			this.c1FlexGridComponentPN.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GridMouseMove);
			this.c1FlexGridDiscipline.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GridMouseMove);

			//add to each grid for handling copy and paste events
			gridEventsCopyPaste = new WAM.Common.GridEventsCopyPaste(this);
			this.c1FlexGridFacility.KeyDown += new KeyEventHandler(gridEventsCopyPaste.gridKeyUpCopyPasteHandler);
			this.c1FlexGridProcess.KeyDown += new KeyEventHandler(gridEventsCopyPaste.gridKeyUpCopyPasteHandler);
			this.c1FlexGridComponent.KeyDown += new KeyEventHandler(gridEventsCopyPaste.gridKeyUpCopyPasteHandler);
			this.c1FlexGridComponentPN.KeyDown += new KeyEventHandler(gridEventsCopyPaste.gridKeyUpCopyPasteHandler);
			this.c1FlexGridDiscipline.KeyDown += new KeyEventHandler(gridEventsCopyPaste.gridKeyUpCopyPasteHandler);

			//c1FlexGridFacility.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.MultiColumn;

			this.c1FlexGridFacility.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridBeforeSort);
			this.c1FlexGridProcess.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridBeforeSort);
			this.c1FlexGridComponent.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridBeforeSort);
			this.c1FlexGridComponentPN.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridBeforeSort);
			this.c1FlexGridDiscipline.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridBeforeSort);

			this.c1FlexGridSpreadsheetData.AfterSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridAfterSort);
			this.c1FlexGridSampleData.AfterSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.GridAfterSort);

			this.c1FlexGridFacility.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GridMouseDown);
			this.c1FlexGridProcess.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GridMouseDown);
			this.c1FlexGridComponent.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GridMouseDown);
			this.c1FlexGridComponentPN.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GridMouseDown);
			this.c1FlexGridDiscipline.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GridMouseDown);

			this.c1FlexGridFacility.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridProcess.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridComponent.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridComponentPN.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridDiscipline.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridSpreadsheetData.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			this.c1FlexGridSampleData.KeyDown += new System.Windows.Forms.KeyEventHandler(GridKeyDown);
			
			this.c1FlexGridFacility.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridProcess.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridComponent.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridComponentPN.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridDiscipline.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridSpreadsheetData.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);
			this.c1FlexGridSampleData.KeyUp += new System.Windows.Forms.KeyEventHandler(GridKeyUp);

			//this.c1FlexGridFacility.AutoClipboard = true;
			//this.c1FlexGridProcess.AutoClipboard = true;
			//this.c1FlexGridComponent.AutoClipboard = true;
			//this.c1FlexGridComponentPN.AutoClipboard = true;
			//this.c1FlexGridDiscipline.AutoClipboard = true;
			this.c1FlexGridSpreadsheetData.AutoClipboard = true;
			this.c1FlexGridSampleData.AutoClipboard = true;

			this.c1FlexGridFacility.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridProcess.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridComponent.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridComponentPN.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridDiscipline.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridSpreadsheetData.KeyActionEnter = KeyActionEnum.MoveDown;
			this.c1FlexGridSampleData.KeyActionEnter = KeyActionEnum.MoveDown;

			this.c1FlexGridFacility.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridProcess.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridComponent.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridComponentPN.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridDiscipline.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridSpreadsheetData.KeyActionEnter = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridSampleData.KeyActionEnter = KeyActionEnum.MoveAcrossOut;

			//mam 01222012 - hitting the tab key causes an unhandled error
			this.c1FlexGridFacility.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridProcess.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridComponent.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridComponentPN.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridDiscipline.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridSpreadsheetData.KeyActionTab = KeyActionEnum.MoveAcrossOut;
			this.c1FlexGridSampleData.KeyActionTab = KeyActionEnum.MoveAcrossOut;

			labelErrorTip.Text = errorTipMessage;
			labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			labelErrorTip.ForeColor = Color.Gray;

			this.linkLabelErrorFac.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkClicked);
			this.linkLabelErrorProc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkClicked);
			this.linkLabelErrorComp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkClicked);
			this.linkLabelErrorCompPN.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkClicked);
			this.linkLabelErrorDisc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkClicked);

			comboBoxSheet.Visible = false;
			labelSheet.Visible = false;
		}

		private void SetGridFixedRowCheckMarkImages()
		{
			System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			Stream toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.TabCheckMark.bmp");
			Image toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
			
			Bitmap b = (Bitmap)toolbarImage;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//pictureBoxToolbarSelectFile.Image = b;

			listColsNoCheckMark.Clear();
			listColsNoCheckMark.Add("Import", "Import");
			listColsNoCheckMark.Add("FacilityName", "FacilityName");
			listColsNoCheckMark.Add("ProcessName", "ProcessName");
			listColsNoCheckMark.Add("ComponentName", "ComponentName");
			listColsNoCheckMark.Add("DisciplineType", "DisciplineType");

			//mam 03202012
			listColsNoCheckMark.Add("RenameExistingFacility", "RenameExistingFacility");
			listColsNoCheckMark.Add("RenameExistingProcess", "RenameExistingProcess");
			listColsNoCheckMark.Add("RenameExistingComponent", "RenameExistingComponent");

			//mam 07072011
			listColsCheckMarkRow1.Add("Crit1", "Crit1");
			listColsCheckMarkRow1.Add("Crit2", "Crit2");
			listColsCheckMarkRow1.Add("Crit3", "Crit3");
			listColsCheckMarkRow1.Add("Crit4", "Crit4");
			listColsCheckMarkRow1.Add("Crit5", "Crit5");
			listColsCheckMarkRow1.Add("Crit6", "Crit6");

			//mam 07072011 - no longer using four fixed crits
			//listColsCheckMarkRow1.Add("CritPublic", "CritPublic");
			//listColsCheckMarkRow1.Add("CritEnvironment", "CritEnvironment");
			//listColsCheckMarkRow1.Add("CritRepair", "CritRepair");
			//listColsCheckMarkRow1.Add("CritEffect", "CritEffect");

			for (int i = c1FlexGridFacility.Cols.Fixed; i < c1FlexGridFacility.Cols.Count; i++)
			{
				if (listColsNoCheckMark.Contains(c1FlexGridFacility.Cols[i].Name.ToString()))
				{
					continue;
				}
				
				c1FlexGridFacility.Cols[i].ImageAlignFixed = ImageAlignEnum.RightTop;
				c1FlexGridFacility.SetCellImage(0, i, toolbarImage);
			}																					

			for (int i = c1FlexGridProcess.Cols.Fixed; i < c1FlexGridProcess.Cols.Count; i++)
			{
				if (listColsNoCheckMark.Contains(c1FlexGridProcess.Cols[i].Name.ToString()))
				{
					continue;
				}
				
				c1FlexGridProcess.Cols[i].ImageAlignFixed = ImageAlignEnum.RightTop;
				c1FlexGridProcess.SetCellImage(0, i, toolbarImage);
			}																					

			for (int i = c1FlexGridComponent.Cols.Fixed; i < c1FlexGridComponent.Cols.Count; i++)
			{
				if (listColsNoCheckMark.Contains(c1FlexGridComponent.Cols[i].Name.ToString()))
				{
					continue;
				}
				
				c1FlexGridComponent.Cols[i].ImageAlignFixed = ImageAlignEnum.RightTop;
				if (listColsCheckMarkRow1.Contains(c1FlexGridComponent.Cols[i].Name.ToString()))
				{
					//put the check mark in row 1 rather than row zero
					c1FlexGridComponent.SetCellImage(1, i, toolbarImage);
				}
				else
				{
					c1FlexGridComponent.SetCellImage(0, i, toolbarImage);
				}
			}																					

			for (int i = c1FlexGridComponentPN.Cols.Fixed; i < c1FlexGridComponentPN.Cols.Count; i++)
			{
				if (listColsNoCheckMark.Contains(c1FlexGridComponentPN.Cols[i].Name.ToString()))
				{
					continue;
				}
				
				c1FlexGridComponentPN.Cols[i].ImageAlignFixed = ImageAlignEnum.RightTop;
				if (listColsCheckMarkRow1.Contains(c1FlexGridComponentPN.Cols[i].Name.ToString()))
				{
					//put the check mark in row 1 rather than row zero
					c1FlexGridComponentPN.SetCellImage(1, i, toolbarImage);
				}
				else
				{
					c1FlexGridComponentPN.SetCellImage(0, i, toolbarImage);
				}
			}																					

			for (int i = c1FlexGridDiscipline.Cols.Fixed; i < c1FlexGridDiscipline.Cols.Count; i++)
			{
				if (listColsNoCheckMark.Contains(c1FlexGridDiscipline.Cols[i].Name.ToString()))
				{
					continue;
				}
				
				c1FlexGridDiscipline.Cols[i].ImageAlignFixed = ImageAlignEnum.RightTop;
				if (listColsCheckMarkRow1.Contains(c1FlexGridDiscipline.Cols[i].Name.ToString()))
				{
					//put the check mark in row 1 rather than row zero
					c1FlexGridDiscipline.SetCellImage(1, i, toolbarImage);
				}
				else
				{
					c1FlexGridDiscipline.SetCellImage(0, i, toolbarImage);
				}
			}
		}

		private void AddDiscCompInfoButtonImage()
		{
			int curColIndex = c1FlexGridDiscipline.Cols[GridColumnName.DiscComponentInfo.ToString()].Index;
			c1FlexGridDiscipline.Cols[curColIndex].ComboList = "...";
			return;

			//			System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			//			Stream toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.DiscCompInfo.bmp");
			//			Image toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
			//			int curColIndex = c1FlexGridDiscipline.Cols[GridColumnName.DiscComponentInfo.ToString()].Index;
			//			
			//			Bitmap b = (Bitmap)toolbarImage;
			//			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//
			//			c1FlexGridDiscipline.Cols[curColIndex].ImageAlign = ImageAlignEnum.CenterCenter;
			//
			//			for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
			//			{
			//				//add the button image to the Component Info column rows
			//				{
			//					c1FlexGridDiscipline.SetCellImage(i, curColIndex, toolbarImage);
			//				}
			//			}
		}

		private void ConfigureDataTable()
		{
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.ItemType.ToString(), typeof(string));
			//dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.ItemID.ToString(), typeof(Int32));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.TempID.ToString(), typeof(Int32));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.ItemName.ToString(), typeof(string));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.ParentName.ToString(), typeof(string));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.SelectedFacID.ToString(), typeof(Int32));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.SelectedProcID.ToString(), typeof(Int32));
			dataTableOriginalDataFromSpreadsheet.Columns.Add(DataTableFieldName.SelectedCompID.ToString(), typeof(Int32));
		}

		private void AssignCellStyles()
		{
			//*******************

			//error style properties

			cellStyleError = c1FlexGridComponent.Styles.Add("Error");
			cellStyleError.BackColor = Color.FromArgb(255, 100, 100);
			cellStyleError.ForeColor = Color.White;
			//cellStyleError.Font = new Font(Font, FontStyle.Italic);
			cellStyleError.Font = new Font(Font, (System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)));

			//*******************

			//valid style properties

			cellStyleValid = c1FlexGridComponent.Styles.Add("Valid");
			cellStyleValid.BackColor = Color.White;
			cellStyleValid.ForeColor = Color.Black;
			cellStyleValid.Font = new Font(Font, FontStyle.Regular);

			//*******************

			//blackout style properties

			cellStyleBlackout = c1FlexGridComponent.Styles.Add("Blackout");
			//cellStyleBlackout.BackColor = Color.Gray;
			//cellStyleBlackout.ForeColor = Color.Gray;
			cellStyleBlackout.BackColor = Color.LightGray;
			cellStyleBlackout.ForeColor = Color.Gray;
			cellStyleBlackout.Font = new Font(Font, FontStyle.Regular);

			//*******************

			//"don't import" style properties

			cellStyleDontImport = c1FlexGridComponent.Styles.Add("DontImport");
			cellStyleDontImport.BackColor = SystemColors.ControlLight;
			cellStyleDontImport.ForeColor = SystemColors.ControlDarkDark;
			//cellStyleDontImport.Font = new Font(Font, FontStyle.Regular);

			//*******************

			//"default value" style properties

			//mam 07072011
			cellStyleDefaultValue = c1FlexGridComponent.Styles.Add("DefaultValue");
			cellStyleDefaultValue.BackColor = Color.FromArgb(255, 255, 128);
			cellStyleDefaultValue.ForeColor = SystemColors.ControlDarkDark;
			cellStyleDefaultValue.Font = new Font(Font, (System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)));

			cellStyleDontImportDefaultValue = c1FlexGridComponent.Styles.Add("DontImportDefaultValue");
			cellStyleDontImportDefaultValue.BackColor = SystemColors.ControlLight;
			cellStyleDontImportDefaultValue.ForeColor = SystemColors.ControlDarkDark;
			//cellStyleDontImportDefaultValue.Font = new Font(Font, (System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)));

			//*******************

			//checkbox style properties

			//mam 03202012
			cellStyleCheckBox = c1FlexGridComponent.Styles.Add("CheckBoxHide");
			cellStyleDefaultValue.BackColor = SystemColors.Window;
			//cellStyleCheckBox.BackColor = Color.Violet;
			//cellStyleCheckBox.ForeColor = Color.Violet;
			//cellStyleDefaultValue.Font = new Font(Font, (System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)));

			//*******************

			//add styles to other grids

			cellStyleErrorFac = c1FlexGridFacility.Styles.Add("Error");
			cellStyleErrorFac.MergeWith(cellStyleError);
			cellStyleValidFac = c1FlexGridFacility.Styles.Add("Valid");
			cellStyleValidFac.MergeWith(cellStyleValid);
			cellStyleBlackoutFac = c1FlexGridFacility.Styles.Add("Blackout");
			cellStyleBlackoutFac.MergeWith(cellStyleBlackout);
			cellStyleDontImportFac = c1FlexGridFacility.Styles.Add("DontImport");
			cellStyleDontImportFac.MergeWith(cellStyleDontImport);

			//mam 07072011
			cellStyleDefaultValueFac = c1FlexGridFacility.Styles.Add("DefaultValue");
			cellStyleDefaultValueFac.MergeWith(cellStyleDefaultValue);
			cellStyleDontImportDefaultValueFac = c1FlexGridFacility.Styles.Add("DontImportDefaultValue");
			cellStyleDontImportDefaultValueFac.MergeWith(cellStyleDontImportDefaultValue);

			//mam 03202012
			cellStyleCheckBoxFac = c1FlexGridFacility.Styles.Add("CheckBoxHide");
			cellStyleCheckBoxFac.MergeWith(cellStyleCheckBox);

			cellStyleErrorProc = c1FlexGridProcess.Styles.Add("Error");
			cellStyleErrorProc.MergeWith(cellStyleError);
			cellStyleValidProc = c1FlexGridProcess.Styles.Add("Valid");
			cellStyleValidProc.MergeWith(cellStyleValid);
			cellStyleBlackoutProc = c1FlexGridProcess.Styles.Add("Blackout");
			cellStyleBlackoutProc.MergeWith(cellStyleBlackout);
			cellStyleDontImportProc = c1FlexGridProcess.Styles.Add("DontImport");
			cellStyleDontImportProc.MergeWith(cellStyleDontImport);

			//mam 07072011
			cellStyleDefaultValueProc = c1FlexGridProcess.Styles.Add("DefaultValue");
			cellStyleDefaultValueProc.MergeWith(cellStyleDefaultValue);
			cellStyleDontImportDefaultValueProc = c1FlexGridProcess.Styles.Add("DontImportDefaultValue");
			cellStyleDontImportDefaultValueProc.MergeWith(cellStyleDontImportDefaultValue);

			//mam 03202012
			cellStyleCheckBoxProc = c1FlexGridProcess.Styles.Add("CheckBoxHide");
			cellStyleCheckBoxProc.MergeWith(cellStyleCheckBox);

			cellStyleErrorCompPN = c1FlexGridComponentPN.Styles.Add("Error");
			cellStyleErrorCompPN.MergeWith(cellStyleError);
			cellStyleValidCompPN = c1FlexGridComponentPN.Styles.Add("Valid");
			cellStyleValidCompPN.MergeWith(cellStyleValid);
			cellStyleBlackoutCompPN = c1FlexGridComponentPN.Styles.Add("Blackout");
			cellStyleBlackoutCompPN.MergeWith(cellStyleBlackout);
			cellStyleDontImportCompPN = c1FlexGridComponentPN.Styles.Add("DontImport");
			cellStyleDontImportCompPN.MergeWith(cellStyleDontImport);

			//mam 07072011
			cellStyleDefaultValueCompPN = c1FlexGridComponentPN.Styles.Add("DefaultValue");
			cellStyleDefaultValueCompPN.MergeWith(cellStyleDefaultValue);
			cellStyleDontImportDefaultValueCompPN = c1FlexGridComponentPN.Styles.Add("DontImportDefaultValue");
			cellStyleDontImportDefaultValueCompPN.MergeWith(cellStyleDontImportDefaultValue);

			//mam 03202012
			cellStyleCheckBoxCompPn = c1FlexGridComponentPN.Styles.Add("CheckBoxHide");
			cellStyleCheckBoxCompPn.MergeWith(cellStyleCheckBox);

			cellStyleErrorDisc = c1FlexGridDiscipline.Styles.Add("Error");
			cellStyleErrorDisc.MergeWith(cellStyleError);
			cellStyleValidDisc = c1FlexGridDiscipline.Styles.Add("Valid");
			cellStyleValidDisc.MergeWith(cellStyleValid);
			cellStyleBlackoutDisc = c1FlexGridDiscipline.Styles.Add("Blackout");
			cellStyleBlackoutDisc.MergeWith(cellStyleBlackout);
			cellStyleDontImportDisc = c1FlexGridDiscipline.Styles.Add("DontImport");
			cellStyleDontImportDisc.MergeWith(cellStyleDontImport);

			//mam 07072011
			cellStyleDefaultValueDisc = c1FlexGridDiscipline.Styles.Add("DefaultValue");
			cellStyleDefaultValueDisc.MergeWith(cellStyleDefaultValue);
			cellStyleDontImportDefaultValueDisc = c1FlexGridDiscipline.Styles.Add("DontImportDefaultValue");
			cellStyleDontImportDefaultValueDisc.MergeWith(cellStyleDontImportDefaultValue);

			//*******************
		}

		private void ConfigureGrid()
		{
			c1FlexGridFacility.Rows[0].HeightDisplay = (int)(c1FlexGridFacility.Rows[0].HeightDisplay * 1.5);
			c1FlexGridProcess.Rows[0].HeightDisplay = (int)(c1FlexGridProcess.Rows[0].HeightDisplay * 1.5);
			c1FlexGridComponent.Rows[0].HeightDisplay = (int)(c1FlexGridFacility.Rows[0].HeightDisplay * 1.5);
			c1FlexGridDiscipline.Rows[0].HeightDisplay = (int)(c1FlexGridDiscipline.Rows[0].HeightDisplay * 1.5);

			//****************

			//facility

			c1FlexGridFacility.Cols["TempID"].Visible = false;

			//****************

			//process

			c1FlexGridProcess.Cols["TempID"].Visible = false;

			//****************

			//component

			c1FlexGridComponent.AllowMerging = AllowMergingEnum.FixedOnly;
			c1FlexGridComponent.Rows[0].AllowMerging = true;
			c1FlexGridComponent.Rows[1].AllowMerging = true;

			c1FlexGridComponentPN.AllowMerging = AllowMergingEnum.FixedOnly;
			c1FlexGridComponentPN.Rows[0].AllowMerging = true;
			c1FlexGridComponentPN.Rows[1].AllowMerging = true;

			for (int i = 0; i < c1FlexGridComponent.Cols.Count; i++)
			{
				c1FlexGridComponent.Cols[i].AllowMerging = true;
				c1FlexGridComponent[1, i] = c1FlexGridComponent[0, i];
			}

			for (int i = 0; i < c1FlexGridComponentPN.Cols.Count; i++)
			{
				c1FlexGridComponentPN.Cols[i].AllowMerging = true;
				c1FlexGridComponentPN[1, i] = c1FlexGridComponentPN[0, i];
			}

			c1FlexGridComponent[0, 0] = c1FlexGridComponent[1, 0] = " ";
			c1FlexGridComponentPN[0, 0] = c1FlexGridComponentPN[1, 0] = " ";

			//mam 07072011
			c1FlexGridComponent.Cols["CipPlanningMode"].Width = 125;

			//mam 07072011
			//for (int i = c1FlexGridComponent.Cols["Crit1"].Index; i <= c1FlexGridComponent.Cols["Crit6"].Index; i++)
			//{
			//	c1FlexGridComponent[0, i] = "Criticality " + i.ToString();
			//	c1FlexGridComponent.Cols[i].WidthDisplay = 100;
			//}

			//mam 07072011 - set the height of the Criticality header row that that spans the Criticality columns
			c1FlexGridComponent.Rows[0].HeightDisplay = 20;

			//mam 07072011 - set the height of the row that contains the headers
			c1FlexGridComponent.Rows[1].HeightDisplay = 40;

			//mam 07072011
			for (int i = c1FlexGridComponent.Cols["Crit1"].Index; i <= c1FlexGridComponent.Cols["Crit6"].Index; i++)
			{	  
				c1FlexGridComponent[0, i] = "Criticality";
				c1FlexGridComponent.Cols[i].WidthDisplay = 100;
			}
			c1FlexGridComponent[1, "Crit1"] = "Criticality 1";
			c1FlexGridComponent[1, "Crit2"] = "Criticality 2";
			c1FlexGridComponent[1, "Crit3"] = "Criticality 3";
			c1FlexGridComponent[1, "Crit4"] = "Criticality 4";
			c1FlexGridComponent[1, "Crit5"] = "Criticality 5";
			c1FlexGridComponent[1, "Crit6"] = "Criticality 6";
			//</mam>

			//mam 07072011 - no longer using four fixed crits
			//for (int i = c1FlexGridComponent.Cols["CritPublic"].Index; i <= c1FlexGridComponent.Cols["CritEffect"].Index; i++)
			//{	  
			//	c1FlexGridComponent[0, i] = "Criticality";
			//	c1FlexGridComponent.Cols[i].WidthDisplay = 100;
			//}
			//c1FlexGridComponent[1, "CritPublic"] = "Public Health";
			//c1FlexGridComponent[1, "CritEnvironment"] = "Environmental";
			//c1FlexGridComponent[1, "CritRepair"] = "Cost of Repair";
			//c1FlexGridComponent[1, "CritEffect"] = "Effect on Customers";

			c1FlexGridComponent.Cols["TempID"].Visible = false;
			c1FlexGridComponent.Cols["ComponentType"].Visible = false;

			c1FlexGridComponentPN.Cols["TempID"].Visible = false;
			c1FlexGridComponentPN.Cols["ComponentType"].Visible = false;

			c1FlexGridComponent.Cols["RedundantAssets"].TextAlign = TextAlignEnum.RightCenter;

			//****************

			//discipline

			//AcquisitionCost
			//CurrentValue
			//RehabCost
			//RepairCost
			//ReplacementValue
			//ReplacementValueYear
			//SalvageValue
			//AnnualMaintCost
			//InstallationYear
			//OriginalUsefulLife
			////LOS
			//Condition
			////Redundant
			////CritPublic
			////CritEnvironment
			////CritRepair
			////CritEffect
			//InspectionDate
			//EquipmentIDNumber
			//Manufacturer
			//RunHours
			//RunningAtInspection
			//AssessedBy

			c1FlexGridDiscipline.AllowMerging = AllowMergingEnum.FixedOnly;
			//c1FlexGridDiscipline.Rows[0].AllowMerging = true;
			//c1FlexGridDiscipline.Rows[1].AllowMerging = true;

			int colNumber = c1FlexGridDiscipline.Cols.Count - 1;
			int colNumberStart = colNumber;

			c1FlexGridDiscipline.Cols.Insert(colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);

			//mam 07072011 - for new rehab cols (RehabInterval, RehabYearLast, RehabNext)
			//mam 01222012 - RehabInterval, RehabYearLast, RehabYearNext
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);

			//mam 01222012 - for new cols (ReplacementValueDesc and RehabCostDesc)
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);

			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);
			//c1FlexGridDiscipline.Cols.Insert(++colNumber);

			colNumber = colNumberStart;
			c1FlexGridDiscipline.Cols[colNumber].Name = "AcquisitionCost";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "CurrentValue";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabCost";

			//mam 01222012
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabCostDesc";

			//mam 07072011
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabCostYear";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabInterval";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabYearLast";
			//mam 01222012
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabNext";

			//mam 01222012
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RehabYearNext";

			c1FlexGridDiscipline.Cols[++colNumber].Name = "RepairCost";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "ReplacementValue";

			//mam 01222012
			c1FlexGridDiscipline.Cols[++colNumber].Name = "ReplacementValueDesc";

			c1FlexGridDiscipline.Cols[++colNumber].Name = "ReplacementValueYear";

			//mam 07072011
			c1FlexGridDiscipline.Cols[++colNumber].Name = "NextReplacementYear";

			c1FlexGridDiscipline.Cols[++colNumber].Name = "SalvageValue";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "AnnualMaintCost";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "InstallationYear";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "OriginalUsefulLife";
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "LOS";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "Condition";

			//c1FlexGridDiscipline.Cols[++colNumber].Name = "RedundantAssets";
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "CritPublic";
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "CritEnvironment";
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "CritRepair";
			//c1FlexGridDiscipline.Cols[++colNumber].Name = "CritEffect";

			c1FlexGridDiscipline.Cols[++colNumber].Name = "InspectionDate";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "EquipmentIDNumber";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "Manufacturer";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RunHours";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "RunningAtInspection";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "AssessedBy";
			c1FlexGridDiscipline.Cols[++colNumber].Name = "DiscComponentInfo";

			//			for (int i = 0; i < c1FlexGridDiscipline.Cols.Count; i++)
			//			{
			//				c1FlexGridDiscipline.Cols[i].AllowMerging = true;
			//				c1FlexGridDiscipline[1, i] = c1FlexGridDiscipline[0, i];
			//			}

			//set column text alignment
			c1FlexGridDiscipline.Cols["AcquisitionCost"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["CurrentValue"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["RehabCost"].TextAlign = TextAlignEnum.RightCenter;

			//mam 01222012
			c1FlexGridDiscipline.Cols["RehabCostDesc"].TextAlign = TextAlignEnum.LeftCenter;

			//mam 07072011
			c1FlexGridDiscipline.Cols["RehabCostYear"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["RehabInterval"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["RehabYearLast"].TextAlign = TextAlignEnum.RightCenter;
			//mam 01222012
			//c1FlexGridDiscipline.Cols["RehabNext"].TextAlign = TextAlignEnum.RightCenter;

			//mam 01222012
			c1FlexGridDiscipline.Cols["RehabYearNext"].TextAlign = TextAlignEnum.RightCenter;

			c1FlexGridDiscipline.Cols["RepairCost"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["ReplacementValue"].TextAlign = TextAlignEnum.RightCenter;

			//mam 01222012
			c1FlexGridDiscipline.Cols["ReplacementValueDesc"].TextAlign = TextAlignEnum.LeftCenter;

			c1FlexGridDiscipline.Cols["ReplacementValueYear"].TextAlign = TextAlignEnum.RightCenter;

			//mam 07072011
			c1FlexGridDiscipline.Cols["NextReplacementYear"].TextAlign = TextAlignEnum.RightCenter;

			c1FlexGridDiscipline.Cols["SalvageValue"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["AnnualMaintCost"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["InstallationYear"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["OriginalUsefulLife"].TextAlign = TextAlignEnum.RightCenter;
			//c1FlexGridDiscipline.Cols["LOS"].TextAlign = TextAlignEnum.LeftCenter;
			//c1FlexGridDiscipline.Cols["Condition"].TextAlign = TextAlignEnum.LeftCenter;

			//c1FlexGridDiscipline.Cols["RedundantAssets"].TextAlign = TextAlignEnum.RightCenter;
			//c1FlexGridDiscipline.Cols["CritPublic"].TextAlign = TextAlignEnum.LeftCenter;
			//c1FlexGridDiscipline.Cols["CritEnvironment"].TextAlign = TextAlignEnum.LeftCenter;
			//c1FlexGridDiscipline.Cols["CritRepair"].TextAlign = TextAlignEnum.LeftCenter;
			//c1FlexGridDiscipline.Cols["CritEffect"].TextAlign = TextAlignEnum.LeftCenter;

			c1FlexGridDiscipline.Cols["InspectionDate"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["EquipmentIDNumber"].TextAlign = TextAlignEnum.LeftCenter;
			c1FlexGridDiscipline.Cols["Manufacturer"].TextAlign = TextAlignEnum.LeftCenter;
			c1FlexGridDiscipline.Cols["RunHours"].TextAlign = TextAlignEnum.RightCenter;
			c1FlexGridDiscipline.Cols["RunningAtInspection"].TextAlign = TextAlignEnum.CenterCenter;
			c1FlexGridDiscipline.Cols["AssessedBy"].TextAlign = TextAlignEnum.LeftCenter;
			c1FlexGridDiscipline.Cols["DiscComponentInfo"].TextAlign = TextAlignEnum.LeftCenter;

			//***************

			//			//set the data type
			//			c1FlexGridDiscipline.Cols["AcquisitionCost"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["CurrentValue"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["RehabCost"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["RepairCost"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["ReplacementValue"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["ReplacementValueYear"].DataType = typeof(Int32);
			//			c1FlexGridDiscipline.Cols["SalvageValue"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["AnnualMaintCost"].DataType = typeof(Decimal);
			//			c1FlexGridDiscipline.Cols["InstallationYear"].DataType = typeof(Int32);
			//			c1FlexGridDiscipline.Cols["OriginalUsefulLife"].DataType = typeof(Int32);
			//			//c1FlexGridDiscipline.Cols["LOS"].DataType = typeof(Int32);
			//			//c1FlexGridDiscipline.Cols["Condition"].DataType = typeof(Int32);
			//			c1FlexGridDiscipline.Cols["InspectionDate"].DataType = typeof(DateTime);
			//			c1FlexGridDiscipline.Cols["EquipmentIDNumber"].DataType = typeof(String);
			//			c1FlexGridDiscipline.Cols["Manufacturer"].DataType = typeof(String);
			//			c1FlexGridDiscipline.Cols["RunHours"].DataType = typeof(Int32);
			//			c1FlexGridDiscipline.Cols["RunningAtInspection"].DataType = typeof(Boolean);
			//			c1FlexGridDiscipline.Cols["AssessedBy"].DataType = typeof(String);
			//			c1FlexGridDiscipline.Cols["DiscComponentInfo"].DataType = typeof(String);

			//***************

			c1FlexGridDiscipline.Cols["AcquisitionCost"].Caption = "Acquisition Cost";
			c1FlexGridDiscipline.Cols["CurrentValue"].Caption = "Current Value";
			c1FlexGridDiscipline.Cols["RehabCost"].Caption = "Rehabilitation Cost";

			//mam 01222012
			c1FlexGridDiscipline.Cols["RehabCostDesc"].Caption = "Rehabilitation Cost Source/Description";

			//mam 07072011
			c1FlexGridDiscipline.Cols["RehabCostYear"].Caption = "Rehabilitation Cost Year";
			c1FlexGridDiscipline.Cols["RehabInterval"].Caption = "Rehabilitation Interval";
			c1FlexGridDiscipline.Cols["RehabYearLast"].Caption = "Last Rehabilitation Year";
			//mam 01222012
			//c1FlexGridDiscipline.Cols["RehabNext"].Caption = "Time to Next Rehabilitation";

			//mam 01222012
			c1FlexGridDiscipline.Cols["RehabYearNext"].Caption = "Next Rehabilitation Year";

			c1FlexGridDiscipline.Cols["RepairCost"].Caption = "Repair Cost";
			c1FlexGridDiscipline.Cols["ReplacementValue"].Caption = "Replacement Value";

			//mam 01222012
			c1FlexGridDiscipline.Cols["ReplacementValueDesc"].Caption = "Replacement Value Source/Description";

			c1FlexGridDiscipline.Cols["ReplacementValueYear"].Caption = "Replacement Value Year";

			//mam 07072011
			c1FlexGridDiscipline.Cols["NextReplacementYear"].Caption = "Next Replacement Year";

			c1FlexGridDiscipline.Cols["SalvageValue"].Caption = "Salvage Value";
			c1FlexGridDiscipline.Cols["AnnualMaintCost"].Caption = "Annual Maintenance Cost";
			c1FlexGridDiscipline.Cols["InstallationYear"].Caption = "Installation Year";
			c1FlexGridDiscipline.Cols["OriginalUsefulLife"].Caption = "Original Useful Life";
			//c1FlexGridDiscipline.Cols["LOS"].Caption = "Level of Service";
			c1FlexGridDiscipline.Cols["Condition"].Caption = "Condition";

			//			c1FlexGridDiscipline.Cols["RedundantAssets"].Caption = "Redundant Asset Count";
			//			for (int i = c1FlexGridDiscipline.Cols["CritPublic"].Index; i <= c1FlexGridDiscipline.Cols["CritEffect"].Index; i++)
			//			{	  
			//				c1FlexGridDiscipline[0, i] = "Criticality";
			//				c1FlexGridDiscipline.Cols[i].WidthDisplay = 100;
			//			}
			//			c1FlexGridDiscipline[1, "CritPublic"] = "Public Health";
			//			c1FlexGridDiscipline[1, "CritEnvironment"] = "Environmental";
			//			c1FlexGridDiscipline[1, "CritRepair"] = "Cost of Repair";
			//			c1FlexGridDiscipline[1, "CritEffect"] = "Effect on Customers";

			c1FlexGridDiscipline.Cols["InspectionDate"].Caption = "Inspection Date";
			c1FlexGridDiscipline.Cols["EquipmentIDNumber"].Caption = "Equipment/ID Number";
			c1FlexGridDiscipline.Cols["Manufacturer"].Caption = "Manufacturer";
			c1FlexGridDiscipline.Cols["RunHours"].Caption = "Run Hours";
			c1FlexGridDiscipline.Cols["RunningAtInspection"].Caption = "Running at Inspection";
			c1FlexGridDiscipline.Cols["AssessedBy"].Caption = "Assessed By";
			c1FlexGridDiscipline.Cols["DiscComponentInfo"].Caption = "Component Info";

			//for (int i = 0; i < c1FlexGridDiscipline.Cols.Count; i++)
			//{
			//	c1FlexGridDiscipline.Cols[i].AllowMerging = true;
			//	c1FlexGridDiscipline[1, i] = c1FlexGridDiscipline[0, i];
			//}
			//for (int i = c1FlexGridDiscipline.Cols["CritPublic"].Index; i <= c1FlexGridDiscipline.Cols["CritEffect"].Index; i++)
			//{	  
			//	c1FlexGridDiscipline[0, i] = "Criticality";
			//	c1FlexGridDiscipline.Cols[i].WidthDisplay = 100;
			//}
			//c1FlexGridDiscipline[1, "CritPublic"] = "Public Health";
			//c1FlexGridDiscipline[1, "CritEnvironment"] = "Environmental";
			//c1FlexGridDiscipline[1, "CritRepair"] = "Cost of Repair";
			//c1FlexGridDiscipline[1, "CritEffect"] = "Effect on Customers";

			c1FlexGridDiscipline.Cols["RunningAtInspection"].DataType = typeof(Boolean);

			c1FlexGridDiscipline.Cols["AnnualMaintCost"].WidthDisplay = 100;

			//mam 01222012
			c1FlexGridDiscipline.Cols["RehabCostDesc"].Width = 125;
			c1FlexGridDiscipline.Cols["ReplacementValueDesc"].Width = 125;

			c1FlexGridDiscipline.Cols["TempID"].Visible = false;
			c1FlexGridDiscipline.Cols["LoadedFacilityName"].Visible = false;
			c1FlexGridDiscipline.Cols["LoadedProcessName"].Visible = false;
			c1FlexGridDiscipline.Cols["LoadedComponentName"].Visible = false;
		}

		private void SetBitmaps()
		{
			//load toolbar pictureboxes with bitmaps
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			//			System.Reflection.Assembly thisExe;
			//			thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			//System.IO.Stream file = null;
			//Image image = null;

			//file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			//image = (Bitmap)Bitmap.FromStream(file);
			//this.pictureBoxToolbarAdd.Image = image;
			//commonTasks.SetBitmap(pictureBoxToolbarAdd);

			//***************************

			System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = null;
			Image image = null;

			//toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			//toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
			//this.pictureBoxToolbarAdd.Image = toolbarImage;

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.SpreadsheetIn.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarSelectFile.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarSelectFile);

			this.pictureBoxSelectFileSpreadsheet.Image = image;
			commonTasks.SetBitmap(pictureBoxSelectFileSpreadsheet);

			this.pictureBoxInstructionSelectFile.Image = image;
			commonTasks.SetBitmap(pictureBoxInstructionSelectFile);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.ToolbarLoadSampleData.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxLoadSampleData.Image = image;
			commonTasks.SetBitmap(pictureBoxLoadSampleData);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.LoadGrid.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarPopulateTabs.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarPopulateTabs);

			this.pictureBoxPopulateTabsSpreadsheet.Image = image;
			commonTasks.SetBitmap(pictureBoxPopulateTabsSpreadsheet);

			this.pictureBoxPopulateTabsSample.Image = image;
			commonTasks.SetBitmap(pictureBoxPopulateTabsSample);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.SpreadsheetOut.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarExport.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarExport);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.ToolbarClearAllOff.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarClearAll.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarClearAll);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarAddGridRow.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarAddGridRow);

			this.pictureBoxInstructionAddGridRow.Image = image;
			commonTasks.SetBitmap(pictureBoxInstructionAddGridRow);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOff8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarDeleteGridRow.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarDeleteGridRow);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.ToolbarCheckMarkOff.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarCheckAll.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarCheckAll);

			//***************

			//			Bitmap b = (Bitmap)pictureBoxToolbarPopulateTabs.Image;
			//			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//			pictureBoxToolbarPopulateTabs.Image = b;
			//
			//			b = (Bitmap)pictureBoxToolbarExport.Image;
			//			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//			pictureBoxToolbarExport.Image = b;
			//
			//			b = (Bitmap)pictureBoxToolbarCheckAll.Image;
			//			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//			pictureBoxToolbarCheckAll.Image = b;
			//
			Bitmap b = (Bitmap)pictureBoxToolbarHelp.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarHelp.Image = b;

			commonTasks = null;
			//file = null;
			//image = null;
		}

		private void SetToolTips()
		{
			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.pictureBoxToolbarSelectFile, "Load an Excel spreadsheet");
			toolTip.SetToolTip(this.pictureBoxSelectFileSpreadsheet, "Load an Excel spreadsheet");
			toolTip.SetToolTip(this.pictureBoxToolbarPopulateTabs, "Populate the grids with data from the Spreadsheet grid");
			toolTip.SetToolTip(this.pictureBoxPopulateTabsSpreadsheet, "Populate the grids with data from this Spreadsheet grid");
			toolTip.SetToolTip(this.pictureBoxLoadSampleData, "Reload the original sample data");
			toolTip.SetToolTip(this.pictureBoxPopulateTabsSample, "Populate the grids with data from this Sample Data grid");
			//toolTip.SetToolTip(this.pictureBoxToolbarLoadSampleData, "Load sample data");
			//toolTip.SetToolTip(this.pictureBoxToolbarPopulateTabsWithSampleData, "Populate the grids with data from this Sample Data grid");

			toolTip.SetToolTip(this.pictureBoxToolbarAddGridRow, "Add a row to the grid");
			toolTip.SetToolTip(this.pictureBoxToolbarDeleteGridRow, "Delete the selected grid row(s)");
			toolTip.SetToolTip(this.pictureBoxToolbarCheckAll, "Check/uncheck all Import check boxes in the current grid");

			toolTip.SetToolTip(this.pictureBoxToolbarExport, "Export data");
			//toolTip.SetToolTip(this.pictureBoxToolbarSample, "Create a sample import file");
			toolTip.SetToolTip(this.pictureBoxToolbarClearAll, "Delete all data from all grids");

			toolTip.SetToolTip(this.pictureBoxToolbarHelp, "Help");
		}
		//</mam>

		//mam

		#endregion /***** Load Tasks *****/

		#region /***** Get Spreadsheet Data and Populate Grids *****/

		private string SelectFileToImport()
		{
			try
			{
				//OpenFileDialog	fileDlg = new OpenFileDialog();
				//
				//fileDlg.Filter = "Tab Delimited Text Files (*.txt)|*.txt";
				//fileDlg.CheckFileExists = true;
				//
				//if (textBoxSource.Text.Length > 0)
				//	fileDlg.FileName = textBoxSource.Text;
				//
				//if (fileDlg.ShowDialog(this) == DialogResult.OK)
				//	textBoxSource.Text = fileDlg.FileName;

				string fileName = "";
				//string fileExtension = "";

				//open the openfile dialog
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.InitialDirectory = Application.StartupPath;

				//mam 03202012 - include .xlsx
				//mam 03202012 - can't include .xlsx because the Component One Excel component only recognizes .xls files
				openFileDialog.Filter = "Excel (*.xls)|*.xls|Comma-Delimited (*.csv)|*.csv|Text (*.txt)|*.txt";
				//openFileDialog.Filter = "Excel (*.xls)|*.xls|Excel (*.xlsx)|*.xlsx|Comma-Delimited (*.csv)|*.csv|Text (*.txt)|*.txt";

				openFileDialog.Title = "Select a File to Import";
				openFileDialog.ValidateNames = true;
				//openFileDialog.OverwritePrompt = true;
				openFileDialog.CheckPathExists = true;
				openFileDialog.CheckFileExists = true;
				openFileDialog.ShowHelp = true;
				openFileDialog.AddExtension = true;
				//openFileDialog.CreatePrompt = true;
				//openFileDialog.DefaultExt = true;
				openFileDialog.ShowDialog();
				
				if(openFileDialog.FileName == "")
				{
					//no file selected
					return string.Empty;
				}
				else
				{
					fileName = openFileDialog.FileName.ToString();
					switch (openFileDialog.FilterIndex)
					{
						case 1:
							//xls
							//fileExtension = ".xls";
							//if (!fileName.EndsWith(".xls"))
							//	fileName += ".xls";
							break;

						//mam 03202012 - new case for .xlsx
						//mam 03202012 - can't include .xlsx because the Component One Excel component only recognizes .xls files
						//case 2:
						//	//xlsx
						//	//fileExtension = ".xlsx";
						//	//if (!fileName.EndsWith(".xlsx"))
						//	//	fileName += ".xlsx";
						//	break;

						case 2:
							//csv
							//fileExtension = ".csv";
							//if (!fileName.EndsWith(".csv"))
							//	fileName += ".csv";
							break;
						case 3:
							//txt
							//fileExtension = ".txt";
							//if (!fileName.EndsWith(".txt"))
							//	fileName += ".txt";
							break;
						default:
							break;
					}
				}

				return fileName;
			}
			catch
			{
				return string.Empty;
			}
		}

		private int DetermineColumnIndices(bool loadSampleData)
		{
			try
			{
				C1FlexGrid grid = c1FlexGridSpreadsheetData;
				int totalColIndices = 0;
				if (loadSampleData)
				{
					grid = c1FlexGridSampleData;
				}

				if (grid.Rows.Count <= 1)
				{
					return colIndicesCount;
				}

				colIndexType = -1;
				//colIndexName = -1;
				//	colIndexParent = -1;
				colIndexCustomENR = -1;
				colIndexFacilityCurrentYear = -1;

				//mam 01222012
				colIndexFacilityCriticality = -1;

				colIndexFac = -1;
				colIndexProc = -1;
				colIndexComp = -1;
				colIndexComments = -1;
				colIndexRetired = -1;
				colIndexLOS = -1;
				colIndexRedundant = -1;

				//mam 07072011
				colIndexCipPlanningMode = -1;
				colIndexAssetClass = -1;

				//mam 07072011
				colIndexCrit1 = -1;
				colIndexCrit2 = -1;
				colIndexCrit3 = -1;
				colIndexCrit4 = -1;
				colIndexCrit5 = -1;
				colIndexCrit6 = -1;

				//mam 07072011 - no longer using four fixed crits
				//colIndexCritPublic = -1;
				//colIndexCritEnvironment = -1;
				//colIndexCritRepair = -1;
				//colIndexCritEffect = -1;

				colIndexVuln = -1;

				//mam 03202012
				colIndexFacilityPhotoFileNorth = -1;
				colIndexFacilityPhotoFileSouth = -1;
				colIndexFacilityPhotoCaptionNorth = -1;
				colIndexFacilityPhotoCaptionSouth = -1;
				colIndexProcessPhotoFile = -1;
				colIndexProcessPhotoCaption = -1;
				colIndexComponentPhotoFile = -1;
				colIndexComponentPhotoCaption = -1;
				colIndexDisciplinePhotoFile = -1;
				colIndexDisciplinePhotoCaption = -1;
				//colIndexDisciplineMechPhotoFile = -1;
				//colIndexDisciplineMechPhotoCaption = -1;
				//colIndexDisciplineStructPhotoFile = -1;
				//colIndexDisciplineStructPhotoCaption = -1;
				//colIndexDisciplineLandPhotoFile = -1;
				//colIndexDisciplineLandPhotoCaption = -1;

				string gridColFixedRowText = "";

				arrayListCriticalities.Sort();

				//mam 07072011 - find each crit column in the grid
				for (int i = 0; i < arrayListCriticalities.Count; i++)
				{
					int critNumber = i + 1;
					string critName = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
					string critName2 = "Criticality - " + critName;
					c1FlexGridComponent[1, "Crit" + critNumber.ToString()] = critName;
					((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = critNumber;
					((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex = -1;
					c1FlexGridComponent.Cols["Crit" + critNumber.ToString()].Visible = true; 

					bool found = false;
					//foreach (Column gridColumn in grid.Cols)
					foreach (Column gridColumn in grid.Cols)
					{
						gridColFixedRowText = gridColumn[grid.Rows.Fixed] == null ? "" : gridColumn[grid.Rows.Fixed].ToString();
						if (string.Compare(gridColFixedRowText, critName, true) == 0 
							|| string.Compare(gridColFixedRowText, critName2, true) == 0)
						{
							((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex = gridColumn.Index;
							//totalColIndices += gridColumn.Index;
							found = true;
							break;
						}
					}
					if (!found)
					{
						//make the column invisible only if it exceeds the number of criticalities defined in the database
						if (critNumber > arrayListCriticalities.Count)
						{
							c1FlexGridComponent.Cols["Crit" + critNumber.ToString()].Visible = false; 
						}
					}
				}

				for (int i = 0; i < arrayListCriticalities.Count; i++)
				{
					int critNumber = i + 1;
					int critColumnIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
					switch (critNumber)
					{
						case 1:
							colIndexCrit1 = critColumnIndex;
							break;
						case 2:
							colIndexCrit2 = critColumnIndex;
							break;
						case 3:
							colIndexCrit3 = critColumnIndex;
							break;
						case 4:
							colIndexCrit4 = critColumnIndex;
							break;
						case 5:
							colIndexCrit5 = critColumnIndex;
							break;
						case 6:
							colIndexCrit6 = critColumnIndex;
							break;
					}
				}
				//</mam>

				//find the columns
				foreach (Column gridColumn in grid.Cols)
				{
					gridColFixedRowText = gridColumn[grid.Rows.Fixed] == null ? "" : gridColumn[grid.Rows.Fixed].ToString();

					if (colIndexType == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.Type.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Type].Caption.ToUpper())))
						
					{
						colIndexType = gridColumn.Index;
					}
					//if (colIndexName == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.Name.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Name].Caption.ToUpper())))
					//{
					//	colIndexName = gridColumn.Index;
					// }

					if (colIndexCustomENR == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CustomENRTable.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CustomENRTable].Caption.ToUpper())))
					{
						colIndexCustomENR = gridColumn.Index;
					}

					if (colIndexFacilityCurrentYear == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityCurrentYear.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityCurrentYear].Caption.ToUpper())))
					{
						colIndexFacilityCurrentYear = gridColumn.Index;
					}

					//mam 01222012
					if (colIndexFacilityCriticality == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityCriticality.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityCriticality].Caption.ToUpper())))
					{
						colIndexFacilityCriticality = gridColumn.Index;
					}

					if (colIndexFac == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityName].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "FACILITY / SYSTEM"))
					{
						colIndexFac = gridColumn.Index;
					}

					if (colIndexProc == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ProcessName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ProcessName].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "TREATMENT PROCESS / BASIN / ZONE"))
					{
						colIndexProc = gridColumn.Index;
					}

					if (colIndexComp == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ComponentName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ComponentName].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "MAJOR COMPONENT / SUBBASIN / SUBZONE"))
					{
						colIndexComp = gridColumn.Index;
					}

					if (colIndexComments == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.Comments.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Comments].Caption.ToUpper())))
					{
						colIndexComments = gridColumn.Index;
					}

					if (colIndexRetired == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.Retired.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Retired].Caption.ToUpper())))
					{
						colIndexRetired = gridColumn.Index;
					}

					//if (colIndexLOS == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.LOS.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.LOS].Caption.ToUpper())))
					//{
					//	colIndexLOS = gridColumn.Index;
					//}

					if (colIndexLOS == -1 && gridColFixedRowText != ""
						&& (string.Compare(gridColFixedRowText, GridColumnName.LOS.ToString(), true) == 0
						|| string.Compare(gridColFixedRowText, dataTableColNames.Columns[(int)GridColumnName.LOS].Caption, true) == 0))
					{
						colIndexLOS = gridColumn.Index;
					}

					//mam 07072011
					if (colIndexCipPlanningMode == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CipPlanningMode.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CipPlanningMode].Caption.ToUpper())))
					{
						colIndexCipPlanningMode = gridColumn.Index;
					}

					//mam 07072011
					if (colIndexAssetClass == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.AssetClass.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.AssetClass].Caption.ToUpper())))
					{
						colIndexAssetClass = gridColumn.Index;
					}

					//if (colIndexRedundant == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.RedundantAssets.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RedundantAssets].Caption.ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "REDUNDANT ASSET COUNT"
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "NUMBER OF ASSETS WITH SIMILAR FUNCTIONALITY"))
					if (colIndexRedundant == -1 && gridColFixedRowText != ""
						&& (string.Compare(gridColFixedRowText, GridColumnName.RedundantAssets.ToString(), true) == 0
						|| string.Compare(gridColFixedRowText, dataTableColNames.Columns[(int)GridColumnName.RedundantAssets].Caption, true) == 0
						|| string.Compare(gridColFixedRowText, "REDUNDANT ASSET COUNT", true) == 0
						|| string.Compare(gridColFixedRowText, "NUMBER OF ASSETS WITH SIMILAR FUNCTIONALITY", true) == 0))
					{
						colIndexRedundant = gridColumn.Index;
					}

					//mam 07072011 - no longer using four fixed crits
					//if (colIndexCritPublic == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CritPublic.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CritPublic].Caption.ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "CRITICALITY - PUBLIC HEALTH AND SAFETY"))
					//{
					//	colIndexCritPublic = gridColumn.Index;
					//}

					//mam 07072011 - no longer using four fixed crits
					//if (colIndexCritEnvironment == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CritEnvironment.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CritEnvironment].Caption.ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "CRITICALITY - ENVIRONMENTAL"))
					//{
					//	colIndexCritEnvironment = gridColumn.Index;
					//}

					//mam 07072011 - no longer using four fixed crits
					//if (colIndexCritRepair == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CritRepair.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CritRepair].Caption.ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "CRITICALITY - COST OF REPAIRS"))
					//{
					//	colIndexCritRepair = gridColumn.Index;
					//}

					//mam 07072011 - no longer using four fixed crits
					//if (colIndexCritEffect == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.CritEffect.ToString().ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CritEffect].Caption.ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "CRITICALITY - EFFECT ON CUSTOMERS"))
					//{
					//	colIndexCritEffect = gridColumn.Index;
					//}

					if (colIndexVuln == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.Vulnerability.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Vulnerability].Caption.ToUpper())))
					{
						colIndexVuln = gridColumn.Index;
					}

					//facility photos

					//mam 03202012
					if (colIndexFacilityPhotoFileNorth == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityPhotoFileNameNorth.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityPhotoFileNameNorth].Caption.ToUpper())))
					{
						colIndexFacilityPhotoFileNorth = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexFacilityPhotoFileSouth == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityPhotoFileNameSouth.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityPhotoFileNameSouth].Caption.ToUpper())))
					{
						colIndexFacilityPhotoFileSouth = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexFacilityPhotoCaptionNorth == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityPhotoCaptionNorth.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityPhotoCaptionNorth].Caption.ToUpper())))
					{
						colIndexFacilityPhotoCaptionNorth = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexFacilityPhotoCaptionSouth == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.FacilityPhotoCaptionSouth.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.FacilityPhotoCaptionSouth].Caption.ToUpper())))
					{
						colIndexFacilityPhotoCaptionSouth = gridColumn.Index;
					}

					//process photos

					//mam 03202012
					if (colIndexProcessPhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ProcessPhotoFileName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ProcessPhotoFileName].Caption.ToUpper())))
					{
						colIndexProcessPhotoFile = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexProcessPhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ProcessPhotoCaption.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ProcessPhotoCaption].Caption.ToUpper())))
					{
						colIndexProcessPhotoCaption = gridColumn.Index;
					}

					//component photos

					//mam 03202012
					if (colIndexComponentPhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ComponentPhotoFileName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ComponentPhotoFileName].Caption.ToUpper())))
					{
						colIndexComponentPhotoFile = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexComponentPhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ComponentPhotoCaption.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ComponentPhotoCaption].Caption.ToUpper())))
					{
						colIndexComponentPhotoCaption = gridColumn.Index;
					}

					//discipline photos

					//mam 03202012
					if (colIndexDisciplinePhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplinePhotoFileName.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplinePhotoFileName].Caption.ToUpper())))
					{
						colIndexDisciplinePhotoFile = gridColumn.Index;
					}

					//mam 03202012
					if (colIndexDisciplinePhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplinePhotoCaption.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplinePhotoCaption].Caption.ToUpper())))
					{
						colIndexDisciplinePhotoCaption = gridColumn.Index;
					}

//					//discipline mech photos
//
//					//mam 03202012
//					if (colIndexDisciplineMechPhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineMechPhotoFile.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineMechPhotoFile].Caption.ToUpper())))
//					{
//						colIndexDisciplineMechPhotoFile = gridColumn.Index;
//					}
//
//					//mam 03202012
//					if (colIndexDisciplineMechPhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineMechPhotoCaption.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineMechPhotoCaption].Caption.ToUpper())))
//					{
//						colIndexDisciplineMechPhotoCaption = gridColumn.Index;
//					}
//
//					//discipline struct photos
//
//					//mam 03202012
//					if (colIndexDisciplineStructPhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineStructPhotoFile.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineStructPhotoFile].Caption.ToUpper())))
//					{
//						colIndexDisciplineStructPhotoFile = gridColumn.Index;
//					}
//
//					//mam 03202012
//					if (colIndexDisciplineStructPhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineStructPhotoCaption.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineStructPhotoCaption].Caption.ToUpper())))
//					{
//						colIndexDisciplineStructPhotoCaption = gridColumn.Index;
//					}
//
//					//discipline land photos
//
//					//mam 03202012
//					if (colIndexDisciplineLandPhotoFile == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineLandPhotoFile.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineLandPhotoFile].Caption.ToUpper())))
//					{
//						colIndexDisciplineLandPhotoFile = gridColumn.Index;
//					}
//
//					//mam 03202012
//					if (colIndexDisciplineLandPhotoCaption == -1 && gridColumn[grid.Rows.Fixed] != null 
//						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.DisciplineLandPhotoCaption.ToString().ToUpper())
//						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.DisciplineLandPhotoCaption].Caption.ToUpper())))
//					{
//						colIndexDisciplineLandPhotoCaption = gridColumn.Index;
//					}
				}

				totalColIndices = DetermineColumnIndicesForDiscipline(loadSampleData);

				//if all of the column indices are -1, then none of the column names matched the ones we're looking for,
				//	and no data will be loaded into the grids
				totalColIndices += 
					colIndexType 
					//+ colIndexName 
					+ colIndexCustomENR
					+ colIndexFacilityCurrentYear

					//mam 01222012
					+ colIndexFacilityCurrentYear

					+ colIndexFac
					+ colIndexProc
					+ colIndexComp
					+ colIndexComments
					+ colIndexRetired
					+ colIndexLOS
					+ colIndexRedundant

					//mam 07072011 - should these be here? - yes, it's OK - it doesn't really matter what the totalColIndices is
					//	- as long as it's not -99
					+ colIndexCipPlanningMode
					+ colIndexAssetClass

					////mam 07072011
					+ colIndexCrit1
					+ colIndexCrit2
					+ colIndexCrit3
					+ colIndexCrit4
					+ colIndexCrit5
					+ colIndexCrit6

					//mam 07072011 - no longer using four fixed crits
					//+ colIndexCritPublic
					//+ colIndexCritEnvironment
					//+ colIndexCritRepair
					//+ colIndexCritEffect

					+ colIndexVuln

					//mam 03202012
					+ colIndexFacilityPhotoFileNorth
					+ colIndexFacilityPhotoFileSouth
					+ colIndexFacilityPhotoCaptionNorth
					+ colIndexFacilityPhotoCaptionSouth
					+ colIndexProcessPhotoFile
					+ colIndexProcessPhotoCaption
					+ colIndexComponentPhotoFile
					+ colIndexComponentPhotoCaption
					+ colIndexDisciplinePhotoFile
					+ colIndexDisciplinePhotoCaption;
					//+ colIndexDisciplineMechPhotoFile
					//+ colIndexDisciplineMechPhotoCaption
					//+ colIndexDisciplineStructPhotoFile
					//+ colIndexDisciplineStructPhotoCaption
					//+ colIndexDisciplineLandPhotoFile
					//+ colIndexDisciplineLandPhotoCaption;

				return totalColIndices;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DetermineColumnIndices: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return -99;
			}
		}

		private int DetermineColumnIndicesForDiscipline(bool loadSampleData)
		{
			try
			{
				C1FlexGrid grid = c1FlexGridSpreadsheetData;
				int totalColIndices = 0;
				if (loadSampleData)
				{
					grid = c1FlexGridSampleData;
				}

				colIndexAcquisitionCost = -1;
				colIndexCurrentValue = -1;
				colIndexRehabCost = -1;

				//mam 07072011
				colIndexRehabCostYear = -1;
				colIndexRehabInterval = -1;
				colIndexRehabYearLast = -1;
				//mam 01222012
				//colIndexRehabNext = -1;

				//mam 01222012
				colIndexRehabYearNext = -1;

				colIndexRepairCost = -1;
				colIndexReplacementValue = -1;
				colIndexReplacementValueYear = -1;

				//mam 07072011
				colIndexNextReplacementYear = -1;

				//mam 01222012
				colIndexReplacementValueDesc = -1;
				colIndexRehabCostDesc = -1;

				colIndexSalvageValue = -1;
				colIndexAnnualMaintCost = -1;
				colIndexInstallationYear = -1;
				colIndexOriginalUsefulLife = -1;
				colIndexCondition = -1;
				colIndexInspectionDate = -1;
				colIndexEquipmentIDNumber = -1;
				colIndexManufacturer = -1;
				colIndexRunHours = -1;
				colIndexRunningAtInspection = -1;
				colIndexAssessedBy = -1;

				foreach (Column gridColumn in grid.Cols)
				{
					if (colIndexAcquisitionCost == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.AcquisitionCost.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.AcquisitionCost].Caption.ToUpper())))
					{
						colIndexAcquisitionCost = gridColumn.Index;
					}
					if (colIndexCurrentValue == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("CurrentValue".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.CurrentValue].Caption.ToUpper())))
					{
						colIndexCurrentValue = gridColumn.Index;
					}
					if (colIndexRehabCost == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabCost".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabCost].Caption.ToUpper())))
					{
						colIndexRehabCost = gridColumn.Index;
					}

					//mam 07072011
					if (colIndexRehabCostYear == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabCostYear".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabCostYear].Caption.ToUpper())))
					{
						colIndexRehabCostYear = gridColumn.Index;
					}
					if (colIndexRehabInterval == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabInterval".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabInterval].Caption.ToUpper())))
					{
						colIndexRehabInterval = gridColumn.Index;
					}
					if (colIndexRehabYearLast == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabYearLast".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabYearLast].Caption.ToUpper())))
					{
						colIndexRehabYearLast = gridColumn.Index;
					}
					//mam 01222012
					//if (colIndexRehabNext == -1 && gridColumn[grid.Rows.Fixed] != null 
					//	&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabNext".ToUpper())
					//	|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabNext].Caption.ToUpper())))
					//{
					//	colIndexRehabNext = gridColumn.Index;
					//}

					//mam 01222012
					if (colIndexRehabYearNext == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RehabYearNext".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabYearNext].Caption.ToUpper())))
					{
						colIndexRehabYearNext = gridColumn.Index;
					}
					//</mam>

					if (colIndexRepairCost == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RepairCost".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RepairCost].Caption.ToUpper())))
					{
						colIndexRepairCost = gridColumn.Index;
					}
					if (colIndexReplacementValue == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("ReplacementValue".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ReplacementValue].Caption.ToUpper())))
					{
						colIndexReplacementValue = gridColumn.Index;
					}
					if (colIndexReplacementValueYear == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("ReplacementValueYear".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ReplacementValueYear].Caption.ToUpper())))
					{
						colIndexReplacementValueYear = gridColumn.Index;
					}

					//mam 07072011
					if (colIndexNextReplacementYear == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("NextReplacementYear".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.NextReplacementYear].Caption.ToUpper())))
					{
						colIndexNextReplacementYear = gridColumn.Index;
					}

					if (colIndexSalvageValue == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("SalvageValue".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.SalvageValue].Caption.ToUpper())))
					{
						colIndexSalvageValue = gridColumn.Index;
					}
					if (colIndexAnnualMaintCost == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("AnnualMaintCost".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.AnnualMaintCost].Caption.ToUpper())))
					{
						colIndexAnnualMaintCost = gridColumn.Index;
					}
					if (colIndexInstallationYear == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("InstallationYear".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.InstallationYear].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "DISCIPLINE INSTALLATION YEAR"))
					{
						colIndexInstallationYear = gridColumn.Index;
					}
					if (colIndexOriginalUsefulLife == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("OriginalUsefulLife".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.OriginalUsefulLife].Caption.ToUpper())))
					{
						colIndexOriginalUsefulLife = gridColumn.Index;
					}
					if (colIndexCondition == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("Condition".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Condition].Caption.ToUpper())))
					{
						colIndexCondition = gridColumn.Index;
					}
					if (colIndexInspectionDate == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("InspectionDate".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.InspectionDate].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "DATE OF INSPECTION"))
					{
						colIndexInspectionDate = gridColumn.Index;
					}
					if (colIndexEquipmentIDNumber == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("EquipmentIDNumber".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.EquipmentIDNumber].Caption.ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper() == "EQUIPMENT/ID NUMBER"))
					{
						colIndexEquipmentIDNumber = gridColumn.Index;
					}
					if (colIndexManufacturer == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("Manufacture".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.Manufacturer].Caption.ToUpper())))
					{
						colIndexManufacturer = gridColumn.Index;
					}
					if (colIndexRunHours == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RunHours".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RunHours].Caption.ToUpper())))
					{
						colIndexRunHours = gridColumn.Index;
					}
					if (colIndexRunningAtInspection == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("RunningAtInspection".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RunningAtInspection].Caption.ToUpper())))
					{
						colIndexRunningAtInspection = gridColumn.Index;
					}
					if (colIndexAssessedBy == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals("AssessedBy".ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.AssessedBy].Caption.ToUpper())))
					{
						colIndexAssessedBy = gridColumn.Index;
					}

					//mam 01222012
					if (colIndexReplacementValueDesc == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.ReplacementValueDesc.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.ReplacementValueDesc].Caption.ToUpper())))
					{
						colIndexReplacementValueDesc = gridColumn.Index;
					}
					if (colIndexRehabCostDesc == -1 && gridColumn[grid.Rows.Fixed] != null 
						&& (gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(GridColumnName.RehabCostDesc.ToString().ToUpper())
						|| gridColumn[grid.Rows.Fixed].ToString().ToUpper().Equals(dataTableColNames.Columns[(int)GridColumnName.RehabCostDesc].Caption.ToUpper())))
					{
						colIndexRehabCostDesc = gridColumn.Index;
					}
				}

				totalColIndices = 
					colIndexAcquisitionCost
					+ colIndexCurrentValue
					+ colIndexRehabCost

					//mam 07072011
					+ colIndexRehabCostYear
					+ colIndexRehabInterval
					+ colIndexRehabYearLast
					//mam 01222012
					//+ colIndexRehabNext

					//mam 01222012
					+ colIndexRehabYearNext

					+ colIndexRepairCost
					+ colIndexReplacementValue
					+ colIndexReplacementValueYear

					//mam 07072011
					+ colIndexNextReplacementYear

					//mam 01222012
					+ colIndexReplacementValueDesc
					+ colIndexRehabCostDesc

					+ colIndexSalvageValue
					+ colIndexAnnualMaintCost
					+ colIndexInstallationYear
					+ colIndexOriginalUsefulLife
					+ colIndexCondition
					+ colIndexInspectionDate
					+ colIndexEquipmentIDNumber
					+ colIndexManufacturer
					+ colIndexRunHours
					+ colIndexRunningAtInspection
					+ colIndexAssessedBy;

				return totalColIndices;

			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DetermineColumnIndicesForDiscipline: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return -99;
			}
		}

		private string ColumnsNotFoundInExcel()
		{
			System.Text.StringBuilder builder = new StringBuilder();

			if (colIndexCustomENR == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["CustomENRTable"].Caption);
			}

			if (colIndexFac == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityName"].Caption);
			}
			
			if (colIndexProc == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ProcessName"].Caption);
			}
			
			if (colIndexComp == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ComponentName"].Caption);
			}
			
			if (colIndexFacilityCurrentYear == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityCurrentYear"].Caption);
			}

			//mam 01222012
			if (colIndexFacilityCriticality == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityCriticality"].Caption);
			}

			if (colIndexRetired == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["Retired"].Caption);
			}
			
			if (colIndexLOS == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["LOS"].Caption);
			}
			
			if (colIndexRedundant == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RedundantAssets"].Caption);
			}
			
			if (colIndexCipPlanningMode == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["CipPlanningMode"].Caption);
			}
			
			if (colIndexAssetClass == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["AssetClass"].Caption);
			}
			
			if (colIndexCrit1 == -1 && arrayListCriticalities.Count > 0)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit1"].Caption);
			}
			
			if (colIndexCrit2 == -1 && arrayListCriticalities.Count > 1)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit2"].Caption);
			}
			
			if (colIndexCrit3 == -1 && arrayListCriticalities.Count > 2)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit3"].Caption);
			}
			
			if (colIndexCrit4 == -1 && arrayListCriticalities.Count > 3)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit4"].Caption);
			}
			
			if (colIndexCrit5 == -1 && arrayListCriticalities.Count > 4)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit5"].Caption);
			}
			
			if (colIndexCrit6 == -1 && arrayListCriticalities.Count > 5)
			{
				builder.Append(Environment.NewLine + "Criticality - " + dataTableColNames.Columns["Crit6"].Caption);
			}
			
			if (colIndexVuln == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["Vulnerability"].Caption);
			}
			
			//discipline columns
			if (colIndexAcquisitionCost == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["AcquisitionCost"].Caption);
			}
			
			if (colIndexCurrentValue == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["CurrentValue"].Caption);
			}
			
			if (colIndexRehabCost == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabCost"].Caption);
			}
			
			if (colIndexRehabCostYear == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabCostYear"].Caption);
			}
			
			if (colIndexRehabInterval == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabInterval"].Caption);
			}
			
			if (colIndexRehabYearLast == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabYearLast"].Caption);
			}

			//mam 01222012
			//if (colIndexRehabNext == -1)
			//{
			//	builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabNext"].Caption);
			//}

			//mam 01222012
			if (colIndexRehabYearNext == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabYearNext"].Caption);
			}
			
			if (colIndexRepairCost == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RepairCost"].Caption);
			}
			
			if (colIndexReplacementValue == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ReplacementValue"].Caption);
			}
			
			if (colIndexReplacementValueYear == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ReplacementValueYear"].Caption);
			}
			
			if (colIndexNextReplacementYear == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["NextReplacementYear"].Caption);
			}

			//mam 01222012
			if (colIndexReplacementValueDesc == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ReplacementValueDesc"].Caption);
			}

			//mam 01222012
			if (colIndexRehabCostDesc == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RehabCostDesc"].Caption);
			}

			if (colIndexSalvageValue == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["SalvageValue"].Caption);
			}
			
			if (colIndexAnnualMaintCost == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["AnnualMaintCost"].Caption);
			}
			
			if (colIndexInstallationYear == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["InstallationYear"].Caption);
			}
			
			if (colIndexOriginalUsefulLife == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["OriginalUsefulLife"].Caption);
			}
			
			if (colIndexCondition == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["Condition"].Caption);
			}
			
			if (colIndexInspectionDate == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["InspectionDate"].Caption);
			}
			
			if (colIndexEquipmentIDNumber == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["EquipmentIDNumber"].Caption);
			}
			
			if (colIndexManufacturer == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["Manufacturer"].Caption);
			}
			
			if (colIndexRunHours == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RunHours"].Caption);
			}
			
			if (colIndexRunningAtInspection == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["RunningAtInspection"].Caption);
			}
			
			if (colIndexAssessedBy == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["AssessedBy"].Caption);
			}
		
			if (colIndexComments == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["Comments"].Caption);
			}

			//facility photos

			//mam 03202012
			if (colIndexFacilityPhotoFileNorth == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityPhotoFileNameNorth"].Caption);
			}

			//mam 03202012
			if (colIndexFacilityPhotoFileSouth == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityPhotoFileNameSouth"].Caption);
			}

			//mam 03202012
			if (colIndexFacilityPhotoCaptionNorth == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityPhotoCaptionNorth"].Caption);
			}

			//mam 03202012
			if (colIndexFacilityPhotoCaptionSouth == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["FacilityPhotoCaptionSouth"].Caption);
			}

			//process photos

			//mam 03202012
			if (colIndexProcessPhotoFile == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ProcessPhotoFileName"].Caption);
			}

			//mam 03202012
			if (colIndexProcessPhotoCaption == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ProcessPhotoCaption"].Caption);
			}

			//component photos

			//mam 03202012
			if (colIndexComponentPhotoFile == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ComponentPhotoFileName"].Caption);
			}

			//mam 03202012
			if (colIndexComponentPhotoCaption == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["ComponentPhotoCaption"].Caption);
			}

			//discipline photos
			
			//mam 03202012
			if (colIndexDisciplinePhotoFile == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplinePhotoFileName"].Caption);
			}

			//mam 03202012
			if (colIndexDisciplinePhotoCaption == -1)
			{
				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplinePhotoCaption"].Caption);
			}

//			//discipline mech photos
//			
//			//mam 03202012
//			if (colIndexDisciplineMechPhotoFile == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineMechPhotoFile"].Caption);
//			}
//
//			//mam 03202012
//			if (colIndexDisciplineMechPhotoCaption == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineMechPhotoCaption"].Caption);
//			}
//
//			//discipline struct photos
//
//			//mam 03202012
//			if (colIndexDisciplineStructPhotoFile == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineStructPhotoFile"].Caption);
//			}
//
//			//mam 03202012
//			if (colIndexDisciplineStructPhotoCaption == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineStructPhotoCaption"].Caption);
//			}
//
//			//discipline land photos
//
//			//mam 03202012
//			if (colIndexDisciplineLandPhotoFile == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineLandPhotoFile"].Caption);
//			}
//
//			//mam 03202012
//			if (colIndexDisciplineLandPhotoCaption == -1)
//			{
//				builder.Append(Environment.NewLine + dataTableColNames.Columns["DisciplineStructPhotoCaption"].Caption);
//			}

			return builder.ToString();
		}

		private bool PopulateGrid(bool loadSampleData)
		{
			try
			{
				int colIndexSum = 0;
				string curValueString = string.Empty;
				string msgText = string.Empty;

				GridFinishEditing();
				DeleteAllData();

				colIndexSum = DetermineColumnIndices(loadSampleData);

				//mam 03202012
				string curSelGridName = "";
				if (arrayListSpreadsheetGrids.Count > 0 && comboBoxSheet.SelectedIndex > -1 && comboBoxSheet.SelectedIndex < arrayListSpreadsheetGrids.Count)
				{
					curSelGridName = ((C1FlexGrid)arrayListSpreadsheetGrids[comboBoxSheet.SelectedIndex]).Name;
				}
				//if (curSelGridName == wamMultipleSpreadsheetName
				if (curSelGridName == multiSheetNameFacility
					|| curSelGridName == multiSheetNameProcess
					|| curSelGridName == multiSheetNameComponentMsc
					|| curSelGridName == multiSheetNameComponentPn
					|| curSelGridName == multiSheetNameDiscMech
					|| curSelGridName == multiSheetNameDiscStruct
					|| curSelGridName == multiSheetNameDiscCivil)
				{
				}
				else
				{
					if (colIndexType == -1)
					{
						//Type column must exist in the spreadsheet
						msgText = "The Type column cannot be found in the spreadsheet.  Data cannot be loaded.";
					}
					else if (colIndexFac == -1 || colIndexProc == -1 || colIndexComp == -1)
					{
						//Facility Name, Process Name, and Component Name columns must all exist in the spreadsheet
						msgText = "One or more of the following columns cannot be found in the spreadsheet.  The data cannot be loaded.";
						msgText += Environment.NewLine + Environment.NewLine + "Facility Name" + Environment.NewLine + "Process Name" + Environment.NewLine + "Component Name";
					}
					else if (colIndexSum == -99)
					{
						msgText = "An error has occurred.  Data cannot be loaded from the spreadsheet.";
					}

					if (msgText.Length > 0)
					{
						msgText += "\r\n\r\nMake sure the column names are in the first row of the spreadsheet";
						msgText += " and that they match the column names found in the Sample Data grid.";
						MessageBox.Show(this, msgText, "Column Names Cannot Be Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
						return false;
					}

					string colsNotFound = ColumnsNotFoundInExcel(); 
					if (colsNotFound != "")
					{
						//some columns could not be found in the Excel file - show them to the user
						msgText = "The following columns could not be found in the Excel spreadsheet.  Would you like to load the spreadsheet anyway?";
						msgText += Environment.NewLine + colsNotFound;
						if (MessageBox.Show(this, msgText, "Columns Not Found", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
						{
							return false;
						}

						//mam 03202012
						this.Refresh();
					}
				}

				ImportFromTextFileFacility importFacility = new ImportFromTextFileFacility();
				ImportFromTextFileProcess importProcess = new ImportFromTextFileProcess();

				//				GridFinishEditing();
				//
				//				DeleteAllData();

				//				c1FlexGridFacility.Rows.RemoveRange(c1FlexGridFacility.Rows.Fixed, c1FlexGridFacility.Rows.Count - c1FlexGridFacility.Rows.Fixed);
				//				c1FlexGridProcess.Rows.RemoveRange(c1FlexGridProcess.Rows.Fixed, c1FlexGridProcess.Rows.Count - c1FlexGridProcess.Rows.Fixed);
				//				c1FlexGridComponent.Rows.RemoveRange(c1FlexGridComponent.Rows.Fixed, c1FlexGridComponent.Rows.Count - c1FlexGridComponent.Rows.Fixed);
				//				c1FlexGridComponentPN.Rows.RemoveRange(c1FlexGridComponentPN.Rows.Fixed, c1FlexGridComponentPN.Rows.Count - c1FlexGridComponentPN.Rows.Fixed);
				//				c1FlexGridDiscipline.Rows.RemoveRange(c1FlexGridDiscipline.Rows.Fixed, c1FlexGridDiscipline.Rows.Count - c1FlexGridDiscipline.Rows.Fixed);
				//
				//				listDictFacilityNames.Clear();
				//				listDictFacilityNamesAll.Clear();
				//				listDictFacilityNamesImportCheckBox.Clear();
				//				listDictProcessNames.Clear();
				//				listDictProcessNamesAll.Clear();
				//				listDictProcessNamesImportCheckBox.Clear();
				//				listDictProcessNamesForComponent.Clear();
				//				listDictComponentNames.Clear();
				//				listDictComponentNamesAll.Clear();
				//				listDictComponentNamesImportCheckBox.Clear();
				//				listDictDisciplineNames.Clear();
				//				listDictDisciplineNamesAll.Clear();
				//				listDictDisciplineNamesImportCheckBox.Clear();
				//				listDictComponentNamesDiscCombo.Clear();
				//
				//				importCollection.listFacility.Clear();
				//				importCollection.listProcess.Clear();
				//				importCollection.listComponent.Clear();
				//				importCollection.listComponentPN.Clear();
				//				importCollection.listDiscipline.Clear();

				//set the FacilityName col to string so we can assign cell values from the spreadsheet, rather than combo box selections
				c1FlexGridProcess.Cols["FacilityName"].DataType = typeof(string);

				//set combo boxes to strings so cells can be populated with data from spreadsheet
				c1FlexGridFacility.Cols["CustomENRTable"].DataType = typeof(string);

				int curTempFacID = 0;
				int curTempProcID = 0;

				C1FlexGrid grid = c1FlexGridSpreadsheetData;
				if (loadSampleData)
				{
					grid = c1FlexGridSampleData;
				}

				foreach (Row gridRow in grid.Rows)
				{
					if (gridRow.Index >= grid.Rows.Fixed)
					{
						//facility
						if (colIndexType > -1 && gridRow[colIndexType] != null 
							&& gridRow[colIndexType].ToString().ToUpper().StartsWith("FAC"))
						{
							curTempFacID--;

							//create a new facility object to import
							importFacility = new ImportFromTextFileFacility();
							importFacility.ImportThisItem = true;
							importFacility.InfoSetID = infoSetID;
							importFacility.TempID = curTempFacID;
							importFacility.ExistingID = 0;
							//importFacility.ItemName = colIndexName > -1 && gridRow[colIndexName] != null? 
							//	gridRow[colIndexName].ToString().Trim(): string.Empty;
							importFacility.ItemName = colIndexFac > -1 && gridRow[colIndexFac] != null? 
								gridRow[colIndexFac].ToString().Trim(): string.Empty;

							//mam 03202012 - unacceptable!!!
							//if (calledFromImportFile && !loadSampleData)
							//{
							//	labelProgress.Text = "Loading Facility  '" + importFacility.ItemName + "'  into grid";
							//	Application.DoEvents();
							//	if (stopLoadingFromExcel)
							//	{
							//		return false;
							//	}
							//}

							//add the facility to the facility grid
							Row newRow = c1FlexGridFacility.Rows.Add();
							c1FlexGridFacility.SetData(newRow.Index, "Import", importFacility.ImportThisItem);
							c1FlexGridFacility.SetData(newRow.Index, "TempID", importFacility.TempID);
							//c1FlexGridFacility.SetData(newRow.Index, "ItemID", importFacility.ExistingID);
							//c1FlexGridFacility.SetData(newRow.Index, "CustomENR", importFacility.CustomENRTableName);
							c1FlexGridFacility.SetData(newRow.Index, "CustomENRTable", colIndexCustomENR > -1 && gridRow[colIndexCustomENR] != null? 
								gridRow[colIndexCustomENR].ToString(): string.Empty);
							c1FlexGridFacility.SetData(newRow.Index, "FacilityName", importFacility.ItemName);
							//c1FlexGridFacility.SetData(newRow.Index, "Comments", importFacility.Comments);
							c1FlexGridFacility.SetData(newRow.Index, "Comments", colIndexComments > -1 && gridRow[colIndexComments] != null? 
								gridRow[colIndexComments].ToString(): string.Empty);

							//mam 07072011
							//c1FlexGridFacility.SetData(newRow.Index, "FacilityCurrentYear", colIndexFacilityCurrentYear > -1 && gridRow[colIndexFacilityCurrentYear] != null? 
							//	gridRow[colIndexFacilityCurrentYear].ToString(): DateTime.Now.Year.ToString());
							c1FlexGridFacility.SetData(newRow.Index, "FacilityCurrentYear", colIndexFacilityCurrentYear > -1 && gridRow[colIndexFacilityCurrentYear] != null ? 
								gridRow[colIndexFacilityCurrentYear].ToString() : SetDefaultValue(c1FlexGridFacility, newRow.Index, "FacilityCurrentYear", DateTime.Now.Year.ToString(), "Facility Year has been set to the current calendar year because it was blank in the Excel file"));

							//mam 01222012
							try
							{
								int tempCurrentYear = int.Parse(gridRow[colIndexFacilityCurrentYear].ToString());
								importFacility.CurrentYear = (short)tempCurrentYear;
							}
							catch
							{
							}

							//mam 01222012
							c1FlexGridFacility.SetData(newRow.Index, "FacilityCriticality", colIndexFacilityCriticality > -1 && gridRow[colIndexFacilityCriticality] != null ? 
								gridRow[colIndexFacilityCriticality].ToString() : SetDefaultValue(c1FlexGridFacility, newRow.Index, "FacilityCriticality", "1.00", "Facility Criticality Weighting Factor has been set to the 1.00 because it was blank in the Excel file"));

							//facility photos

							//mam 03202012
							c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoFileNameNorth", colIndexFacilityPhotoFileNorth > -1 && gridRow[colIndexFacilityPhotoFileNorth] != null? 
								gridRow[colIndexFacilityPhotoFileNorth].ToString(): string.Empty);
							c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoFileNameSouth", colIndexFacilityPhotoFileSouth > -1 && gridRow[colIndexFacilityPhotoFileSouth] != null? 
								gridRow[colIndexFacilityPhotoFileSouth].ToString(): string.Empty);
							c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoCaptionNorth", colIndexFacilityPhotoCaptionNorth > -1 && gridRow[colIndexFacilityPhotoCaptionNorth] != null? 
								gridRow[colIndexFacilityPhotoCaptionNorth].ToString(): string.Empty);
							c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoCaptionSouth", colIndexFacilityPhotoCaptionSouth > -1 && gridRow[colIndexFacilityPhotoCaptionSouth] != null? 
								gridRow[colIndexFacilityPhotoCaptionSouth].ToString(): string.Empty);

							//add the facility to the list of facilities
							listDictFacilityNames.Add(curTempFacID, importFacility);
							listDictFacilityNamesAll.Add(curTempFacID, importFacility);
							listDictFacilityNamesImportCheckBox.Add(curTempFacID, importFacility);
						}

						//process
						if (colIndexType > -1 && gridRow[colIndexType] != null && 
							gridRow[colIndexType].ToString().ToUpper().StartsWith("PROC"))
						{
							curTempProcID--;

							//create a new process object to import
							importProcess = new ImportFromTextFileProcess();
							importProcess.ImportThisItem = true;
							importProcess.ParentExists = true;
							importProcess.InfoSetID = infoSetID;
							importProcess.TempID = curTempProcID;
							importProcess.ExistingID = 0;
							importProcess.ItemName = colIndexProc > -1 && gridRow[colIndexProc] != null? 
								gridRow[colIndexProc].ToString().Trim(): string.Empty;

							//mam 03202012 - unacceptable!!!
							//if (calledFromImportFile && !loadSampleData)
							//{
							//	labelProgress.Text = "Loading Treatment Process  '" + importProcess.ItemName + "'  into grid";
							//	Application.DoEvents();
							//	if (stopLoadingFromExcel)
							//	{
							//		return false;
							//	}
							//}

							Row newRow = c1FlexGridProcess.Rows.Add();
							c1FlexGridProcess.SetData(newRow.Index, "Import", importProcess.ImportThisItem);
							c1FlexGridProcess.SetData(newRow.Index, "TempID", importProcess.TempID);
							//c1FlexGridProcess.SetData(newRow.Index, "ItemID", importProcess.ExistingID);
							c1FlexGridProcess.SetData(newRow.Index, "FacilityName", colIndexFac > -1 && gridRow[colIndexFac] != null? 
								gridRow[colIndexFac].ToString().Trim(): null);
							c1FlexGridProcess.SetData(newRow.Index, "ProcessName", importProcess.ItemName);
							c1FlexGridProcess.SetData(newRow.Index, "Comments", colIndexComments > -1 && gridRow[colIndexComments] != null? 
								gridRow[colIndexComments].ToString(): string.Empty);

							//mam 03202012
							c1FlexGridProcess.SetData(newRow.Index, "ProcessPhotoFileName", colIndexProcessPhotoFile > -1 && gridRow[colIndexProcessPhotoFile] != null? 
								gridRow[colIndexProcessPhotoFile].ToString(): string.Empty);
							c1FlexGridProcess.SetData(newRow.Index, "ProcessPhotoCaption", colIndexProcessPhotoCaption > -1 && gridRow[colIndexProcessPhotoCaption] != null? 
								gridRow[colIndexProcessPhotoCaption].ToString(): string.Empty);

							importCollection.Add(importProcess);

							//listDictProcessNames.Add(curTempProcID, importProcess);
							//listDictProcessNamesAll.Add(curTempProcID, importProcess);
							//listDictProcessNamesImportCheckBox.Add(curTempProcID, importProcess);

							listDictProcessNames.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
							listDictProcessNamesAll.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
							listDictProcessNamesImportCheckBox.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
						}
					}
				}

				HideInstructionPanel();

				//add existing Facility names to list dictionary (these are facilities that are currently in the tree)
				AddExistingFacilitiesToCombo();

				//add existing Process names to list dictionary (these are processes that are currently in the tree)
				AddExistingProcessesToCombo();
				AssignDataMapProcessGrid();
				AssignDataMapCustomENR();

				//PopulateCustomEnrComboBox();
				bool returnValue = PopulateGridComponent(loadSampleData);
				bool returnValue2 = PopulateGridDiscipline(loadSampleData);

				//mam 03202012 - don't automatically validate the data as it is loaded into the grid
				if (allowContinuousValidation)
				{
					ValidateGridData();
				}

				//buttonTest_Click(null, null);
				//SetFacilitiesInComponentGrid();

				int gridRowCount = CountGridRows();
				if (gridRowCount == 0)
				{
					msgText = "No data was found in the Excel spreadsheet.  No data was loaded.";
					MessageBox.Show(this, msgText, "Column Names Cannot Be Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}

				SetClearAllButtonState();

				if (isInitialized && !loadSampleData && gridRowCount > 0 && returnValue && returnValue2)
				{
					MessageBox.Show(this, "The data has been loaded into the Import grids", "Load Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else if (!returnValue || !returnValue2)
				{
					MessageBox.Show(this, "An error occurred while loading the data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}

				return (!returnValue || !returnValue2)? false: true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in PopulateGrid: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		private bool PopulateGridComponent(bool loadSampleData)
		{
			try
			{
				C1FlexGrid gridToLoad = c1FlexGridSpreadsheetData;
				if (loadSampleData)
				{
					gridToLoad = c1FlexGridSampleData;
				}

				//PopulateCompTypeComboBox();

				ImportFromTextFileComponent importComponent = new ImportFromTextFileComponent();
				C1FlexGrid grid = new C1FlexGrid();

				//set the FacilityName and ProcessName cols to strings so we can assign cell values from the spreadsheet, 
				//	rather than combo box selections
				c1FlexGridComponent.Cols["FacilityName"].DataType = typeof(string);
				c1FlexGridComponent.Cols["ProcessName"].DataType = typeof(string);
				c1FlexGridComponentPN.Cols["FacilityName"].DataType = typeof(string);
				c1FlexGridComponentPN.Cols["ProcessName"].DataType = typeof(string);

				//set combo boxes to strings so cells can be populated with data from spreadsheet
				c1FlexGridComponent.Cols["LOS"].DataType = typeof(string);

				//mam 07072011
				c1FlexGridComponent.Cols["CipPlanningMode"].DataType = typeof(string);

				//mam 07072011
				c1FlexGridComponent.Cols["Crit1"].DataType = typeof(string);
				c1FlexGridComponent.Cols["Crit2"].DataType = typeof(string);
				c1FlexGridComponent.Cols["Crit3"].DataType = typeof(string);
				c1FlexGridComponent.Cols["Crit4"].DataType = typeof(string);
				c1FlexGridComponent.Cols["Crit5"].DataType = typeof(string);
				c1FlexGridComponent.Cols["Crit6"].DataType = typeof(string);

				//mam 07072011 - no longer using four fixed crits
				//c1FlexGridComponent.Cols["CritPublic"].DataType = typeof(string);
				//c1FlexGridComponent.Cols["CritEnvironment"].DataType = typeof(string);
				//c1FlexGridComponent.Cols["CritRepair"].DataType = typeof(string);
				//c1FlexGridComponent.Cols["CritEffect"].DataType = typeof(string);

				int curTempCompID = 0;
				string curValueString = string.Empty;
				foreach (Row gridRow in gridToLoad.Rows)
				{
					if (gridRow.Index >= gridToLoad.Rows.Fixed)
					{
						if (colIndexType > -1 && gridRow[colIndexType] != null && 
							gridRow[colIndexType].ToString().ToUpper().StartsWith("COMP"))
						{
							curTempCompID--;

							//create a new component object to import
							importComponent = new ImportFromTextFileComponent();
						
							//set the properties of the import object
							importComponent.ImportThisItem = true;
							importComponent.ParentExists = true;
							importComponent.InfoSetID = infoSetID;
							importComponent.TempID = curTempCompID;
							importComponent.ExistingID = 0;

							//mam 07072011 - assign value below
							//importComponent.Retired = colIndexRetired > -1 && gridRow[colIndexRetired] != null?
							//	(gridRow[colIndexRetired].ToString().Trim().ToUpper() == "TRUE"? true: false): false;

							importComponent.ItemName = colIndexComp > -1 && gridRow[colIndexComp] != null? 
								gridRow[colIndexComp].ToString().Trim(): string.Empty;

							//mam 03202012 - unacceptable!!!
							//if (calledFromImportFile && !loadSampleData)
							//{
							//	labelProgress.Text = "Loading Major Component  '" + importComponent.ItemName + "'  into grid";
							//	Application.DoEvents();
							//	if (stopLoadingFromExcel)
							//	{
							//		return false;
							//	}
							//}

							importComponent.MechStructDisciplines = true;
							if (colIndexType > -1 && gridRow[colIndexType] != null && gridRow[colIndexType].ToString().ToUpper() == "COMPPN")
							{
								importComponent.MechStructDisciplines = false;
							}

							//*************************

							//set grid data

							if (importComponent.MechStructDisciplines)
							{
								grid = c1FlexGridComponent;
							}
							else
							{
								grid = c1FlexGridComponentPN;
							}

							Row newRow = grid.Rows.Add();
							grid.SetData(newRow.Index, "Import", importComponent.ImportThisItem);
							grid.SetData(newRow.Index, "TempID", importComponent.TempID);
							//grid.SetData(newRow.Index, "ItemID", importComponent.ExistingID);
							grid.SetData(newRow.Index, "FacilityName", colIndexFac > -1 && gridRow[colIndexFac] != null? 
								gridRow[colIndexFac].ToString().Trim(): null);
							grid.SetData(newRow.Index, "ProcessName", colIndexProc > -1 && gridRow[colIndexProc] != null? 
								gridRow[colIndexProc].ToString().Trim(): null);
							grid.SetData(newRow.Index, "ComponentName", importComponent.ItemName);

							//mam 07072011
							//grid.SetData(newRow.Index, "Retired", importComponent.Retired);
							if (colIndexRetired > -1)
							{
								curValueString = gridRow[colIndexRetired] == null ? "" : gridRow[colIndexRetired].ToString().Trim().ToUpper();
								//if (gridRow[colIndexRetired] == null)
								//{
								//	AssignDefaultValueTrueFalse(grid, newRow.Index, "Retired", false);
								//}
								//else
								//{
									//curValueString = gridRow[colIndexRetired].ToString().Trim().ToUpper();
									if (curValueString != "TRUE" && curValueString != "FALSE")
									{
										AssignDefaultValueTrueFalse(grid, newRow.Index, "Retired", false);
									}
									else
									{
										importComponent.Retired = curValueString == "TRUE" ? true : false;
										grid.SetData(newRow.Index, "Retired", importComponent.Retired);
									}
								//}
							}

							grid.SetData(newRow.Index, "Comments", colIndexComments > -1 && gridRow[colIndexComments] != null? 
								gridRow[colIndexComments].ToString(): string.Empty);

							//mam 03202012
							grid.SetData(newRow.Index, "ComponentPhotoFileName", colIndexComponentPhotoFile > -1 && gridRow[colIndexComponentPhotoFile] != null? 
								gridRow[colIndexComponentPhotoFile].ToString(): string.Empty);
							grid.SetData(newRow.Index, "ComponentPhotoCaption", colIndexComponentPhotoCaption > -1 && gridRow[colIndexComponentPhotoCaption] != null? 
								gridRow[colIndexComponentPhotoCaption].ToString(): string.Empty);

							if (importComponent.MechStructDisciplines)
							{
								c1FlexGridComponent.SetData(newRow.Index, "ComponentType", 0);

								if (colIndexLOS > -1)
								{
									if (gridRow[colIndexLOS] == null)
									{
										//mam 07072011 - assign the default LOS on initial grid load if the Excel cell is blank
										AssignDefaultValueLos(c1FlexGridComponent, newRow.Index, "LOS");
									}
									else
									{
										curValueString = EnumHandlers.GetLOSTextFromSingleWord(gridRow[colIndexLOS].ToString());
										if (curValueString.Length == 0)
										{
											c1FlexGridComponent.SetData(newRow.Index, "LOS", gridRow[colIndexLOS].ToString());
										}
										else
										{
											c1FlexGridComponent.SetData(newRow.Index, "LOS", curValueString);
										}
									}
								}

								//mam 07072011 - changed this
								if (colIndexRedundant > -1)
								{
									grid.SetData(newRow.Index, "RedundantAssets", colIndexRedundant > -1 && gridRow[colIndexRedundant] != null ? 
										gridRow[colIndexRedundant].ToString() 
										: SetDefaultValue(grid, newRow.Index, "RedundantAssets", "1", "Number of Assets with Similar Functionality has been set to its default value of 1 because it was blank in the Excel file"));
								}

								//if (colIndexRedundant > -1 && gridRow[colIndexRedundant] != null)
								//{
								//	curValueString = gridRow[colIndexRedundant].ToString();
								//	//if (curValueString.Length == 0)
								//	//{
								//	//	c1FlexGridComponent.SetData(newRow.Index, "RedundantAssets", gridRow[colIndexRedundant].ToString());
								//	//}
								//	//else
								//	//{
								//	c1FlexGridComponent.SetData(newRow.Index, "RedundantAssets", curValueString);
								//	//}
								//}

								//mam 07072011
								if (colIndexCipPlanningMode > -1)
								{
									if (gridRow[colIndexCipPlanningMode] == null)
									{
										//mam 07072011 - assign the default planning mode on initial grid load if the Excel cell is blank
										AssignDefaultValuePlanningMode(c1FlexGridComponent, newRow.Index, "CipPlanningMode");
									}
									else
									{
										curValueString = gridRow[colIndexCipPlanningMode].ToString();
										int listIndex = sortedListCip.IndexOfValue(curValueString);
										curValueString = listIndex > -1 ? sortedListCip.GetByIndex(listIndex).ToString() : curValueString;
										c1FlexGridComponent.SetData(newRow.Index, "CipPlanningMode", curValueString);
									}
								}
								//if (colIndexCipPlanningMode > -1)
								//	if (gridRow[colIndexCipPlanningMode] == null)
								//	{
								//		//
								//	}
								//	else
								//	{
								//		curValueString = gridRow[colIndexCipPlanningMode].ToString();
								//		int listIndex = sortedListCip.IndexOfValue(curValueString);
								//		curValueString = listIndex > -1 ? sortedListCip.GetByIndex(listIndex).ToString() : curValueString;
								//		c1FlexGridComponent.SetData(newRow.Index, "CipPlanningMode", curValueString);
								//	}

								//mam 07072011
								if (colIndexAssetClass > -1 && gridRow[colIndexAssetClass] != null)
								{
									curValueString = gridRow[colIndexAssetClass].ToString();
									c1FlexGridComponent.SetData(newRow.Index, "AssetClass", curValueString);
								}

								//*****************************

								bool found = false;
								//mam 07072011
								if (colIndexCrit1 > -1)
								{
									if (gridRow[colIndexCrit1] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit1");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit1].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit1 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 1;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true) == 0 
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit1", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit1", curValueString);
												}
											}
										}
									}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 0)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit1");
//									}
//								}

								//mam 07072011
								if (colIndexCrit2 > -1)
								{
									if (gridRow[colIndexCrit2] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit2");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit2].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit2 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 2;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true) == 0
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit2", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit2", curValueString);
												}
											}
										}
									}

									//curValueString = gridRow[colIndexCrit2].ToString();
									//int curValueInt = Convert.ToInt32(curValueString);

									//for (int i = 0; i < arrayListCriticalities.Count; i++)
									//{
									//	int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
									//	if (colIndexCrit2 == colIndex)
									//	{
									//		((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 2;
									//		ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;
									//		if (ld[curValueInt] == null)
									//		{
									//			c1FlexGridComponent.SetData(newRow.Index, "Crit2", curValueString);
									//		}
									//		else
									//		{
									//			c1FlexGridComponent.SetData(newRow.Index, "Crit2", ld[curValueInt].ToString());
									//		}
									//		break;
									//	}
									//}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 1)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit2");
//									}
//								}

								//mam 07072011
								if (colIndexCrit3 > -1)
								{
									if (gridRow[colIndexCrit3] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit3");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit3].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit3 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 3;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true) == 0 
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit3", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit3", curValueString);
												}
											}
										}
									}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 2)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit3");
//									}
//								}

								//mam 07072011
								if (colIndexCrit4 > -1)
								{
									if (gridRow[colIndexCrit4] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit4");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit4].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit4 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 4;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true) == 0 
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit4", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit4", curValueString);
												}
											}
										}
									}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 3)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit4");
//									}
//								}

								//mam 07072011
								if (colIndexCrit5 > -1)
								{
									if (gridRow[colIndexCrit5] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit5");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit5].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit5 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 5;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true) == 0 
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit5", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit5", curValueString);
												}
											}
										}
									}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 4)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit5");
//									}
//								}

								//mam 07072011
								if (colIndexCrit6 > -1)
								{
									if (gridRow[colIndexCrit6] == null)
									{
										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit6");
									}
									else
									{
										//get the value from the grid cell
										curValueString = gridRow[colIndexCrit6].ToString();

										//match the grid column with the array list to find the correct criticality
										for (int i = 0; i < arrayListCriticalities.Count; i++)
										{
											int colIndex = ((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex;
											if (colIndexCrit6 == colIndex)
											{
												((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber = 6;
												ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;

												found = false;
												IDictionaryEnumerator idEnumerator = ld.GetEnumerator();
												while (idEnumerator.MoveNext())
												{
													//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
													if (string.Compare(curValueString, idEnumerator.Key.ToString(), true)  == 0
														|| string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
													{
														c1FlexGridComponent.SetData(newRow.Index, "Crit6", idEnumerator.Key);
														found = true;
														break;
													}
												}

												if (!found)
												{
													c1FlexGridComponent.SetData(newRow.Index, "Crit6", curValueString);
												}
											}
										}
									}
								}
//								else
//								{
//									//mam 07072011 - if the crit col wasn't found, assign a default value
//									if (arrayListCriticalities.Count > 5)
//									{
//										AssignDefaultValueCrit(c1FlexGridComponent, newRow.Index, "Crit6");
//									}
//								}

								//*****************************

								//mam 07072011 - no longer using four fixed crits
								//if (colIndexCritPublic > -1 && gridRow[colIndexCritPublic] != null)
								//{
								//	//try to get the real crit factor text based on the text from the spreadsheet
								//	curValueString = EnumHandlers.GetCritPublicHealthTextFromSingleWord(gridRow[colIndexCritPublic].ToString());
								//	if (curValueString.Length == 0)
								//	{
								//		//if the spreadsheet text doesn't match the crit value, set the grid cell to the spreadsheet text
								//		c1FlexGridComponent.SetData(newRow.Index, "CritPublic", gridRow[colIndexCritPublic].ToString());
								//	}
								//	else
								//	{
								//		//if the spreadsheet value matches the crit value, set the grid cell to the crit text
								//		c1FlexGridComponent.SetData(newRow.Index, "CritPublic", curValueString);
								//	}
								//}

								//mam 07072011 - no longer using four fixed crits
								//if (colIndexCritEnvironment > -1 && gridRow[colIndexCritEnvironment] != null)
								//{
								//	curValueString = EnumHandlers.GetCritEnvironmentTextFromSingleWord(gridRow[colIndexCritEnvironment].ToString());
								//	if (curValueString.Length == 0)
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritEnvironment", gridRow[colIndexCritEnvironment].ToString());
								//	}
								//	else
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritEnvironment", curValueString);
								//	}
								//}

								//mam 07072011 - no longer using four fixed crits
								//if (colIndexCritRepair > -1 && gridRow[colIndexCritRepair] != null)
								//{
								//	curValueString = EnumHandlers.GetCritRepairTextFromSingleWord(gridRow[colIndexCritRepair].ToString());
								//	if (curValueString.Length == 0)
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritRepair", gridRow[colIndexCritRepair].ToString());
								//	}
								//	else
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritRepair", curValueString);
								//	}
								//}

								//mam 07072011 - no longer using four fixed crits
								//if (colIndexCritEffect > -1 && gridRow[colIndexCritEffect] != null)
								//{
								//	curValueString = EnumHandlers.GetCritEffectTextFromSingleWord(gridRow[colIndexCritEffect].ToString());
								//	if (curValueString.Length == 0)
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritEffect", gridRow[colIndexCritEffect].ToString());
								//	}
								//	else
								//	{
								//		c1FlexGridComponent.SetData(newRow.Index, "CritEffect", curValueString);
								//	}
								//}

								if (colIndexVuln > -1 && gridRow[colIndexVuln] != null)
								{
									importComponent.OverrideVulnerability = true;
									c1FlexGridComponent.SetData(newRow.Index, "Vulnerability", gridRow[colIndexVuln].ToString());
								}
							}
							else
							{
								c1FlexGridComponentPN.SetData(newRow.Index, "ComponentType", 1);
							}

							listDictComponentNames.Add(curTempCompID, importComponent);
							listDictComponentNamesAll.Add(curTempCompID, importComponent);
							listDictComponentNamesImportCheckBox.Add(curTempCompID, importComponent);
						}
					}
				}

				//add existing Component names to list dictionary (these are components that are currently in the tree)
				AddExistingComponentsToCombo();
				AssignDataMapComponentGrid(c1FlexGridComponent);
				AssignDataMapComponentGrid(c1FlexGridComponentPN);
				AssignDataMapLos(c1FlexGridComponent);
				AssignDataMapCrit(c1FlexGridComponent);

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in PopulateGridComponent: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		//mam 07072011
		private decimal LocalRehabIntervalDefault(short oul)
		{
			//set rehab interval to 50% of the oul
			decimal rehabInterval = Math.Round((decimal)oul / 2, 1);
			return rehabInterval;	//.ToString();
		}

		//mam 01222012 - added inspectionYear
		//mam 07072011
		private int LocalRehabYearLastDefault(short facilityYear, short installationYear, decimal rehabInterval, int inspectionYear)
		{
			//mam 01222012 - we are no longer allowing Last Rehab Year to be zero
			//if (rehabInterval == 0)
			//{
			//	//return installationYear > facilityYear ? facilityYear : installationYear;
			//	//return "0";
			//	return 0;
			//}
		
			//mam 01222012
			int rehabYearLast = 0;
			if (installationYear > 0)
			{
				//default to installation year
				rehabYearLast = installationYear;
			}
			else if (inspectionYear > 0)
			{
				//default to inspection year if installation year is zero
				rehabYearLast = inspectionYear;
			}

			//mam 01222012
			if (rehabInterval > 0)
			{
				rehabYearLast = facilityYear - Convert.ToInt32(Math.Ceiling((double)Math.Max(facilityYear - installationYear, 0) % Convert.ToDouble(rehabInterval)));
			}
		
			//mam 01222012
			if (inspectionYear == -1)
			{
				//don't check last rehab year against installation year or inspection year
				//	(this is used when importing the data into WAM - the data has already been verified)
				return rehabYearLast;
			}

			//mam 01222012
			if (installationYear > inspectionYear || rehabYearLast > inspectionYear)
			{
				//installation year <= last rehab year <= inspection year <= facility current year <= next rehab/replacement year
			
				//if installation year is greater than inspection year, the constraints have already been violated, so there is
				//	no point in comparing last rehab year to those values
				
				return inspectionYear;
			}

			//mam 01222012
			if (rehabYearLast < installationYear)
			{
				return installationYear;
			}

			return rehabYearLast;
		}

		//mam 01222012
		private string LocalReplacementYearNextDefault(int facilityYear, int inspectionYear, int originalUsefulLife, byte condition)
		{
			//next replacement year = facility current year + time to next replacement
			//time to next replacement = EvRul + inspection year - facility current year
			//EvRul = (1 - condition fraction) * OUL
			//next placement year = facility current year + (1 - condition fraction) * OUL + inspection year - facility current year
			//next replacement year simplifies to (1 - condition fraction) * OUL + inspection year

			//if next replacement year < facility year, next replacement year = facility year

			if (condition == 0xff)
			{
				return "";
			}

			int nextReplacementYear = 0;
			//decimal conditionFraction = EnumHandlers.GetConditionRankValue((CondRank)condition);
			decimal conditionFraction = EnumHandlers.GetConditionRankValueForUsefulLife((CondRank)condition);
			double result = Convert.ToDouble((1 - conditionFraction) * originalUsefulLife + inspectionYear);

			nextReplacementYear = Convert.ToInt32(Math.Floor(result));
			nextReplacementYear = nextReplacementYear < facilityYear ? facilityYear : nextReplacementYear;

			return nextReplacementYear.ToString();
		}

		//mam 01222012
		private string LocalRehabYearNextDefault(int facilityYear, int inspectionYear, int originalUsefulLife, byte condition)
		{
			//next rehab year = facility current year + time to next rehab
			//time to next rehab = EcRul + inspection year - facility current year
			//EcRul = OUL / 2 - OUL * condition fraction
			//next rehab year = facility current year + OUL / 2 - OUL * condition fraction + inspection year - facility current year
			//next rehab year simplifies to OUL / 2 - OUL * condition fraction + inspection year

			//if next rehab year < facility year, next rehab year = facility year

			if (condition == 0xff)
			{
				return "";
			}

			int nextRehabYear = 0;
			//decimal conditionFraction = EnumHandlers.GetConditionRankValue((CondRank)condition);
			decimal conditionFraction = EnumHandlers.GetConditionRankValueForUsefulLife((CondRank)condition);
			double result = (double)originalUsefulLife / 2 - (double)(originalUsefulLife * conditionFraction) + inspectionYear;

			nextRehabYear = Convert.ToInt32(Math.Floor(result));
			nextRehabYear = nextRehabYear < facilityYear ? facilityYear : nextRehabYear;

			return nextRehabYear.ToString();
		}

		private bool PopulateGridDiscipline(bool loadSampleData)
		{
			try
			{
				C1FlexGrid gridToLoad = c1FlexGridSpreadsheetData;
				if (loadSampleData)
				{
					gridToLoad = c1FlexGridSampleData;
				}

				//PopulateDiscTypeComboBox();

				//set the FacilityName and ProcessName and ComponentName cols to strings so we can assign cell values 
				//	from the spreadsheet, rather than combo box selections
				c1FlexGridDiscipline.Cols["FacilityName"].DataType = typeof(string);
				c1FlexGridDiscipline.Cols["ProcessName"].DataType = typeof(string);
				c1FlexGridDiscipline.Cols["ComponentName"].DataType = typeof(string);

				//set combo boxes to strings so cells can be populated with data from spreadsheet
				//c1FlexGridDiscipline.Cols["LOS"].DataType = typeof(string);
				c1FlexGridDiscipline.Cols["Condition"].DataType = typeof(string);

				ImportFromTextFileDiscipline importDiscipline = new ImportFromTextFileDiscipline();
				int curTempDiscID = 0;
				//string compType = string.Empty;
				string curValueString = string.Empty;

				//mam 07072011
				bool returnValue = true;
				bool okToAddToList = false;

				foreach (Row gridRow in gridToLoad.Rows)
				{
					try
					{
						//mam 07072011
						okToAddToList = false;

						if (gridRow.Index >= gridToLoad.Rows.Fixed)
						{
							if (colIndexType > -1 && gridRow[colIndexType] != null && 
								(gridRow[colIndexType].ToString().ToUpper().StartsWith("MECH")
								|| gridRow[colIndexType].ToString().ToUpper().StartsWith("STRUCT")
								|| gridRow[colIndexType].ToString().ToUpper().StartsWith("CIVIL")))
							{
								curTempDiscID--;

								//mam 07072011
								okToAddToList = true;

								//create a new discipline object to import
								importDiscipline = new ImportFromTextFileDiscipline();
								importDiscipline.DisciplineType = WAM.UI.NodeType.DisciplineMech;

								//mam 03202012
								string discType = "";

								if (colIndexType > -1 && gridRow[colIndexType] != null)
								{
									if (gridRow[colIndexType].ToString().ToUpper().StartsWith("MECH"))
									{
										importDiscipline.DisciplineType = WAM.UI.NodeType.DisciplineMech;
										discType = "Mechanical Discipline";
									}
									else if (gridRow[colIndexType].ToString().ToUpper().StartsWith("STRUCT"))
									{
										importDiscipline.DisciplineType = WAM.UI.NodeType.DisciplineStruct;
										discType = "Structural Discipline";
									}
									else if (gridRow[colIndexType].ToString().ToUpper().StartsWith("CIVIL"))
									{
										importDiscipline.DisciplineType = WAM.UI.NodeType.DisciplineLand;
										discType = "Civil Discipline";
									}
								}

								importDiscipline.LoadedFacName = gridRow[colIndexFac]!= null ? gridRow[colIndexFac].ToString() : "";
								importDiscipline.LoadedProcName = gridRow[colIndexProc]!= null ? gridRow[colIndexProc].ToString() : "";
								importDiscipline.LoadedCompName = gridRow[colIndexComp]!= null ? gridRow[colIndexComp].ToString() : "";

								importDiscipline.ImportThisItem = true;
								importDiscipline.ParentExists = true;
								importDiscipline.InfoSetID = infoSetID;
								importDiscipline.TempID = curTempDiscID;
								importDiscipline.ExistingID = 0;
								//importDiscipline.ItemName = gridRow[colIndexName].ToString().Trim();
								importDiscipline.MechStructDisciplines = true;

								//mam 03202012 - unacceptable!!!
								//if (calledFromImportFile && !loadSampleData)
								//{
								//	labelProgress.Text = "Loading " + discType + " into grid";
								//	Application.DoEvents();
								//	if (stopLoadingFromExcel)
								//	{
								//		return false;
								//	}
								//}

								//mam 07072011 - assign value below, with the rest of the values
								//importDiscipline.RunningAtInspection = colIndexRunningAtInspection > -1 && gridRow[colIndexRunningAtInspection] != null ? 
								//	(gridRow[colIndexRunningAtInspection].ToString().Trim().ToUpper() == "TRUE" ? true : false) : false;

								//*************************

								//set grid data

								C1FlexGrid grid = new C1FlexGrid();
								//if (importDiscipline.MechStructDisciplines)
								//{
								grid = c1FlexGridDiscipline;
								//}
								//else
								//{
								//	grid = c1FlexGridDiscipline;
								//}

								//							//set the FacilityName and ProcessName and ComponentName cols to strings so we can assign cell values 
								//							//	from the spreadsheet, rather than combo box selections
								//							grid.Cols["FacilityName"].DataType = typeof(string);
								//							grid.Cols["ProcessName"].DataType = typeof(string);
								//							grid.Cols["ComponentName"].DataType = typeof(string);

								Row newRow = grid.Rows.Add();
								grid.SetData(newRow.Index, "Import", importDiscipline.ImportThisItem);
								grid.SetData(newRow.Index, "TempID", importDiscipline.TempID);

								grid.SetData(newRow.Index, "LoadedFacilityName", importDiscipline.LoadedFacName);
								grid.SetData(newRow.Index, "LoadedProcessName", importDiscipline.LoadedProcName);
								grid.SetData(newRow.Index, "LoadedComponentName", importDiscipline.LoadedCompName);

								//grid.SetData(newRow.Index, "ItemID", importDiscipline.ExistingID);
								grid.SetData(newRow.Index, "FacilityName", colIndexFac > -1 && gridRow[colIndexFac] != null ? 
									gridRow[colIndexFac].ToString().Trim() : null);
								grid.SetData(newRow.Index, "ProcessName", colIndexProc > -1 && gridRow[colIndexProc] != null ? 
									gridRow[colIndexProc].ToString().Trim() : null);
								grid.SetData(newRow.Index, "ComponentName", colIndexComp > -1 && gridRow[colIndexComp] != null ? 
									gridRow[colIndexComp].ToString().Trim() : null);
								grid.SetData(newRow.Index, "Comments", colIndexComments > -1 && gridRow[colIndexComments] != null ? 
									gridRow[colIndexComments].ToString() : string.Empty);

								//mam 12262012 - for testing only!!!
								//WriteDataFromStructGrid(6);

								grid.SetData(newRow.Index, "AcquisitionCost", colIndexAcquisitionCost > -1 && gridRow[colIndexAcquisitionCost] != null && gridRow[colIndexAcquisitionCost].ToString() != "" ? 
									gridRow[colIndexAcquisitionCost].ToString() : null);
								if (colIndexCurrentValue > -1 && gridRow[colIndexCurrentValue] != null && gridRow[colIndexCurrentValue].ToString() != "")
								{
									importDiscipline.OverrideCurrentValue = true;
									c1FlexGridDiscipline.SetData(newRow.Index, "CurrentValue", gridRow[colIndexCurrentValue].ToString());
								}

								//mam 03202012
								grid.SetData(newRow.Index, "DisciplinePhotoFileName", colIndexDisciplinePhotoFile > -1 && gridRow[colIndexDisciplinePhotoFile] != null? 
									gridRow[colIndexDisciplinePhotoFile].ToString(): string.Empty);
								grid.SetData(newRow.Index, "DisciplinePhotoCaption", colIndexDisciplinePhotoCaption > -1 && gridRow[colIndexDisciplinePhotoCaption] != null? 
									gridRow[colIndexDisciplinePhotoCaption].ToString(): string.Empty);

								//mam 07072011 - moved up from below so we can use oul to calculate default rehab interval, and install year to calculate default last rehab year
								grid.SetData(newRow.Index, "OriginalUsefulLife", colIndexOriginalUsefulLife > -1 && gridRow[colIndexOriginalUsefulLife] != null && gridRow[colIndexOriginalUsefulLife].ToString() != "" ? 
									gridRow[colIndexOriginalUsefulLife].ToString() : SetDefaultValue(grid, newRow.Index, "OriginalUsefulLife", "0", "Original Useful Life has been set to zero because it was blank in the Excel file."));
								grid.SetData(newRow.Index, "InstallationYear", colIndexInstallationYear > -1 && gridRow[colIndexInstallationYear] != null && gridRow[colIndexInstallationYear].ToString() != "" ? 
									gridRow[colIndexInstallationYear].ToString() : SetDefaultValue(grid, newRow.Index, "InstallationYear", DateTime.Now.Year.ToString(), "Installation Year has been set to the current calendar year because it was blank in the Excel file"));

								//***************
								//mam 07072011 - get OUL for use in calculating default RehabInterval
								//  get facility current year for use in calculating default RehabYearLast
								short oul = 0;
								try
								{
									oul = short.Parse(grid.GetData(newRow.Index, "OriginalUsefulLife").ToString());
								}
								catch
								{
								}

								short facYear = 0;
								string disciplineFacName = grid.GetData(newRow.Index, "FacilityName").ToString();
								for (int rowNumber = c1FlexGridFacility.Rows.Fixed; rowNumber < c1FlexGridFacility.Rows.Count; rowNumber++)
								{
									string curFacName = c1FlexGridFacility.GetData(rowNumber, "FacilityName").ToString();
									if (string.Compare(curFacName, disciplineFacName, true) == 0)
									{
										try
										{
											facYear = short.Parse(c1FlexGridFacility.GetData(rowNumber, "FacilityCurrentYear").ToString());
										}
										catch
										{
										}
										break;
									}
								}
								//***************

								//grid.SetData(newRow.Index, "RehabCost", colIndexRehabCost > -1 && gridRow[colIndexRehabCost] != null ? 
								//	gridRow[colIndexRehabCost].ToString() : "0");
								grid.SetData(newRow.Index, "RehabCost", colIndexRehabCost > -1 && gridRow[colIndexRehabCost] != null && gridRow[colIndexRehabCost].ToString() != "" ? 
									gridRow[colIndexRehabCost].ToString() : SetDefaultValue(grid, newRow.Index, "RehabCost", "0", "Rehabilitation Cost has been set to zero because it was blank in the Excel file"));

								//mam 07072011
								grid.SetData(newRow.Index, "RehabCostYear", colIndexRehabCostYear > -1 && gridRow[colIndexRehabCostYear] != null && gridRow[colIndexRehabCostYear].ToString() != "" ? 
									gridRow[colIndexRehabCostYear].ToString() : SetDefaultValue(grid, newRow.Index, "RehabCostYear", "0", "Rehabilitation Cost Year has been set to zero because it was blank in the Excel file"));
								string defaultMessage = "Rehabilitation Interval was blank in the Excel file, so it has been set to a default value of 50% of Original Useful Life";
								if (oul == 0)
								{
									defaultMessage = "Rehabilitation Interval has been set to zero because it was blank in the Excel file";
								}
								grid.SetData(newRow.Index, "RehabInterval", colIndexRehabInterval > -1 && gridRow[colIndexRehabInterval] != null && gridRow[colIndexRehabInterval].ToString() != "" ? 
									gridRow[colIndexRehabInterval].ToString() : SetDefaultValue(grid, newRow.Index, "RehabInterval", LocalRehabIntervalDefault(oul).ToString(), defaultMessage));

								//mam 01222012 - moved up so we can calculate next rehab year and next replacement year
								grid.SetData(newRow.Index, "InspectionDate", colIndexInspectionDate > -1 && gridRow[colIndexInspectionDate] != null && gridRow[colIndexInspectionDate].ToString() != "" ? 
									gridRow[colIndexInspectionDate].ToString() : SetDefaultValue(grid, newRow.Index, "InspectionDate", DateTime.Now.Date.ToString(), "Inspection Date has been set to today's date because it was blank in the Excel file"));

								decimal rehabInterval = 0m;
								try
								{
									rehabInterval = decimal.Parse(grid.GetData(newRow.Index, "RehabInterval").ToString());
								}
								catch
								{
								}
								
								short installYear = 0;
								try
								{
									installYear = short.Parse(grid.GetData(newRow.Index, "InstallationYear").ToString());
								}
								catch
								{
								}

								//mam 01222012 - get inspectionYear and condition for use in calculating next replacement year and next rehab year

								//mam 01222012
								int inspectionYear = DateTime.Now.Year;
								try
								{
									DateTime inspectionDate = DateTime.Parse(grid.GetData(newRow.Index, "InspectionDate").ToString());
									inspectionYear = inspectionDate.Year;
								}
								catch
								{
								}

								//the source grid
								//gridRow[colIndexRehabYearLast]
								//the target grid
								//grid[newRow.Index, "RehabYearNext"]
								
								//mam 01222012
								byte condition = 0xFF;
								try
								{
									//string cellValue = grid.GetData(newRow.Index, "Condition").ToString();
									//string cellValue = grid.GetData(newRow.Index, colIndexCondition).ToString();
									string cellValue = "";
									if (gridRow[colIndexCondition] != null && gridRow[colIndexCondition].ToString().Trim() != "")
									{
										cellValue = gridRow[colIndexCondition].ToString().Trim().Substring(0, 1);
									}

									//if (cellValue != null || cellValue.Trim() != "")
									//{
									//	cellValue = cellValue.Substring(0, 1);
									//}

									condition = byte.Parse(cellValue);
								}
								catch
								{
								}

								if (rehabInterval == 0)
								{
									defaultMessage = "Last Rehabilitation has been set to zero because it was blank in the Excel file";
								}
								else
								{
									defaultMessage = "Last Rehabilitation Year was blank in the Excel file, so it has been set to the most recent possible";
									defaultMessage += " rehabilitation year based on Facility Current Year, Installation Year and Rehabilitation Interval";
								}

								grid.SetData(newRow.Index, "RehabYearLast", colIndexRehabYearLast > -1 && gridRow[colIndexRehabYearLast] != null && gridRow[colIndexRehabYearLast].ToString() != "" ? 
									gridRow[colIndexRehabYearLast].ToString() : SetDefaultValue(grid, newRow.Index, "RehabYearLast", LocalRehabYearLastDefault(facYear, installYear, rehabInterval, inspectionYear).ToString(), defaultMessage));

								//mam 01222012
								//grid.SetData(newRow.Index, "RehabNext", colIndexRehabNext > -1 && gridRow[colIndexRehabNext] != null && gridRow[colIndexRehabNext].ToString() != "" ? 
								//	gridRow[colIndexRehabNext].ToString() : null);

								//mam 01222012
								grid.SetData(newRow.Index, "RehabYearNext", colIndexRehabYearNext > -1 && gridRow[colIndexRehabYearNext] != null && gridRow[colIndexRehabYearNext].ToString() != "" ? 
									gridRow[colIndexRehabYearNext].ToString() : null);

								//mam 01222012 - no - don't set a default value when data is brought in from Excel 
								//	- if the user left the cell blank in Excel, leave it blank here, because that means
								//	  it will be calculated by WAM
								//mam 01222012
								//grid.SetData(newRow.Index, "RehabYearNext", colIndexRehabYearNext > -1 && gridRow[colIndexRehabYearNext] != null && gridRow[colIndexRehabYearNext].ToString() != "" ? 
								//	gridRow[colIndexRehabYearNext].ToString() : SetDefaultValue(grid, newRow.Index, "RehabYearNext", LocalRehabYearNextDefault(facYear, inspectionYear, oul, condition)
								//	, "Next Rehabilitation Year has been set to its default value of Economic Remaining Useful Life + Inspection Year"));

								//</mam>

								grid.SetData(newRow.Index, "RepairCost", colIndexRepairCost > -1 && gridRow[colIndexRepairCost] != null && gridRow[colIndexRepairCost].ToString() != "" ? 
									gridRow[colIndexRepairCost].ToString() : null);
								grid.SetData(newRow.Index, "ReplacementValue", colIndexReplacementValue > -1 && gridRow[colIndexReplacementValue] != null && gridRow[colIndexReplacementValue].ToString() != "" ? 
									gridRow[colIndexReplacementValue].ToString() : SetDefaultValue(grid, newRow.Index, "ReplacementValue", "0", "Replacement Value has been set to zero because it was blank in the Excel file"));
								
								//mam 07072011 - set the default Replacement Value Year to zero, to agree with the default value when a new Discipline is created
								//grid.SetData(newRow.Index, "ReplacementValueYear", colIndexReplacementValueYear > -1 && gridRow[colIndexReplacementValueYear] != null ? 
								//	gridRow[colIndexReplacementValueYear].ToString() : DateTime.Now.Year.ToString());
								grid.SetData(newRow.Index, "ReplacementValueYear", colIndexReplacementValueYear > -1 && gridRow[colIndexReplacementValueYear] != null && gridRow[colIndexReplacementValueYear].ToString() != "" ? 
									gridRow[colIndexReplacementValueYear].ToString() : SetDefaultValue(grid, newRow.Index, "ReplacementValueYear", "0", "Replacement Value Year has been set to zero because it was blank in the Excel file"));

								//mam 07072011
								grid.SetData(newRow.Index, "NextReplacementYear", colIndexNextReplacementYear > -1 && gridRow[colIndexNextReplacementYear] != null && gridRow[colIndexNextReplacementYear].ToString() != "" ? 
									gridRow[colIndexNextReplacementYear].ToString() : null);

								//mam 01222012 - no - don't set a default value when data is brought in from Excel 
								//	- if the user left the cell blank in Excel, leave it blank here, because that means
								//	  it will be calculated by WAM
								//mam 01222012
								//grid.SetData(newRow.Index, "NextReplacementYear", colIndexNextReplacementYear > -1 && gridRow[colIndexNextReplacementYear] != null && gridRow[colIndexNextReplacementYear].ToString() != "" ? 
								//	gridRow[colIndexNextReplacementYear].ToString() : SetDefaultValue(grid, newRow.Index, "NextReplacementYear", LocalReplacementYearNextDefault(facYear, inspectionYear, oul, condition).ToString()
								//	, "Next Replacement Year has been set to its default value of Evaluated Remaining Useful Life + Inspection Year"));

								//mam 01222012
								grid.SetData(newRow.Index, "ReplacementValueDesc", colIndexReplacementValueDesc > -1 && gridRow[colIndexReplacementValueDesc] != null && gridRow[colIndexReplacementValueDesc].ToString() != "" ? 
									gridRow[colIndexReplacementValueDesc].ToString() : null);

								//mam 01222012
								grid.SetData(newRow.Index, "RehabCostDesc", colIndexRehabCostDesc > -1 && gridRow[colIndexRehabCostDesc] != null && gridRow[colIndexRehabCostDesc].ToString() != "" ? 
									gridRow[colIndexRehabCostDesc].ToString() : null);

								grid.SetData(newRow.Index, "SalvageValue", colIndexSalvageValue > -1 && gridRow[colIndexSalvageValue] != null ? 
									gridRow[colIndexSalvageValue].ToString() : SetDefaultValue(grid, newRow.Index, "SalvageValue", "0", "Salvage Value has been set to zero because it was blank in the Excel file"));
								grid.SetData(newRow.Index, "AnnualMaintCost", colIndexAnnualMaintCost > -1 && gridRow[colIndexAnnualMaintCost] != null && gridRow[colIndexAnnualMaintCost].ToString() != "" ? 
									gridRow[colIndexAnnualMaintCost].ToString() : SetDefaultValue(grid, newRow.Index, "AnnualMaintCost", "0", "Annual Maintenance Cost has been set to zero because it was blank in the Excel file"));

								//moved up so we can calculate last rehab year
								//grid.SetData(newRow.Index, "InstallationYear", colIndexInstallationYear > -1 && gridRow[colIndexInstallationYear] != null ? 
								//	gridRow[colIndexInstallationYear].ToString() : SetDefaultValue(grid, newRow.Index, "InstallationYear", DateTime.Now.Year.ToString(), "Installation Year has been set to the current calendar year because it was blank in the Excel file"));

								//mam 07072011 - move this up so we can use original useful life when calculating the default rehab interval
								//grid.SetData(newRow.Index, "OriginalUsefulLife", colIndexOriginalUsefulLife > -1 && gridRow[colIndexOriginalUsefulLife] != null ? 
								//	gridRow[colIndexOriginalUsefulLife].ToString() : SetDefaultValue(grid, newRow.Index, "OriginalUsefulLife", "0", "Original Useful Life has been set to zero because it was blank in the Excel file."));

								//mam 01222012 - move this up so we can use the inspection year when calculating the default next rehab year and next replacement year
								//grid.SetData(newRow.Index, "InspectionDate", colIndexInspectionDate > -1 && gridRow[colIndexInspectionDate] != null && gridRow[colIndexInspectionDate].ToString() != "" ? 
								//	gridRow[colIndexInspectionDate].ToString() : SetDefaultValue(grid, newRow.Index, "InspectionDate", DateTime.Now.Date.ToString(), "Inspection Date has been set to today's date because it was blank in the Excel file"));

								grid.SetData(newRow.Index, "EquipmentIDNumber", colIndexEquipmentIDNumber > -1 && gridRow[colIndexEquipmentIDNumber] != null && gridRow[colIndexEquipmentIDNumber].ToString() != "" ? 
									gridRow[colIndexEquipmentIDNumber].ToString() : null);
								grid.SetData(newRow.Index, "Manufacturer", colIndexManufacturer > -1 && gridRow[colIndexManufacturer] != null && gridRow[colIndexManufacturer].ToString() != "" ? 
									gridRow[colIndexManufacturer].ToString() : null);
								grid.SetData(newRow.Index, "RunHours", colIndexRunHours > -1 && gridRow[colIndexRunHours] != null && gridRow[colIndexRunHours].ToString() != "" ? 
									gridRow[colIndexRunHours].ToString() : null);

								//mam 07072011
								//grid.SetData(newRow.Index, "RunningAtInspection", importDiscipline.RunningAtInspection);
								if (colIndexRunningAtInspection > -1)
								{
									if (gridRow[colIndexRunningAtInspection] == null)
									{
										if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
										{
											AssignDefaultValueTrueFalse(c1FlexGridDiscipline, newRow.Index, "RunningAtInspection", false);
										}
									}
									else
									{
										curValueString = gridRow[colIndexRunningAtInspection].ToString().Trim().ToUpper();
										if (curValueString != "TRUE" && curValueString != "FALSE")
										{
											if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
											{
												AssignDefaultValueTrueFalse(c1FlexGridDiscipline, newRow.Index, "RunningAtInspection", false);
											}
										}
										else
										{
											importDiscipline.RunningAtInspection = curValueString == "TRUE" ? true : false;
											grid.SetData(newRow.Index, "RunningAtInspection", importDiscipline.RunningAtInspection);
										}
									}
								}

								grid.SetData(newRow.Index, "AssessedBy", colIndexAssessedBy > -1 && gridRow[colIndexAssessedBy] != null && gridRow[colIndexAssessedBy].ToString() != "" ? 
									gridRow[colIndexAssessedBy].ToString() : null);

								//if (colIndexLOS > -1 && gridRow[colIndexLOS] != null)
								//{
								//	curValueString = EnumHandlers.GetLOSTextFromSingleWord(gridRow[colIndexLOS].ToString());
								//	if (curValueString.Length == 0)
								//	{
								//		c1FlexGridDiscipline.SetData(newRow.Index, "LOS", gridRow[colIndexLOS].ToString());
								//	}
								//	else
								//	{
								//		c1FlexGridDiscipline.SetData(newRow.Index, "LOS", curValueString);
								//	}
								//}

								if (colIndexCondition > -1 && gridRow[colIndexCondition] != null && gridRow[colIndexCondition].ToString() != "")
								{
									curValueString = EnumHandlers.GetConditionTextFromSingleWord(gridRow[colIndexCondition].ToString().Trim());
									if (curValueString.Length == 0)
									{
										c1FlexGridDiscipline.SetData(newRow.Index, "Condition", gridRow[colIndexCondition].ToString());
									}
									else
									{
										//if curValueString is N/A, it's because the grid value is N/A or NA, or because the grid value
										//	does not match any of the condition values, so that the condition cannot be determined
										if (curValueString == EnumHandlers.GetConditionRankString(WAM.Data.CondRank.No).ToString() 
											&& (gridRow[colIndexCondition].ToString().Trim().ToUpper() != "N/A" 
											&& gridRow[colIndexCondition].ToString().Trim().ToUpper() != "NA"))
										{
											c1FlexGridDiscipline.SetData(newRow.Index, "Condition", gridRow[colIndexCondition].ToString());
										}
										else
										{
											c1FlexGridDiscipline.SetData(newRow.Index, "Condition", curValueString);
										}
									}
								}
								else
								{
									c1FlexGridDiscipline.SetData(newRow.Index, "Condition", EnumHandlers.GetConditionRankString(CondRank.No));

									//mam 07072011
									SetDefaultValue(c1FlexGridDiscipline, newRow.Index, "Condition", "", "Condition has been set to N/A because it was blank in the Excel file");
								}

								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
								{
									c1FlexGridDiscipline.SetData(newRow.Index, "DisciplineType", 0);
								}
								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
								{
									c1FlexGridDiscipline.SetData(newRow.Index, "DisciplineType", 1);
								}
								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
								{
									c1FlexGridDiscipline.SetData(newRow.Index, "DisciplineType", 2);
								}

								//mam 07072011 - moved these down, outside of the try block
								//listDictDisciplineNames.Add(curTempDiscID, importDiscipline);
								//listDictDisciplineNamesAll.Add(curTempDiscID, importDiscipline);
								//listDictDisciplineNamesImportCheckBox.Add(curTempDiscID, importDiscipline);

								//add the Discipline Component Info

								//mam 07072011 - added valueCount and discipline type check
								int curGridRow = 0;
								int valueCount = 0;

								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
								{
									//mechanical
									importDiscipline.MechExcessiveVibration = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechExcessiveNoise = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechExcessiveCorrosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechExcessiveLeaks = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechRunningHot = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechCanRunWhenInspected = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechSupportIsFunctional = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechPartsMissing = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechPartsAvailable = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechAdequate = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MechMotorAmps = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.InstrIndicationFunctional = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.InstrAlarmFunctional = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.InstrPartsMissing = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.InstrPartsAvailable = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.ElecExcessiveCorrosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.ElecCleanContacts = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.ElecPartsAvailable = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.PipeExcessiveCorrosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.PipeExcessiveLeaks = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.PipePaintGood = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);

									//mam 07072011
									if (valueCount == 0)
									{
										//set the mech disc cell yellow
										SetDefaultValue(c1FlexGridDiscipline, newRow.Index, "DiscComponentInfo", "", "At least one item in Component Info has been set to N/A because that item was blank in the Excel file");
									}
								}

								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
								{
									//structural
									curGridRow = 21;
									importDiscipline.ConcreteSpalling = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.StructExcessiveCorrosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MembExcessiveCorrosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.CorrosionCoating = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.PaintGood = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.VisibleDeformities = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.SettingEvident = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.MajorCracks = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);

									//mam 07072011
									if (valueCount == 0)
									{
										//set the struct disc cell yellow
										SetDefaultValue(c1FlexGridDiscipline, newRow.Index, "DiscComponentInfo", "", "At least one item in Component Info has been set to N/A because that item was blank in the Excel file");
									}
								}

								if (importDiscipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
								{
									//civil
									curGridRow = 29;
									importDiscipline.SeveralPotholes = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.ExcessiveErosion = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.RoadDegradation = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.ExpansionSpace = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.FunctionCover = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.FencingAdequate = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.FacilitiesSecure = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppClayLiner = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBermErosionInterior = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBermErosionBermExterior = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBermVegetation = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBermSettlement = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBermSeepage = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppBurrowHoles = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppErosionProtectionPresent = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppErosionProtectionAdequate = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppAlgalBlooms = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);
									importDiscipline.LandAppDrainageAdequate = LoadDiscCompInfoItem(gridToLoad, importDiscipline, gridRow, dataTableDiscCompInfo.Rows[curGridRow++][1].ToString(), ref valueCount);

									//mam 07072011
									if (valueCount == 0)
									{
										//set the civil disc cell yellow
										SetDefaultValue(c1FlexGridDiscipline, newRow.Index, "DiscComponentInfo", "", "At least one item in Component Info has been set to N/A because that item was blank in the Excel file");
									}
								}
							}
						}
					}
					catch(Exception ex)
					{
						string errorText = ex.Message;
						returnValue = false;
					}

					//mam 07072011 - moved these down, outside of the try block
					if (okToAddToList)
					{
						listDictDisciplineNames.Add(curTempDiscID, importDiscipline);
						listDictDisciplineNamesAll.Add(curTempDiscID, importDiscipline);
						listDictDisciplineNamesImportCheckBox.Add(curTempDiscID, importDiscipline);
					}

				}	//end of grid row looper

				try
				{
					//add existing Discipline names to list dictionary (these are discipline that are currently in the tree)
					AddExistingDisciplinesToCombo();
					AssignDataMapDisciplineGrid();
					//AssignDataMapLos(c1FlexGridDiscipline);
					AssignDataMapCondition(c1FlexGridDiscipline);
					//AssignDataMapCrit(c1FlexGridDiscipline);
				}
				catch
				{
					returnValue = false;
				}

					//return true;
				return returnValue;

			}
			catch
			{
				//MessageBox.Show(this, "An error occurred in PopulateGridDiscipline: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		//mam 07072011 - added isNull
		private ItemStatus LoadDiscCompInfoItem(C1FlexGrid gridToLoad, ImportFromTextFileDiscipline curDiscipline, Row curGridRow, string discCompInfoItem, ref int valueCount)
		{
			try
			{
				string curValue;
				foreach (Column gridColumn in gridToLoad.Cols)
				{
					if (gridColumn[gridToLoad.Rows.Fixed] != null 
						&& gridColumn[gridToLoad.Rows.Fixed].ToString().Length > 0
						&& (gridColumn[gridToLoad.Rows.Fixed].ToString().Trim().ToUpper().Equals(discCompInfoItem.ToUpper())))
					{
						curValue = "";
						if (gridColumn[curGridRow.Index]!= null && gridColumn[curGridRow.Index].ToString().Trim().Length > 0)
						{
							curValue = gridColumn[curGridRow.Index].ToString().ToUpper().Trim();
							valueCount++;
						}
						if (curValue == "Y" || curValue == "YES")
						{
							return ItemStatus.Yes;
						}
						else if (curValue == "N" || curValue == "NO")
						{
							return ItemStatus.No;
						}
					}
				}

				return ItemStatus.NotApplicable;
			}
			catch
			{
				return ItemStatus.NotApplicable;
			}
		}

		//mam 03202012 - create this new method so we can load a sample grid and pass it back out to the calling method
		//	(this is used when creating the export/import report)
		public C1FlexGrid LoadSampleDataExternal()
		{
			arrayListCriticalities = Common.CommonTasks.LoadImportCritArray();
			LoadSampleData();

			return c1FlexGridSampleData;
		}

		private void LoadSampleData()
		{
			try
			{
				string fileName = string.Format(@"{0}\SampleData.wam", Application.StartupPath);
				System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();

				Stream stream = thisExe.GetManifestResourceStream("WAM.Files.SampleData.xls");
				byte[] byteArray = ReadFully(stream, 0);
				FileStream fileStream = new FileStream(fileName, System.IO.FileMode.Create);
				BinaryWriter binaryWriter = new BinaryWriter(fileStream);
				binaryWriter.Write(byteArray);
				binaryWriter.Flush();
				binaryWriter.Close();

				if (stream != null)
				{
					stream.Close();
				}
				if (fileStream != null)
				{
					fileStream.Close();
				}
				byteArray = null;

				if (System.IO.File.Exists(fileName))
				{
					LoadExcelFileSampleData(fileName);
				}
				else
				{
					MessageBox.Show("Sample file cannot be found");
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in LoadSampleData: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private static byte[] ReadFully (Stream stream, int initialLength)
		{
			// If we've been passed an unhelpful initial length, just use 32K.
			if (initialLength < 1)
			{
				initialLength = 32768;
			}
    
			byte[] buffer = new byte[initialLength];
			int read=0;
    
			int chunk;
			while ( (chunk = stream.Read(buffer, read, buffer.Length-read)) > 0)
			{
				read += chunk;
        
				// If we've reached the end of our buffer, check to see if there's any more information
				if (read == buffer.Length)
				{
					int nextByte = stream.ReadByte();
            
					// End of stream? If so, we're done
					if (nextByte==-1)
					{
						return buffer;
					}
            
					// Nope. Resize the buffer, put in the byte we've just read, and continue
					byte[] newBuffer = new byte[buffer.Length*2];
					Array.Copy(buffer, newBuffer, buffer.Length);
					newBuffer[read]=(byte)nextByte;
					buffer = newBuffer;
					read++;
				}
			}
			// Buffer is now too big. Shrink it.
			byte[] ret = new byte[read];
			Array.Copy(buffer, ret, read);
			return ret;
		}

		//mam 03202012 - added private variable fileToImportExcel
		private string fileToImportExcel = "";
		private bool calledFromImportFile = false;

		private void ImportFile(bool loadSampleGrid)
		{
			try
			{
				string fileToImport = SelectFileToImport();
				if (fileToImport.Length == 0)
				{
					return;
				}

				//mam 03202012
				fileToImportExcel = fileToImport;

				//mam 03202012
				if (useProgressPanel)
				{
					this.panelProgress.Left = 0;
					this.panelProgress.Top = 0;
					this.panelProgress.Size = this.ClientSize;
					this.panelProgress.Visible = true;
					calledFromImportFile = true;
				}

				//mam 03202012
				this.Enabled = false;

				this.Refresh();
				this.Cursor = Cursors.WaitCursor;

				//mam 03202012 - let's put the excel loading and grid creation on its own thread, as it can make WAM appear
				//	to be unresponsive if run on the UI thread
				//Update:  No - just run the data loading on the UI thread - it would be nice to create a worker thread to 
				//	handle the Excel data loading and grid population, but it would take too long to modify the existing code
				//	and retest the import from top to bottom!!!
				//Use DoEvents instead - it will be safe in this instance because the ImportFromTextFile form is modal, and 
				//	will be covered with a panel so the user cannot interact with it (but can cancel the current operation via the panel)
				//Update:  No - DoEvents isn't helping - WAM still seems unresponsive - we need a separate thread
				LoadExcelFile(fileToImport, loadSampleGrid, false);
				//excelLoadThread = new Thread(new ThreadStart(LoadExcelFileThread));
				//excelLoadThread.ApartmentState = ApartmentState.STA;
				//progressDisplayLoadExcel = new ProgressDisplayLoadExcel(this, 0, 0, 0);
				//progressDisplayLoadExcel.ShowDialog();
			}
			finally
			{
				this.Enabled = true;
				this.Cursor = Cursors.Default;
				calledFromImportFile = false;
				this.panelProgress.Visible = false;
			}
		}

		//mam 03202012
		//let's comment this so it doesn't get used
		//public void StartImportThreadExcelLoad()
		//{
		//	excelLoadThread.Start();
		//}

		//mam 03202012
		//let's comment this so it doesn't get used
		//public void LoadExcelFileThread()
		//{
		//	//no calls to ImportFile pass true for loadSampleGrid, so just pass false here
		//	//no calls to LoadExcelFile pass true for forExport, so just pass false here
		//	LoadExcelFile(fileToImportExcel, false, false);
		//}

		private bool PopulateTabs(bool loadSampleData, bool overwriteWithNewSpreadsheetData)
		{
			try
			{
				//if there are any rows in any of the grids, ask the user whether to 
				//	overwrite any data that may exist

				//count grid rows
				int rowCount = CountGridRows();
				DialogResult dialogResult = DialogResult.Yes;
				if (rowCount > 0)
				{
					//string msgText = "All data that currently exists in the Facility, Process, Component, and";
					//msgText += " Discipline grids will be overwritten.  Continue?";
					
					string msgText = "Overwrite existing data in the Facility, Process, Component, and Discipline tabs?";

					if (overwriteWithNewSpreadsheetData)
					{
						msgText = "Overwrite existing data in the Facility, Process, Component, and Discipline tabs?";
					}

					dialogResult = MessageBox.Show(msgText, "Populate Grids", 
						MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
				}
				if (dialogResult == DialogResult.Yes)
				{
					return PopulateGrid(loadSampleData);
				}

				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion /***** Get Spreadsheet Data and Populate Grids *****/

		#region /***** Populate Combo Boxes *****/

		private void PopulateCustomEnrComboBox()
		{
			listDictionaryCustomENRTable.Clear();
			WAM.Common.ComboBoxMethods comboBoxMethods = new WAM.Common.ComboBoxMethods();
			listDictionaryCustomENRTable = comboBoxMethods.GetEnrListItems(true);

			AssignDataMapCustomENR();

			c1FlexGridFacility.Redraw = true;
		}

		private void AssignDataMapCustomENR()
		{
			c1FlexGridFacility.Cols["CustomENRTable"].DataType = typeof(Int32);
			c1FlexGridFacility.Cols["CustomENRTable"].DataMap = listDictionaryCustomENRTable;
			c1FlexGridFacility.Cols["CustomENRTable"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void PopulateCompTypeComboBox()
		{
			listDictionaryComponentType.Add(0, "Mechanical / Structural / Civil");
			listDictionaryComponentType.Add(1, "Nodes / Appurtenances / Piping");

			c1FlexGridComponent.Cols["ComponentType"].DataType = typeof(Int32);
			c1FlexGridComponent.Cols["ComponentType"].DataMap = listDictionaryComponentType;
			c1FlexGridComponent.Cols["ComponentType"].TextAlign = TextAlignEnum.LeftCenter;

			c1FlexGridComponentPN.Cols["ComponentType"].DataType = typeof(Int32);
			c1FlexGridComponentPN.Cols["ComponentType"].DataMap = listDictionaryComponentType;
			c1FlexGridComponentPN.Cols["ComponentType"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void PopulateLosComboBox(C1FlexGrid grid)
		{
			LevelOfService[] losValues = (LevelOfService[])Enum.GetValues(typeof(LevelOfService));
			listDictionaryLOS = new ListDictionary();
			for (int i = 0; i < losValues.Length; i++)
			{
				listDictionaryLOS.Add((int)losValues[i], EnumHandlers.GetLOSString(losValues[i]));
			}
			AssignDataMapLos(grid);
		}

		private void AssignDataMapLos(C1FlexGrid grid)
		{
			grid.Cols["LOS"].DataType = typeof(Int32);
			grid.Cols["LOS"].DataMap = listDictionaryLOS;
			grid.Cols["LOS"].TextAlign = TextAlignEnum.LeftCenter;
		}

		//mam 07072011
		private void PopulateCipComboBox(C1FlexGrid grid)
		{
			try
			{
				arrayListCip = Common.CommonTasks.GetCipObjects();
				sortedListCip = new SortedList();
				for (int i = 0; i < arrayListCip.Count; i++)
				{
					Common.CommonTasks.Cip cip = (Common.CommonTasks.Cip)arrayListCip[i];
					sortedListCip.Add(cip.CipPlanningId, cip.CipPlanningText);
				}
				AssignDataMapCip(grid);
			}
			catch
			{
				//string msg = "An error has occurred in PopulateCipComboBox";
				//WAM.Common.CommonTasks.ShowErrorMessage("ImportFromTextFile.PopulatePlanningModeComboBox", "An error has occurred: " + msg + ex.Message);
				MessageBox.Show(this, "An error occurred while accessing the Planning Mode data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//mam 07072011
		private void AssignDataMapCip(C1FlexGrid grid)
		{
			grid.Cols["CipPlanningMode"].DataType = typeof(Int32);
			grid.Cols["CipPlanningMode"].DataMap = sortedListCip;
			grid.Cols["CipPlanningMode"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void PopulateConditionComboBox(C1FlexGrid grid)
		{
			CondRank[] condValues = (CondRank[])Enum.GetValues(typeof(CondRank));
			listDictionaryCondition = new ListDictionary();
			for (int i = 0; i < condValues.Length; i++)
			{
				listDictionaryCondition.Add(i, EnumHandlers.GetConditionRankString(condValues[i]));
			}
			AssignDataMapCondition(grid);
		}

		private void AssignDataMapCondition(C1FlexGrid grid)
		{
			grid.Cols["Condition"].DataType = typeof(Int32);
			grid.Cols["Condition"].DataMap = listDictionaryCondition;
			grid.Cols["Condition"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void AssignDataMapCrit(C1FlexGrid grid)
		{
			//mam 07072011
			//clear the grid col datamaps
			try
			{
				for (int i = 1; i <= 6; i++)
				{
					grid.Cols["Crit" + i.ToString()].DataType = null;
					grid.Cols["Crit" + i.ToString()].DataMap = null;
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show("data map error:  " + ex.ToString());
			}
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				int critNumber = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber;
				grid.Cols["Crit" + critNumber.ToString()].DataType = typeof(Int32);
				grid.Cols["Crit" + critNumber.ToString()].DataMap = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;
				grid.Cols["Crit" + critNumber.ToString()].TextAlign = TextAlignEnum.LeftCenter;
			}

			//mam 07072011 - hide the unused crit columns
			HideUnusedCritColumns(grid);
			//for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
			//{
			//	grid.Cols["Crit" + i.ToString()].Visible = false;
			//}

			//			//mam 07072011
			//			grid.Cols["Crit1"].DataType = typeof(Int32);
			//			grid.Cols["Crit1"].DataMap = ((CriticalityForImport)arrayListCriticalities[0]).CriticalityFactors;
			//			grid.Cols["Crit1"].TextAlign = TextAlignEnum.LeftCenter;

			//*************************

			//mam 07072011 - no longer using four fixed crits
			//grid.Cols["CritPublic"].DataType = typeof(Int32);
			//grid.Cols["CritPublic"].DataMap = listDictionaryCritPublic;
			//grid.Cols["CritPublic"].TextAlign = TextAlignEnum.LeftCenter;
			//grid.Cols["CritEnvironment"].DataType = typeof(Int32);
			//grid.Cols["CritEnvironment"].DataMap = listDictionaryCritEnvironment;
			//grid.Cols["CritEnvironment"].TextAlign = TextAlignEnum.LeftCenter;
			//grid.Cols["CritRepair"].DataType = typeof(Int32);
			//grid.Cols["CritRepair"].DataMap = listDictionaryCritRepair;
			//grid.Cols["CritRepair"].TextAlign = TextAlignEnum.LeftCenter;
			//grid.Cols["CritEffect"].DataType = typeof(Int32);
			//grid.Cols["CritEffect"].DataMap = listDictionaryCritEffect;
			//grid.Cols["CritEffect"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void PopulateCritComboBox()
		{
			//mam 07072011
			arrayListCriticalities = Common.CommonTasks.LoadImportCritArray();
			int critNumber = 0;
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				critNumber = i + 1;
				c1FlexGridComponent[1, "Crit" + critNumber.ToString()] = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
			}

			//***************************

			//mam 07072011 - no longer using four fixed crits
			////crit - public health
			//CriticalityPublicHealth[] critHealthValues = (CriticalityPublicHealth[])Enum.GetValues(
			//	typeof(CriticalityPublicHealth));
			//listDictionaryCritPublic = new ListDictionary();
			//for (int i = 0; i < critHealthValues.Length; i++)
			//{
			//	listDictionaryCritPublic.Add((int)critHealthValues[i], EnumHandlers.GetCritPublicHealthStringAssocValue(critHealthValues[i]));
			//}

			//***************************

			//mam 07072011 - no longer using four fixed crits
			////crit - environmental
			//CriticalityEnvironmental[] critEnvValues = (CriticalityEnvironmental[])Enum.GetValues(
			//	typeof(CriticalityEnvironmental));
			//listDictionaryCritEnvironment = new ListDictionary();
			//for (int i = 0; i < critEnvValues.Length; i++)
			//{
			//	listDictionaryCritEnvironment.Add((int)critEnvValues[i], EnumHandlers.GetCritEnvironmentalStringAssocValue(critEnvValues[i]));
			//}

			//***************************

			//mam 07072011 - no longer using four fixed crits
			////crit - repair cost
			//CriticalityRepairCost[] critRepairValues = (CriticalityRepairCost[])Enum.GetValues(
			//	typeof(CriticalityRepairCost));
			//listDictionaryCritRepair = new ListDictionary();
			//for (int i = 0; i < critRepairValues.Length; i++)
			//{
			//	listDictionaryCritRepair.Add((int)critRepairValues[i], EnumHandlers.GetCritRepairCostStringAssocValue(critRepairValues[i]));
			//}

			//***************************

			//mam 07072011 - no longer using four fixed crits
			////crit - effect on customers
			//CriticalityCustomerEffect[] critCustEffectValues = (CriticalityCustomerEffect[])Enum.GetValues(
			//	typeof(CriticalityCustomerEffect));
			//listDictionaryCritEffect = new ListDictionary();
			//for (int i = 0; i < critCustEffectValues.Length; i++)
			//{
			//	listDictionaryCritEffect.Add((int)critCustEffectValues[i], EnumHandlers.GetCritCustomerEffectStringAssocValue(critCustEffectValues[i]));
			//}

			AssignDataMapCrit(c1FlexGridComponent);
			//AssignDataMapCrit(c1FlexGridDiscipline);
		}

		private void PopulateDiscTypeComboBox()
		{
			listDictionaryDisciplineType.Add(0, "Mechanical");
			listDictionaryDisciplineType.Add(1, "Structural");
			listDictionaryDisciplineType.Add(2, "Civil");

			c1FlexGridDiscipline.Cols["DisciplineType"].DataType = typeof(Int32);
			c1FlexGridDiscipline.Cols["DisciplineType"].DataMap = listDictionaryDisciplineType;
			c1FlexGridDiscipline.Cols["DisciplineType"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void AddExistingFacilitiesToCombo()
		{
			try
			{
				//add existing Facility names to list dictionary (these are facilities that are currently in the tree)
				Facility[] facilities = CacheManager.GetFacilities(infoSetID);
				ImportFromTextFileFacility importFacility = new ImportFromTextFileFacility();
				int curTempFacID = GetNextTempID(WAM.UI.NodeType.Facility);

				for (int i = 0; i < facilities.Length; i++)
				{
					//curTempFacID--;
					importFacility = new ImportFromTextFileFacility();
					importFacility.ImportThisItem = false;
					importFacility.InfoSetID = infoSetID;
					importFacility.TempID = curTempFacID;
					importFacility.ExistingID = facilities[i].ID;
					importFacility.UsesCustomENRTable = facilities[i].UsesCustomENRTable;
					importFacility.CustomENRListID = facilities[i].CustomENRListID;
					//importFacility.CustomENRTableName = facilities[i]
					importFacility.ItemName = facilities[i].Name;
					importFacility.Comments = facilities[i].Comments;

					listDictFacilityNamesAll.Add(curTempFacID, importFacility);
					listDictFacilityNamesImportCheckBox.Add(curTempFacID, importFacility);

					curTempFacID--;
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddExistingFacilitiesToCombo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AddExistingProcessesToCombo()
		{
			try
			{
				Facility[] facilities = CacheManager.GetFacilities(infoSetID);
				ImportFromTextFileProcess importProcess = new ImportFromTextFileProcess();
				int curTempProcID = GetNextTempID(WAM.UI.NodeType.TreatmentProcess);

				for (int i = 0; i < facilities.Length; i++)
				{
					TreatmentProcess[] processes = CacheManager.GetProcesses(infoSetID, facilities[i].ID);
					for (int j = 0; j < processes.Length; j++)
					{
						//curTempProcID--;
						importProcess = new ImportFromTextFileProcess();
						importProcess.ImportThisItem = false;
						importProcess.ParentExists = true;
						importProcess.InfoSetID = infoSetID;
						importProcess.TempID = curTempProcID;
						importProcess.ExistingID = processes[j].ID;
						importProcess.FacilityID = facilities[i].ID;
						importProcess.ItemName = processes[j].Name;
						importProcess.Comments = processes[j].Comments;

						importCollection.Add(importProcess);

						listDictProcessNamesAll.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
						listDictProcessNamesImportCheckBox.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
						//listDictProcessNamesImportCheckBox.Add((ImportFromTextFileProcess)importCollection.listProcess[importProcess.TempID], 
						//	((ImportFromTextFileProcess)importCollection.listProcess[importProcess.TempID]).ItemName);

						curTempProcID--;
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddExistingProcessesToCombo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AddExistingComponentsToCombo()
		{
			Facility[] facilities = CacheManager.GetFacilities(infoSetID);
			ImportFromTextFileComponent importComponent = new ImportFromTextFileComponent();
			int curTempCompID = GetNextTempID(WAM.UI.NodeType.MajorComponent);

			for (int i = 0; i < facilities.Length; i++)
			{
				TreatmentProcess[] processes = CacheManager.GetProcesses(infoSetID, facilities[i].ID);
				for (int j = 0; j < processes.Length; j++)
				{
					MajorComponent[] components = CacheManager.GetComponents(infoSetID, processes[j].ID);
					for (int k = 0; k < components.Length; k++)
					{
						//curTempCompID--;

						importComponent = new ImportFromTextFileComponent();
						importComponent.ImportThisItem = false;
						importComponent.ParentExists = true;
						importComponent.InfoSetID = infoSetID;
						importComponent.TempID = curTempCompID;
						importComponent.ExistingID = components[k].ID;
						importComponent.ProcessID = processes[j].ID;
						importComponent.ItemName = components[k].Name;
						importComponent.Retired = components[k].Retired;
						importComponent.MechStructDisciplines = components[k].MechStructDisciplines;
						importComponent.Comments = components[k].Comments;

						listDictComponentNamesAll.Add(curTempCompID, importComponent);

						curTempCompID--;
					}
				}
			}
		}

		private void AddExistingDisciplinesToCombo()
		{
			Facility[] facilities = CacheManager.GetFacilities(infoSetID);
			ImportFromTextFileDiscipline importDiscipline = new ImportFromTextFileDiscipline();
			int curTempDiscID = GetNextTempID(WAM.UI.NodeType.DisciplineMech);

			for (int i = 0; i < facilities.Length; i++)
			{
				TreatmentProcess[] processes = CacheManager.GetProcesses(infoSetID, facilities[i].ID);
				for (int j = 0; j < processes.Length; j++)
				{
					MajorComponent[] components = CacheManager.GetComponents(infoSetID, processes[j].ID);
					for (int k = 0; k < components.Length; k++)
					{
						Discipline[] disciplines = CacheManager.GetDisciplines(infoSetID, components[k].ID);
						for (int l = 0; l < disciplines.Length; l++)

						{
							//curTempDiscID--;

							importDiscipline = new ImportFromTextFileDiscipline();
							importDiscipline.ImportThisItem = false;
							importDiscipline.ParentExists = true;
							importDiscipline.InfoSetID = infoSetID;
							importDiscipline.TempID = curTempDiscID;
							importDiscipline.ExistingID = disciplines[l].ID;
							importDiscipline.ComponentID = components[k].ID;
							importDiscipline.ItemName = components[k].Name;

							listDictDisciplineNamesAll.Add(curTempDiscID, importDiscipline);
							listDictDisciplineNamesImportCheckBox.Add(curTempDiscID, importDiscipline);

							curTempDiscID--;
						}
					}
				}
			}
		}

		#endregion /***** Populate Combo Boxes *****/

		#region /***** Validate Data *****/

		public void ValidateGridData()
		{
			try
			{
				GridFinishEditing();
				ResetErrorCount();

				//mam 07072011 - get a list of the visible criticality columns
				ArrayList arrayListVisibleCrits = new ArrayList();
				for (int i = 0; i < arrayListCriticalities.Count; i++)
				{
					//all crit columns will be visible, regardless of whether the columns was found in the Excel file
					//	so don't check the .ColumnIndex
					//if (((CriticalityForImport)arrayListCriticalities[i]).ColumnIndex > -1)
					{
						arrayListVisibleCrits.Add(i + 1);
					}
				}
				//</mam>

				//				int errorCountFac = 0;
				//				int errorCountProc = 0;
				//				int errorCountComp = 0;
				//				int errorCountCompPN = 0;
				//				int errorCountDisc = 0;

				CellRange cellRange = new CellRange();

				//facility grid
				for (int i = c1FlexGridFacility.Rows.Fixed; i < c1FlexGridFacility.Rows.Count; i++)
				{
					if (!(bool)c1FlexGridFacility[i, "Import"])
					{
						for (int j = c1FlexGridFacility.Cols.Fixed; j < c1FlexGridFacility.Cols.Count; j++)
						{
							cellRange = c1FlexGridFacility.GetCellRange(i, j);
							//mam 07072011 - added "DontImportDefaultValue"
							if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
							{
								cellRange.Style = c1FlexGridFacility.Styles["Valid"];
							}
							cellRange.UserData = string.Empty;
						}
						continue;
					}
					ValidateGridDataCheckLength(c1FlexGridFacility, i, "FacilityName", 1, 255, false);

					//mam 03202012 - check whether facility name already exists
					ValidateGridDataDuplicateName(c1FlexGridFacility, i, "FacilityName", "Facility", false);

					ValidateGridDataCheckYear(c1FlexGridFacility, i, "FacilityCurrentYear", false, false);

					//mam 03202012 - change fac crit range from 0.1-1.0 to 0.01-100
					//mam 01222012
					//ValidateGridDataCheckValue(c1FlexGridFacility, i, "FacilityCriticality", 0.1, 1.0, false, true, true, false);
					ValidateGridDataCheckValue(c1FlexGridFacility, i, "FacilityCriticality", 0.01, 100.0, false, true, true, false);

					ValidateGridDataCombo(c1FlexGridFacility, i, "CustomENRTable", true, false);
				}

				errorCountFac = errorCount;

				//process grid
				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					if (!(bool)c1FlexGridProcess[i, "Import"])
					{
						for (int j = c1FlexGridProcess.Cols.Fixed; j < c1FlexGridProcess.Cols.Count; j++)
						{
							cellRange = c1FlexGridProcess.GetCellRange(i, j);
							//mam 07072011 - added "DontImportDefaultValue"
							if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
							{
								cellRange.Style = c1FlexGridProcess.Styles["Valid"];
							}
							cellRange.UserData = string.Empty;
						}
						continue;
					}
					ValidateGridDataCheckLength(c1FlexGridProcess, i, "ProcessName", 1, 255, false);
					ValidateGridDataCombo(c1FlexGridProcess, i, "FacilityName", true, false);
				}

				SetProcessPropertyFacilityID();

				//mam 03202012 - check whether process name already exists
				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					ValidateGridDataDuplicateName(c1FlexGridProcess, i, "ProcessName", "Process", false);
				}

				errorCountProc = errorCount - errorCountFac;

				//component grid - MSC
				for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
				{
					if (!(bool)c1FlexGridComponent[i, "Import"])
					{
						for (int j = c1FlexGridComponent.Cols.Fixed; j < c1FlexGridComponent.Cols.Count; j++)
						{
							cellRange = c1FlexGridComponent.GetCellRange(i, j);
							//mam 07072011 - added "DontImportDefaultValue"
							if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
							{
								//mam 07072011
								if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
								{
									//return;
								}
								else
								{
									cellRange.Style = c1FlexGridComponent.Styles["Valid"];
									cellRange.UserData = string.Empty;
								}
							}
							//cellRange.UserData = string.Empty;
						}
						continue;
					}
					ValidateGridDataCheckLength(c1FlexGridComponent, i, "ComponentName", 1, 255, false);
					ValidateGridDataCombo(c1FlexGridComponent, i, "FacilityName", true, false);
					ValidateGridDataCombo(c1FlexGridComponent, i, "ProcessName", true, false);
					ValidateGridDataCombo(c1FlexGridComponent, i, "ComponentType", true, false);
					ValidateGridDataCombo(c1FlexGridComponent, i, "LOS", true, false);

					//mam 07072011
					//ValidateGridDataCheckValue(c1FlexGridComponent, i, "RedundantAssets", 1, 9999, true, false, true, false);
					ValidateSingleCell(c1FlexGridComponent, i, "RedundantAssets", false);

					//mam 07072011
					ValidateGridDataCombo(c1FlexGridComponent, i, "CipPlanningMode", true, false);
					//ValidateGridDataCheckLength(c1FlexGridComponent, i, "AssetClass", 0, 20, false);
					ValidateSingleCell(c1FlexGridComponent, i, "AssetClass", false);

					//mam 07072011 - validate the visible crit columns
					for (int j = 0; j < arrayListVisibleCrits.Count; j++)
					{
						ValidateGridDataCombo(c1FlexGridComponent, i, "Crit" + arrayListVisibleCrits[j].ToString(), true, false);
					}

					//mam 07072011 - no longer using four fixed crits
					//ValidateGridDataCombo(c1FlexGridComponent, i, "CritPublic", true);
					//ValidateGridDataCombo(c1FlexGridComponent, i, "CritEnvironment", true);
					//ValidateGridDataCombo(c1FlexGridComponent, i, "CritRepair", true);
					//ValidateGridDataCombo(c1FlexGridComponent, i, "CritEffect", true);

					ValidateGridDataCheckValue(c1FlexGridComponent, i, "Vulnerability", 0, 0.9999, true, true, true, false);
				}

				SetComponentPropertyProcessID(c1FlexGridComponent);

				//mam 03202012 - check whether component name already exists
				for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
				{
					ValidateGridDataDuplicateName(c1FlexGridComponent, i, "ComponentName", "Component", false);
				}

				errorCountComp = errorCount - errorCountFac - errorCountProc;

				//component grid - PN
				for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
				{
					if (!(bool)c1FlexGridComponentPN[i, "Import"])
					{
						for (int j = c1FlexGridComponentPN.Cols.Fixed; j < c1FlexGridComponentPN.Cols.Count; j++)
						{
							cellRange = c1FlexGridComponentPN.GetCellRange(i, j);
							//mam 07072011 - added "DontImportDefaultValue"
							if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
							{
								cellRange.Style = c1FlexGridComponentPN.Styles["Valid"];
							}
							cellRange.UserData = string.Empty;
						}
						continue;
					}
					ValidateGridDataCheckLength(c1FlexGridComponentPN, i, "ComponentName", 1, 255, false);
					ValidateGridDataCombo(c1FlexGridComponentPN, i, "FacilityName", true, false);
					ValidateGridDataCombo(c1FlexGridComponentPN, i, "ProcessName", true, false);
					ValidateGridDataCombo(c1FlexGridComponentPN, i, "ComponentType", true, false);
				}

				SetComponentPropertyProcessID(c1FlexGridComponentPN);

				//mam 03202012 - check whether component name already exists
				for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
				{
					ValidateGridDataDuplicateName(c1FlexGridComponentPN, i, "ComponentName", "Component", false);
				}

				errorCountCompPN = errorCount - errorCountFac - errorCountProc - errorCountComp;

				//discipline grid
				for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
				{
					if (!(bool)c1FlexGridDiscipline[i, "Import"])
					{
						for (int j = c1FlexGridDiscipline.Cols.Fixed; j < c1FlexGridDiscipline.Cols.Count; j++)
						{
							cellRange = c1FlexGridDiscipline.GetCellRange(i, j);
							//mam 07072011 - added "DontImportDefaultValue"
							if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
							{
								//mam 07072011
								if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
								{
									//continue;
								}
								else
								{
									cellRange.Style = c1FlexGridDiscipline.Styles["Valid"];
									cellRange.UserData = string.Empty;
								}
							}
							//cellRange.UserData = string.Empty;
						}
						continue;
					}
					//ValidateGridDataCheckLength(c1FlexGridDiscipline, i, "AssessedBy", 0, 255, false);
					////ValidateGridDataCombo(c1FlexGridDiscipline, i, "FacilityName", true);
					////ValidateGridDataCombo(c1FlexGridDiscipline, i, "ProcessName", true);
					ValidateGridDataCombo(c1FlexGridDiscipline, i, "ComponentName", true, false);
					ValidateGridDataCombo(c1FlexGridDiscipline, i, "DisciplineType", true, false);
					//ValidateGridDataCombo(c1FlexGridDiscipline, i, "LOS", true);
					ValidateGridDataCombo(c1FlexGridDiscipline, i, "Condition", true, false);

					ValidateSingleCell(c1FlexGridDiscipline, i, "AssessedBy", false);

					ValidateSingleCell(c1FlexGridDiscipline, i, "AcquisitionCost", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "CurrentValue", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabCost", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabCostYear", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabInterval", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabYearLast", false);

					//mam 01222012
					//ValidateSingleCell(c1FlexGridDiscipline, i, "RehabNext", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabYearNext", false);

					ValidateSingleCell(c1FlexGridDiscipline, i, "RepairCost", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "ReplacementValue", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "SalvageValue", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "AnnualMaintCost", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "ReplacementValueYear", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "NextReplacementYear", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "InstallationYear", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "InspectionDate", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "OriginalUsefulLife", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "EquipmentIDNumber", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "AssessedBy", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "Manufacturer", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RunHours", false);

					//mam 01222012
					ValidateSingleCell(c1FlexGridDiscipline, i, "ReplacementValueDesc", false);
					ValidateSingleCell(c1FlexGridDiscipline, i, "RehabCostDesc", false);

					//the following calls are replaced by ValidateSingleCell, directly above
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "AcquisitionCost", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "CurrentValue", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "RehabCost", 0, currencyMax, true, true, false);

					//mam 07072011
					//ValidateGridDataCheckYear(c1FlexGridDiscipline, i, "RehabCostYear", true);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "RehabInterval", 0, 100, true, true, true);
					//ValidateGridDataCheckYear(c1FlexGridDiscipline, i, "RehabYearLast", true);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "RehabNext", 0, 100, true, true, true);

					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "RepairCost", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "ReplacementValue", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "SalvageValue", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "AnnualMaintCost", 0, currencyMax, true, true, false);
					//ValidateGridDataCheckYear(c1FlexGridDiscipline, i, "ReplacementValueYear", true);

					//mam 07072011
					//ValidateGridDataCheckYear(c1FlexGridDiscipline, i, "NextReplacementYear", true);

					//ValidateGridDataCheckYear(c1FlexGridDiscipline, i, "InstallationYear", true);
					//ValidateGridDataCheckDate(c1FlexGridDiscipline, i, "InspectionDate", true);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "OriginalUsefulLife", 0, 9999, true, false, true);
					//ValidateGridDataCheckLength(c1FlexGridDiscipline, i, "EquipmentIDNumber", 0, 255);
					//ValidateGridDataCheckLength(c1FlexGridDiscipline, i, "AssessedBy", 0, 255);
					//ValidateGridDataCheckLength(c1FlexGridDiscipline, i, "Manufacturer", 0, 255);
					//ValidateGridDataCheckValue(c1FlexGridDiscipline, i, "RunHours", 0, Int16.MaxValue, true, false, false);
				}
				ValidateGridDataCheckDupDiscType();

				errorCountDisc = errorCount - errorCountFac - errorCountProc - errorCountComp - errorCountCompPN;

				labelErrorCount.Text = errorCount.ToString();
				labelErrorCountFac.Text = errorCountFac.ToString();
				labelErrorCountProc.Text = errorCountProc.ToString();
				labelErrorCountComp.Text = errorCountComp.ToString();
				labelErrorCountCompPN.Text = errorCountCompPN.ToString();
				labelErrorCountDisc.Text = errorCountDisc.ToString();

				//set visibility of error tip controls
				SetErrorTipVisibility();
			}
			catch
			{
				errorCount++;
				labelErrorCount.Text = errorCount.ToString();
			}
		}

		private void ValidateSingleCell(C1FlexGrid grid, int rowNumber, string fieldName, bool afterUserEdit)
		{
			switch (fieldName)
			{
				case "AcquisitionCost":
				case "CurrentValue":
				case "RehabCost":
				case "RepairCost":
				case "ReplacementValue":
				case "SalvageValue":
				case "AnnualMaintCost":
				{
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0, currencyMax, true, true, false, afterUserEdit);
					break;
				}

				case "RehabInterval":
				//mam 01222012
				//case "RehabNext":
				{
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0, 100, true, true, true, afterUserEdit);
					break;
				}

				case "RehabCostYear":
				//mam 01222012
				//case "RehabYearLast":
				case "ReplacementValueYear":
				//mam 01222012
				//case "NextReplacementYear":
				{
					ValidateGridDataCheckYear(grid, rowNumber, fieldName, true, afterUserEdit);
					break;
				}

				case "InstallationYear":
				case "FacilityCurrentYear":
				//mam 01222012
				case "RehabYearLast":
				{
					ValidateGridDataCheckYear(grid, rowNumber, fieldName, false, afterUserEdit);
					break;
				}

				//mam 01222012
				case "FacilityCriticality":
				{
					//mam 03202012 - change fac crit range from 0.1-1.0 to 0.01-100
					//ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0.1, 1.0, false, true, true, afterUserEdit);
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0.01, 100.0, false, true, true, afterUserEdit);
					break;
				}

				//mam 01222012
				case "RehabYearNext":
				{
					if (grid[rowNumber, "RehabYearNext"] != null)
					{
						string nextYear = grid.GetData(rowNumber, "RehabYearNext").ToString().Trim();
						ValidateNextRehabYear(grid, rowNumber, "", fieldName, nextYear, afterUserEdit);
					}
					break;
				}

				//mam 01222012
				case "NextReplacementYear":
				{
					if (grid[rowNumber, "NextReplacementYear"] != null)
					{
						string nextYear = grid.GetData(rowNumber, "NextReplacementYear").ToString().Trim();
						ValidateNextRehabYear(grid, rowNumber, "", fieldName, nextYear, afterUserEdit);
					}
					break;
				}

				case "InspectionDate":
				{
					ValidateGridDataCheckDate(grid, rowNumber, "InspectionDate", false, afterUserEdit);
					break;
				}
				case "OriginalUsefulLife":
				{
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0, 9999, false, false, true, afterUserEdit);
					break;
				}
				case "EquipmentIDNumber":
				case "AssessedBy":
				case "Manufacturer":
				{
					ValidateGridDataCheckLength(grid, rowNumber, fieldName, 0, 255, afterUserEdit);
					break;
				}
				case "AssetClass":
				{
					ValidateGridDataCheckLength(grid, rowNumber, fieldName, 0, 20, afterUserEdit);
					break;
				}
				case "RunHours":
				{
					//mam 10112014 - changed from Int16.MaxValue (32767) to Int32.MaxValue (2,147,483,647) 
					//	to allow Mechanical Discipline run hours to exceed 32767 when validating data in the import grid
					//	(access the import grid by clicking File > Import > ImportFromExcelFile... in the menu)
					//ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0, Int16.MaxValue, true, false, false, afterUserEdit);
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 0, Int32.MaxValue, true, false, false, afterUserEdit);
					break;
				}
				case "Condition":
				case "LOS":
				case "CipPlanningMode":
				{
					ValidateGridDataCombo(grid, rowNumber, fieldName, true, afterUserEdit);
					break;
				}
				case "RunningAtInspection":
				{
					//the user can only click the checkbox, so there is no data to validate; just set the style to "Valid"
					CellRange cellRange = c1FlexGridDiscipline.GetCellRange(rowNumber, c1FlexGridDiscipline.Cols[fieldName].Index);
					cellRange.Style = c1FlexGridDiscipline.Styles["Valid"];
					cellRange.UserData = string.Empty;
					break;
				}
				case "Crit1":
				case "Crit2":
				case "Crit3":
				case "Crit4":
				case "Crit5":
				case "Crit6":
				{
					ValidateGridDataCombo(grid, rowNumber, fieldName, true, afterUserEdit);
					break;
				}
				case "RedundantAssets":
				{
					ValidateGridDataCheckValue(grid, rowNumber, fieldName, 1, 9999, true, false, true, afterUserEdit);
					break;
				}
				case "Comments":

				//mam 01222012
				case "ReplacementValueDesc":
				case "RehabCostDesc":

				{
					//not necessary to check comments or description fields for length or content
					break;
				}
				case "Retired":
				case "Vulnerability":
				{
					//these fields do not require validation
					break;
				}
				default:
				{
					//MessageBox.Show("Field name " + fieldName + " not found in ValidateSingleCell");
					break;
				}
			}
		}

		//mam 01222012
		//C1FlexGrid grid, int i, string fieldName, double minValue, double maxValue, bool allowNull, bool allowDecimals, bool showMaxValue, bool singleCell
		private void ValidateNextRehabYear(C1FlexGrid grid, int rowNumber, string facilityYear, string fieldName, string fieldValue, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(rowNumber, grid.Cols[fieldName].Index);
			string nextYear = fieldValue.Trim();
			facilityYear = facilityYear.Trim();

			try
			{
				//string errorTip = "Enter a four-digit year \r\nCell can be blank";
				string errorTip = "Enter a four-digit year >= Facility Current Year \r\nCell can be blank";

				if (nextYear == null || nextYear.Length == 0)
				{
					if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
					{
						if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue" && singleCell)
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
						else
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
					}
					return;
				}

				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}
				}

				//set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style != null && cellRange.Style.Name.IndexOf("Dont") == -1)
				{
					cellRange.Style = grid.Styles["DefaultValue"];
				}

				//next rehab year must be four digits
				if (nextYear.Length != 4)				
				{
					SetError(grid, cellRange, errorTip);
					return;
				}

				//facility current year and next rehab year must be four digits
				//facility current year can't be zero or blank
				//if (facilityYear.Length > 0 && facilityYear.Length != 4)			
				//{
				//	errorTip += "\r\n\r\nFacility Year must be four digits";
				//}

				//check whether value is 4 numbers
				if (nextYear.Length == 4)
				{
					Regex regex = new Regex("[1-9][0-9][0-9][0-9]");
					Match match = regex.Match(nextYear);
					if (!match.Success)
					{
						SetError(grid, cellRange, errorTip);
						return;
					}
				}

				//next year is a four-digit number
				//next year must be >= facility year
				//int facYear = 0;
				try
				{
					ImportFromTextFileComponent component = (ImportFromTextFileComponent)grid[rowNumber, "ComponentName"];
					int facYear = (int)GetFacilityYearFromComponent(component);
					int year = int.Parse(nextYear);

					if (year < facYear)
					{
						errorTip = "Must be >= Facility Current Year \r\nCell can be blank";

						//mam 01222012 - show all constraints
						errorTip += "\r\n\r\nInstallation Year <= Last Rehabilitation Year <= Inspection Year <= Facility Current Year <= Next Replacement Year and Next Rehabilitation Year";

						SetError(grid, cellRange, errorTip);
						return;
					}
				}
				catch
				{
				}

				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				//errorCount++;
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		private void ValidateGridDataCheckDupDiscType()
		{
			C1FlexGrid grid = c1FlexGridDiscipline;
			//loop through the grid rows to determine if any component has more than one of the same discipline type
			for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
			{
				try
				{
					CellRange cellRangeCompName = grid.GetCellRange(i, grid.Cols["ComponentName"].Index);
					CellRange cellRangeDiscType = grid.GetCellRange(i, grid.Cols["DisciplineType"].Index);
					string errorTip = "This Component already has a Discipline of type " + cellRangeDiscType.DataDisplay.ToString();

					//if the component column is not of type ImportFromTextFileComponent, don't check it, because it will
					//	have been marked as having in error in earlier validation code
					if (cellRangeCompName.Data == null || cellRangeCompName.Data.GetType() != typeof(ImportFromTextFileComponent))
					{
						continue;
					}

					//if we're not importing the current row, continue with the next row
					if (!Convert.ToBoolean(grid.Rows[i]["Import"]))
					{
						continue;
					}

					//get component info for the current row
					ImportFromTextFileComponent component = (ImportFromTextFileComponent)grid.GetData(i, "ComponentName");
					int curCompTempID = component.TempID;
					int curDiscTypeID = Convert.ToInt32(grid[i, "DisciplineType"]);

					for (int rowToCheck = i + 1; rowToCheck < grid.Rows.Count; rowToCheck++)
					{
						try
						{
							//get cell ranges for row to check
							CellRange cellRangeCompNameToCheck = grid.GetCellRange(rowToCheck, grid.Cols["ComponentName"].Index);
							CellRange cellRangeDiscTypeToCheck = grid.GetCellRange(rowToCheck, grid.Cols["DisciplineType"].Index);

							//if the component column is not of type ImportFromTextFileComponent, don't check it, because it will
							//	have been marked as having in error in earlier validation code
							if (cellRangeCompNameToCheck.Data.GetType() != typeof(ImportFromTextFileComponent))
							{
								continue;
							}

							//if we're not importing the current row, continue with the next row
							if (!Convert.ToBoolean(grid.Rows[rowToCheck]["Import"]))
							{
								continue;
							}

							//get the component from the row to check
							component = (ImportFromTextFileComponent)grid.GetData(rowToCheck, "ComponentName");
							//if (!component.ImportThisItem)
							//{
							//	continue;
							//}

							if (component.TempID == curCompTempID 
								&& Convert.ToInt32(grid[rowToCheck, "DisciplineType"]) == curDiscTypeID)
							{
								//a row with the same component and disc type already exists
								SetError(grid, cellRangeDiscTypeToCheck, errorTip);
							}
						}
						catch
						{
							errorCountUnknownError++;
							if (grid != null)
							{
								CellRange cellRange = grid.GetCellRange(rowToCheck, grid.Cols["DisciplineType"].Index);
								SetError(grid, cellRange, "Unknown error");
							}
						}
					}
				}
				catch
				{
					errorCountUnknownError++;
					if (grid != null)
					{
						CellRange cellRange = grid.GetCellRange(i, grid.Cols["DisciplineType"].Index);
						SetError(grid, cellRange, "Unknown error");
						return;
					}
				}
			}
		}

		//mam 07072011 - added singlecell
		private void ValidateGridDataCheckValue(C1FlexGrid grid, int i, string fieldName, 
			double minValue, double maxValue, bool allowNull, bool allowDecimals, bool showMaxValue, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);

			//set the error tip
			//string errorTip = "Min value = " + minValue.ToString() + "; max value = " + maxValue.ToString();
			string errorTip = "Min value = " + minValue.ToString();
			if (showMaxValue)
			{
				errorTip += "; max value = " + (maxValue == currencyMax ? string.Format("{0:N0}", maxValue) : maxValue.ToString());
			}

			if (allowDecimals)
			{
				errorTip += "\r\nDecimals allowed";
			}
			else
			{
				errorTip += "\r\nNo decimals";
			}

			if (allowNull)
			{
				errorTip += "\r\nCell can be blank";
			}
			else
			{
				errorTip += "\r\nCell must contain a value";
			}
			//

			try
			{
				if (allowNull && (grid[i, fieldName] == null || grid[i, fieldName].ToString().Length == 0))
				{
					//mam 07072011 - added "DontImportDefaultValue"
					if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
					{
						if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue" && singleCell)
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
						else
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
					}
					//cellRange.UserData = string.Empty;
					return;
				}

				//cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);
				//cellRange.Data = grid.Editor;
				//string curValueString = grid[i, fieldName].ToString();
				string curValueString = grid[i, fieldName] == null? "": grid[i, fieldName].ToString();
				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}

				}
				//cellRange.UserData = string.Empty;

				//mam 07072011 - set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				//if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0)
				if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style != null && cellRange.Style.Name.IndexOf("Dont") == -1)
				{
					cellRange.Style = grid.Styles["DefaultValue"];
				}

				//mam 07072011
				if (fieldName == "OriginalUsefulLife" && curValueString.Length == 0)
				{
					//original useful life cannot be blank
					SetError(grid, cellRange, errorTip);
					return;
				}

				//check floating point number:  ^-?\d*(\.\d+)?$
				//check floating point number:  ^(\-)?\d*(\.\d+)?$  (allows empty string)
				//check floating point number:  ^(((\d{1,3})(,\d{3})*)|(\d+))(.\d+)?$
				//check non-zero integer:  ^[0-9]*[1-9]+$|^[1-9]+[0-9]*$

				string numberOfDecimals = "0,20";
				if (!allowDecimals)
				{
					numberOfDecimals = "0";
				}
				//check whether the value is a number, with or without decimals, commas, or dollar signs
				//string patternToMatch = @"^\$?(\d{1,3}(\,\d{3})*|(\d+))(\.\d{" + numberOfDecimals + "})?$";
				//Regex regex = new Regex(@patternToMatch);
				Regex regex = new Regex(@"^\$?(\d{1,3}(\,\d{3})*|(\d+)|(\d{0}))(\.\d{" + numberOfDecimals + "})?$");
				Match match = regex.Match(curValueString);
				if (!match.Success)
				{
					SetError(grid, cellRange, errorTip);
					return;
				}

				//the value is a number with or without decimals
				try
				{
					decimal curValueDecimal = decimal.Parse(curValueString, System.Globalization.NumberStyles.Currency);
					if (curValueDecimal < (decimal)minValue)
					{
						//if we're not showing a max value, let the user know that the value is too small
						if (!showMaxValue)
						{
							errorTip += "\r\nThe value you have entered is too small";
						}
						SetError(grid, cellRange, errorTip);

						//mam 07072011
						return;
					}
					if (curValueDecimal > (decimal)maxValue)
					{
						//if we're not showing a max value, let the user know that the value is too large
						if (!showMaxValue)
						{
							errorTip += "\r\nThe value you have entered is too large";
						}
						SetError(grid, cellRange, errorTip);

						//mam 07072011
						return;
					}

					//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
					if (singleCell)
					{
						//the user has changed the data, and the data is valid
						//if the cell style contains DontImport, don't change the cell style, but do set userdata = ""
						if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
						{
							cellRange.Style = grid.Styles["DontImport"];
						}
						else
						{
							cellRange.Style = grid.Styles["Valid"];
						}
						cellRange.UserData = string.Empty;
					}
				}
				catch
				{
					SetError(grid, cellRange, errorTip);
					return;
				}
			}
			catch
			{
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		//mam 03202012
		private void ValidateGridDataDuplicateName(C1FlexGrid grid, int i, string fieldName, string fieldType, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);
			string curValueString = grid[i, fieldName] == null? "": grid[i, fieldName].ToString();

			if (curValueString == "")
			{
				//if the name is blank, get out, as there is nothing to check
				//(the name has already been checked for length/nullity in ValidateGridDataCheckLength)
				return;
			}

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendFormat("This {0} Name already exists in WAM.", fieldType);
			stringBuilder.Append(Environment.NewLine + Environment.NewLine);
			stringBuilder.Append("Change the name, or");
			stringBuilder.AppendFormat(Environment.NewLine + Environment.NewLine + "Click 'Rename Existing' to allow WAM to rename the existing {0}", fieldType);
			stringBuilder.AppendFormat(" (by appending  '{0}'  to the existing {1} name).", renameExistingAppendage, fieldType);

			string errorTip = stringBuilder.ToString();

			CellRange cellRangeCheckBox = new CellRange();
			int renameColIndex = 0;

			try
			{
				if (fieldName == "FacilityName")
				{
					renameColIndex = grid.Cols["RenameExistingFacility"].Index;
					cellRangeCheckBox = grid.GetCellRange(i, renameColIndex);

					Facility[] facilities = CacheManager.GetFacilities(infoSetID);
					for (int x = 0; x < facilities.Length; x++)
					{
						if (string.Compare(facilities[x].Name.Trim(), curValueString.Trim(), true) == 0)
						{
							//the facility name matches an existing facility name

							//if the checkbox is not true or false, set it to false so it will be picked up as false in the summary tab
							if (grid[i, renameColIndex] == null)
							{
								grid.SetCellCheck(i, renameColIndex, CheckEnum.Unchecked);
							}

							if (!(bool)grid[i, renameColIndex])
							{
								//the rename existing checkbox is not checked
								SetError(grid, cellRange, errorTip);
							}

							cellRangeCheckBox.Style = grid.Styles["Valid"];
							cellRangeCheckBox.Style.Display = DisplayEnum.Overlay;

							return;
						}
					}

					//there is no match between the import grid facility name and an existing facility name
					//hide the RenameExistingFacility checkbox
					cellRangeCheckBox.Style = grid.Styles["CheckBoxHide"];
					cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
					grid[i, renameColIndex] = null;

					//check if there is a matching name in the facility import grid
					stringBuilder = new StringBuilder();
					stringBuilder.AppendFormat("This {0} Name already exists in this grid.", fieldType);
					stringBuilder.Append(Environment.NewLine + Environment.NewLine);
					stringBuilder.AppendFormat("Please change the {0} Name.", fieldType);
					errorTip = stringBuilder.ToString();

					int dupCount = 0;
					IDictionaryEnumerator idEnumerator = listDictFacilityNames.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						//if the text in the grid matches either the factor score or the factor text, set the grid text to the list dictionary key
						if (string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
						{
							dupCount++;
							if (dupCount > 1)
							{
								SetError(grid, cellRange, errorTip);
								break;
							}
						}
					}

					return;
				}

				else if (fieldName == "ProcessName")
				{
					//get the facility from the facility combo in this row in the process grid
					//if that facility has a non-zero existing id, get the processes for that id

					renameColIndex = grid.Cols["RenameExistingProcess"].Index;
					cellRangeCheckBox = grid.GetCellRange(i, renameColIndex);

					int tempID = Convert.ToInt32(c1FlexGridProcess[i, "TempID"]);
					int facilityId = ((ImportFromTextFileProcess)listDictProcessNames[tempID]).FacilityID;

					if (facilityId > 0)
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(infoSetID, facilityId);
						for (int x = 0; x < processes.Length; x++)
						{
							if (string.Compare(processes[x].Name.Trim(), curValueString.Trim(), true) == 0)
							{
								//the process name matches an existing process name

								//if the checkbox is not true or false, set it to false so it will be picked up as false in the summary tab
								if (grid[i, renameColIndex] == null)
								{
									grid.SetCellCheck(i, renameColIndex, CheckEnum.Unchecked);
								}

								if (!(bool)grid[i, "RenameExistingProcess"])
								{
									//the rename existing checkbox is not checked
									SetError(grid, cellRange, errorTip);
								}

								cellRangeCheckBox.Style = grid.Styles["Valid"];
								cellRangeCheckBox.Style.Display = DisplayEnum.Overlay;

								return;
							}
						}

						//there is no match between the import grid process name and an existing process name
						//hide the RenameExistingProcess checkbox
						cellRangeCheckBox.Style = grid.Styles["CheckBoxHide"];
						cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
						grid[i, renameColIndex] = null;
					}

					if (facilityId != 0)
					{
						stringBuilder = new StringBuilder();
						stringBuilder.AppendFormat("This {0} Name already exists in this grid for this Facility.", fieldType);
						stringBuilder.Append(Environment.NewLine + Environment.NewLine);
						stringBuilder.AppendFormat("Please change the {0} Name.", fieldType);
						errorTip = stringBuilder.ToString();

						int dupCount = 0;
						IDictionaryEnumerator idEnumerator = listDictProcessNames.GetEnumerator();
						while (idEnumerator.MoveNext())
						{
							if (facilityId == ((ImportFromTextFileProcess)idEnumerator.Value).FacilityID 
								&& string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
							{
								dupCount++;
								if (dupCount > 1)
								{
									SetError(grid, cellRange, errorTip);
									break;
								}
							}
						}

						return;
					}
				}

				else if (fieldName == "ComponentName")
				{
					renameColIndex = grid.Cols["RenameExistingComponent"].Index;
					cellRangeCheckBox = grid.GetCellRange(i, renameColIndex);

					int tempID = Convert.ToInt32(grid[i, "TempID"]);
					int processId = ((ImportFromTextFileComponent)listDictComponentNames[tempID]).ProcessID;

					if (processId > 0)
					{
						MajorComponent[] components = CacheManager.GetComponents(infoSetID, processId);
						for (int x = 0; x < components.Length; x++)
						{
							if (string.Compare(components[x].Name.Trim(), curValueString.Trim(), true) == 0)
							{
								//the component name matches an existing component name

								//if the checkbox is not true or false, set it to false so it will be picked up as false in the summary tab
								if (grid[i, renameColIndex] == null)
								{
									grid.SetCellCheck(i, renameColIndex, CheckEnum.Unchecked);
								}

								if (!(bool)grid[i, "RenameExistingComponent"])
								{
									//the rename existing checkbox is not checked
									SetError(grid, cellRange, errorTip);
								}

								cellRangeCheckBox.Style = grid.Styles["Valid"];
								cellRangeCheckBox.Style.Display = DisplayEnum.Overlay;

								return;
							}
						}

						//there is no match between the import grid component name and an existing component name
						//hide the RenameExistingComponent checkbox
						cellRangeCheckBox.Style = grid.Styles["CheckBoxHide"];
						cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
						grid[i, renameColIndex] = null;
					}

					if (processId != 0)
					{
						stringBuilder = new StringBuilder();
						stringBuilder.AppendFormat("This {0} Name already exists in this grid for this Process.", fieldType);
						stringBuilder.Append(Environment.NewLine + Environment.NewLine);
						stringBuilder.AppendFormat("Please change the {0} Name.", fieldType);
						errorTip = stringBuilder.ToString();

						int dupCount = 0;
						IDictionaryEnumerator idEnumerator = listDictComponentNames.GetEnumerator();
						while (idEnumerator.MoveNext())
						{
							if (processId == ((ImportFromTextFileComponent)idEnumerator.Value).ProcessID
								&& string.Compare(curValueString, idEnumerator.Value.ToString(), true) == 0)
							{
								dupCount++;
								if (dupCount > 1)
								{
									SetError(grid, cellRange, errorTip);
									break;
								}
							}
						}

						return;
					}
				}

				//since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		private void ValidateGridDataCheckLength(C1FlexGrid grid, int i, string fieldName, int minLength, int maxLength, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);
			string errorTip = "Minimum length = " + minLength.ToString() + "; maximum length = " + maxLength.ToString();

			try
			{
				string curValueString = grid[i, fieldName] == null? "": grid[i, fieldName].ToString();
				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					//mam 07072011
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}
				}
				//cellRange.UserData = string.Empty;
				if (curValueString.Length < minLength || curValueString.Length > maxLength)
				{
					SetError(grid, cellRange, errorTip);

					//mam 07072011 - added return
					return;
				}

				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				//errorCount++;
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		//mam 07072011
		private string ValidateGridDataCheckTextForSingleQuote(C1FlexGrid grid, int i, string fieldName, string textToCheck)
		{
			//remove single quotes from text
			string removeQuotes = textToCheck.Replace("'", "");
			return removeQuotes;
		}

		private void ValidateGridDataCheckYear(C1FlexGrid grid, int i, string fieldName, bool allowNull, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);

			try
			{
				string errorTip = "Enter a four-digit year";

				if (fieldName != "FacilityCurrentYear" && fieldName != "InstallationYear"
					//mam 01222012
					&& fieldName != "RehabYearLast")
				{
					errorTip += " or a zero";
				}

				if (allowNull)
				{
					errorTip += "\r\nCell can be blank";
				}
				else
				{
					errorTip += "\r\nCell must contain a value";
				}

				//mam 01222012
				if (fieldName == "InstallationYear")
				{
					errorTip += "\r\n\r\nMust be <= Last Rehabilitation Year";

					//mam 01222012 - show all constraints
					errorTip += "\r\n\r\nInstallation Year <= Last Rehabilitation Year <= Inspection Year <= Facility Current Year <= Next Replacement Year and Next Rehabilitation Year";
				}

				//mam 01222012
				if (fieldName == "RehabYearLast")
				{
					errorTip += "\r\n\r\nMust be >= Installation Year";
					errorTip += "\r\nMust be <= Inspection Year";

					//mam 01222012 - show all constraints
					errorTip += "\r\n\r\nInstallation Year <= Last Rehabilitation Year <= Inspection Year <= Facility Current Year <= Next Replacement Year and Next Rehabilitation Year";
				}

				if (allowNull && (grid[i, fieldName] == null || grid[i, fieldName].ToString().Length == 0))
				{
					//mam 07072011 - added "DontImportDefaultValue"
					if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
					{
						if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue" && singleCell)
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
						else
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
					}
					//cellRange.UserData = string.Empty;
					return;
				}

				//cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);
				//string curValueString = grid[i, fieldName].ToString();
				string curValueString = grid[i, fieldName] == null? "": grid[i, fieldName].ToString();
				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}
				}
				//cellRange.UserData = string.Empty;

				//mam 07072011 - set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				//if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0)
				if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style != null && cellRange.Style.Name.IndexOf("Dont") == -1)
				{
					cellRange.Style = grid.Styles["DefaultValue"];
				}

				if ((fieldName == "FacilityCurrentYear" && curValueString.Length != 4)
					|| (fieldName == "InstallationYear" && curValueString.Length != 4)
					//mam 01222012
					|| (fieldName == "RehabYearLast" && curValueString.Length != 4))
				{
					//facility current year and installation year must be four digits
					//facility current year and installation year can't be zero or blank

					//mam 01222012
					//last rehab year must be four digits, not blank, not zero, >= installation year and <= inspection year

					SetError(grid, cellRange, errorTip);
					return;
				}

				if (curValueString == "0" || curValueString.Length == 0 || curValueString.Length == 4)
				{
					//other years must be blank, zero, or four digits
				}
				else
				{
					SetError(grid, cellRange, errorTip);
					return;
				}


				//if ((fieldName == "FacilityCurrentYear" && curValueString.Length == 4)
				//	|| (fieldName != "FacilityCurrentYear" && (curValueString == "0" || curValueString.Length == 0
				//	|| curValueString.Length == 4)))
				//{
				//}
				//else
				//{
				//	SetError(grid, cellRange, errorTip);
				//	return;
				//}

				//value is either blank, zero, or four characters - if four chars, verify that they are all numbers
				if (curValueString.Length == 4)
				{
					Regex regex = new Regex("[1-9][0-9][0-9][0-9]");
					Match match = regex.Match(curValueString);
					if (!match.Success)
					{
						SetError(grid, cellRange, errorTip);

						//mam 07072011 - added return
						return;
					}
				}

				//mam 01222012
				if (fieldName == "InstallationYear")
				{
					int lastRehabYear = 0;
					try
					{
						lastRehabYear = Convert.ToInt32(grid[i, "RehabYearLast"].ToString());
					}
					catch
					{
					}

					if (Convert.ToInt32(curValueString) > lastRehabYear)
					{
						SetError(grid, cellRange, errorTip);
						return;
					}
				}

				//mam 01222012
				if (fieldName == "RehabYearLast")
				{
					int installationYear = 0;
					try
					{
						installationYear = Convert.ToInt32(grid[i, "InstallationYear"].ToString());
					}
					catch
					{
					}

					int inspectionYear = 0;
					try
					{
						inspectionYear = Convert.ToDateTime(grid[i, "InspectionDate"].ToString()).Year;
					}
					catch
					{
					}

					int lastRehabYear = Convert.ToInt32(curValueString);
					if (lastRehabYear < installationYear || lastRehabYear > inspectionYear)
					{
						SetError(grid, cellRange, errorTip);
						return;
					}
				}


				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					//cellRange.Style = grid.Styles["Valid"];
					//cellRange.UserData = string.Empty;
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				//errorCount++;
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		private bool ValidateGridDataCheckDate(C1FlexGrid grid, int i, string fieldName, bool allowNull, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);
			bool errorThrown = false;
			try
			{
				if (allowNull && (grid[i, fieldName] == null || grid[i, fieldName].ToString().Length == 0))
				{
					//mam 07072011 - added "DontImportDefaultValue"
					if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
					{
						if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue" && singleCell)
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
						else
						{
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
						}
					}
					//cellRange.UserData = string.Empty;
					return true;
				}

				string curValueString = grid[i, fieldName] == null? "": grid[i, fieldName].ToString();
				int pos = curValueString.IndexOf(" ", 0);
				if (pos > -1)
				{
					curValueString = curValueString.Substring(0, pos);
				}
				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}
				}
				//cellRange.UserData = string.Empty;

				//mam 07072011 - set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				//if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0)
				if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style != null && cellRange.Style.Name.IndexOf("Dont") == -1)
				{
					cellRange.Style = grid.Styles["DefaultValue"];
				}

				if (fieldName == "InspectionDate" && curValueString.Length == 0)
				{
					//inspection date cannot be blank
					SetError(grid, cellRange, "Enter a date mm/dd/yyyy");
					return false;
				}

				//date (no time):
				Regex regex = new Regex(@"((^(10|12|0?[13578])([/])(3[01]|[12][0-9]|0?[1-9])([/])((1[8-9]\d{2})|([2-9]\d{3}))$)|(^(11|0?[469])([/])(30|[12][0-9]|0?[1-9])([/])((1[8-9]\d{2})|([2-9]\d{3}))$)|(^(0?2)([/])(2[0-8]|1[0-9]|0?[1-9])([/])((1[8-9]\d{2})|([2-9]\d{3}))$)|(^(0?2)([/])(29)([/])([2468][048]00)$)|(^(0?2)([/])(29)([/])([3579][26]00)$)|(^(0?2)([/])(29)([/])([1][89][0][48])$)|(^(0?2)([/])(29)([/])([2-9][0-9][0][48])$)|(^(0?2)([/])(29)([/])([1][89][2468][048])$)|(^(0?2)([/])(29)([/])([2-9][0-9][2468][048])$)|(^(0?2)([/])(29)([/])([1][89][13579][26])$)|(^(0?2)([/])(29)([/])([2-9][0-9][13579][26])$))");
				//date with time:
				//Regex regex = new Regex(@"(?n:^(?=\d)((?<day>31(?!(.0?[2469]|11))|30(?!.0?2)|29(?(.0?2)(?=.{3,4}(1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(16|[2468][048]|[3579][26])00))|0?[1-9]|1\d|2[0-8])(?<sep>[/.-])(?<month>0?[1-9]|1[012])\2(?<year>(1[6-9]|[2-9]\d)\d{2})(?:(?=\x20\d)\x20|$))?(?<time>((0?[1-9]|1[012])(:[0-5]\d){0,2}(?i:\[AP]M))|([01]\d|2[0-3])(:[0-5]\d){1,2})?$)");
				//Regex regex = new Regex(@"^(?=\d)(?:(?:31(?!.(?:0?[2469]|11))|(?:30|29)(?!.0?2)|29(?=.0?2.(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(?:\x20|$))|(?:2[0-8]|1\d|0?[1-9]))([-./])(?:1[012]|0?[1-9])\1(?:1[6-9]|[2-9]\d)?\d\d(?:(?=\x20\d)\x20|$))?(((0?[1-9]|1[012])(:[0-5]\d){0,2}(\x20[AP]M))|([01]\d|2[0-3])(:[0-5]\d){1,2})?$");
				Match match = regex.Match(curValueString);
				if (match.Success)
				{
					//cellRange.Data = curValueString.ToString("MM/dd/yyyy");
					DateTime dateTime = DateTime.Parse(curValueString);
					curValueString = dateTime.ToShortDateString();
					cellRange.Data = curValueString;
				}
				else
				{
					SetError(grid, cellRange, "Enter a date mm/dd/yyyy");
					return false;
				}

				//mam 01222012
				if (fieldName == "InspectionDate")
				{
					try
					{
						ImportFromTextFileComponent component = (ImportFromTextFileComponent)grid[i, "ComponentName"];
						int facYear = (int)GetFacilityYearFromComponent(component);

						//inspection date has already been verified above
						int year = DateTime.Parse(curValueString).Year;

						int lastRehabYear = 0;
						try
						{
							lastRehabYear = Convert.ToInt32(grid[i, "RehabYearLast"].ToString());
						}
						catch
						{
						}

						if (year > facYear || year < lastRehabYear)
						{
							string errorTip = "Must be <= Facility Current Year";
							errorTip += "\r\nMust be >= Last Rehabilitation Year";

							//mam 01222012 - show all constraints
							errorTip += "\r\n\r\nInstallation Year <= Last Rehabilitation Year <= Inspection Year <= Facility Current Year <= Next Replacement Year and Next Rehabilitation Year";

							SetError(grid, cellRange, errorTip);
							return false;
						}
					}
					catch
					{
					}
				}

				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					//cellRange.Style = grid.Styles["Valid"];
					//cellRange.UserData = string.Empty;
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}

				return true;
			}
			catch
			{
				//errorCount++;
				errorThrown = true;
				return false;
			}
			finally
			{
				errorCountUnknownError++;
				if (errorThrown && grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		//mam 07072011 - added int defaultValue
		private void ValidateGridRowWithDataMap(IDictionaryEnumerator idEnumerator, C1FlexGrid grid, CellRange cellRange, 
			int rowNumber, string curValueString, string fieldName, int minValue, int maxValue, bool useID, bool allowBlank, int defaultValue)
		{
			try
			{
				int curValueInt = -1;
				bool idFound = false;
				string valueToTest = "";
				string comboBoxValue = "";

				if ((cellRange.Data == null || cellRange.Data.ToString().Length == 0) && allowBlank)
				{
					return;
				}

				//mam 07072011 - set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				//if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0)
				if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style != null && cellRange.Style.Name.IndexOf("Dont") == -1)
				{
					cellRange.Style = grid.Styles["DefaultValue"];
				}

				//****************************************

				//mam 07072011 - if curValueString = "", the user has deleted the value from the grid cell - let the cell be blank
				if (curValueString == "")
				{
					SetError(grid, cellRange, errorTipCombo);
					return;
				}

				//mam 07072011
				//this portion is being used only by LOS
				if (curValueString == "" && defaultValue > -1)
				{
					//there is no value in the grid cell, so assign the default value to it
					while (idEnumerator.MoveNext())
					{
						if (Convert.ToInt32(idEnumerator.Key) == defaultValue)
						{
							grid.SetData(rowNumber, fieldName, defaultValue);
							idFound = true;

							//string caption = grid.Rows[grid.Rows.Fixed][fieldName].ToString();
							string caption = grid.Rows[0][fieldName].ToString();
							//caption = grid.Rows[1][fieldName].ToString();
							SetDefaultValue(grid, rowNumber, fieldName, "", "The " + caption + " has been set to its default value because it was left blank in the Excel file.");

							return;
						}
					}
				}

				//****************************************

				//if (cellRange.Data.ToString() == cellRange.DataDisplay.ToString())
				if (cellRange.Data != null && cellRange.Data.ToString() == cellRange.DataDisplay.ToString())
				{
					if (cellRange.Data == null || cellRange.Data.ToString().Length == 0 && allowBlank)
					{
						return;
					}
					while (idEnumerator.MoveNext())
					{
						valueToTest = curValueString.Trim().ToUpper();
						comboBoxValue = idEnumerator.Value.ToString().Trim().ToUpper();
						//if (curValueString.Trim().ToUpper() == idEnumerator.Value.ToString().Trim().ToUpper())
						if (valueToTest == comboBoxValue
							|| (comboBoxValue.Length >= valueToTest.Length 
							&& valueToTest == comboBoxValue.Substring(0, valueToTest.Length)))
						{
							grid.SetData(rowNumber, fieldName, Convert.ToInt32(idEnumerator.Key));
							idFound = true;
							break;
						}
					}
				}
				else
				{
					if (useID)
					{
						//the value is based on a database ID - make sure the selected ID is in the combo box list
						try
						{
							curValueInt = Convert.ToInt32(curValueString);
							idEnumerator.Reset();
							while (idEnumerator.MoveNext())
							{
								if (curValueInt == (int)idEnumerator.Key)
								{
									//should not be necessary to set the data, but do it anyway, just to be sure
									grid.SetData(rowNumber, fieldName, Convert.ToInt32(idEnumerator.Key));
									idFound = true;
									break;
								}
							}
						}
						catch
						{
							//we don't care why the error occurred
						}
					}
					else
					{
						//the value must be within a range of integers
						try
						{
							curValueInt = Convert.ToInt32(curValueString);
							if (curValueInt >= minValue && curValueInt <= maxValue)
							{
								grid.SetData(rowNumber, fieldName, curValueInt);
								idFound = true;
							}
						}
						catch
						{
							//we don't care why the error occurred
						}
					}
				}

				//mam 07072011 - should this be here?
				//	it doesn't seem to be necessary - things are working without it
				//if (curValueString == "")
				//{
				//	string caption = grid.Rows[grid.Rows.Fixed][fieldName].ToString();
				//	SetDefaultValue(grid, rowNumber, fieldName, "", "The " + caption + " has been set to its default value because it was left blank in the Excel file.");
				//}

				if (!idFound)
				{
					SetError(grid, cellRange, errorTipCombo);
				}
			}
			catch
			{
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		//mam 07072011
		private void AssignDefaultValueLos(C1FlexGrid grid, int rowNumber, string fieldName)
		{
			int defaultValue = 1;
			IDictionaryEnumerator idEnumerator = listDictionaryLOS.GetEnumerator();
			while (idEnumerator.MoveNext())
			{
				if (Convert.ToInt32(idEnumerator.Key) == defaultValue)
				{
					grid.SetData(rowNumber, fieldName, defaultValue);

					string caption = grid.Rows[0][fieldName].ToString();
					SetDefaultValue(grid, rowNumber, fieldName, "", "The " + caption + " has been set to its default value because it was left blank in the Excel file.");

					return;
				}
			}
		}

		//mam 07072011
		private void AssignDefaultValuePlanningMode(C1FlexGrid grid, int rowNumber, string fieldName)
		{
			int selectedIndex = sortedListCip.IndexOfKey(defaultCipId);
			if (selectedIndex > -1)
			{
				grid.SetData(rowNumber, fieldName, sortedListCip.GetByIndex(selectedIndex).ToString());
				SetDefaultValue(grid, rowNumber, fieldName, "", "The Planning Mode has been set to its default value because it was left blank in the Excel file.");
			}
		}

		private void AssignDefaultValueTrueFalse(C1FlexGrid grid, int rowNumber, string fieldName, bool valueToSet)
		{
			string caption = grid.Rows[0][fieldName].ToString();
			SetDefaultValue(grid, rowNumber, fieldName, "", caption  + " has been set to " + valueToSet.ToString() + " because it was left blank or was something other than TRUE or FALSE in the Excel file.");
		}

		//mam 07072011
		private void AssignDefaultValueCrit(C1FlexGrid grid, int rowNumber, string fieldName)
		{
			int critNumber = Convert.ToInt32(fieldName.Substring(fieldName.Length - 1, 1));
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				if (((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber == critNumber)
				{
					ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors;
					CriticalityForImport crit = (CriticalityForImport)arrayListCriticalities[i];
			
					int curValueInt = crit.DefaultCriticalityScore;
					if (ld[curValueInt] != null)
					{
						grid.SetData(rowNumber, fieldName, curValueInt);
						string caption = grid.Rows[0][fieldName].ToString();
						SetDefaultValue(grid, rowNumber, fieldName, "", "The " + caption + " has been set to its default value because it was left blank in the Excel file.");
							
						return;
					}
				}
			}
		}

		//mam 07072011
		private void ValidateGridRowWithDataMapSortedList(SortedList sortedList, C1FlexGrid grid, CellRange cellRange, 
			int rowNumber, string curValueString, string fieldName, bool allowBlank)
		{
			try
			{
				int selectedIndex = 0;
				bool idFound = false;
				string valueToTest = "";
				string comboBoxValue = "";

				if ((cellRange.Data == null || cellRange.Data.ToString().Length == 0) && allowBlank)
				{
					return;
				}

				//if curValueString = "", don't assign a default value
				//curValueString can only be "" when the user has deleted the value from the grid cell
				if (curValueString == "")
				{
					idFound = false;
				}
				else if (curValueString == "" || Common.CommonTasks.IsNumericInteger(curValueString))
				{
					int curValueInt = curValueString == "" ? defaultCipId : Convert.ToInt32(curValueString);

					//curValueInt is the Id
					selectedIndex = sortedListCip.IndexOfKey(curValueInt);
					if (selectedIndex > -1)
					{
						grid.SetData(rowNumber, fieldName, sortedListCip.GetByIndex(selectedIndex).ToString());
						idFound = true;
					}
				}
				else
				{
					IDictionaryEnumerator idEnumerator;
					idEnumerator = sortedList.GetEnumerator();

					while (idEnumerator.MoveNext())
					{
						valueToTest = curValueString.Trim().ToUpper();
						comboBoxValue = idEnumerator.Value.ToString().Trim().ToUpper();
						if (valueToTest == comboBoxValue
							|| (comboBoxValue.Length >= valueToTest.Length 
							&& valueToTest == comboBoxValue.Substring(0, valueToTest.Length)))
						{
							//grid.SetData(rowNumber, fieldName, Convert.ToInt32(idEnumerator.Key));
							grid.SetData(rowNumber, fieldName, idEnumerator.Value);
							idFound = true;
							break;
						}
					}
				}
				if (curValueString == "")
				{
					SetDefaultValue(grid, rowNumber, fieldName, "", "The Planning Mode has been set to its default value because it was left blank in the Excel file.");
				}
				if (!idFound)
				{
					SetError(grid, cellRange, errorTipCombo);
				}
			}
			catch
			{
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		//mam 07072011 - new method for new crits
		private void ValidateGridRowWithDataMapNewCrit(ListDictionary ld, C1FlexGrid grid, CellRange cellRange, 
			int rowNumber, string curValueString, string fieldName, bool allowBlank, bool singleCell)
		{
			try
			{
				bool idFound = false;
				string valueToTest = "";
				string comboBoxValue = "";

				//if curValueString is empty, set the grid cell value to the default value for the crit
				//if curValueString is numeric, try to find it in the ListDictionary keys
				//otherwise, compare it to the ListDictionary values

				//**********************************************

				//if curValueString = "", don't assign a default value
				//curValueString can only be "" when the user has deleted the value from the grid cell
				//	or when the column can't be found in the Excel file
				if (curValueString == "")
				{
					idFound = false;
				}

					//if curValueString is empty, set the grid cell value to the default value for the crit
					//				if (curValueString == "")
					//				{
					//					int critNumber = Convert.ToInt32(fieldName.Substring(fieldName.Length - 1, 1));
					//					for (int i = 0; i < arrayListCriticalities.Count; i++)
					//					{
					//						CriticalityForImport crit = (CriticalityForImport)arrayListCriticalities[i];
					//						if (crit.CriticalityNumber == critNumber)
					//						{
					//							int curValueInt = crit.DefaultCriticalityScore;
					//							if (ld[curValueInt] != null)
					//							{
					//								grid.SetData(rowNumber, fieldName, curValueInt);
					//								idFound = true;
					//
					//								//string caption = grid.Rows[grid.Rows.Fixed][fieldName].ToString();
					//								string caption = grid.Rows[0][fieldName].ToString();
					//								SetDefaultValue(grid, rowNumber, fieldName, "", "The " + caption + " has been set to its default value because it was left blank in the Excel file.");
					//								
					//								return;
					//							}
					//						}
					//					}
					//				}
				
					//**********************************************

					//check whether curValueString is an integer
				else if (Common.CommonTasks.IsNumericInteger(curValueString))
				{
					int curValueInt = Convert.ToInt32(curValueString);
					if (ld[curValueInt] != null)
					{
						grid.SetData(rowNumber, fieldName, curValueInt);
						idFound = true;
					}
				}
				else
				{
					//curValueString is not an integer - compare it to the list dictionary text values
					IDictionaryEnumerator idEnumerator;
					idEnumerator = ld.GetEnumerator();

					while (idEnumerator.MoveNext())
					{
						valueToTest = curValueString.Trim().ToUpper();
						comboBoxValue = idEnumerator.Value.ToString().Trim().ToUpper();
						if (valueToTest == comboBoxValue
							|| (comboBoxValue.Length >= valueToTest.Length 
							&& valueToTest == comboBoxValue.Substring(0, valueToTest.Length)))
						{
							grid.SetData(rowNumber, fieldName, Convert.ToInt32(idEnumerator.Key));
							idFound = true;
							break;
						}
					}
				}
				if (!idFound)
				{
					SetError(grid, cellRange, errorTipCombo);
					return;
				}

				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					//cellRange.Style = grid.Styles["Valid"];
					//cellRange.UserData = string.Empty;
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		private void ValidateGridDataCombo(C1FlexGrid grid, int i, string fieldName, bool setError, bool singleCell)
		{
			CellRange cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);

			////mam 07072011 - if the cell style has been set to DefaultValue, the cell value is valid, so just leave it as it is
			//if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
			//{
			//	return;
			//}

			try
			{
				IDictionaryEnumerator idEnumerator;
				//int curValueInt = -1;
				bool idFound = false;
				string curValueString = grid[i, fieldName] == null? string.Empty: grid[i, fieldName].ToString();
				//cellRange = grid.GetCellRange(i, grid.Cols[fieldName].Index);

				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					//mam 07072011
					if (cellRange.Style != null && cellRange.Style.Name == "DefaultValue")
					{
						//return;
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;
					}
				}
				//cellRange.UserData = string.Empty;

				//mam 07072011 - set the cell style to DefaultValue for all cells that have user data
				//this will include error cells, but they will be taken care of below
				//if (cellRange.UserData != null)
				//{
				//	cellRange.Style = grid.Styles["DefaultValue"];
				//}

				switch (fieldName)
				{
					case "FacilityName":
						//make sure the row has set the facility by ID, rather than by facility name
						//(if the Data is the same as the DataDisplay, the facility column has been set to the facility text,
						//	rather than to the facility ID)
						//IDictionaryEnumerator idEnumerator = listDictFacilityNames.GetEnumerator();
						if (fieldName == "FacilityName")
						{
							idEnumerator = listDictFacilityNamesAll.GetEnumerator();
							idFound = false;

							if (cellRange.Data == null)
							{
								if (listDictFacilityNamesAll.Count == 0)
								{
									SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Facility in the Facility tab");
								}
								else
								{
									SetError(grid, cellRange, errorTipCombo);
								}
								return;
							}

							if (cellRange.Data.GetType() == typeof(ImportFromTextFileFacility))
							{
								if (listDictFacilityNamesAll.Contains(((ImportFromTextFileFacility)cellRange.Data).TempID)
									&& (((ImportFromTextFileFacility)cellRange.Data).ImportThisItem
									|| ((ImportFromTextFileFacility)cellRange.Data).ExistingID > 0))
								{
									idFound = true;
								}
							}
							else if (cellRange.Data.ToString() == cellRange.DataDisplay.ToString())
							{
								idFound = false;
								while (idEnumerator.MoveNext())
								{
									if (curValueString.Trim().ToUpper() == idEnumerator.Value.ToString().Trim().ToUpper())
									{
										//grid.SetData(i, fieldName, Convert.ToInt32(idEnumerator.Key));
										grid.SetData(i, fieldName, idEnumerator.Value);
										//if the Facility will not be imported, any Processes or Major Components
										//	intended to go into the Facility also cannot be imported
										if (((ImportFromTextFileFacility)idEnumerator.Value).ImportThisItem
											|| ((ImportFromTextFileFacility)idEnumerator.Value).ExistingID > 0)
										{
											idFound = true;
										}
										break;
									}
								}
							}
							if (!idFound)
							{
								if (listDictFacilityNamesAll.Count == 0)
								{
									SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Facility in the Facility tab");
								}
								else
								{
									SetError(grid, cellRange, errorTipCombo);
								}

								//mam 07072011 - added return
								return;
							}
						}
						break;
					case "ProcessName":
						int facIDTemp = 0;
						//if the selected facility is not in the combo box, it doesn't exist, and cannot have any processes
						//(the FacilityName column may contain a string or it may be null or it may contain an import facility object)
						if (grid[i, "FacilityName"] != null 
							&& grid[i, "FacilityName"].GetType() == typeof(ImportFromTextFileFacility))
						{
							facIDTemp = ((ImportFromTextFileFacility)grid[i, "FacilityName"]).TempID;
						}
						if (facIDTemp == 0)
						{
							if (listDictProcessNamesAll.Count == 0)
							{
								SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Process in the Process tab");
							}
							else
							{
								SetError(grid, cellRange, errorTipCombo);
							}
							return;
						}

						if (cellRange.Data == null)
						{
							if (listDictProcessNamesAll.Count == 0)
							{
								SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Process in the Process tab");
							}
							else
							{
								SetError(grid, cellRange, errorTipCombo);
							}
							return;
						}

						if (cellRange.Data.GetType() == typeof(ImportFromTextFileProcess))
						{
							//if (((ImportFromTextFileProcess)cellRange.Data).ParentExists
							//	&& (((ImportFromTextFileProcess)cellRange.Data).ImportThisItem
							//	|| ((ImportFromTextFileProcess)cellRange.Data).ExistingID > 0))
							if (listDictProcessNamesAll.Contains(((ImportFromTextFileProcess)cellRange.Data).TempID)
								&& ((ImportFromTextFileProcess)cellRange.Data).ParentExists
								&& (((ImportFromTextFileProcess)cellRange.Data).ImportThisItem
								|| ((ImportFromTextFileProcess)cellRange.Data).ExistingID > 0))
							{
								int facIDExisting = ((ImportFromTextFileFacility)grid[i, "FacilityName"]).ExistingID == 0? 
								facIDTemp: ((ImportFromTextFileFacility)grid[i, "FacilityName"]).ExistingID;
								//if (facIDExisting == 0)
								//{
								//	facIDExisting = facIDTemp;
								//}

								if (((ImportFromTextFileProcess)cellRange.Data).FacilityID != facIDExisting)
								{
									SetError(grid, cellRange, errorTipCombo);
									return;
								}
							}
							else
							{
								//either the facility does not exist/is not being imported, or the process either
								//does not exist or is not being imported
								SetError(grid, cellRange, errorTipCombo);
								return;
							}
						}
						else if (cellRange.Data.ToString() == cellRange.DataDisplay.ToString())
						{
							ImportFromTextFileProcess process = FindProcessForFacilityByIndexOrName(facIDTemp, -1, cellRange.Data.ToString());
							if (process == null)
							{
								if (listDictProcessNamesAll.Count == 0)
								{
									SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Process in the Process tab");
								}
								else
								{
									//the process does not exist in the facility
									SetError(grid, cellRange, errorTipCombo);
								}

								//mam 07072011 - added return
								return;
							}
							else
							{
								grid.SetData(i, "ProcessName", process);
							}
						}
						break;
					case "ComponentName":
						//this code runs only for the Discipline grid
						if (cellRange.Data == null)
						{
							if (listDictComponentNamesAll.Count == 0)
							{
								SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Component in the Component tab");
							}
							else
							{
								SetError(grid, cellRange, errorTipCombo);
							}
							return;
						}

						//if the cell data is a string rather than a component object, set the cell contents to the object
						if (cellRange.Data.GetType() != typeof(ImportFromTextFileComponent))
						{
							//the component is a string - find the component in the list and set the cell to the component object
							idEnumerator = listDictComponentNamesImportCheckBox.GetEnumerator();
							idFound = false;
							while (idEnumerator.MoveNext())
							{
								if (cellRange.Data.ToString().ToUpper() == ((ImportFromTextFileComponent)idEnumerator.Value).ItemName.ToUpper())
								{
									//mam 112806
									//found a component in the combo box that matches by name the component string from the Excel file;
									//	make sure the process and facility names also match those from the Excel file
									//to do this, use the component's ProcessID to get the process name
									//then use the process' FacilityID to get the facility name
									int curID = ((ImportFromTextFileComponent)idEnumerator.Value).ProcessID;

									if (listDictProcessNames.Contains(curID) &&
										((ImportFromTextFileProcess)listDictProcessNames[curID]).ItemName.ToUpper() 
										== grid[i, "LoadedProcessName"].ToString().ToUpper())
									{
										curID = ((ImportFromTextFileProcess)listDictProcessNames[curID]).FacilityID;
										if (listDictFacilityNames.Contains(curID) &&
											((ImportFromTextFileFacility)listDictFacilityNames[curID]).ItemName.ToUpper() 
											== grid[i, "LoadedFacilityName"].ToString().ToUpper())
										{
											//component found in list
											grid.SetData(i, "ComponentName", (ImportFromTextFileComponent)idEnumerator.Value);
											SetFacilityAndProcessInDiscGridBasedOnComponent((ImportFromTextFileComponent)idEnumerator.Value, 
												grid, i, false);
											idFound = true;
											break;
										}
									}
								}
							}

							if (!idFound)
							{
								if (listDictComponentNamesAll.Count == 0)
								{
									SetError(grid, cellRange, errorTipCombo + "\r\nor Create a Component in the Component tab");
								}
								else
								{
									SetError(grid, cellRange, errorTipCombo);
								}
								return;
							}
						}

						//						//set error style, if necessary
						//						if (cellRange.Data.GetType() != typeof(ImportFromTextFileComponent))
						//						{
						//							SetError(grid, cellRange);
						//							return;
						//						}

						ImportFromTextFileComponent component = (ImportFromTextFileComponent)grid.GetData(i, "ComponentName");
						if (component == null
							|| !component.ParentExists || component.ProcessID == 0 || !component.ImportThisItem || component.ExistingID > 0)
						{
							//the component is null or has no parent process, or won't be imported or already exists in the tree
							SetError(grid, cellRange, errorTipCombo);

							//mam 07072011 - added return
							return;
						}
						else
						{
							SetFacilityAndProcessInDiscGridBasedOnComponent(component, grid, i, false);
						}
						break;
					case "CustomENRTable":
						idEnumerator = listDictionaryCustomENRTable.GetEnumerator();
						ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, -1, -1, true, true, -1);
						break;
					case "ComponentType":
						idEnumerator = listDictionaryComponentType.GetEnumerator();
						ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 1, false, false, -1);
						break;
					case "LOS":
						idEnumerator = listDictionaryLOS.GetEnumerator();
						ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 5, false, false, 1);
						break;

						//mam 07072011
					case "CipPlanningMode":
						//idEnumerator = sortedListCip.GetEnumerator();
						ValidateGridRowWithDataMapSortedList(sortedListCip, grid, cellRange, i, curValueString, fieldName, false);
						break;

					case "Condition":
						idEnumerator = listDictionaryCondition.GetEnumerator();
						if (curValueString == "255")
						{
							curValueString = "6";
						}
						ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 6, false, false, -1);
						break;

						//mam 07072011
					case "Crit1":
					case "Crit2":
					case "Crit3":
					case "Crit4":
					case "Crit5":
					case "Crit6":
						int critNumber = Convert.ToInt32(fieldName.Substring(fieldName.Length - 1, 1));
						for (int j = 0; j < arrayListCriticalities.Count; j++)
						{
							if (((CriticalityForImport)arrayListCriticalities[j]).CriticalityNumber == critNumber)
							{
								ListDictionary ld = ((CriticalityForImport)arrayListCriticalities[j]).CriticalityFactors;
								ValidateGridRowWithDataMapNewCrit(ld, grid, cellRange, i, curValueString, fieldName, false, singleCell);
								
								break;
							}
						}
						break;
						//</mam>

						//mam 07072011 - no longer using four fixed crits
						//case "CritPublic":
						//	idEnumerator = listDictionaryCritPublic.GetEnumerator();
						//	ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 3, false, false);
						//	break;
						//case "CritEnvironment":
						//	idEnumerator = listDictionaryCritEnvironment.GetEnumerator();
						//	ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 3, false, false);
						//	break;
						//case "CritRepair":
						//	idEnumerator = listDictionaryCritRepair.GetEnumerator();
						//	ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 3, false, false);
						//	break;
						//case "CritEffect":
						//	idEnumerator = listDictionaryCritEffect.GetEnumerator();
						//	ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 3, false, false);
						//	break;

					case "DisciplineType":
						idEnumerator = listDictionaryDisciplineType.GetEnumerator();
						ValidateGridRowWithDataMap(idEnumerator, grid, cellRange, i, curValueString, fieldName, 0, 2, false, false, -1);
						break;
				}

				//mam 07072011 - since we're no longer setting all cells to "Valid" before validation, do it here for a cell that passed the validation test
				if (singleCell)
				{
					//cellRange.Style = grid.Styles["Valid"];
					//cellRange.UserData = string.Empty;
					if (cellRange.Style != null && cellRange.Style.Name.IndexOf("DontImport") > -1)
					{
						cellRange.Style = grid.Styles["DontImport"];
					}
					else
					{
						cellRange.Style = grid.Styles["Valid"];
					}
					cellRange.UserData = string.Empty;
				}
			}
			catch
			{
				//errorCount++;
				errorCountUnknownError++;
				if (grid != null)
				{
					SetError(grid, cellRange, "Unknown error");
				}
			}
		}

		private void SetProcessPropertyFacilityID()
		{
			try
			{
				//call this method only during validation

				//set the process.FacilityID to the facility.ExistingID for the facility in the same grid row
				//if the facility.ExistingID is zero, then the facility does not yet exist - if it is to be imported, 
				//	set the process.FacilityID to the facility's TempID; otherwise, set process.FacilityID to zero

				CellRange cellRange;
				int tempID = 0;

				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					tempID = Convert.ToInt32(c1FlexGridProcess[i, "TempID"]);
					((ImportFromTextFileProcess)listDictProcessNames[tempID]).FacilityID = 0;

					//get the cell range for the facility in the current row to check its error status
					cellRange = c1FlexGridProcess.GetCellRange(i, c1FlexGridProcess.Cols["FacilityName"].Index);
					if (cellRange.Style == null || cellRange.Style.Name != "Error")
					{
						if (c1FlexGridProcess[i, "FacilityName"] != null 
							&& c1FlexGridProcess[i, "FacilityName"].GetType() == typeof(ImportFromTextFileFacility))
						{
							ImportFromTextFileFacility tempFac = (ImportFromTextFileFacility)c1FlexGridProcess[i, "FacilityName"];
							if (tempFac.ExistingID == 0) //&& tempFac.ImportThisItem)
							{
								((ImportFromTextFileProcess)listDictProcessNames[tempID]).FacilityID = tempFac.TempID;
							}
							else
							{
								((ImportFromTextFileProcess)listDictProcessNames[tempID]).FacilityID = tempFac.ExistingID;
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in SetProcessPropertyFacilityID: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void SetComponentPropertyProcessID(C1FlexGrid grid)
		{
			try
			{
				//call this method only during validation

				//set the component.ProcessID to the process.ExistingID for the process in the same grid row
				//if the process.ExistingID is zero, then the process does not yet exist - if it is to be imported, 
				//	set the component.ProcessID to the process' TempID; otherwise, set component.ProcessID to zero

				CellRange cellRange;
				int tempID = 0;

				for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
				{
					tempID = Convert.ToInt32(grid[i, "TempID"]);
					((ImportFromTextFileComponent)listDictComponentNames[tempID]).ProcessID = 0;

					//get the cell range for the process in the current row to check its error status
					cellRange = grid.GetCellRange(i, grid.Cols["ProcessName"].Index);
					if (cellRange.Style == null || cellRange.Style.Name != "Error")
					{
						if (grid[i, "ProcessName"] != null && grid[i, "ProcessName"].GetType() == typeof(ImportFromTextFileProcess))
						{
							ImportFromTextFileProcess tempProc = (ImportFromTextFileProcess)grid[i, "ProcessName"];
							if (tempProc.ExistingID == 0) //&& tempProc.ImportThisItem)
							{
								((ImportFromTextFileComponent)listDictComponentNames[tempID]).ProcessID = tempProc.TempID;
							}
							else
							{
								((ImportFromTextFileComponent)listDictComponentNames[tempID]).ProcessID = tempProc.ExistingID;
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in SetComponentPropertyProcessID: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void ResetErrorCount()
		{
			errorCount = 0;
			//errorCountByCellErrorStyle = 0;
			errorCountUnknownError = 0;
			errorInSetError = 0;
		}

		private void SetError(C1FlexGrid grid, CellRange cellRange, string errorTip)
		{
			try
			{
				//mam 07072011 - added "DontImportDefaultValue"
				if (cellRange.Style == null || (cellRange.Style.Name != "DontImport" && cellRange.Style.Name != "DontImportDefaultValue"))
				{
					errorCount++;
					cellRange.Style = grid.Styles["Error"];
					cellRange.UserData = errorTip;
				}
			}
			catch
			{
				errorInSetError++;
			}
		}

		//		//mam 07072011 - this is unnecessary
		//		private struct StructGridCellRange
		//		{
		//			private C1FlexGrid grid;
		//			private int rowIndex;
		//			private int colIndex;
		//			private string styleName;
		//
		//			public StructGridCellRange(C1FlexGrid grid, int rowIndex, int colIndex, string styleName)
		//			{
		//				this.grid = grid;
		//				this.rowIndex = rowIndex;
		//				this.colIndex = colIndex;
		//				this.styleName = styleName;
		//			}
		//
		//			public C1FlexGrid Grid
		//			{
		//				get { return grid; }
		//				set { grid = value; }
		//			}
		//			public int RowIndex
		//			{
		//				get { return rowIndex; }
		//				set { rowIndex = value; }
		//			}
		//			public int ColIndex
		//			{
		//				get { return colIndex; }
		//				set { colIndex = value; }
		//			}
		//			public string StyleName
		//			{
		//				get { return styleName; }
		//				set { styleName = value; }
		//			}
		//		}

		private string SetDefaultValue(C1FlexGrid grid, int rowIndex, string colName, string defaultValue, string defaultTip)
		{
			CellRange cellRange = grid.GetCellRange(rowIndex, grid.Cols[colName].Index);
			cellRange.Style = grid.Styles["DefaultValue"];
			cellRange.UserData = "*DEFAULT*" + defaultTip;
			return defaultValue;
		}

		#endregion /***** Validate Data *****/

		#region /***** Import the Data *****/

		private void CountErrors()
		{
			CellRange cellRange;
			errorCountByCellErrorStyle = 0;

			//count the grid cells that have the Error style
			for (int colIndex = c1FlexGridFacility.Cols.Fixed; colIndex < c1FlexGridFacility.Cols.Count; colIndex++)
			{
				for (int rowIndex = c1FlexGridFacility.Rows.Fixed; rowIndex < c1FlexGridFacility.Rows.Count; rowIndex++)
				{
					if (Convert.ToBoolean(c1FlexGridFacility[rowIndex, "Import"]))
					{
						cellRange = c1FlexGridFacility.GetCellRange(rowIndex, colIndex);
						if (cellRange.Style != null && cellRange.Style.Name == "Error")
						{
							errorCountByCellErrorStyle++;
						}
					}
				}
			}
			for (int colIndex = c1FlexGridProcess.Cols.Fixed; colIndex < c1FlexGridProcess.Cols.Count; colIndex++)
			{
				for (int rowIndex = c1FlexGridProcess.Rows.Fixed; rowIndex < c1FlexGridProcess.Rows.Count; rowIndex++)
				{
					if (Convert.ToBoolean(c1FlexGridProcess[rowIndex, "Import"]))
					{
						cellRange = c1FlexGridProcess.GetCellRange(rowIndex, colIndex);
						if (cellRange.Style != null && cellRange.Style.Name == "Error")
						{
							errorCountByCellErrorStyle++;
						}
					}
				}
			}
			for (int colIndex = c1FlexGridComponent.Cols.Fixed; colIndex < c1FlexGridComponent.Cols.Count; colIndex++)
			{
				for (int rowIndex = c1FlexGridComponent.Rows.Fixed; rowIndex < c1FlexGridComponent.Rows.Count; rowIndex++)
				{
					if (Convert.ToBoolean(c1FlexGridComponent[rowIndex, "Import"]))
					{
						cellRange = c1FlexGridComponent.GetCellRange(rowIndex, colIndex);
						//if (cellRange.Style != null && cellRange.Style == c1FlexGridComponent.Styles["Error"])
						if (cellRange.Style != null && cellRange.Style.Name == "Error")
						{
							errorCountByCellErrorStyle++;
						}
					}
				}
			}

			for (int colIndex = c1FlexGridComponentPN.Cols.Fixed; colIndex < c1FlexGridComponentPN.Cols.Count; colIndex++)
			{
				for (int rowIndex = c1FlexGridComponentPN.Rows.Fixed; rowIndex < c1FlexGridComponentPN.Rows.Count; rowIndex++)
				{
					if (Convert.ToBoolean(c1FlexGridComponentPN[rowIndex, "Import"]))
					{
						cellRange = c1FlexGridComponentPN.GetCellRange(rowIndex, colIndex);
						//if (cellRange.Style != null && cellRange.Style == c1FlexGridComponentPN.Styles["Error"])
						if (cellRange.Style != null && cellRange.Style.Name == "Error")
						{
							errorCountByCellErrorStyle++;
						}
					}
				}
			}
		}

		//mam 03202012
		private void ProgressUpdate(TimeSpan t)
		{
			if (this.progressDisplay.InvokeRequired)
			{
				this.progressDisplay.Invoke(new DelegateProgressUpdate(this.ProgressUpdate), new object[]{ t });
			}
			else
			{
				this.progressDisplay.UpdateCounter(t);
			}

			return;

			//this code is for the panel progress updater, which is no longer being used
			//gridRowCount++;
			//textBoxProgressRowCount.Text = string.Format("{0} of {1}", gridRowCount.ToString(), totalRowCount.ToString());
			//textBoxProgressTime.Text = string.Format("{0}:{1}", t.Minutes.ToString(), t.Seconds.ToString().PadLeft(2, '0'));
			//this.Refresh();
		}

		//mam 03202012
		private void ProgressClose()
		{
			if (this.progressDisplay.InvokeRequired)
			{
				this.progressDisplay.Invoke(new DelegateProgressClose(this.ProgressClose));
			}
			else
			{
				this.progressDisplay.Close();
				this.progressDisplay.Dispose();
				this.progressDisplay = null;
			}

			return;

			//this code is for the panel progress updater, which is no longer being used
			//panelProgressDisplay.Visible = false;
			//SetImportButtonState(false);
		}

		//mam 03202012
		private void ProgressErrorMessage(string message)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(new DelegateProgressErrorMessage(this.ProgressErrorMessage));
			}
			else
			{
				MessageBox.Show(this, message, "Import Not Completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//mam 03202012
		private void ProgressMessage(string message)
		{
			if (this.InvokeRequired)
			{
				//this is called only from the import thread, so don't check this.InvokeRequired
				this.Invoke(new DelegateProgressMessage(this.ProgressMessage), new object[]{ message });
			}
			else
			{
				MessageBox.Show(this, message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		//mam 03202012
		private void ProgressUpdate2(TimeSpan t)
		{
			if (this.progressDisplayLoadExcel.InvokeRequired)
			{
				this.progressDisplayLoadExcel.Invoke(new DelegateProgressUpdate(this.ProgressUpdate2), new object[]{ t });
			}
			else
			{
				this.progressDisplayLoadExcel.UpdateCounter(t);
			}
		}

		//mam 03202012
		private void ProgressUpdateText2(string message)
		{
			if (this.progressDisplayLoadExcel.InvokeRequired)
			{
				ProgressMessage("invoke required");
				this.progressDisplayLoadExcel.Invoke(new DelegateProgressUpdateText(this.ProgressUpdateText2), new object[]{ message });
			}
			else
			{
				this.progressDisplayLoadExcel.UpdateText(message);
			}
		}

		//mam 03202012
		private void ProgressClose2()
		{
			if (this.progressDisplayLoadExcel.InvokeRequired)
			{
				this.progressDisplayLoadExcel.Invoke(new DelegateProgressClose(this.ProgressClose2));
			}
			else
			{
				this.progressDisplayLoadExcel.Close();
				this.progressDisplayLoadExcel.Dispose();
				this.progressDisplayLoadExcel = null;
			}
		}

		//mam 03202012
		//private void CallProgressErrorMessageFromNonUiThread(string message)
		//{
		//	//this is called only from the import thread, so don't check this.InvokeRequired
		//	this.Invoke(new DelegateProgressErrorMessage(this.ProgressErrorMessage), new object[]{ message });
		//}

		//mam 03202012
		//private void CallProgressMessageFromNonUiThread(string message)
		//{
		//	//this is called only from the import thread, so don't check this.InvokeRequired
		//	this.Invoke(new DelegateProgressMessage(this.ProgressMessage), new object[]{ message });
		//}

		private bool ImportData()
		{
			try
			{
				//this.Cursor = Cursors.WaitCursor;

				GridFinishEditing();
				ValidateGridData();

				if (errorCount > 0)
				{
					MessageBox.Show(this, "Errors exist.  The data cannot be imported.", "Import Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return false;
				}

				//mam 07072011 - let's not bother showing the user how long it will take to import the data
				// - we can't accurately figure that out, anyway
				//also, the number of rows imported is displayed as the import is occurring, and the user can see how long it will
				//	take by how many rows are left to import
				//also, the user has the ability to stop the import at any time
				//int gridRowCount = CountGridRows();
				//secondsRequired = Math.Round((double)gridRowCount / 4.5, 0);
				//minutesRequired = Math.Round((double)gridRowCount / 4.5 / 60, 1);
				//if (minutesRequired > 1 || secondsRequired > 5)
				//{
				//	StringBuilder builder = new StringBuilder(50);
				//	builder.AppendFormat("Approximately {0} will be required to import the data.  Do you wish to continue?", minutesRequired < 1? secondsRequired.ToString() + " seconds": minutesRequired.ToString() + " minutes");
				//	if (MessageBox.Show(this, builder.ToString(), "Import Data", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
				//	{
				//		return true;
				//	}
				//}

				//convert decimal portion of minutes to seconds for progress display
				//if (minutesRequired > 1)
				//{
				//	secondsRequired = (minutesRequired - Math.Floor(minutesRequired)) * 60;
				//}
				//minutesRequired = Math.Floor(minutesRequired);

				stopImportingData = false;

				//importThread is started from the OnLoad event of the progressDisplay form
				importThread = new Thread(new ThreadStart(ImportData2));
				importThread.ApartmentState = ApartmentState.STA;

				//mam 07072011 - commented for testing only
				//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
				//mam 03202012 - call it from the ui thread
				//mam 03202012 - no longer estimating time required, so just pass zero for those values
				//progressDisplay = new ProgressDisplay(this, CountGridRows(), secondsRequired, minutesRequired);
				//progressDisplay = new ProgressDisplay(this, CountGridRows(), 0, 0);
				progressDisplay = new ProgressDisplay(this, CountGridRowsToImport(), 0, 0);
				progressDisplay.ShowDialog();	

				//mam 07072011 - for testing only
				//	leave it we'll use this instead of the modal progress display, which appears to sometimes cause the import form to freeze after the import is completed
				//mam 03202012 - comment this - let's use the old progress display
				//ProgressDisplaySetup();

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in ImportData: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		public void CancelImport()
		{
			stopImportingData = true;
		}

		public void StartImportThread()
		{
			importThread.Start();
		}

		//mam 03202012
		private void RenameExistingFacility(Facility newFacility, DataAccess dataAccess, ref C1FlexGrid gridErrors)
		{
			//rename the existing facility (all existing facilities with the same name in the infoset will be renamed)
			try
			{
				//WAM.Common.CommonTasks.GenerateDivideByZeroError();

				int curInfosetId = newFacility.InfoSetID;
				DataTable dataTableNewNames = dataAccess.GetDisconnectedDataTableSP("RenameExistingFacility"
					, "@infosetId", curInfosetId
					, "@exceptFacilityId", newFacility.ID
					, "@existingName", newFacility.Name
					, "@appendage", renameExistingAppendage);

				if (dataTableNewNames != null)
				{
					foreach (DataRow dataRow in dataTableNewNames.Rows)
					{
						//rename facility in the cache
						Facility facToChange = CacheManager.GetFacility(curInfosetId, Convert.ToInt32(dataRow["Id"]));
						facToChange.Name = dataRow["Name"].ToString();

						//rename facility in the tree
						((MainForm)this.parentForm).RenameFacilityNode(facToChange.ID, facToChange.Name);
					}
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error renaming existing Facility " + newFacility.Name + ": " + ex.Message);
			}
		}

		//mam 03202012
		private void RenameExistingProcess(TreatmentProcess newProcess, DataAccess dataAccess, ref C1FlexGrid gridErrors)
		{
			//rename the existing process (all existing processes with the same name in the facility will be renamed)
			try
			{
				//WAM.Common.CommonTasks.GenerateDivideByZeroError();

				int curFacilityId = newProcess.FacilityID;
				DataTable dataTableNewNames = dataAccess.GetDisconnectedDataTableSP("RenameExistingProcess"
					, "@facilityId", curFacilityId
					, "@exceptProcessId", newProcess.ID
					, "@existingName", newProcess.Name
					, "@appendage", renameExistingAppendage);

				if (dataTableNewNames != null)
				{
					foreach (DataRow dataRow in dataTableNewNames.Rows)
					{
						//rename process in the cache
						TreatmentProcess procToChange = CacheManager.GetTreatmentProcess(newProcess.InfoSetID, Convert.ToInt32(dataRow["Id"]));
						procToChange.Name = dataRow["Name"].ToString();

						//rename process in the tree
						((MainForm)this.parentForm).RenameTreatmentProcessNode(newProcess.FacilityID, procToChange.ID, procToChange.Name);
					}
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error renaming existing Treatment Process " + newProcess.Name + ": " + ex.Message);
			}
		}

		//mam 03202012
		private void RenameExistingComponent(MajorComponent newComponent, DataAccess dataAccess, ref C1FlexGrid gridErrors)
		{
			//rename the existing component (all existing components with the same name in the process will be renamed)
			try
			{
				//WAM.Common.CommonTasks.GenerateDivideByZeroError();

				int curProcessId = newComponent.ProcessID;
				DataTable dataTableNewNames = dataAccess.GetDisconnectedDataTableSP("RenameExistingComponent"
					, "@processId", curProcessId
					, "@exceptComponentId", newComponent.ID
					, "@existingName", newComponent.Name
					, "@appendage", renameExistingAppendage);

				if (dataTableNewNames != null)
				{
					foreach (DataRow dataRow in dataTableNewNames.Rows)
					{
						//rename component in the cache
						MajorComponent compToChange = CacheManager.GetMajorComponent(newComponent.InfoSetID, Convert.ToInt32(dataRow["Id"]));
						compToChange.Name = dataRow["Name"].ToString();

						//rename component in the tree
						((MainForm)this.parentForm).RenameMajorComponentNode(newComponent.ProcessID, compToChange.ID, compToChange.Name);
					}
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error renaming existing Major Component " + newComponent.Name + ": " + ex.Message);
			}
		}

		private void ImportData2()
		{
			try
			{
				//mam 07072011
				C1FlexGrid gridErrors = Common.CommonTasks.GetErrorGrid();

				//mam 102309
				//Drive.Synchronization.SyncAction add = Drive.Synchronization.SyncAction.Add;

				//add each new facility to the data table
				//DataTable dataTableImport = dataTableOriginalDataFromSpreadsheet.Clone();
				//int newFacilityID = 0;
				int curFacilityID = 0;
				int curProcessID = 0;
				//int curComponentID = 0;
				string compType = string.Empty;

				//********************

				//COUNT ERRORS
				CountErrors();

				//********************

				DateTime elapsedTimeStart = DateTime.Now;
				TimeSpan elapsedTime;
				//DateTime elapsedTimeStop = DateTime.Now;

				//IDictionaryEnumerator idEnumerator;

				//mam 07072011
				DataAccess dataAccess = new DataAccess();
				defaultCipId = Common.CommonTasks.DefaultCipPlanningId;
				//short facilityYear = 0;
				bool success = true;

				//add new facilities to tree
				for (int i = c1FlexGridFacility.Rows.Fixed; i < c1FlexGridFacility.Rows.Count; i++)
				{
					if (stopImportingData)
					{
						break;
					}

					//mam 03202012 - don't update the progress display unless the row will be imported
					if (!Convert.ToBoolean(c1FlexGridFacility.Rows[i]["Import"]))
					{
						continue;
					}

					//this.Cursor = Cursors.WaitCursor;
					elapsedTime = DateTime.Now - elapsedTimeStart;

					//mam 03202012 - let's use this, and call it from the ui thread
					//mam 07072011 - commented for testing only
					//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
					//progressDisplay.UpdateCounter(elapsedTime);
					ProgressUpdate(elapsedTime);

					//mam 03202012 - comment this - let's use the old progress display
					//mam 07072011 - replacement progress display
					//UpdateCounter(elapsedTime);

					ImportFromTextFileFacility facility = null;

					//mam 03202012 - already checked this above
					//if (Convert.ToBoolean(c1FlexGridFacility.Rows[i]["Import"]))
					{
						//get the facility and note the ID
						facility = (ImportFromTextFileFacility)listDictFacilityNames[Convert.ToInt32(c1FlexGridFacility.Rows[i]["TempID"])];
						if (facility == null)
						{
							continue;
						}

						//set properties
						//mam 07072011 - set default current year here
						facility.CurrentYear = Convert.ToInt16(DateTime.Now.Year);
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityCurrentYear"]) 
							&& c1FlexGridFacility[i, "FacilityCurrentYear"] != null && c1FlexGridFacility[i, "FacilityCurrentYear"].ToString().Length > 0)
						{
							facility.CurrentYear = Convert.ToInt16(c1FlexGridFacility[i, "FacilityCurrentYear"].ToString().Trim());
						}

						//mam 01222012
						facility.FacilityCriticality = 1.00M;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityCriticality"]) 
							&& c1FlexGridFacility[i, "FacilityCriticality"] != null && c1FlexGridFacility[i, "FacilityCriticality"].ToString().Length > 0)
						{
							facility.FacilityCriticality = Convert.ToDecimal(c1FlexGridFacility[i, "FacilityCriticality"].ToString().Trim());
						}

						facility.CustomENRListID = 0;
						facility.UsesCustomENRTable = false;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["CustomENRTable"]))
						{
							if (c1FlexGridFacility[i, "CustomENRTable"] != null 
								&& c1FlexGridFacility[i, "CustomENRTable"].ToString().Length > 0)
							{
								if ((int)c1FlexGridFacility[i, "CustomENRTable"] > 0)
								{
									facility.CustomENRListID = (int)c1FlexGridFacility[i, "CustomENRTable"];
									facility.UsesCustomENRTable = true;
								}
							}
						}

						//mam 03202012 - why wasn't this here before? facility comments have not been being imported!
						facility.Comments = string.Empty;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["Comments"]))
						{
							facility.Comments = c1FlexGridFacility[i, "Comments"] == null? string.Empty: c1FlexGridFacility[i, "Comments"].ToString();
						}

						//start facility photos ************************************

						//mam 03202012
						facility.PhotoFileNameNorth = string.Empty;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityPhotoFileNameNorth"]))
						{
							facility.PhotoFileNameNorth = c1FlexGridFacility[i, "FacilityPhotoFileNameNorth"] == null? string.Empty: c1FlexGridFacility[i, "FacilityPhotoFileNameNorth"].ToString();
						}

						//mam 03202012
						facility.PhotoCaptionNorth = string.Empty;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityPhotoCaptionNorth"]))
						{
							facility.PhotoCaptionNorth = c1FlexGridFacility[i, "FacilityPhotoCaptionNorth"] == null? string.Empty: c1FlexGridFacility[i, "FacilityPhotoCaptionNorth"].ToString();
						}

						//mam 03202012
						facility.PhotoFileNameSouth = string.Empty;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityPhotoFileNameSouth"]))
						{
							facility.PhotoFileNameSouth = c1FlexGridFacility[i, "FacilityPhotoFileNameSouth"] == null? string.Empty: c1FlexGridFacility[i, "FacilityPhotoFileNameSouth"].ToString();
						}

						//mam 03202012
						facility.PhotoCaptionSouth = string.Empty;
						if (CheckColumnImport(c1FlexGridFacility, i, c1FlexGridFacility.Cols["FacilityPhotoCaptionSouth"]))
						{
							facility.PhotoCaptionSouth = c1FlexGridFacility[i, "FacilityPhotoCaptionSouth"] == null? string.Empty: c1FlexGridFacility[i, "FacilityPhotoCaptionSouth"].ToString();
						}

						//stop facility photos ************************************

						//add the new facility to the tree
						curFacilityID = ((MainForm)this.parentForm).AddFacility(facility.ItemName, true);

						//mam 07072011 - if the save failed, get out
						if (curFacilityID == 0)
						{
							//mam 03202012 - let's use this, and call it from the ui thread
							//mam 07072011 - commented for testing only
							//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
							//progressDisplay.Close();
							//progressDisplay = null;
							ProgressClose();

							//mam 03202012 - comment this - let's use the old progress display
							//mam 07072011 - replacement progress display
							//ProgressDisplayClose();

							//mam 03202012 - call messagebox from ui thread
							//MessageBox.Show(this, "An error occurred while saving the Facility data.  The import has been stopped.", "Import Not Completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
							string message = "An error occurred while saving the Facility data.  The import has been stopped.";
							ProgressErrorMessage(message);

							return;
						}

						facility.ExistingID = curFacilityID;

						//save properties in the newly-created facility
						Facility newFacility = CacheManager.GetFacility(facility.InfoSetID, curFacilityID);

						if (newFacility != null)
						{
							//*****************************
							//mam 03202012 - rename an existing facility because of a duplicate name, if necessary
							if (c1FlexGridFacility[i, "RenameExistingFacility"] != null && (bool)c1FlexGridFacility[i, "RenameExistingFacility"])
							{
								RenameExistingFacility(newFacility, dataAccess, ref gridErrors);
							}
							//*****************************

							newFacility.CustomENRListID = facility.CustomENRListID;
							newFacility.UsesCustomENRTable = facility.UsesCustomENRTable;
							newFacility.CurrentYear = facility.CurrentYear;
							//facilityYear = newFacility.CurrentYear;

							//mam 01222012
							newFacility.FacilityCriticality = facility.FacilityCriticality;

							//mam 03202012
							newFacility.Comments = facility.Comments;

							//mam 03202012
							newFacility.PhotoFileNameNorth = facility.PhotoFileNameNorth;
							newFacility.CaptionNorth = facility.PhotoCaptionNorth;
							newFacility.PhotoFileNameSouth = facility.PhotoFileNameSouth;
							newFacility.CaptionSouth = facility.PhotoCaptionSouth;

							//mam 03202012 - set a flag so the save routine knows that the facility is being imported
							newFacility.BeingImported = true;

							//mam 07072011 - added bool success
							success = newFacility.Save();
							//Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newFacility, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newFacility, add));

							//mam 03202012 - reset the import flag
							newFacility.BeingImported = false;

							//mam 07072011
							if (!success)
							{
								Facility facilityPreSave = new Facility(newFacility.ID);
								((MainForm)this.parentForm).SetNodeTagFacility(newFacility, facilityPreSave);
								Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error importing Facility " + newFacility.Name);
							}
						}
					}
				}

				//add new processes to the tree
				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					if (stopImportingData)
					{
						break;
					}

					//mam 03202012 - don't update the progress display unless the row will be imported
					if (!Convert.ToBoolean(c1FlexGridProcess.Rows[i]["Import"]))
					{
						continue;
					}

					//this.Cursor = Cursors.WaitCursor;
					elapsedTime = DateTime.Now - elapsedTimeStart;

					//mam 03202012 - let's use this, and call it from the ui thread
					//mam 07072011 - commented for testing only
					//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
					//progressDisplay.UpdateCounter(elapsedTime);
					ProgressUpdate(elapsedTime);

					//mam 03202012 - comment this - let's use the old progress display
					//mam 07072011 - replacement progress display
					//UpdateCounter(elapsedTime);

					//mam 03202012 - already checked this above
					//if (Convert.ToBoolean(c1FlexGridProcess.Rows[i]["Import"])) //&& ((ImportFromTextFileProcess)c1FlexGridProcess.Rows[i]["ProcessName"]).ParentExists)
					{
						ImportFromTextFileFacility facility = (ImportFromTextFileFacility)c1FlexGridProcess[i, "FacilityName"];
						if (facility.ExistingID == 0 && !facility.ImportThisItem)
						{
							continue;
						}
						//get the TempID for the selected facility in the current grid row
						int curTempFacID = Convert.ToInt32(((ImportFromTextFileFacility)c1FlexGridProcess[i, "FacilityName"]).TempID);

						//find the selected facility in the list dictionary and note the ID
						curFacilityID = ((ImportFromTextFileFacility)listDictFacilityNamesAll[curTempFacID]).ExistingID;

						ImportFromTextFileProcess importProcess = (ImportFromTextFileProcess)listDictProcessNames[
							Convert.ToInt32(c1FlexGridProcess.Rows[i]["TempID"])];

						//don't set the FacilityID
						//importProcess.FacilityID = curFacilityID;

						if (CheckColumnImport(c1FlexGridProcess, i, c1FlexGridProcess.Cols["ProcessName"]))
							importProcess.ItemName = c1FlexGridProcess[i, "ProcessName"].ToString().Trim();

						//*************************************

						//create the new process
						//mam 07072011 - added zero parameter for cipplanningid
						TreatmentProcess newProcess = (TreatmentProcess)((MainForm)this.parentForm).AddNodeForImportedData(WAM.UI.NodeType.TreatmentProcess, 
							curFacilityID, importProcess.ItemName, false, 0, ref gridErrors);

						//mam 07072011 - if the save failed, get out
						if (newProcess == null)
						{
							//mam 03202012 - let's use this, and call it from the ui thread
							//mam 07072011 - commented for testing only
							//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
							//progressDisplay.Close();
							//progressDisplay = null;
							ProgressClose();

							//mam 03202012 - comment this - let's use the old progress display
							//mam 07072011 - replacement progress display
							//ProgressDisplayClose();

							//mam 03202012 - call messagebox from ui thread
							//MessageBox.Show(this, "An error occurred while saving the Treatment Process data.  The import has been stopped.", "Import Not Completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
							string message = "An error occurred while saving the Treatment Process data.  The import has been stopped.";
							ProgressErrorMessage(message);

							return;
						}

						//mam 03202012
						if (c1FlexGridProcess[i, "RenameExistingProcess"] != null && (bool)c1FlexGridProcess[i, "RenameExistingProcess"])
						{
							RenameExistingProcess(newProcess, dataAccess, ref gridErrors);
						}

						importProcess.ExistingID = newProcess.ID;

						//*************************************

						//set additional properties in the existing import component object
						//mam 07072011 - set default comments here
						importProcess.Comments = string.Empty;
						if (CheckColumnImport(c1FlexGridProcess, i, c1FlexGridProcess.Cols["Comments"]))
						{
							importProcess.Comments = c1FlexGridProcess[i, "Comments"] == null? string.Empty: c1FlexGridProcess[i, "Comments"].ToString();
						}

						//*************************************

						//mam 03202012
						importProcess.PhotoFileName = string.Empty;
						if (CheckColumnImport(c1FlexGridProcess, i, c1FlexGridProcess.Cols["ProcessPhotoFileName"]))
						{
							importProcess.PhotoFileName = c1FlexGridProcess[i, "ProcessPhotoFileName"] == null? string.Empty: c1FlexGridProcess[i, "ProcessPhotoFileName"].ToString();
						}

						//mam 03202012
						importProcess.PhotoCaption = string.Empty;
						if (CheckColumnImport(c1FlexGridProcess, i, c1FlexGridProcess.Cols["ProcessPhotoCaption"]))
						{
							importProcess.PhotoCaption = c1FlexGridProcess[i, "ProcessPhotoCaption"] == null? string.Empty: c1FlexGridProcess[i, "ProcessPhotoCaption"].ToString();
						}

						//set the properties in the newly-created component
						newProcess.Comments = importProcess.Comments;

						//mam 03202012
						newProcess.PhotoFileName = importProcess.PhotoFileName;
						newProcess.CaptionPhoto = importProcess.PhotoCaption;

						//mam 07072011 - added bool success
						success = newProcess.Save();
						//Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newProcess, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newProcess, add));

						//mam 07072011
						if (!success)
						{
							TreatmentProcess processPreSave = new TreatmentProcess(newProcess.ID);
							((MainForm)this.parentForm).SetNodeTagTreatmentProcess(newProcess, processPreSave);
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error importing Treatment Process " + newProcess.Name);
						}
					}
				}

				//add new MSC components to the tree
				for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
				{
					if (stopImportingData)
					{
						break;
					}

					//mam 03202012 - don't update the progress display unless the row will be imported
					if (!Convert.ToBoolean(c1FlexGridComponent.Rows[i]["Import"]))
					{
						continue;
					}

					//this.Cursor = Cursors.WaitCursor;
					elapsedTime = DateTime.Now - elapsedTimeStart;

					//mam 03202012 - let's use this, and call it from the ui thread
					//mam 07072011 - commented for testing only
					//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
					//progressDisplay.UpdateCounter(elapsedTime);
					ProgressUpdate(elapsedTime);

					//mam 03202012 - comment this - let's use the old progress display
					//mam 07072011 - replacement progress display
					//UpdateCounter(elapsedTime);

					//mam 03202012 - already checked this above
					//if (Convert.ToBoolean(c1FlexGridComponent.Rows[i]["Import"])) //&& ((ImportFromTextFileComponent)c1FlexGridComponent.Rows[i]["ComponentName"]).ParentExists)
					{
						ImportFromTextFileProcess process = (ImportFromTextFileProcess)c1FlexGridComponent[i, "ProcessName"];
						if (process.ExistingID == 0 && !process.ImportThisItem)
						{
							continue;
						}
						//find the grid row component in the list dictionary and save the import info to the newly-created component
						ImportFromTextFileComponent importComponent = (ImportFromTextFileComponent)listDictComponentNames[
							Convert.ToInt32(c1FlexGridComponent.Rows[i]["TempID"])];

						//don't set the ProcessID
						//importComponent.ProcessID = ((ImportFromTextFileProcess)c1FlexGridComponent.GetData(i, "ProcessName")).ExistingID;

						curProcessID = ((ImportFromTextFileProcess)c1FlexGridComponent.GetData(i, "ProcessName")).ExistingID;

						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["ComponentName"]))
							importComponent.ItemName = c1FlexGridComponent[i, "ComponentName"].ToString().Trim();
						importComponent.MechStructDisciplines = true;

						//mam 07072011
						string curValueString = string.Empty;
						//set default planning mode here
						importComponent.CipPlanningModeId = defaultCipId;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CipPlanningMode"]))
						{
							curValueString = c1FlexGridComponent[i, "CipPlanningMode"] == null ? "" : c1FlexGridComponent[i, "CipPlanningMode"].ToString();
							//if (c1FlexGridComponent[i, "CipPlanningMode"] == null || c1FlexGridComponent[i, "CipPlanningMode"].ToString() == "")	// && c1FlexGridComponent[i, "CipPlanningMode"].ToString().Length > 0)
							if (curValueString != "")
							{
								int selectedIndex = sortedListCip.IndexOfValue(c1FlexGridComponent[i, "CipPlanningMode"].ToString());
								importComponent.CipPlanningModeId = Convert.ToInt32(sortedListCip.GetKey(selectedIndex));
							}
						}

						//*************************************

						//create the new component
						//mam 07072011 - added parameter for cipplanningid
						MajorComponent newComponent = (MajorComponent)((MainForm)this.parentForm).AddNodeForImportedData(
							WAM.UI.NodeType.MajorComponent, curProcessID, 
							importComponent.ItemName, importComponent.MechStructDisciplines, importComponent.CipPlanningModeId, ref gridErrors);

						//mam 07072011 - if the save failed, get out
						if (newComponent == null)
						{
							//mam 03202012 - let's use this, and call it from the ui thread
							//mam 07072011 - commented for testing only
							//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
							//progressDisplay.Close();
							//progressDisplay = null;
							ProgressClose();

							//mam 03202012 - comment this - let's use the old progress display
							//mam 07072011 - replacement progress display
							//ProgressDisplayClose();

							//mam 03202012 - call messagebox from ui thread
							//MessageBox.Show(this, "An error occurred while saving the Component data.  The import has been stopped.", "Import Not Completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
							string message = "An error occurred while saving the Component data.  The import has been stopped.";
							ProgressErrorMessage(message);

							return;
						}

						//*************************************

						//mam 03202012
						if (c1FlexGridComponent[i, "RenameExistingComponent"] != null && (bool)c1FlexGridComponent[i, "RenameExistingComponent"])
						{
							RenameExistingComponent(newComponent, dataAccess, ref gridErrors);
						}

						//set additional properties in the existing import component object
						importComponent.ExistingID = newComponent.ID;

						//mam 07072011 - set default retired here
						importComponent.Retired = false;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["Retired"]))
							importComponent.Retired = (bool)c1FlexGridComponent[i, "Retired"];

						//mam 07072011 - set default LOS here
						importComponent.LOS = EnumHandlers.GetLOSRank(1);
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["LOS"]))
							importComponent.LOS = EnumHandlers.GetLOSRank((int)c1FlexGridComponent[i, "LOS"]);

						importComponent.RedundantAssets = 1;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["RedundantAssets"]))
						{
							if (c1FlexGridComponent[i, "RedundantAssets"] != null && c1FlexGridComponent[i, "RedundantAssets"].ToString().Length > 0)
							{
								importComponent.RedundantAssets = Convert.ToInt16(c1FlexGridComponent[i, "RedundantAssets"]);
							}
						}

						//mam 07072011
						//set default asset class here
						importComponent.AssetClass = string.Empty;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["AssetClass"]))
						{
							if (newComponent.MechStructDisciplines)
							{
								curValueString = c1FlexGridComponent[i, "AssetClass"] == null ? "" : c1FlexGridComponent[i, "AssetClass"].ToString();
								importComponent.AssetClass = curValueString;
							}
						}

						//if (c1FlexGridComponent[i, "CipPlanningMode"] != null && c1FlexGridComponent[i, "CipPlanningMode"].ToString().Length > 0)
						//{
						//	importComponent.CipPlanningMode = Convert.ToInt16(c1FlexGridComponent[i, "RedundantAssets"]);
						//}
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CipPlanningMode"]))
						//	importComponent.CipPlanningMode = c1FlexGridComponent[i, "CipPlanningMode"] == null? string.Empty: c1FlexGridComponent[i, "CipPlanningMode"].ToString();
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CipPlanningMode"]))
						//	importComponent.LOS = EnumHandlers.GetLOSRank((int)c1FlexGridComponent[i, "CipPlanningMode"]);


						//mam 07072011 - set the criticality score for each criticality in the criticalities array list
						for (int j = 0; j < arrayListCriticalities.Count; j++)
						{
							string critNumberString = ((CriticalityForImport)arrayListCriticalities[j]).CriticalityNumber.ToString();
							if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["Crit" + critNumberString]))
							{
								((CriticalityForImport)arrayListCriticalities[j]).SelectedCriticalityScore = (int)c1FlexGridComponent[i, "Crit" + critNumberString];
							}
						}
						//</mam>

						//mam 07072011 - no longer using four fixed crits
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CritPublic"]))
						//	importComponent.CritPublic = EnumHandlers.CritHealthFromIndex((int)c1FlexGridComponent[i, "CritPublic"]);
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CritEnvironment"]))
						//	importComponent.CritEnvironment = EnumHandlers.CritEnvironmentFromIndex((int)c1FlexGridComponent[i, "CritEnvironment"]);
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CritRepair"]))
						//	importComponent.CritRepair = EnumHandlers.CritRepairFromIndex((int)c1FlexGridComponent[i, "CritRepair"]);
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CritEffect"]))
						//	importComponent.CritEffect = EnumHandlers.CritEffectFromIndex((int)c1FlexGridComponent[i, "CritEffect"]);

						//mam 07072011 - set vuln properties here
						importComponent.Vulnerability = 0.0;
						importComponent.OverrideVulnerability = false;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["Vulnerability"]))
						{
							if (c1FlexGridComponent[i, "Vulnerability"] != null && c1FlexGridComponent[i, "Vulnerability"].ToString().Length > 0)
							{
								//importComponent.Vulnerability = (double)c1FlexGridComponent[i, "Vulnerability"];
								importComponent.Vulnerability = Convert.ToDouble(c1FlexGridComponent[i, "Vulnerability"].ToString().Trim());
								importComponent.OverrideVulnerability = true;
							}
						}

						//mam 07072011 - set default comments here
						importComponent.Comments = string.Empty;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["Comments"]))
							importComponent.Comments = c1FlexGridComponent[i, "Comments"] == null? string.Empty: c1FlexGridComponent[i, "Comments"].ToString();

						//mam 03202012
						importComponent.PhotoFileName = string.Empty;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["ComponentPhotoFileName"]))
						{
							importComponent.PhotoFileName = c1FlexGridComponent[i, "ComponentPhotoFileName"] == null? string.Empty: c1FlexGridComponent[i, "ComponentPhotoFileName"].ToString();
						}

						//mam 03202012
						importComponent.PhotoCaption = string.Empty;
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["ComponentPhotoCaption"]))
						{
							importComponent.PhotoCaption = c1FlexGridComponent[i, "ComponentPhotoCaption"] == null? string.Empty: c1FlexGridComponent[i, "ComponentPhotoCaption"].ToString();
						}

						//*************************************

						//set the properties in the newly-created component
						//importComponent.ComponentType
						//newComponent.MechStructDisciplines = importComponent.MechStructDisciplines;
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["Retired"]))
						//{
							newComponent.Retired = importComponent.Retired;
						//}
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["LOS"]))
						//{
							newComponent.LOS = importComponent.LOS;
						//}
						//if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["RedundantAssets"]))
						//{
							newComponent.RedundantAssetCount = importComponent.RedundantAssets;
						//}

						//mam 07072011
						if (CheckColumnImport(c1FlexGridComponent, i, c1FlexGridComponent.Cols["CipPlanningMode"]))
						{
							newComponent.CipPlanningId = importComponent.CipPlanningModeId;
						}
						if (newComponent.MechStructDisciplines)
						{
							newComponent.AssetClass = importComponent.AssetClass;
						}

						//mam 03202012
						newComponent.PhotoFileName = importComponent.PhotoFileName;
						newComponent.CaptionPhoto = importComponent.PhotoCaption;

						//mam 07072011 - no longer using the four fixed criticalities
						//	no need to save the new crit values to the newComponent because we are saving the crit values
						//	directly to the database in the SaveCriticalities method, below
						//newComponent.CritPublicHealth = importComponent.CritPublic;
						//newComponent.CritEnvironmental = importComponent.CritEnvironment;
						//newComponent.CritRepair = importComponent.CritRepair;
						//newComponent.CritCustEffect = importComponent.CritEffect;

						newComponent.OverrideVulnerability = importComponent.OverrideVulnerability;
						newComponent.Vulnerability = importComponent.Vulnerability;
						newComponent.Comments = importComponent.Comments;

						//mam 07072011 - save the criticality data to the database
						SaveCriticalities(newComponent);

						//mam 07072011 - added bool success
						//mam 102309 - don't do this - we are saving manually, directly below
						//apparently we are doing this
						success = newComponent.Save();

						//mam 07072011
						if (!success)
						{
							MajorComponent componentPreSave = new MajorComponent(newComponent.ID);
							((MainForm)this.parentForm).SetNodeTagMajorComponent(newComponent, componentPreSave);
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error importing Major Component " + newComponent.Name);
						}
					}
				}

				//add new PN components to the tree
				for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
				{
					if (stopImportingData)
					{
						break;
					}

					//mam 03202012 - don't update the progress display unless the row will be imported
					if (!Convert.ToBoolean(c1FlexGridComponentPN.Rows[i]["Import"]))
					{
						continue;
					}

					//this.Cursor = Cursors.WaitCursor;
					elapsedTime = DateTime.Now - elapsedTimeStart;

					//mam 03202012 - let's use this, and call it from the ui thread
					//mam 07072011 - commented for testing only
					//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
					//progressDisplay.UpdateCounter(elapsedTime);
					ProgressUpdate(elapsedTime);

					//mam 03202012 - comment this - let's use the old progress display
					//mam 07072011 - replacement progress display
					//UpdateCounter(elapsedTime);

					//mam 03202012 - already checked this above
					//if (Convert.ToBoolean(c1FlexGridComponentPN.Rows[i]["Import"])) //&& ((ImportFromTextFileComponent)c1FlexGridComponent.Rows[i]["ComponentName"]).ParentExists)
					{
						ImportFromTextFileProcess process = (ImportFromTextFileProcess)c1FlexGridComponentPN[i, "ProcessName"];
						if (process.ExistingID == 0 && !process.ImportThisItem)
						{
							continue;
						}
						//find the grid row component in the list dictionary and save the import info to the newly-created component
						ImportFromTextFileComponent importComponent = (ImportFromTextFileComponent)listDictComponentNames[
							Convert.ToInt32(c1FlexGridComponentPN.Rows[i]["TempID"])];

						//don't set the ProcessID
						//importComponent.ProcessID = ((ImportFromTextFileProcess)c1FlexGridComponentPN.GetData(i, "ProcessName")).ExistingID;

						curProcessID = ((ImportFromTextFileProcess)c1FlexGridComponentPN.GetData(i, "ProcessName")).ExistingID;

						if (CheckColumnImport(c1FlexGridComponentPN, i, c1FlexGridComponentPN.Cols["ComponentName"]))
							importComponent.ItemName = c1FlexGridComponentPN[i, "ComponentName"].ToString().Trim();
						importComponent.MechStructDisciplines = false;

						//*************************************

						//create the new component
						//mam 07072011 - added zero parameter for cipplanningid
						MajorComponent newComponent = (MajorComponent)((MainForm)this.parentForm).AddNodeForImportedData(
							WAM.UI.NodeType.MajorComponent, curProcessID, 
							importComponent.ItemName, importComponent.MechStructDisciplines, 0, ref gridErrors);

						//mam 07072011 - if the save failed, get out
						if (newComponent == null)
						{
							//mam 03202012 - let's use this, and call it from the ui thread
							//mam 07072011 - commented for testing only
							//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
							//progressDisplay.Close();
							//progressDisplay = null;
							ProgressClose();

							//mam 03202012 - comment this - let's use the old progress display
							//mam 07072011 - replacement progress display
							//ProgressDisplayClose();

							//mam 03202012 - call messagebox from ui thread
							//MessageBox.Show(this, "An error occurred while saving the Component data.  The import has been stopped.", "Import Not Completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
							string message = "An error occurred while saving the Component data.  The import has been stopped.";
							ProgressErrorMessage(message);

							return;
						}

						//*************************************

						//mam 03202012
						if (c1FlexGridComponentPN[i, "RenameExistingComponent"] != null && (bool)c1FlexGridComponentPN[i, "RenameExistingComponent"])
						{
							RenameExistingComponent(newComponent, dataAccess, ref gridErrors);
						}

						//set additional properties in the existing import component object
						importComponent.ExistingID = newComponent.ID;

						//mam 07072011 - set default retired here
						importComponent.Retired = false;
						if (CheckColumnImport(c1FlexGridComponentPN, i, c1FlexGridComponentPN.Cols["Retired"]))
							importComponent.Retired = (bool)c1FlexGridComponentPN[i, "Retired"];

						//mam 07072011 - set default comments here
						importComponent.Comments = string.Empty;
						if (CheckColumnImport(c1FlexGridComponentPN, i, c1FlexGridComponentPN.Cols["Comments"]))
							importComponent.Comments = c1FlexGridComponentPN[i, "Comments"] == null? string.Empty: c1FlexGridComponentPN[i, "Comments"].ToString();

						//mam 03202012
						importComponent.PhotoFileName = string.Empty;
						if (CheckColumnImport(c1FlexGridComponentPN, i, c1FlexGridComponentPN.Cols["ComponentPhotoFileName"]))
						{
							importComponent.PhotoFileName = c1FlexGridComponentPN[i, "ComponentPhotoFileName"] == null? string.Empty: c1FlexGridComponentPN[i, "ComponentPhotoFileName"].ToString();
						}

						//mam 03202012
						importComponent.PhotoCaption = string.Empty;
						if (CheckColumnImport(c1FlexGridComponentPN, i, c1FlexGridComponentPN.Cols["ComponentPhotoCaption"]))
						{
							importComponent.PhotoCaption = c1FlexGridComponentPN[i, "ComponentPhotoCaption"] == null? string.Empty: c1FlexGridComponentPN[i, "ComponentPhotoCaption"].ToString();
						}

						//*************************************

						//set the properties in the newly-created component
						//importComponent.ComponentType
						//newComponent.MechStructDisciplines = importComponent.MechStructDisciplines;
						newComponent.Retired = importComponent.Retired;
						newComponent.Comments = importComponent.Comments;

						//mam 03202012
						newComponent.PhotoFileName = importComponent.PhotoFileName;
						newComponent.CaptionPhoto = importComponent.PhotoCaption;

						//mam 07072011 - added bool success
						success = newComponent.Save();

						//mam 07072011
						if (!success)
						{
							MajorComponent componentPreSave = new MajorComponent(newComponent.ID);
							((MainForm)this.parentForm).SetNodeTagMajorComponent(newComponent, componentPreSave);
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error importing Major Component " + newComponent.Name);
						}
					}
				}

				//add data to the disciplines that were created when the components were imported
				for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
				{
					if (stopImportingData)
					{
						break;
					}

					//mam 03202012 - don't update the progress display unless the row will be imported
					if (!Convert.ToBoolean(c1FlexGridDiscipline.Rows[i]["Import"]))
					{
						continue;
					}

					//this.Cursor = Cursors.WaitCursor;
					elapsedTime = DateTime.Now - elapsedTimeStart;

					//mam 03202012 - let's use this, and call it from the ui thread
					//mam 07072011 - commented for testing only
					//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
					//progressDisplay.UpdateCounter(elapsedTime);
					ProgressUpdate(elapsedTime);

					//mam 03202012 - comment this - let's use the old progress display
					//mam 07072011 - replacement progress display
					//UpdateCounter(elapsedTime);

					//mam 03202012 - already checked this above
					//if (Convert.ToBoolean(c1FlexGridDiscipline.Rows[i]["Import"]))
					{
						ImportFromTextFileComponent component = (ImportFromTextFileComponent)c1FlexGridDiscipline[i, "ComponentName"];
						if (component.ExistingID == 0 && !component.ImportThisItem)
						{
							continue;
						}

						//determine the discipline type for the current row
						DisciplineType discType = WAM.Data.Discipline.GetDisciplineTypeFromInt(
							(int)c1FlexGridDiscipline.Rows[i]["DisciplineType"]);

						//get the disciplines for the component based on component id and discipline type
						Discipline[] disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ExistingID);

						//mam 07072011 - get the facility's current year
						MajorComponent tempComp = CacheManager.GetMajorComponent(component.InfoSetID, component.ExistingID);
						TreatmentProcess tempProc = CacheManager.GetTreatmentProcess(tempComp.InfoSetID, tempComp.ProcessID);
						short facilityYear = CacheManager.GetFacility(tempProc.InfoSetID, tempProc.FacilityID).CurrentYear;

						//mam 07072011
						if (disciplines.Length < 3)
						{
							bool mechExists = false;
							bool structExists = false;
							bool landExists = false;
							foreach (Discipline disc in disciplines)
							{
								if (disc.GetType() == typeof(DisciplineMech))
								{
									mechExists = true;
								}
								if (disc.GetType() == typeof(DisciplineStruct))
								{
									structExists = true;
								}
								if (disc.GetType() == typeof(DisciplineLand))
								{
									landExists = true;
								}
							}
							if (!mechExists)
							{
								Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Mechanical Discipline not created for Major Component " + component.ItemName);
							}
							if (!structExists)
							{
								Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Structural Discipline not created for Major Component " + component.ItemName);
							}
							if (!landExists)
							{
								Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Civil Discipline not created for Major Component " + component.ItemName);
							}
						}

						foreach (Discipline disc in disciplines)
						{
							if (discType == DisciplineType.Mechanical
								&& disc.GetType() == typeof(DisciplineMech))
							{
								ImportDisciplineMech((DisciplineMech)disc, i, component.CipPlanningModeId == zeroRehabCostCipPlanningId, facilityYear, ref gridErrors);
							}
							if (discType == DisciplineType.Structural
								&& disc.GetType() == typeof(DisciplineStruct))
							{
								ImportDisciplineStruct((DisciplineStruct)disc, i, component.CipPlanningModeId == zeroRehabCostCipPlanningId, facilityYear, ref gridErrors);
							}

							if (discType == DisciplineType.Land
								&& disc.GetType() == typeof(DisciplineLand))
							{
								ImportDisciplineLand((DisciplineLand)disc, i, component.CipPlanningModeId == zeroRehabCostCipPlanningId, facilityYear, ref gridErrors);
							}
						}
					}
				}

				ResetExistingIDsToZeroAfterImporting();

				//mam 03202012 - let's use this, and call it from the ui thread
				//mam 07072011 - commented for testing only
				//	leave it commented - the progress display modal form appears to sometimes cause the import form to freeze after the import is completed
				//progressDisplay.Close();
				//progressDisplay = null;
				ProgressClose();

				//mam 03202012 - comment this - let's use the old progress display
				//mam 07072011 - replacement progress display
				//ProgressDisplayClose();

				if (stopImportingData)
				{
					//mam 03202012 - call messagebox from ui thread
					ProgressMessage("The import has been stopped.");
				}
				else
				{
					if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
					{
						//mam 03202012 - call from ui thread!!!
						errorDisplay = new ErrorDisplayMessage(gridErrors, "Data was Imported but Errors Occurred", "Import Errors");
						errorDisplay.ShowInTaskbar = false;
						errorDisplay.ShowDialog(this);
					}
					else
					{
						//mam 03202012 - call messagebox from ui thread
						ProgressMessage("The data has been imported.");
					}
				}

				return;	// true;
			}
			catch(Exception ex)
			{
				//mam 03202012 - call messagebox from ui thread
				//MessageBox.Show(this, "An error occurred in ImportData2: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				string message = "An error occurred in ImportData2: " + ex.Message;
				ProgressErrorMessage(message);

				return;	// false;
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}

		//mam 07072011
		private void SaveCriticalities(MajorComponent newComponent)
		{
			//create an xml string to pass in to the stored procedure
			System.Text.StringBuilder xmlString = new System.Text.StringBuilder();
			xmlString.Append("<Criticalities>");
			int counter = 0;
			for (int j = 0; j < arrayListCriticalities.Count; j++)
			{
				string critNumberString = ((CriticalityForImport)arrayListCriticalities[j]).CriticalityNumber.ToString();
				if (CheckColumnImport(c1FlexGridComponent, j, c1FlexGridComponent.Cols["Crit" + critNumberString]))
				{
					counter++;
					int critId = ((CriticalityForImport)arrayListCriticalities[j]).CriticalityId;
					int score = ((CriticalityForImport)arrayListCriticalities[j]).SelectedCriticalityScore;

					//add data to xml string
					xmlString.AppendFormat("<Criticality CriticalityId=\"{0}\" CriticalityScore=\"{1}\" />", critId, score);
				}
			}
			xmlString.Append("</Criticalities>");

			if (counter > 0)
			{
				DataAccess dataAccess = new DataAccess();
				try
				{
					//save the criticality scores
					dataAccess.ExecuteCommandInsertCriticalityValuesComponent(newComponent.ID, xmlString.ToString(), true);

					System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityByComponent", "@componentId", newComponent.ID);
					newComponent.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesIntoCollection(dataTable);
				}
				catch (Exception ex)
				{
					string msg = "An error has occurred.  Criticality values may not have been saved." 
						+ Environment.NewLine + Environment.NewLine 
						+ ex.Message ;
					MessageBox.Show(this, msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				finally
				{
					dataAccess = null;
				}
			}
		}

		private bool ResetExistingIDsToZeroAfterImporting()
		{
			try
			{
				//go through each row in each grid and set the ExistingID to zero

				for (int i = c1FlexGridFacility.Rows.Fixed; i < c1FlexGridFacility.Rows.Count; i++)
				{
					((ImportFromTextFileFacility)listDictFacilityNamesAll[Convert.ToInt32(c1FlexGridFacility[i, "TempID"])]).ExistingID = 0;
				}
				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					((ImportFromTextFileProcess)listDictProcessNamesAll[Convert.ToInt32(c1FlexGridProcess[i, "TempID"])]).ExistingID = 0;
				}
				for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
				{
					((ImportFromTextFileComponent)listDictComponentNamesAll[Convert.ToInt32(c1FlexGridComponent[i, "TempID"])]).ExistingID = 0;
				}
				for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
				{
					((ImportFromTextFileComponent)listDictComponentNamesAll[Convert.ToInt32(c1FlexGridComponentPN[i, "TempID"])]).ExistingID = 0;
				}
				for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
				{
					((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[i, "TempID"])]).ExistingID = 0;
				}

				return true;
			}
			catch
			{
				return false;
			}
		}

		private bool CheckColumnImport(C1FlexGrid grid, int gridRow, Column gridColumnToImport)
		{
			try
			{
				bool importThisColumn = true;
				if (grid[gridRow, gridColumnToImport.Index] == null 
					|| grid[gridRow, gridColumnToImport.Index].ToString().Length == 0 
					//mam 07072011 - added "DontImportDefaultValue"
					//|| (gridColumnToImport.UserData != null && gridColumnToImport.UserData.ToString() == "DontImport"))
					|| (gridColumnToImport.UserData != null 
						&& (gridColumnToImport.UserData.ToString() == "DontImport" || gridColumnToImport.UserData.ToString() == "DontImportDefaultValue")))
				{
					importThisColumn = false;
				}
				return importThisColumn;
			}
			catch
			{
				return true;
			}
		}

		private bool CheckColumnImportDiscComponentInfo(C1FlexGrid grid, int gridRow, Column gridColumnToImport)
		{
			try
			{
				bool importThisColumn = true;
				//mam 07072011 - added "DontImportDefaultValue"
				//if (gridColumnToImport.UserData != null && gridColumnToImport.UserData.ToString() == "DontImport")
				if (gridColumnToImport.UserData != null 
					&& (gridColumnToImport.UserData.ToString() == "DontImport" || gridColumnToImport.UserData.ToString() == "DontImportDefaultValue"))
				{
					importThisColumn = false;
				}
				return importThisColumn;
			}
			catch
			{
				return true;
			}
		}

		//mam 07072011
		private bool CheckColumnImportRehab(C1FlexGrid grid, int gridRow, Column gridColumnToImport)
		{
			try
			{
				bool importThisColumn = true;
				if (gridColumnToImport.UserData != null 
					&& (gridColumnToImport.UserData.ToString() == "DontImport" 
					|| gridColumnToImport.UserData.ToString() == "DontImportDefaultValue"))
				{
					importThisColumn = false;
				}
				return importThisColumn;
			}
			catch
			{
				return true;
			}
		}

		private void ImportDisciplineMech(DisciplineMech discipline, int i, bool zeroRehab, short facilityYear, ref C1FlexGrid gridErrors)
		{
			C1FlexGrid grid = c1FlexGridDiscipline;

			//mam 07072011 - to allow any rehab values that exist in the import grid to be saved to the database, set the parent component's
			//	planning mode to something other than the id that causes rehab values to be set to zero
			//set it back after the discipline is saved, and set the rehab values to zero
			int planningId = 0;
			if (zeroRehab)
			{
				//importComponent.CipPlanningModeId = nonZeroRehabCostCipPlanningId;
				component = CacheManager.GetMajorComponent(discipline.InfoSetID, discipline.ComponentID);
				planningId = component.CipPlanningId;
				component.CipPlanningId = nonZeroRehabCostCipPlanningId;
			}

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AcquisitionCost"]))
			{
				//discipline.AcquisitionCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AcquisitionCost"]);
				if (grid[i, "AcquisitionCost"] != DBNull.Value 
					&& grid[i, "AcquisitionCost"] != null
					&& grid[i, "AcquisitionCost"].ToString().Length > 0)
				{
					discipline.OverrideAcquisitionCost = true;
					discipline.AcquisitionCost = Convert.ToDecimal(grid[i, "AcquisitionCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			{
				//discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
				if (grid[i, "CurrentValue"] != DBNull.Value 
					&& grid[i, "CurrentValue"] != null
					&& grid[i, "CurrentValue"].ToString().Length > 0)
				{
					discipline.OverrideCurrentValue = true;
					discipline.CurrentValue = Convert.ToDecimal(grid[i, "CurrentValue"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
				discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostYear"]))
				discipline.RehabCostYear = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabCostYear"]);

			//mam 07072011 - moved installation year and original useful life up from below so that their 
			//	values can be used to calculate rehab interval and last rehab year
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
				discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
				discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			//mam 07072011 - rehab interval and last rehab year are different from other values in that if they are null in the grid,
			//	we have to calculate a value for them (whereas other values just default to zero, and are already zero in the 
			//	discipline object).  rehab interval and last rehab year are zero in the discipline object - calculate them if 
			//	grid cells are null
			decimal rehabInterval = 0;
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabInterval"]))
			{
				if (c1FlexGridDiscipline[i, "RehabInterval"] == null || c1FlexGridDiscipline[i, "RehabInterval"].ToString() == "")
				{
					//calculate default rehab interval
					rehabInterval = LocalRehabIntervalDefault(discipline.OrgUsefulLife);
				}
				else
				{
					rehabInterval = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabInterval"]);
				}
				discipline.RehabInterval = rehabInterval;
			}
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabYearLast"]))
			{
				if (c1FlexGridDiscipline[i, "RehabYearLast"] == null || c1FlexGridDiscipline[i, "RehabYearLast"].ToString() == "")
				{
					//calculate default last rehab year
					//mam 01222012 - added -1 for inspection year parameter
					discipline.RehabYearLast = LocalRehabYearLastDefault(facilityYear, discipline.InstallationYear, rehabInterval, -1);
				}
				else
				{
					discipline.RehabYearLast = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabYearLast"]);
				}
			}

			//mam 01222012 - no longer allowing time to next rehab to be overridden
			////if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabNext"]))
			////	discipline.RehabNext = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabNext"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabNext"]))
			//{
			//	if (grid[i, "RehabNext"] != DBNull.Value 
			//		&& grid[i, "RehabNext"] != null
			//		&& grid[i, "RehabNext"].ToString().Length > 0)
			//	{
			//		//mam 01222012 - no longer using override for Time to Next Rehab
			//		//discipline.OverrideRehabNext = true;
			//
			//		discipline.RehabNext = Convert.ToDecimal(grid[i, "RehabNext"]);
			//	}
			//}
			//</mam>

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabYearNext"]))
			{
				if (grid[i, "RehabYearNext"] != DBNull.Value 
					&& grid[i, "RehabYearNext"] != null
					&& grid[i, "RehabYearNext"].ToString().Length > 0)
				{
					discipline.OverrideRehabYearNext = true;
					discipline.RehabYearNext = Convert.ToInt32(grid[i, "RehabYearNext"]);
				}
			}

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			{
				//discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
				if (grid[i, "RepairCost"] != DBNull.Value 
					&& grid[i, "RepairCost"] != null
					&& grid[i, "RepairCost"].ToString().Length > 0)
				{
					discipline.OverrideRepairCost = true;
					discipline.RepairCost = Convert.ToDecimal(grid[i, "RepairCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValue"]))
				discipline.ReplacementValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "ReplacementValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueYear"]))
				discipline.ReplacementValueYear = Convert.ToInt32(c1FlexGridDiscipline[i, "ReplacementValueYear"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["NextReplacementYear"]))
			{
				if (grid[i, "NextReplacementYear"] != DBNull.Value 
					&& grid[i, "NextReplacementYear"] != null
					&& grid[i, "NextReplacementYear"].ToString().Length > 0)
				{
					discipline.OverrideNextReplacementYear = true;
					discipline.NextReplacementYear = Convert.ToInt32(grid[i, "NextReplacementYear"]);
				}
			}

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueDesc"]))
				discipline.ReplacementValueDesc = c1FlexGridDiscipline[i, "ReplacementValueDesc"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostDesc"]))
				discipline.RehabCostDesc = c1FlexGridDiscipline[i, "RehabCostDesc"].ToString();

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["SalvageValue"]))
				discipline.SalvageValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "SalvageValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AnnualMaintCost"]))
				discipline.AnnualMaintCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AnnualMaintCost"]);

			//mam 07072011 - moved installation year and original useful life up so that their values can be used to calculate
			//	rehab interval and last rehab year
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
			//	discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
			//	discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InspectionDate"]))
				discipline.DateInspected = Convert.ToDateTime(c1FlexGridDiscipline[i, "InspectionDate"]);
			//discipline.LOS = EnumHandlers.GetLOSRank((int)c1FlexGridComponent[i, "LOS"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Condition"]))
				discipline.ConditionRanking = EnumHandlers.GetConditionRankFromSingleWord(c1FlexGridDiscipline[i, "Condition"].ToString());

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["EquipmentIDNumber"]))
				discipline.EquipmentNumber = c1FlexGridDiscipline[i, "EquipmentIDNumber"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Manufacturer"]))
				discipline.Manufacturer = c1FlexGridDiscipline[i, "Manufacturer"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunHours"]))
				discipline.RunHours = c1FlexGridDiscipline[i, "RunHours"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunningAtInspection"]))
				discipline.RunningAtInspect = Convert.ToBoolean(c1FlexGridDiscipline[i, "RunningAtInspection"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			//	discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
			//	discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			//	discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AssessedBy"]))
				discipline.AssessedBy = c1FlexGridDiscipline[i, "AssessedBy"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Comments"]))
				discipline.Comments = c1FlexGridDiscipline[i, "Comments"] == null? string.Empty: c1FlexGridDiscipline[i, "Comments"].ToString();

			//mam 03202012
			discipline.PhotoFileName = string.Empty;
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["DisciplinePhotoFileName"]))
			{
				discipline.PhotoFileName = c1FlexGridDiscipline[i, "DisciplinePhotoFileName"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoFileName"].ToString();
			}

			//mam 03202012
			discipline.CaptionPhoto = string.Empty;
			if (CheckColumnImport(c1FlexGridDiscipline, i, c1FlexGridDiscipline.Cols["DisciplinePhotoCaption"]))
			{
				discipline.CaptionPhoto = c1FlexGridDiscipline[i, "DisciplinePhotoCaption"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoCaption"].ToString();
			}

			ImportFromTextFileDiscipline gridRowDiscipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[i, "TempID"])]);
			
			if (CheckColumnImportDiscComponentInfo(grid, i, c1FlexGridDiscipline.Cols["DiscComponentInfo"]))
			{
				discipline.MechExcessiveVibration = gridRowDiscipline.MechExcessiveVibration;
				discipline.MechExcessiveNoise = gridRowDiscipline.MechExcessiveNoise;
				discipline.MechExcessiveCorrosion = gridRowDiscipline.MechExcessiveCorrosion;
				discipline.MechExcessiveLeaks = gridRowDiscipline.MechExcessiveLeaks;
				discipline.MechRunningHot = gridRowDiscipline.MechRunningHot;
				discipline.MechCanRunWhenInspected = gridRowDiscipline.MechCanRunWhenInspected;
				discipline.MechSupportIsFunctional = gridRowDiscipline.MechSupportIsFunctional;
				discipline.MechPartsMissing = gridRowDiscipline.MechPartsMissing;
				discipline.MechPartsAvailable = gridRowDiscipline.MechPartsAvailable;
				discipline.MechAdequate = gridRowDiscipline.MechAdequate;
				discipline.MechMotorAmps = gridRowDiscipline.MechMotorAmps;
				discipline.InstrIndicationFunctional = gridRowDiscipline.InstrIndicationFunctional;
				discipline.InstrAlarmFunctional = gridRowDiscipline.InstrAlarmFunctional;
				discipline.InstrPartsMissing = gridRowDiscipline.InstrPartsMissing;
				discipline.InstrPartsAvailable = gridRowDiscipline.InstrPartsAvailable;
				discipline.InstrSpareCapacity = gridRowDiscipline.InstrSpareCapacity;
				discipline.ElecExcessiveCorrosion = gridRowDiscipline.ElecExcessiveCorrosion;
				discipline.ElecCleanContacts = gridRowDiscipline.ElecCleanContacts;
				discipline.ElecPartsAvailable = gridRowDiscipline.ElecPartsAvailable;
				discipline.ElecSpareCapacity = gridRowDiscipline.ElecSpareCapacity;
				discipline.PipeExcessiveCorrosion = gridRowDiscipline.PipeExcessiveCorrosion;
				discipline.PipeExcessiveLeaks = gridRowDiscipline.PipeExcessiveLeaks;
				discipline.PipePaintGood = gridRowDiscipline.PipePaintGood;
			}

			//mam 07072011 - added bool success
			//mam 07072011 - apparently we are doing it
			//mam 102309 - don't do this - we are saving manually, directly below
			//mam 07072011 - this save will use the discipline's GetUpdateSql because the discipline has already been created
			//	GetUpdateSql looks at the database value for its parent component's cip planning id, and save the
			//	rehabinterval and rehabnext to the database, or not, depending on the cip planning id
			//	however, when importing, we want to save rehabinterval to the database always, regardless of cip
			//	and rehabnext when it is overridden
			//	so let's create a new Save routine in the disciplines that sets a discipline variable that GetUpdateSql can check
			//	to determine whether or not to write rehabinterval and rehabnext to the database
			//	instead of calling discipline.Save(), call discipline.SaveForImport();
			//bool success = discipline.Save();
			bool success = discipline.SaveForImport();

			//mam 07072011 - when importing, we want to save the actual values from the Excel file for rehab interval, rehab next,
			//	and rehab year next, but they are set to zero when the discipline sets the rehab values if the parent component's
			//	planning mode is replacement.  so, save the actual Excel file values above, and set the discipline rehab properties
			//	to zero here so we get the correct values in the database, and the correct values in the discipline cache
			if (zeroRehab)
			{
				component.CipPlanningId = planningId;
				discipline.RehabInterval = 0m;
				discipline.RehabNext = 0m;
				discipline.RehabYearNext = 0;
			}

			//mam 07072011
			if (!success)
			{
				DisciplineMech disciplinePreSave = new DisciplineMech(discipline.ID);
				((MainForm)this.parentForm).SetNodeTagDiscipline(discipline, disciplinePreSave);
				string rowData = "Error importing Mech Discipline for " 
					+ discipline.GetFacility().Name + @" / " 
					+ discipline.GetTreatmentProcess().Name + @" / " 
					+ discipline.GetMajorComponent().Name;
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, rowData);
			}

			//DataAccess dataAccess = new DataAccess();
			//dataAccess.ExecuteCommand(discipline.GetUpdateSqlForImport());
			//discipline = new DisciplineMech(discipline.ID);
		}

		private void ImportDisciplineStruct(DisciplineStruct discipline, int i, bool zeroRehab, short facilityYear, ref C1FlexGrid gridErrors)
		{
			C1FlexGrid grid = c1FlexGridDiscipline;

			//mam 07072011 - to allow any rehab values that exist in the import grid to be saved to the database, set the parent component's
			//	planning mode to something other than the id that causes rehab values to be set to zero
			//set it back after the discipline is saved, and set the rehab values to zero
			int planningId = 0;
			if (zeroRehab)
			{
				//importComponent.CipPlanningModeId = nonZeroRehabCostCipPlanningId;
				component = CacheManager.GetMajorComponent(discipline.InfoSetID, discipline.ComponentID);
				planningId = component.CipPlanningId;
				component.CipPlanningId = nonZeroRehabCostCipPlanningId;
			}

			if (CheckColumnImport(grid, i, grid.Cols["AcquisitionCost"]))
			{
				//discipline.AcquisitionCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AcquisitionCost"]);
				if (grid[i, "AcquisitionCost"] != DBNull.Value 
					&& grid[i, "AcquisitionCost"] != null
					&& grid[i, "AcquisitionCost"].ToString().Length > 0)
				{
					discipline.OverrideAcquisitionCost = true;
					discipline.AcquisitionCost = Convert.ToDecimal(grid[i, "AcquisitionCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			{
				//discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
				if (grid[i, "CurrentValue"] != DBNull.Value 
					&& grid[i, "CurrentValue"] != null
					&& grid[i, "CurrentValue"].ToString().Length > 0)
				{
					discipline.OverrideCurrentValue = true;
					discipline.CurrentValue = Convert.ToDecimal(grid[i, "CurrentValue"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
				discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostYear"]))
				discipline.RehabCostYear = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabCostYear"]);

			//mam 07072011 - moved installation year and original useful life up from below so that their 
			//	values can be used to calculate rehab interval and last rehab year
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
				discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
				discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			//mam 07072011 - rehab interval and last rehab year are different from other values in that if they are null in the grid,
			//	we have to calculate a value for them (whereas other values just default to zero, and are already zero in the 
			//	discipline object).  rehab interval and last rehab year are zero in the discipline object - calculate them if 
			//	grid cells are null
			decimal rehabInterval = 0m;
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabInterval"]))
			{
				if (c1FlexGridDiscipline[i, "RehabInterval"] == null || c1FlexGridDiscipline[i, "RehabInterval"].ToString() == "")
				{
					//calculate default rehab interval
					rehabInterval = LocalRehabIntervalDefault(discipline.OrgUsefulLife);
				}
				else
				{
					rehabInterval = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabInterval"]);
				}
				discipline.RehabInterval = rehabInterval;
			}
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabYearLast"]))
			{
				if (c1FlexGridDiscipline[i, "RehabYearLast"] == null || c1FlexGridDiscipline[i, "RehabYearLast"].ToString() == "")
				{
					//calculate default last rehab year
					//mam 01222012 - added -1 for inspection year parameter
					discipline.RehabYearLast = LocalRehabYearLastDefault(facilityYear, discipline.InstallationYear, rehabInterval, -1);
				}
				else
				{
					discipline.RehabYearLast = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabYearLast"]);
				}
			}

			//mam 01222012 - no longer allowing time to next rehab to be overridden
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabNext"]))
			//{
			//	if (grid[i, "RehabNext"] != DBNull.Value 
			//		&& grid[i, "RehabNext"] != null
			//		&& grid[i, "RehabNext"].ToString().Length > 0)
			//	{
			//		//mam 01222012 - no longer using override for Time to Next Rehab
			//		//discipline.OverrideRehabNext = true;
			//
			//		discipline.RehabNext = Convert.ToDecimal(grid[i, "RehabNext"]);
			//	}
			//}
			//</mam>

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabYearNext"]))
			{
				if (grid[i, "RehabYearNext"] != DBNull.Value 
					&& grid[i, "RehabYearNext"] != null
					&& grid[i, "RehabYearNext"].ToString().Length > 0)
				{
					discipline.OverrideRehabYearNext = true;
					discipline.RehabYearNext = Convert.ToInt32(grid[i, "RehabYearNext"]);
				}
			}

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			{
				//discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
				if (grid[i, "RepairCost"] != DBNull.Value 
					&& grid[i, "RepairCost"] != null
					&& grid[i, "RepairCost"].ToString().Length > 0)
				{
					discipline.OverrideRepairCost = true;
					discipline.RepairCost = Convert.ToDecimal(grid[i, "RepairCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValue"]))
				discipline.ReplacementValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "ReplacementValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueYear"]))
				discipline.ReplacementValueYear = Convert.ToInt32(c1FlexGridDiscipline[i, "ReplacementValueYear"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["NextReplacementYear"]))
			{
				if (grid[i, "NextReplacementYear"] != DBNull.Value 
					&& grid[i, "NextReplacementYear"] != null
					&& grid[i, "NextReplacementYear"].ToString().Length > 0)
				{
					discipline.OverrideNextReplacementYear = true;
					discipline.NextReplacementYear = Convert.ToInt32(grid[i, "NextReplacementYear"]);
				}
			}

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueDesc"]))
				discipline.ReplacementValueDesc = c1FlexGridDiscipline[i, "ReplacementValueDesc"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostDesc"]))
				discipline.RehabCostDesc = c1FlexGridDiscipline[i, "RehabCostDesc"].ToString();

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["SalvageValue"]))
				discipline.SalvageValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "SalvageValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AnnualMaintCost"]))
				discipline.AnnualMaintCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AnnualMaintCost"]);

			//mam 07072011 - moved installation year and original useful life up so that their values can be used to calculate
			//	rehab interval and last rehab year
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
			//	discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
			//	discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InspectionDate"]))
				discipline.DateInspected = Convert.ToDateTime(c1FlexGridDiscipline[i, "InspectionDate"]);
			//discipline.LOS = EnumHandlers.GetLOSRank((int)c1FlexGridComponent[i, "LOS"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Condition"]))
				discipline.ConditionRanking = EnumHandlers.GetConditionRankFromSingleWord(c1FlexGridDiscipline[i, "Condition"].ToString());

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["EquipmentIDNumber"]))
				discipline.EquipmentNumber = c1FlexGridDiscipline[i, "EquipmentIDNumber"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Manufacturer"]))
				discipline.Manufacturer = c1FlexGridDiscipline[i, "Manufacturer"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunHours"]))
				discipline.RunHours = c1FlexGridDiscipline[i, "RunHours"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunningAtInspection"]))
				discipline.RunningAtInspect = Convert.ToBoolean(c1FlexGridDiscipline[i, "RunningAtInspection"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			//discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
			//discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			//discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AssessedBy"]))
				discipline.AssessedBy = c1FlexGridDiscipline[i, "AssessedBy"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Comments"]))
				discipline.Comments = c1FlexGridDiscipline[i, "Comments"] == null? string.Empty: c1FlexGridDiscipline[i, "Comments"].ToString();

			//mam 03202012
			discipline.PhotoFileName = string.Empty;
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["DisciplinePhotoFileName"]))
			{
				discipline.PhotoFileName = c1FlexGridDiscipline[i, "DisciplinePhotoFileName"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoFileName"].ToString();
			}

			//mam 03202012
			discipline.CaptionPhoto = string.Empty;
			if (CheckColumnImport(c1FlexGridDiscipline, i, c1FlexGridDiscipline.Cols["DisciplinePhotoCaption"]))
			{
				discipline.CaptionPhoto = c1FlexGridDiscipline[i, "DisciplinePhotoCaption"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoCaption"].ToString();
			}

			ImportFromTextFileDiscipline gridRowDiscipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[i, "TempID"])]);

			if (CheckColumnImportDiscComponentInfo(grid, i, c1FlexGridDiscipline.Cols["DiscComponentInfo"]))
			{
				discipline.ConcreteSpalling = gridRowDiscipline.ConcreteSpalling;
				discipline.StructExcessiveCorrosion = gridRowDiscipline.StructExcessiveCorrosion;
				discipline.MembExcessiveCorrosion = gridRowDiscipline.MembExcessiveCorrosion;
				discipline.CorrosionCoating = gridRowDiscipline.CorrosionCoating;
				discipline.PaintGood = gridRowDiscipline.PaintGood;
				discipline.VisibleDeformities = gridRowDiscipline.VisibleDeformities;
				discipline.SettingEvident = gridRowDiscipline.SettingEvident;
				discipline.RoofExcessiveDegradation = gridRowDiscipline.RoofExcessiveDegradation;
				discipline.MajorCracks = gridRowDiscipline.MajorCracks;
			}


			//mam 07072011 - added bool success
			//mam 07072011 - apparently we are doing it
			//mam 102309 - don't do this - we are saving manually, directly below
			//mam 07072011 - this save will use the discipline's GetUpdateSql because the discipline has already been created
			//	GetUpdateSql looks at the database value for its parent component's cip planning id, and save the
			//	rehabinterval and rehabnext to the database, or not, depending on the cip planning id
			//	however, when importing, we want to save rehabinterval to the database always, regardless of cip
			//	and rehabnext when it is overridden
			//	so let's create a new Save routine in the disciplines that sets a discipline variable that GetUpdateSql can check
			//	to determine whether or not to write rehabinterval and rehabnext to the database
			//	instead of calling discipline.Save(), call discipline.SaveForImport();
			//bool success = discipline.Save();
			bool success = discipline.SaveForImport();

			//mam 07072011 - when importing, we want to save the actual values from the Excel file for rehab interval, rehab next,
			//	and rehab year next, but they are set to zero when the discipline sets the rehab values if the parent component's
			//	planning mode is replacement.  so, save the actual Excel file values above, and set the discipline rehab properties
			//	to zero here so we get the correct values in the database, and the correct values in the discipline cache
			if (zeroRehab)
			{
				component.CipPlanningId = planningId;
				discipline.RehabInterval = 0m;
				discipline.RehabNext = 0m;
				discipline.RehabYearNext = 0;
			}

			//mam 07072011
			if (!success)
			{
				DisciplineStruct disciplinePreSave = new DisciplineStruct(discipline.ID);
				((MainForm)this.parentForm).SetNodeTagDiscipline(discipline, disciplinePreSave);
				string rowData = "Error importing Struct Discipline for " 
					+ discipline.GetFacility().Name + @" / " 
					+ discipline.GetTreatmentProcess().Name + @" / " 
					+ discipline.GetMajorComponent().Name;
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, rowData);
			}

			//DataAccess dataAccess = new DataAccess();
			//dataAccess.ExecuteCommand(discipline.GetUpdateSqlForImport());
			//discipline = new DisciplineStruct(discipline.ID);
		}

		private void ImportDisciplineLand(DisciplineLand discipline, int i, bool zeroRehab, short facilityYear, ref C1FlexGrid gridErrors)
		{
			C1FlexGrid grid = c1FlexGridDiscipline;

			//mam 07072011 - to allow any rehab values that exist in the import grid to be saved to the database, set the parent component's
			//	planning mode to something other than the id that causes rehab values to be set to zero
			//set it back after the discipline is saved, and set the rehab values to zero
			int planningId = 0;
			if (zeroRehab)
			{
				//importComponent.CipPlanningModeId = nonZeroRehabCostCipPlanningId;
				component = CacheManager.GetMajorComponent(discipline.InfoSetID, discipline.ComponentID);
				planningId = component.CipPlanningId;
				component.CipPlanningId = nonZeroRehabCostCipPlanningId;
			}

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AcquisitionCost"]))
			{
				//discipline.AcquisitionCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AcquisitionCost"]);
				if (grid[i, "AcquisitionCost"] != DBNull.Value 
					&& grid[i, "AcquisitionCost"] != null
					&& grid[i, "AcquisitionCost"].ToString().Length > 0)
				{
					discipline.OverrideAcquisitionCost = true;
					discipline.AcquisitionCost = Convert.ToDecimal(grid[i, "AcquisitionCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			{
				//discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
				if (grid[i, "CurrentValue"] != DBNull.Value 
					&& grid[i, "CurrentValue"] != null
					&& grid[i, "CurrentValue"].ToString().Length > 0)
				{
					discipline.OverrideCurrentValue = true;
					discipline.CurrentValue = Convert.ToDecimal(grid[i, "CurrentValue"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
				discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostYear"]))
				discipline.RehabCostYear = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabCostYear"]);

			//mam 07072011 - moved installation year and original useful life up from below so that their 
			//	values can be used to calculate rehab interval and last rehab year
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
				discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
				discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			//mam 07072011 - rehab interval and last rehab year are different from other values in that if they are null in the grid,
			//	we have to calculate a value for them (whereas other values just default to zero, and are already zero in the 
			//	discipline object).  rehab interval and last rehab year are zero in the discipline object - calculate them if 
			//	grid cells are null
			decimal rehabInterval = 0m;
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabInterval"]))
			{
				if (c1FlexGridDiscipline[i, "RehabInterval"] == null || c1FlexGridDiscipline[i, "RehabInterval"].ToString() == "")
				{
					//calculate default rehab interval
					rehabInterval = LocalRehabIntervalDefault(discipline.OrgUsefulLife);
				}
				else
				{
					rehabInterval = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabInterval"]);
				}
				discipline.RehabInterval = rehabInterval;
			}
			if (CheckColumnImportRehab(grid, i, c1FlexGridDiscipline.Cols["RehabYearLast"]))
			{
				if (c1FlexGridDiscipline[i, "RehabYearLast"] == null || c1FlexGridDiscipline[i, "RehabYearLast"].ToString() == "")
				{
					//calculate default last rehab year
					//mam 01222012 - added -1 for inspection year parameter
					discipline.RehabYearLast = LocalRehabYearLastDefault(facilityYear, discipline.InstallationYear, rehabInterval, -1);
				}
				else
				{
					discipline.RehabYearLast = Convert.ToInt32(c1FlexGridDiscipline[i, "RehabYearLast"]);
				}
			}

			//mam 01222012 - no longer allowing time to next rehab to be overridden
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabNext"]))
			//{
			//	if (grid[i, "RehabNext"] != DBNull.Value 
			//		&& grid[i, "RehabNext"] != null
			//		&& grid[i, "RehabNext"].ToString().Length > 0)
			//	{
			//		//mam 01222012 - no longer using override for Time to Next Rehab
			//		//discipline.OverrideRehabNext = true;
			//
			//		discipline.RehabNext = Convert.ToDecimal(grid[i, "RehabNext"]);
			//	}
			//}
			//</mam>

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabYearNext"]))
			{
				if (grid[i, "RehabYearNext"] != DBNull.Value 
					&& grid[i, "RehabYearNext"] != null
					&& grid[i, "RehabYearNext"].ToString().Length > 0)
				{
					discipline.OverrideRehabYearNext = true;
					discipline.RehabYearNext = Convert.ToInt32(grid[i, "RehabYearNext"]);
				}
			}

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			{
				//discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
				if (grid[i, "RepairCost"] != DBNull.Value 
					&& grid[i, "RepairCost"] != null
					&& grid[i, "RepairCost"].ToString().Length > 0)
				{
					discipline.OverrideRepairCost = true;
					discipline.RepairCost = Convert.ToDecimal(grid[i, "RepairCost"]);
				}
			}
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValue"]))
				discipline.ReplacementValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "ReplacementValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueYear"]))
				discipline.ReplacementValueYear = Convert.ToInt32(c1FlexGridDiscipline[i, "ReplacementValueYear"]);

			//mam 07072011
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["NextReplacementYear"]))
			{
				if (grid[i, "NextReplacementYear"] != DBNull.Value 
					&& grid[i, "NextReplacementYear"] != null
					&& grid[i, "NextReplacementYear"].ToString().Length > 0)
				{
					discipline.OverrideNextReplacementYear = true;
					discipline.NextReplacementYear = Convert.ToInt32(grid[i, "NextReplacementYear"]);
				}
			}

			//mam 01222012
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["ReplacementValueDesc"]))
				discipline.ReplacementValueDesc = c1FlexGridDiscipline[i, "ReplacementValueDesc"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCostDesc"]))
				discipline.RehabCostDesc = c1FlexGridDiscipline[i, "RehabCostDesc"].ToString();

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["SalvageValue"]))
				discipline.SalvageValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "SalvageValue"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AnnualMaintCost"]))
				discipline.AnnualMaintCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "AnnualMaintCost"]);

			//mam 07072011 - moved installation year and original useful life up so that their values can be used to calculate
			//	rehab interval and last rehab year
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InstallationYear"]))
			//	discipline.InstallationYear = Convert.ToInt16(c1FlexGridDiscipline[i, "InstallationYear"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["OriginalUsefulLife"]))
			//	discipline.OrgUsefulLife = Convert.ToInt16(c1FlexGridDiscipline[i, "OriginalUsefulLife"]);

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["InspectionDate"]))
				discipline.DateInspected = Convert.ToDateTime(c1FlexGridDiscipline[i, "InspectionDate"]);
			//discipline.LOS = EnumHandlers.GetLOSRank((int)c1FlexGridComponent[i, "LOS"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Condition"]))
				discipline.ConditionRanking = EnumHandlers.GetConditionRankFromSingleWord(c1FlexGridDiscipline[i, "Condition"].ToString());

			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["EquipmentIDNumber"]))
				discipline.EquipmentNumber = c1FlexGridDiscipline[i, "EquipmentIDNumber"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Manufacturer"]))
				discipline.Manufacturer = c1FlexGridDiscipline[i, "Manufacturer"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunHours"]))
				discipline.RunHours = c1FlexGridDiscipline[i, "RunHours"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RunningAtInspection"]))
				discipline.RunningAtInspect = Convert.ToBoolean(c1FlexGridDiscipline[i, "RunningAtInspection"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["CurrentValue"]))
			//	discipline.CurrentValue = Convert.ToDecimal(c1FlexGridDiscipline[i, "CurrentValue"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RehabCost"]))
			//	discipline.RehabCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RehabCost"]);
			//if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["RepairCost"]))
			//	discipline.RepairCost = Convert.ToDecimal(c1FlexGridDiscipline[i, "RepairCost"]);
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["AssessedBy"]))
				discipline.AssessedBy = c1FlexGridDiscipline[i, "AssessedBy"].ToString();
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["Comments"]))
				discipline.Comments = c1FlexGridDiscipline[i, "Comments"] == null? string.Empty: c1FlexGridDiscipline[i, "Comments"].ToString();

			//mam 03202012
			discipline.PhotoFileName = string.Empty;
			if (CheckColumnImport(grid, i, c1FlexGridDiscipline.Cols["DisciplinePhotoFileName"]))
			{
				discipline.PhotoFileName = c1FlexGridDiscipline[i, "DisciplinePhotoFileName"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoFileName"].ToString();
			}

			//mam 03202012
			discipline.CaptionPhoto1 = string.Empty;
			if (CheckColumnImport(c1FlexGridDiscipline, i, c1FlexGridDiscipline.Cols["DisciplinePhotoCaption"]))
			{
				discipline.CaptionPhoto1 = c1FlexGridDiscipline[i, "DisciplinePhotoCaption"] == null? string.Empty: c1FlexGridDiscipline[i, "DisciplinePhotoCaption"].ToString();
			}

			ImportFromTextFileDiscipline gridRowDiscipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[i, "TempID"])]);

			if (CheckColumnImportDiscComponentInfo(grid, i, c1FlexGridDiscipline.Cols["DiscComponentInfo"]))
			{
				discipline.SeveralPotholes = gridRowDiscipline.SeveralPotholes;
				discipline.ExcessiveErosion = gridRowDiscipline.ExcessiveErosion;
				discipline.RoadDegradation = gridRowDiscipline.RoadDegradation;
				discipline.ExpansionSpace = gridRowDiscipline.ExpansionSpace;
				discipline.FunctionCover = gridRowDiscipline.FunctionCover;
				discipline.FencingAdequate = gridRowDiscipline.FencingAdequate;
				discipline.FacilitiesSecure = gridRowDiscipline.FacilitiesSecure;
				discipline.LandAppClayLiner = gridRowDiscipline.LandAppClayLiner;
				discipline.LandAppBermErosionInterior = gridRowDiscipline.LandAppBermErosionInterior;
				discipline.LandAppBermErosionBermExterior = gridRowDiscipline.LandAppBermErosionBermExterior;
				discipline.LandAppBermVegetation = gridRowDiscipline.LandAppBermVegetation;
				discipline.LandAppBermSettlement = gridRowDiscipline.LandAppBermSettlement;
				discipline.LandAppBermSeepage = gridRowDiscipline.LandAppBermSeepage;
				discipline.LandAppBurrowHoles = gridRowDiscipline.LandAppBurrowHoles;
				discipline.LandAppErosionProtectionPresent = gridRowDiscipline.LandAppErosionProtectionPresent;
				discipline.LandAppErosionProtectionAdequate = gridRowDiscipline.LandAppErosionProtectionAdequate;
				discipline.LandAppAlgalBlooms = gridRowDiscipline.LandAppAlgalBlooms;
				discipline.LandAppDrainageAdequate = gridRowDiscipline.LandAppDrainageAdequate;
			}

			//mam 07072011 - added bool success
			//mam 07072011 - apparently we are doing it
			//mam 102309 - don't do this - we are saving manually, directly below
			//mam 07072011 - this save will use the discipline's GetUpdateSql because the discipline has already been created
			//	GetUpdateSql looks at the database value for its parent component's cip planning id, and save the
			//	rehabinterval and rehabnext to the database, or not, depending on the cip planning id
			//	however, when importing, we want to save rehabinterval to the database always, regardless of cip
			//	and rehabnext when it is overridden
			//	so let's create a new Save routine in the disciplines that sets a discipline variable that GetUpdateSql can check
			//	to determine whether or not to write rehabinterval and rehabnext to the database
			//	instead of calling discipline.Save(), call discipline.SaveForImport();
			//bool success = discipline.Save();
			bool success = discipline.SaveForImport();

			//mam 07072011 - when importing, we want to save the actual values from the Excel file for rehab interval, rehab next,
			//	and rehab year next, but they are set to zero when the discipline sets the rehab values if the parent component's
			//	planning mode is replacement.  so, save the actual Excel file values above, and set the discipline rehab properties
			//	to zero here so we get the correct values in the database, and the correct values in the discipline cache
			if (zeroRehab)
			{
				component.CipPlanningId = planningId;
				discipline.RehabInterval = 0m;
				discipline.RehabNext = 0m;
				discipline.RehabYearNext = 0;
			}

			//mam 07072011
			if (!success)
			{
				DisciplineLand disciplinePreSave = new DisciplineLand(discipline.ID);
				((MainForm)this.parentForm).SetNodeTagDiscipline(discipline, disciplinePreSave);
				string rowData = "Error importing Civil Discipline for " 
					+ discipline.GetFacility().Name + @" / " 
					+ discipline.GetTreatmentProcess().Name + @" / " 
					+ discipline.GetMajorComponent().Name;
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, rowData);

			}

			//DataAccess dataAccess = new DataAccess();
			//dataAccess.ExecuteCommand(discipline.GetUpdateSqlForImport());
			//discipline = new DisciplineLand(discipline.ID);
		}

		#endregion /***** Import the Data *****/

		#region /***** Load Excel Sheet *****/

		private void LoadExcelFileSampleData(string fileToLoad)
		{
			try
			{
				excelBookSampleData.Clear();

				//load the excel sample file
				excelBookSampleData.Load(fileToLoad);

				C1FlexGrid flex = new C1FlexGrid();
				XLSheet sheet = excelBookSampleData.Sheets[0];
				flex.Name = sheet.Name;

				//load sheet into new grid
				LoadSheet(flex, sheet, true, true);

				//set datasource
				c1FlexGridSampleData.DataSource = flex;

				SetToolbarButtonState();

				if (isInitialized)
				{
					MessageBox.Show(this, "The Sample Data was successfully reloaded into the Sample Data grid.", "Load Sample Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in LoadExcelFileSampleData: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		//mam 03202012
		private C1FlexGrid flexFacility = new C1FlexGrid();
		private C1FlexGrid flexProcess = new C1FlexGrid();
		private C1FlexGrid flexComponent = new C1FlexGrid();
		private C1FlexGrid flexComponentPn = new C1FlexGrid();
		private C1FlexGrid flexDiscMech = new C1FlexGrid();
		private C1FlexGrid flexDiscStruct = new C1FlexGrid();
		private C1FlexGrid flexDiscLand = new C1FlexGrid();

		//mam 03202012 - if WAM System worksheets exist in the Excel file, load them and combine them into one grid
		private C1FlexGrid CreateSystemSpreadsheet()
		{
			bool createAggregate = false;

			//if the excel file has at least two sheets that have the same name as the WAM system sheets, combine the sheets into one grid
			int sheetFoundCount = 0;
			foreach (XLSheet sheet in excelBook.Sheets)
			{
				for (int i = 0; i < WAM.Common.Globals.SortedListExportImportTabNames.Count; i++)
				{
					if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[i].ToString(), true) == 0)
					{
						sheetFoundCount++;
					}
				}
			}

			C1FlexGrid flexAll = new C1FlexGrid();
			flexAll.Cols.Count = 1;
			flexAll.Rows.Count = 1;
			flexAll.Cols.Fixed = 1;
			flexAll.Rows.Fixed = 1;

			//Facility
			//Process
			//CompMSC
			//CompPN
			//Mechanical
			//Structural
			//Civil

			if (sheetFoundCount > 1)
			{
				//return flexAll;
				createAggregate = true;
			}

			//*****************

			//C1FlexGrid flexAll = new C1FlexGrid();
			//flexAll.Cols.Count = 1;
			//flexAll.Rows.Count = 1;
			//flexAll.Cols.Fixed = 1;
			//flexAll.Rows.Fixed = 1;
			Column newGridCol = flexAll.Cols.Add();
			newGridCol.Name	= "Type";
			newGridCol.Caption = "Type";

			C1FlexGrid gridCurrent = new C1FlexGrid();

			ArrayList arrayListGridTypes = new ArrayList();
			arrayListGridTypes.Add("Facility");
			arrayListGridTypes.Add("Process");
			arrayListGridTypes.Add("CompMSC");
			arrayListGridTypes.Add("CompPN");
			arrayListGridTypes.Add("Mechanical");
			arrayListGridTypes.Add("Structural");
			arrayListGridTypes.Add("Civil");

			//C1FlexGrid flexFacility = new C1FlexGrid();
			//C1FlexGrid flexProcess = new C1FlexGrid();
			//C1FlexGrid flexComponent = new C1FlexGrid();
			//C1FlexGrid flexComponentPn = new C1FlexGrid();
			//C1FlexGrid flexDiscMech = new C1FlexGrid();
			//C1FlexGrid flexDiscStruct = new C1FlexGrid();
			//C1FlexGrid flexDiscLand = new C1FlexGrid();

			int gridNumber = 0;

			//if the sheet is a WAM system sheet, load it into a grid
			foreach (XLSheet sheet in excelBook.Sheets)
			{
				bool sheetFound = false;

				ArrayList arrayListSpreadsheetGridsSystemTabs = new ArrayList();

				//if (sheet.Name == "WAM System Facility")
				//if (sheet.Name == multiSheetNameFacility)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[0].ToString(), true) == 0)
				{
					//flexFacility.Name = sheet.Name;
					flexFacility.Name = WAM.Common.Globals.SortedListExportImportTabNames[0].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexFacility);

					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					//mam 12262012 - for testing only!!!
					//WriteDataFromStructGrid(3);

					LoadSheet(flexFacility, sheet, true, false);
					gridCurrent = flexFacility;
					gridNumber = 0;
					sheetFound = true;
				}
				//else if (sheet.Name == "WAM System Process")
				//else if (sheet.Name == multiSheetNameProcess)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[1].ToString(), true) == 0)
				{
					//flexProcess.Name = sheet.Name;
					flexProcess.Name = WAM.Common.Globals.SortedListExportImportTabNames[1].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexProcess);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					LoadSheet(flexProcess, sheet, true, false);
					gridCurrent = flexProcess;
					gridNumber = 1;
					sheetFound = true;
				}
				//else if (sheet.Name == "WAM System Component MSC")
				//else if (sheet.Name == multiSheetNameComponentMsc)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[2].ToString(), true) == 0)
				{
					//flexComponent.Name = sheet.Name;
					flexComponent.Name = WAM.Common.Globals.SortedListExportImportTabNames[2].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexComponent);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					LoadSheet(flexComponent, sheet, true, false);
					gridCurrent = flexComponent;
					gridNumber = 2;
					sheetFound = true;
				}
				//else if (sheet.Name == "WAM System Component PN")
				//else if (sheet.Name == multiSheetNameComponentPn)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[3].ToString(), true) == 0)
				{
					//flexComponentPn.Name = sheet.Name;
					flexComponentPn.Name = WAM.Common.Globals.SortedListExportImportTabNames[3].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexComponentPn);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					LoadSheet(flexComponentPn, sheet, true, false);
					gridCurrent = flexComponentPn;
					gridNumber = 3;
					sheetFound = true;
				}
				//else if (sheet.Name == "WAM System Discipline Mech")
				//else if (sheet.Name == multiSheetNameDiscMech)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[4].ToString(), true) == 0)
				{
					//flexDiscMech.Name = sheet.Name;
					flexDiscMech.Name = WAM.Common.Globals.SortedListExportImportTabNames[4].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexDiscMech);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					LoadSheet(flexDiscMech, sheet, true, false);
					gridCurrent = flexDiscMech;
					gridNumber = 4;
					sheetFound = true;
				}
				//else if (sheet.Name == "WAM System Discipline Struct")
				//else if (sheet.Name == multiSheetNameDiscStruct)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[5].ToString(), true) == 0)
				{
					//flexDiscStruct.Name = sheet.Name;
					flexDiscStruct.Name = WAM.Common.Globals.SortedListExportImportTabNames[5].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexDiscStruct);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					//mam 12262012 - for testing only!!!
					//WriteDataFromStructGrid(4);

					LoadSheet(flexDiscStruct, sheet, true, false);
					gridCurrent = flexDiscStruct;
					gridNumber = 5;
					sheetFound = true;

					//mam 12262012 - for testing only!!!
					//WriteDataFromStructGrid(5);
				}
				//if (sheet.Name == "WAM System Discipline Civil")
				//else if (sheet.Name == multiSheetNameDiscCivil)
				if (string.Compare(sheet.Name, WAM.Common.Globals.SortedListExportImportTabNames[6].ToString(), true) == 0)
				{
					//flexDiscLand.Name = sheet.Name;
					flexDiscLand.Name = WAM.Common.Globals.SortedListExportImportTabNames[6].ToString();
					arrayListSpreadsheetGridsSystemTabs.Add(flexDiscLand);
					
					//mam 03202012 - unacceptable!!!
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return null;
					//}

					LoadSheet(flexDiscLand, sheet, true, false);
					gridCurrent = flexDiscLand;
					gridNumber = 6;
					sheetFound = true;
				}

				if (!sheetFound)
				{
					continue;
				}

				//mam 03202012 - unacceptable!!!
				////ProgressUpdateText2("Creating WAM Combined Spreadsheet");
				//labelProgress.Text = "Adding  '" + sheet.Name + "'  to WAM Combined Spreadsheet";
				//Application.DoEvents();
				//if (stopLoadingFromExcel)
				//{
				//	return null;
				//}

				// combine all WAM System grids into one grid, the flexAll grid

				//flexAll grid has one fixed col, and one fixed row, and one data col with name and caption = "Type"
				//the Type col will be populated by WAM, not by the Excel file

				//if the current grid has at least one row of data, add its column names to the flexAll grid
				//assume the first row has column names
				//row 0 is the fixed row
				//row 1 is the first data row (the column names row)
				if (gridCurrent.Rows.Count > 1 && createAggregate)
				{
					//start with colNumber = 1 because colNumber 0 is the fixed column
					for (int colNumber = 1; colNumber < gridCurrent.Cols.Count; colNumber++)
					{
						if (gridCurrent[1, colNumber] != null)
						{
							string colCaption = gridCurrent.GetData(1, colNumber).ToString().Trim();
							gridCurrent.Cols[colNumber].Name = colCaption;
							if (!flexAll.Cols.Contains(colCaption))
							{
								newGridCol = flexAll.Cols.Add();
								newGridCol.Name = colCaption;
								newGridCol.Caption = colCaption;
							}
						}
					}
				}

				//progressDisplayLoadExcel.UpdateText("in aggregate 1");

				if (gridCurrent.Rows.Count > 1)
				{
					//add a Type column to the current grid (if it already has one, delete it first)
					if (gridCurrent.Cols.Contains("Type"))
					{
						gridCurrent.Cols.Remove("Type");
					}
					newGridCol = gridCurrent.Cols.Insert(1);
					newGridCol.Name	= "Type";
					newGridCol.Caption = "Type";

					//add "Type" to the fixed row and the first data row
					gridCurrent.SetData(0, "Type", "Type");
					gridCurrent.SetData(1, "Type", "Type");
				}

				//progressDisplayLoadExcel.UpdateText("in aggregate 2");

				//comboBoxSheet.Items.Add(gridCurrent.Name);
				//arrayListSpreadsheetGrids.Add(gridCurrent);

				//if the current grid has additional rows, add the data to the flexAll grid
				//row 0 is the fixed row in the current grid
				//row 1 is the column names row in the current grid
				//row 2 is the first data row in the current grid
				string curGridType = arrayListGridTypes[gridNumber].ToString();
				for (int rowNumberSource = 2; rowNumberSource < gridCurrent.Rows.Count; rowNumberSource++)
				{
					//add the type string to the Type column for the current grid
					gridCurrent.SetData(rowNumberSource, "Type", curGridType);

					//if there are 0 or 1 WAM system spreadsheets, don't create the aggregate spreadsheet
					if (!createAggregate)
					{
						continue;
					}

					Row newGridRow = flexAll.Rows.Add();
					string rowData = "";

					flexAll[newGridRow.Index, "Type"] = arrayListGridTypes[gridNumber].ToString();
					for (int colNumberTarget = 2; colNumberTarget < flexAll.Cols.Count; colNumberTarget++)
					{
						string colName = flexAll.Cols[colNumberTarget].Name;
						if (gridCurrent.Cols.Contains(colName))
						{
							//flexAll.SetData(newGridRow.Index, colName, gridCurrent.GetData(rowNumberSource, colName));
							object curData = gridCurrent.GetData(rowNumberSource, colName);

							//mam 12262012 - for testing only!!!
//							try
//							{
//								System.Diagnostics.Debug.WriteLine("TEST " + gridCurrent.Name + "\t" + colName + "\t" + curData.ToString());
//							}
//							catch(Exception ex)
//							{
//								System.Diagnostics.Debug.WriteLine("TEST " + gridCurrent.Name + "\t" + colName + "\tERROR: " + ex.Message);
//							}
							//mam 12262012 - for testing only!!! end

							if (curData != null)
							{
								flexAll.SetData(newGridRow.Index, colName, curData);
								rowData += curData.ToString().Trim();
							}
						}
					}

					//if row is empty, remove it
					if (rowData == "")
					{
						flexAll.Rows.Remove(newGridRow);
					}
					//else
					//{
					//	gridCurrent.SetData(rowNumberSource, "Type", arrayListGridTypes[gridNumber].ToString());
					//}
				}

				//progressDisplayLoadExcel.UpdateText("after create aggregate");
			}

			//add a row that contains the column names
			Row rowCaption = flexAll.Rows.Insert(0);
			for (int i = 1; i < flexAll.Cols.Count; i++)
			{
				rowCaption[i] = flexAll.Cols[i].Name;
			}

			return flexAll;
		}

		private void LoadExcelFile(string fileToLoad, bool loadSampleGrid, bool forExport)
		{
			//mam 03202012
			//if WAM tabs exist, they have been consolidated into one grid, called WAM System Spreadsheet

			try
			{
				//mam 03202012
				stopLoadingFromExcel = false;

				if (forExport)
				{
					//clear the existing values
					excelBook.Clear();
					arrayListSpreadsheetGrids.Clear();
					comboBoxSheet.Items.Clear();
				}

				//clear everything
				excelBook.Clear();
				arrayListSpreadsheetGrids.Clear();
				comboBoxSheet.Items.Clear();

				//mam 03202012 - unacceptable!!!
				////ProgressUpdateText2("Loading Excel file");
				//labelProgress.Text = "Loading Excel file";
				//Application.DoEvents();

				//load the excel file
				excelBook.Load(fileToLoad);

				//mam 03202012 - unacceptable!!!
				////ProgressUpdateText2("Loading sample data");
				//labelProgress.Text = "Loading sample data";
				//Application.DoEvents();
				//if (stopLoadingFromExcel)
				//{
				//	return;
				//}

				//mam 03202012
				C1FlexGrid flexAll = new C1FlexGrid();
				if (!loadSampleGrid)
				{
					//progressDisplayLoadExcel.UpdateText("before create system spreadsheet");

					flexAll = CreateSystemSpreadsheet();

					//mam 03202012 - name the grid
					flexAll.Name = wamMultipleSpreadsheetName;

					//progressDisplayLoadExcel.UpdateText("after create system spreadsheet");

					if (flexAll != null && flexAll.Rows.Count > 2 && flexAll.Cols.Count > 2)
					{
						//comboBoxSheet.Items.Add("WAM System Spreadsheet");
						comboBoxSheet.Items.Add(wamMultipleSpreadsheetName);
						arrayListSpreadsheetGrids.Add(flexAll);
					}
				}

				//create one grid per sheet and add them to listbox
				foreach (XLSheet sheet in excelBook.Sheets)
				{
					//mam 03202012 - load each individual WAM system sheet in case the user 
					//	wants to load one of them into the import grid
					//(the grids have already been loaded from Excel in CreateSystemSpreadsheet)
					if (string.Compare(sheet.Name, multiSheetNameFacility, true) == 0)
					{
						//mam 12272012
						//the load process loads temporary Fac, Proc, Comp and Disc grids (flexFacility, flexProcess, flexComponent, flexComponentPn, flexDiscMech, flexDiscStruct, flexDiscLand)
                        //	with data from Excel, writes all of that data to a single grid, and then loads the data into other individual grids
						//	for display to the user
						//there are no fixed columns or column headers in the temporary grids; each column header is read into a data cell in each grid
						//	from Excel (along with the data as it is read from Excel)
						//a Type column is added to the temporary Fac, Proc, Comp, and Disc grids after the data is loaded from Excel, which
						//	moves all other columns one column to the right
						//the temporary grids are not cleared between loadings (the cells should be overwritten by the incoming data, but in the case
						//	of Excel cells that appear empty but cannot be read by WAM, WAM doesn't write a null to that cell in the temporary grids,
						//	and, since the temporary grids are not cleared between loadings, data from the previous loading will remain in a cell
						//	in the temporary grid that was not overwritten with incoming data from the current loading)
						//if the data is then read again from an Excel file with WAM-unreadable cells, the import grid will display the data that was
						//	not overwritten in the grid, and it will be the data from the previous column in the Excel file
						//the WAM-unreadable cells look blank in Excel, but there must be some hidden code or formatting in them that makes them
						//	unreadable to WAM
						//this problem occurs in WAM versions 4.3.0.0 and 4.3.1.0, and was fixed in version 4.3.2.0
						//the solution is to clear the temporary Fac, Proc, Comp and Disc grids before each load, and to write a null to each 
						//	cell in those grids that is unreadable in Excel (this writing of null to the unreadable cells should not be necessary
						//	as the grid will already have been cleared, but let's do it anyway for completeness)

						//mam 12272012
						//reset the grid
						flexFacility = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexFacility);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameProcess, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexProcess = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexProcess);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameComponentMsc, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexComponent = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexComponent);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameComponentPn, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexComponentPn = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexComponentPn);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameDiscMech, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexDiscMech = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexDiscMech);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameDiscStruct, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexDiscStruct = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexDiscStruct);
						continue;
					}
					if (string.Compare(sheet.Name, multiSheetNameDiscCivil, true) == 0)
					{
						//mam 12272012
						//reset the grid
						flexDiscLand = new C1FlexGrid();

						comboBoxSheet.Items.Add(sheet.Name);
						arrayListSpreadsheetGrids.Add(flexDiscLand);
						continue;
					}

					if (!loadSampleGrid)
					{
						//add sheet name to combo box
						comboBoxSheet.Items.Add(sheet.Name);
					}

					//create a new grid for the current sheet, and add it to the array list
					C1FlexGrid flex = new C1FlexGrid();
					flex.Name = sheet.Name;
					arrayListSpreadsheetGrids.Add(flex);

					//mam 03202012 - unacceptable!!!
					////ProgressUpdateText2("Loading Excel sheet  '" + sheet.Name + "'");
					//labelProgress.Text = "Loading Excel sheet  '" + sheet.Name + "'";
					//Application.DoEvents();
					//if (stopLoadingFromExcel)
					//{
					//	return;
					//}

					//load sheet into new grid
					LoadSheet(flex, sheet, true, loadSampleGrid);

					//progressDisplayLoadExcel.UpdateText("after load sheet " + sheet.Name);
				}

				//mam 03202012 - unacceptable!!!
				////ProgressUpdateText2("Loading data into import grids");
				//labelProgress.Text = "Loading data into import grids";
				//Application.DoEvents();
				//if (stopLoadingFromExcel)
				//{
				//	return;
				//}

				if (!loadSampleGrid)
				{
					codeHasRun = false;

					//mam 03202012 - need to assign selected index based on sheet name rather than worksheet index
					//	because the workbook may have WAM System worksheets which have been consolidated into one grid
					//select current sheet
					//comboBoxSheet.SelectedIndex = excelBook.Sheets.SelectedIndex;
					string selectedSheetName = excelBook.Sheets[excelBook.Sheets.SelectedIndex].Name;

					//************************
					//mam 03202012 - if the aggregate sheet exists, load it
					//mam 03202012 - if the selected Excel sheet is WAM.Common.Globals.SampleDataTabName, load a different tab

					if (string.Compare(comboBoxSheet.Items[0].ToString(), wamMultipleSpreadsheetName, true) == 0)
					{
						comboBoxSheet.SelectedIndex = 0;
					}
					//if (string.Compare(comboBoxSheet.Items[0].ToString(), wamMultipleSpreadsheetName, true) == 0
					//	&& (string.Compare(selectedSheetName, WAM.Common.Globals.SampleDataTabName, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameFacility, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameProcess, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameComponentMsc, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameComponentPn, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameDiscMech, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameDiscStruct, true) == 0
					//	|| string.Compare(selectedSheetName, multiSheetNameDiscCivil, true) == 0))
					//{
					//	comboBoxSheet.SelectedIndex = 0;
					//}
					else if (string.Compare(selectedSheetName, WAM.Common.Globals.SampleDataTabName, true) == 0)
					{
						//the sample data sheet is selected in the excel file
						//it is already determined that there is no WAM combined spreadsheet
						//if there is a sheet named "Import Format," load it
						//find the sample data sheet in the combo box and load the next one, or a previous one
						//WAM.Common.Globals.SampleDataTabName

						//look for a sheet named "Import Format" and load it, if found
						for (int i = 0; i < comboBoxSheet.Items.Count; i++)
						{
							if (comboBoxSheet.Items[i].ToString() == WAM.Common.Globals.AllDataTabName)
							{
								comboBoxSheet.SelectedIndex = i;
								break;
							}
						}

						//the "Import Format" sheet was not found, load another sheet
						//look for a sheet preceding or succeeding the sample data sheet, and load it if it exists
						for (int i = 0; i < comboBoxSheet.Items.Count; i++)
						{
							if (comboBoxSheet.Items[i].ToString() == WAM.Common.Globals.SampleDataTabName)
							{
								if (comboBoxSheet.Items.Count > i + 1)
								{
									//load the sheet after the sample data sheet
									comboBoxSheet.SelectedIndex = i + 1;
								}
								else if (i > 0)
								{
									//load the sheet before the sample data sheet
									comboBoxSheet.SelectedIndex = i - 1;
								}
								else
								{
									//there is nothing else to load, so load the sample sheet
									comboBoxSheet.SelectedIndex = i;
								}
								
								break;
							}
						}
					}
					else
						//************************
					{
						for (int i = 0; i < comboBoxSheet.Items.Count; i++)
						{
							if (comboBoxSheet.Items[i].ToString() == selectedSheetName)
							{
								comboBoxSheet.SelectedIndex = i;
							}
						}
					}

					//if SelectedIndexChanged did not get called, call it
					if (!codeHasRun)
					{
						//mam 03202012 - set selected index to 0, which will automatically call comboBoxSheet_SelectedIndexChanged
						//	and AfterComboSheetSelect
						//comboBoxSheet_SelectedIndexChanged(null, null);
						//AfterComboSheetSelect(loadSampleGrid);
						comboBoxSheet.SelectedIndex = 0;
					}
				}
				else
				{
					// get the selected grid
					C1FlexGrid flex = arrayListSpreadsheetGrids[0] as C1FlexGrid;

					// bind it to the visible grid
					c1FlexGridSampleData.DataSource = flex;
				}

				comboBoxSheet.Visible = comboBoxSheet.Items.Count > 1? true: false;
				labelSheet.Visible = comboBoxSheet.Visible;

				//				PopulateTabs(loadSampleGrid, true);
				//
				//				if (isInitialized && tabControlImport.SelectedTab.Name == tabPageOverview.Name)
				//				{
				//					CreateGridFromGrids();
				//				}
				//
				//				SetToolbarButtonState();

				//PopulateTabs(loadSampleGrid, true);
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in LoadExcelFile: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AfterComboSheetSelect(bool loadSampleGrid)
		{
			PopulateTabs(loadSampleGrid, true);

			if (isInitialized && tabControlImport.SelectedTab.Name == tabPageOverview.Name)
			{
				CreateGridFromGrids();
			}

			SetToolbarButtonState();
		}

		//mam 12262012 - for testing only!!!
//		private void WriteDataFromStructGrid(int count)
//		{
//			System.Diagnostics.Debug.WriteLine("");
//			System.Diagnostics.Debug.WriteLine("BEGIN BEGIN BEGIN BEGIN " + count.ToString());
//
//			foreach (Row gridRow in flexDiscStruct.Rows)
//			{
//				if (gridRow.Index < flexDiscStruct.Rows.Fixed)
//				{
//					continue;
//				}
//
//				foreach (Column gridColumn in flexDiscStruct.Cols)
//				{
//					if (gridColumn.Index < flexDiscStruct.Cols.Fixed)
//					{
//						continue;
//					}
//
//					try
//					{
//						System.Diagnostics.Debug.WriteLine("col " + gridColumn.Index.ToString() + ": " + flexDiscStruct[gridRow.Index, gridColumn.Index].ToString());
//					}
//					catch(Exception ex)
//					{
//						System.Diagnostics.Debug.WriteLine("col " + gridColumn.Index.ToString() + ": " + gridRow.Index.ToString() + "\t" + gridColumn.Index.ToString() + "\tNO DATA");
//					}
//				}
//			}
//
//			System.Diagnostics.Debug.WriteLine("");
//			System.Diagnostics.Debug.WriteLine("END END END END END END");
//		}
		//mam 12262012 - for testing only!!! end

		private void LoadSheet(C1FlexGrid flex, XLSheet sheet, bool fixedCells, bool isSampleData)
		{
			//load the data from the Excel spreadsheet into the grid as is, without making any changes or corrections

			//mam 12262012 - for testing only!!!
			//WriteDataFromStructGrid(1);

			// account for fixed cells
			int frows = flex.Rows.Fixed;
			int fcols = flex.Cols.Fixed;

			//mam 03202012
			//remove the empty rows from Excel - it's faster to remove rows from Excel than it is to remove rows from a flex grid
			//(if rows are deleted from within the Excel spreadsheet, the sheet still thinks they are there, even though the cells do not contain data)
			for (int r = sheet.Rows.Count - 1; r >= 0; r--)
			{
				bool rowHasData = false;
				for (int c = 0; c < sheet.Columns.Count; c++)
				{
					// get cell
					XLCell cell = sheet.GetCell(r, c);

					if (cell != null && cell.Value != null)
					{
						rowHasData = true;
					}

					////mam 12262012 - for testing only!!!
					//if (rowHasData) break;
				}

				if (!rowHasData)
				{
					sheet.Rows.RemoveAt(r);
				}
			}

			// copy dimensions
			flex.Rows.Count = sheet.Rows.Count    + frows;
			flex.Cols.Count = sheet.Columns.Count + fcols;

			// initialize fixed cells
			if (fixedCells && frows > 0 && fcols > 0)
			{
				flex.Styles.Fixed.TextAlign = TextAlignEnum.CenterCenter;
				for (int r = 1; r < flex.Rows.Count; r++)
				{
					flex[r, 0] = r;
				}
				for (int c = 1; c < flex.Cols.Count; c++)
				{
					string hdr = string.Format("{0}", (char)('A' + c - 1));
					flex[0, c] = hdr;
				}
			}

			// set default properties
			flex.Font = sheet.Book.DefaultFont;
			flex.Rows.DefaultSize = C1XLBook.TwipsToPixels(sheet.DefaultRowHeight);
			flex.Cols.DefaultSize = C1XLBook.TwipsToPixels(sheet.DefaultColumnWidth);

			//prepare to convert styles
			_styles = new Hashtable();

			for (int r = 0; r < sheet.Rows.Count; r++)
			{
			}

			// set row/column properties
			//if (sheet.Name != "WAM Comp MSC")
			//{
			//	return;
			//}

			//mam 03202012
			if (isSampleData)
			{
				for (int r = 0; r < sheet.Rows.Count; r++)
				{
					// size/visibility
					Row   fr = flex.Rows[r + frows];
					XLRow xr = sheet.Rows[r];
				
					//mam 03202012 - setting the height is incredibly slow
					//do it for the sample grid only
					if (xr.Height >= 0)
						fr.Height = C1XLBook.TwipsToPixels(xr.Height);
					fr.Visible = xr.Visible;
				
					// style
					CellStyle cs = StyleFromExcel(flex, xr.Style);

					if (cs != null)
					{
						//cs.DefinedElements &= ~StyleElementFlags.TextAlign; // << need to fix the grid
						fr.Style = cs;
					}
				}
			}
			else
			{
				for (int r = 0; r < sheet.Rows.Count; r++)
				{
					// size/visibility
					Row   fr = flex.Rows[r + frows];
					XLRow xr = sheet.Rows[r];
				
					//mam 03202012 - setting the height is incredibly slow - let's skip it
					//no - let's do it for the sample grid only
					//if (xr.Height >= 0)
					//	fr.Height = C1XLBook.TwipsToPixels(xr.Height);
					fr.Visible = xr.Visible;
				
					// style
					CellStyle cs = StyleFromExcel(flex, xr.Style);

					if (cs != null)
					{
						//cs.DefinedElements &= ~StyleElementFlags.TextAlign; // << need to fix the grid
						fr.Style = cs;
					}
				}
			}

			for (int c = 0; c < sheet.Columns.Count; c++)
			{
				// size/visibility
				Column   fc = flex.Cols[c + fcols];
				XLColumn xc = sheet.Columns[c];
				if (xc.Width >= 0)
					fc.Width = C1XLBook.TwipsToPixels(xc.Width);
				fc.Visible = xc.Visible;

				// style
				CellStyle cs = StyleFromExcel(flex, xc.Style);
				if (cs != null)
				{
					//cs.DefinedElements &= ~StyleElementFlags.TextAlign; // << need to fix the grid
					fc.Style = cs;
				}
			}

			//load cells
			for (int r = 0; r < sheet.Rows.Count; r++)
			{
				if (stopLoadingFromExcel)
				{
					return;
				}

				for (int c = 0; c < sheet.Columns.Count; c++)
				{
					// get cell
					XLCell cell = sheet.GetCell(r, c);
					//if (cell == null) continue;

					//mam 12262012 - for testing only!!!
//					if (r == 1 && sheet.Name == "WAM Disc Struct")
//					{
//						try
//						{
//							System.Diagnostics.Debug.WriteLine("EXCEL " + c.ToString() + "\t" + cell.Value.ToString());
//						}
//						catch(Exception ex)
//						{
//							System.Diagnostics.Debug.WriteLine("EXCEL ERROR: " + c.ToString() + "\t" + ex.Message);
//						}
//
//						try
//						{
//							System.Diagnostics.Debug.WriteLine("row " + r.ToString() + " col " + c.ToString() + ": " + flex[r + frows, c + fcols].ToString());
//						}
//						catch(Exception ex)
//						{
//							System.Diagnostics.Debug.WriteLine("row " + r.ToString() + " col " + c.ToString() + ": ERROR " + ex.Message);
//						}
//					}

					if (cell == null)
					{
						CellRange cellRange = flex.GetCellRange(r + frows, c + fcols);
						CellStyle csNull = flex.Styles.Add(_styles.Count.ToString());
						csNull.Border.Color = SystemColors.ControlDark;
						cellRange.Style = csNull;

						//mam 12272012
						//write null to the grid when the Excel cell object is null
						//(this is unnecessary, as the grid is now being cleared before reloading it, but let's do it anyway)
						flex[r + frows, c + fcols] = null;

						continue;
					}

					//mam 12262012 - for testing only!!!
					//if (r == 1 && sheet.Name == "WAM Disc Struct")
					//{
					//	WriteDataFromStructGrid(10);
					//}

					//mam 12262012 - for testing only!!!
//					int x = c + fcols;
//					if (r == 1 && sheet.Name == "WAM Disc Struct")
//					{
//						try
//						{
//							//System.Diagnostics.Debug.WriteLine(sheet.Name + "\t" + x.ToString() + "\t" + cell.Value.ToString());
//							////System.Diagnostics.Debug.WriteLine("row " + r.ToString() + " col " + c.ToString() + ": " + flex[r + frows, c + fcols].ToString());
//							System.Diagnostics.Debug.WriteLine("WRITE " + "\t" + x.ToString() + "\t" + cell.Value.ToString());
//						}
//						catch(Exception ex)
//						{
//							//System.Diagnostics.Debug.WriteLine(sheet.Name + "\t" + x.ToString() + "\tcell data error: " + ex.Message);
//							System.Diagnostics.Debug.WriteLine("WRITE " + "\t" + x.ToString() + "\tcell data error: " + ex.Message);
//						}
//					}

					// apply content
					flex[r + frows, c + fcols] = cell.Value;

					//mam 12262012 - for testing only!!!
//					if (r == 1 && sheet.Name == "WAM Disc Struct")
//					{
//						WriteDataFromStructGrid(11);
//
//						if (cell.Value != null)
//						{
//							System.Diagnostics.Debug.WriteLine("WROTE " + "\t" + x.ToString() + "\t" + flex[r + frows, c + fcols].ToString());
//						}
//						else
//						{
//							System.Diagnostics.Debug.WriteLine("WROTE " + "\t" + x.ToString() + "\tNULL");
//						}
//					}

					// apply style
					CellStyle cs = StyleFromExcel(flex, cell.Style);
					if (cs != null)
						flex.SetCellStyle(r + frows, c + fcols, cs);
				}
			}

			//*****************************
			//mam 07072011 - set the names in the criticality cells - for sample data only

			//mam 12262012 - for testing only!!!
			//WriteDataFromStructGrid(2);

			if (isSampleData)
			{
				//mam 01222012 - Criticality1 column is now column 10
				//Criticality1 column is column 9
				for (int i = 0; i < arrayListCriticalities.Count; i++)
				{
					//mam 01222012
					flex[1, i + 10] = "Criticality - " + ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
					//flex[1, i + 9] = "Criticality - " + ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
					////flex[1, i + 9] = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
				}

				//hide the unused crit columns
				for (int i = arrayListCriticalities.Count; i < 6; i++)
				{
					//mam 01222012
					//flex.Cols[i + 9].Visible = false;
					flex.Cols[i + 10].Visible = false;
				}

				//mam 01222012 - crits now start at column 10
				//Criticality1 factor scores for each Major Component start at row 8, column 10
				//Criticality1 list of factor scores start at row 18, column 10
				//Criticality1 list of factor text values start at row 28, column 10
				//write the factor scores and text values to the grid
				CriticalityForImport crit;
				ListDictionary listDictFactors;
				IDictionaryEnumerator idEnumerator;
				IDictionaryEnumerator idEnumeratorScores;
				int counter = 0;
				for (int i = 0; i < arrayListCriticalities.Count; i++)
				{
					counter = 0;
					crit = (CriticalityForImport)arrayListCriticalities[i];
					listDictFactors = crit.CriticalityFactors;
					idEnumerator = listDictFactors.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						//mam 01222012
						flex[counter + 18, i + 10] = Convert.ToInt32(idEnumerator.Key);
						flex[counter + 28, i + 10] = idEnumerator.Value.ToString();
						//flex[counter + 18, i + 9] = Convert.ToInt32(idEnumerator.Key);
						//flex[counter + 28, i + 9] = idEnumerator.Value.ToString();
						counter++;
					}
				}

				//enter scores for each sample Major Component
				counter = -1;
				if (arrayListCriticalities.Count > 0)
				{
					int scoreCount = ((CriticalityForImport)arrayListCriticalities[0]).CriticalityFactors.Count;
					idEnumeratorScores = ((CriticalityForImport)arrayListCriticalities[0]).CriticalityFactors.GetEnumerator();

					//mam 01222012 - the following code works only when the criticality factors are exactly the same for each criticality
					//for (int i = 0; i < arrayListCriticalities.Count; i++)
					//{
					//	counter++;
					//	counter = counter % scoreCount;
					//	idEnumeratorScores.Reset();
					//	for (int k = 0; k <= counter; k++)
					//	{
					//		idEnumeratorScores.MoveNext();
					//	}
					//	for (int j = 0; j < 3; j++)
					//	{
					//		//[row, col]
					//		//mam 01222012
					//		//flex[j + 8, i + 9] = Convert.ToInt32(idEnumeratorScores.Key);
					//		flex[j + 8, i + 10] = Convert.ToInt32(idEnumeratorScores.Key);
					//	}
					//}

					//mam 01222012 - the following should work when the criticality factors are different for each criticality
					for (int i = 0; i < arrayListCriticalities.Count; i++)
					{
						//counter++;
						//counter = counter % scoreCount;
						//idEnumeratorScores.Reset();
						idEnumeratorScores = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors.GetEnumerator();
						scoreCount = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityFactors.Count;
						int minKey = 9999;
						for (int k = 0; k < scoreCount; k++)
						{
							idEnumeratorScores.MoveNext();
							int curKey = Convert.ToInt32(idEnumeratorScores.Key);
							minKey = curKey < minKey ? curKey : minKey;
						}
						for (int j = 0; j < 3; j++)
						{
							//[row, col]
							//mam 01222012
							////flex[j + 8, i + 9] = Convert.ToInt32(idEnumeratorScores.Key);
							//flex[j + 8, i + 10] = Convert.ToInt32(idEnumeratorScores.Key);
							flex[j + 8, i + 10] = minKey;
						}
					}
				}
			}
			//*****************************
		}

		//convert Excel style into FlexGrid style
		private CellStyle StyleFromExcel(C1FlexGrid flex, XLStyle style)
		{
			if (style == null)
				return null;

			// look it up on list
			if (_styles.Contains(style))
				return _styles[style] as CellStyle;

			// create new flex style
			CellStyle cs = flex.Styles.Add(_styles.Count.ToString());

			cs.Border.Color = SystemColors.ControlDark;

			// set up new style
			if (style.Font != null)						cs.Font = style.Font;
			if (style.ForeColor != Color.Transparent)	cs.ForeColor = style.ForeColor;
			if (style.BackColor != Color.Transparent)	cs.BackColor = style.BackColor;
			if (style.Rotation == 90)					cs.TextDirection = TextDirectionEnum.Up;
			if (style.Rotation == 180)					cs.TextDirection = TextDirectionEnum.Down;
			if (style.Format != null && style.Format.Length > 0)
				cs.Format = XLStyle.FormatXLToDotNet(style.Format);
			switch (style.AlignHorz)
			{
				case XLAlignHorzEnum.Center:
					cs.WordWrap = style.WordWrap;
				switch (style.AlignVert)
				{
					case XLAlignVertEnum.Top:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterTop;
						break;
					case XLAlignVertEnum.Center:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
						break;
					default:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterBottom;
						break;
				}
					break;
				case XLAlignHorzEnum.Right:
					cs.WordWrap = style.WordWrap;
				switch (style.AlignVert)
				{
					case XLAlignVertEnum.Top:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightTop;
						break;
					case XLAlignVertEnum.Center:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
						break;
					default:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightBottom;
						break;
				}
					break;
				case XLAlignHorzEnum.Left:
					cs.WordWrap = style.WordWrap;
				switch (style.AlignVert)
				{
					case XLAlignVertEnum.Top:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.LeftTop;
						break;
					case XLAlignVertEnum.Center:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.LeftCenter;
						break;
					default:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.LeftBottom;
						break;
				}
					break;
				default:
					cs.WordWrap = style.WordWrap;
				switch (style.AlignVert)
				{
					case XLAlignVertEnum.Top:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.GeneralTop;
						break;
					case XLAlignVertEnum.Center:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.GeneralCenter;
						break;
					default:
						cs.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.GeneralBottom;
						break;
				}
					break;
			}
		
			// save it
			_styles.Add(style, cs);

			// return it
			return cs;
		}

		#endregion /***** Load Excel Sheet *****/

		#region /***** Save Excel Sheet *****/

		private void SaveExcelFile()
		{
			try
			{
				// choose file
				SaveFileDialog dlg = new SaveFileDialog();
				dlg.DefaultExt = "xls";
				dlg.FileName = "*.xls";
				if (dlg.ShowDialog() != DialogResult.OK)
					return;

				// clear book
				excelBook.Clear();
				excelBook.Sheets.Clear();
				//#############
				//excelBookExport.Clear();
				//excelBookExport.Sheets.Clear();
				//#############

				// copy grids to book sheets (from Spreadsheet tab)
				//don't do this - Spreadsheet tab is currently not visible to user
				//			foreach (C1FlexGrid grid in arrayListSpreadsheetGrids)
				//			{
				//				XLSheet sheet = excelBook.Sheets.Add(grid.Name);
				//				SaveSheet(grid, sheet, false);
				//
				//				//#############
				//				//XLSheet sheet2 = excelBookExport.Sheets.Add(grid.Name);
				//				//SaveSheet(grid, sheet2, false);
				//				//#############
				//			}

				// save selected sheet index
				//excelBook.Sheets.SelectedIndex = comboBoxSheet.SelectedIndex;
				excelBook.Sheets.SelectedIndex = 0;

				CreateExcelSheetFromGrids();

				//XLSheet sheetSample = excelBookSampleData.Sheets[0];
				XLSheet sheetSample = excelBook.Sheets.Add("Sample Data");
				SaveSheet(c1FlexGridSampleData, sheetSample, false);

				//#############
				//XLSheet sheetSample2 = excelBookExport.Sheets.Add("Sample Data");
				//SaveSheet(c1FlexGridSampleData, sheetSample2, true);
				//#############

				// save the book
				try
				{
					excelBook.Save(dlg.FileName);
				}
				catch
				{
					MessageBox.Show("The Excel file cannot be saved.  Make sure the Excel file isn't already open in Excel or another application.", 
						"File Cannot be Saved", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

				}

				//remove the non-spreadsheet sheets
				try
				{
					excelBook.Sheets.Remove("Grid Data");
					excelBook.Sheets.Remove("Sample Data");
				}
				catch
				{
					//MessageBox.Show("error removing sheets");
				}
				//#############
				//excelBookExport.Save(dlg.FileName + "2");
				//#############
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, "An error occurred in SaveExcelFile: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void SaveSheet(C1FlexGrid flex, XLSheet sheet, bool fixedCells)
		{
			// account for fixed cells
			int frows = flex.Rows.Fixed;
			int fcols = flex.Cols.Fixed;
			if (fixedCells) frows = fcols = 0;

			// copy dimensions
			int lastRow = flex.Rows.Count - frows - 1;
			int lastCol = flex.Cols.Count - fcols - 1;
			if (lastRow < 0 || lastCol < 0) return;
			XLCell cell = sheet[lastRow, lastCol];

			// set default properties
			sheet.Book.DefaultFont   = flex.Font;
			sheet.DefaultRowHeight   = C1XLBook.PixelsToTwips(flex.Rows.DefaultSize);
			sheet.DefaultColumnWidth = C1XLBook.PixelsToTwips(flex.Cols.DefaultSize);

			// prepare to convert styles
			_styles = new Hashtable();

			// set row/column properties
			for (int r = frows; r < flex.Rows.Count; r++)
			{
				// size/visibility
				Row   fr = flex.Rows[r];
				XLRow xr = sheet.Rows[r - frows];
				if (fr.Height >= 0)
					xr.Height = C1XLBook.PixelsToTwips(fr.Height);
				xr.Visible = fr.Visible;

				// style
				XLStyle xs = StyleFromFlex(fr.Style);
				if (xs != null)
					xr.Style = xs;
			}
			for (int c = fcols; c < flex.Cols.Count; c++)
			{
				// size/visibility
				Column   fc = flex.Cols[c];
				XLColumn xc = sheet.Columns[c - fcols];
				if (fc.Width >= 0)
					xc.Width = C1XLBook.PixelsToTwips(fc.Width);
				xc.Visible = fc.Visible;

				// style
				XLStyle xs = StyleFromFlex(fc.Style);
				if (xs != null)
					xc.Style = xs;
			}

			// load cells
			for (int r = frows; r < flex.Rows.Count; r++)
			{
				for (int c = fcols; c < flex.Cols.Count; c++)
				{
					// get cell
					cell = sheet[r - frows, c - fcols];

					// apply content
					cell.Value = flex[r, c];

					// apply style
					XLStyle xs = StyleFromFlex(flex.GetCellStyle(r, c));
					if (xs != null)
						cell.Style = xs;
				}
			}
		}

		// convert FlexGrid style into Excel style
		private XLStyle StyleFromFlex(CellStyle style)
		{
			// sanity
			if (style == null)
				return null;

			// look it up on list
			if (_styles.Contains(style))
				return _styles[style] as XLStyle;

			// create new Excel style
			XLStyle xs = new XLStyle(excelBook);

			// set up new style
			xs.Font      = style.Font;
			xs.ForeColor = style.ForeColor;
			xs.BackColor = style.BackColor;
			xs.WordWrap  = style.WordWrap;
			xs.Format    = XLStyle.FormatDotNetToXL(style.Format);

			xs.BorderLeft = XLLineStyleEnum.Thin;
			xs.BorderTop = XLLineStyleEnum.Thin;
			xs.BorderRight = XLLineStyleEnum.Thin;
			xs.BorderBottom = XLLineStyleEnum.Thin;
			xs.BorderColorLeft = SystemColors.ControlDark;
			xs.BorderColorTop = SystemColors.ControlDark;
			xs.BorderColorRight = SystemColors.ControlDark;
			xs.BorderColorBottom = SystemColors.ControlDark;

			switch (style.TextDirection)
			{
				case TextDirectionEnum.Up:
					xs.Rotation = 90;
					break;
				case TextDirectionEnum.Down:
					xs.Rotation = 180;
					break;
			}
			switch (style.TextAlign)
			{
				case TextAlignEnum.CenterBottom:
					xs.AlignHorz = XLAlignHorzEnum.Center;
					xs.AlignVert = XLAlignVertEnum.Bottom;
					break;
				case TextAlignEnum.CenterCenter:
					xs.AlignHorz = XLAlignHorzEnum.Center;
					xs.AlignVert = XLAlignVertEnum.Center;
					break;
				case TextAlignEnum.CenterTop:
					xs.AlignHorz = XLAlignHorzEnum.Center;
					xs.AlignVert = XLAlignVertEnum.Top;
					break;
				case TextAlignEnum.GeneralBottom:
					xs.AlignHorz = XLAlignHorzEnum.General;
					xs.AlignVert = XLAlignVertEnum.Bottom;
					break;
				case TextAlignEnum.GeneralCenter:
					xs.AlignHorz = XLAlignHorzEnum.General;
					xs.AlignVert = XLAlignVertEnum.Center;
					break;
				case TextAlignEnum.GeneralTop:
					xs.AlignHorz = XLAlignHorzEnum.General;
					xs.AlignVert = XLAlignVertEnum.Top;
					break;
				case TextAlignEnum.LeftBottom:
					xs.AlignHorz = XLAlignHorzEnum.Left;
					xs.AlignVert = XLAlignVertEnum.Bottom;
					break;
				case TextAlignEnum.LeftCenter:
					xs.AlignHorz = XLAlignHorzEnum.Left;
					xs.AlignVert = XLAlignVertEnum.Center;
					break;
				case TextAlignEnum.LeftTop:
					xs.AlignHorz = XLAlignHorzEnum.Left;
					xs.AlignVert = XLAlignVertEnum.Top;
					break;
				case TextAlignEnum.RightBottom:
					xs.AlignHorz = XLAlignHorzEnum.Right;
					xs.AlignVert = XLAlignVertEnum.Bottom;
					break;
				case TextAlignEnum.RightCenter:
					xs.AlignHorz = XLAlignHorzEnum.Right;
					xs.AlignVert = XLAlignVertEnum.Center;
					break;
				case TextAlignEnum.RightTop:
					xs.AlignHorz = XLAlignHorzEnum.Right;
					xs.AlignVert = XLAlignVertEnum.Top;
					break;
				default:
					break;
			}

			// save it
			_styles.Add(style, xs);

			// return it
			return xs;
		}

		#endregion /***** Save Excel Sheet *****/

		#region /***** Click Events *****/

		private void tabControlImport_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			try
			{
				HideInstructionPanel();
				SetToolbarButtonState();

				if (isInitialized && tabControlImport.SelectedTab.Name == tabPageOverview.Name)
				{
					CreateGridFromGrids();
				}

				SetErrorTipVisibility();

				if (isInitialized && tabControlImport.SelectedTab.Name == tabPageComponentPN.Name)
				{
					labelGeneralMessage.Text = importPipeNodedataMessage;
					SetInfoMsgVisibility(true);
				}
				else
				{
					SetInfoMsgVisibility(false);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred after clicking a tab: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void SetErrorTipVisibility()
		{
			//set visibility of error tip controls

			int checkErrorCount = 0;

			if (isInitialized && tabControlImport.SelectedTab.Name == tabPageFacility.Name)
			{
				checkErrorCount = errorCountFac;
			}
			else if (isInitialized && tabControlImport.SelectedTab.Name == tabPageProcess.Name)
			{
				checkErrorCount = errorCountProc;
			}
			else if (isInitialized && tabControlImport.SelectedTab.Name == tabPageComponent.Name)
			{
				checkErrorCount = errorCountComp;
			}
			else if (isInitialized && tabControlImport.SelectedTab.Name == tabPageComponentPN.Name)
			{
				checkErrorCount = errorCountCompPN;
			}
			else if (isInitialized && tabControlImport.SelectedTab.Name == tabPageDiscipline.Name)
			{
				checkErrorCount = errorCountDisc;
			}

			panelErrorMessage.Visible = checkErrorCount > 0;
			labelErrorTip.Visible = panelErrorMessage.Visible;
		}

		private void SetInfoMsgVisibility(bool isVisible)
		{
			panelGeneralMessage.Visible = isVisible;
		}

		private void pictureBoxToolbarAddGridRow_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			AddGridRow();

			if (allowContinuousValidation)
				ValidateGridData();
			
			SetClearAllButtonState();
		}

		private void pictureBoxInstructionAddGridRow_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			tabControlImport.SelectedTab = tabControlImport.TabPages[0];
			AddGridRow();

			//mam 03202012
			if (allowContinuousValidation)
				ValidateGridData();

			SetClearAllButtonState();
		}

		private void pictureBoxToolbarDeleteGridRow_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			PerformDeleteGridRowTasks(sender, e);
			SetToolbarButtonState();
			SetClearAllButtonState();
		}

		private void pictureBoxToolbarExport_Click(object sender, System.EventArgs e)
		{
			GridFinishEditing();
			SaveExcelFile();
		}

		private void CreateExcelSheetFromGrids()
		{
			if (CountGridRows() == 0)
			{
				return;
			}

			HideInstructionPanel();

			XLSheet sheet = excelBook.Sheets.Add();
			ArrayList arrayListGrids = new ArrayList();
			C1FlexGrid grid = new C1FlexGrid();
			XLCell cell;
			CellRange cellRange;
			XLStyle xsDefault = new XLStyle(excelBook);
			xsDefault.Font = new Font("Arial", 10, FontStyle.Regular);
			bool isDiscipline = false;

			int excelRow = 0;
			int excelCol = 0;

			//add grids to array
			arrayListGrids.Add(c1FlexGridFacility);
			arrayListGrids.Add(c1FlexGridProcess);
			arrayListGrids.Add(c1FlexGridComponent);
			arrayListGrids.Add(c1FlexGridComponentPN);
			arrayListGrids.Add(c1FlexGridDiscipline);

			// step 2: get the sheet that was created by default, give it a name
			sheet.Name = "Grid Data";

			//sheet.Book.DefaultFont   = c1FlexGridFacility.Font;
			sheet.Book.DefaultFont   = new Font("Arial", 10, FontStyle.Regular);
			sheet.DefaultRowHeight   = C1XLBook.PixelsToTwips(c1FlexGridSampleData.Rows.DefaultSize);
			sheet.DefaultColumnWidth = C1XLBook.PixelsToTwips(c1FlexGridSampleData.Cols.DefaultSize);

			//mam 07072011 - remove unused crit cols from a copy of dataTableColNames so they don't get exported
			DataTable dataTableColNames2 = dataTableColNames.Copy();
			string newColCaption = "";
			for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
			{
				dataTableColNames2.Columns.Remove("Crit" + i.ToString());
			}
			//prepend "Criticality - " to each criticality column caption
			for (int i = 1; i <= arrayListCriticalities.Count; i++)
			{
				newColCaption = "Criticality - " + dataTableColNames2.Columns["Crit" + i.ToString()].Caption;
				dataTableColNames2.Columns["Crit" + i.ToString()].Caption = newColCaption;
			}
			//</mam>

			//write the column headers to the Excel file
			int curCellColIndex = 0;

			//mam 07072011 - use dataTableColNames2
			//foreach (DataColumn dataColumn in dataTableColNames.Columns)
			foreach (DataColumn dataColumn in dataTableColNames2.Columns)
			{
				cell = sheet[0, dataColumn.Ordinal]; 
				cell.Value = dataColumn.Caption.ToString();
				cell.Style = xsDefault;

				curCellColIndex = dataColumn.Ordinal;
			}

			//write column headers for disc comp info data
			foreach (DataRow dataRow in dataTableDiscCompInfo.Rows)
			{
				cell = sheet[0, ++curCellColIndex]; 
				cell.Value = dataRow[1].ToString();
				cell.Style = xsDefault;
			}

			//write the data from the Fac, Proc, Comp, CompPN, and Disc grids to the Excel file
			for (int gridNumber = 0; gridNumber < arrayListGrids.Count; gridNumber++)
			{
				grid = (C1FlexGrid)arrayListGrids[gridNumber];

				//CellStyle cellStyleDefault = grid.Styles.Add("Default");
				////cellStyleDefault.Font = new Font(Font, (System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)));
				//cellStyleDefault.Font = new Font("Arial", 10, FontStyle.Regular);

				for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
				{
					isDiscipline = false;
					excelRow++;

					//mam 07072011 - use dataTableColNames2
					//excelCol = dataTableColNames.Columns[GridColumnName.Type.ToString()].Ordinal;
					excelCol = dataTableColNames2.Columns[GridColumnName.Type.ToString()].Ordinal;

					cell = sheet[excelRow, excelCol];
					if (grid.Name.Equals(c1FlexGridFacility.Name))
						cell.Value = "Facility";
					if (grid.Name.Equals(c1FlexGridProcess.Name))
						cell.Value = "Process";
					if (grid.Name.Equals(c1FlexGridComponent.Name))
						cell.Value = "CompMSC";
					if (grid.Name.Equals(c1FlexGridComponentPN.Name))
						cell.Value = "CompPN";
					if (grid.Name.Equals(c1FlexGridDiscipline.Name))
					{
						isDiscipline = true;
						cellRange = grid.GetCellRange(i, grid.Cols["DisciplineType"].Index);
						cell.Value = cellRange.DataDisplay.ToString();
					}
					cell.Style = xsDefault;

					for (int j = grid.Cols.Fixed; j < grid.Cols.Count; j++)
					{
						if (grid.Cols[j].Visible)
						{
							if (listDictColNamesDontExport.Contains(grid.Cols[j].Name.ToString()))
							{
								continue;
							}

							//mam 07072011 - use dataTableColNames2
							//excelCol = dataTableColNames.Columns[grid.Cols[j].Name].Ordinal;
							excelCol = dataTableColNames2.Columns[grid.Cols[j].Name].Ordinal;

							cell = sheet[excelRow, excelCol];
							cellRange = grid.GetCellRange(i, j);
							if (cellRange.Data != null)
							{
								cell.Value = cellRange.DataDisplay.ToString();
							}

							// apply style
							XLStyle xs = StyleFromFlex(grid.GetCellStyle(i, j));
							if (xs == null)
							{
								cell.Style = xsDefault;
							}
							else
							{
								xs.Font = new Font("Arial", 10, cellRange.Style.Font.Style);
								//xs.ForeColor = Color.Purple;
								cell.Style = xs;
							}
						}
					}

					if (isDiscipline)
					{
						//create a discipline object
						//get the discipline's disc comp info data
						//find the column in the Excel sheet
						//write the data to the Excel sheet

						ImportFromTextFileDiscipline discipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(grid[i, "TempID"])]);
						excelCol = -1;

						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
						{
							for (int findColIndex = 0; findColIndex <= curCellColIndex; findColIndex++)
							{
								//if (sheet[0, findColIndex].Value.ToString() == "MechExcessiveVibration")
								if (sheet[0, findColIndex].Value.ToString() == "Mech Excessive Vibration")
								{
									excelCol = findColIndex;
									break;
								}
							}
						}
						else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
						{
							for (int findColIndex = 0; findColIndex <= curCellColIndex; findColIndex++)
							{
								//if (sheet[0, findColIndex].Value.ToString() == "ConcreteSpalling")
								if (sheet[0, findColIndex].Value.ToString() == "Struct Concrete Spalling")
								{
									excelCol = findColIndex;
									break;
								}
							}
						}
						else if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
						{
							for (int findColIndex = 0; findColIndex <= curCellColIndex; findColIndex++)
							{
								//if (sheet[0, findColIndex].Value.ToString() == "SeveralPotholes")
								if (sheet[0, findColIndex].Value.ToString() == "Civil Several Potholes")
								{
									excelCol = findColIndex;
									break;
								}
							}
						}

						if (excelCol == -1)
						{
							MessageBox.Show("Error writing Disc Comp Info to Excel file");
							continue;
						}

						//mech
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
						{
							sheet[excelRow, excelCol++].Value = discipline.MechExcessiveVibration == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveVibration.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechExcessiveNoise == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveNoise.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveCorrosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechExcessiveLeaks == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveLeaks.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechRunningHot == ItemStatus.NotApplicable ? "N/A" : discipline.MechRunningHot.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechCanRunWhenInspected == ItemStatus.NotApplicable ? "N/A" : discipline.MechCanRunWhenInspected.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechSupportIsFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.MechSupportIsFunctional.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechPartsMissing == ItemStatus.NotApplicable ? "N/A" : discipline.MechPartsMissing.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.MechPartsAvailable.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.MechAdequate.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MechMotorAmps == ItemStatus.NotApplicable ? "N/A" : discipline.MechMotorAmps.ToString();
							sheet[excelRow, excelCol++].Value = discipline.InstrIndicationFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.InstrIndicationFunctional.ToString();
							sheet[excelRow, excelCol++].Value = discipline.InstrAlarmFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.InstrAlarmFunctional.ToString();
							sheet[excelRow, excelCol++].Value = discipline.InstrPartsMissing == ItemStatus.NotApplicable ? "N/A" : discipline.InstrPartsMissing.ToString();
							sheet[excelRow, excelCol++].Value = discipline.InstrPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.InstrPartsAvailable.ToString();
							sheet[excelRow, excelCol++].Value = discipline.ElecExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.ElecExcessiveCorrosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.ElecCleanContacts == ItemStatus.NotApplicable ? "N/A" : discipline.ElecCleanContacts.ToString();
							sheet[excelRow, excelCol++].Value = discipline.ElecPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.ElecPartsAvailable.ToString();
							sheet[excelRow, excelCol++].Value = discipline.PipeExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.PipeExcessiveCorrosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.PipeExcessiveLeaks == ItemStatus.NotApplicable ? "N/A" : discipline.PipeExcessiveLeaks.ToString();
							sheet[excelRow, excelCol++].Value = discipline.PipePaintGood == ItemStatus.NotApplicable ? "N/A" : discipline.PipePaintGood.ToString();
						}

						//struct
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
						{
							sheet[excelRow, excelCol++].Value = discipline.ConcreteSpalling == ItemStatus.NotApplicable ? "N/A" : discipline.ConcreteSpalling.ToString();
							sheet[excelRow, excelCol++].Value = discipline.StructExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.StructExcessiveCorrosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MembExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.MembExcessiveCorrosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.CorrosionCoating == ItemStatus.NotApplicable ? "N/A" : discipline.CorrosionCoating.ToString();
							sheet[excelRow, excelCol++].Value = discipline.PaintGood == ItemStatus.NotApplicable ? "N/A" : discipline.PaintGood.ToString();
							sheet[excelRow, excelCol++].Value = discipline.VisibleDeformities == ItemStatus.NotApplicable ? "N/A" : discipline.VisibleDeformities.ToString();
							sheet[excelRow, excelCol++].Value = discipline.SettingEvident == ItemStatus.NotApplicable ? "N/A" : discipline.SettingEvident.ToString();
							sheet[excelRow, excelCol++].Value = discipline.MajorCracks == ItemStatus.NotApplicable ? "N/A" : discipline.MajorCracks.ToString();
						}

						//civil
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
						{
							sheet[excelRow, excelCol++].Value = discipline.SeveralPotholes == ItemStatus.NotApplicable ? "N/A" : discipline.SeveralPotholes.ToString();
							sheet[excelRow, excelCol++].Value = discipline.ExcessiveErosion == ItemStatus.NotApplicable ? "N/A" : discipline.ExcessiveErosion.ToString();
							sheet[excelRow, excelCol++].Value = discipline.RoadDegradation == ItemStatus.NotApplicable ? "N/A" : discipline.RoadDegradation.ToString();
							sheet[excelRow, excelCol++].Value = discipline.ExpansionSpace == ItemStatus.NotApplicable ? "N/A" : discipline.ExpansionSpace.ToString();
							sheet[excelRow, excelCol++].Value = discipline.FunctionCover == ItemStatus.NotApplicable ? "N/A" : discipline.FunctionCover.ToString();
							sheet[excelRow, excelCol++].Value = discipline.FencingAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.FencingAdequate.ToString();
							sheet[excelRow, excelCol++].Value = discipline.FacilitiesSecure == ItemStatus.NotApplicable ? "N/A" : discipline.FacilitiesSecure.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppClayLiner == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppClayLiner.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBermErosionInterior == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermErosionInterior.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBermErosionBermExterior == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermErosionBermExterior.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBermVegetation == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermVegetation.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBermSettlement == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermSettlement.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBermSeepage == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermSeepage.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppBurrowHoles == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBurrowHoles.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppErosionProtectionPresent == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppErosionProtectionPresent.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppErosionProtectionAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppErosionProtectionAdequate.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppAlgalBlooms == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppAlgalBlooms.ToString();
							sheet[excelRow, excelCol++].Value = discipline.LandAppDrainageAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppDrainageAdequate.ToString();
						}
					}
				}
			}
		}

		private void CreateGridFromGrids()
		{
			//clear the Overview grid and set grid properties
			if (c1FlexGridOverview.Rows.Count > 1)
			{
				//c1FlexGridOverview.Clear(ClearFlags.Content, 1, 1, c1FlexGridOverview.Rows.Count - 1, c1FlexGridOverview.Cols.Count - 1);
				c1FlexGridOverview.Rows.RemoveRange(1, c1FlexGridOverview.Rows.Count - 1);
			}

			if (CountGridRows() == 0)
			{
				return;
			}

			ArrayList arrayListGrids = new ArrayList();
			C1FlexGrid grid = new C1FlexGrid();
			CellRange cellRange;
			bool isDiscipline = false;

			int excelRow = 0;
			int excelCol = 0;

			//add grids to array
			arrayListGrids.Add(c1FlexGridFacility);
			arrayListGrids.Add(c1FlexGridProcess);
			arrayListGrids.Add(c1FlexGridComponent);
			arrayListGrids.Add(c1FlexGridComponentPN);
			arrayListGrids.Add(c1FlexGridDiscipline);

			//			//clear the Overview grid and set grid properties
			//			if (c1FlexGridOverview.Rows.Count > 1)
			//			{
			//				//c1FlexGridOverview.Clear(ClearFlags.Content, 1, 1, c1FlexGridOverview.Rows.Count - 1, c1FlexGridOverview.Cols.Count - 1);
			//				c1FlexGridOverview.Rows.RemoveRange(1, c1FlexGridOverview.Rows.Count - 1);
			//			}
			c1FlexGridOverview.AllowDragging = AllowDraggingEnum.None;
			c1FlexGridOverview.AllowEditing = false;
			c1FlexGridOverview.Cols[0].WidthDisplay = 20;

			//add RecordSelector column to Overview grid
			//newGridCol = c1FlexGridOverview.Cols.Add();
			//newGridCol.Name	= "RowSelector";
			//newGridCol.Caption = "";
			//newGridCol.WidthDisplay = 20;

			////add columns to Overview grid
			//foreach (DataColumn dataColumn in dataTableColNames.Columns)
			//{
			//	newGridCol = c1FlexGridOverview.Cols.Add();
			//	newGridCol.Name	= dataColumn.ColumnName;
			//	newGridCol.Caption = dataColumn.Caption;
			//}

			//write the data from the Fac, Proc, Comp, CompPN, and Disc grids to the Overview grid
			for (int gridNumber = 0; gridNumber < arrayListGrids.Count; gridNumber++)
			{
				grid = (C1FlexGrid)arrayListGrids[gridNumber];

				//mam 07072011 - set the crit column names and column visibility in the overview grid
				if (grid.Name.Equals(c1FlexGridComponent.Name))
				{
					string critNumber = "";
					for (int i = 1; i <= 6; i++)
					{
						critNumber = i.ToString();
						c1FlexGridOverview[0, "Crit" + critNumber] = grid[1, "Crit" + critNumber];
						c1FlexGridOverview.Cols["Crit" + critNumber].Visible = grid.Cols["Crit" + critNumber].Visible;
					}

					//mam 07072011 - prepend "Criticality - " to each crit column caption in the Summary grid
					string newColCaption = "";
					string existingColCaption = "";
					for (int i = 1; i <= arrayListCriticalities.Count ; i++)
					{
						existingColCaption = c1FlexGridOverview.Cols["Crit" + i.ToString()].Caption;
						c1FlexGridOverview[0, "Crit" + i.ToString()] = existingColCaption;
						if (!existingColCaption.StartsWith("Criticality - "))
						{
							newColCaption = "Criticality - " + existingColCaption;
							c1FlexGridOverview.Cols["Crit" + i.ToString()].Caption = newColCaption;
						}
					}
					//</mam>
				}
				//</mam>

				for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
				{
					isDiscipline = false;
					excelRow++;
					c1FlexGridOverview.Rows.Add();

					//add 1 to Ordinal to account for RecordSelector column in c1FlexGridOverview
					excelCol = dataTableColNames.Columns[GridColumnName.Type.ToString()].Ordinal + 1;
					if (grid.Name.Equals(c1FlexGridFacility.Name))
					{
						c1FlexGridOverview[excelRow, excelCol] = "Facility";
					}
					if (grid.Name.Equals(c1FlexGridProcess.Name))
					{
						c1FlexGridOverview[excelRow, excelCol] = "Process";
					}
					if (grid.Name.Equals(c1FlexGridComponent.Name))
					{
						c1FlexGridOverview[excelRow, excelCol] = "CompMSC";
					}
					if (grid.Name.Equals(c1FlexGridComponentPN.Name))
					{
						c1FlexGridOverview[excelRow, excelCol] = "CompPN";
					}
					if (grid.Name.Equals(c1FlexGridDiscipline.Name))
					{
						isDiscipline = true;
						cellRange = grid.GetCellRange(i, grid.Cols["DisciplineType"].Index);
						c1FlexGridOverview[excelRow, excelCol] = cellRange.DataDisplay.ToString();
					}

					for (int j = grid.Cols.Fixed; j < grid.Cols.Count; j++)
					{
						if (grid.Cols[j].Visible)
						{
							if (listDictColNamesDontExport.Contains(grid.Cols[j].Name.ToString()))
							{
								continue;
							}

							//add 1 to Ordinal to account for RecordSelector column in c1FlexGridOverview
							excelCol = dataTableColNames.Columns[grid.Cols[j].Name].Ordinal + 1;
							cellRange = grid.GetCellRange(i, j);
							if (cellRange.Data != null)
							{
								c1FlexGridOverview[excelRow, excelCol] = cellRange.DataDisplay.ToString();
							}
						}
					}

					if (isDiscipline)
					{
						//create a discipline object
						//get the discipline's disc comp info data
						//write the data to the grid

						ImportFromTextFileDiscipline discipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(grid[i, "TempID"])]);

						//mech
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineMech)
						{
							c1FlexGridOverview[excelRow, "MechExcessiveVibration"] = discipline.MechExcessiveVibration == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveVibration.ToString();
							c1FlexGridOverview[excelRow, "MechExcessiveNoise"] = discipline.MechExcessiveNoise == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveNoise.ToString();
							c1FlexGridOverview[excelRow, "MechExcessiveCorrosion"] = discipline.MechExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveCorrosion.ToString();
							c1FlexGridOverview[excelRow, "MechExcessiveLeaks"] = discipline.MechExcessiveLeaks == ItemStatus.NotApplicable ? "N/A" : discipline.MechExcessiveLeaks.ToString();
							c1FlexGridOverview[excelRow, "MechRunningHot"] = discipline.MechRunningHot == ItemStatus.NotApplicable ? "N/A" : discipline.MechRunningHot.ToString();
							c1FlexGridOverview[excelRow, "MechCanRunWhenInspected"] = discipline.MechCanRunWhenInspected == ItemStatus.NotApplicable ? "N/A" : discipline.MechCanRunWhenInspected.ToString();
							c1FlexGridOverview[excelRow, "MechSupportIsFunctional"] = discipline.MechSupportIsFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.MechSupportIsFunctional.ToString();
							c1FlexGridOverview[excelRow, "MechPartsMissing"] = discipline.MechPartsMissing == ItemStatus.NotApplicable ? "N/A" : discipline.MechPartsMissing.ToString();
							c1FlexGridOverview[excelRow, "MechPartsAvailable"] = discipline.MechPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.MechPartsAvailable.ToString();
							c1FlexGridOverview[excelRow, "MechAdequate"] = discipline.MechAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.MechAdequate.ToString();
							c1FlexGridOverview[excelRow, "MechMotorAmps"] = discipline.MechMotorAmps == ItemStatus.NotApplicable ? "N/A" : discipline.MechMotorAmps.ToString();
							c1FlexGridOverview[excelRow, "InstrIndicationFunctional"] = discipline.InstrIndicationFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.InstrIndicationFunctional.ToString();
							c1FlexGridOverview[excelRow, "InstrAlarmFunctional"] = discipline.InstrAlarmFunctional == ItemStatus.NotApplicable ? "N/A" : discipline.InstrAlarmFunctional.ToString();
							c1FlexGridOverview[excelRow, "InstrPartsMissing"] = discipline.InstrPartsMissing == ItemStatus.NotApplicable ? "N/A" : discipline.InstrPartsMissing.ToString();
							c1FlexGridOverview[excelRow, "InstrPartsAvailable"] = discipline.InstrPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.InstrPartsAvailable.ToString();
							c1FlexGridOverview[excelRow, "ElecExcessiveCorrosion"] = discipline.ElecExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.ElecExcessiveCorrosion.ToString();
							c1FlexGridOverview[excelRow, "ElecCleanContacts"] = discipline.ElecCleanContacts == ItemStatus.NotApplicable ? "N/A" : discipline.ElecCleanContacts.ToString();
							c1FlexGridOverview[excelRow, "ElecPartsAvailable"] = discipline.ElecPartsAvailable == ItemStatus.NotApplicable ? "N/A" : discipline.ElecPartsAvailable.ToString();
							c1FlexGridOverview[excelRow, "PipeExcessiveCorrosion"] = discipline.PipeExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.PipeExcessiveCorrosion.ToString();
							c1FlexGridOverview[excelRow, "PipeExcessiveLeaks"] = discipline.PipeExcessiveLeaks == ItemStatus.NotApplicable ? "N/A" : discipline.PipeExcessiveLeaks.ToString();
							c1FlexGridOverview[excelRow, "PipePaintGood"] = discipline.PipePaintGood == ItemStatus.NotApplicable ? "N/A" : discipline.PipePaintGood.ToString();
						}

						//struct
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
						{
							c1FlexGridOverview[excelRow, "ConcreteSpalling"] = discipline.ConcreteSpalling == ItemStatus.NotApplicable ? "N/A" : discipline.ConcreteSpalling.ToString();
							c1FlexGridOverview[excelRow, "StructExcessiveCorrosion"] = discipline.StructExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.StructExcessiveCorrosion.ToString();
							c1FlexGridOverview[excelRow, "MembExcessiveCorrosion"] = discipline.MembExcessiveCorrosion == ItemStatus.NotApplicable ? "N/A" : discipline.MembExcessiveCorrosion.ToString();
							c1FlexGridOverview[excelRow, "CorrosionCoating"] = discipline.CorrosionCoating == ItemStatus.NotApplicable ? "N/A" : discipline.CorrosionCoating.ToString();
							c1FlexGridOverview[excelRow, "PaintGood"] = discipline.PaintGood == ItemStatus.NotApplicable ? "N/A" : discipline.PaintGood.ToString();
							c1FlexGridOverview[excelRow, "VisibleDeformities"] = discipline.VisibleDeformities == ItemStatus.NotApplicable ? "N/A" : discipline.VisibleDeformities.ToString();
							c1FlexGridOverview[excelRow, "SettingEvident"] = discipline.SettingEvident == ItemStatus.NotApplicable ? "N/A" : discipline.SettingEvident.ToString();
							c1FlexGridOverview[excelRow, "MajorCracks"] = discipline.MajorCracks == ItemStatus.NotApplicable ? "N/A" : discipline.MajorCracks.ToString();
						}

						//civil
						if (discipline.DisciplineType == WAM.UI.NodeType.DisciplineLand)
						{
							c1FlexGridOverview[excelRow, "SeveralPotholes"] = discipline.SeveralPotholes == ItemStatus.NotApplicable ? "N/A" : discipline.SeveralPotholes.ToString();
							c1FlexGridOverview[excelRow, "ExcessiveErosion"] = discipline.ExcessiveErosion == ItemStatus.NotApplicable ? "N/A" : discipline.ExcessiveErosion.ToString();
							c1FlexGridOverview[excelRow, "RoadDegradation"] = discipline.RoadDegradation == ItemStatus.NotApplicable ? "N/A" : discipline.RoadDegradation.ToString();
							c1FlexGridOverview[excelRow, "ExpansionSpace"] = discipline.ExpansionSpace == ItemStatus.NotApplicable ? "N/A" : discipline.ExpansionSpace.ToString();
							c1FlexGridOverview[excelRow, "FunctionCover"] = discipline.FunctionCover == ItemStatus.NotApplicable ? "N/A" : discipline.FunctionCover.ToString();
							c1FlexGridOverview[excelRow, "FencingAdequate"] = discipline.FencingAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.FencingAdequate.ToString();
							c1FlexGridOverview[excelRow, "FacilitiesSecure"] = discipline.FacilitiesSecure == ItemStatus.NotApplicable ? "N/A" : discipline.FacilitiesSecure.ToString();
							c1FlexGridOverview[excelRow, "LandAppClayLiner"] = discipline.LandAppClayLiner == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppClayLiner.ToString();
							c1FlexGridOverview[excelRow, "LandAppBermErosionInterior"] = discipline.LandAppBermErosionInterior == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermErosionInterior.ToString();
							c1FlexGridOverview[excelRow, "LandAppBermErosionBermExterior"] = discipline.LandAppBermErosionBermExterior == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermErosionBermExterior.ToString();
							c1FlexGridOverview[excelRow, "LandAppBermVegetation"] = discipline.LandAppBermVegetation == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermVegetation.ToString();
							c1FlexGridOverview[excelRow, "LandAppBermSettlement"] = discipline.LandAppBermSettlement == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermSettlement.ToString();
							c1FlexGridOverview[excelRow, "LandAppBermSeepage"] = discipline.LandAppBermSeepage == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBermSeepage.ToString();
							c1FlexGridOverview[excelRow, "LandAppBurrowHoles"] = discipline.LandAppBurrowHoles == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppBurrowHoles.ToString();
							c1FlexGridOverview[excelRow, "LandAppErosionProtectionPresent"] = discipline.LandAppErosionProtectionPresent == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppErosionProtectionPresent.ToString();
							c1FlexGridOverview[excelRow, "LandAppErosionProtectionAdequate"] = discipline.LandAppErosionProtectionAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppErosionProtectionAdequate.ToString();
							c1FlexGridOverview[excelRow, "LandAppAlgalBlooms"] = discipline.LandAppAlgalBlooms == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppAlgalBlooms.ToString();
							c1FlexGridOverview[excelRow, "LandAppDrainageAdequate"] = discipline.LandAppDrainageAdequate == ItemStatus.NotApplicable ? "N/A" : discipline.LandAppDrainageAdequate.ToString();
						}
					}
				}
			}
		}

		private void pictureBoxToolbarClearAll_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (CountGridRows() == 0)
				{
					return;
				}

				if (MessageBox.Show("Delete all data from all grids?", "Delete All Data From All Grids?", 
					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
				{
					DeleteAllData();
					AddExistingFacilitiesToCombo();
					AddExistingProcessesToCombo();
					AssignDataMapProcessGrid();
					AssignDataMapCustomENR();
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred after clicking Delete All button: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void DeleteAllData()
		{
			try
			{
				GridFinishEditing();

				c1FlexGridFacility.Rows.RemoveRange(c1FlexGridFacility.Rows.Fixed, c1FlexGridFacility.Rows.Count - c1FlexGridFacility.Rows.Fixed);
				c1FlexGridProcess.Rows.RemoveRange(c1FlexGridProcess.Rows.Fixed, c1FlexGridProcess.Rows.Count - c1FlexGridProcess.Rows.Fixed);
				c1FlexGridComponent.Rows.RemoveRange(c1FlexGridComponent.Rows.Fixed, c1FlexGridComponent.Rows.Count - c1FlexGridComponent.Rows.Fixed);
				c1FlexGridComponentPN.Rows.RemoveRange(c1FlexGridComponentPN.Rows.Fixed, c1FlexGridComponentPN.Rows.Count - c1FlexGridComponentPN.Rows.Fixed);
				c1FlexGridDiscipline.Rows.RemoveRange(c1FlexGridDiscipline.Rows.Fixed, c1FlexGridDiscipline.Rows.Count - c1FlexGridDiscipline.Rows.Fixed);

				listDictFacilityNames.Clear();
				listDictFacilityNamesAll.Clear();
				listDictFacilityNamesImportCheckBox.Clear();
				listDictProcessNames.Clear();
				listDictProcessNamesAll.Clear();
				listDictProcessNamesImportCheckBox.Clear();
				listDictProcessNamesForComponent.Clear();
				listDictComponentNames.Clear();
				listDictComponentNamesAll.Clear();
				listDictComponentNamesImportCheckBox.Clear();
				listDictDisciplineNames.Clear();
				listDictDisciplineNamesAll.Clear();
				listDictDisciplineNamesImportCheckBox.Clear();
				listDictComponentNamesDiscCombo.Clear();

				importCollection.listFacility.Clear();
				importCollection.listProcess.Clear();
				importCollection.listComponent.Clear();
				importCollection.listComponentPN.Clear();
				importCollection.listDiscipline.Clear();

				if (tabControlImport.SelectedTab.Name.Equals(tabPageOverview.Name))
				{
					CreateGridFromGrids();
				}

				SetClearAllButtonState();
				SetToolbarButtonState();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DeleteAllData: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void pictureBoxToolbarHelp_Click(object sender, System.EventArgs e)
		{
			//HideInstructionPanel();
			//MessageBox.Show("This functionality is not yet available", "Functionality Not Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingDataExcel.htm");
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			//This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			hlpEvent.Handled = true;

			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ImportingDataExcel.htm");
		}

		private void pictureBoxToolbarSelectFile_Click(object sender, System.EventArgs e)
		{
			ImportFile(false);
		}

		private void pictureBoxInstructionSelectFile_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			ImportFile(false);
		}

		private void pictureBoxSelectFileSpreadsheet_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			ImportFile(false);
		}

		private void buttonValidate_Click(object sender, System.EventArgs e)
		{
			if (CountGridRows() == 0)
			{
				MessageBox.Show(this, "There is no data to validate", "Validate Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			HideInstructionPanel();
			ValidateGridData();
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (CountGridRows() == 0)
			{
				MessageBox.Show(this, "There is no data to import", "Import Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			HideInstructionPanel();
			ImportData();
		}

		private void comboBoxSheet_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			codeHasRun = true;

			// get the selected grid
			C1FlexGrid flex = arrayListSpreadsheetGrids[comboBoxSheet.SelectedIndex] as C1FlexGrid;

			// bind it to the visible grid
			c1FlexGridSpreadsheetData.DataSource = flex;

			if (sender != null)
			{
				AfterComboSheetSelect(false);
			}
		}

		private void pictureBoxToolbarPopulateTabs_Click(object sender, System.EventArgs e)
		{
			PopulateTabs(false, false);
		}

		private void pictureBoxLoadSampleData_Click(object sender, System.EventArgs e)
		{
			LoadSampleData();
		}

		private void pictureBoxPopulateTabsSample_Click(object sender, System.EventArgs e)
		{
			if (c1FlexGridSampleData.Rows.Count == c1FlexGridSampleData.Rows.Fixed)
			{
				//MessageBox.Show(this, "Please reload the Sample Data first.", "Load Excel Spreadsheet", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				MessageBox.Show(this, "There is no data in the Sample Data grid.", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (PopulateTabs(true, false))
			{
				MessageBox.Show(this, "The data was loaded into the Import grids.", "Populate Grids", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
			{
				MessageBox.Show(this, "An error occurred while loading the data.", "Populate Grids", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void pictureBoxPopulateTabsSpreadsheet_Click(object sender, System.EventArgs e)
		{
			HideInstructionPanel();
			if (c1FlexGridSpreadsheetData.Rows.Count == c1FlexGridSpreadsheetData.Rows.Fixed)
			{
				MessageBox.Show(this, "Please load an Excel spreadsheet first.", "Load Excel Spreadsheet", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (PopulateTabs(false, false))
			{
				MessageBox.Show(this, "The data was loaded into the Import grids.", "Populate Grids", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

		private void pictureBoxToolbarCheckAll_Click(object sender, System.EventArgs e)
		{
			if (tabControlImport.SelectedTab.Name == tabPageSpreadsheetData.Name
				|| tabControlImport.SelectedTab.Name == tabPageSampleData.Name)
			{
				return;
			}

			HideInstructionPanel();
			C1FlexGrid grid = new C1FlexGrid();

			if (tabControlImport.SelectedTab.Name.Equals(tabPageFacility.Name))
			{
				UpdateFacilityAfterCheckingImportCheckBox(-1, SetAllImportCheckboxes(c1FlexGridFacility));
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageProcess.Name))
			{
				UpdateProcessAfterCheckingImportCheckBox(-1, SetAllImportCheckboxes(c1FlexGridProcess));
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponent.Name))
			{
				UpdateComponentAfterCheckingImportCheckBox(c1FlexGridComponent, -1, SetAllImportCheckboxes(c1FlexGridComponent));
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponentPN.Name))
			{
				UpdateComponentAfterCheckingImportCheckBox(c1FlexGridComponentPN, -1, SetAllImportCheckboxes(c1FlexGridComponentPN));
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageDiscipline.Name))
			{
				UpdateDisciplineAfterCheckingImportCheckBox(-1, SetAllImportCheckboxes(c1FlexGridDiscipline));
			}
			else
			{
				return;
			}

			if (allowContinuousValidation)
				ValidateGridData();
		}

		private bool SetAllImportCheckboxes(C1FlexGrid grid)
		{
			try
			{
				//determine whether to check all import boxes, or uncheck them
				//if any of the boxes are currently unchecked, check all of them

				bool importThisItem = false;
				for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
				{
					if (!Convert.ToBoolean(grid[i, "Import"]))
					{
						importThisItem = true;
						break;
					}
				}
				for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
				{
					grid.SetData(i, "Import", importThisItem);
				}
				return importThisItem;
			}
			catch
			{
				return false;
			}
		}

		private void LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			switch (((LinkLabel)sender).Tag.ToString().ToUpper())
			{
				case "FAC":
					tabControlImport.SelectedTab = tabPageFacility;
					break;
				case "PROC":
					tabControlImport.SelectedTab = tabPageProcess;
					break;
				case "COMP":
					tabControlImport.SelectedTab = tabPageComponent;
					break;
				case "COMPPN":
					tabControlImport.SelectedTab = tabPageComponentPN;
					break;
				case "DISC":
					tabControlImport.SelectedTab = tabPageDiscipline;
					break;
			}
		}

		private void c1FlexGridDiscipline_CellButtonClick(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			ImportFromTextFileDiscipline gridRowDiscipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[e.Row, "TempID"])]);
			DiscCompInfoHolder discCompInfo = new DiscCompInfoHolder(gridRowDiscipline);
			//DiscCompInfoHolder discCompInfo = new DiscCompInfoHolder(
			//	((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[e.Row, "TempID"])]));

			discCompInfo.ShowDialog();

			//mam 07072011 - set cell style of discCompInfo cell to Valid, if necessary
			try
			{
				CellRange cellRange = c1FlexGridDiscipline.GetCellRange(e.Row, e.Col);
				string disciplineTypeIdString = c1FlexGridDiscipline.GetData(e.Row, "DisciplineType").ToString();
				if (disciplineTypeIdString == "0" && cellRange.Style.Name == "DefaultValue")
				{
					//if any values are not n/a, the user must have changed something
					if (CheckDiscCompInfoAnyValueNotNA(0, e.Row))
					{
						cellRange.Style = c1FlexGridDiscipline.Styles["Valid"];
					}
				}
				if (disciplineTypeIdString == "1" && cellRange.Style.Name == "DefaultValue")
				{
					//if any values are not n/a, the user must have changed something
					if (CheckDiscCompInfoAnyValueNotNA(1, e.Row))
					{
						cellRange.Style = c1FlexGridDiscipline.Styles["Valid"];
					}
				}
				if (disciplineTypeIdString == "2" && cellRange.Style.Name == "DefaultValue")
				{
					//if any values are not n/a, the user must have changed something
					if (CheckDiscCompInfoAnyValueNotNA(2, e.Row))
					{
						cellRange.Style = c1FlexGridDiscipline.Styles["Valid"];
					}
				}

			}
			catch
			{
				//we don't care why the error occurred - all we're doing is changing the color of the cell - if there was a problem, ignore it
			}
		}

		//mam 07072011
		private bool CheckDiscCompInfoAnyValueNotNA(int disciplineType, int rowNumber)
		{
			ImportFromTextFileDiscipline gridRowDiscipline = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[Convert.ToInt32(c1FlexGridDiscipline[rowNumber, "TempID"])]);
			int changeCount = 0;

			if (disciplineType == 0)
			{
				//mech
				if (gridRowDiscipline.MechExcessiveVibration != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechExcessiveNoise != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechExcessiveCorrosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechExcessiveLeaks != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechRunningHot != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechCanRunWhenInspected != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechSupportIsFunctional != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechPartsMissing != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechPartsAvailable != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechAdequate != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MechMotorAmps != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.InstrIndicationFunctional != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.InstrAlarmFunctional != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.InstrPartsMissing != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.InstrPartsAvailable != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.ElecExcessiveCorrosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.ElecCleanContacts != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.ElecPartsAvailable != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.PipeExcessiveCorrosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.PipeExcessiveLeaks != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.PipePaintGood != ItemStatus.NotApplicable) changeCount++;
			}
			else if (disciplineType == 1)
			{
				//struct
				if (gridRowDiscipline.ConcreteSpalling != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.StructExcessiveCorrosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MembExcessiveCorrosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.CorrosionCoating != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.PaintGood != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.VisibleDeformities != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.SettingEvident != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.MajorCracks != ItemStatus.NotApplicable) changeCount++;
			}
			else if (disciplineType == 2)
			{
				//civil
				if (gridRowDiscipline.SeveralPotholes != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.ExcessiveErosion != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.RoadDegradation != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.ExpansionSpace != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.FunctionCover != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.FencingAdequate != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.FacilitiesSecure != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppClayLiner != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBermErosionInterior != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBermErosionBermExterior != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBermVegetation != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBermSettlement != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBermSeepage != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppBurrowHoles != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppErosionProtectionPresent != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppErosionProtectionAdequate != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppAlgalBlooms != ItemStatus.NotApplicable) changeCount++;
				if (gridRowDiscipline.LandAppDrainageAdequate != ItemStatus.NotApplicable) changeCount++;
			}

			return changeCount > 0;
		}

		private void checkBoxContinuousValidation_CheckedChanged(object sender, System.EventArgs e)
		{
			SetContinuousValidateProps();

			//if (allowContinuousValidation)
		{
			ValidateGridData();
		}
		}

		private void SetContinuousValidateProps()
		{
			allowContinuousValidation = checkBoxContinuousValidation.Checked;
			buttonValidate.Visible = !allowContinuousValidation;
		}

		#endregion /***** Click Events *****/

		#region /***** Add Grid Rows *****/

		private int GetNextTempID(WAM.UI.NodeType nodeType)
		{
			IDictionaryEnumerator idEnumerator = listDictFacilityNamesAll.GetEnumerator();
			int tempID = 0;
			switch (nodeType)
			{
				case WAM.UI.NodeType.Facility:
					idEnumerator = listDictFacilityNamesAll.GetEnumerator();
					break;
				case WAM.UI.NodeType.TreatmentProcess:
					idEnumerator = listDictProcessNamesAll.GetEnumerator();
					break;
				case WAM.UI.NodeType.MajorComponent:
					idEnumerator = listDictComponentNamesAll.GetEnumerator();
					break;
				case WAM.UI.NodeType.DisciplineMech:
				case WAM.UI.NodeType.DisciplineStruct:
				case WAM.UI.NodeType.DisciplineLand:
					idEnumerator = listDictDisciplineNamesAll.GetEnumerator();
					break;
				case WAM.UI.NodeType.DisciplinePipe:
				case WAM.UI.NodeType.DisciplineNode:
					//idEnumerator = listDictDisciplineNamesAll.GetEnumerator();
					break;
			}
			
			while (idEnumerator.MoveNext())
			{
				if (Convert.ToInt32(idEnumerator.Key) < tempID)
				{
					tempID = Convert.ToInt32(idEnumerator.Key);
				}
			}

			return --tempID;
		}

		private void AddGridRow()
		{
			GridFinishEditing();

			if (tabControlImport.SelectedTab.Name.Equals(tabPageFacility.Name))
			{
				AddGridRowFacility();
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageProcess.Name))
			{
				AddGridRowProcess();
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponent.Name))
			{
				AddGridRowComponent(true);
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponentPN.Name))
			{
				AddGridRowComponent(false);
			}
			else if (tabControlImport.SelectedTab.Name.Equals(tabPageDiscipline.Name))
			{
				AddGridRowDiscipline();
			}
			else if (tabControlImport.SelectedTab.Name == tabPageSpreadsheetData.Name)
			{
				c1FlexGridSpreadsheetData.Rows.Add();
				AssignNumbersToFixedColumn(c1FlexGridSpreadsheetData);
			}
			else if (tabControlImport.SelectedTab.Name == tabPageSampleData.Name)
			{
				c1FlexGridSampleData.Rows.Add();
				AssignNumbersToFixedColumn(c1FlexGridSampleData);
			}
			else
			{
				return;
			}

			SetToolbarButtonState();
		}

		private void AddGridRowFacility()
		{
			try
			{
				//c1FlexGridFacility.AllowAddNew = true;

				ImportFromTextFileFacility importFacility = new ImportFromTextFileFacility();
				int curTempFacID = GetNextTempID(WAM.UI.NodeType.Facility);

				importFacility.ImportThisItem = true;
				importFacility.InfoSetID = infoSetID;
				importFacility.TempID = curTempFacID;
				importFacility.ExistingID = 0;
				importFacility.CurrentYear = Convert.ToInt16(DateTime.Now.Year);
				importFacility.CustomENRTableName = string.Empty;
				importFacility.ItemName = "New Facility";
				importFacility.Comments = string.Empty;

				//add the facility to the facility grid
				Row newRow = c1FlexGridFacility.Rows.Add();
				c1FlexGridFacility.SetData(newRow.Index, "Import", importFacility.ImportThisItem);
				c1FlexGridFacility.SetData(newRow.Index, "TempID", importFacility.TempID);
				//c1FlexGridFacility.SetData(newRow.Index, "ItemID", importFacility.ExistingID);
				c1FlexGridFacility.SetData(newRow.Index, "FacilityCurrentYear", importFacility.CurrentYear);

				//mam 01222012
				c1FlexGridFacility.SetData(newRow.Index, "FacilityCriticality", importFacility.FacilityCriticality);

				c1FlexGridFacility.SetData(newRow.Index, "CustomENRTable", importFacility.CustomENRTableName);
				c1FlexGridFacility.SetData(newRow.Index, "FacilityName", importFacility.ItemName);
				c1FlexGridFacility.SetData(newRow.Index, "Comments", importFacility.Comments);

				//mam 03202012
				int renameColIndex = c1FlexGridFacility.Cols["RenameExistingFacility"].Index;
				CellRange cellRangeCheckBox = c1FlexGridFacility.GetCellRange(newRow.Index, renameColIndex);
				cellRangeCheckBox.Style = c1FlexGridFacility.Styles["CheckBoxHide"];
				cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
				c1FlexGridFacility[newRow.Index, renameColIndex] = null;

				//mam 03202012
				c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoFileNameNorth", importFacility.PhotoFileNameNorth);
				c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoFileNameSouth", importFacility.PhotoFileNameSouth);
				c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoCaptionNorth", importFacility.PhotoCaptionNorth);
				c1FlexGridFacility.SetData(newRow.Index, "FacilityPhotoCaptionSouth", importFacility.PhotoCaptionSouth);

				//add the facility to the list of facilities
				listDictFacilityNames.Add(curTempFacID, importFacility);
				listDictFacilityNamesAll.Add(curTempFacID, importFacility);
				listDictFacilityNamesImportCheckBox.Add(curTempFacID, importFacility);

				//c1FlexGridFacility.AllowAddNew = false;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddGridRowFacility: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AddGridRowProcess()
		{
			try
			{
				//c1FlexGridProcess.AllowAddNew = true;

				ImportFromTextFileProcess importProcess = new ImportFromTextFileProcess();
				int curTempProcID = GetNextTempID(WAM.UI.NodeType.TreatmentProcess);

				importProcess.ImportThisItem = true;
				importProcess.InfoSetID = infoSetID;
				importProcess.TempID = curTempProcID;
				importProcess.ExistingID = 0;
				importProcess.ItemName = "New Process";
				importProcess.Comments = string.Empty;

				Row newRow = c1FlexGridProcess.Rows.Add();
				c1FlexGridProcess.SetData(newRow.Index, "Import", importProcess.ImportThisItem);
				c1FlexGridProcess.SetData(newRow.Index, "TempID", importProcess.TempID);
				//c1FlexGridProcess.SetData(newRow.Index, "ItemID", importProcess.ExistingID);
				c1FlexGridProcess.SetData(newRow.Index, "FacilityName", null);
				c1FlexGridProcess.SetData(newRow.Index, "ProcessName", importProcess.ItemName);
				c1FlexGridProcess.SetData(newRow.Index, "Comments", importProcess.Comments);

				//mam 03202012
				int renameColIndex = c1FlexGridProcess.Cols["RenameExistingProcess"].Index;
				CellRange cellRangeCheckBox = c1FlexGridProcess.GetCellRange(newRow.Index, renameColIndex);
				cellRangeCheckBox.Style = c1FlexGridProcess.Styles["CheckBoxHide"];
				cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
				c1FlexGridProcess[newRow.Index, renameColIndex] = null;

				//mam 03202012
				c1FlexGridProcess.SetData(newRow.Index, "ProcessPhotoFileName", importProcess.PhotoFileName);
				c1FlexGridProcess.SetData(newRow.Index, "ProcessPhotoCaption", importProcess.PhotoCaption);

				listDictProcessNames.Add(curTempProcID, importProcess);
				listDictProcessNamesAll.Add(curTempProcID, importProcess);
				//listDictProcessNames.Add(importProcess, importProcess.ItemName);
				//listDictProcessNamesAll.Add(importProcess, importProcess.ItemName);

				importCollection.Add(importProcess);

				listDictProcessNamesImportCheckBox.Add(curTempProcID, (ImportFromTextFileProcess)importCollection.listProcess[curTempProcID]);
				//listDictProcessNamesImportCheckBox.Add((ImportFromTextFileProcess)importCollection.listProcess[importProcess.TempID], 
				//	((ImportFromTextFileProcess)importCollection.listProcess[importProcess.TempID]).ItemName);

				AssignDataMapProcessGrid();
				//AssignDataMapComponentGrid(c1FlexGridComponent);
				//AssignDataMapComponentGrid(c1FlexGridComponentPN);

				//c1FlexGridProcess.AllowAddNew = false;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddGridRowProcess: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AddGridRowComponent(bool isMechStruc)
		{
			try
			{
				//c1FlexGridComponent.AllowAddNew = true;

				ImportFromTextFileComponent importComponent = new ImportFromTextFileComponent();
				int curTempCompID = GetNextTempID(WAM.UI.NodeType.MajorComponent);
				//string curValueString = string.Empty;

				//set the properties of the import object
				importComponent.ImportThisItem = true;
				importComponent.InfoSetID = infoSetID;
				importComponent.TempID = curTempCompID;
				importComponent.ExistingID = 0;
				importComponent.Retired = false;
				importComponent.ItemName = "New Component";
				importComponent.Comments = string.Empty;
				importComponent.MechStructDisciplines = isMechStruc;

				//set grid data

				C1FlexGrid grid = new C1FlexGrid();
				if (importComponent.MechStructDisciplines)
				{
					grid = c1FlexGridComponent;
				}
				else
				{
					grid = c1FlexGridComponentPN;
				}

				Row newRow = grid.Rows.Add();
				grid.SetData(newRow.Index, "Import", importComponent.ImportThisItem);
				grid.SetData(newRow.Index, "TempID", importComponent.TempID);
				//grid.SetData(newRow.Index, "ItemID", importComponent.ExistingID);
				grid.SetData(newRow.Index, "FacilityName", null);
				grid.SetData(newRow.Index, "ProcessName", null);
				grid.SetData(newRow.Index, "ComponentName", importComponent.ItemName);
				grid.SetData(newRow.Index, "Retired", importComponent.Retired);

				if (importComponent.MechStructDisciplines)
				{
					grid.SetData(newRow.Index, "RedundantAssets", "1");
				}

				grid.SetData(newRow.Index, "Comments", importComponent.Comments);

				if (importComponent.MechStructDisciplines)
				{
					grid.SetData(newRow.Index, "ComponentType", 0);
					grid.SetData(newRow.Index, "LOS", 1);

					//mam 07072011
					for (int i = 0; i < arrayListCip.Count; i++)
					{
						if (((Common.CommonTasks.Cip)arrayListCip[i]).UseAsDefault)
						{
							grid.SetData(newRow.Index, "CipPlanningMode", ((Common.CommonTasks.Cip)arrayListCip[i]).CipPlanningText);
							break;
						}
					}

					//mam 07072011
					grid.SetData(newRow.Index, "AssetClass", "");

					//mam 07072011 - select the default crits in the crit dropdowns as each row is added
					for (int i = 0; i < arrayListCriticalities.Count; i++)
					{
						string critNumberString = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityNumber.ToString();
						int defaultScore = ((CriticalityForImport)arrayListCriticalities[i]).DefaultCriticalityScore;
						grid.SetData(newRow.Index, "Crit" + critNumberString, defaultScore);
					}

					//mam 07072011 - no longer using four fixed crits
					//grid.SetData(newRow.Index, "CritPublic", 3);
					//grid.SetData(newRow.Index, "CritEnvironment", 2);
					//grid.SetData(newRow.Index, "CritRepair", 2);
					//grid.SetData(newRow.Index, "CritEffect", 2);
				}
				else
				{
					grid.SetData(newRow.Index, "ComponentType", 1);
				}

				//mam 03202012
				int renameColIndex = grid.Cols["RenameExistingComponent"].Index;
				CellRange cellRangeCheckBox = grid.GetCellRange(newRow.Index, renameColIndex);
				cellRangeCheckBox.Style = grid.Styles["CheckBoxHide"];
				cellRangeCheckBox.Style.Display = DisplayEnum.TextOnly;
				grid[newRow.Index, renameColIndex] = null;

				//mam 03202012
				grid.SetData(newRow.Index, "ComponentPhotoFileName", importComponent.PhotoFileName);
				grid.SetData(newRow.Index, "ComponentPhotoCaption", importComponent.PhotoCaption);

				listDictComponentNames.Add(curTempCompID, importComponent);
				listDictComponentNamesAll.Add(curTempCompID, importComponent);
				listDictComponentNamesImportCheckBox.Add(curTempCompID, importComponent);

				AssignDataMapComponentGrid(grid);

				//c1FlexGridComponent.AllowAddNew = false;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddGridRowComponent: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void AddGridRowDiscipline()
		{
			try
			{
				//c1FlexGridDiscipline.AllowAddNew = true;

				ImportFromTextFileDiscipline importDiscipline = new ImportFromTextFileDiscipline();
				int curTempDiscID = GetNextTempID(WAM.UI.NodeType.DisciplineMech);
				//string curValueString = string.Empty;

				//set the properties of the import object
				importDiscipline.ImportThisItem = true;
				importDiscipline.InfoSetID = infoSetID;
				importDiscipline.TempID = curTempDiscID;
				importDiscipline.ExistingID = 0;
				importDiscipline.ItemName = "New Discipline";
				importDiscipline.Comments = string.Empty;
				importDiscipline.MechStructDisciplines = true;
				importDiscipline.DisciplineType = WAM.UI.NodeType.DisciplineMech;

				//set grid data

				C1FlexGrid grid = new C1FlexGrid();
				//if (importDiscipline.MechStructDisciplines)
				//{
				grid = c1FlexGridDiscipline;
				//}
				//else
				//{
				//	grid = c1FlexGridDiscipline;
				//}

				Row newRow = grid.Rows.Add();
				grid.SetData(newRow.Index, "DisciplineType", 0);
				grid.SetData(newRow.Index, "Import", importDiscipline.ImportThisItem);
				grid.SetData(newRow.Index, "TempID", importDiscipline.TempID);
				//grid.SetData(newRow.Index, "ItemID", importDiscipline.ExistingID);
				grid.SetData(newRow.Index, "FacilityName", null);
				grid.SetData(newRow.Index, "ProcessName", null);
				grid.SetData(newRow.Index, "ComponentName", null);
				grid.SetData(newRow.Index, "Comments", string.Empty);

				//if (importDiscipline.MechStructDisciplines)
				//grid.SetData(newRow.Index, "LOS", 1);
				grid.SetData(newRow.Index, "Condition", 6);
				//grid.SetData(newRow.Index, "AcquisitionCost", importDiscipline.AcquisitionCost);
				grid.SetData(newRow.Index, "ReplacementValue", importDiscipline.ReplacementValue);
				grid.SetData(newRow.Index, "ReplacementValueYear", importDiscipline.ReplacementValueYear);
				grid.SetData(newRow.Index, "SalvageValue", importDiscipline.SalvageValue);
				grid.SetData(newRow.Index, "AnnualMaintCost", importDiscipline.AnnualMaintCost);
				grid.SetData(newRow.Index, "InstallationYear", importDiscipline.InstallationYear);
				grid.SetData(newRow.Index, "OriginalUsefulLife", importDiscipline.OriginalUsefulLife);
				////grid.SetData(newRow.Index, "CurrentValue", importDiscipline.CurrentValue);
				////grid.SetData(newRow.Index, "OverrideCurrentValue", importDiscipline.);
				grid.SetData(newRow.Index, "RehabCost", importDiscipline.RehabCost);
				grid.SetData(newRow.Index, "RehabCostYear", importDiscipline.RehabCostYear);
				grid.SetData(newRow.Index, "RehabInterval", importDiscipline.RehabInterval);
				grid.SetData(newRow.Index, "RehabYearLast", importDiscipline.RehabYearLast);
				grid.SetData(newRow.Index, "InspectionDate", importDiscipline.InspectionDate);
				//grid.SetData(newRow.Index, "EquipmentIDNumber", importDiscipline.EquipmentIDNumber);
				//grid.SetData(newRow.Index, "AssessedBy", importDiscipline.AssessedBy);
				//grid.SetData(newRow.Index, "Manufacturer", importDiscipline.Manufacturer);
				//grid.SetData(newRow.Index, "RunHours", importDiscipline.RunHours);
				//grid.SetData(newRow.Index, "RunningAtInspection", importDiscipline.RunningAtInspection);

				//do we need these?  what about manufacturer, assessed by, etc.?
				//they are not necessary as they will be blank in a new row 
				//mam 01222012
				//grid.SetData(newRow.Index, "ReplacementValueDesc", string.Empty);
				//grid.SetData(newRow.Index, "RehabCostDesc", string.Empty);

				//mam 03202012
				grid.SetData(newRow.Index, "DisciplinePhotoFileName", importDiscipline.PhotoFileName);
				grid.SetData(newRow.Index, "DisciplinePhotoCaption", importDiscipline.PhotoCaption);

				listDictDisciplineNames.Add(curTempDiscID, importDiscipline);
				listDictDisciplineNamesAll.Add(curTempDiscID, importDiscipline);
				listDictDisciplineNamesImportCheckBox.Add(curTempDiscID, importDiscipline);

				AssignDataMapDisciplineGrid();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in AddGridRowDiscipline: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		#endregion /***** Add Grid Rows *****/

		#region /***** Delete Grid Rows *****/

		private ArrayList DeleteGridRows(C1FlexGrid grid)
		{
			try
			{
				//delete the grid rows and return an array of TempIDs for the deleted rows
				//(must first select each row manually because unless the SelectionMode is ListBox, 
				//	the grid won't recognize the rows as selected)

				ArrayList arrayListTempIDsToDelete = new ArrayList();
				grid.Selection.Normalize();
				for (int i = grid.Selection.r1; i <= grid.Selection.r2; i++)
				{
					grid.Rows[i].Selected = true;
					if (grid.Name != c1FlexGridSpreadsheetData.Name && grid.Name != c1FlexGridSampleData.Name)
					{
						arrayListTempIDsToDelete.Add(Convert.ToInt32(grid[i, "TempID"]));
					}
				}
				int selRowCount = grid.Rows.Selected.Count;

				if (selRowCount > 0)
				{
					string msgText = "Delete the selected row?";
					if (selRowCount > 1)
					{
						msgText = string.Format("Delete the {0} selected rows?", selRowCount);
					}

					//DialogResult dialogResult = DialogResult.Yes;
					if (MessageBox.Show(msgText, "Delete Rows", MessageBoxButtons.YesNo, MessageBoxIcon.Question, 
						MessageBoxDefaultButton.Button1) == DialogResult.Yes)
					{
						grid.Rows.RemoveRange(grid.Selection.r1, selRowCount);
					}
					else
					{
						arrayListTempIDsToDelete.Clear();
					}
				}
				
				//after deleting a grid row, set the focus on another existing row in the grid
				try
				{
					for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
					{
						grid.Rows[i].Selected = false;
					}

					if (grid.Row > grid.Rows.Count)
					{
						grid.Select(grid.Rows.Count - 1, grid.Col);
					}
					else
					{
						grid.Select(grid.Row, grid.Col);
					}
					grid.Focus();
				}
				catch
				{
				}

				return arrayListTempIDsToDelete;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DeleteGridRows: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return null;
			}
		}

		private void PerformDeleteGridRowTasks(object sender, System.EventArgs e)
		{
			try
			{
				GridFinishEditing();

				C1FlexGrid grid = new C1FlexGrid();
				ArrayList arrayListTempIDsDeleted = new ArrayList();

				if (tabControlImport.SelectedTab.Name.Equals(tabPageFacility.Name))
				{
					if (c1FlexGridFacility.Rows.Count == c1FlexGridFacility.Rows.Fixed)
					{
						return;
					}

					//delete the grid rows
					arrayListTempIDsDeleted = DeleteGridRows(c1FlexGridFacility);

					//set process properties and remove facilities from lists
					if (arrayListTempIDsDeleted != null)
					{
						//set properties for processes that belong to the deleted facilities
						arrayListTempIDsDeleted.Sort();
						IDictionaryEnumerator idEnumerator = listDictProcessNamesAll.GetEnumerator();
						while (idEnumerator.MoveNext())
						{
							if (arrayListTempIDsDeleted.BinarySearch(((ImportFromTextFileProcess)idEnumerator.Value).FacilityID) > -1)
							{
								((ImportFromTextFileProcess)idEnumerator.Value).FacilityID = 0;
								((ImportFromTextFileProcess)idEnumerator.Value).ParentExists = false;
							}
						}

						//remove facilities from lists
						for (int i = 0; i < arrayListTempIDsDeleted.Count; i++)
						{
							listDictFacilityNames.Remove(arrayListTempIDsDeleted[i]);
							listDictFacilityNamesAll.Remove(arrayListTempIDsDeleted[i]);
							listDictFacilityNamesImportCheckBox.Remove(arrayListTempIDsDeleted[i]);
						}
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageProcess.Name))
				{
					if (c1FlexGridProcess.Rows.Count == c1FlexGridProcess.Rows.Fixed)
					{
						return;
					}

					//delete the grid rows
					arrayListTempIDsDeleted = DeleteGridRows(c1FlexGridProcess);

					//set component properties and remove processes from lists
					if (arrayListTempIDsDeleted != null)
					{
						//set properties for components that belong to the deleted processes
						arrayListTempIDsDeleted.Sort();
						IDictionaryEnumerator idEnumerator = listDictComponentNamesAll.GetEnumerator();
						while (idEnumerator.MoveNext())
						{
							if (arrayListTempIDsDeleted.BinarySearch(((ImportFromTextFileComponent)idEnumerator.Value).ProcessID) > -1)
							{
								((ImportFromTextFileComponent)idEnumerator.Value).ProcessID = 0;
								((ImportFromTextFileComponent)idEnumerator.Value).ParentExists = false;
							}
						}

						//remove processes from lists
						for (int i = 0; i < arrayListTempIDsDeleted.Count; i++)
						{
							listDictProcessNames.Remove(arrayListTempIDsDeleted[i]);
							listDictProcessNamesAll.Remove(arrayListTempIDsDeleted[i]);
							listDictProcessNamesImportCheckBox.Remove(arrayListTempIDsDeleted[i]);
							importCollection.RemoveProcess((int)arrayListTempIDsDeleted[i]);
						}
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponent.Name) 
					|| tabControlImport.SelectedTab.Name.Equals(tabPageComponentPN.Name))
				{
					//delete the grid rows
					if (tabControlImport.SelectedTab.Name.Equals(tabPageComponent.Name))
					{
						if (c1FlexGridComponent.Rows.Count == c1FlexGridComponent.Rows.Fixed)
						{
							return;
						}
						arrayListTempIDsDeleted = DeleteGridRows(c1FlexGridComponent);
					}
					else
					{
						if (c1FlexGridComponentPN.Rows.Count == c1FlexGridComponentPN.Rows.Fixed)
						{
							return;
						}
						arrayListTempIDsDeleted = DeleteGridRows(c1FlexGridComponentPN);
					}

					//set discipline properties and remove components from lists
					if (arrayListTempIDsDeleted != null)
					{
						//set properties for disciplines that belong to the deleted components
						arrayListTempIDsDeleted.Sort();
						IDictionaryEnumerator idEnumerator = listDictDisciplineNamesAll.GetEnumerator();
						while (idEnumerator.MoveNext())
						{
							//if (arrayListTempIDsDeleted.BinarySearch(((ImportFromTextFileDiscipline)idEnumerator.Value).TempID) > -1)
							if (arrayListTempIDsDeleted.BinarySearch(((ImportFromTextFileDiscipline)idEnumerator.Value).ComponentID) > -1)
							{
								((ImportFromTextFileDiscipline)idEnumerator.Value).ComponentID = 0;
								((ImportFromTextFileDiscipline)idEnumerator.Value).ParentExists = false;
							}
						}

						//remove components from lists
						for (int i = 0; i < arrayListTempIDsDeleted.Count; i++)
						{
							listDictComponentNames.Remove(arrayListTempIDsDeleted[i]);
							listDictComponentNamesAll.Remove(arrayListTempIDsDeleted[i]);
							listDictComponentNamesImportCheckBox.Remove(arrayListTempIDsDeleted[i]);
						}
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageDiscipline.Name))
				{
					if (c1FlexGridDiscipline.Rows.Count == c1FlexGridDiscipline.Rows.Fixed)
					{
						return;
					}

					//delete the grid rows
					arrayListTempIDsDeleted = DeleteGridRows(c1FlexGridDiscipline);

					//set discipline properties and remove components from lists
					if (arrayListTempIDsDeleted != null)
					{
						//remove disciplines from lists
						for (int i = 0; i < arrayListTempIDsDeleted.Count; i++)
						{
							listDictDisciplineNames.Remove(arrayListTempIDsDeleted[i]);
							listDictDisciplineNamesAll.Remove(arrayListTempIDsDeleted[i]);
							listDictDisciplineNamesImportCheckBox.Remove(arrayListTempIDsDeleted[i]);
						}
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageSpreadsheetData.Name))
				{
					if (c1FlexGridSpreadsheetData.Rows.Count == c1FlexGridSpreadsheetData.Rows.Fixed)
					{
						return;
					}

					//delete the grid rows
					DeleteGridRows(c1FlexGridSpreadsheetData);
					AssignNumbersToFixedColumn(c1FlexGridSpreadsheetData);
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageSampleData.Name))
				{
					if (c1FlexGridSampleData.Rows.Count == c1FlexGridSampleData.Rows.Fixed)
					{
						return;
					}

					//delete the grid rows
					DeleteGridRows(c1FlexGridSampleData);
					AssignNumbersToFixedColumn(c1FlexGridSampleData);
				}
				else
				{
					return;
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in PerformDeleteGridRowTasks: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		#endregion /***** Delete Grid Rows *****/

		#region /***** Methods *****/

		private void AssignDataMapProcessGrid()
		{
			//assign facility names to process grid facility column combo box
			c1FlexGridProcess.Cols["FacilityName"].DataType = typeof(ImportFromTextFileFacility);
			c1FlexGridProcess.Cols["FacilityName"].DataMap = listDictFacilityNamesImportCheckBox;
			c1FlexGridProcess.Cols["FacilityName"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void AssignDataMapComponentGrid(C1FlexGrid grid)
		{
			grid.Cols["FacilityName"].DataType = typeof(ImportFromTextFileFacility);
			grid.Cols["FacilityName"].DataMap = listDictFacilityNamesImportCheckBox;
			grid.Cols["FacilityName"].TextAlign = TextAlignEnum.LeftCenter;

			grid.Cols["ProcessName"].DataType = typeof(ImportFromTextFileProcess);
			grid.Cols["ProcessName"].DataMap = listDictProcessNamesImportCheckBox;
			grid.Cols["ProcessName"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void AssignDataMapDisciplineGrid()
		{
			c1FlexGridDiscipline.Cols["FacilityName"].DataType = typeof(ImportFromTextFileFacility);
			c1FlexGridDiscipline.Cols["FacilityName"].DataMap = listDictFacilityNamesImportCheckBox;
			c1FlexGridDiscipline.Cols["FacilityName"].TextAlign = TextAlignEnum.LeftCenter;

			c1FlexGridDiscipline.Cols["ProcessName"].DataType = typeof(ImportFromTextFileProcess);
			c1FlexGridDiscipline.Cols["ProcessName"].DataMap = listDictProcessNamesImportCheckBox;
			c1FlexGridDiscipline.Cols["ProcessName"].TextAlign = TextAlignEnum.LeftCenter;

			c1FlexGridDiscipline.Cols["ComponentName"].DataType = typeof(ImportFromTextFileComponent);
			c1FlexGridDiscipline.Cols["ComponentName"].DataMap = listDictComponentNamesImportCheckBox;
			c1FlexGridDiscipline.Cols["ComponentName"].TextAlign = TextAlignEnum.LeftCenter;
		}

		private void SetToolbarButtonState()
		{
			try
			{
				if (!isInitialized)
				{
					return;
				}

				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				bool delOff = false;
				bool checkOff = false;
				string addBitmap = "WAM.Graphics.ButtonAddOn8.bmp";
				string deleteBitmap = "WAM.Graphics.ButtonDeleteOn8.bmp";
				string checkBitmap = "WAM.Graphics.Grid.ToolbarCheckMarkGreen.bmp";

				//1. allow add for Fac, Proc, Comp, Disc, Sample always
				//2. allow add for Spread only when col count > 1
				//3. allow del for all grids only when row count > fixed row count
				//4. allow check for Fac, Proc, Comp, Disc only when row count > fixed row count
				//5. allow check for Spread, Sample never

				//2
				if (tabControlImport.SelectedTab.Name == tabPageSpreadsheetData.Name 
					&& c1FlexGridSpreadsheetData.Cols.Count <= 1)
				{
					addBitmap = "WAM.Graphics.ButtonAddOff8.bmp";
				}

				//3
				if (tabControlImport.SelectedTab.Name == tabPageFacility.Name)
				{
					delOff = c1FlexGridFacility.Rows.Count <= c1FlexGridFacility.Rows.Fixed;
					checkOff = delOff;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageProcess.Name)
				{
					delOff = c1FlexGridProcess.Rows.Count <= c1FlexGridProcess.Rows.Fixed;
					checkOff = delOff;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageComponent.Name)
				{
					delOff = c1FlexGridComponent.Rows.Count <= c1FlexGridComponent.Rows.Fixed;
					checkOff = delOff;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageComponentPN.Name)
				{
					delOff = c1FlexGridComponentPN.Rows.Count <= c1FlexGridComponentPN.Rows.Fixed;
					checkOff = delOff;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageDiscipline.Name)
				{
					delOff = c1FlexGridDiscipline.Rows.Count <= c1FlexGridDiscipline.Rows.Fixed;
					checkOff = delOff;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageSpreadsheetData.Name)
				{
					delOff = c1FlexGridSpreadsheetData.Rows.Count <= c1FlexGridSpreadsheetData.Rows.Fixed;
					checkOff = true;
				}
				else if (tabControlImport.SelectedTab.Name == tabPageSampleData.Name)
				{
					delOff = c1FlexGridSampleData.Rows.Count <= c1FlexGridSampleData.Rows.Fixed;
					checkOff = true;
				}

				if (delOff)
				{
					deleteBitmap = "WAM.Graphics.ButtonDeleteOff8.bmp";
				}
				if (checkOff)
				{
					checkBitmap = "WAM.Graphics.Grid.ToolbarCheckMarkOff.bmp";
				}

				System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
				System.IO.Stream file = null;
				Image image = null;

				file = thisExe.GetManifestResourceStream(addBitmap);
				image = (Bitmap)Bitmap.FromStream(file);
				this.pictureBoxToolbarAddGridRow.Image = image;
				commonTasks.SetBitmap(pictureBoxToolbarAddGridRow);

				file = thisExe.GetManifestResourceStream(deleteBitmap);
				image = (Bitmap)Bitmap.FromStream(file);
				this.pictureBoxToolbarDeleteGridRow.Image = image;
				commonTasks.SetBitmap(pictureBoxToolbarDeleteGridRow);

				file = thisExe.GetManifestResourceStream(checkBitmap);
				image = (Bitmap)Bitmap.FromStream(file);
				this.pictureBoxToolbarCheckAll.Image = image;
				commonTasks.SetBitmap(pictureBoxToolbarCheckAll);
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in SetToolbarButtonState: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void SetClearAllButtonState()
		{
			if (!isInitialized)
			{
				return;
			}

			try
			{
				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
				System.IO.Stream file = null;
				Image image = null;

				if (CountGridRows() == 0)
				{
					file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.ToolbarClearAllOff.bmp");
				}
				else
				{
					file = thisExe.GetManifestResourceStream("WAM.Graphics.Grid.ToolbarClearAllOn.bmp");
				}
				image = (Bitmap)Bitmap.FromStream(file);
				this.pictureBoxToolbarClearAll.Image = image;
				commonTasks.SetBitmap(pictureBoxToolbarClearAll);
			}
			catch
			{
			}
		}

		private int CountGridRows()
		{
			try
			{
				int gridRowCount = 0;

				gridRowCount += c1FlexGridFacility.Rows.Count - c1FlexGridFacility.Rows.Fixed;
				gridRowCount += c1FlexGridProcess.Rows.Count - c1FlexGridProcess.Rows.Fixed;
				gridRowCount += c1FlexGridComponent.Rows.Count - c1FlexGridComponent.Rows.Fixed;
				gridRowCount += c1FlexGridComponentPN.Rows.Count - c1FlexGridComponentPN.Rows.Fixed;
				gridRowCount += c1FlexGridDiscipline.Rows.Count - c1FlexGridDiscipline.Rows.Fixed;

				return gridRowCount;
			}
			catch
			{
				return 0;
			}
		}

		//mam 03202012
		private int CountGridRowsToImport()
		{
			try
			{
				int gridRowCount = 0;

				for (int i = c1FlexGridFacility.Rows.Fixed; i < c1FlexGridFacility.Rows.Count; i++)
				{
					if (Convert.ToBoolean(c1FlexGridFacility.Rows[i]["Import"]))
					{
						gridRowCount++;
					}
				}

				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					if (Convert.ToBoolean(c1FlexGridProcess.Rows[i]["Import"]))
					{
						gridRowCount++;
					}
				}

				for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
				{
					if (Convert.ToBoolean(c1FlexGridComponent.Rows[i]["Import"]))
					{
						gridRowCount++;
					}
				}

				for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
				{
					if (Convert.ToBoolean(c1FlexGridComponentPN.Rows[i]["Import"]))
					{
						gridRowCount++;
					}
				}

				for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
				{
					if (Convert.ToBoolean(c1FlexGridDiscipline.Rows[i]["Import"]))
					{
						gridRowCount++;
					}
				}

				return gridRowCount;
			}
			catch
			{
				return 0;
			}
		}

		private void HideInstructionPanel()
		{
			panelOpenFormHolder.Visible = false;
		}

		private void AssignNumbersToFixedColumn(C1FlexGrid grid)
		{
			int rowCounter = 0;
			for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
			{
				grid[i, 0] = ++rowCounter;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Grid Methods *****/

		private void c1FlexGridFacility_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			//01222012 - add FacilityCriticality? - no, it's not necessary because nothing in the import grids depends on it

			try
			{
				if (e.Col == c1FlexGridFacility.Cols["FacilityName"].Index)
				{
					//the user may have changed the Facility name, so update the facility object
					((ImportFromTextFileFacility)listDictFacilityNamesImportCheckBox[
						Convert.ToInt32(c1FlexGridFacility[e.Row, "TempID"])]).ItemName = c1FlexGridFacility[e.Row, e.Col].ToString();
				}
				else if (e.Col == c1FlexGridFacility.Cols["Import"].Index)
				{
					UpdateFacilityAfterCheckingImportCheckBox(e.Row, Convert.ToBoolean(c1FlexGridFacility[e.Row, "Import"]));
				}
					//mam 07072011
				else if (e.Col == c1FlexGridFacility.Cols["FacilityCurrentYear"].Index)
				{
					if (c1FlexGridFacility[e.Row, "FacilityCurrentYear"] != null)
					{
						short facilityYear = 0;
						try
						{
							facilityYear = short.Parse(c1FlexGridFacility[e.Row, "FacilityCurrentYear"].ToString());
						}
						catch
						{
						}

						UpdateFacilityAfterChangingCurrentYear(e.Row, facilityYear);
					}
				}
				//mam 03202012 - even though the checkbox is not visible, the user can still check/uncheck it - don't allow this
				else if (e.Col == c1FlexGridFacility.Cols["RenameExistingFacility"].Index)
				{
					if (c1FlexGridFacility.GetCellRange(e.Row, e.Col).Style.Name == "CheckBoxHide")
					{
						c1FlexGridFacility[e.Row, e.Col] = null;
					}
				}
				else
				{
					ValidateSingleCell(c1FlexGridFacility, e.Row, c1FlexGridFacility.Cols[e.Col].Name, true);
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in c1FlexGridFacility_AfterEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		//mam 07072011
		private void UpdateFacilityAfterChangingCurrentYear(int gridRowIndex, short facilityYear)
		{
			try
			{
				int curTempID = (int)c1FlexGridFacility[gridRowIndex, "TempID"];
				((ImportFromTextFileFacility)listDictFacilityNames[curTempID]).CurrentYear = facilityYear;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in UpdateFacilityAfterChangingCurrentYear: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void UpdateFacilityAfterCheckingImportCheckBox(int gridRowIndex, bool importThisItem)
		{
			try
			{
				if (c1FlexGridFacility.Rows.Count == c1FlexGridFacility.Rows.Fixed)
				{
					return;
				}

				//find the current row's facility in the list dictionary and update the Import property
				IDictionaryEnumerator idEnumerator;
				CellRange cellRange;
				int curTempID = 0;
				int curFacExistingID = 0;
				int gridColIndex = c1FlexGridFacility.Cols["Import"].Index;

				if (gridRowIndex > -1)
				{
					//set properties for the current facility grid row
					curTempID = (int)c1FlexGridFacility[gridRowIndex, "TempID"];
					((ImportFromTextFileFacility)listDictFacilityNames[curTempID]).ImportThisItem = importThisItem;
					curFacExistingID = ((ImportFromTextFileFacility)listDictFacilityNames[curTempID]).ExistingID;

					//set style for one row only (user clicked an individual Import check box)
					cellRange = c1FlexGridFacility.GetCellRange(gridRowIndex, c1FlexGridFacility.Cols.Fixed, 
						gridRowIndex, c1FlexGridFacility.Cols.Count - 1);
				}
				else
				{
					//set properties for the current facility grid row
					idEnumerator = listDictFacilityNames.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						((ImportFromTextFileFacility)idEnumerator.Value).ImportThisItem = importThisItem;
					}

					//user clicked the check all/uncheck all button, so set style for all rows
					cellRange = c1FlexGridFacility.GetCellRange(c1FlexGridFacility.Rows.Fixed, c1FlexGridFacility.Cols.Fixed, 
						c1FlexGridFacility.Rows.Count - 1, c1FlexGridFacility.Cols.Count - 1);
				}

				//set the cell style
				//cellRange.Style = importThisItem? c1FlexGridFacility.Styles["Valid"]: c1FlexGridFacility.Styles["DontImport"];
				SetImportCellStyleAfterClickingImportAll(c1FlexGridFacility, gridRowIndex, importThisItem);

				//load the list dictionary with the existing facilities, and the facilities to be imported
				listDictFacilityNamesImportCheckBox.Clear();
				idEnumerator = listDictFacilityNamesAll.GetEnumerator();
				while (idEnumerator.MoveNext())
				{
					if (((ImportFromTextFileFacility)idEnumerator.Value).ImportThisItem ||
						((ImportFromTextFileFacility)idEnumerator.Value).ExistingID > 0)
					{
						listDictFacilityNamesImportCheckBox.Add(((ImportFromTextFileFacility)idEnumerator.Value).TempID, 
							(ImportFromTextFileFacility)idEnumerator.Value);
					}
				}

				c1FlexGridProcess.Cols["FacilityName"].DataMap = listDictFacilityNamesImportCheckBox;
				c1FlexGridComponent.Cols["FacilityName"].DataMap = listDictFacilityNamesImportCheckBox;

				//***************

				//set the FacilityID and ParentExists properties for each process in this facility
				ImportFromTextFileProcess process = new ImportFromTextFileProcess();
				ImportFromTextFileFacility facility = new ImportFromTextFileFacility();
				for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
				{
					process = (ImportFromTextFileProcess)listDictProcessNamesAll[Convert.ToInt32(c1FlexGridProcess[i, "TempID"])];
					process.ParentExists = false;
					process.FacilityID = 0;
					if (c1FlexGridProcess[i, "FacilityName"] != null 
						&& c1FlexGridProcess[i, "FacilityName"].GetType() == typeof(ImportFromTextFileFacility))
					{
						facility = (ImportFromTextFileFacility)c1FlexGridProcess[i, "FacilityName"];
						process.ParentExists = facility.ExistingID > 0? true: facility.ImportThisItem;
						process.FacilityID = facility.ExistingID == 0? facility.TempID: facility.ExistingID;
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in UpdateFacilityAfterCheckingImportCheckBox: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void c1FlexGridProcess_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			try
			{
				if (e.Col == c1FlexGridProcess.Cols["FacilityName"].Index)
				{
					//set process properties
					ImportFromTextFileFacility facility = c1FlexGridProcess[e.Row, "FacilityName"] as ImportFromTextFileFacility;
					ImportFromTextFileProcess process = (ImportFromTextFileProcess)listDictProcessNamesImportCheckBox[
						Convert.ToInt32(c1FlexGridProcess[e.Row, "TempID"])];
					process.FacilityID = facility.TempID;
					process.ParentExists = true;
				}
				else if (e.Col == c1FlexGridProcess.Cols["ProcessName"].Index)
				{
					//the user may have changed the Process name, so update the process object
					((ImportFromTextFileProcess)importCollection.listProcess[
						Convert.ToInt32(c1FlexGridProcess[e.Row, "TempID"])]).ItemName = c1FlexGridProcess[e.Row, e.Col].ToString();
				}
				else if (e.Col == c1FlexGridProcess.Cols["Import"].Index)
				{
					UpdateProcessAfterCheckingImportCheckBox(e.Row, Convert.ToBoolean(c1FlexGridProcess[e.Row, "Import"]));
				}
				//mam 03202012 - even though the checkbox is not visible, the user can still check/uncheck it - don't allow this
				else if (e.Col == c1FlexGridProcess.Cols["RenameExistingProcess"].Index)
				{
					if (c1FlexGridProcess.GetCellRange(e.Row, e.Col).Style.Name == "CheckBoxHide")
					{
						c1FlexGridProcess[e.Row, e.Col] = null;
					}
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in c1FlexGridProcess_AfterEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void UpdateProcessAfterCheckingImportCheckBox(int gridRowIndex, bool importThisItem)
		{
			try
			{
				if (c1FlexGridProcess.Rows.Count == c1FlexGridProcess.Rows.Fixed)
				{
					return;
				}

				//find the current row's process in the list dictionary and update the Import property
				IDictionaryEnumerator idEnumerator;
				CellRange cellRange;
				int curTempID = 0;
				int curProcExistingID = 0;
				int gridColIndex = c1FlexGridProcess.Cols["Import"].Index;

				if (gridRowIndex > -1)
				{
					curTempID = (int)c1FlexGridProcess[gridRowIndex, "TempID"];
					((ImportFromTextFileProcess)listDictProcessNames[curTempID]).ImportThisItem = importThisItem;
					curProcExistingID = ((ImportFromTextFileProcess)listDictProcessNames[curTempID]).ExistingID;

					//set style for one row only (user clicked an individual Import check box)
					cellRange = c1FlexGridProcess.GetCellRange(gridRowIndex, c1FlexGridProcess.Cols.Fixed, 
						gridRowIndex, c1FlexGridProcess.Cols.Count - 1);
				}
				else
				{
					//set properties for the current process grid row
					idEnumerator = listDictProcessNames.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						((ImportFromTextFileProcess)idEnumerator.Value).ImportThisItem = importThisItem;
					}

					//user clicked the check all/uncheck all button, so set style for all rows
					cellRange = c1FlexGridProcess.GetCellRange(c1FlexGridProcess.Rows.Fixed, c1FlexGridProcess.Cols.Fixed, 
						c1FlexGridProcess.Rows.Count - 1, c1FlexGridProcess.Cols.Count - 1);
				}

				//set the cell style
				//cellRange.Style = importThisItem? c1FlexGridProcess.Styles["Valid"]: c1FlexGridProcess.Styles["DontImport"];
				SetImportCellStyleAfterClickingImportAll(c1FlexGridProcess, gridRowIndex, importThisItem);

				//load the list dictionary with the existing processes, and the processes to be imported
				listDictProcessNamesImportCheckBox.Clear();
				idEnumerator = listDictProcessNamesAll.GetEnumerator();
				while (idEnumerator.MoveNext())
				{
					if (((ImportFromTextFileProcess)idEnumerator.Value).ImportThisItem ||
						((ImportFromTextFileProcess)idEnumerator.Value).ExistingID > 0)
					{
						listDictProcessNamesImportCheckBox.Add(((ImportFromTextFileProcess)idEnumerator.Value).TempID, 
							(ImportFromTextFileProcess)idEnumerator.Value);
					}
				}

				c1FlexGridComponent.Cols["ProcessName"].DataMap = listDictProcessNamesImportCheckBox;
				c1FlexGridComponentPN.Cols["ProcessName"].DataMap = listDictProcessNamesImportCheckBox;

				//***************

				//set the ProcessID and ParentExists properties for each component in this process
				ImportFromTextFileComponent component = new ImportFromTextFileComponent();
				ImportFromTextFileProcess process = new ImportFromTextFileProcess();
				for (int gridNumber = 0; gridNumber <= 1; gridNumber++)
				{
					C1FlexGrid grid = c1FlexGridComponent;
					if (gridNumber > 0)
					{
						grid = c1FlexGridComponentPN;
					}
					for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
					{
						component = (ImportFromTextFileComponent)listDictComponentNamesAll[Convert.ToInt32(grid[i, "TempID"])];
						component.ParentExists = false;
						component.ProcessID = 0;
						if (grid[i, "ProcessName"] != null 
							&& grid[i, "ProcessName"].GetType() == typeof(ImportFromTextFileProcess))
						{
							process = (ImportFromTextFileProcess)grid[i, "ProcessName"];
							component.ParentExists = process.ExistingID > 0? true: process.ImportThisItem;
							component.ProcessID = process.ExistingID == 0? process.TempID: process.ExistingID;
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in UpdateProcessAfterCheckingImportCheckBox: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void ComponentGrid_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;
				
				if (e.Col == grid.Cols["ComponentName"].Index)
				{
					//the user may have changed the Component name, so update the component object
					((ImportFromTextFileComponent)listDictComponentNamesImportCheckBox[
						Convert.ToInt32(grid[e.Row, "TempID"])]).ItemName = grid[e.Row, e.Col].ToString();
				}
				else if (e.Col == grid.Cols["Import"].Index)
				{
					UpdateComponentAfterCheckingImportCheckBox(grid, e.Row, Convert.ToBoolean(grid[e.Row, "Import"]));
				}
				//mam 07072011 - set the selection to the list dictionary value rather than the list dictionary key
				//	we shouldn't have to do this, but this combo box is behaving differently other combos in the grid
				else if (tabControlImport.SelectedTab.Name == "tabPageComponent" && e.Col == grid.Cols["CipPlanningMode"].Index)
				{
					int selectedKey = Convert.ToInt32(grid[e.Row, e.Col]);
					int selectedIndex = sortedListCip.IndexOfKey(selectedKey);
					c1FlexGridComponent.SetData(e.Row, e.Col, sortedListCip.GetByIndex(selectedIndex).ToString());
					ValidateSingleCell(grid, e.Row, grid.Cols[e.Col].Name, true);
				}
				//mam 03202012 - even though the checkbox is not visible, the user can still check/uncheck it - don't allow this
				else if (e.Col == grid.Cols["RenameExistingComponent"].Index)
				{
					if (grid.GetCellRange(e.Row, e.Col).Style.Name == "CheckBoxHide")
					{
						grid[e.Row, e.Col] = null;
					}
				}
				//mam 07072011
				else
				{
					ValidateSingleCell(grid, e.Row, grid.Cols[e.Col].Name, true);
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in ComponentGrid_AfterEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void UpdateComponentAfterCheckingImportCheckBox(C1FlexGrid grid, int gridRowIndex, bool importThisItem)
		{
			try
			{
				if (grid.Rows.Count == grid.Rows.Fixed)
				{
					return;
				}

				//find the current row's component in the list dictionary and update the Import property
				IDictionaryEnumerator idEnumerator;
				CellRange cellRange;
				int curTempID = 0;
				int curCompExistingID = 0;
				int gridColIndex = grid.Cols["Import"].Index;

				if (gridRowIndex > -1)
				{
					curTempID = (int)grid[gridRowIndex, "TempID"];
					((ImportFromTextFileComponent)listDictComponentNames[curTempID]).ImportThisItem = importThisItem;
					curCompExistingID = ((ImportFromTextFileComponent)listDictComponentNames[curTempID]).ExistingID;

					//set style for one row only (user clicked an individual Import check box)
					cellRange = grid.GetCellRange(gridRowIndex, grid.Cols.Fixed, 
						gridRowIndex, grid.Cols.Count - 1);
				}
				else
				{
					//loop through the grid rather than the list because some components in the list might be in
					//	the other component grid, and are unaffected by the user pressing the "check all" button
					//	for this component grid
					for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
					{
						((ImportFromTextFileComponent)listDictComponentNames[
							Convert.ToInt32(grid[i, "TempID"])]).ImportThisItem = importThisItem;
					}

					//user clicked the check all/uncheck all button, so set style for all rows
					cellRange = grid.GetCellRange(grid.Rows.Fixed, grid.Cols.Fixed, 
						grid.Rows.Count - 1, grid.Cols.Count - 1);
				}

				//set the cell style
				//cellRange.Style = importThisItem? grid.Styles["Valid"]: grid.Styles["DontImport"];
				SetImportCellStyleAfterClickingImportAll(grid, gridRowIndex, importThisItem);

				//load the list dictionary with the components to be imported
				listDictComponentNamesImportCheckBox.Clear();
				idEnumerator = listDictComponentNames.GetEnumerator();
				while (idEnumerator.MoveNext())
				{
					if (((ImportFromTextFileComponent)idEnumerator.Value).ImportThisItem && 
						((ImportFromTextFileComponent)idEnumerator.Value).ExistingID == 0)
						//if (((ImportFromTextFileComponent)idEnumerator.Value).ImportThisItem ||
						//	((ImportFromTextFileComponent)idEnumerator.Value).ExistingID > 0)
					{
						listDictComponentNamesImportCheckBox.Add(((ImportFromTextFileComponent)idEnumerator.Value).TempID, 
							(ImportFromTextFileComponent)idEnumerator.Value);
					}
				}

				c1FlexGridDiscipline.Cols["ComponentName"].DataMap = listDictComponentNamesImportCheckBox;

				//***************

				//find each discipline that uses this ComponentID and set its ParentExists property
				idEnumerator = listDictDisciplineNamesAll.GetEnumerator();
				while (idEnumerator.MoveNext())
				{
					if (gridRowIndex < 0)
					{
						//if a component exists for the discipline, set the ParentExists property
						if (listDictComponentNames.Contains(((ImportFromTextFileDiscipline)idEnumerator.Value).ComponentID))
						{
							((ImportFromTextFileDiscipline)idEnumerator.Value).ParentExists = importThisItem;
						}
						continue;
					}

					if (((ImportFromTextFileDiscipline)idEnumerator.Value).ComponentID == curTempID
						|| ((ImportFromTextFileDiscipline)idEnumerator.Value).ComponentID == curCompExistingID)
					{
						((ImportFromTextFileDiscipline)idEnumerator.Value).ParentExists = importThisItem;
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in UpdateComponentAfterCheckingImportCheckBox: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void c1FlexGridDiscipline_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			try
			{
				if (e.Col == c1FlexGridDiscipline.Cols["Import"].Index)
				{
					UpdateDisciplineAfterCheckingImportCheckBox(e.Row, Convert.ToBoolean(c1FlexGridDiscipline[e.Row, "Import"]));
				}
				//mam 07072011
				else if (e.Col == c1FlexGridDiscipline.Cols["ComponentName"].Index)
				{
					//mam 07072011 - get the facility's current year to calculate the last rehab year

					ImportFromTextFileComponent component = (ImportFromTextFileComponent)c1FlexGridDiscipline[e.Row, "ComponentName"];
					short facilityYear = GetFacilityYearFromComponent(component);
					decimal rehabInterval = 0m;
					int lastRehabYear = 0;
					short oul = 0;
					short installationYear = 0;

					if (c1FlexGridDiscipline[e.Row, "OriginalUsefulLife"] != null)
					{
						try
						{
							oul = short.Parse(c1FlexGridDiscipline[e.Row, "OriginalUsefulLife"].ToString());
						}
						catch
						{
						}
					}

					rehabInterval = Math.Round((decimal)oul / 2, 1);
					
					if (c1FlexGridDiscipline[e.Row, "InstallationYear"] != null)
					{
						try
						{
							installationYear = short.Parse(c1FlexGridDiscipline[e.Row, "InstallationYear"].ToString());
						}
						catch
						{
						}
					}

					//mam 01222012
					int inspectionYear = 0;
					if (c1FlexGridDiscipline[e.Row, "InspectionDate"] != null)
					{
						try
						{
							DateTime inspectionDate = DateTime.Parse(c1FlexGridDiscipline[e.Row, "InspectionDate"].ToString());
							inspectionYear = inspectionDate.Year;
						}
						catch
						{
						}
					}

					//mam 01222012 - added inspectionYear
					lastRehabYear = LocalRehabYearLastDefault(facilityYear, installationYear, rehabInterval, inspectionYear);

					//mam 01222012 - need next rehab year and next replacement year here? - no - they are not calculated based
					//	on component data - they are either user-entered or calculated by WAM after import

					c1FlexGridDiscipline.SetData(e.Row, "RehabInterval", rehabInterval.ToString());
					c1FlexGridDiscipline.SetData(e.Row, "RehabYearLast", lastRehabYear.ToString());
				}
				else if (e.Col == c1FlexGridDiscipline.Cols["DisciplineType"].Index)
				{
					//determine the discipline type for the current row
					int curDiscTypeID = Convert.ToInt32(c1FlexGridDiscipline[e.Row, "DisciplineType"]);

					ImportFromTextFileDiscipline curDisc = ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll
						[Convert.ToInt32(c1FlexGridDiscipline[e.Row, "TempID"])]);
					if (curDiscTypeID == 0)
					{
						curDisc.DisciplineType = WAM.UI.NodeType.DisciplineMech;
						c1FlexGridDiscipline[e.Row, "OriginalUsefulLife"] = 20;
					}
					else if (curDiscTypeID == 1)
					{
						curDisc.DisciplineType = WAM.UI.NodeType.DisciplineStruct;
						c1FlexGridDiscipline[e.Row, "OriginalUsefulLife"] = 50;
					}
					else if (curDiscTypeID == 2)
					{
						curDisc.DisciplineType = WAM.UI.NodeType.DisciplineLand;
						c1FlexGridDiscipline[e.Row, "OriginalUsefulLife"] = 50;
					}
				}
				else
				{
					ValidateSingleCell(c1FlexGridDiscipline, e.Row, c1FlexGridDiscipline.Cols[e.Col].Name, true);
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in c1FlexGridDiscipline_AfterEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void UpdateDisciplineAfterCheckingImportCheckBox(int gridRowIndex, bool importThisItem)
		{
			try
			{
				if (c1FlexGridDiscipline.Rows.Count == c1FlexGridDiscipline.Rows.Fixed)
				{
					return;
				}

				IDictionaryEnumerator idEnumerator;
				CellRange cellRange;
				int curTempID = 0;
				int curDiscExistingID = 0;
				int gridColIndex = c1FlexGridDiscipline.Cols["Import"].Index;

				if (gridRowIndex > -1)
				{
					curTempID = (int)c1FlexGridDiscipline[gridRowIndex, "TempID"];

					((ImportFromTextFileDiscipline)listDictDisciplineNames[curTempID]).ImportThisItem = importThisItem;
					curDiscExistingID = ((ImportFromTextFileDiscipline)listDictDisciplineNames[curTempID]).ExistingID;

					cellRange = c1FlexGridDiscipline.GetCellRange(gridRowIndex, c1FlexGridDiscipline.Cols.Fixed, 
						gridRowIndex, c1FlexGridDiscipline.Cols.Count - 1);
				}
				else
				{
					//set properties for the current process grid row
					idEnumerator = listDictDisciplineNames.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						((ImportFromTextFileDiscipline)idEnumerator.Value).ImportThisItem = importThisItem;
					}

					cellRange = c1FlexGridDiscipline.GetCellRange(c1FlexGridDiscipline.Rows.Fixed, c1FlexGridDiscipline.Cols.Fixed, 
						c1FlexGridDiscipline.Rows.Count - 1, c1FlexGridDiscipline.Cols.Count - 1);
				}

				//set the cell style
				//cellRange.Style = importThisItem? c1FlexGridDiscipline.Styles["Valid"]: c1FlexGridDiscipline.Styles["DontImport"];
				SetImportCellStyleAfterClickingImportAll(c1FlexGridDiscipline, gridRowIndex, importThisItem);

				//load the list dictionary with the disciplines to be imported
				listDictDisciplineNamesImportCheckBox.Clear();
				idEnumerator = listDictDisciplineNamesAll.GetEnumerator();
				while (idEnumerator.MoveNext())
				{
					if (((ImportFromTextFileDiscipline)idEnumerator.Value).ImportThisItem && 
						((ImportFromTextFileDiscipline)idEnumerator.Value).ExistingID == 0)
					{
						listDictDisciplineNamesImportCheckBox.Add(((ImportFromTextFileDiscipline)idEnumerator.Value).TempID, 
							(ImportFromTextFileDiscipline)idEnumerator.Value);
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in UpdateDisciplineAfterCheckingImportCheckBox: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		public void SetGridRowImportCellStyleAfterPaste()
		{
			try
			{
				if (tabControlImport.SelectedTab.Name.Equals(tabPageFacility.Name))
				{
					for (int i = c1FlexGridFacility.Rows.Fixed; i < c1FlexGridFacility.Rows.Count; i++)
					{
						UpdateFacilityAfterCheckingImportCheckBox(i, Convert.ToBoolean(c1FlexGridFacility[i, "Import"]));
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageProcess.Name))
				{
					for (int i = c1FlexGridProcess.Rows.Fixed; i < c1FlexGridProcess.Rows.Count; i++)
					{
						UpdateProcessAfterCheckingImportCheckBox(i, Convert.ToBoolean(c1FlexGridProcess[i, "Import"]));
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponent.Name))
				{
					for (int i = c1FlexGridComponent.Rows.Fixed; i < c1FlexGridComponent.Rows.Count; i++)
					{
						UpdateComponentAfterCheckingImportCheckBox(c1FlexGridComponent, i, Convert.ToBoolean(c1FlexGridComponent[i, "Import"]));
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageComponentPN.Name))
				{
					for (int i = c1FlexGridComponentPN.Rows.Fixed; i < c1FlexGridComponentPN.Rows.Count; i++)
					{
						UpdateComponentAfterCheckingImportCheckBox(c1FlexGridComponentPN, i, Convert.ToBoolean(c1FlexGridComponentPN[i, "Import"]));
					}
				}
				else if (tabControlImport.SelectedTab.Name.Equals(tabPageDiscipline.Name))
				{
					for (int i = c1FlexGridDiscipline.Rows.Fixed; i < c1FlexGridDiscipline.Rows.Count; i++)
					{
						UpdateDisciplineAfterCheckingImportCheckBox(i, Convert.ToBoolean(c1FlexGridDiscipline[i, "Import"]));
					}
				}

				if (allowContinuousValidation)
					ValidateGridData();
			}
			catch
			{
			}
		}

		private void SetImportCellStyleAfterClickingImportAll(C1FlexGrid grid, int gridRowIndex, bool importThisItem)
		{
			try
			{
				CellRange cellRangeSingleCell;
				for (int i = grid.Cols.Fixed; i < grid.Cols.Count; i++)
				{
					if (grid.Cols[i].UserData == null || grid.Cols[i].UserData.ToString().Length == 0)
					{
						//the column is to be imported, so the cell style can be changed
						//(if the column was not to be imported, the color of the cell should be left as the "Don't Import" color)

						if (gridRowIndex > -1)
						{
							cellRangeSingleCell = grid.GetCellRange(gridRowIndex, i);

							//mam 07072011
							//cellRangeSingleCell.Style = importThisItem ? grid.Styles["Valid"] : grid.Styles["DontImport"];
							cellRangeSingleCell.Style = grid.Styles["Valid"];
							if (importThisItem)
							{
								if (cellRangeSingleCell.UserData != null && cellRangeSingleCell.UserData.ToString().Length > 0)
								{
									if (cellRangeSingleCell.UserData.ToString().StartsWith("*DEFAULT*"))
									{
										cellRangeSingleCell.Style = grid.Styles["DefaultValue"];
									}
								}
							}
							else
							{
								cellRangeSingleCell.Style = grid.Styles["DontImport"];
							}
						}
						else
						{
							for (int j = grid.Rows.Fixed; j < grid.Rows.Count; j++)
							{
								cellRangeSingleCell = grid.GetCellRange(j, i);

								//mam 07072011
								//cellRangeSingleCell.Style = importThisItem ? grid.Styles["Valid"] : grid.Styles["DontImport"];
								cellRangeSingleCell.Style = grid.Styles["Valid"];
								if (importThisItem)
								{
									if (cellRangeSingleCell.UserData != null && cellRangeSingleCell.UserData.ToString().Length > 0)
									{
										if (cellRangeSingleCell.UserData.ToString().StartsWith("*DEFAULT*"))
										{
											cellRangeSingleCell.Style = grid.Styles["DefaultValue"];
										}
									}
								}
								else
								{
									cellRangeSingleCell.Style = grid.Styles["DontImport"];
								}
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		private void c1FlexGridFacility_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			/* If the 'Alt' and 'E' keys are pressed, allow the user to edit the TreeNode label. */
			//if(e.Alt && e.KeyCode == Keys.E)
			//{
			//	treeView1.LabelEdit = true;
			//	// If there is a TreeNode under the mose cursor, begin editing. 
			//	TreeNode editNode = treeView1.GetNodeAt(
			//		treeView1.PointToClient(Control.MousePosition));
			//	if(editNode != null)
			//	{ 
			//		editNode.BeginEdit();
			//	}
			//}

			GridMouseMove(sender, e);
		}

		private void GridMouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			C1FlexGrid curGrid = (C1FlexGrid)sender;

			//if (((C1FlexGrid)sender).MouseRow < 0)
			if (curGrid.MouseRow < 0)
			{
				return;
			}

			//if the cell has UserData, then display the error message
			//not necessarily - a cell now has UserData if it has been populated with a default value
			CellRange cellRange = (curGrid.GetCellRange(curGrid.MouseRow, curGrid.MouseCol));
			
			//mam 07072011 - add check for cell style
			if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style.Name == "Error")
			{
				if (cellRange.UserData.ToString().IndexOf("\r\n") > -1)
				{
					labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
				}
				else
				{
					labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
				}
				labelErrorTip.Text = cellRange.UserData.ToString();
				labelErrorTip.ForeColor = Color.Black;
			}
			else
			{
				//the mouse is not being held over a cell with an error, so display the instruction message in the error box
				labelErrorTip.Text = errorTipMessage;
				labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
				labelErrorTip.ForeColor = Color.Gray;
			}

			//set the information message text
			labelGeneralMessage.Text = "";
			if (tabControlImport.SelectedTab.Name == tabPageComponentPN.Name)
			{
				labelGeneralMessage.Text = importPipeNodedataMessage;
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "CustomENRTable")
			{
				labelGeneralMessage.Text = "To use the default (20-City Average) ENR values, select [none] from the Custom ENR Table drop-down list";
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "AcquisitionCost")
			{
				labelGeneralMessage.Text = "Leave the Acquisition Cost grid cell blank and WAM will automatically calculate the value after the data is imported";
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "CurrentValue")
			{
				labelGeneralMessage.Text = "Leave the Current Value grid cell blank and WAM will automatically calculate the value after the data is imported";
			}

			//mam 01222012
			//mam 07072011
			//else if (curGrid.Cols[curGrid.MouseCol].Name == "RehabNext")
			//{
			//	labelGeneralMessage.Text = "Leave the Time to Next Rehabilitation grid cell blank and WAM will automatically calculate the value after the data is imported";
			//}

			else if (curGrid.Cols[curGrid.MouseCol].Name == "RepairCost")
			{
				labelGeneralMessage.Text = "Leave the Repair Cost grid cell blank and WAM will automatically calculate the value after the data is imported";
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "Vulnerability")
			{
				labelGeneralMessage.Text = "Leave the Vulnerability grid cell blank and WAM will automatically calculate the value after the data is imported";
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "DisciplineType")
			{
				//labelGeneralMessage.Text = "Changing the Discipline Type will automatically reset the Original Useful Life to its default value,";
				//labelGeneralMessage.Text += " but the user can change the Original Useful Life to any value desired";

				//labelGeneralMessage.Text = "Changing the Discipline Type will automatically reset the Original Useful Life to its discipline-specific";
				//labelGeneralMessage.Text += " default value, but the user can override the default value and set the Original Useful Life";
				//labelGeneralMessage.Text += " to another value if so desired.";

				labelGeneralMessage.Text = "Changing the Discipline Type will automatically reset the Original Useful Life to its";
				labelGeneralMessage.Text += " discipline-specific default value. The user can ";
				labelGeneralMessage.Text += " set the Original Useful Life to another value, if desired.";
			}
			else if (curGrid.Cols[curGrid.MouseCol].Name == "OriginalUsefulLife")
			{
				//labelGeneralMessage.Text = "Original Useful Life default values:\r\n     Mechanical: 20 years\r\n     Structural: 50 years\r\n     Civil: 50 years\r\n";
				labelGeneralMessage.Text = "Original Useful Life default values:\r\nMech: 20 years; Structural and Civil: 50 years";
			}
			else if (curGrid.Name == c1FlexGridDiscipline.Name && curGrid.Cols[curGrid.MouseCol].Name == "ComponentName")
			{
				labelGeneralMessage.Text = "Changing the Component will automatically set the Rehabilitation Interval and the ";
				labelGeneralMessage.Text += " Last Rehabilitation Year to their default values.  The user can change these values, if desired.";
			}
			//mam 07072011
			else if (curGrid.Cols[curGrid.MouseCol].Name == "RehabInterval")
			{
				labelGeneralMessage.Text = "Rehabilitation Interval default value = 50% of Original Useful Life";
			}
			//mam 07072011
			else if (curGrid.Cols[curGrid.MouseCol].Name == "RehabYearLast")
			{
				labelGeneralMessage.Text = "Last Rehabilitation Year default value is the most recent possible year that rehabilitation could have";
				labelGeneralMessage.Text += " occurred, based on Facility Current Year, Installation Year and Rehabilitation Interval";
			}

			//mam 01222012
			else if (curGrid.Cols[curGrid.MouseCol].Name == "RehabYearNext")
			{
				labelGeneralMessage.Text = "Leave the Next Rehabilitation Year grid cell blank and WAM will automatically calculate the value after the data is imported";
			}

			////mam 01222012
			//else if (curGrid.Cols[curGrid.MouseCol].Name == "RehabYearNext")
			//{
			//	labelGeneralMessage.Text = "Next Rehabilitation Year default value is Economic Remaining Remaining Useful Life (EcRUL) + Inspection Year";
			//	labelGeneralMessage.Text += " (EcRUL = OUL / 2 - OUL * Condition Fraction)";
			//}

			//mam 07072011
			else if (curGrid.Cols[curGrid.MouseCol].Name == "NextReplacementYear")
			{
				labelGeneralMessage.Text = "Leave the Next Replacement Year grid cell blank and WAM will automatically calculate the value after the data is imported";
			}

			//mam 07072011
			else if (curGrid.Cols[curGrid.MouseCol].Name == "NextReplacementYear")
			{
				labelGeneralMessage.Text = "Next Replacement Year default value is Evaluated Remaining Remaining Useful Life (EvRUL) + Inspection Year";
				labelGeneralMessage.Text += " (EvRUL = (1 - Condition Fraction) * OUL)";
			}

			//mam 07072011
			if (cellRange.UserData != null && cellRange.UserData.ToString().Length > 0 && cellRange.Style.Name == "DefaultValue")
			{
				string userData = cellRange.UserData.ToString().Replace("*DEFAULT*", "");
				if (labelGeneralMessage.Text != "" && curGrid.Cols[curGrid.MouseCol].Name != "RehabInterval" 
					&& curGrid.Cols[curGrid.MouseCol].Name != "RehabYearLast")
					////mam 01222012
					//&& curGrid.Cols[curGrid.MouseCol].Name != "RehabYearNext"
					//&& curGrid.Cols[curGrid.MouseCol].Name != "NextReplacementYear")
				{
					//if in comp pn tab, there is already a message about not being able to import pipes and nodes here
					//the message is long, so don't display it - just display the default value message
					labelGeneralMessage.Text = userData + Environment.NewLine + Environment.NewLine + labelGeneralMessage.Text;
					if (tabControlImport.SelectedTab.Name == tabPageComponentPN.Name)
					{
						labelGeneralMessage.Text = userData;
					}
				}
				else
				{
					labelGeneralMessage.Text = userData;
				}
			}

			SetInfoMsgVisibility(labelGeneralMessage.Text != "");

			//			if (curGrid.Cols[curGrid.MouseCol].UserData != null 
			//				&& curGrid.Cols[curGrid.MouseCol].UserData.ToString().Length > 0)
			//			{
			//				//panelGeneralMessage.Visible = true;
			//				////labelGeneralMessage.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			//				labelGeneralMessage.Text = curGrid.Cols[curGrid.MouseCol].UserData.ToString();
			//				////labelGeneralMessage.ForeColor = Color.Black;
			//				SetInfoMsgVisibility(true);
			//			}
			//			else
			//			{
			//				//panelGeneralMessage.Visible = false;
			//				////labelGeneralMessage.Text = generalTipMessage;
			//				////labelGeneralMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			//				////labelGeneralMessage.ForeColor = Color.Gray;
			//				SetInfoMsgVisibility(false);
			//			}
		}

		private void GridMouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			curMouseX = e.X;
			curMouseY = e.Y;
			curMouseRow = ((C1FlexGrid)sender).MouseRow;
		}

		private void ImportFromTextFile_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			labelErrorTip.Text = errorTipMessage;
			labelErrorTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			labelErrorTip.ForeColor = Color.Gray;
		}

		private bool pasteOccurred = false;
		private void GridKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;

				if (e.KeyCode == Keys.Delete)
				{
					if (grid.Col == 0)
					{
						PerformDeleteGridRowTasks(sender, e);
					}
					else
					{
						try
						{
							if (grid.Cols[grid.Col].AllowEditing && grid.Editor == null)
							{
								//the user has pressed the Delete key, but was not already editing the grid cell;
								//this means that the user wants to delete the contents of the cell - so do it here
								grid.StartEditing();
								grid.Editor.Text = "";
								grid.FinishEditing();

								//deleting the value from a combo box cell doesn't result in a call to AfterEdit
								//	so call it here
								if (grid.Cols[grid.Col].DataMap != null)
								{
									CellRange cellRange = grid.GetCellRange(grid.Row, grid.Col);
									cellRange.Data = null;
									grid[grid.Row, grid.Col] = null;

									if (allowContinuousValidation)
										ValidateGridData();
								}
							}
						}
						catch
						{
						}
					}
				}
				else if (e.Control && e.KeyCode == Keys.V)
				{
					pasteOccurred = true;
				}
			}
			catch
			{
			}
		}

		private void GridKeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			try
			{
				if (pasteOccurred)
				{
					//if the user pasted text into a cell, AfterEdit is not fired, so call ValidateGridData() here
					pasteOccurred = false;

					if (allowContinuousValidation)
						ValidateGridData();
				}
			}
			catch
			{
			}
		}

		private void GridBeforeSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;
				int rowToCheck = 0;

				if (listColsNoCheckMark.Contains(grid.Cols[e.Col].Name.ToString()))
				{
					return;
				}

				if (listColsCheckMarkRow1.Contains(grid.Cols[e.Col].Name.ToString()))
				{
					if (curMouseRow == 0)
					{
						e.Cancel = true;
						return;
					}

					rowToCheck = 1;
					curMouseY -= grid.Rows[rowToCheck].Top;
				}

				
				int colLeft = grid.Cols[e.Col].Left;
				int mouseX = curMouseX - colLeft - grid.ScrollPosition.X;
				int colWidth = grid.Cols[e.Col].WidthDisplay;

				if (curMouseRow == rowToCheck && colWidth - mouseX <= 12 && curMouseY < 12)
				{
					e.Cancel = true;

					CellRange cellRangeSingleCell;
					//CellRange cellRange = grid.GetCellRange(grid.Rows.Fixed, e.Col, grid.Rows.Count - 1, e.Col);
					string curCellStyleName = "Valid";
					//cellRange.Normalize();

					if (grid.Cols[e.Col].UserData == null || grid.Cols[e.Col].UserData.ToString().Length == 0)
					{
						//the column is currently being imported - change it to not be imported
						curCellStyleName = "DontImport";
						grid.Cols[e.Col].UserData = "DontImport";
					}
					else
					{
						//the column is currently not being imported - change it to be imported
						curCellStyleName = "Valid";
						grid.Cols[e.Col].UserData = "";
					}

					//ORIGINAL CODE:
					////set the style for each cell in the column
					////for (int i = cellRange.r1; i <= cellRange.r2; i++)
					//for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
					//{
					//	if (Convert.ToBoolean(grid[i, "Import"]))
					//	{
					//		//the row is being imported, so go ahead and set the Don't Import style
					//		cellRangeSingleCell = grid.GetCellRange(i, e.Col);
					//		cellRangeSingleCell.Style = grid.Styles[curCellStyleName];
					//	}
					//}

					//NEW CODE:
					for (int i = grid.Rows.Fixed; i < grid.Rows.Count; i++)
					{
						cellRangeSingleCell = grid.GetCellRange(i, e.Col);
						if (Convert.ToBoolean(grid[i, "Import"]))
						{
							if (curCellStyleName == "DontImport")
							{
								//the cell is being imported - change it to not being imported
								//if the cell style is DefaultValue, set it to DontImportDefaultValue; don't change the userdata
								//if the cell style is anything else, set it to DontImport; userdata can be set if desired

								if (cellRangeSingleCell.Style != null && cellRangeSingleCell.Style.Name == "DefaultValue")
								{
									//the cell is already marked as DefaultValue
									cellRangeSingleCell.Style = grid.Styles["DontImportDefaultValue"];
								}
								else
								{
									cellRangeSingleCell.Style = grid.Styles["DontImport"];
								}
							}
							else
							{
								//the cell is not being imported - change it to being imported
								//if the cell style was DefaultValue before it was set to not import, set it back to DefaultValue
								//otherwise, set it to Valid - if the contents are actually not valid, this will be corrected when the data is validated
								//	by calling ValidateGridData(), below

								if (cellRangeSingleCell.UserData != null && cellRangeSingleCell.UserData.ToString().IndexOf("*DEFAULT*") > -1)
								{
									cellRangeSingleCell.Style = grid.Styles["DefaultValue"];
								}
								else
								{
									cellRangeSingleCell.Style = grid.Styles["Valid"];
								}
							}
						}
					}

					if (allowContinuousValidation)
						ValidateGridData();
				}
			}
			catch
			{
			}
		}

		private void GridAfterSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
		{
			AssignNumbersToFixedColumn((C1FlexGrid)sender);
		}

		private void GridFinishEditing()
		{
			try
			{
				c1FlexGridFacility.FinishEditing();
				c1FlexGridProcess.FinishEditing();
				c1FlexGridComponent.FinishEditing();
				c1FlexGridComponentPN.FinishEditing();
				c1FlexGridDiscipline.FinishEditing();
				c1FlexGridSpreadsheetData.FinishEditing();
				c1FlexGridSampleData.FinishEditing();
			}
			catch
			{
			}
		}

		private void c1FlexGridProcess_ValidateEdit(object sender, C1.Win.C1FlexGrid.ValidateEditEventArgs e)
		{
			try
			{
				if (e.Col == c1FlexGridProcess.Cols["FacilityName"].Index)
				{
					ComboBox cbTest = c1FlexGridProcess.Editor as ComboBox;
					int dataMapIndex = -1;
					IDictionaryEnumerator idEnumerator = listDictFacilityNamesImportCheckBox.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						dataMapIndex++;
						if (cbTest.SelectedIndex == dataMapIndex)
						{
							c1FlexGridProcess[e.Row, "FacilityName"] = (ImportFromTextFileFacility)idEnumerator.Value;

							//ProcessGridSetProcPropsAfterSelectingFacility((ImportFromTextFileFacility)idEnumerator.Value, e.Row, e.Col);
							//set the error style to valid
							CellRange cellRange = c1FlexGridProcess.GetCellRange(e.Row, e.Col);
							cellRange.Style = c1FlexGridProcess.Styles["Valid"];
							cellRange.UserData = string.Empty;

							//set properties for the process in this row
							ImportFromTextFileFacility facility = (ImportFromTextFileFacility)idEnumerator.Value;
							IDictionaryEnumerator idEnumeratorProc = listDictProcessNames.GetEnumerator();
							while (idEnumeratorProc.MoveNext())
							{
								if (Convert.ToInt32(idEnumeratorProc.Key) == (int)c1FlexGridProcess[e.Row, "TempID"])
								{
									ImportFromTextFileProcess process = (ImportFromTextFileProcess)idEnumeratorProc.Value;
									process.ParentExists = facility.ExistingID > 0? true: facility.ImportThisItem;
									process.FacilityID = facility.ExistingID == 0? facility.TempID: facility.ExistingID;
									break;
								}
							}
							break;
						}
					}

					return;
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in c1FlexGridProcess_ValidateEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}		
		}

		private void ProcessGridSetProcPropsAfterSelectingFacility(ImportFromTextFileFacility facility, int rowNumber, int colNumber)
		{
			//set the error style to valid
			CellRange cellRange = c1FlexGridProcess.GetCellRange(rowNumber, colNumber);
			cellRange.Style = c1FlexGridProcess.Styles["Valid"];
			cellRange.UserData = string.Empty;

			//set properties for the process in this row
			//ImportFromTextFileFacility facility = (ImportFromTextFileFacility)idEnumerator.Value;
			IDictionaryEnumerator idEnumeratorProc = listDictProcessNames.GetEnumerator();

			while (idEnumeratorProc.MoveNext())
			{
				if (Convert.ToInt32(idEnumeratorProc.Key) == (int)c1FlexGridProcess[rowNumber, "TempID"])
				{
					ImportFromTextFileProcess process = (ImportFromTextFileProcess)idEnumeratorProc.Value;
					process.ParentExists = facility.ExistingID > 0? true: facility.ImportThisItem;
					process.FacilityID = facility.ExistingID == 0? facility.TempID: facility.ExistingID;
					break;
				}
			}
		}

		private void ComponentGrid_ValidateEdit(object sender, C1.Win.C1FlexGrid.ValidateEditEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;
				//ImportFromTextFileFacility facility;
				ImportFromTextFileProcess process;
				if (e.Col == grid.Cols["FacilityName"].Index)
				{
					ComboBox cbTest = grid.Editor as ComboBox;
					int dataMapIndex = -1;
					//IDictionaryEnumerator idEnumerator = listDictFacilityNamesAll.GetEnumerator();
					IDictionaryEnumerator idEnumerator = listDictFacilityNamesImportCheckBox.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						dataMapIndex++;
						if (cbTest.SelectedIndex == dataMapIndex)
						{
							grid[e.Row, "FacilityName"] = (ImportFromTextFileFacility)idEnumerator.Value;

							//set the error style to valid
							CellRange cellRange = grid.GetCellRange(e.Row, e.Col);
							cellRange.Style = grid.Styles["Valid"];
							cellRange.UserData = string.Empty;
							break;
						}
					}

					return;
				}
				else if (e.Col == grid.Cols["ProcessName"].Index)
				{
					ComboBox cb = grid.Editor as ComboBox;

					//find the corresponding process
					int facIDTemp = 0;

					//if the selected facility is not in the combo box, it doesn't exist, and cannot have any processes
					//(the FacilityName column may contain a string or it may be null or it may contain an import facility object)
					if (grid[e.Row, "FacilityName"] != null 
						&& grid[e.Row, "FacilityName"].GetType() == typeof(ImportFromTextFileFacility))
					{
						facIDTemp = ((ImportFromTextFileFacility)grid[e.Row, "FacilityName"]).TempID;
					}

					if (facIDTemp == 0)
					{
						return;
					}

					//grid.Cols["ProcessName"].DataType = typeof(ImportFromTextFileProcess);
					process = FindProcessForFacilityByIndexOrName(facIDTemp, cb.SelectedIndex, string.Empty);
					if (process != null)
					{
						grid.SetData(e.Row, "ProcessName", process);

						//set the error style to valid
						CellRange cellRange = grid.GetCellRange(e.Row, e.Col);
						cellRange.Style = grid.Styles["Valid"];
						cellRange.UserData = string.Empty;

						//set properties for the component in this row
						IDictionaryEnumerator idEnumeratorComp = listDictComponentNames.GetEnumerator();
						while (idEnumeratorComp.MoveNext())
						{
							if (((ImportFromTextFileComponent)idEnumeratorComp.Value).TempID == (int)grid[e.Row, "TempID"])
							{
								ImportFromTextFileComponent component = (ImportFromTextFileComponent)idEnumeratorComp.Value;
								component.ParentExists = process.ExistingID > 0? true: process.ImportThisItem;
								component.ProcessID = process.ExistingID == 0? process.TempID: process.ExistingID;
								break;
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in ComponentGrid_ValidateEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void DisciplineGrid_ValidateEdit(object sender, C1.Win.C1FlexGrid.ValidateEditEventArgs e)
		{
			try
			{
				ImportFromTextFileComponent component;
				C1FlexGrid grid = (C1FlexGrid)sender;

				if (e.Col == grid.Cols["ComponentName"].Index)
				{
					ComboBox cbTest = grid.Editor as ComboBox;
					int dataMapIndex = -1;
					IDictionaryEnumerator idEnumerator = listDictComponentNamesDiscCombo.GetEnumerator();
					while (idEnumerator.MoveNext())
					{
						dataMapIndex++;
						if (cbTest.SelectedIndex == dataMapIndex)
						{
							component = (ImportFromTextFileComponent)idEnumerator.Value;
							grid.SetData(e.Row, "ComponentName", component);

							//set the error style to valid (unless it is already set to DontImport)
							CellRange cellRange = grid.GetCellRange(e.Row, e.Col);
							if (cellRange.Style == null || cellRange.Style.Name != "DontImport")
							{
								cellRange.Style = grid.Styles["Valid"];
								cellRange.UserData = string.Empty;
							}

							break;
						}
					}

					//if the component was not found, set the facility and process cells to empty strings
					if (grid[e.Row, "ComponentName"] == null 
						|| grid[e.Row, "ComponentName"].GetType() != typeof(ImportFromTextFileComponent))
					{
						grid.SetData(e.Row, "FacilityName", string.Empty);
						grid.SetData(e.Row, "ProcessName", string.Empty);
						return;
					}

					//set the data in the Facility and Process columns based on the selected Component
					component = (ImportFromTextFileComponent)grid[e.Row, "ComponentName"];
					SetFacilityAndProcessInDiscGridBasedOnComponent(component, grid, e.Row, false);

					//set properties for the discipline in this row
					IDictionaryEnumerator idEnumeratorDisc = listDictDisciplineNames.GetEnumerator();
					while (idEnumeratorDisc.MoveNext())
					{
						if (((ImportFromTextFileDiscipline)idEnumeratorDisc.Value).TempID == (int)grid[e.Row, "TempID"])
						{
							ImportFromTextFileDiscipline discipline = (ImportFromTextFileDiscipline)idEnumeratorDisc.Value;
							discipline.ParentExists = component.ExistingID > 0? true: component.ImportThisItem;
							discipline.ComponentID = component.ExistingID == 0? component.TempID: component.ExistingID;
							break;
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DisciplineGrid_ValidateEdit: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		//mam 07072011
		private short GetFacilityYearFromComponent(ImportFromTextFileComponent component)
		{
			try
			{
				//mam 01222012
				if (component == null)
				{
					return 0;
				}

				short facilityYear = 0;

				//find the process and facility
				IDictionaryEnumerator idEnumeratorProc = listDictProcessNamesAll.GetEnumerator();
				while (idEnumeratorProc.MoveNext())
				{
					ImportFromTextFileProcess process = (ImportFromTextFileProcess)idEnumeratorProc.Value;
					int curProcID = process.ExistingID == 0? process.TempID: process.ExistingID;
					if (curProcID == component.ProcessID)
					{
						//found the parent process of the currently-selected component
						//find the parent of the process
						IDictionaryEnumerator idEnumeratorFac = listDictFacilityNamesAll.GetEnumerator();
						while (idEnumeratorFac.MoveNext())
						{
							ImportFromTextFileFacility facility = (ImportFromTextFileFacility)idEnumeratorFac.Value;
							int curFacID = facility.ExistingID == 0? facility.TempID: facility.ExistingID;
							if (curFacID == process.FacilityID)
							{
								if (curFacID > 0)
								{
									Facility facility2 = CacheManager.GetFacility(facility.InfoSetID, curFacID);
									return facility2.CurrentYear;
								}
								return facility.CurrentYear;
							}
						}
					}
				}

				return facilityYear;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in GetFacilityYearFromComponent: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return 0;
			}
		}

		private bool SetFacilityAndProcessInDiscGridBasedOnComponent(ImportFromTextFileComponent component, 
			C1FlexGrid grid, int gridRowIndex, bool getStatusOnly)
		{
			try
			{
				bool foundFac = false;
				bool foundProc = false;

				//find the process and facility
				IDictionaryEnumerator idEnumeratorProc = listDictProcessNamesAll.GetEnumerator();
				while (idEnumeratorProc.MoveNext())
				{
					ImportFromTextFileProcess process = (ImportFromTextFileProcess)idEnumeratorProc.Value;
					int curProcID = process.ExistingID == 0? process.TempID: process.ExistingID;
					if (curProcID == component.ProcessID)
					{
						//found the parent process of the currently-selected component
						if (!getStatusOnly)
						{
							grid.SetData(gridRowIndex, "ProcessName", process);
						}
						foundProc = true;

						//find the parent of the process
						IDictionaryEnumerator idEnumeratorFac = listDictFacilityNamesAll.GetEnumerator();
						while (idEnumeratorFac.MoveNext())
						{
							ImportFromTextFileFacility facility = (ImportFromTextFileFacility)idEnumeratorFac.Value;
							int curFacID = facility.ExistingID == 0? facility.TempID: facility.ExistingID;
							if (curFacID == process.FacilityID)
							{
								//found the parent facility of the process
								if (!getStatusOnly)
								{
									grid.SetData(gridRowIndex, "FacilityName", facility);
								}
								foundFac = true;
								break;
							}
						}
						break;
					}
				}

				if (!getStatusOnly)
				{
					if (!foundFac)
					{
						grid.SetData(gridRowIndex, "FacilityName", string.Empty);
						grid.SetData(gridRowIndex, "FacilityName", null);
					}
					if (!foundProc)
					{
						grid.SetData(gridRowIndex, "ProcessName", string.Empty);
						grid.SetData(gridRowIndex, "ProcessName", null);
					}
				}

				return !foundFac || !foundProc? false: true;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in SetFacilityAndProcessInDiscGridBasedOnComponent: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		private void ComponentGrid_SetupEditor(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;

				//load the combo box with the processes that belong to the selected facility
				if (grid.Cols[e.Col].Name == "ProcessName")
				{
					int facIDTemp = 0;
					ComboBox comboBox = grid.Editor as ComboBox;
					if (comboBox == null)
					{
						return;
					}

					comboBox.Items.Clear();

					//if the selected facility is not in the combo box, it doesn't exist, and cannot have any processes
					//(the FacilityName column may contain a string or it may be null or it may contain an import facility object)
					if (grid[e.Row, "FacilityName"] != null 
						&& grid[e.Row, "FacilityName"].GetType() == typeof(ImportFromTextFileFacility))
					{
						facIDTemp = ((ImportFromTextFileFacility)grid[e.Row, "FacilityName"]).TempID;
					}

					//if facIDTemp is zero, the FacilityName col contains a string or is null, so just add all Processes
					//	to the combo box
					if (facIDTemp == 0)
					{
						//no - don't do this
						//						IDictionaryEnumerator idEnumeratorProc = listDictProcessNamesAll.GetEnumerator();
						//						while (idEnumeratorProc.MoveNext())
						//						{
						//							comboBox.Items.Add(((ImportFromTextFileProcess)idEnumeratorProc.Value).ItemName);
						//						}
						return;
					}

					//comboBox.Items.Clear();
					if (((ImportFromTextFileFacility)grid[e.Row, "FacilityName"]).ImportThisItem
						|| ((ImportFromTextFileFacility)grid[e.Row, "FacilityName"]).ExistingID > 0)
					{
						FindProcessesForFacility(ref comboBox, facIDTemp, 0);
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in ComponentGrid_SetupEditor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void FindProcessesForFacility(ref ComboBox comboBox, int facIDTemp, int comboBoxIndex)
		{
			try
			{
				//get the facility
				ImportFromTextFileFacility facility = (ImportFromTextFileFacility)listDictFacilityNamesAll[facIDTemp];
				int facIDExisting = facility.ExistingID == 0? facility.TempID: facility.ExistingID;

				//loop through the process list to find processes with same facility id as facIDExisting
				IDictionaryEnumerator idEnumeratorProc = listDictProcessNamesAll.GetEnumerator();
				while (idEnumeratorProc.MoveNext())
				{
					if (((ImportFromTextFileProcess)idEnumeratorProc.Value).FacilityID == facIDExisting
						&& (((ImportFromTextFileProcess)idEnumeratorProc.Value).ImportThisItem
						|| ((ImportFromTextFileProcess)idEnumeratorProc.Value).ExistingID > 0))
					{
						//found a process that exists in the facility - add the process to the combo box
						comboBox.Items.Add(((ImportFromTextFileProcess)idEnumeratorProc.Value).ItemName);
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in FindProcessesForFacility: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void DisciplineGrid_SetupEditor(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			try
			{
				C1FlexGrid grid = (C1FlexGrid)sender;

				//don't change the items available in the Process or Component combo boxes because we are now not
				//	allowing the user to select the Facility or Process in the Discipline grid - the user can select
				//  only from the full list of Components that are to be imported (not any existing Components)

				if (grid.Cols[e.Col].Name == "ComponentName")
				{
					ComboBox comboBox = grid.Editor as ComboBox;
					if (comboBox == null)
					{
						return;
					}

					//add the components to the combo box that have a parent process
					comboBox.Items.Clear();
					listDictComponentNamesDiscCombo.Clear();

					ImportFromTextFileComponent component = new ImportFromTextFileComponent();
					IDictionaryEnumerator idEnumeratorComp = listDictComponentNamesImportCheckBox.GetEnumerator();
					while (idEnumeratorComp.MoveNext())
					{
						component = (ImportFromTextFileComponent)idEnumeratorComp.Value;
						if (SetFacilityAndProcessInDiscGridBasedOnComponent(component, null, -1, true))
						{
							comboBox.Items.Add(component.ItemName);
							listDictComponentNamesDiscCombo.Add(component.TempID, component);
						}
					}
				}

				return;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in DisciplineGrid_SetupEditor: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void FindComponentsForProcess(ref ComboBox comboBox, int procIDTemp, int comboBoxIndex)
		{
			try
			{
				ImportFromTextFileProcess process = (ImportFromTextFileProcess)listDictProcessNamesAll[procIDTemp];
				int procIDExisting = process.ExistingID == 0? process.TempID: process.ExistingID;

				//loop through the component list to find components with same process id as procIDExisting
				IDictionaryEnumerator idEnumeratorComp = listDictComponentNamesAll.GetEnumerator();
				while (idEnumeratorComp.MoveNext())
				{
					if (((ImportFromTextFileComponent)idEnumeratorComp.Value).ProcessID == procIDExisting
						&& (((ImportFromTextFileComponent)idEnumeratorComp.Value).ImportThisItem
						|| ((ImportFromTextFileComponent)idEnumeratorComp.Value).ExistingID > 0))
					{
						//found a component that exists in the process - add the component to the combo box
						comboBox.Items.Add(((ImportFromTextFileComponent)idEnumeratorComp.Value).ItemName);
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in FindComponentsForProcess: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private ImportFromTextFileProcess FindProcessForFacilityByIndexOrName(int facIDTemp, int comboBoxIndex, string processName)
		{
			try
			{
				//get the facility
				ImportFromTextFileFacility facility = (ImportFromTextFileFacility)listDictFacilityNamesAll[facIDTemp];
				int facIDExisting = facility.ExistingID == 0? facility.TempID: facility.ExistingID;

				//loop through the process list to find processes with same facility id as facIDExisting
				int procListIndex = -1;
				IDictionaryEnumerator idEnumeratorProc = listDictProcessNamesAll.GetEnumerator();
				while (idEnumeratorProc.MoveNext())
				{
					if (((ImportFromTextFileProcess)idEnumeratorProc.Value).FacilityID == facIDExisting)
					{
						if (comboBoxIndex > -1)
						{
							//found a process that exists in the facility - check its index against comboBoxIndex
							if (++procListIndex == comboBoxIndex 
								&& ((ImportFromTextFileProcess)idEnumeratorProc.Value).ParentExists
								&& (((ImportFromTextFileProcess)idEnumeratorProc.Value).ImportThisItem
								|| ((ImportFromTextFileProcess)idEnumeratorProc.Value).ExistingID > 0))
							{
								return (ImportFromTextFileProcess)idEnumeratorProc.Value;
							}
						}
						else
						{
							//found a process that exists in the facility = check its name against the processName parameter
							if (((ImportFromTextFileProcess)idEnumeratorProc.Value).ItemName.ToUpper() == processName.Trim().ToUpper() 
								&& ((ImportFromTextFileProcess)idEnumeratorProc.Value).ParentExists
								&& (((ImportFromTextFileProcess)idEnumeratorProc.Value).ImportThisItem 
								|| ((ImportFromTextFileProcess)idEnumeratorProc.Value).ExistingID > 0))
							{
								return (ImportFromTextFileProcess)idEnumeratorProc.Value;
							}
						}
					}
				}
				return null;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in FindProcessForFacilityByIndexOrName: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return null;
			}
		}

		private ImportFromTextFileComponent FindComponentForProcessByIndexOrName(int procIDTemp, int comboBoxIndex, string componentName)
		{
			try
			{
				//get the process
				ImportFromTextFileProcess process = (ImportFromTextFileProcess)listDictProcessNamesAll[procIDTemp];
				int procIDExisting = process.ExistingID == 0? process.TempID: process.ExistingID;

				//loop through the component list to find componentes with same process id as procIDExisting
				int compListIndex = -1;
				IDictionaryEnumerator idEnumeratorComp = listDictComponentNamesAll.GetEnumerator();
				while (idEnumeratorComp.MoveNext())
				{
					if (((ImportFromTextFileComponent)idEnumeratorComp.Value).ProcessID == procIDExisting)
					{
						if (comboBoxIndex > -1)
						{
							//found a component that exists in the process - check its index against comboBoxIndex
							if (++compListIndex == comboBoxIndex 
								&& (((ImportFromTextFileComponent)idEnumeratorComp.Value).ImportThisItem
								|| ((ImportFromTextFileComponent)idEnumeratorComp.Value).ExistingID > 0))
							{
								return (ImportFromTextFileComponent)idEnumeratorComp.Value;
							}
						}
						else
						{
							//found a component that exists in the process = check its name against the componentName parameter
							if (((ImportFromTextFileComponent)idEnumeratorComp.Value).ItemName.ToUpper() == componentName.Trim().ToUpper() 
								&& (((ImportFromTextFileComponent)idEnumeratorComp.Value).ImportThisItem 
								|| ((ImportFromTextFileComponent)idEnumeratorComp.Value).ExistingID > 0))
							{
								return (ImportFromTextFileComponent)idEnumeratorComp.Value;
							}
						}
					}
				}

				return null;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred in ImportFromTextFileComponent: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return null;
			}
		}

		//mam 07072011 - hide unused grid crit columns
		private void HideUnusedCritColumns(C1FlexGrid flexGrid)
		{
			for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
			{
				flexGrid.Cols["Crit" + i.ToString()].Visible = false;
			}
		}

		#endregion /***** Grid Methods *****/

		#region /***** TestCode *****/

		private void buttonTest_Click(object sender, System.EventArgs e)
		{
			//CellRange cellRangeSingleCell = c1FlexGridDiscipline.GetCellRange(1, 15);
			//cellRangeSingleCell.Style = c1FlexGridDiscipline.Styles["DontImportDefaultValue"];
			////cellRangeSingleCell.Style = c1FlexGridDiscipline.Styles["DontImport"];
			//cellRangeSingleCell = c1FlexGridDiscipline.GetCellRange(2, 15);
			//cellRangeSingleCell.Style = c1FlexGridDiscipline.Styles["DontImport"];
		}

		private void c1FlexGridComponent_CellButtonClick(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			//MessageBox.Show("CellButtonClick: " + c1FlexGridComponent[e.Row, "FacilityName"].ToString());
			//MessageBox.Show("HashCode = " + c1FlexGridComponent.Cols[e.Col].DataMap.GetHashCode().ToString());
		}

		private void c1FlexGridComponent_ChangeEdit(object sender, System.EventArgs e)
		{
			//MessageBox.Show("ChangeEdit: " + c1FlexGridComponent[2, "FacilityName"].ToString());
			//((ImportFromTextFileFacility)idEnumerator.Value).ExistingID
			//MessageBox.Show("HashCode = " + c1FlexGridComponent.Cols["FacilityName"].DataMap.GetHashCode().ToString());
		}

		private void c1FlexGridComponent_ComboCloseUp(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			//			//c1FlexGridComponent.Cols[e.Col].DataMap.SyncRoot();
			//			//MessageBox.Show("HashCode = " + c1FlexGridComponent.Cols[e.Col].DataMap.GetHashCode().ToString());
			////			MessageBox.Show("ComboCloseUp: " + c1FlexGridComponent[e.Row, "FacilityName"].ToString());
			//			IDictionaryEnumerator idEnumerator = listDictFacilityNamesAll.GetEnumerator();
			//			while (idEnumerator.MoveNext())
			//			{
			//				//MessageBox.Show("ComboCloseUp: " + ((ImportFromTextFileFacility)idEnumerator.Value).ExistingID.ToString());
			//				if (((ImportFromTextFileFacility)idEnumerator.Value).ExistingID == 3)
			//				{
			//					MessageBox.Show("setting facility");
			//					c1FlexGridComponent[e.Row, "FacilityName"] = (ImportFromTextFileFacility)idEnumerator.Value;
			//					break;
			//				}
			//			}
			////			MessageBox.Show("ComboCloseUp: " + c1FlexGridComponent[e.Row, "FacilityName"].ToString());
			////			MessageBox.Show("DataIndex = " + c1FlexGridComponent.Cols[e.Col].DataIndex.ToString());
		}

		private void c1FlexGridComponent_ComboDropDown(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			//MessageBox.Show("ComboDropDown: " + c1FlexGridComponent[e.Row, "FacilityName"].ToString());
			//MessageBox.Show("HashCode = " + c1FlexGridComponent.Cols[e.Col].DataMap.GetHashCode().ToString());
		}

		//		private bool isMousePointerInArea(Point mousePosition, Rectangle area)
		//		{
		//			Point relativePoint = new Point(0, 0);
		//			relativePoint.X = mousePosition.X - this.Location.X;
		//			relativePoint.Y = mousePosition.Y - this.Location.Y;
		//
		//			return area.Contains(relativePoint);
		//		}

		#endregion /***** TestCode *****/

		#region /***** Get Grid Objects *****/

		public ImportFromTextFileDiscipline GetDisciplineObject(int getTempID)
		{
			//ImportFromTextFileDiscipline importDiscipline = new ImportFromTextFileDiscipline();
			return ((ImportFromTextFileDiscipline)listDictDisciplineNamesAll[getTempID]);
		}

		#endregion /***** Get Grid Objects *****/

		//mam 03202012
		private bool stopLoadingFromExcel = false;
		private void buttonStopLoadingExcel_Click(object sender, System.EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show(this, "Stop Loading Data from Excel?", "Stop Loading Data from Excel?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			if (dialogResult == DialogResult.Yes)
			{
				//cancel the current loading operation
				stopLoadingFromExcel = true;
			}
		}

		//mam 03202012 - we are not going to use the new panel progress updater, but are going to use the original 
		//	progress updater form, so comment all of this code
		#region /***** Progress Display *****/

//		//private double secondsRequired = 0;
//		//private double minutesRequired = 0;
//		private int totalRowCount = 0;
//		private int gridRowCount = 0;
//
//		private void ProgressDisplaySetup()
//		{
//			try
//			{
//				gridRowCount = 0;
//				//labelProgressTotalTime.Text = string.Format("{0}  minutes  {1}  seconds", minutesRequired.ToString(), secondsRequired.ToString());
//				//((ImportFromTextFile)parentForm).StartImportThread();
//
//				totalRowCount = CountGridRows();
//				textBoxProgressRowCount.ReadOnly = true;
//				textBoxProgressTime.ReadOnly = true;
//				textBoxProgressRowCount.BackColor = SystemColors.Window;
//				textBoxProgressTime.BackColor = SystemColors.Window;
//				CenterProgressPanel();
//				panelProgressDisplay.Visible = true;
//				SetImportButtonState(true);
//			}
//			catch
//			{
//			}
//		}
//
//		private void CenterProgressPanel()
//		{
//			try
//			{
//				int left = Convert.ToInt32(Math.Floor((tabControlImport.Width - panelProgressDisplay.Width) / 2));
//				int top = tabControlImport.Top + 30 + Convert.ToInt32(Math.Floor((tabControlImport.Height - panelProgressDisplay.Height) / 2));
//				panelProgressDisplay.Location = new System.Drawing.Point(left, top);
//			}
//			catch
//			{
//			}
//		}
//
//		private void SetImportButtonState(bool importing)
//		{
//			try
//			{
//				buttonValidate.Enabled = !importing;
//				buttonOK.Enabled = !importing;
//				buttonCancel.Enabled = !importing;
//				tabControlImport.Enabled = !importing;
//				checkBoxContinuousValidation.Enabled = !importing;
//
//				this.pictureBoxToolbarSelectFile.Enabled = !importing;
//				this.pictureBoxSelectFileSpreadsheet.Enabled = !importing;
//				this.pictureBoxInstructionSelectFile.Enabled = !importing;
//				this.pictureBoxLoadSampleData.Enabled = !importing;
//				this.pictureBoxToolbarPopulateTabs.Enabled = !importing;
//				this.pictureBoxPopulateTabsSpreadsheet.Enabled = !importing;
//				this.pictureBoxPopulateTabsSample.Enabled = !importing;
//				this.pictureBoxToolbarExport.Enabled = !importing;
//				this.pictureBoxToolbarClearAll.Enabled = !importing;
//				this.pictureBoxToolbarAddGridRow.Enabled = !importing;
//				this.pictureBoxInstructionAddGridRow.Enabled = !importing;
//				this.pictureBoxToolbarDeleteGridRow.Enabled = !importing;
//				this.pictureBoxToolbarCheckAll.Enabled = !importing;
//				//this.pictureBoxToolbarHelp.Enabled = !importing;
//			}
//			catch
//			{
//			}
//		}
//
//		private void ProgressDisplayClose()
//		{
//			panelProgressDisplay.Visible = false;
//			SetImportButtonState(false);
//		}
//
//		private void UpdateCounter(TimeSpan elapsedTime)
//		{
//			try
//			{
//				gridRowCount++;
//				textBoxProgressRowCount.Text = string.Format("{0} of {1}", gridRowCount.ToString(), totalRowCount.ToString());
//				textBoxProgressTime.Text = string.Format("{0}:{1}", elapsedTime.Minutes.ToString(), elapsedTime.Seconds.ToString().PadLeft(2, '0'));
//				this.Refresh();
//			}
//			catch
//			{
//			}
//		}
//
//		private void buttonCancelImport_Click(object sender, System.EventArgs e)
//		{
//			DialogResult dialogResult = DialogResult.No;
//			try
//			{
//				dialogResult = MessageBox.Show("Stop importing data?", "Stop Importing Data?", 
//					MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
//					
//				if (dialogResult == DialogResult.Yes)
//				{
//					CancelImport();
//				}
//			}
//			catch(Exception ex)
//			{
//				MessageBox.Show(this, "An error occurred while stopping the import: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//			}
//			finally
//			{
//				if (dialogResult == DialogResult.Yes)
//				{
//					panelProgressDisplay.Visible = false;
//					SetImportButtonState(false);				}
//			}
//		}
//
//		private void panelProgressDisplay_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
//		{
//			WAM.UI.FX.FX.PaintGradient(sender, e, panelProgressDisplay.Height, panelProgressDisplay.Width);
//		}
//
//		private void ImportFromTextFile_Resize(object sender, System.EventArgs e)
//		{
//			if (panelProgressDisplay.Visible)
//			{
//				CenterProgressPanel();
//			}
//		}

		#endregion /***** Progress Display *****/
	}
}
