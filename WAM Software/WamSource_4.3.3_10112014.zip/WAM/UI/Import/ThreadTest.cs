using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ThreadTest.
	/// </summary>
	public class ThreadTest : System.Windows.Forms.Form
	{
		private delegate void TickerDelegate(String s);
		private TickerDelegate tickerDelegate1, tickerDelegate2;

		Label label1, label2;

		String[] newsItems = {
			"Safest Aerobic Machine Launched", 
			"First Dog Cloning Is Only Days Away",
			"Reviving the Extinct Tasmanian Tiger" };

		String[] businessItems = {
			"FirstMeasure Software to Go Nasdaq",
			"MFMF Directors To Meet For The First Time",
			"First Sign of Economic Recovery Finally At Sight",
			"Euro Hits Record Low (Again)" };
  
		Thread thread1, thread2;

		private System.ComponentModel.Container components = null;

		public ThreadTest()
		{
			InitializeComponent();

			tickerDelegate1 = new TickerDelegate(SetLeftTicker);
			tickerDelegate2 = new TickerDelegate(SetRightTicker);

			Initialize();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// ThreadTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "ThreadTest";
			this.Text = "ThreadTest";

		}
		#endregion

		private void Initialize() 
		{
			label1 = new Label();
			label2 = new Label();

			label1.Width = 280;
			label1.Height = 30;
			label1.Location = new Point(1, 10);
			label1.TextAlign = ContentAlignment.MiddleRight;

			label2.Width = 280;
			label2.Height = 30;
			label2.Location = new Point(1, 40);

			this.Controls.Add(label1);
			this.Controls.Add(label2);

			thread1 = new Thread(new ThreadStart(MoveLeft));
			thread1.Start();    

			thread2 = new Thread(new ThreadStart(MoveRight));
			thread2.Start();    
		}
	
		private void MoveLeft() 
		{
			int counter = 0;
			int max = newsItems.Length;

			while (true) 
			{
				// get news headline
				String headline = newsItems[counter];
				counter++;
				if (counter==max)
					counter = 0;

				for (int i=0; i<=headline.Length; i++) 
				{
					//label1.Text = headline.Substring(0, i);
					label1.Invoke(tickerDelegate1,new object[] { headline.Substring(0,i) });
					Thread.Sleep(60);
				}
				Thread.Sleep(100);  
			}    
		}

		private void MoveRight() 
		{
			int counter = 0;
			int max = newsItems.Length;

			while (true) 
			{
				// get news headline
				String headline = businessItems[counter];
				counter++;
				if (counter==max)
					counter = 0;

				for (int i=0; i<=headline.Length; i++) 
				{
					//label2.Text = headline.Substring(0, i);
					label2.Invoke(tickerDelegate2,new object[] { headline.Substring(0,i) });
					Thread.Sleep(100);
				}

				Thread.Sleep(100);
			}    
		}

		protected override void OnClosing(CancelEventArgs e) 
		{
			thread1.Join(0);   
			thread2.Join(0);
			Environment.Exit(0);
		}

		//public static void Main() 
		//{
		//	Ticker ticker = new Ticker();
		//	Application.Run(ticker);    
		//}

		private void SetLeftTicker(String s)
		{
			label1.Text = s;
		}

		private void SetRightTicker(String s)
		{
			label2.Text = s;
		}

	}
}
