using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportDiscInfoLand.
	/// </summary>
	public class ImportDiscInfoLand : System.Windows.Forms.UserControl
	{
		#region /***** Member Variables *****/

		private System.Windows.Forms.GroupBox groupBoxLandApplication;
		private WAM.UI.ItemStatusControl itemStatusLandAppBermErosionInterior;
		private WAM.UI.ItemStatusControl itemStatusLandAppBermErosionBermExterior;
		private WAM.UI.ItemStatusControl itemStatusLandAppDrainageAdequate;
		private WAM.UI.ItemStatusControl itemStatusLandAppBermVegetation;
		private WAM.UI.ItemStatusControl itemStatusLandAppErosionProtectionPresent;
		private WAM.UI.ItemStatusControl itemStatusLandAppErosionProtectionAdequate;
		private WAM.UI.ItemStatusControl itemStatusLandAppAlgalBlooms;
		private WAM.UI.ItemStatusControl itemStatusLandAppBermSettlement;
		private WAM.UI.ItemStatusControl itemStatusLandAppBermSeepage;
		private WAM.UI.ItemStatusControl itemStatusLandAppClayLiner;
		private WAM.UI.ItemStatusControl itemStatusLandAppBurrowHoles;
		private System.Windows.Forms.GroupBox groupBoxSite;
		private WAM.UI.ItemStatusControl itemStatusSeveralPotholes;
		private WAM.UI.ItemStatusControl itemStatusExcessiveErosion;
		private WAM.UI.ItemStatusControl itemStatusSevereRoadDegradation;
		private WAM.UI.ItemStatusControl itemStatusSpaceForExpansion;
		private WAM.UI.ItemStatusControl itemStatusFunctionalGroundCover;
		private WAM.UI.ItemStatusControl itemStatusFencingAdequate;
		private WAM.UI.ItemStatusControl itemStatusFacilitiesSecure;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panelSeparator;
		private System.Windows.Forms.Panel panel1;
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportDiscInfoLand()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBoxLandApplication = new System.Windows.Forms.GroupBox();
			this.itemStatusLandAppBermErosionInterior = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppBermErosionBermExterior = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppDrainageAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppBermVegetation = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppErosionProtectionPresent = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppErosionProtectionAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppAlgalBlooms = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppBermSettlement = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppBermSeepage = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppClayLiner = new WAM.UI.ItemStatusControl();
			this.itemStatusLandAppBurrowHoles = new WAM.UI.ItemStatusControl();
			this.groupBoxSite = new System.Windows.Forms.GroupBox();
			this.itemStatusSeveralPotholes = new WAM.UI.ItemStatusControl();
			this.itemStatusExcessiveErosion = new WAM.UI.ItemStatusControl();
			this.itemStatusSevereRoadDegradation = new WAM.UI.ItemStatusControl();
			this.itemStatusSpaceForExpansion = new WAM.UI.ItemStatusControl();
			this.itemStatusFunctionalGroundCover = new WAM.UI.ItemStatusControl();
			this.itemStatusFencingAdequate = new WAM.UI.ItemStatusControl();
			this.itemStatusFacilitiesSecure = new WAM.UI.ItemStatusControl();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panelSeparator = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBoxLandApplication.SuspendLayout();
			this.groupBoxSite.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBoxLandApplication
			// 
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBermErosionInterior);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBermErosionBermExterior);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppDrainageAdequate);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBermVegetation);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppErosionProtectionPresent);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppErosionProtectionAdequate);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppAlgalBlooms);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBermSettlement);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBermSeepage);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppClayLiner);
			this.groupBoxLandApplication.Controls.Add(this.itemStatusLandAppBurrowHoles);
			this.groupBoxLandApplication.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxLandApplication.Location = new System.Drawing.Point(313, 38);
			this.groupBoxLandApplication.Name = "groupBoxLandApplication";
			this.groupBoxLandApplication.Size = new System.Drawing.Size(364, 232);
			this.groupBoxLandApplication.TabIndex = 1;
			this.groupBoxLandApplication.TabStop = false;
			// 
			// itemStatusLandAppBermErosionInterior
			// 
			this.itemStatusLandAppBermErosionInterior.Caption = "Excessive erosion on berm interior?";
			this.itemStatusLandAppBermErosionInterior.Location = new System.Drawing.Point(8, 31);
			this.itemStatusLandAppBermErosionInterior.Name = "itemStatusLandAppBermErosionInterior";
			this.itemStatusLandAppBermErosionInterior.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBermErosionInterior.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBermErosionInterior.TabIndex = 1;
			// 
			// itemStatusLandAppBermErosionBermExterior
			// 
			this.itemStatusLandAppBermErosionBermExterior.Caption = "Excessive erosion on berm exterior?";
			this.itemStatusLandAppBermErosionBermExterior.Location = new System.Drawing.Point(8, 51);
			this.itemStatusLandAppBermErosionBermExterior.Name = "itemStatusLandAppBermErosionBermExterior";
			this.itemStatusLandAppBermErosionBermExterior.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBermErosionBermExterior.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBermErosionBermExterior.TabIndex = 2;
			// 
			// itemStatusLandAppDrainageAdequate
			// 
			this.itemStatusLandAppDrainageAdequate.Caption = "Adequate drainage?";
			this.itemStatusLandAppDrainageAdequate.Location = new System.Drawing.Point(8, 211);
			this.itemStatusLandAppDrainageAdequate.Name = "itemStatusLandAppDrainageAdequate";
			this.itemStatusLandAppDrainageAdequate.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppDrainageAdequate.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppDrainageAdequate.TabIndex = 10;
			// 
			// itemStatusLandAppBermVegetation
			// 
			this.itemStatusLandAppBermVegetation.Caption = "Vegetation along berms?";
			this.itemStatusLandAppBermVegetation.Location = new System.Drawing.Point(8, 71);
			this.itemStatusLandAppBermVegetation.Name = "itemStatusLandAppBermVegetation";
			this.itemStatusLandAppBermVegetation.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBermVegetation.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBermVegetation.TabIndex = 3;
			// 
			// itemStatusLandAppErosionProtectionPresent
			// 
			this.itemStatusLandAppErosionProtectionPresent.Caption = "Presence of riprap or other erosion protection?";
			this.itemStatusLandAppErosionProtectionPresent.Location = new System.Drawing.Point(8, 151);
			this.itemStatusLandAppErosionProtectionPresent.Name = "itemStatusLandAppErosionProtectionPresent";
			this.itemStatusLandAppErosionProtectionPresent.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppErosionProtectionPresent.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppErosionProtectionPresent.TabIndex = 7;
			// 
			// itemStatusLandAppErosionProtectionAdequate
			// 
			this.itemStatusLandAppErosionProtectionAdequate.Caption = "Adequate erosion protection?";
			this.itemStatusLandAppErosionProtectionAdequate.Location = new System.Drawing.Point(8, 171);
			this.itemStatusLandAppErosionProtectionAdequate.Name = "itemStatusLandAppErosionProtectionAdequate";
			this.itemStatusLandAppErosionProtectionAdequate.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppErosionProtectionAdequate.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppErosionProtectionAdequate.TabIndex = 8;
			// 
			// itemStatusLandAppAlgalBlooms
			// 
			this.itemStatusLandAppAlgalBlooms.Caption = "Excessive algal blooms?";
			this.itemStatusLandAppAlgalBlooms.Location = new System.Drawing.Point(8, 191);
			this.itemStatusLandAppAlgalBlooms.Name = "itemStatusLandAppAlgalBlooms";
			this.itemStatusLandAppAlgalBlooms.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppAlgalBlooms.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppAlgalBlooms.TabIndex = 9;
			// 
			// itemStatusLandAppBermSettlement
			// 
			this.itemStatusLandAppBermSettlement.Caption = "Noticeable settlement of berms?";
			this.itemStatusLandAppBermSettlement.Location = new System.Drawing.Point(8, 91);
			this.itemStatusLandAppBermSettlement.Name = "itemStatusLandAppBermSettlement";
			this.itemStatusLandAppBermSettlement.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBermSettlement.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBermSettlement.TabIndex = 4;
			// 
			// itemStatusLandAppBermSeepage
			// 
			this.itemStatusLandAppBermSeepage.Caption = "Presence of seepage on outer edge of berms?";
			this.itemStatusLandAppBermSeepage.Location = new System.Drawing.Point(8, 111);
			this.itemStatusLandAppBermSeepage.Name = "itemStatusLandAppBermSeepage";
			this.itemStatusLandAppBermSeepage.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBermSeepage.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBermSeepage.TabIndex = 5;
			// 
			// itemStatusLandAppClayLiner
			// 
			this.itemStatusLandAppClayLiner.Caption = "Presence of clay liner?";
			this.itemStatusLandAppClayLiner.Location = new System.Drawing.Point(8, 11);
			this.itemStatusLandAppClayLiner.Name = "itemStatusLandAppClayLiner";
			this.itemStatusLandAppClayLiner.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppClayLiner.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppClayLiner.TabIndex = 0;
			// 
			// itemStatusLandAppBurrowHoles
			// 
			this.itemStatusLandAppBurrowHoles.Caption = "Presence of burrow holes?";
			this.itemStatusLandAppBurrowHoles.Location = new System.Drawing.Point(8, 131);
			this.itemStatusLandAppBurrowHoles.Name = "itemStatusLandAppBurrowHoles";
			this.itemStatusLandAppBurrowHoles.Size = new System.Drawing.Size(352, 16);
			this.itemStatusLandAppBurrowHoles.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusLandAppBurrowHoles.TabIndex = 6;
			// 
			// groupBoxSite
			// 
			this.groupBoxSite.Controls.Add(this.itemStatusSeveralPotholes);
			this.groupBoxSite.Controls.Add(this.itemStatusExcessiveErosion);
			this.groupBoxSite.Controls.Add(this.itemStatusSevereRoadDegradation);
			this.groupBoxSite.Controls.Add(this.itemStatusSpaceForExpansion);
			this.groupBoxSite.Controls.Add(this.itemStatusFunctionalGroundCover);
			this.groupBoxSite.Controls.Add(this.itemStatusFencingAdequate);
			this.groupBoxSite.Controls.Add(this.itemStatusFacilitiesSecure);
			this.groupBoxSite.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxSite.Location = new System.Drawing.Point(9, 38);
			this.groupBoxSite.Name = "groupBoxSite";
			this.groupBoxSite.Size = new System.Drawing.Size(296, 164);
			this.groupBoxSite.TabIndex = 0;
			this.groupBoxSite.TabStop = false;
			// 
			// itemStatusSeveralPotholes
			// 
			this.itemStatusSeveralPotholes.Caption = "Several potholes?";
			this.itemStatusSeveralPotholes.Location = new System.Drawing.Point(8, 11);
			this.itemStatusSeveralPotholes.Name = "itemStatusSeveralPotholes";
			this.itemStatusSeveralPotholes.Size = new System.Drawing.Size(284, 16);
			this.itemStatusSeveralPotholes.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusSeveralPotholes.TabIndex = 0;
			// 
			// itemStatusExcessiveErosion
			// 
			this.itemStatusExcessiveErosion.Caption = "Excessive erosion?";
			this.itemStatusExcessiveErosion.Location = new System.Drawing.Point(8, 31);
			this.itemStatusExcessiveErosion.Name = "itemStatusExcessiveErosion";
			this.itemStatusExcessiveErosion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusExcessiveErosion.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusExcessiveErosion.TabIndex = 1;
			// 
			// itemStatusSevereRoadDegradation
			// 
			this.itemStatusSevereRoadDegradation.Caption = "Severe road degradation evident?";
			this.itemStatusSevereRoadDegradation.Location = new System.Drawing.Point(8, 51);
			this.itemStatusSevereRoadDegradation.Name = "itemStatusSevereRoadDegradation";
			this.itemStatusSevereRoadDegradation.Size = new System.Drawing.Size(284, 16);
			this.itemStatusSevereRoadDegradation.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusSevereRoadDegradation.TabIndex = 2;
			// 
			// itemStatusSpaceForExpansion
			// 
			this.itemStatusSpaceForExpansion.Caption = "Space for expansion?";
			this.itemStatusSpaceForExpansion.Location = new System.Drawing.Point(8, 71);
			this.itemStatusSpaceForExpansion.Name = "itemStatusSpaceForExpansion";
			this.itemStatusSpaceForExpansion.Size = new System.Drawing.Size(284, 16);
			this.itemStatusSpaceForExpansion.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusSpaceForExpansion.TabIndex = 3;
			// 
			// itemStatusFunctionalGroundCover
			// 
			this.itemStatusFunctionalGroundCover.Caption = "Functional ground cover?";
			this.itemStatusFunctionalGroundCover.Location = new System.Drawing.Point(8, 91);
			this.itemStatusFunctionalGroundCover.Name = "itemStatusFunctionalGroundCover";
			this.itemStatusFunctionalGroundCover.Size = new System.Drawing.Size(284, 16);
			this.itemStatusFunctionalGroundCover.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusFunctionalGroundCover.TabIndex = 4;
			// 
			// itemStatusFencingAdequate
			// 
			this.itemStatusFencingAdequate.Caption = "Fencing adequate and well maintained?";
			this.itemStatusFencingAdequate.Location = new System.Drawing.Point(8, 111);
			this.itemStatusFencingAdequate.Name = "itemStatusFencingAdequate";
			this.itemStatusFencingAdequate.Size = new System.Drawing.Size(284, 28);
			this.itemStatusFencingAdequate.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusFencingAdequate.TabIndex = 5;
			// 
			// itemStatusFacilitiesSecure
			// 
			this.itemStatusFacilitiesSecure.Caption = "Facilities adequately secured?";
			this.itemStatusFacilitiesSecure.Location = new System.Drawing.Point(8, 143);
			this.itemStatusFacilitiesSecure.Name = "itemStatusFacilitiesSecure";
			this.itemStatusFacilitiesSecure.Size = new System.Drawing.Size(284, 16);
			this.itemStatusFacilitiesSecure.Status = WAM.Data.ItemStatus.NotApplicable;
			this.itemStatusFacilitiesSecure.TabIndex = 6;
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(688, 32);
			this.labelTitle.TabIndex = 95;
			this.labelTitle.Text = "  Component Info - Civil / Sitework";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelSeparator
			// 
			this.panelSeparator.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelSeparator.Location = new System.Drawing.Point(0, 32);
			this.panelSeparator.Name = "panelSeparator";
			this.panelSeparator.Size = new System.Drawing.Size(688, 2);
			this.panelSeparator.TabIndex = 96;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(0, 280);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(688, 2);
			this.panel1.TabIndex = 97;
			// 
			// ImportDiscInfoLand
			// 
			this.BackColor = System.Drawing.Color.White;
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panelSeparator);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.groupBoxLandApplication);
			this.Controls.Add(this.groupBoxSite);
			this.Name = "ImportDiscInfoLand";
			this.Size = new System.Drawing.Size(688, 282);
			this.groupBoxLandApplication.ResumeLayout(false);
			this.groupBoxSite.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Methods *****/

		public void LoadDataLand(ImportFromTextFileDiscipline discipline)
		{
			this.Location = new Point(0, 0);
			this.Size = new Size(688, 282);
			this.Parent.Size = new Size(693, 357);
			this.Visible = true;

			itemStatusSeveralPotholes.Status = discipline.SeveralPotholes;
			itemStatusExcessiveErosion.Status = discipline.ExcessiveErosion;
			itemStatusSevereRoadDegradation.Status = discipline.RoadDegradation;
			itemStatusSpaceForExpansion.Status = discipline.ExpansionSpace;
			itemStatusFunctionalGroundCover.Status = discipline.FunctionCover;
			itemStatusFencingAdequate.Status = discipline.FencingAdequate;
			itemStatusFacilitiesSecure.Status = discipline.FacilitiesSecure;
			itemStatusLandAppClayLiner.Status = discipline.LandAppClayLiner;
			itemStatusLandAppBermErosionInterior.Status = discipline.LandAppBermErosionInterior;
			itemStatusLandAppBermErosionBermExterior.Status = discipline.LandAppBermErosionBermExterior;
			itemStatusLandAppBermVegetation.Status = discipline.LandAppBermVegetation;
			itemStatusLandAppBermSettlement.Status = discipline.LandAppBermSettlement;
			itemStatusLandAppBermSeepage.Status = discipline.LandAppBermSeepage;
			itemStatusLandAppBurrowHoles.Status = discipline.LandAppBurrowHoles;
			itemStatusLandAppErosionProtectionPresent.Status = discipline.LandAppErosionProtectionPresent;
			itemStatusLandAppErosionProtectionAdequate.Status = discipline.LandAppErosionProtectionAdequate;
			itemStatusLandAppAlgalBlooms.Status = discipline.LandAppAlgalBlooms;
			itemStatusLandAppDrainageAdequate.Status = discipline.LandAppDrainageAdequate;
		}

		public void SaveDataLand(ImportFromTextFileDiscipline discipline)
		{
			discipline.SeveralPotholes = itemStatusSeveralPotholes.Status;
			discipline.ExcessiveErosion = itemStatusExcessiveErosion.Status;
			discipline.RoadDegradation = itemStatusSevereRoadDegradation.Status;
			discipline.ExpansionSpace = itemStatusSpaceForExpansion.Status;
			discipline.FunctionCover = itemStatusFunctionalGroundCover.Status;
			discipline.FencingAdequate = itemStatusFencingAdequate.Status;
			discipline.FacilitiesSecure = itemStatusFacilitiesSecure.Status;
			discipline.LandAppClayLiner = itemStatusLandAppClayLiner.Status;
			discipline.LandAppBermErosionInterior = itemStatusLandAppBermErosionInterior.Status;
			discipline.LandAppBermErosionBermExterior = itemStatusLandAppBermErosionBermExterior.Status;
			discipline.LandAppBermVegetation = itemStatusLandAppBermVegetation.Status;
			discipline.LandAppBermSettlement = itemStatusLandAppBermSettlement.Status;
			discipline.LandAppBermSeepage = itemStatusLandAppBermSeepage.Status;
			discipline.LandAppBurrowHoles = itemStatusLandAppBurrowHoles.Status;
			discipline.LandAppErosionProtectionPresent = itemStatusLandAppErosionProtectionPresent.Status;
			discipline.LandAppErosionProtectionAdequate = itemStatusLandAppErosionProtectionAdequate.Status;
			discipline.LandAppAlgalBlooms = itemStatusLandAppAlgalBlooms.Status;
			discipline.LandAppDrainageAdequate = itemStatusLandAppDrainageAdequate.Status;
		}

		#endregion /***** Methods *****/

	}
}
