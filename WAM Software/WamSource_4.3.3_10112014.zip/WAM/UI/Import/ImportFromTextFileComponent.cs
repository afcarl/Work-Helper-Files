using System;
using WAM.Data;

namespace WAM.UI.Import
{
	/// <summary>
	/// Summary description for ImportFromTextFileComponent.
	/// </summary>
	public class ImportFromTextFileComponent
	{
		#region /***** Member Variables *****/

		private int		infoSetID = 0;
		private int		existingID = 0;
		private int		tempID = 0;
		private int		processID = 0;
		private short	redundantAssets = 0;
		//private int		componentType = 0;
		private short	currentYear = (short)DateTime.Now.Year;
		private bool	importThisItem = false;
		private bool	retired = false;
		private string	itemName = "New Component";
		private string	comments = "";
		private			LevelOfService los = LevelOfService.LOS1;

		//mam 07072011 - no longer using four fixed crits
		//private			CriticalityPublicHealth critPublic = CriticalityPublicHealth.NoEffect;
		//private			CriticalityEnvironmental critEnvironment = CriticalityEnvironmental.NoEffect;
		//private			CriticalityRepairCost critRepair = CriticalityRepairCost.LessThan5k;
		//private			CriticalityCustomerEffect critEffect = CriticalityCustomerEffect.NoEffect;

		private double	vulnerability = 0.0;
		private bool	overrideVulnerability = false;
		private bool	mechStructDisc = true;
		private bool	parentExists = false;

		//mam 07072011
		private int cipPlanningModeId = 0;
		private string assetClass = "";

		//mam 03202012
		private string photoFileName = "";
		private string photoCaption = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ImportFromTextFileComponent()
		{
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Properties *****/

		public int InfoSetID
		{
			get { return infoSetID; }
			set { infoSetID = value; }
		}

		public int ExistingID
		{
			get { return existingID; }
			set { existingID = value; }
		}

		public int TempID
		{
			get { return tempID; }
			set { tempID = value; }
		}

		public int ProcessID
		{
			get { return processID; }
			set { processID = value; }
		}

		public short RedundantAssets
		{
			get { return redundantAssets; }
			set { redundantAssets = value; }
		}

		//mam 07072011
		public int CipPlanningModeId
		{
			get { return cipPlanningModeId; }
			set { cipPlanningModeId = value; }
		}

		//mam 07072011
		public string AssetClass
		{
			get { return assetClass; }
			set { assetClass = value; }
		}

		//public int ComponentType
		//{
		//	get { return componentType; }
		//	set { componentType = value; }
		//}

		public string ItemName
		{
			get { return itemName; }
			set
			{
				if (value.Length > 255)
				{
					itemName = value.Substring(255);
				}
				else
				{
					itemName = value;
				}
			}
		}

//		public short CurrentYear
//		{
//			get { return currentYear; }
//			set { currentYear = value; }
//		}

		public string		Comments
		{
			get { return comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
				{
					comments = value.Substring(Int16.MaxValue);
				}
				else
				{
					comments = value;
				}
			}
		}

		public bool ImportThisItem
		{
			get { return importThisItem; }
			set { importThisItem = value; }
		}

		public bool Retired
		{
			get { return retired; }
			set { retired = value; }
		}

		public LevelOfService LOS
		{
			get
			{ 
				//if (MechStructDisciplines)
				{
					return los;
				}
			}
			set
			{
				if (MechStructDisciplines)
				{
					los = value;
				}
			}
		}

		//mam 07072011
		//let's have these integers represent the factor scores (not the ScoreIds)
		//public Common.Criticality Crit1
//		public int Crit1
//		{
//			get { return crit1; }
//			set { crit1 = value; }
//		}
//		public int Crit2
//		{
//			get { return crit2; }
//			set { crit2 = value; }
//		}
//		public int Crit3
//		{
//			get { return crit3; }
//			set { crit3 = value; }
//		}
//		public int Crit4
//		{
//			get { return crit4; }
//			set { crit4 = value; }
//		}
//		public int Crit5
//		{
//			get { return crit5; }
//			set { crit5 = value; }
//		}
//		public int Crit6
//		{
//			get { return crit6; }
//			set { crit6 = value; }
//		}
		//</mam>

		//mam 07072011 - no longer using four fixed crits
//		public CriticalityPublicHealth CritPublic
//		{
//			get { return critPublic; }
//			set { critPublic = value; }
//		}

		//mam 07072011 - no longer using four fixed crits
//		public CriticalityEnvironmental CritEnvironment
//		{
//			get { return critEnvironment; }
//			set { critEnvironment = value; }
//		}

		//mam 07072011 - no longer using four fixed crits
//		public CriticalityRepairCost CritRepair
//		{
//			get { return critRepair; }
//			set { critRepair = value; }
//		}

		//mam 07072011 - no longer using four fixed crits
//		public CriticalityCustomerEffect CritEffect
//		{
//			get { return critEffect; }
//			set { critEffect = value; }
//		}

		public double Vulnerability
		{
			get
			{
				//if (MechStructDisciplines)
				{
					return vulnerability;
				}
			}
			set
			{
				if (MechStructDisciplines)
				{
					vulnerability = value;
				}
			}
		}

		public bool MechStructDisciplines
		{
			get { return mechStructDisc; }
			set { mechStructDisc = value; }
		}

		public bool OverrideVulnerability
		{
			get { return overrideVulnerability; }
			set { overrideVulnerability = value; }
		}

		public bool ParentExists
		{
			get { return parentExists; }
			set { parentExists = value; }
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return photoFileName; }
			set
			{
				if (value.Length > 255)
				{
					photoFileName = value.Substring(255);
				}
				else
				{
					photoFileName = value;
				}
			}
		}

		//mam 03202012
		public string PhotoCaption
		{
			get { return photoCaption; }
			set
			{
				if (value.Length > 255)
				{
					photoCaption = value.Substring(255);
				}
				else
				{
					photoCaption = value;
				}
			}
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		public override string ToString()
		{
			return this.itemName;
		}

		#endregion /***** Methods *****/

	}
}
