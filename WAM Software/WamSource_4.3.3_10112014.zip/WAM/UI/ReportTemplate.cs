using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportTemplate.
	/// </summary>
	public class ReportTemplate : System.Windows.Forms.Form
	{
		private string nameTemplate = "";
		private string labelText = "";

		private System.Windows.Forms.TextBox textBoxReportTemplateName;
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;

		private System.Windows.Forms.PictureBox pictureBoxHelp;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ReportTemplate()
		{
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportTemplate));
			this.textBoxReportTemplateName = new System.Windows.Forms.TextBox();
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// textBoxReportTemplateName
			// 
			this.textBoxReportTemplateName.Location = new System.Drawing.Point(13, 37);
			this.textBoxReportTemplateName.MaxLength = 100;
			this.textBoxReportTemplateName.Name = "textBoxReportTemplateName";
			this.textBoxReportTemplateName.Size = new System.Drawing.Size(263, 20);
			this.textBoxReportTemplateName.TabIndex = 1;
			this.textBoxReportTemplateName.Text = "";
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(10, 11);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(238, 21);
			this.labelReportTemplateName.TabIndex = 0;
			this.labelReportTemplateName.Text = "New Template Name";
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(130, 114);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&OK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(211, 114);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(257, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 92;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// ReportTemplate
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(292, 144);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelReportTemplateName);
			this.Controls.Add(this.textBoxReportTemplateName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportTemplate";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ReportTemplate";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReportTemplate_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool ShowForm(ref string nameTemplate, string labelText, Form owner)
		{
			ReportTemplate form = new ReportTemplate();
			bool success;

			//form.templateID = templateID;
			form.nameTemplate = nameTemplate;
			form.labelText = labelText;
			success = (form.ShowDialog(owner) == DialogResult.OK);

			if (success)
			{
				nameTemplate = form.nameTemplate;
			}

			return success;			
		}

		protected override void OnLoad(EventArgs e)
		{
			this.Text = "Report Template Name";

			labelReportTemplateName.Text = labelText;

			textBoxReportTemplateName.Text = nameTemplate;
			if (nameTemplate.Length > 255)
				textBoxReportTemplateName.Text = nameTemplate.Substring(255);

			textBoxReportTemplateName.Focus();
			textBoxReportTemplateName.SelectionStart = 0;
			textBoxReportTemplateName.SelectionLength = textBoxReportTemplateName.Text.Length;

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (textBoxReportTemplateName.Text.Trim().Length == 0)
			{
				MessageBox.Show(this, 
					"Please enter a name for the report template.", "Enter Report Template Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxReportTemplateName.Focus();
				return;
			}

			nameTemplate = textBoxReportTemplateName.Text;
			if (nameTemplate.Length > 255)
				nameTemplate = nameTemplate.Substring(255);

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
		}

		private void ReportTemplate_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}

}
