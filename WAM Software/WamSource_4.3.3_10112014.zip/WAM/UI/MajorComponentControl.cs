using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Drive.Collections;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for MajorComponentControl.
	/// </summary>
	public class MajorComponentControl : System.Windows.Forms.UserControl
	{
		private bool		m_suppressUpdates = false;
		private	MajorComponent m_component = null;

		private System.Windows.Forms.TextBox textBoxComponentName;
		private System.Windows.Forms.TextBox textBoxFacilityName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBoxLogo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxProcessName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageMain;
		private System.Windows.Forms.TabPage tabPagePhoto;
		private WAM.UI.Grids.ComponentGrid componentGrid1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBoxComments;
		private WAM.UI.PhotoControl pictureBox;
		private System.Windows.Forms.Button buttonBrowsePhoto;
		private System.Windows.Forms.TextBox textBoxPhotoCaption;
		private System.Windows.Forms.TabPage tabPageAssessment;
		private System.Windows.Forms.TabPage tabPageCostAllocation;
		private WAM.UI.Grids.ComponentAssessmentGrid gridAssessment;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBoxAssessmentComments;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox comboBoxLOS;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.ComboBox comboBoxCritHealth;
		private System.Windows.Forms.ComboBox comboBoxCritEnv;
		private System.Windows.Forms.ComboBox comboBoxCritRepairCost;
		private System.Windows.Forms.ComboBox comboBoxCritCustEffect;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox textBoxCritTotal;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox comboBoxVulnerability;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox textBoxRisk;
		private System.Windows.Forms.TextBox textBoxAllocComments;
		private System.Windows.Forms.Label label15;
		private WAM.UI.Grids.CostAllocationGrid gridAllocation;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox textBoxCurrentYear;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.CheckBox checkBoxRetired;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MajorComponentControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBoxComponentName = new System.Windows.Forms.TextBox();
			this.textBoxFacilityName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxProcessName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageMain = new System.Windows.Forms.TabPage();
			this.textBoxComments = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.componentGrid1 = new WAM.UI.Grids.ComponentGrid();
			this.tabPageAssessment = new System.Windows.Forms.TabPage();
			this.label14 = new System.Windows.Forms.Label();
			this.comboBoxVulnerability = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.comboBoxLOS = new System.Windows.Forms.ComboBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label12 = new System.Windows.Forms.Label();
			this.comboBoxCritCustEffect = new System.Windows.Forms.ComboBox();
			this.comboBoxCritRepairCost = new System.Windows.Forms.ComboBox();
			this.comboBoxCritEnv = new System.Windows.Forms.ComboBox();
			this.comboBoxCritHealth = new System.Windows.Forms.ComboBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.textBoxCritTotal = new System.Windows.Forms.TextBox();
			this.textBoxRisk = new System.Windows.Forms.TextBox();
			this.textBoxAssessmentComments = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.gridAssessment = new WAM.UI.Grids.ComponentAssessmentGrid();
			this.tabPageCostAllocation = new System.Windows.Forms.TabPage();
			this.label16 = new System.Windows.Forms.Label();
			this.textBoxAllocComments = new System.Windows.Forms.TextBox();
			this.gridAllocation = new WAM.UI.Grids.CostAllocationGrid();
			this.tabPagePhoto = new System.Windows.Forms.TabPage();
			this.pictureBox = new WAM.UI.PhotoControl();
			this.buttonBrowsePhoto = new System.Windows.Forms.Button();
			this.textBoxPhotoCaption = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.textBoxCurrentYear = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.checkBoxRetired = new System.Windows.Forms.CheckBox();
			this.tabControl.SuspendLayout();
			this.tabPageMain.SuspendLayout();
			this.tabPageAssessment.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tabPageCostAllocation.SuspendLayout();
			this.tabPagePhoto.SuspendLayout();
			this.SuspendLayout();
			// 
			// textBoxComponentName
			// 
			this.textBoxComponentName.Location = new System.Drawing.Point(216, 60);
			this.textBoxComponentName.MaxLength = 255;
			this.textBoxComponentName.Name = "textBoxComponentName";
			this.textBoxComponentName.Size = new System.Drawing.Size(228, 20);
			this.textBoxComponentName.TabIndex = 5;
			this.textBoxComponentName.Text = "";
			this.textBoxComponentName.Leave += new System.EventHandler(this.textBoxComponentName_Leave);
			// 
			// textBoxFacilityName
			// 
			this.textBoxFacilityName.Location = new System.Drawing.Point(216, 4);
			this.textBoxFacilityName.Name = "textBoxFacilityName";
			this.textBoxFacilityName.ReadOnly = true;
			this.textBoxFacilityName.Size = new System.Drawing.Size(228, 20);
			this.textBoxFacilityName.TabIndex = 1;
			this.textBoxFacilityName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(92, 6);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Facility / System Name:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pictureBoxLogo
			// 
			this.pictureBoxLogo.Location = new System.Drawing.Point(4, 4);
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.Size = new System.Drawing.Size(76, 108);
			this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBoxLogo.TabIndex = 13;
			this.pictureBoxLogo.TabStop = false;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(88, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 2;
			this.label2.Text = "Process / Basin / Zone:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBoxProcessName
			// 
			this.textBoxProcessName.Location = new System.Drawing.Point(216, 32);
			this.textBoxProcessName.Name = "textBoxProcessName";
			this.textBoxProcessName.ReadOnly = true;
			this.textBoxProcessName.Size = new System.Drawing.Size(228, 20);
			this.textBoxProcessName.TabIndex = 3;
			this.textBoxProcessName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 28);
			this.label3.TabIndex = 4;
			this.label3.Text = "Component / Subasin / Subzone:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageMain);
			this.tabControl.Controls.Add(this.tabPageAssessment);
			this.tabControl.Controls.Add(this.tabPageCostAllocation);
			this.tabControl.Controls.Add(this.tabPagePhoto);
			this.tabControl.ItemSize = new System.Drawing.Size(110, 18);
			this.tabControl.Location = new System.Drawing.Point(4, 116);
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.tabControl.Size = new System.Drawing.Size(690, 352);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl.TabIndex = 8;
			this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
			// 
			// tabPageMain
			// 
			this.tabPageMain.Controls.Add(this.textBoxComments);
			this.tabPageMain.Controls.Add(this.label4);
			this.tabPageMain.Controls.Add(this.componentGrid1);
			this.tabPageMain.Location = new System.Drawing.Point(4, 22);
			this.tabPageMain.Name = "tabPageMain";
			this.tabPageMain.Size = new System.Drawing.Size(682, 326);
			this.tabPageMain.TabIndex = 0;
			this.tabPageMain.Text = "Main";
			// 
			// textBoxComments
			// 
			this.textBoxComments.AcceptsReturn = true;
			this.textBoxComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxComments.Multiline = true;
			this.textBoxComments.Name = "textBoxComments";
			this.textBoxComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxComments.Size = new System.Drawing.Size(674, 156);
			this.textBoxComments.TabIndex = 2;
			this.textBoxComments.Text = "";
			this.textBoxComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(4, 152);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Comments:";
			// 
			// componentGrid1
			// 
			this.componentGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.componentGrid1.GridStyle = WAM.UI.Grids.ComponentGrid.GridType.MajorComponents;
			this.componentGrid1.Location = new System.Drawing.Point(4, 4);
			this.componentGrid1.Name = "componentGrid1";
			this.componentGrid1.Size = new System.Drawing.Size(674, 144);
			this.componentGrid1.TabIndex = 0;
			// 
			// tabPageAssessment
			// 
			this.tabPageAssessment.Controls.Add(this.label14);
			this.tabPageAssessment.Controls.Add(this.comboBoxVulnerability);
			this.tabPageAssessment.Controls.Add(this.label13);
			this.tabPageAssessment.Controls.Add(this.comboBoxLOS);
			this.tabPageAssessment.Controls.Add(this.groupBox1);
			this.tabPageAssessment.Controls.Add(this.textBoxRisk);
			this.tabPageAssessment.Controls.Add(this.textBoxAssessmentComments);
			this.tabPageAssessment.Controls.Add(this.label7);
			this.tabPageAssessment.Controls.Add(this.label6);
			this.tabPageAssessment.Controls.Add(this.gridAssessment);
			this.tabPageAssessment.Location = new System.Drawing.Point(4, 22);
			this.tabPageAssessment.Name = "tabPageAssessment";
			this.tabPageAssessment.Size = new System.Drawing.Size(682, 326);
			this.tabPageAssessment.TabIndex = 2;
			this.tabPageAssessment.Text = "Assessment";
			// 
			// label14
			// 
			this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label14.Location = new System.Drawing.Point(562, 298);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(32, 16);
			this.label14.TabIndex = 8;
			this.label14.Text = "Risk:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxVulnerability
			// 
			this.comboBoxVulnerability.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxVulnerability.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxVulnerability.Location = new System.Drawing.Point(498, 268);
			this.comboBoxVulnerability.Name = "comboBoxVulnerability";
			this.comboBoxVulnerability.Size = new System.Drawing.Size(176, 21);
			this.comboBoxVulnerability.TabIndex = 7;
			this.comboBoxVulnerability.SelectedIndexChanged += new System.EventHandler(this.OnChangeVulnerability);
			// 
			// label13
			// 
			this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label13.Location = new System.Drawing.Point(498, 252);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(100, 16);
			this.label13.TabIndex = 6;
			this.label13.Text = "Vulnerability:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxLOS
			// 
			this.comboBoxLOS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxLOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxLOS.Location = new System.Drawing.Point(594, 4);
			this.comboBoxLOS.Name = "comboBoxLOS";
			this.comboBoxLOS.Size = new System.Drawing.Size(48, 21);
			this.comboBoxLOS.TabIndex = 4;
			this.comboBoxLOS.SelectedIndexChanged += new System.EventHandler(this.OnChangeLOS);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Controls.Add(this.comboBoxCritCustEffect);
			this.groupBox1.Controls.Add(this.comboBoxCritRepairCost);
			this.groupBox1.Controls.Add(this.comboBoxCritEnv);
			this.groupBox1.Controls.Add(this.comboBoxCritHealth);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label10);
			this.groupBox1.Controls.Add(this.label11);
			this.groupBox1.Controls.Add(this.label9);
			this.groupBox1.Controls.Add(this.textBoxCritTotal);
			this.groupBox1.Location = new System.Drawing.Point(494, 28);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(184, 220);
			this.groupBox1.TabIndex = 5;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Criticality";
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(4, 194);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(96, 16);
			this.label12.TabIndex = 8;
			this.label12.Text = "Overall Criticality:";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxCritCustEffect
			// 
			this.comboBoxCritCustEffect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCritCustEffect.Location = new System.Drawing.Point(4, 164);
			this.comboBoxCritCustEffect.Name = "comboBoxCritCustEffect";
			this.comboBoxCritCustEffect.Size = new System.Drawing.Size(176, 21);
			this.comboBoxCritCustEffect.TabIndex = 7;
			this.comboBoxCritCustEffect.SelectedIndexChanged += new System.EventHandler(this.OnChangeCriticality);
			// 
			// comboBoxCritRepairCost
			// 
			this.comboBoxCritRepairCost.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCritRepairCost.Location = new System.Drawing.Point(4, 120);
			this.comboBoxCritRepairCost.Name = "comboBoxCritRepairCost";
			this.comboBoxCritRepairCost.Size = new System.Drawing.Size(176, 21);
			this.comboBoxCritRepairCost.TabIndex = 5;
			this.comboBoxCritRepairCost.SelectedIndexChanged += new System.EventHandler(this.OnChangeCriticality);
			// 
			// comboBoxCritEnv
			// 
			this.comboBoxCritEnv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCritEnv.Location = new System.Drawing.Point(4, 76);
			this.comboBoxCritEnv.Name = "comboBoxCritEnv";
			this.comboBoxCritEnv.Size = new System.Drawing.Size(176, 21);
			this.comboBoxCritEnv.TabIndex = 3;
			this.comboBoxCritEnv.SelectedIndexChanged += new System.EventHandler(this.OnChangeCriticality);
			// 
			// comboBoxCritHealth
			// 
			this.comboBoxCritHealth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxCritHealth.Location = new System.Drawing.Point(4, 32);
			this.comboBoxCritHealth.Name = "comboBoxCritHealth";
			this.comboBoxCritHealth.Size = new System.Drawing.Size(176, 21);
			this.comboBoxCritHealth.TabIndex = 1;
			this.comboBoxCritHealth.SelectedIndexChanged += new System.EventHandler(this.OnChangeCriticality);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(4, 16);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(132, 16);
			this.label8.TabIndex = 0;
			this.label8.Text = "Public Health and Safety:";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(4, 104);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(132, 16);
			this.label10.TabIndex = 4;
			this.label10.Text = "Cost of Repair:";
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(4, 148);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(132, 16);
			this.label11.TabIndex = 6;
			this.label11.Text = "Effect on Customers:";
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(4, 60);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(132, 16);
			this.label9.TabIndex = 2;
			this.label9.Text = "Environmental:";
			// 
			// textBoxCritTotal
			// 
			this.textBoxCritTotal.Location = new System.Drawing.Point(100, 192);
			this.textBoxCritTotal.Name = "textBoxCritTotal";
			this.textBoxCritTotal.ReadOnly = true;
			this.textBoxCritTotal.Size = new System.Drawing.Size(44, 20);
			this.textBoxCritTotal.TabIndex = 9;
			this.textBoxCritTotal.Text = "";
			// 
			// textBoxRisk
			// 
			this.textBoxRisk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxRisk.Location = new System.Drawing.Point(594, 296);
			this.textBoxRisk.Name = "textBoxRisk";
			this.textBoxRisk.ReadOnly = true;
			this.textBoxRisk.Size = new System.Drawing.Size(44, 20);
			this.textBoxRisk.TabIndex = 9;
			this.textBoxRisk.Text = "";
			// 
			// textBoxAssessmentComments
			// 
			this.textBoxAssessmentComments.AcceptsReturn = true;
			this.textBoxAssessmentComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAssessmentComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxAssessmentComments.Multiline = true;
			this.textBoxAssessmentComments.Name = "textBoxAssessmentComments";
			this.textBoxAssessmentComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAssessmentComments.Size = new System.Drawing.Size(486, 156);
			this.textBoxAssessmentComments.TabIndex = 2;
			this.textBoxAssessmentComments.Text = "";
			this.textBoxAssessmentComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(4, 152);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 16);
			this.label7.TabIndex = 1;
			this.label7.Text = "Comments:";
			// 
			// label6
			// 
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label6.Location = new System.Drawing.Point(498, 6);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(96, 16);
			this.label6.TabIndex = 3;
			this.label6.Text = "Level of Service:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// gridAssessment
			// 
			this.gridAssessment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAssessment.GridStyle = WAM.UI.Grids.ComponentAssessmentGrid.GridType.MajorComponents;
			this.gridAssessment.Location = new System.Drawing.Point(4, 4);
			this.gridAssessment.Name = "gridAssessment";
			this.gridAssessment.Size = new System.Drawing.Size(486, 144);
			this.gridAssessment.TabIndex = 0;
			// 
			// tabPageCostAllocation
			// 
			this.tabPageCostAllocation.Controls.Add(this.label16);
			this.tabPageCostAllocation.Controls.Add(this.textBoxAllocComments);
			this.tabPageCostAllocation.Controls.Add(this.gridAllocation);
			this.tabPageCostAllocation.Location = new System.Drawing.Point(4, 22);
			this.tabPageCostAllocation.Name = "tabPageCostAllocation";
			this.tabPageCostAllocation.Size = new System.Drawing.Size(682, 326);
			this.tabPageCostAllocation.TabIndex = 3;
			this.tabPageCostAllocation.Text = "Cost Allocation by %";
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(4, 152);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(100, 16);
			this.label16.TabIndex = 5;
			this.label16.Text = "Comments:";
			// 
			// textBoxAllocComments
			// 
			this.textBoxAllocComments.AcceptsReturn = true;
			this.textBoxAllocComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAllocComments.Location = new System.Drawing.Point(4, 168);
			this.textBoxAllocComments.Multiline = true;
			this.textBoxAllocComments.Name = "textBoxAllocComments";
			this.textBoxAllocComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxAllocComments.Size = new System.Drawing.Size(674, 156);
			this.textBoxAllocComments.TabIndex = 4;
			this.textBoxAllocComments.Text = "";
			this.textBoxAllocComments.Leave += new System.EventHandler(this.textBoxComments_Leave);
			// 
			// gridAllocation
			// 
			this.gridAllocation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridAllocation.GridStyle = WAM.UI.Grids.CostAllocationGrid.GridType.Disciplines;
			this.gridAllocation.Location = new System.Drawing.Point(4, 4);
			this.gridAllocation.Name = "gridAllocation";
			this.gridAllocation.Size = new System.Drawing.Size(674, 144);
			this.gridAllocation.TabIndex = 0;
			// 
			// tabPagePhoto
			// 
			this.tabPagePhoto.Controls.Add(this.pictureBox);
			this.tabPagePhoto.Controls.Add(this.buttonBrowsePhoto);
			this.tabPagePhoto.Controls.Add(this.textBoxPhotoCaption);
			this.tabPagePhoto.Location = new System.Drawing.Point(4, 22);
			this.tabPagePhoto.Name = "tabPagePhoto";
			this.tabPagePhoto.Size = new System.Drawing.Size(682, 326);
			this.tabPagePhoto.TabIndex = 1;
			this.tabPagePhoto.Text = "Photo";
			// 
			// pictureBox
			// 
			this.pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.pictureBox.Image = null;
			this.pictureBox.Location = new System.Drawing.Point(4, 4);
			this.pictureBox.Name = "pictureBox";
			this.pictureBox.Size = new System.Drawing.Size(674, 264);
			this.pictureBox.TabIndex = 17;
			// 
			// buttonBrowsePhoto
			// 
			this.buttonBrowsePhoto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonBrowsePhoto.Location = new System.Drawing.Point(304, 296);
			this.buttonBrowsePhoto.Name = "buttonBrowsePhoto";
			this.buttonBrowsePhoto.TabIndex = 16;
			this.buttonBrowsePhoto.Text = "Browse...";
			this.buttonBrowsePhoto.Click += new System.EventHandler(this.buttonBrowsePhoto_Click);
			// 
			// textBoxPhotoCaption
			// 
			this.textBoxPhotoCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxPhotoCaption.Location = new System.Drawing.Point(4, 272);
			this.textBoxPhotoCaption.MaxLength = 255;
			this.textBoxPhotoCaption.Name = "textBoxPhotoCaption";
			this.textBoxPhotoCaption.Size = new System.Drawing.Size(674, 20);
			this.textBoxPhotoCaption.TabIndex = 15;
			this.textBoxPhotoCaption.Text = "";
			this.textBoxPhotoCaption.Leave += new System.EventHandler(this.textBoxPhotoCaption_Leave);
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(0, 0);
			this.label15.Name = "label15";
			this.label15.TabIndex = 0;
			// 
			// textBoxCurrentYear
			// 
			this.textBoxCurrentYear.Location = new System.Drawing.Point(532, 4);
			this.textBoxCurrentYear.Name = "textBoxCurrentYear";
			this.textBoxCurrentYear.ReadOnly = true;
			this.textBoxCurrentYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxCurrentYear.TabIndex = 32;
			this.textBoxCurrentYear.Text = "";
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(448, 6);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(84, 16);
			this.label17.TabIndex = 33;
			this.label17.Text = "Current Year:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// checkBoxRetired
			// 
			this.checkBoxRetired.Location = new System.Drawing.Point(532, 28);
			this.checkBoxRetired.Name = "checkBoxRetired";
			this.checkBoxRetired.Size = new System.Drawing.Size(68, 16);
			this.checkBoxRetired.TabIndex = 34;
			this.checkBoxRetired.Text = "Retired?";
			this.checkBoxRetired.CheckedChanged += new System.EventHandler(this.checkBoxRetired_CheckedChanged);
			// 
			// MajorComponentControl
			// 
			this.AutoScroll = true;
			this.AutoScrollMinSize = new System.Drawing.Size(698, 472);
			this.Controls.Add(this.checkBoxRetired);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.textBoxCurrentYear);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.textBoxComponentName);
			this.Controls.Add(this.textBoxFacilityName);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBoxLogo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.textBoxProcessName);
			this.Controls.Add(this.label3);
			this.Name = "MajorComponentControl";
			this.Size = new System.Drawing.Size(698, 472);
			this.tabControl.ResumeLayout(false);
			this.tabPageMain.ResumeLayout(false);
			this.tabPageAssessment.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.tabPageCostAllocation.ResumeLayout(false);
			this.tabPagePhoto.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public void			SetComponent(MajorComponent component)
		{
			m_component = component;
			RefreshData();
		}

		protected override void OnLoad(EventArgs e)
		{
			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.LogoSmall.bmp");
			pictureBoxLogo.Image = Bitmap.FromStream(file);

			LoadLOS();
			LoadCriticalityBoxes();
			LoadVulnerability();

			base.OnLoad(e);
		}

		private void		LoadLOS()
		{
			int				pos;
			LevelOfService[] losValues = 
				(LevelOfService[])Enum.GetValues(typeof(LevelOfService));

			comboBoxLOS.BeginUpdate();
			comboBoxLOS.DisplayMember = "DisplayMember";
			comboBoxLOS.Items.Clear();
			for (pos = 0; pos < losValues.Length; pos++)
			{
				comboBoxLOS.Items.Add(new ListItem(
					EnumHandlers.GetLOSShort(losValues[pos]),
					losValues[pos]));
			}
			comboBoxLOS.EndUpdate();
		}

		private void		LoadCriticalityBoxes()
		{
			int				pos;

			// Public Health and Safety
			CriticalityPublicHealth[] critHealthValues = 
				(CriticalityPublicHealth[])Enum.GetValues(
				typeof(CriticalityPublicHealth));
			comboBoxCritHealth.BeginUpdate();
			comboBoxCritHealth.DisplayMember = "DisplayMember";
			comboBoxCritHealth.Items.Clear();
			for (pos = 0; pos < critHealthValues.Length; pos++)
			{
				comboBoxCritHealth.Items.Add(new ListItem(
					EnumHandlers.GetCritPublicHealthString(
					critHealthValues[pos]),
					critHealthValues[pos]));
			}
			comboBoxCritHealth.EndUpdate();

			// Environmental
			CriticalityEnvironmental[] critEnvValues = 
				(CriticalityEnvironmental[])Enum.GetValues(
				typeof(CriticalityEnvironmental));
			comboBoxCritEnv.BeginUpdate();
			comboBoxCritEnv.DisplayMember = "DisplayMember";
			comboBoxCritEnv.Items.Clear();
			for (pos = 0; pos < critEnvValues.Length; pos++)
			{
				comboBoxCritEnv.Items.Add(new ListItem(
					EnumHandlers.GetCritEnvironmentalString(
					critEnvValues[pos]),
					critEnvValues[pos]));
			}
			comboBoxCritEnv.EndUpdate();

			// Cost of Repair
			CriticalityRepairCost[] critRepairValues = 
				(CriticalityRepairCost[])Enum.GetValues(
				typeof(CriticalityRepairCost));
			comboBoxCritRepairCost.BeginUpdate();
			comboBoxCritRepairCost.DisplayMember = "DisplayMember";
			comboBoxCritRepairCost.Items.Clear();
			for (pos = 0; pos < critRepairValues.Length; pos++)
			{
				comboBoxCritRepairCost.Items.Add(new ListItem(
					EnumHandlers.GetCritRepairCostString(
					critRepairValues[pos]),
					critRepairValues[pos]));
			}
			comboBoxCritRepairCost.EndUpdate();

			// Customer Effect
			CriticalityCustomerEffect[] critCustEffectValues = 
				(CriticalityCustomerEffect[])Enum.GetValues(
				typeof(CriticalityCustomerEffect));
			comboBoxCritCustEffect.BeginUpdate();
			comboBoxCritCustEffect.DisplayMember = "DisplayMember";
			comboBoxCritCustEffect.Items.Clear();
			for (pos = 0; pos < critCustEffectValues.Length; pos++)
			{
				comboBoxCritCustEffect.Items.Add(new ListItem(
					EnumHandlers.GetCritCustomerEffectString(
					critCustEffectValues[pos]),
					critCustEffectValues[pos]));
			}
			comboBoxCritCustEffect.EndUpdate();
		}

		private void		LoadVulnerability()
		{
			int				pos;
			Vulnerability[] vulnerabilityValues = 
				(Vulnerability[])Enum.GetValues(typeof(Vulnerability));

			// Add vulnerabilities
			comboBoxVulnerability.BeginUpdate();
			comboBoxVulnerability.DisplayMember = "DisplayMember";
			comboBoxVulnerability.Items.Clear();
			for (pos = 0; pos < vulnerabilityValues.Length; pos++)
			{
				comboBoxVulnerability.Items.Add(new ListItem(
					EnumHandlers.GetVulnerabilityString(vulnerabilityValues[pos]),
					vulnerabilityValues[pos]));
			}
			comboBoxVulnerability.EndUpdate();
		}

		public void			RefreshData()
		{
			componentGrid1.SetRootObject(m_component);
			gridAssessment.SetRootObject(m_component);
			gridAllocation.SetRootObject(m_component);

			if (m_component == null)
				return;

			tabControl.SelectedIndex = 0;

			m_suppressUpdates = true;
			TreatmentProcess process = 
				TreatmentProcessCache.Cached.GetTreatmentProcess(m_component.ProcessID);
			Facility facility = 
				FacilityCache.Cached.GetFacility(process.FacilityID);

			textBoxCurrentYear.Text = facility.CurrentYear.ToString();

			textBoxFacilityName.Text = facility.Name;
			textBoxProcessName.Text = process.Name;
			textBoxComponentName.Text = m_component.Name;
			textBoxComments.Text = m_component.Comments;
			textBoxAllocComments.Text = m_component.Comments;
			textBoxAssessmentComments.Text = m_component.Comments;

			checkBoxRetired.Checked = m_component.Retired;

			SelectLOS();
			SelectCriticality();
			SelectVulnerability();
			m_suppressUpdates = false;

			UpdateCriticality();
		}

		private void		SelectLOS()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxLOS.Items.Count; pos++)
			{
				item = comboBoxLOS.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((LevelOfService)item.Value == m_component.LOS)
				{
					comboBoxLOS.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectCriticality()
		{
			SelectCritPublicHealthAndSafety();
			SelectCritEnvironmental();
			SelectCritCostOfRepair();
			SelectCritEffectOnCustomers();
		}

		private void		SelectCritPublicHealthAndSafety()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxCritHealth.Items.Count; pos++)
			{
				item = comboBoxCritHealth.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((CriticalityPublicHealth)item.Value == m_component.CritPublicHealth)
				{
					comboBoxCritHealth.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectCritEnvironmental()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxCritEnv.Items.Count; pos++)
			{
				item = comboBoxCritEnv.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((CriticalityEnvironmental)item.Value == m_component.CritEnvironmental)
				{
					comboBoxCritEnv.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectCritCostOfRepair()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxCritRepairCost.Items.Count; pos++)
			{
				item = comboBoxCritRepairCost.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((CriticalityRepairCost)item.Value == m_component.CritRepair)
				{
					comboBoxCritRepairCost.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectCritEffectOnCustomers()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxCritCustEffect.Items.Count; pos++)
			{
				item = comboBoxCritCustEffect.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((CriticalityCustomerEffect)item.Value == m_component.CritCustEffect)
				{
					comboBoxCritCustEffect.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		SelectVulnerability()
		{
			int				pos = 0;
			ListItem		item;

			for (pos = 0; pos < comboBoxVulnerability.Items.Count; pos++)
			{
				item = comboBoxVulnerability.Items[pos] as ListItem;
				if (item == null)
					continue;

				if ((Vulnerability)item.Value == m_component.Vulnerability)
				{
					comboBoxVulnerability.SelectedIndex = pos;
					return;
				}
			}
		}

		private void		UpdateCriticality()
		{
			if (m_component == null)
				return;

			// Take the sum of the criticality items
			textBoxCritTotal.Text = m_component.GetOverallCriticality().ToString();

			UpdateRisk();
		}

		private void		UpdateRisk()
		{
			textBoxRisk.Text = string.Format("{0:F1}", m_component.GetRisk());
		}

		private void textBoxComponentName_Leave(object sender, System.EventArgs e)
		{
			if (m_component != null && textBoxComponentName.Text.Length > 0)
			{
				if (string.Compare(m_component.Name, textBoxComponentName.Text) != 0)
				{
					// Update the name
					m_component.Name = textBoxComponentName.Text;
					m_component.Save();
				}
			}
		}

		private void textBoxComments_Leave(object sender, System.EventArgs e)
		{
			if (m_component == null)
				return;

			bool			changed = false;

			if (sender is TextBox)
			{
				if (((TextBox)sender).Text != m_component.Comments)
				{
					m_component.Comments = ((TextBox)sender).Text;
					changed = true;
				}
			}

			if (changed)
			{
				m_component.Save();

				// Update all of the comments fields that are NOT 
				// the comments field that sent the notification
				if (!object.ReferenceEquals(sender, textBoxComments))
					textBoxComments.Text = m_component.Comments;
				if (!object.ReferenceEquals(sender, textBoxAllocComments))
					textBoxAllocComments.Text = m_component.Comments;
				if (!object.ReferenceEquals(sender, textBoxAssessmentComments))
					textBoxAssessmentComments.Text = m_component.Comments;
			}
		}

		private void tabControl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl.SelectedTab == tabPagePhoto)
			{
				if (m_component != null)
				{
					// Check to see if there is a photo in the photos directory
					textBoxPhotoCaption.Text = m_component.CaptionPhoto;

					pictureBox.Image = m_component.GetPhoto();
					if (pictureBox.Image == null)
						buttonBrowsePhoto.Text = "Browse";
					else
						buttonBrowsePhoto.Text = "Delete";
				}
				else
				{
					textBoxPhotoCaption.Text = "";
					pictureBox.Image = null;
					buttonBrowsePhoto.Text = "Browse";
				}
			}
		}

		private void buttonBrowsePhoto_Click(object sender, System.EventArgs e)
		{
			if (pictureBox.Image == null)
			{
				OpenFileDialog	fileDlg = new OpenFileDialog();

				fileDlg.Filter = "JPG Images (*.jpg)|*.jpg";
				fileDlg.CheckFileExists = true;

				if (fileDlg.ShowDialog(this) == DialogResult.OK)
				{
					string	targetPath = m_component.GetImagePath();

					// Get the image and copy it to the images path
					System.IO.File.Copy(fileDlg.FileName, targetPath, true);
					m_component.CaptionPhoto = 
						Drive.IO.Directory.GetFileNameFromPath(fileDlg.FileName, false);
					textBoxPhotoCaption.Text = m_component.CaptionPhoto;
					m_component.Save();
					buttonBrowsePhoto.Text = "Delete";
					pictureBox.Image = m_component.GetPhoto();
				}
			}
			else
			{
				pictureBox.Image = null;
				string		targetPath = m_component.GetImagePath();

				if (System.IO.File.Exists(targetPath))
					System.IO.File.Delete(targetPath);

				m_component.CaptionPhoto = "";
				textBoxPhotoCaption.Text = "";
				buttonBrowsePhoto.Text = "Browse";
			}
		}

		private void textBoxPhotoCaption_Leave(object sender, System.EventArgs e)
		{
			if (m_component.CaptionPhoto != textBoxPhotoCaption.Text)
			{
				m_component.CaptionPhoto = textBoxPhotoCaption.Text;
				m_component.Save();
			}
		}

		private void OnChangeCriticality(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			// Update public health
			CriticalityPublicHealth	health = (CriticalityPublicHealth)
				((ListItem)comboBoxCritHealth.SelectedItem).Value;
			m_component.CritPublicHealth = health;

			// Update environmental
			CriticalityEnvironmental env = (CriticalityEnvironmental)
				((ListItem)comboBoxCritEnv.SelectedItem).Value;
			m_component.CritEnvironmental = env;

			// Update cost of Repairs
			CriticalityRepairCost repair = (CriticalityRepairCost)
				((ListItem)comboBoxCritRepairCost.SelectedItem).Value;
			m_component.CritRepair = repair;

			// Update Effect on Customers
			CriticalityCustomerEffect custEffect = (CriticalityCustomerEffect)
				((ListItem)comboBoxCritCustEffect.SelectedItem).Value;
			m_component.CritCustEffect = custEffect;

			// Save the component
			m_component.Save();
			UpdateCriticality();
		}

		private void OnChangeLOS(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			LevelOfService	los = (LevelOfService)((ListItem)comboBoxLOS.SelectedItem).Value;
			m_component.LOS = los;
			m_component.Save();

			// Refresh the grid (some display items change based on LOS)
			componentGrid1.SetRootObject(m_component);
		}

		private void OnChangeVulnerability(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			Vulnerability	vuln = (Vulnerability)((ListItem)comboBoxVulnerability.SelectedItem).Value;
			m_component.Vulnerability = vuln;
			m_component.Save();

			UpdateRisk();
		}

		private void checkBoxRetired_CheckedChanged(object sender, System.EventArgs e)
		{
			if (m_component == null || m_suppressUpdates)
				return;

			m_component.Retired = checkBoxRetired.Checked;
			m_component.Save();
			System.Text.StringBuilder builder = new System.Text.StringBuilder();

			builder.Append("The Cost Weighted Percentage of Asset Value on the ");
			builder.Append("process screen will need to be adjusted so that the ");
			builder.Append("total Cost Weighted Percentage equals 100, because this ");
			builder.Append("component will now be ");
			if (m_component.Retired)
				builder.Append("excluded from ");
			else
				builder.Append("included in ");
			builder.Append("all calculations.");

			MessageBox.Show(this, builder.ToString(), "Retired Warning", 
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}
}
