using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

//mam 102309
//mam
//using System.Data.OleDb;
using Drive.Data.OleDb;
using System.Text;
//</mam>

namespace WAM.UI
{
	/// <summary>
	/// Summary description for SelectInfoSetForm.
	/// </summary>
	public class SelectInfoSetForm : System.Windows.Forms.Form 
	{
		//mam
		int curSelRow = 0;
		bool copyingInfoSet = false;
		bool copyPhoto = false;
		bool cancelCopy = false;
		bool loadingGrid = false;
		bool isLoading = false;
		string sourceInfoSetImagePath = "";
		string newInfoSetImagePath = "";
		//</mam>

		private string		m_currentInfoSet = "";
		private string		m_currentFacility = "";
		private string		m_currentProcess = "";
		private string		m_currentComponent = "";
		private StringBuilder m_statusBuilder = new StringBuilder();
		private C1.Win.C1FlexGrid.C1FlexGrid gridSets;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.ImageList imageListActiveStatus;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.Button buttonAddSet;
		private System.Windows.Forms.Button buttonRemoveSet;
		private System.Windows.Forms.Button buttonEditSet;
		private System.Windows.Forms.Button buttonSetActive;
		private System.Windows.Forms.Button buttonCopy;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panelStatus;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.Panel panelStatusHolder;
		private System.Windows.Forms.Label labelCopying;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.ComponentModel.IContainer components;

		public SelectInfoSetForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SelectInfoSetForm));
			this.gridSets = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.buttonAddSet = new System.Windows.Forms.Button();
			this.buttonRemoveSet = new System.Windows.Forms.Button();
			this.buttonEditSet = new System.Windows.Forms.Button();
			this.buttonSetActive = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.imageListActiveStatus = new System.Windows.Forms.ImageList(this.components);
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.buttonCopy = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panelStatusHolder = new System.Windows.Forms.Panel();
			this.panelStatus = new System.Windows.Forms.Panel();
			this.labelCopying = new System.Windows.Forms.Label();
			this.labelStatus = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.gridSets)).BeginInit();
			this.panelStatusHolder.SuspendLayout();
			this.panelStatus.SuspendLayout();
			this.SuspendLayout();
			// 
			// gridSets
			// 
			this.gridSets.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
			this.gridSets.AllowEditing = false;
			this.gridSets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.gridSets.BackColor = System.Drawing.SystemColors.Window;
			this.gridSets.ColumnInfo = @"5,1,0,0,0,85,Columns:0{Width:0;}	1{Width:18;AllowResizing:False;}	2{Width:214;Caption:""Information Set Name"";DataType:System.String;TextAlign:LeftCenter;}	3{Width:200;Caption:""Description"";DataType:System.String;TextAlign:LeftCenter;}	4{Caption:""FixedInfoSet"";Visible:False;DataType:System.Boolean;TextAlign:LeftCenter;ImageAlign:CenterCenter;}	";
			this.gridSets.ExtendLastCol = true;
			this.gridSets.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
			this.gridSets.ForeColor = System.Drawing.SystemColors.WindowText;
			this.gridSets.Location = new System.Drawing.Point(4, 37);
			this.gridSets.Name = "gridSets";
			this.gridSets.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
			this.gridSets.Size = new System.Drawing.Size(448, 291);
			this.gridSets.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Fixed{Font:Microsoft Sans Serif, 8.25pt, style=Bold;BackColor:Control;ForeColor:64, 64, 64;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	FixedInfoSet{Font:Microsoft Sans Serif, 8.25pt, style=Italic;BackColor:252, 240, 218;}	");
			this.gridSets.TabIndex = 1;
			this.gridSets.AfterSelChange += new C1.Win.C1FlexGrid.RangeEventHandler(this.gridSets_AfterSelChange);
			// 
			// buttonAddSet
			// 
			this.buttonAddSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonAddSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAddSet.Location = new System.Drawing.Point(460, 37);
			this.buttonAddSet.Name = "buttonAddSet";
			this.buttonAddSet.Size = new System.Drawing.Size(84, 23);
			this.buttonAddSet.TabIndex = 2;
			this.buttonAddSet.Text = "&Add Set";
			this.toolTip.SetToolTip(this.buttonAddSet, "Add a new information set");
			this.buttonAddSet.Click += new System.EventHandler(this.buttonAddSet_Click);
			// 
			// buttonRemoveSet
			// 
			this.buttonRemoveSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonRemoveSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonRemoveSet.Location = new System.Drawing.Point(460, 69);
			this.buttonRemoveSet.Name = "buttonRemoveSet";
			this.buttonRemoveSet.Size = new System.Drawing.Size(84, 23);
			this.buttonRemoveSet.TabIndex = 3;
			this.buttonRemoveSet.Text = "&Delete Set";
			this.toolTip.SetToolTip(this.buttonRemoveSet, "Delete the selected information set");
			this.buttonRemoveSet.Click += new System.EventHandler(this.buttonRemoveSet_Click);
			// 
			// buttonEditSet
			// 
			this.buttonEditSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonEditSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonEditSet.Location = new System.Drawing.Point(460, 124);
			this.buttonEditSet.Name = "buttonEditSet";
			this.buttonEditSet.Size = new System.Drawing.Size(84, 23);
			this.buttonEditSet.TabIndex = 4;
			this.buttonEditSet.Text = "&Edit Set";
			this.toolTip.SetToolTip(this.buttonEditSet, "Edit the selected information set (rename / set description)");
			this.buttonEditSet.Click += new System.EventHandler(this.buttonEditSet_Click);
			// 
			// buttonSetActive
			// 
			this.buttonSetActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonSetActive.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSetActive.Location = new System.Drawing.Point(460, 264);
			this.buttonSetActive.Name = "buttonSetActive";
			this.buttonSetActive.Size = new System.Drawing.Size(84, 23);
			this.buttonSetActive.TabIndex = 6;
			this.buttonSetActive.Text = "&Set Active";
			this.toolTip.SetToolTip(this.buttonSetActive, "Set the selected information set to be the active set (will reload cache)");
			this.buttonSetActive.Click += new System.EventHandler(this.buttonSetActive_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(460, 304);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(84, 23);
			this.buttonClose.TabIndex = 7;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// imageListActiveStatus
			// 
			this.imageListActiveStatus.ColorDepth = System.Windows.Forms.ColorDepth.Depth4Bit;
			this.imageListActiveStatus.ImageSize = new System.Drawing.Size(16, 15);
			this.imageListActiveStatus.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// buttonCopy
			// 
			this.buttonCopy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCopy.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCopy.Location = new System.Drawing.Point(460, 156);
			this.buttonCopy.Name = "buttonCopy";
			this.buttonCopy.Size = new System.Drawing.Size(84, 23);
			this.buttonCopy.TabIndex = 5;
			this.buttonCopy.Text = "&Copy Set";
			this.toolTip.SetToolTip(this.buttonCopy, "Copy the selected information set");
			this.buttonCopy.Click += new System.EventHandler(this.buttonCopy_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(284, 70);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(84, 23);
			this.buttonCancel.TabIndex = 8;
			this.buttonCancel.Text = "Stop";
			this.toolTip.SetToolTip(this.buttonCancel, "Stop the copying of the information set");
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			this.buttonCancel.MouseEnter += new System.EventHandler(this.buttonCancel_MouseEnter);
			this.buttonCancel.MouseLeave += new System.EventHandler(this.buttonCancel_MouseLeave);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(8, 8);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(276, 21);
			this.labelTitle.TabIndex = 0;
			this.labelTitle.Text = "Select an Information Set";
			// 
			// panelStatusHolder
			// 
			this.panelStatusHolder.BackColor = System.Drawing.Color.MidnightBlue;
			this.panelStatusHolder.Controls.Add(this.panelStatus);
			this.panelStatusHolder.Location = new System.Drawing.Point(33, 110);
			this.panelStatusHolder.Name = "panelStatusHolder";
			this.panelStatusHolder.Size = new System.Drawing.Size(376, 100);
			this.panelStatusHolder.TabIndex = 10;
			this.panelStatusHolder.Visible = false;
			// 
			// panelStatus
			// 
			this.panelStatus.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(252)), ((System.Byte)(240)), ((System.Byte)(218)));
			this.panelStatus.Controls.Add(this.buttonCancel);
			this.panelStatus.Controls.Add(this.labelCopying);
			this.panelStatus.Controls.Add(this.labelStatus);
			this.panelStatus.Location = new System.Drawing.Point(2, 2);
			this.panelStatus.Name = "panelStatus";
			this.panelStatus.Size = new System.Drawing.Size(372, 96);
			this.panelStatus.TabIndex = 11;
			this.panelStatus.Paint += new System.Windows.Forms.PaintEventHandler(this.labelStatus_Paint);
			// 
			// labelCopying
			// 
			this.labelCopying.AutoSize = true;
			this.labelCopying.BackColor = System.Drawing.Color.Transparent;
			this.labelCopying.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelCopying.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelCopying.Location = new System.Drawing.Point(2, 2);
			this.labelCopying.Name = "labelCopying";
			this.labelCopying.Size = new System.Drawing.Size(78, 20);
			this.labelCopying.TabIndex = 3;
			this.labelCopying.Text = "Copying...";
			// 
			// labelStatus
			// 
			this.labelStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelStatus.Location = new System.Drawing.Point(4, 30);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(358, 66);
			this.labelStatus.TabIndex = 2;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(522, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 95;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// SelectInfoSetForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 338);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.panelStatusHolder);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.buttonCopy);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.buttonAddSet);
			this.Controls.Add(this.gridSets);
			this.Controls.Add(this.buttonRemoveSet);
			this.Controls.Add(this.buttonEditSet);
			this.Controls.Add(this.buttonSetActive);
			this.helpProvider1.SetHelpKeyword(this, "InfoSetManagement.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(560, 372);
			this.Name = "SelectInfoSetForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Information Set Management";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SelectInfoSetForm_KeyPress);
			this.Load += new System.EventHandler(this.SelectInfoSetForm_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.SelectInfoSetForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.gridSets)).EndInit();
			this.panelStatusHolder.ResumeLayout(false);
			this.panelStatus.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public static void	ShowForm(Form owner)
		{
			SelectInfoSetForm form = new SelectInfoSetForm();

			form.ShowDialog(owner);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			if (copyingInfoSet)
			{
				e.Cancel = true;
				return;
			}

			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			//mam
			isLoading = true;
			//</mam>

			// Set up the toolbar
			System.Reflection.Assembly thisExe = 
				System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = 
				thisExe.GetManifestResourceStream("WAM.Graphics.UI.SelectInfoSetForm.ActiveStatus.bmp");

			imageListActiveStatus.Images.AddStrip(Bitmap.FromStream(file));
			LoadGrid();

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			isLoading = false;
			SetButtons();
			//</mam>
			
			base.OnLoad(e);
		}

		private void		LoadGrid()
		{
			//mam 
			loadingGrid = true;
			//</mam>

			WAM.Data.InfoSet[] infoSets = WAM.Data.InfoSet.LoadAll();
			int				row = 1;

			gridSets.Redraw = false;
			gridSets.Rows.Count = 1;
			for (int pos = 0; pos < infoSets.Length; pos++)
			{
				gridSets.Rows.Add().UserData = infoSets[pos];
				UpdateGridRow(row++, infoSets[pos]);
			}

			gridSets.Redraw = true;

			//mam
			loadingGrid = false;
			//</mam>
		}

		private void		UpdateGridRow(int row, InfoSet infoSet)
		{
			gridSets.SetCellImage(row, 1, 
				imageListActiveStatus.Images[
				Drive.SQL.BoolToBit(infoSet.ID == InfoSet.CurrentID)]);
			gridSets.SetCellImage(row, 1, imageListActiveStatus.Images[
				Drive.SQL.BoolToBit(infoSet.ID == InfoSet.CurrentID)]);
			//mam - highlight the active InfoSet
			if (!copyingInfoSet && Drive.SQL.BoolToBit(infoSet.ID == InfoSet.CurrentID) != 0)
			{
				gridSets.Select(row, 1);
				curSelRow = row;
			}
			//</mam>

			gridSets.SetData(row, 2, infoSet.Name);
			gridSets.SetData(row, 3, infoSet.Description);

			if (infoSet.GetFixed())
			{
				gridSets.Rows[row].Style = gridSets.Styles["FixedInfoSet"];
				gridSets.SetData(row, 4, infoSet.GetFixed());
			}

			SetButtons();
		}

		private void buttonAddSet_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (InfoSetDetailForm.ShowForm(0, this))
			{
				LoadGrid();
			}
			SetButtons();
		}

		private InfoSet		GetSelectedInfoSet()
		{
			InfoSet			infoSet = null;

			if (gridSets.Rows.Count >= gridSets.Rows.Fixed)
				infoSet = gridSets.Rows[gridSets.Row].UserData as InfoSet;

			return infoSet;
		}

		private void buttonRemoveSet_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			InfoSet			infoSet = GetSelectedInfoSet();

			if (infoSet != null)
			{
				if (infoSet.ID == InfoSet.CurrentID)
				{
					MessageBox.Show(this,
						"This information set is currently the active set. You may not delete the active information set.",
						"Delete Information Set",
						MessageBoxButtons.OK, MessageBoxIcon.Information);

						//mam - prevent the "Delete Information Set?" messagebox from popping up
						return;
						//</mam>
				}

				//gridSets.Rows.Add().UserData = infoSets[pos];
				//mam - specify name of InfoSet in message
				//DialogResult result = MessageBox.Show(this, 
				//	"Are you sure that you want to delete Information Set  \r\n'" + gridSets.RowSel.ToString() + "'  ?",
				//	"Delete Information Set?", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
				//	MessageBoxDefaultButton.Button2);
				DialogResult result = MessageBox.Show(this, 
					"All data and photos for this Information Set will be deleted.\n\nAre you sure that you want to delete Information Set\r\n'" + infoSet.Name + "'  ?",
					"Delete Information Set?", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
					MessageBoxDefaultButton.Button2);
				//</mam>

				if (result == DialogResult.Yes)
				{
					infoSet.Delete();

					//mam 102309 - don't delete photos
					//mam 102309 - delete photos
					//mam - delete photos
					string pathToDelete = infoSet.GetImagePath();
					if (pathToDelete != "")
					{
						try
						{
							if (System.IO.Directory.Exists(pathToDelete))
								System.IO.Directory.Delete(pathToDelete, true);
						}
						catch
						{
						}
					}
					//</mam>

					gridSets.RemoveItem(gridSets.Row);
				}
			}

			SetButtons();
		}

		private void buttonEditSet_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			InfoSet			infoSet = GetSelectedInfoSet();

			if (infoSet != null)
			{
				if (InfoSetDetailForm.ShowForm(infoSet.ID, this))
				{
					int row = gridSets.Row;

					infoSet = new InfoSet(infoSet.ID);
					gridSets.Rows[row].UserData = infoSet;
					UpdateGridRow(row, infoSet);
				}
			}

			SetButtons();
		}

		private void buttonSetActive_Click(object sender, System.EventArgs e)
		{
			InfoSet			infoSet = GetSelectedInfoSet();

			if (infoSet != null && infoSet.ID != InfoSet.CurrentID)
			{
				InfoSet.CurrentID = infoSet.ID;

				//mam - force the entire cache to reload (for some reason, it is not doing so 
				//LoadCacheForm.ShowForm(infoSet.ID, this);
				LoadCacheForm.ShowForm(infoSet.ID, this, true);
				//</mam>

				// Update for the image
				for (int row = 1; row < gridSets.Rows.Count; row++)
					UpdateGridRow(row, (InfoSet)gridSets.Rows[row].UserData);
			}
			SetButtons();
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private void buttonCopy_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to copy data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam
			copyingInfoSet = true;
			copyPhoto = false;
			cancelCopy = false;
			//</mam>

			DialogResult result = MessageBox.Show(this, 
				"Would you like to copy the photos for this InfoSet?", 
				"Copy InfoSet Photos", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2);
			//</mam>

			if (result == DialogResult.Cancel)
			{
				copyingInfoSet = false;
				MessageBox.Show("The InfoSet has not been copied.", "Copy InfoSet", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			else if (result == DialogResult.Yes)
			{
				copyPhoto = true;
			}
			else if (result == DialogResult.No)
			{
				copyPhoto = false;
			}

			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
			//mam - disable buttons while copying
			gridSets.Enabled = false;
			buttonAddSet.Enabled = false;
			buttonRemoveSet.Enabled = false;
			buttonEditSet.Enabled = false;
			buttonCopy.Enabled = false;
			buttonSetActive.Enabled = false;
			buttonClose.Enabled = false;
			//</mam>

			labelStatus.Text = "";
			panelStatusHolder.Visible = true;
			this.Refresh();

			InfoSet			infoSet = GetSelectedInfoSet();
			InfoSet			newSet;
			InfoSet			orgSet = infoSet;

			try
			{
				orgSet = infoSet;
				newSet = new InfoSet(0);
				newSet.Name = GetNewInfoSetName(orgSet);
				orgSet.CopyTo(newSet);
				newSet.Save();
				m_currentInfoSet = orgSet.Name;
				ImportFacilities(orgSet, newSet);

				UpdateStatus();
				if (cancelCopy)
				{
					CancelCopyMessage();
					//return;
				}

				LoadGrid();
				gridSets.Select(curSelRow, 1);

				this.Cursor = System.Windows.Forms.Cursors.Default;
				panelStatusHolder.Visible = false;

				if (!cancelCopy)
				{
					MessageBox.Show("The InfoSet was copied successfully.", "Copy InfoSet",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
				}
			}
			catch
			{
				MessageBox.Show("An error occurred while copying the InfoSet.", "Copy InfoSet",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			}
			finally
			{
				//mam
				copyingInfoSet = false;
				copyPhoto = false;
				cancelCopy = false;
				this.Cursor = System.Windows.Forms.Cursors.Default;
				panelStatusHolder.Visible = false;

				gridSets.Enabled = true;
				buttonAddSet.Enabled = true;
				buttonRemoveSet.Enabled = true;
				buttonEditSet.Enabled = true;
				buttonCopy.Enabled = true;
				buttonSetActive.Enabled = true;
				buttonClose.Enabled = true;
				//</mam>
			}

			SetButtons();
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private void		UpdateStatus()
		{
			m_statusBuilder.Length = 0;

			if (m_currentInfoSet.Length > 0)
				m_statusBuilder.Append(m_currentInfoSet);
			
			if (m_currentFacility.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentFacility);
			}

			if (m_currentProcess.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentProcess);
			}

			if (m_currentComponent.Length > 0)
			{
				m_statusBuilder.Append(" / ");
				m_statusBuilder.Append(m_currentComponent);
			}

			labelStatus.Text = m_statusBuilder.ToString();

			labelStatus.Refresh();

			//mam - don't allow DoEvents
			//mam - OK, allow it, but only because buttons have now been disabled, 
			//	and we're giving the user a chance to cancel the copying
			Application.DoEvents();
			//</mam>
		}
		//</mam>

		//mam 102309
		private string CreateImagesFolder(string assetName)
		{
			//string curDate = DateTime.Now.Ticks.ToString();
			string curPath = WAM.Common.Globals.WamPhotoPath;
			string imagePathCopyTo = curPath + "\\" + assetName;
			bool successCreatePhotoFolder = false;

			if (System.IO.Directory.Exists(imagePathCopyTo))
			{
				successCreatePhotoFolder = true;
			}
			else
			{
				try
				{
					System.IO.Directory.CreateDirectory(imagePathCopyTo);
					successCreatePhotoFolder = true;
				}
				catch
				{
				}
			}

//			if (!successCreatePhotoFolder)
//			{
//				try
//				{
//					imagePathCopyTo = curDate;
//					System.IO.Directory.CreateDirectory(imagePathCopyTo);
//					successCreatePhotoFolder = true;
//				}
//				catch
//				{
//				}
//			}

			return successCreatePhotoFolder ? imagePathCopyTo : "";
		}

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportFacilities(InfoSet orgSet, InfoSet newSet)
		{
			Facility[]		sourceFacilities = CacheManager.GetFacilities(orgSet.ID);
			Facility		source;
			Facility		newFacility;

			sourceInfoSetImagePath = orgSet.GetImagePath();

			//mam 102309
			//newInfoSetImagePath = newSet.GetImagePath();
			newInfoSetImagePath = CreateImagesFolder(newSet.Name);

			for (int pos = 0; pos < sourceFacilities.Length; pos++)
			{
				source = sourceFacilities[pos];
				m_currentFacility = source.Name;
				UpdateStatus();
				if (cancelCopy)
				{
					//CancelCopyMessage();
					return true;
				}

				newFacility = new Facility(0);
				source.CopyTo(newFacility, copyPhoto);
				newFacility.InfoSetID = newSet.ID;
				newFacility.Save();

				//mam - this is no longer necessary, as only the Facilities.CustomENRListID field is copied, rather than
				//	copying the actual ENR Table values
				//if (source.UsesCustomENRTable)
				//	source.CopyENRTable(newFacility);
				//</mam>

				//mam - copy photos
				if (copyPhoto)
				{
					//too slow:
					//string copyPhoto1From = source.GetImage1PathReport();
					//string copyPhoto2From = source.GetImage2PathReport();
					//string copyPhotoTo = "";

					//faster:

					//mam 102309 - check Photo1 before using ID string
					//mam 102309 - no
					string copyPhoto1From = "";
					string copyPhoto1To = "";
					string copyPhoto2From = "";
					string copyPhoto2To = "";
					//if (source.PhotoNorth != "")
					//{
					//	copyPhoto1From = @sourceInfoSetImagePath + "\\" + source.PhotoNorth;
					//	copyPhoto1To = @newInfoSetImagePath + "\\" + newFacility.PhotoNorth;
					//}
					//else
					//{
						copyPhoto1From = string.Format(@"{0}\{1:D4}-N.jpg", @sourceInfoSetImagePath, source.ID);
						copyPhoto1To = string.Format(@"{0}\{1:D4}-N.jpg", @newInfoSetImagePath, newFacility.ID);
					//}

					//mam 102309 - check Photo2 before using ID string
					//mam 102309 - no
					//if (source.PhotoSouth != "")
					//{
					//	copyPhoto2From = @sourceInfoSetImagePath + "\\" + source.PhotoSouth;
					//	copyPhoto2To = @newInfoSetImagePath + "\\" + newFacility.PhotoSouth;
					//}
					//else
					//{
						copyPhoto2From = string.Format(@"{0}\{1:D4}-S.jpg", @sourceInfoSetImagePath, source.ID);
						copyPhoto2To = string.Format(@"{0}\{1:D4}-S.jpg", @newInfoSetImagePath, newFacility.ID);
					//}

					try
					{
						if (System.IO.File.Exists(copyPhoto1From))
							System.IO.File.Copy(copyPhoto1From, copyPhoto1To, true);
					}
					catch
					{
					}

					try
					{
						if (System.IO.File.Exists(copyPhoto2From))
							System.IO.File.Copy(copyPhoto2From, copyPhoto2To, true);
					}
					catch
					{
					}
				}
				//</mam>

				ImportProcesses(source, newFacility, orgSet.ID);
			}

			m_currentFacility = "";
			UpdateStatus();
			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportProcesses(Facility sourceFacility, Facility newFacility, int orgSetID)
		{
			TreatmentProcess[] sourceProcesses = CacheManager.GetProcesses(orgSetID, sourceFacility.ID);
			TreatmentProcess sourceProcess;
			TreatmentProcess newProcess;

			for (int pos = 0; pos < sourceProcesses.Length; pos++)
			{
				sourceProcess = sourceProcesses[pos];
				m_currentProcess = sourceProcess.Name;
				UpdateStatus();
				if (cancelCopy)
				{
					//CancelCopyMessage();
					return true;
				}

				newProcess = new TreatmentProcess(0);
				sourceProcess.CopyTo(newProcess, copyPhoto);
				newProcess.FacilityID = newFacility.ID;
				newProcess.Save();

				//mam - copy photo
				if (copyPhoto)
				{
					//too slow:
					//string copyPhotoFrom = sourceProcess.GetImagePath();
					//string copyPhotoTo = newProcess.GetImagePath();

					//faster:

					//mam 102309 - check Photo before using ID string
					//mam 12309 - no
					string copyPhotoFrom = "";
					string copyPhotoTo = "";
					//if (sourceProcess.Photo != "")
					//{
					//	copyPhotoFrom = @sourceInfoSetImagePath + "\\" + sourceProcess.Photo;
					//	copyPhotoTo = @newInfoSetImagePath + "\\" + newProcess.Photo;
					//}
					//else
					//{
						copyPhotoFrom = string.Format(
							@"{0}\{1:D4}-{2:D4}.jpg", @sourceInfoSetImagePath,
							sourceFacility.ID, sourceProcess.ID);
						copyPhotoTo = string.Format(
							@"{0}\{1:D4}-{2:D4}.jpg", @newInfoSetImagePath,
							newFacility.ID, newProcess.ID);
					//}
					try
					{
						if (System.IO.File.Exists(copyPhotoFrom))
							System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
					}
					catch
					{
					}
				}
				//</mam>

				ImportComponents(sourceProcess, newProcess, orgSetID);
			}

			m_currentProcess = "";
			UpdateStatus();
			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportComponents(TreatmentProcess sourceProcess, TreatmentProcess newProcess, int orgSetID)
		{
			MajorComponent[] sourceComponents = CacheManager.GetComponents(orgSetID, sourceProcess.ID);
			MajorComponent sourceComponent;
			MajorComponent newComponent;

			for (int pos = 0; pos < sourceComponents.Length; pos++)
			{
				sourceComponent = sourceComponents[pos];
				m_currentComponent = sourceComponent.Name;
				UpdateStatus();
				if (cancelCopy)
				{
					//CancelCopyMessage();
					return true;
				}

				newComponent = new MajorComponent(0);
				sourceComponent.CopyTo(newComponent, copyPhoto);
				newComponent.ProcessID = newProcess.ID;
				newComponent.Save();

				//mam 07072011
				newComponent.InsertCriticalityValuesAllCopy(sourceComponent.ID, newComponent.ID);

				//mam - copy photo
				if (copyPhoto)
				{
					//too slow:
					//string copyPhotoFrom = sourceComponent.GetImagePath();
					//string copyPhotoTo = newComponent.GetImagePath();

					//faster:

					//mam 102309 - check Photo before using ID string
					//mam 12309 - no
					string copyPhotoFrom = "";
					string copyPhotoTo = "";
					//if (sourceComponent.Photo != "")
					//{
					//	copyPhotoFrom = @sourceInfoSetImagePath + "\\" + sourceComponent.Photo;
					//	copyPhotoTo = @newInfoSetImagePath + "\\" + newComponent.Photo;
					//}
					//else
					//{
						copyPhotoFrom = string.Format(
							@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @sourceInfoSetImagePath,
							sourceProcess.FacilityID, sourceProcess.ID, sourceComponent.ID);
						copyPhotoTo = string.Format(
							@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @newInfoSetImagePath,
							newProcess.FacilityID, newProcess.ID, newComponent.ID);
					//}

					try
					{
						if (System.IO.File.Exists(copyPhotoFrom))
							System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
					}
					catch
					{
					}
				}
				//</mam>

				ImportDisciplines(sourceComponent, newComponent, orgSetID, sourceProcess.ID, newProcess.ID, sourceProcess.FacilityID, newProcess.FacilityID);
			}

			m_currentComponent = "";
			UpdateStatus();
			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportDisciplines(MajorComponent sourceComponent, MajorComponent newComponent, int orgSetID, 
								int sourceProcessID, int newProcessID, int sourceFacilityID, int newFacilityID)
		{
			Discipline[]	disciplines = CacheManager.GetDisciplines(orgSetID, sourceComponent.ID);
			Discipline		newDiscipline = null;
			bool			importAssetList = false;
			bool			importPipeData = false;
			bool			importNodeData = false;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				// Skip non-existent disciplines
				//mam - don't skip the Mech Disc because it may have assets
				//mam - in fact, don't skip any of the disciplines, because they may have photos
				//if (disciplines[pos].ConditionRanking == CondRank.No && disciplines[pos].Type != DisciplineType.Mechanical)
				//	continue;
				//</mam>

				importAssetList = false;
				importPipeData = false;
				importNodeData = false;

				switch (disciplines[pos].Type)
				{
					case DisciplineType.Mechanical:
						newDiscipline = new DisciplineMech(0);
						importAssetList = true;
						break;
					case DisciplineType.Structural:
						newDiscipline = new DisciplineStruct(0);
						break;
					case DisciplineType.Land:
						newDiscipline = new DisciplineLand(0);
						break;
					case DisciplineType.Pipes:
						newDiscipline = new DisciplinePipe(0);
						importPipeData = true;
						break;
					case DisciplineType.Nodes:
						newDiscipline = new DisciplineNode(0);
						importNodeData = true;
						break;
					default:
						continue;
				}

				//mam 07072011 - have to use error grid
				C1.Win.C1FlexGrid.C1FlexGrid gridErrors = Common.CommonTasks.GetErrorGrid();

				newDiscipline.ComponentID = newComponent.ID;

				//mam 07072011 - added parameter gridErrors
				disciplines[pos].CopyTo(newDiscipline, copyPhoto, ref gridErrors);
				newDiscipline.Save();

				//mam - copy photo
				if (copyPhoto)
				{
					string copyPhotoFrom = "";
					string copyPhotoTo = "";

					switch (disciplines[pos].Type)
					{
						case DisciplineType.Mechanical:
						case DisciplineType.Structural:
						{
							//newDiscipline.ComponentID
							//newDiscipline.InfoSetID

							//too slow:
							//string copyPhotoFrom = disciplines[pos].GetImagePath();
							//string copyPhotoTo = newDiscipline.GetImagePath();

							//faster:
							//string copyPhotoFrom = disciplines[pos].GetImagePath(sourceFacilityID, sourceProcessID, sourceComponent.ID, sourceComponent.InfoSetID);
							//string copyPhotoTo = newDiscipline.GetImagePath(newFacilityID, newProcessID, newComponent.ID, newComponent.InfoSetID);

							//a little faster still:

							//mam 102309 - check Photo before using ID string
							//mam 12309 - no
							//if (disciplines[pos].Photo != "")
							//{
							//	copyPhotoFrom = @sourceInfoSetImagePath + "\\" + disciplines[pos].Photo;
							//	copyPhotoTo = @newInfoSetImagePath + "\\" + newDiscipline.Photo;
							//}
							//else
							//{
								copyPhotoFrom = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @sourceInfoSetImagePath,
									sourceFacilityID, sourceProcessID, sourceComponent.ID, (int)disciplines[pos].Type);
								copyPhotoTo = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @newInfoSetImagePath,
									newFacilityID, newProcessID, newComponent.ID, (int)newDiscipline.Type);
							//}

							try
							{
								if (System.IO.File.Exists(copyPhotoFrom))
									System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
							}
							catch
							{
							}
						}
							break;
						case DisciplineType.Land:
						{
							//mam 102309
							//newDiscipline = new DisciplineLand(newDiscipline.ID);

							for (int i = 1; i <= 3; i++)
							{
								//too slow:
								//string copyPhotoFrom = ((DisciplineLand)disciplines[pos]).GetImagePath(i);
								//string copyPhotoTo = ((DisciplineLand)newDiscipline).GetImagePath(i);

								//faster:
								//string copyPhotoFrom = ((DisciplineLand)disciplines[pos]).GetImagePath(sourceFacilityID, sourceProcessID, sourceComponent.ID, sourceComponent.InfoSetID);
								//string copyPhotoTo = ((DisciplineLand)newDiscipline).GetImagePath(newFacilityID, newProcessID, newComponent.ID, newComponent.InfoSetID);

								//a little faster still:

								//mam 102309 - check Photo before using ID string
//								bool photoExists = false;
//								if (i == 1)
//								{
//									if (((DisciplineLand)disciplines[pos]).Photo1 != "")
//									{
//										copyPhotoFrom = @sourceInfoSetImagePath + "\\" + ((DisciplineLand)disciplines[pos]).Photo1;
//										copyPhotoTo = @newInfoSetImagePath + "\\" + ((DisciplineLand)newDiscipline).Photo1;
//										photoExists = true;
//									}
//								}
//								if (i == 2)
//								{
//									if (((DisciplineLand)disciplines[pos]).Photo2 != "")
//									{
//										copyPhotoFrom = @sourceInfoSetImagePath + "\\" + ((DisciplineLand)disciplines[pos]).Photo2;
//										copyPhotoTo = @newInfoSetImagePath + "\\" + ((DisciplineLand)newDiscipline).Photo2;
//										photoExists = true;
//									}
//								}
//								if (i == 3)
//								{
//									if (((DisciplineLand)disciplines[pos]).Photo3 != "")
//									{
//										copyPhotoFrom = @sourceInfoSetImagePath + "\\" + ((DisciplineLand)disciplines[pos]).Photo3;
//										copyPhotoTo = @newInfoSetImagePath + "\\" + ((DisciplineLand)newDiscipline).Photo3;
//										photoExists = true;
//									}
//								}

								//if (!photoExists)
								//{
									copyPhotoFrom = string.Format(
										@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @sourceInfoSetImagePath,
										sourceFacilityID, sourceProcessID, sourceComponent.ID, (int)disciplines[pos].Type, i);
									copyPhotoTo = string.Format(
										@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @newInfoSetImagePath,
										newFacilityID, newProcessID, newComponent.ID, (int)newDiscipline.Type, i);
								//}

								try
								{
									if (System.IO.File.Exists(copyPhotoFrom))
										System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
								}
								catch
								{
								}
							}
							break;
						}
						
						default:
							//continue;
							break;
					}
				}
				//</mam>

				if (importAssetList)
				{
					//ImportAssetList(sourceComponent, newComponent, sourceConnection);
					ImportAssetList(sourceComponent, newComponent, orgSetID);
				}
				else if (importPipeData)
				{
					//ImportPipeData(disciplines[pos], newDiscipline, sourceConnection);
					ImportPipeData(disciplines[pos], newDiscipline, orgSetID);
				}
				else if (importNodeData)
				{
					//ImportNodeData(disciplines[pos], newDiscipline, sourceConnection);
					ImportNodeData(disciplines[pos], newDiscipline, orgSetID);
				}
			}

			m_currentComponent = "";
			UpdateStatus();
			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportAssetList(MajorComponent sourceComponent, MajorComponent newComponent, int orgSetID)
		{
			ComponentAsset[] sourceAssets = CacheManager.GetAssets(orgSetID, sourceComponent.ID);
			ComponentAsset	sourceAsset = null;
			ComponentAsset	newAsset = null;

			for (int pos = 0; pos < sourceAssets.Length; pos++)
			{
				sourceAsset = sourceAssets[pos];

				newAsset = new ComponentAsset(0);
				sourceAsset.CopyTo(newAsset);
				newAsset.ComponentID = newComponent.ID;
				newAsset.Save();
			}

			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportPipeData(Discipline sourceDiscipline, Discipline newDiscipline, int orgSetID)
		{
			PipeData[]		sourceRecords = CacheManager.GetPipeDataForDiscipline(orgSetID, sourceDiscipline.ID);
			PipeData		sourceRec = null;
			PipeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new PipeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscPipeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011
				newRec.SaveCriticalityValuesAll();
			}

			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportNodeData(Discipline sourceDiscipline, Discipline newDiscipline, int orgSetID)
		{
			NodeData[]		sourceRecords = CacheManager.GetNodeDataForDiscipline(orgSetID, sourceDiscipline.ID);
			NodeData		sourceRec = null;
			NodeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new NodeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscNodeID = newDiscipline.ID;
				newRec.Save();

				//mam 11142011
				newRec.SaveCriticalityValuesAll();
			}

			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private string		GetNewInfoSetName(InfoSet importSet)
		{
			InfoSet[]		existingSets = InfoSet.LoadAll();
			string			curName = importSet.Name;
			string			orgName = importSet.Name;
			int				attempts = 0;

			// Iterate through the info sets to be imported; don't duplicate info 
			// set names (append a rev # on the end; user may rename later)
			for (int pos = 0; pos < existingSets.Length; pos++)
			{
				if (string.Compare(curName, existingSets[pos].Name) == 0)
				{
					attempts++;
					curName = string.Format("{0} {1}", orgName, attempts);
					// Start the loop back over so that we can try the new name
					pos = -1;
				}
			}

			return curName;
		}

		private void labelStatus_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
		//</mam>

		//mam
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			hlpEvent.Handled = true;

			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "InfoSetManagement.htm");
		}
		//</mam>

		//mam
		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "InfoSetManagement.htm");
		}
		//</mam>

		//mam
		private void gridSets_AfterSelChange(object sender, C1.Win.C1FlexGrid.RangeEventArgs e)
		{
			if (copyingInfoSet || loadingGrid)
				return;

			curSelRow = e.NewRange.r1;

			//don't allow fixed infoset to be edited or deleted
			if (curSelRow > 0)
				SetButtons();
		}
		//</mam>

		//mam
		private void SetButtons()
		{
			if (isLoading || loadingGrid)
				return;

			buttonEditSet.Enabled = true;
			buttonRemoveSet.Enabled = true;

			InfoSet infoSet = null;

			if (curSelRow > gridSets.Rows.Count - 1)
				return;

			infoSet = gridSets.Rows[curSelRow].UserData as InfoSet;
			if (infoSet.GetFixed())
			{
				buttonEditSet.Enabled = false;
			}
		}
		//</mam>

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			cancelCopy = true;
		}

		private void CancelCopyMessage()
		{
			MessageBox.Show(this, "The copying of the information set has been stopped.",
				"Copy Information Set", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void buttonCancel_MouseEnter(object sender, System.EventArgs e)
		{
			buttonCancel.Cursor = Cursors.AppStarting;
		}

		private void buttonCancel_MouseLeave(object sender, System.EventArgs e)
		{
			buttonCancel.Cursor = Cursors.WaitCursor;
		}

		private void SelectInfoSetForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void SelectInfoSetForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void SelectInfoSetForm_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
