using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using C1.Win.C1FlexGrid;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ErrorDisplayMessage.
	/// </summary>
	public class ErrorDisplayMessage : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		C1FlexGrid gridReasons = new C1FlexGrid();
		ArrayList arrayListReasons = new ArrayList();
		StringBuilder builderList = new StringBuilder();
		string messageText1 = string.Empty;
		string messageText2 = string.Empty;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Panel panel24;
		private System.Windows.Forms.Panel panelGridHolder;
		private System.Windows.Forms.Label labelSkipReasonMessage1;
		private System.Windows.Forms.Label labelSkipReasonMessage2;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCopyToClipboard;
		private C1.Win.C1FlexGrid.C1FlexGrid c1FlexGridErrorList;
		private System.ComponentModel.Container components = null;

		#endregion /***** Member Variables *****/

		#region /***** Construction and Disposal *****/

		public ErrorDisplayMessage(C1FlexGrid gridReasons, string messageText1, string messageText2)
		{
			InitializeComponent();

			this.gridReasons = gridReasons;
			this.messageText1 = messageText1;
			this.messageText2 = messageText2;
		}

		public ErrorDisplayMessage()
		{
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			labelSkipReasonMessage1.Text = messageText1;
			labelSkipReasonMessage2.Text = messageText2;
			InitializeControls();

			base.OnLoad(e);
		}

		private void InitializeControls()
		{
			this.Text = "Errors";
			this.CenterToParent();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;

			c1FlexGridErrorList.AllowEditing = false;

			c1FlexGridErrorList.Cols.Count = 2;
			c1FlexGridErrorList.Cols.Fixed = 1;
			c1FlexGridErrorList.Cols[0].WidthDisplay = 25;
			//c1FlexGridErrorList.Cols[1].WidthDisplay = 60;
			//c1FlexGridErrorList.Cols[1].WidthDisplay = c1FlexGridErrorList.Width - 25;
			//c1FlexGridErrorList.Cols[3].WidthDisplay = 100;
			c1FlexGridErrorList.ExtendLastCol = true;

			//c1FlexGridErrorList.Cols[1].DataType = typeof(Int32);

			c1FlexGridErrorList.Rows[0].HeightDisplay = 2 * c1FlexGridErrorList.Rows[0].Height;

			//c1FlexGridErrorList.Cols[1].Name = "LineNumber";
			c1FlexGridErrorList.Cols[1].Name = "Error";
			//c1FlexGridErrorList.Cols[3].Name = "IDNumber";

			//c1FlexGridErrorList.Cols[1].Caption = "Line\r\nNumber";
			//c1FlexGridErrorList.Cols[2].Caption = "Reason " + itemType + " was Not Imported";
			c1FlexGridErrorList.Cols[1].Caption = "Error Description";
			//c1FlexGridErrorList.Cols[3].Caption = "ID Number";

			//for (int i = 1; i <= 3; i++)
			//{
			//	c1FlexGridErrorList.Cols[i].TextAlignFixed = TextAlignEnum.CenterCenter;
			//}
			c1FlexGridErrorList.Cols[1].TextAlignFixed = TextAlignEnum.CenterCenter;

			c1FlexGridErrorList.Rows.Count = gridReasons.Rows.Count;
			c1FlexGridErrorList.Rows.Fixed = gridReasons.Rows.Fixed;
			
			CellRange cellRange = gridReasons.GetCellRange(1, 1, gridReasons.Rows.Count - 1, gridReasons.Cols.Count - 1);
			cellRange.Normalize();
			CellRange cellRange2 = c1FlexGridErrorList.GetCellRange(1, 1, c1FlexGridErrorList.Rows.Count - 1, c1FlexGridErrorList.Cols.Count - 1);
			cellRange2.Normalize();
			cellRange2.Clip = cellRange.Clip.ToString();

			c1FlexGridErrorList.Rows[0].HeightDisplay = 35;

			SetRowNumbersInGrid();
		}

		private void SetRowNumbersInGrid()
		{
			//add row numbers to the fixed column
			for (int i = 1; i < c1FlexGridErrorList.Rows.Count; i++)
			{
				c1FlexGridErrorList[i, 0] = i;
			}
		}

		//mam 07072011
		public void SetProperties(C1FlexGrid gridReasons, string messageText1, string messageText2)
		{
			this.gridReasons = gridReasons;
			this.messageText1 = messageText1;
			this.messageText2 = messageText2;
		}

		#endregion /***** Methods *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ErrorDisplayMessage));
			this.labelSkipReasonMessage1 = new System.Windows.Forms.Label();
			this.c1FlexGridErrorList = new C1.Win.C1FlexGrid.C1FlexGrid();
			this.labelTitle = new System.Windows.Forms.Label();
			this.panel24 = new System.Windows.Forms.Panel();
			this.panelGridHolder = new System.Windows.Forms.Panel();
			this.labelSkipReasonMessage2 = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCopyToClipboard = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridErrorList)).BeginInit();
			this.panelGridHolder.SuspendLayout();
			this.SuspendLayout();
			// 
			// labelSkipReasonMessage1
			// 
			this.labelSkipReasonMessage1.BackColor = System.Drawing.Color.Transparent;
			this.labelSkipReasonMessage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelSkipReasonMessage1.Location = new System.Drawing.Point(9, 46);
			this.labelSkipReasonMessage1.Name = "labelSkipReasonMessage1";
			this.labelSkipReasonMessage1.Size = new System.Drawing.Size(504, 16);
			this.labelSkipReasonMessage1.TabIndex = 3;
			this.labelSkipReasonMessage1.Text = "label1";
			// 
			// c1FlexGridErrorList
			// 
			this.c1FlexGridErrorList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1FlexGridErrorList.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
			this.c1FlexGridErrorList.ColumnInfo = "2,1,0,0,0,85,Columns:";
			this.c1FlexGridErrorList.Location = new System.Drawing.Point(1, 1);
			this.c1FlexGridErrorList.Name = "c1FlexGridErrorList";
			this.c1FlexGridErrorList.Rows.Count = 2;
			this.c1FlexGridErrorList.Size = new System.Drawing.Size(474, 186);
			this.c1FlexGridErrorList.Styles = new C1.Win.C1FlexGrid.CellStyleCollection(@"Normal{Font:Microsoft Sans Serif, 8.25pt;}	Fixed{BackColor:Control;ForeColor:ControlText;Border:Flat,1,ControlDark,Both;}	Highlight{BackColor:Highlight;ForeColor:HighlightText;}	Search{BackColor:Highlight;ForeColor:HighlightText;}	Frozen{BackColor:Beige;}	EmptyArea{BackColor:AppWorkspace;Border:Flat,1,ControlDarkDark,Both;}	GrandTotal{BackColor:Black;ForeColor:White;}	Subtotal0{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal1{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal2{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal3{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal4{BackColor:ControlDarkDark;ForeColor:White;}	Subtotal5{BackColor:ControlDarkDark;ForeColor:White;}	");
			this.c1FlexGridErrorList.TabIndex = 0;
			this.c1FlexGridErrorList.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.c1FlexGridErrorList_BeforeEdit);
			this.c1FlexGridErrorList.AfterSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.c1FlexGridErrorList_AfterSort);
			this.c1FlexGridErrorList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.c1FlexGridErrorList_KeyDown);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelTitle.Location = new System.Drawing.Point(0, 0);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(492, 32);
			this.labelTitle.TabIndex = 5;
			this.labelTitle.Text = " Errors";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel24
			// 
			this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel24.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(172)), ((System.Byte)(168)), ((System.Byte)(153)));
			this.panel24.Location = new System.Drawing.Point(0, 32);
			this.panel24.Name = "panel24";
			this.panel24.Size = new System.Drawing.Size(500, 2);
			this.panel24.TabIndex = 150;
			// 
			// panelGridHolder
			// 
			this.panelGridHolder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelGridHolder.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(172)), ((System.Byte)(168)), ((System.Byte)(153)));
			this.panelGridHolder.Controls.Add(this.c1FlexGridErrorList);
			this.panelGridHolder.Location = new System.Drawing.Point(8, 92);
			this.panelGridHolder.Name = "panelGridHolder";
			this.panelGridHolder.Size = new System.Drawing.Size(476, 188);
			this.panelGridHolder.TabIndex = 0;
			// 
			// labelSkipReasonMessage2
			// 
			this.labelSkipReasonMessage2.BackColor = System.Drawing.Color.Transparent;
			this.labelSkipReasonMessage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelSkipReasonMessage2.Location = new System.Drawing.Point(9, 72);
			this.labelSkipReasonMessage2.Name = "labelSkipReasonMessage2";
			this.labelSkipReasonMessage2.Size = new System.Drawing.Size(504, 16);
			this.labelSkipReasonMessage2.TabIndex = 4;
			this.labelSkipReasonMessage2.Text = "label1";
			this.labelSkipReasonMessage2.Visible = false;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(465, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 153;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Visible = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(412, 288);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&Close";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCopyToClipboard
			// 
			this.buttonCopyToClipboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonCopyToClipboard.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCopyToClipboard.Location = new System.Drawing.Point(8, 288);
			this.buttonCopyToClipboard.Name = "buttonCopyToClipboard";
			this.buttonCopyToClipboard.Size = new System.Drawing.Size(72, 23);
			this.buttonCopyToClipboard.TabIndex = 1;
			this.buttonCopyToClipboard.Text = "Copy &All";
			this.buttonCopyToClipboard.Click += new System.EventHandler(this.buttonCopyToClipboard_Click);
			// 
			// ErrorDisplayMessage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(492, 318);
			this.Controls.Add(this.buttonCopyToClipboard);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelSkipReasonMessage2);
			this.Controls.Add(this.panelGridHolder);
			this.Controls.Add(this.panel24);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.labelSkipReasonMessage1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(500, 352);
			this.Name = "ErrorDisplayMessage";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ErrorDisplayMessage";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.ErrorDisplayMessage_Closing);
			((System.ComponentModel.ISupportInitialize)(this.c1FlexGridErrorList)).EndInit();
			this.panelGridHolder.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void c1FlexGridErrorList_AfterSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
		{
			SetRowNumbersInGrid();
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("This feature is not yet available");
			//Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsSelectReportData.htm");
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void buttonCopyToClipboard_Click(object sender, System.EventArgs e)
		{
			//copy all data in the grid to the clipboard
			CellRange cellRange = c1FlexGridErrorList.GetCellRange(0, 1, c1FlexGridErrorList.Rows.Count - 1, c1FlexGridErrorList.Cols.Count - 1);
			cellRange.Normalize();
			Clipboard.SetDataObject(cellRange.Clip.ToString(), true);
		}

		private void c1FlexGridErrorList_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
		{
			//MessageBox.Show("before edit");
			System.Diagnostics.Debug.WriteLine("before edit");
			e.Cancel = true;
		}

		private void c1FlexGridErrorList_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.Control)
			{
				switch (e.KeyCode)
				{
					case Keys.Insert:
					case Keys.C: //copy
						Clipboard.SetDataObject(c1FlexGridErrorList.Clip);
						break;
					case Keys.X: //cut
						//Clipboard.SetDataObject(c1FlexGridErrorList.Clip);
						//CellRange cellRange = c1FlexGridErrorList.Selection;
						//cellRange.Data = null;
						break;
					case Keys.V: //paste
						//IDataObject data = Clipboard.GetDataObject();
						//if (data.GetDataPresent(typeof(string)))
						//{
						//	//get content (note: Excel appends a cr/lf)
						//	string clip = (string)data.GetData(typeof(string));
						//	if (clip.EndsWith("\r\n"))
						//	{
						//		clip = clip.Substring(0, clip.Length - 2);
						//	}

						//	c1FlexGridErrorList.Select(c1FlexGridErrorList.Row, c1FlexGridErrorList.Col, c1FlexGridErrorList.Rows.Count-1, c1FlexGridErrorList.Cols.Count-1, false);
						//	c1FlexGridErrorList.Clip = clip;
						//	c1FlexGridErrorList.Select(c1FlexGridErrorList.Row, c1FlexGridErrorList.Col, false);
						//}
						break;
				}
			}
		}

		private void ErrorDisplayMessage_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			//e.Cancel = this.DialogResult == DialogResult.Cancel;
		}
	}
}
