using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for ReportTemplate.
	/// </summary>
	public class ReportRenderFormat : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Button buttonCancel;

		public delegate void Message(string str);
		public event Message OnMessage;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.RadioButton radioButtonExcel;
		private System.Windows.Forms.RadioButton radioButtonHTML;
		private System.Windows.Forms.RadioButton radioButtonPDF;
		private System.Windows.Forms.RadioButton radioButtonRTF;
		private System.Windows.Forms.RadioButton radioButtonText;
		private System.Windows.Forms.CheckBox checkBoxPDFOneFile;
		private System.Windows.Forms.RadioButton radioButtonCSV;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ReportRenderFormat()
		{
			InitializeComponent();

			this.Text = "Report Format";
			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

//		public ReportTemplate(ref string newTemplateNameFromForm)
//		{
//			InitializeComponent();
////			formOwner = owner;
////			//((WAM.UI.ReportFilterForm)formOwner)
////			formOwner.ne
//			this.newTemplateNameFromForm = newTemplateNameFromForm;
//		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportRenderFormat));
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.buttonOK = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.radioButtonExcel = new System.Windows.Forms.RadioButton();
			this.radioButtonHTML = new System.Windows.Forms.RadioButton();
			this.radioButtonPDF = new System.Windows.Forms.RadioButton();
			this.radioButtonRTF = new System.Windows.Forms.RadioButton();
			this.radioButtonText = new System.Windows.Forms.RadioButton();
			this.checkBoxPDFOneFile = new System.Windows.Forms.CheckBox();
			this.radioButtonCSV = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(10, 11);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(190, 21);
			this.labelReportTemplateName.TabIndex = 0;
			this.labelReportTemplateName.Text = "Select Report Format";
			// 
			// buttonOK
			// 
			this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonOK.Location = new System.Drawing.Point(192, 130);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Size = new System.Drawing.Size(72, 23);
			this.buttonOK.TabIndex = 2;
			this.buttonOK.Text = "&OK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(30)), ((System.Byte)(30)), ((System.Byte)(30)));
			this.buttonCancel.Location = new System.Drawing.Point(273, 130);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(72, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Cancel";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(324, 10);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 92;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// radioButtonExcel
			// 
			this.radioButtonExcel.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonExcel.Location = new System.Drawing.Point(55, 180);
			this.radioButtonExcel.Name = "radioButtonExcel";
			this.radioButtonExcel.Size = new System.Drawing.Size(73, 16);
			this.radioButtonExcel.TabIndex = 93;
			this.radioButtonExcel.Text = "Excel";
			this.radioButtonExcel.Visible = false;
			// 
			// radioButtonHTML
			// 
			this.radioButtonHTML.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonHTML.Location = new System.Drawing.Point(55, 126);
			this.radioButtonHTML.Name = "radioButtonHTML";
			this.radioButtonHTML.Size = new System.Drawing.Size(73, 16);
			this.radioButtonHTML.TabIndex = 94;
			this.radioButtonHTML.Text = "HTML";
			this.radioButtonHTML.Visible = false;
			// 
			// radioButtonPDF
			// 
			this.radioButtonPDF.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonPDF.Location = new System.Drawing.Point(55, 72);
			this.radioButtonPDF.Name = "radioButtonPDF";
			this.radioButtonPDF.Size = new System.Drawing.Size(161, 16);
			this.radioButtonPDF.TabIndex = 95;
			this.radioButtonPDF.Text = "PDF  (for Adobe Reader)";
			// 
			// radioButtonRTF
			// 
			this.radioButtonRTF.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonRTF.Location = new System.Drawing.Point(55, 99);
			this.radioButtonRTF.Name = "radioButtonRTF";
			this.radioButtonRTF.Size = new System.Drawing.Size(177, 16);
			this.radioButtonRTF.TabIndex = 96;
			this.radioButtonRTF.Text = "Rich Text Format  (for Word)";
			// 
			// radioButtonText
			// 
			this.radioButtonText.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonText.Location = new System.Drawing.Point(55, 153);
			this.radioButtonText.Name = "radioButtonText";
			this.radioButtonText.Size = new System.Drawing.Size(73, 16);
			this.radioButtonText.TabIndex = 97;
			this.radioButtonText.Text = "Text";
			this.radioButtonText.Visible = false;
			// 
			// checkBoxPDFOneFile
			// 
			this.checkBoxPDFOneFile.BackColor = System.Drawing.Color.Transparent;
			this.checkBoxPDFOneFile.Location = new System.Drawing.Point(204, 72);
			this.checkBoxPDFOneFile.Name = "checkBoxPDFOneFile";
			this.checkBoxPDFOneFile.Size = new System.Drawing.Size(136, 16);
			this.checkBoxPDFOneFile.TabIndex = 98;
			this.checkBoxPDFOneFile.Text = "All pages in one file";
			this.checkBoxPDFOneFile.Visible = false;
			// 
			// radioButtonCSV
			// 
			this.radioButtonCSV.BackColor = System.Drawing.Color.Transparent;
			this.radioButtonCSV.Location = new System.Drawing.Point(55, 45);
			this.radioButtonCSV.Name = "radioButtonCSV";
			this.radioButtonCSV.Size = new System.Drawing.Size(273, 16);
			this.radioButtonCSV.TabIndex = 99;
			this.radioButtonCSV.Text = "Comma-delimited  (for Excel or other spreadsheet)";
			// 
			// ReportRenderFormat
			// 
			this.AcceptButton = this.buttonOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(354, 160);
			this.Controls.Add(this.radioButtonCSV);
			this.Controls.Add(this.checkBoxPDFOneFile);
			this.Controls.Add(this.radioButtonText);
			this.Controls.Add(this.radioButtonRTF);
			this.Controls.Add(this.radioButtonPDF);
			this.Controls.Add(this.radioButtonHTML);
			this.Controls.Add(this.radioButtonExcel);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.buttonOK);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.labelReportTemplateName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.HelpButton = true;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportRenderFormat";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Report Format";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.ReportTemplate_Paint);
			this.ResumeLayout(false);

		}
		#endregion

//		public static bool	ShowForm(ref string newTemplateName, Form owner)
//		{
//			ReportTemplate form = new ReportTemplate();
//
//			//form.newTemplateName = newTemplateName;
//			//newTemplateName = "ASDF";
//			return form.ShowDialog(owner) == DialogResult.OK;
//			newTemplateName = textBoxReportTemplateName.Text;
//		}

//		public static bool	ShowForm(WAM.Logic.UnitFilter unitFilter, Form owner)
//		{
//			FilterBuilderForm form = new FilterBuilderForm();
//
//			form.m_unitFilter = unitFilter;
//			return form.ShowDialog(owner) == DialogResult.OK;
//		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			this.Text = "Report Template Name";
			radioButtonExcel.Checked = true;

			//mam
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			base.OnLoad(e);
		}

		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			if (radioButtonExcel.Checked)
				this.OnMessage("excel");
			else if (radioButtonHTML.Checked)
				this.OnMessage("html");
			else if (radioButtonPDF.Checked)
			{
				if (checkBoxPDFOneFile.Checked)
					this.OnMessage("pdf1");
				else
					this.OnMessage("pdf");
			}
			else if (radioButtonRTF.Checked)
				this.OnMessage("rtf");
			else if (radioButtonText.Checked)
				this.OnMessage("text");
			else if (radioButtonCSV.Checked)
				this.OnMessage("csv");

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void ReportTemplate_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("The help feature is not yet available.", "Help", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

	}

}
