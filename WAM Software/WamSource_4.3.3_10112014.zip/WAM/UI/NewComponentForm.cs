using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for NewComponentForm.
	/// </summary>
	public class NewComponentForm : System.Windows.Forms.Form
	{
		//mam 03202012
		private int infosetId = 0;
		private int processId = 0;

		private System.Windows.Forms.ComboBox comboBoxComponentType;
		private System.Windows.Forms.Label labelComponentTypeStatic;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonAccept;
		private System.Windows.Forms.TextBox textBoxName;
		private System.Windows.Forms.Label labelName;
		private System.Windows.Forms.HelpProvider helpProvider1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public NewComponentForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(NewComponentForm));
			this.comboBoxComponentType = new System.Windows.Forms.ComboBox();
			this.labelComponentTypeStatic = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonAccept = new System.Windows.Forms.Button();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.labelName = new System.Windows.Forms.Label();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.SuspendLayout();
			// 
			// comboBoxComponentType
			// 
			this.comboBoxComponentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxComponentType.Items.AddRange(new object[] {
																	   "Mechanical / Structural / Civil",
																	   "Nodes / Appurtenances / Piping"});
			this.comboBoxComponentType.Location = new System.Drawing.Point(8, 64);
			this.comboBoxComponentType.Name = "comboBoxComponentType";
			this.comboBoxComponentType.Size = new System.Drawing.Size(344, 21);
			this.comboBoxComponentType.TabIndex = 3;
			// 
			// labelComponentTypeStatic
			// 
			this.labelComponentTypeStatic.BackColor = System.Drawing.Color.Transparent;
			this.labelComponentTypeStatic.Location = new System.Drawing.Point(4, 48);
			this.labelComponentTypeStatic.Name = "labelComponentTypeStatic";
			this.labelComponentTypeStatic.Size = new System.Drawing.Size(352, 16);
			this.labelComponentTypeStatic.TabIndex = 2;
			this.labelComponentTypeStatic.Text = "Select the Component / Subbasin / Subzone type:";
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(275, 96);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 5;
			this.buttonCancel.Text = "Cancel";
			// 
			// buttonAccept
			// 
			this.buttonAccept.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAccept.Location = new System.Drawing.Point(190, 96);
			this.buttonAccept.Name = "buttonAccept";
			this.buttonAccept.TabIndex = 4;
			this.buttonAccept.Text = "&Accept";
			this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
			// 
			// textBoxName
			// 
			this.textBoxName.Location = new System.Drawing.Point(8, 24);
			this.textBoxName.MaxLength = 255;
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(341, 20);
			this.textBoxName.TabIndex = 1;
			this.textBoxName.Text = "";
			// 
			// labelName
			// 
			this.labelName.BackColor = System.Drawing.Color.Transparent;
			this.labelName.Location = new System.Drawing.Point(4, 4);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(352, 16);
			this.labelName.TabIndex = 0;
			this.labelName.Text = "Please enter the name of the new Component / Subbasin / Subzone:";
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// NewComponentForm
			// 
			this.AcceptButton = this.buttonAccept;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(358, 126);
			this.Controls.Add(this.comboBoxComponentType);
			this.Controls.Add(this.labelComponentTypeStatic);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonAccept);
			this.Controls.Add(this.textBoxName);
			this.Controls.Add(this.labelName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "NewComponent.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "NewComponentForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Add New Component";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NewComponentForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.NewComponentForm_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		//mam 03202012 - added infosetId
		//public static MajorComponent ShowForm(int processID, Form owner)
		public static MajorComponent ShowForm(int infosetId, int processID, Form owner)
		{
			NewComponentForm form = new NewComponentForm();
			MajorComponent component = null;

			//mam 03202012
			form.infosetId = infosetId;
			form.processId = processID;

			try
			{
				if (form.ShowDialog(owner) == DialogResult.OK)
				{
					component = new MajorComponent(0);

					component.Name = form.textBoxName.Text;
					component.MechStructDisciplines = 
						(form.comboBoxComponentType.SelectedIndex == 0);
					component.ProcessID = processID;
					component.InfoSetID = InfoSet.CurrentID;

					//mam 102309
					//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
					//int componentId = dataAccess.ExecuteCommandReturnAutoID(component.GetInsertSqlForCopy());
					//component = new MajorComponent(componentId);

					//mam 07072011 - added bool success
					//mam 07072011 - no we're not
					//mam 102309 - no longer necessary as we are saving the component manually, above
					bool success = component.Save();

					//mam 07072011
					if (!success)
					{
						return null;
					}

					//mam 07072011 - should we save criticalities here or in major component Save method?
					//	do it here because the save method saves data for other scenarios (copying a node, saving screen data)
					if (component.MechStructDisciplines)
					{
						component.InsertCriticalityValuesAllDefault();
					}

					//mam 102309
					//Drive.Synchronization.SyncAction add = Drive.Synchronization.SyncAction.Add;
					//Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(component, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(component, add));

					return component;
				}
			}
			finally
			{
				form.Dispose(true);
			}

			return null;
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
		}

		protected override void OnLoad(EventArgs e)
		{
			comboBoxComponentType.SelectedIndex = 0;

			base.OnLoad(e);
		}

		private void buttonAccept_Click(object sender, System.EventArgs e)
		{
			if (textBoxName.Text.Length <= 0)
			{
				MessageBox.Show(this, 
					"Please enter a name for the new component.", "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
				textBoxName.Focus();
				return;
			}

			//************************
			//mam 03202012
			WAM.Data.MajorComponent[] components = WAM.Data.CacheManager.GetComponents(infosetId, processId);
			for (int x = 0; x < components.Length; x++)
			{
				if (string.Compare(components[x].Name.Trim(), textBoxName.Text.Trim(), true) == 0)
				{
					MessageBox.Show(this, "There is already a Component with the name  '" 
						+ textBoxName.Text.Trim() + "'  in the Process."
						+ Environment.NewLine + Environment.NewLine + "Please enter a different name."
						, "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
					textBoxName.Focus();
					return;
				}
			}
			//************************

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void NewComponentForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void NewComponentForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
	}
}
