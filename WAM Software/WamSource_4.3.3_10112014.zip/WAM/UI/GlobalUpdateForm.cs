using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using WAM.Data;
using Drive.Collections;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for GlobalUpdateForm.
	/// </summary>
	public class GlobalUpdateForm : System.Windows.Forms.Form
	{
		#region /***** Variables *****/

		private Facility	m_facility = null;
		private System.Windows.Forms.Button buttonUpdate;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.ComboBox comboBoxGlobalUpdate;
		private System.Windows.Forms.Label labelReportTemplateName;
		private System.Windows.Forms.Label labelWarning;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.ComboBox comboBoxLOS;
		private System.Windows.Forms.Label labelLOS;
		private System.Windows.Forms.Label labelMessage;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.ProgressBar progressBarUpdate;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private C1.Win.C1Input.C1DateEdit c1DateEditInspection;
		private System.Windows.Forms.Label labelInspection;
		private System.Windows.Forms.Label labelRepValueYear;
		private System.Windows.Forms.TextBox textBoxRepValueYear;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public GlobalUpdateForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GlobalUpdateForm));
			this.buttonUpdate = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.labelWarning = new System.Windows.Forms.Label();
			this.comboBoxGlobalUpdate = new System.Windows.Forms.ComboBox();
			this.labelReportTemplateName = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.textBoxRepValueYear = new System.Windows.Forms.TextBox();
			this.labelRepValueYear = new System.Windows.Forms.Label();
			this.labelLOS = new System.Windows.Forms.Label();
			this.comboBoxLOS = new System.Windows.Forms.ComboBox();
			this.c1DateEditInspection = new C1.Win.C1Input.C1DateEdit();
			this.labelInspection = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.labelMessage = new System.Windows.Forms.Label();
			this.progressBarUpdate = new System.Windows.Forms.ProgressBar();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.c1DateEditInspection)).BeginInit();
			this.SuspendLayout();
			// 
			// buttonUpdate
			// 
			this.buttonUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonUpdate.Location = new System.Drawing.Point(76, 208);
			this.buttonUpdate.Name = "buttonUpdate";
			this.buttonUpdate.Size = new System.Drawing.Size(112, 23);
			this.buttonUpdate.TabIndex = 7;
			this.buttonUpdate.Text = "Perform Update";
			this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(308, 231);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(80, 23);
			this.buttonCancel.TabIndex = 3;
			this.buttonCancel.Text = "Close";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// labelWarning
			// 
			this.labelWarning.BackColor = System.Drawing.Color.Transparent;
			this.labelWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelWarning.ForeColor = System.Drawing.Color.Blue;
			this.labelWarning.Location = new System.Drawing.Point(30, 191);
			this.labelWarning.Name = "labelWarning";
			this.labelWarning.Size = new System.Drawing.Size(290, 55);
			this.labelWarning.TabIndex = 6;
			this.labelWarning.Text = "WARNING: This option will override the Level of Service values on all Components " +
				"/ Subbasins / Subzones in this Facility / System !";
			this.labelWarning.Visible = false;
			// 
			// comboBoxGlobalUpdate
			// 
			this.comboBoxGlobalUpdate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxGlobalUpdate.Location = new System.Drawing.Point(17, 63);
			this.comboBoxGlobalUpdate.Name = "comboBoxGlobalUpdate";
			this.comboBoxGlobalUpdate.Size = new System.Drawing.Size(234, 21);
			this.comboBoxGlobalUpdate.TabIndex = 2;
			this.comboBoxGlobalUpdate.SelectedIndexChanged += new System.EventHandler(this.comboBoxGlobalUpdate_SelectedIndexChanged);
			// 
			// labelReportTemplateName
			// 
			this.labelReportTemplateName.BackColor = System.Drawing.Color.Transparent;
			this.labelReportTemplateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelReportTemplateName.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelReportTemplateName.Location = new System.Drawing.Point(8, 8);
			this.labelReportTemplateName.Name = "labelReportTemplateName";
			this.labelReportTemplateName.Size = new System.Drawing.Size(190, 21);
			this.labelReportTemplateName.TabIndex = 0;
			this.labelReportTemplateName.Text = "Global Update";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(16, 43);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(202, 18);
			this.label1.TabIndex = 1;
			this.label1.Text = "Select the global value to update:";
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel1.Location = new System.Drawing.Point(0, 97);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(396, 2);
			this.panel1.TabIndex = 99;
			this.panel1.Visible = false;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel2.Location = new System.Drawing.Point(-1, 214);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(396, 2);
			this.panel2.TabIndex = 100;
			this.panel2.Visible = false;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Transparent;
			this.panel3.Controls.Add(this.textBoxRepValueYear);
			this.panel3.Controls.Add(this.labelRepValueYear);
			this.panel3.Controls.Add(this.labelLOS);
			this.panel3.Controls.Add(this.comboBoxLOS);
			this.panel3.Controls.Add(this.c1DateEditInspection);
			this.panel3.Controls.Add(this.labelInspection);
			this.panel3.Controls.Add(this.panel7);
			this.panel3.Controls.Add(this.panel6);
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Controls.Add(this.labelMessage);
			this.panel3.Location = new System.Drawing.Point(17, 105);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(239, 91);
			this.panel3.TabIndex = 104;
			// 
			// textBoxRepValueYear
			// 
			this.textBoxRepValueYear.Location = new System.Drawing.Point(148, 29);
			this.textBoxRepValueYear.MaxLength = 4;
			this.textBoxRepValueYear.Name = "textBoxRepValueYear";
			this.textBoxRepValueYear.Size = new System.Drawing.Size(48, 20);
			this.textBoxRepValueYear.TabIndex = 122;
			this.textBoxRepValueYear.Text = "0";
			// 
			// labelRepValueYear
			// 
			this.labelRepValueYear.BackColor = System.Drawing.Color.Transparent;
			this.labelRepValueYear.Location = new System.Drawing.Point(10, 32);
			this.labelRepValueYear.Name = "labelRepValueYear";
			this.labelRepValueYear.Size = new System.Drawing.Size(136, 16);
			this.labelRepValueYear.TabIndex = 107;
			this.labelRepValueYear.Text = "Replacement Value Year:";
			this.labelRepValueYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelLOS
			// 
			this.labelLOS.BackColor = System.Drawing.Color.Transparent;
			this.labelLOS.Location = new System.Drawing.Point(36, 62);
			this.labelLOS.Name = "labelLOS";
			this.labelLOS.Size = new System.Drawing.Size(88, 16);
			this.labelLOS.TabIndex = 4;
			this.labelLOS.Text = "Level of Service:";
			this.labelLOS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// comboBoxLOS
			// 
			this.comboBoxLOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxLOS.Location = new System.Drawing.Point(129, 59);
			this.comboBoxLOS.Name = "comboBoxLOS";
			this.comboBoxLOS.Size = new System.Drawing.Size(48, 21);
			this.comboBoxLOS.TabIndex = 5;
			// 
			// c1DateEditInspection
			// 
			this.c1DateEditInspection.AllowDbNull = false;
			this.c1DateEditInspection.FormatType = C1.Win.C1Input.FormatTypeEnum.ShortDate;
			this.c1DateEditInspection.Location = new System.Drawing.Point(116, 60);
			this.c1DateEditInspection.Name = "c1DateEditInspection";
			this.c1DateEditInspection.Size = new System.Drawing.Size(104, 20);
			this.c1DateEditInspection.TabIndex = 121;
			this.c1DateEditInspection.Tag = null;
			this.c1DateEditInspection.Value = new System.DateTime(2003, 7, 31, 0, 0, 0, 0);
			this.c1DateEditInspection.Visible = false;
			// 
			// labelInspection
			// 
			this.labelInspection.Location = new System.Drawing.Point(14, 62);
			this.labelInspection.Name = "labelInspection";
			this.labelInspection.Size = new System.Drawing.Size(100, 16);
			this.labelInspection.TabIndex = 120;
			this.labelInspection.Text = "&Date of Inspection:";
			this.labelInspection.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelInspection.Visible = false;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel7.Location = new System.Drawing.Point(0, 84);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(234, 1);
			this.panel7.TabIndex = 119;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel6.Location = new System.Drawing.Point(0, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(234, 1);
			this.panel6.TabIndex = 118;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel5.Location = new System.Drawing.Point(234, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(1, 84);
			this.panel5.TabIndex = 116;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(1, 84);
			this.panel4.TabIndex = 115;
			// 
			// labelMessage
			// 
			this.labelMessage.BackColor = System.Drawing.Color.Transparent;
			this.labelMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelMessage.Location = new System.Drawing.Point(12, 6);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.Size = new System.Drawing.Size(220, 70);
			this.labelMessage.TabIndex = 3;
			this.labelMessage.Text = "Select the Level of Service to apply to this Facility / System\'s Disciplines:";
			// 
			// progressBarUpdate
			// 
			this.progressBarUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.progressBarUpdate.Location = new System.Drawing.Point(17, 221);
			this.progressBarUpdate.Name = "progressBarUpdate";
			this.progressBarUpdate.Size = new System.Drawing.Size(361, 20);
			this.progressBarUpdate.TabIndex = 8;
			this.progressBarUpdate.Visible = false;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(366, 8);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 106;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// GlobalUpdateForm
			// 
			this.AcceptButton = this.buttonUpdate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(394, 260);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.progressBarUpdate);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.labelReportTemplateName);
			this.Controls.Add(this.comboBoxGlobalUpdate);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonUpdate);
			this.Controls.Add(this.labelWarning);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.helpProvider1.SetHelpKeyword(this, "GlobalUpdate.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "GlobalUpdateForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Global Update";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GlobalUpdateForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.GlobalUpdateForm_Paint);
			this.panel3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.c1DateEditInspection)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Public Methods *****/

		public static bool	ShowForm(Facility facility, Form owner)
		{
			GlobalUpdateForm form = new GlobalUpdateForm();

			form.m_facility = facility;
			return form.ShowDialog(owner) == DialogResult.OK;
		}

		#endregion /***** Public Methods *****/

		#region /***** Methods *****/

		protected override void OnLoad(EventArgs e)
		{
			c1DateEditInspection.Value = DateTime.Now.Date;

			LoadLOS();

			//mam
			LoadGlobalUpdate();
			SetToolTips();

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			commonTasks.LoadHelpImage(pictureBoxHelp);
			commonTasks = null;
			//</mam>

			//mam 050806
			//this.textBoxRepValueYear.Leave += new System.EventHandler(this.TextBoxLeave);

			this.textBoxRepValueYear.Text = DateTime.Now.Year.ToString();

			base.OnLoad(e);
		}

		private void		LoadLOS()
		{
			int				pos;
			LevelOfService[] losValues = 
				(LevelOfService[])Enum.GetValues(typeof(LevelOfService));

			comboBoxLOS.BeginUpdate();
			comboBoxLOS.DisplayMember = "DisplayMember";
			comboBoxLOS.Items.Clear();
			for (pos = 0; pos < losValues.Length; pos++)
			{
				comboBoxLOS.Items.Add(new ListItem(
					EnumHandlers.GetLOSShort(losValues[pos]),
					losValues[pos]));
			}
			comboBoxLOS.EndUpdate();
			comboBoxLOS.SelectedIndex = 2;
		}

		//mam
		private void LoadGlobalUpdate()
		{
			GlobalUpdate[] globalUpdateValues = (GlobalUpdate[])Enum.GetValues(typeof(GlobalUpdate));

			comboBoxGlobalUpdate.Items.Clear();
			comboBoxGlobalUpdate.BeginUpdate();
			comboBoxGlobalUpdate.DisplayMember = "DisplayMember";
			for (int pos = 0; pos < globalUpdateValues.Length; pos++)
			{
				//MessageBox.Show(globalUpdateValues[pos].ToString());
				//if (globalUpdateValues[pos].ToString().Equals(GlobalUpdate.ReplacementValue.ToString()))
				//{
				//	continue;
				//}
				comboBoxGlobalUpdate.Items.Add(new ListItem(
					EnumHandlers.GetGlobalUpdateString(globalUpdateValues[pos]), globalUpdateValues[pos]));
			}
			comboBoxGlobalUpdate.EndUpdate();

			comboBoxGlobalUpdate.SelectedIndex = 0;
		}
		//</mam>

		private bool ValidateValue(int selUpdate)
		{
			if ((int)GlobalUpdate.ReplacementValueYear == selUpdate)
			{

				//validate text box value (must be four-digit value with non-zero first digit)
				string msgText = string.Empty;
				try
				{
					string curValueString = textBoxRepValueYear.Text;

					//must be four digits
					Regex regex = new Regex("[1-9][0-9][0-9][0-9]");
					Match match = regex.Match(curValueString);
					if (!match.Success)
					{
						msgText = "Please enter a four-digit value";
						if (curValueString.Length > 0 && curValueString.Substring(0, 1) == "0")
						{
							msgText += " with a non-zero first digit";
						}
						MessageBox.Show(this, msgText, "Replacement Value Year", 
							MessageBoxButtons.OK, MessageBoxIcon.Information);
						textBoxRepValueYear.Focus();
						return false;
					}
				}
				catch
				{
					msgText = "An error has occurred while attempting to update the Replacement Value Year.";
					msgText += "\r\n\r\nNo Replacement Value Years have been changed.";

					MessageBox.Show(this, msgText, "Replacement Value Year", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return false;
				}
			}

			return true;
		}

		//mam 03202012
		private bool CheckValidInspectionYear()
		{
			//check whether desired inspection year violates timing constraints 

			//install <= last rehab <= inspection <= facility <= next rehab/replacement

			int inspectionYear = ((DateTime)c1DateEditInspection.Value).Date.Year;
			int maxLastRehabYear = 0;
			int curYear = 0;
			//int[] lastRehabYear = new int[5];

			TreatmentProcess[] processesTest = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
			foreach (TreatmentProcess process in processesTest)
			{
				MajorComponent[] componentsTest = CacheManager.GetComponents(InfoSet.CurrentID, process.ID);
				foreach (MajorComponent component in componentsTest)
				{
					Discipline[] disciplinesTest = CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);
					foreach (Discipline discipline in disciplinesTest)
					{
						if (discipline is DisciplineMech)
						{
							curYear = ((DisciplineMech)discipline).RehabYearLast;
							maxLastRehabYear = curYear > maxLastRehabYear ? curYear : maxLastRehabYear;
							//lastRehabYear[0] = ((DisciplineMech)discipline).InstallationYear;
						}
						else if (discipline is DisciplineStruct)
						{
							curYear = ((DisciplineStruct)discipline).RehabYearLast;
							maxLastRehabYear = curYear > maxLastRehabYear ? curYear : maxLastRehabYear;
							//lastRehabYear[1] = ((DisciplineStruct)discipline).InstallationYear;
						}
						else if (discipline is DisciplineLand)
						{
							curYear = ((DisciplineLand)discipline).RehabYearLast;
							maxLastRehabYear = curYear > maxLastRehabYear ? curYear : maxLastRehabYear;
							//lastRehabYear[2] = ((DisciplineLand)discipline).InstallationYear;
						}
						else if (discipline is DisciplinePipe)
						{
							curYear = ((DisciplinePipe)discipline).RehabYearLast;
							maxLastRehabYear = curYear > maxLastRehabYear ? curYear : maxLastRehabYear;
							//lastRehabYear[3] = ((DisciplinePipe)discipline).InstallationYear;
						}
						else if (discipline is DisciplineNode)
						{
							curYear = ((DisciplineNode)discipline).RehabYearLast;
							maxLastRehabYear = curYear > maxLastRehabYear ? curYear : maxLastRehabYear;
							//lastRehabYear[4] = ((DisciplineNode)discipline).InstallationYear;
						}
					}

					//for (int i = 0; i < lastRehabYear.Length; i++)
					//{
					//	//maxLastRehabYear = (int)Math.Max(maxLastRehabYear, lastRehabYear[i]);
					//	maxLastRehabYear = lastRehabYear[i] > maxLastRehabYear ? lastRehabYear[i] : maxLastRehabYear;
					//}
				}
			}
			//}

			//MessageBox.Show("FacilityYear = " + m_facility.CurrentYear.ToString());
			//MessageBox.Show("maxLastRehabYear = " + maxLastRehabYear.ToString());

			if (inspectionYear < maxLastRehabYear)
			{
				string inspectionDate = ((DateTime)c1DateEditInspection.Value).Date.ToShortDateString();
				string msg = "The Inspection Date cannot be set to  " + inspectionDate + "."
					+ Environment.NewLine + Environment.NewLine + "The Inspection year must be greater than the largest Last Rehabilitation Year, which is " 
					+ maxLastRehabYear.ToString() + ".";
				//+ Environment.NewLine + Environment.NewLine + "The largest Last Rehabilitation Year is " + maxLastRehabYear.ToString();
				MessageBox.Show(this, msg, "Cannot Set Inspection Date", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
			if (inspectionYear > m_facility.CurrentYear)
			{
				string inspectionDate = ((DateTime)c1DateEditInspection.Value).Date.ToShortDateString();
				string msg = "The Inspection Date cannot be set to  " + inspectionDate + "."
					+ Environment.NewLine + Environment.NewLine + "The Inspection year must be less than the Facility Current Year, which is " 
					+ m_facility.CurrentYear.ToString() + ".";
				MessageBox.Show(this, msg, "Cannot Set Inspection Date", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			return true;
		}

		private void buttonUpdate_Click(object sender, System.EventArgs e)
		{
			int selUpdate = comboBoxGlobalUpdate.SelectedIndex;
			if (!ValidateValue(selUpdate))
			{
				return;
			}

			//mam 03202012 - determine whether the proposed inspection year violates the timing constraints
			if (selUpdate == (int)GlobalUpdate.DateOfInspection)
			{
				if (!CheckValidInspectionYear())
				{
					return;
				}
			}

			DialogResult result = MessageBox.Show(this,
				"Are you sure you want to perform this update?", "Perform Update?", MessageBoxButtons.YesNo, 
				MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

			if (result != DialogResult.Yes)
			{
				MessageBox.Show("Update cancelled.", "Global Update", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			this.buttonUpdate.Visible = false;
			this.buttonCancel.Visible = false;
			this.progressBarUpdate.Visible = true;
			this.Refresh();
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;

			try
			{
				//int selUpdate = comboBoxGlobalUpdate.SelectedIndex;
				switch (selUpdate)
				{
					case (int)GlobalUpdate.LevelOfService:
					{
						// Get all of the treatment processes in this facility, and 
						// go down to the major component level and set the LOS on 
						// all of the components (that are the standard discipline type)

						//mam - include pipes and nodes, too

						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						PipeData[] pipes;
						NodeData[] nodes;
						LevelOfService los = (LevelOfService)((ListItem)comboBoxLOS.SelectedItem).Value;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int pos = 0;
						int totalItems = 0;
						
						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								if (components[componentPos].MechStructDisciplines)
								{
									totalItems += 1;
								}
								else
								{
									disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
									for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
									{
										if (disciplines[disciplinePos] is DisciplinePipe)
										{
											pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
											totalItems += pipes.Length;
										}
										else if (disciplines[disciplinePos] is DisciplineNode)
										{
											nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
											totalItems += nodes.Length;
										}
									}
								}
							}
						}
						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								if (components[componentPos].MechStructDisciplines)
								{
									progressBarUpdate.Value += 1;
									progressBarUpdate.Refresh();

									components[componentPos].LOS = los;
									components[componentPos].Save();
								}
								else
								{
									//use this code if we are going to include the Pipes and Nodes

									disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
									for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
									{
										if (disciplines[disciplinePos] is DisciplinePipe)
										{
											pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

											for (pos = 0; pos < pipes.Length; pos++)
											{
												progressBarUpdate.Value += 1;
												progressBarUpdate.Refresh();

												pipes[pos].LevelOfService = los;
												pipes[pos].Save();
											}
										}
										else if (disciplines[disciplinePos] is DisciplineNode)
										{
											nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

											for (pos = 0; pos < nodes.Length; pos++)
											{
												progressBarUpdate.Value += 1;
												progressBarUpdate.Refresh();

												nodes[pos].LevelOfService = los;
												nodes[pos].Save();
											}
										}
									}
								}
							}
						}

						break;
					}
				
					//mam 112806 - remove ReplacementValue global update
//					case (int)GlobalUpdate.ReplacementValue:
//					{
//						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
//						MajorComponent[] components;
//						Discipline[] disciplines;
//						PipeData[] pipes;
//						NodeData[] nodes;
//						int processPos = 0;
//						int componentPos = 0;
//						int disciplinePos = 0;
//						int pos = 0;
//						int totalItems = 0;
//
//						//count the total number of items to be modified **************
//						for (processPos = 0; processPos < processes.Length; processPos++)
//						{
//							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);
//
//							for (componentPos = 0; componentPos < components.Length; componentPos++)
//							{
//								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
//								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
//								{
//									if (disciplines[disciplinePos] is DisciplinePipe)
//									{
//										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
//										totalItems += pipes.Length;
//									}
//									else if (disciplines[disciplinePos] is DisciplineNode)
//									{
//										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
//										totalItems += nodes.Length;
//									}
//									else
//									{
//										totalItems += 1;
//									}
//								}
//							}
//						}
//						//*************************************************************
//						progressBarUpdate.Maximum = totalItems;
//
//						progressBarUpdate.Value = 0;
//						for (processPos = 0; processPos < processes.Length; processPos++)
//						{
//							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);
//
//							for (componentPos = 0; componentPos < components.Length; componentPos++)
//							{
//								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
//								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
//								{
//									if (disciplines[disciplinePos] is DisciplinePipe)
//									{
//										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
//
//										for (pos = 0; pos < pipes.Length; pos++)
//										{
//											progressBarUpdate.Value += 1;
//											progressBarUpdate.Refresh();
//
//											pipes[pos].ReplacementValue = pipes[pos].GetCurrentValue();
//											pipes[pos].Save();
//										}
//									}
//									else if (disciplines[disciplinePos] is DisciplineNode)
//									{
//										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
//
//										for (pos = 0; pos < nodes.Length; pos++)
//										{
//											progressBarUpdate.Value += 1;
//											progressBarUpdate.Refresh();
//
//											nodes[pos].ReplacementValue = nodes[pos].GetCurrentValue();
//											nodes[pos].Save();
//										}
//									}
//									else
//									{
//										progressBarUpdate.Value += 1;
//										progressBarUpdate.Refresh();
//
//										disciplines[disciplinePos].ReplacementValue = disciplines[disciplinePos].GetCurrentValue();
//										disciplines[disciplinePos].Save();
//									}
//								}
//							}
//						}
//
//						break;
//					}

					//mam 090105 - add new global update option
					case (int)GlobalUpdate.DateOfInspection:
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int totalItems = 0;
						DateTime inspecDate = ((DateTime)c1DateEditInspection.Value).Date;

						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);

								totalItems += disciplines.Length;
							}
						}

						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									progressBarUpdate.Value += 1;
									progressBarUpdate.Refresh();

									if (disciplines[disciplinePos] is DisciplineMech)
									{
										((DisciplineMech)disciplines[disciplinePos]).DateInspected = inspecDate;
									}
									else if (disciplines[disciplinePos] is DisciplineStruct)
									{
										((DisciplineStruct)disciplines[disciplinePos]).DateInspected = inspecDate;
									}
									else if (disciplines[disciplinePos] is DisciplineLand)
									{
										((DisciplineLand)disciplines[disciplinePos]).DateInspected = inspecDate;
									}
									else if (disciplines[disciplinePos] is DisciplinePipe)
									{
										((DisciplinePipe)disciplines[disciplinePos]).DateInspected = inspecDate;
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										((DisciplineNode)disciplines[disciplinePos]).DateInspected = inspecDate;
									}

									disciplines[disciplinePos].Save();
								}
							}
						}

						break;
					}

					//mam 050806
					case (int)GlobalUpdate.ReplacementValueYear:
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						PipeData[] pipes;
						NodeData[] nodes;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int pos = 0;
						int totalItems = 0;

						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += pipes.Length;
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += nodes.Length;
									}
									else
									{
										totalItems += 1;
									}
								}
							}
						}
						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						int curRepYearValue = textBoxRepValueYear.Text.Length > 0? Convert.ToInt32(textBoxRepValueYear.Text): 0;
						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < pipes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											if (pipes[pos].ReplacementValue > 0)
											{
												pipes[pos].ReplacementValueYear = curRepYearValue;
												pipes[pos].Save();
											}
										}
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < nodes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											if (nodes[pos].ReplacementValue > 0)
											{
												nodes[pos].ReplacementValueYear = curRepYearValue;
												nodes[pos].Save();
											}
										}
									}
									else
									{
										progressBarUpdate.Value += 1;
										progressBarUpdate.Refresh();

										if (disciplines[disciplinePos].ReplacementValue > 0)
										{
											disciplines[disciplinePos].ReplacementValueYear = curRepYearValue;
											disciplines[disciplinePos].Save();
										}
									}
								}
							}
						}

						break;
					}

					//mam 050806
					case (int)GlobalUpdate.AcquisitionCost:
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						PipeData[] pipes;
						NodeData[] nodes;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int pos = 0;
						int totalItems = 0;

						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += pipes.Length;
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += nodes.Length;
									}
									else
									{
										totalItems += 1;
									}
								}
							}
						}
						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < pipes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											pipes[pos].OverrideAcquisitionCost = false;
											pipes[pos].Save();
										}
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < nodes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											nodes[pos].OverrideAcquisitionCost = false;
											nodes[pos].Save();
										}
									}
									else
									{
										progressBarUpdate.Value += 1;
										progressBarUpdate.Refresh();

										disciplines[disciplinePos].OverrideAcquisitionCost = false;
										disciplines[disciplinePos].Save();
									}
								}
							}
						}

						break;
					}

					//mam 112806
					case (int)GlobalUpdate.CurrentValue:
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						PipeData[] pipes;
						NodeData[] nodes;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int pos = 0;
						int totalItems = 0;

						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += pipes.Length;
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += nodes.Length;
									}
									else
									{
										totalItems += 1;
									}
								}
							}
						}
						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < pipes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											pipes[pos].OverrideCurrentValue = false;
											pipes[pos].Save();
										}
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < nodes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											nodes[pos].OverrideCurrentValue = false;
											nodes[pos].Save();
										}
									}
									else
									{
										progressBarUpdate.Value += 1;
										progressBarUpdate.Refresh();

										disciplines[disciplinePos].OverrideCurrentValue = false;
										disciplines[disciplinePos].Save();
									}
								}
							}
						}

						break;
					}

					//mam 112806
					case (int)GlobalUpdate.RepairCost:
					{
						TreatmentProcess[] processes = CacheManager.GetProcesses(InfoSet.CurrentID, m_facility.ID);
						MajorComponent[] components;
						Discipline[] disciplines;
						PipeData[] pipes;
						NodeData[] nodes;
						int processPos = 0;
						int componentPos = 0;
						int disciplinePos = 0;
						int pos = 0;
						int totalItems = 0;

						//count the total number of items to be modified **************
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += pipes.Length;
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);
										totalItems += nodes.Length;
									}
									else
									{
										totalItems += 1;
									}
								}
							}
						}
						//*************************************************************
						progressBarUpdate.Maximum = totalItems;

						progressBarUpdate.Value = 0;
						for (processPos = 0; processPos < processes.Length; processPos++)
						{
							components = CacheManager.GetComponents(InfoSet.CurrentID, processes[processPos].ID);

							for (componentPos = 0; componentPos < components.Length; componentPos++)
							{
								disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, components[componentPos].ID);
								for (disciplinePos = 0; disciplinePos < disciplines.Length; disciplinePos++)
								{
									if (disciplines[disciplinePos] is DisciplinePipe)
									{
										pipes = CacheManager.GetPipeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < pipes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											pipes[pos].OverrideRepairCost = false;
											pipes[pos].Save();
										}
									}
									else if (disciplines[disciplinePos] is DisciplineNode)
									{
										nodes = CacheManager.GetNodeDataForDiscipline(InfoSet.CurrentID, disciplines[disciplinePos].ID);

										for (pos = 0; pos < nodes.Length; pos++)
										{
											progressBarUpdate.Value += 1;
											progressBarUpdate.Refresh();

											nodes[pos].OverrideRepairCost = false;
											nodes[pos].Save();
										}
									}
									else
									{
										progressBarUpdate.Value += 1;
										progressBarUpdate.Refresh();

										disciplines[disciplinePos].OverrideRepairCost = false;
										disciplines[disciplinePos].Save();
									}
								}
							}
						}

						break;
					}

				}

				//this.DialogResult = DialogResult.OK;
				this.progressBarUpdate.Visible = false;
				this.buttonUpdate.Visible = true;
				this.buttonCancel.Visible = true;
				MessageBox.Show("The update completed successfully.", "Global Update", 
					MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch(Exception ex)
			{
				this.DialogResult = DialogResult.Cancel;
				MessageBox.Show(ex.Message.ToString(), "Error",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			}
			finally
			{
				this.progressBarUpdate.Visible = false;
				this.buttonUpdate.Visible = true;
				this.buttonCancel.Visible = true;
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}

			//this.Close();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			//this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		//mam
		private void comboBoxGlobalUpdate_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ResetVisible();

			int selUpdate = comboBoxGlobalUpdate.SelectedIndex;

			switch (selUpdate)
			{
				case (int)GlobalUpdate.LevelOfService:
				{
					//labelMessage.Text = "Select the Level of Service to apply to all Disciplines (except Nodes and Pipes) in this Facility / System:";
					labelMessage.Text = "Select the Level of Service to apply to all Components and Disciplines in this Facility / System:";
					labelLOS.Visible = true;
					comboBoxLOS.Visible = true;
					//labelWarning.Text = "WARNING:\r\nClicking 'Update Values' will override the Level of Service values on all Components / Subbasins / Subzones in this Facility / System !";
				}
				break;
				
				//mam 112806 - remove ReplacementValue global update
//				case (int)GlobalUpdate.ReplacementValue:
//				{
//					labelMessage.Text = "Set the Replacement Value equal to the Current Value for all Disciplines in this Facility / System.";
//					//labelWarning.Text = "WARNING:\r\nClicking 'Update Values' will set the Replacement Value equal to the Current Value for all Disciplines in this Facility / System !";
//				}
//				break;

				//mam 090105 - add new global update option
				case (int)GlobalUpdate.DateOfInspection:
				{
					labelMessage.Text = "Select the Date of Inspection to apply to all Disciplines in this Facility / System:";
					labelInspection.Visible = true;
					c1DateEditInspection.Visible = true;
				}
				break;

				//mam 050806
				case (int)GlobalUpdate.ReplacementValueYear:
				{
					labelRepValueYear.Top = labelLOS.Top;
					textBoxRepValueYear.Top = labelRepValueYear.Top - 3;
					labelRepValueYear.Visible = true;
					textBoxRepValueYear.Visible = true;
					labelMessage.Text = "Set the Replacement Value Year to the specified value for those Disciplines in this Facility / System";
					labelMessage.Text += " that have a Replacement Value greater than zero.";
				}
				break;

				//mam 050806
				case (int)GlobalUpdate.AcquisitionCost:
				{
					labelMessage.Text = "Set ALL Acquisition Costs (including those that are currently overridden) to be automatically calculated for all Disciplines in this Facility / System.";
				}
				break;

				//mam 112806
				case (int)GlobalUpdate.CurrentValue:
				{
					labelMessage.Text = "Set ALL Current Values (including those that are currently overridden) to be automatically calculated for all Disciplines in this Facility / System.";
				}
				break;

				//mam 112806
				case (int)GlobalUpdate.RepairCost:
				{
					labelMessage.Text = "Set ALL Repair Costs (including those that are currently overridden) to be automatically calculated for all Disciplines in this Facility / System.";
				}
				break;
			}
		}
		//</mam>

		//mam
		private void ResetVisible()
		{
			labelLOS.Visible = false;
			comboBoxLOS.Visible = false;
			labelInspection.Visible = false;
			c1DateEditInspection.Visible = false;
			labelRepValueYear.Visible = false;
			textBoxRepValueYear.Visible = false;
		}
		//</mam>

		//mam
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			//helpLabel.Text = (string)requestingControl.Tag;
			hlpEvent.Handled = true;

			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GlobalUpdate.htm");
		}
		//</mam>

		//mam
		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("The help feature is not yet available.", "Help", 
			//	MessageBoxButtons.OK, MessageBoxIcon.Information);
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GlobalUpdate.htm");
		}

		private void GlobalUpdateForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}
		//</mam>

		//mam
		private void SetToolTips()
		{
			// Create the ToolTip and associate with the Form container.
			ToolTip toolTip = new ToolTip();

			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			toolTip.SetToolTip(this.pictureBoxHelp, "Help");
		}

		private void GlobalUpdateForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}
		//</mam>

		#endregion /***** Methods *****/
	}
}
