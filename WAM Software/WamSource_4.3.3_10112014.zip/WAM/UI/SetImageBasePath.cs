using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for SetImageBasePath.
	/// </summary>
	public class SetImageBasePath : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonAccept;
		private System.Windows.Forms.Label labelName;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBoxImagePath;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.PictureBox pictureBoxHelp;

		public Form FormOwner = null;
		public SetImageBasePath()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SetImageBasePath));
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonAccept = new System.Windows.Forms.Button();
			this.textBoxImagePath = new System.Windows.Forms.TextBox();
			this.labelName = new System.Windows.Forms.Label();
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCancel.Location = new System.Drawing.Point(357, 103);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 1;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// buttonAccept
			// 
			this.buttonAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonAccept.Location = new System.Drawing.Point(272, 103);
			this.buttonAccept.Name = "buttonAccept";
			this.buttonAccept.TabIndex = 0;
			this.buttonAccept.Text = "&Accept";
			this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
			// 
			// textBoxImagePath
			// 
			this.textBoxImagePath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxImagePath.Location = new System.Drawing.Point(5, 37);
			this.textBoxImagePath.MaxLength = 255;
			this.textBoxImagePath.Name = "textBoxImagePath";
			this.textBoxImagePath.ReadOnly = true;
			this.textBoxImagePath.Size = new System.Drawing.Size(348, 20);
			this.textBoxImagePath.TabIndex = 2;
			this.textBoxImagePath.Text = "";
			// 
			// labelName
			// 
			this.labelName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelName.BackColor = System.Drawing.Color.Transparent;
			this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelName.Location = new System.Drawing.Point(5, 7);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(343, 16);
			this.labelName.TabIndex = 4;
			this.labelName.Text = "Set the Path for All WAM Images";
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonBrowse.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonBrowse.Location = new System.Drawing.Point(357, 36);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.TabIndex = 3;
			this.buttonBrowse.Text = "Browse";
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(6, 59);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(342, 28);
			this.label1.TabIndex = 9;
			this.label1.Text = "(This image path is for all InfoSets in WAM.  Do not include the folder name for " +
				"any specific InfoSet in the path.)";
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(411, 4);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 96;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// SetImageBasePath
			// 
			this.AcceptButton = this.buttonAccept;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(438, 132);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.buttonBrowse);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonAccept);
			this.Controls.Add(this.textBoxImagePath);
			this.Controls.Add(this.labelName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "SetImageBasePath";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Set Image Base Path";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.SetImageBasePath_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SetImageBasePath_KeyPress);
			this.Load += new System.EventHandler(this.SetImageBasePath_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.SetImageBasePath_Paint);
			this.ResumeLayout(false);

		}
		#endregion

		private void SetImageBasePath_Load(object sender, System.EventArgs e)
		{
			this.textBoxImagePath.Text = WAM.Common.Globals.WamPhotoPath;
		}

		private void SetImageBasePath_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.DialogResult = DialogResult.Cancel;
				this.Close();
			}
		}

		private void SetImageBasePath_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void buttonBrowse_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.FolderBrowserDialog folderDialog = new FolderBrowserDialog();
			folderDialog.ShowNewFolderButton = false;
			folderDialog.Description = "Select the path for the WAM images";
			string curPath = textBoxImagePath.Text.Trim();
			if (curPath != "" && System.IO.Directory.Exists(curPath))
			{
				folderDialog.SelectedPath = curPath;
			}
			else
			{
				folderDialog.SelectedPath = Application.StartupPath;
			}

			if (folderDialog.ShowDialog() == DialogResult.OK)
			{
				string setPath = folderDialog.SelectedPath;
				this.textBoxImagePath.Text = setPath;
			}
		}

		private void buttonAccept_Click(object sender, System.EventArgs e)
		{
			WAM.Common.CommonTasks.SetInfosetImagePath(textBoxImagePath.Text);
			this.Close();

			((MainForm)FormOwner).AfterChangeImageFolder();
		}

		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void SetImageBasePath_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "SettingPhotoPath.htm");
		}
	}
}
