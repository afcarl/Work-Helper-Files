using System;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using WAM.Data;
using C1.Win.C1Chart;

namespace WAM.UI
{
	/// <summary>
	/// Summary description for GraphViewerForm.
	/// </summary>
	public class GraphViewerForm : System.Windows.Forms.Form
	{
		#region /***** Member Variables *****/

		string chartPropString = "";

		private ArrayList	m_graphUnits = null;
		private GraphYAxis	m_yAxis = GraphYAxis.AcquisitionCost;
		private System.Windows.Forms.Button buttonClose;
		private C1.Win.C1Chart.C1Chart chart;
		private System.Windows.Forms.Button buttonConfigureGraph;
		private System.Windows.Forms.Button buttonSaveImage;
		private System.Windows.Forms.Button buttonPrint;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private ArrayList dataPointArrayListGroup0 = new ArrayList();
		private ArrayList dataPointArrayListGroup1 = new ArrayList();

		private Form parentForm = null;
		private object[] objGraphSettings = null;
		private bool m_initialized = false;
		private bool showY2Axis = false;
		private decimal billionErrY1 = 0;
		private decimal billionErrY2 = 0;
		private string unitType = "";
		private int axisMinX = 0;
		private int axisMaxX = 0;
		private double axisMinY1 = 0;
		private double axisMaxY1 = 0;
		private double axisMinY2 = 0;
		private double axisMaxY2 = 0;

		// default values
		private int axisMinXDefault = 0;
		private int axisMaxXDefault = 0;
		private double axisMinY1Default = 0;
		private double axisMaxY1Default = 0;
		private double axisMinY2Default = 0;
		private double axisMaxY2Default = 0;
		private double axisUnitMajorXDefault = 0;
		private double axisUnitMajorY1Default = 0;
		private double axisUnitMajorY2Default = 0;
		private double axisUnitMinorXDefault = 0;
		private double axisUnitMinorY1Default = 0;
		private double axisUnitMinorY2Default = 0;

		private int unitChangeXDefault = 0;
		private double unitChangeY1Default = 0;
		private double unitChangeY2Default = 0;

		GraphViewerForm formLegend;
		bool isFormLegend = false;
		//</mam>

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		//mam
		private GraphYAxis	m_yAxis2 = GraphYAxis.AcquisitionCost;
		private decimal valueLow1 = 0;
		private decimal valueLow2 = 0;
		private int unitChangeX = 0;
		private double unitChangeY1 = 0;
		private double unitChangeY2 = 0;
		private int valueYearLow = 0;
		private int valueYearHigh = 0;
		private string axisCurrent = "Y2";
		private System.Windows.Forms.HScrollBar hScrollBarAxisMin;
		private System.Windows.Forms.HScrollBar hScrollBarAxisMax;
		private System.Windows.Forms.Label labelAxisMin;
		private System.Windows.Forms.Label labelAxisMax;
		private System.Windows.Forms.Label labelAxisMaxCaption;
		private System.Windows.Forms.Label labelAxisMinCaption;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button buttonResetGraphValues;
		private System.Windows.Forms.RadioButton radioButtonAxisY2;
		private System.Windows.Forms.RadioButton radioButtonAxisY1;
		private System.Windows.Forms.RadioButton radioButtonAxisX;
		private System.Windows.Forms.PictureBox pictureBoxHelp;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBoxAxes;
		private System.Windows.Forms.GroupBox groupBoxMaxMin;
		private System.Windows.Forms.CheckBox checkBoxZoom;
		private System.Windows.Forms.Button buttonSyncAxes;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label labelStatus;
		private System.Windows.Forms.Label labelStatus2;
		private System.Windows.Forms.Button buttonTest2;
		private System.Windows.Forms.Button buttonShowHideLegend;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button buttonLegendPopup;
		private System.Windows.Forms.Button buttonSetYAxesToZero;
		private System.Windows.Forms.Label labelAxisUnitMajor;
		//</mam>

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public GraphViewerForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GraphViewerForm));
			this.chart = new C1.Win.C1Chart.C1Chart();
			this.buttonClose = new System.Windows.Forms.Button();
			this.buttonConfigureGraph = new System.Windows.Forms.Button();
			this.buttonSaveImage = new System.Windows.Forms.Button();
			this.buttonPrint = new System.Windows.Forms.Button();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.groupBoxAxes = new System.Windows.Forms.GroupBox();
			this.radioButtonAxisY2 = new System.Windows.Forms.RadioButton();
			this.radioButtonAxisY1 = new System.Windows.Forms.RadioButton();
			this.radioButtonAxisX = new System.Windows.Forms.RadioButton();
			this.groupBoxMaxMin = new System.Windows.Forms.GroupBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.hScrollBarAxisMin = new System.Windows.Forms.HScrollBar();
			this.hScrollBarAxisMax = new System.Windows.Forms.HScrollBar();
			this.labelAxisMin = new System.Windows.Forms.Label();
			this.labelAxisMax = new System.Windows.Forms.Label();
			this.labelAxisMaxCaption = new System.Windows.Forms.Label();
			this.labelAxisMinCaption = new System.Windows.Forms.Label();
			this.buttonResetGraphValues = new System.Windows.Forms.Button();
			this.labelAxisUnitMajor = new System.Windows.Forms.Label();
			this.pictureBoxHelp = new System.Windows.Forms.PictureBox();
			this.labelTitle = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.buttonSyncAxes = new System.Windows.Forms.Button();
			this.checkBoxZoom = new System.Windows.Forms.CheckBox();
			this.buttonLegendPopup = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.buttonSetYAxesToZero = new System.Windows.Forms.Button();
			this.buttonShowHideLegend = new System.Windows.Forms.Button();
			this.labelStatus = new System.Windows.Forms.Label();
			this.labelStatus2 = new System.Windows.Forms.Label();
			this.buttonTest2 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
			this.groupBoxAxes.SuspendLayout();
			this.groupBoxMaxMin.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// chart
			// 
			this.chart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.chart.DataSource = null;
			this.chart.Interaction.Enabled = true;
			this.chart.Location = new System.Drawing.Point(4, 32);
			this.chart.Name = "chart";
			this.chart.PropBag = "<?xml version=\"1.0\"?><Chart2DPropBag Version=\"\"><StyleCollection><NamedStyle Name" +
				"=\"PlotArea\" ParentName=\"Area\" StyleData=\"Border=None,Black,1;\" /><NamedStyle Nam" +
				"e=\"Legend\" ParentName=\"Legend.default\" StyleData=\"Font=Microsoft Sans Serif, 8.2" +
				"5pt;AlignVert=Top;GradientStyle=None;AlignHorz=Center;Wrap=False;ForeColor=Contr" +
				"olText;Border=Solid,Black,1;HatchStyle=None;Opaque=True;BackColor2=;BackColor=Wh" +
				"ite;\" /><NamedStyle Name=\"Footer\" ParentName=\"Control\" StyleData=\"Font=Microsoft" +
				" Sans Serif, 8.25pt;GradientStyle=None;ForeColor=ControlText;Border=None,Black,1" +
				";HatchStyle=None;Opaque=True;BackColor2=;BackColor=White;\" /><NamedStyle Name=\"A" +
				"rea\" ParentName=\"Area.default\" StyleData=\"Font=Microsoft Sans Serif, 8.25pt;Alig" +
				"nVert=Top;GradientStyle=None;Rotation=Rotate0;ForeColor=ControlText;Border=None," +
				"Black,1;HatchStyle=None;Opaque=True;BackColor2=;BackColor=White;\" /><NamedStyle " +
				"Name=\"Control\" ParentName=\"Control.default\" StyleData=\"Font=Microsoft Sans Serif" +
				", 8.25pt;GradientStyle=None;ForeColor=ControlText;Border=Solid,Black,1;HatchStyl" +
				"e=None;Opaque=True;BackColor2=;BackColor=White;\" /><NamedStyle Name=\"AxisX\" Pare" +
				"ntName=\"Area\" StyleData=\"Rotation=Rotate0;AlignHorz=Center;ForeColor=ControlText" +
				";Font=Arial, 8.25pt;AlignVert=Bottom;\" /><NamedStyle Name=\"AxisY\" ParentName=\"Ar" +
				"ea\" StyleData=\"Rotation=Rotate270;AlignHorz=Near;ForeColor=ControlText;Font=Aria" +
				"l, 8.25pt;AlignVert=Center;\" /><NamedStyle Name=\"LabelStyleDefault\" ParentName=\"" +
				"LabelStyleDefault.default\" StyleData=\"Border=Solid,Black,1;Font=Arial, 8.25pt;\" " +
				"/><NamedStyle Name=\"Legend.default\" ParentName=\"Control\" StyleData=\"Border=None," +
				"Black,1;Wrap=False;AlignVert=Top;\" /><NamedStyle Name=\"LabelStyleDefault.default" +
				"\" ParentName=\"Control\" StyleData=\"Border=None,Black,1;BackColor=Transparent;\" />" +
				"<NamedStyle Name=\"Header\" ParentName=\"Control\" StyleData=\"Font=Arial, 8.25pt, st" +
				"yle=Bold;AlignVert=Top;GradientStyle=None;AlignHorz=Center;ForeColor=ControlText" +
				";Border=None,Black,1;HatchStyle=None;Opaque=True;BackColor2=;BackColor=White;\" /" +
				"><NamedStyle Name=\"Control.default\" ParentName=\"\" StyleData=\"ForeColor=ControlTe" +
				"xt;Border=None,Black,1;BackColor=Control;\" /><NamedStyle Name=\"AxisY2\" ParentNam" +
				"e=\"Area\" StyleData=\"Rotation=Rotate90;AlignHorz=Far;ForeColor=ControlText;Font=A" +
				"rial, 8.25pt;AlignVert=Center;\" /><NamedStyle Name=\"Area.default\" ParentName=\"Co" +
				"ntrol\" StyleData=\"Border=None,Black,1;AlignVert=Top;\" /></StyleCollection><Chart" +
				"GroupsCollection><ChartGroup Name=\"Group1\" Use3D=\"False\"><DataSerializer Default" +
				"Set=\"True\"><DataSeriesCollection><DataSeriesSerializer><LineStyle Color=\"Thistle" +
				"\" /><SymbolStyle Color=\"RoyalBlue\" Shape=\"Dot\" /><SeriesLabel>series 0</SeriesLa" +
				"bel><X>1999;2000;2001</X><Y>100000;120000;140000</Y><DataTypes>Double;Double;Dou" +
				"ble;Double;Double</DataTypes><DataFields>;;;;</DataFields></DataSeriesSerializer" +
				"><DataSeriesSerializer><LineStyle Color=\"DarkGray\" /><SymbolStyle Color=\"Cornflo" +
				"werBlue\" Shape=\"Dot\" /><SeriesLabel>series 1</SeriesLabel><X>1999;2000;2001</X><" +
				"Y>105000;115000;135000</Y><DataTypes>Double;Double;Double;Double;Double</DataTyp" +
				"es><DataFields>;;;;</DataFields></DataSeriesSerializer></DataSeriesCollection></" +
				"DataSerializer></ChartGroup><ChartGroup Name=\"Group2\" Use3D=\"False\"><DataSeriali" +
				"zer><DataSeriesCollection><DataSeriesSerializer><LineStyle Color=\"DarkGreen\" /><" +
				"SymbolStyle Color=\"SaddleBrown\" Shape=\"Tri\" /><SeriesLabel>series 2</SeriesLabel" +
				"><X>1999;2000;2001</X><Y>50000;75000;85000</Y><DataTypes>Double;Double;Double;Do" +
				"uble;Double</DataTypes><DataFields>;;;;</DataFields></DataSeriesSerializer><Data" +
				"SeriesSerializer><LineStyle Color=\"DarkGreen\" /><SymbolStyle Color=\"SaddleBrown\"" +
				" Shape=\"InvertedTri\" /><SeriesLabel>series 3</SeriesLabel><X>1999;2000;2001</X><" +
				"Y>60000;65000;70000</Y><DataTypes>Double;Double;Double;Double;Double</DataTypes>" +
				"<DataFields>;;;;</DataFields></DataSeriesSerializer></DataSeriesCollection></Dat" +
				"aSerializer></ChartGroup></ChartGroupsCollection><Header Compass=\"North\" Locatio" +
				"nDefault=\"20, -1\" SizeDefault=\"625, -1\"><Text>vs Time</Text></Header><Footer Com" +
				"pass=\"South\" /><Legend Compass=\"South\" Visible=\"True\" /><ChartArea Depth=\"20\" Ro" +
				"tation=\"45\" Elevation=\"45\" /><Axes><Axis Max=\"2001\" Min=\"1999\" UnitMajor=\"1\" Uni" +
				"tMinor=\"1\" AutoMajor=\"False\" AutoMinor=\"False\" AutoMax=\"True\" AutoMin=\"True\" _on" +
				"Top=\"-1\" Compass=\"South\"><Text>Current Year</Text><GridMajor /><GridMinor /></Ax" +
				"is><Axis Max=\"140000\" Min=\"100000\" AnnoFormat=\"NumericManual\" UnitMajor=\"5000\" U" +
				"nitMinor=\"2500\" AutoMajor=\"True\" AutoMinor=\"True\" AutoMax=\"True\" AutoMin=\"True\" " +
				"_onTop=\"-1\" Compass=\"West\"><SB Min=\"100000\" Max=\"140000\" ScrollKeys=\"Cursor\" /><" +
				"Text>Acquisition Cost ($)</Text><GridMajor Visible=\"True\" Spacing=\"5000\" /><Grid" +
				"Minor /></Axis><Axis Max=\"86000\" Min=\"50000\" AnnoFormat=\"NumericManual\" UnitMajo" +
				"r=\"2000\" UnitMinor=\"1000\" AutoMajor=\"True\" AutoMinor=\"True\" AutoMax=\"True\" AutoM" +
				"in=\"True\" _onTop=\"-1\" Compass=\"East\"><SB Min=\"50000\" Max=\"86000\" ScrollKeys=\"Cur" +
				"sor\" /><GridMajor Visible=\"True\" Spacing=\"2000\" /><GridMinor /></Axis></Axes></C" +
				"hart2DPropBag>";
			this.chart.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.chart.Size = new System.Drawing.Size(659, 432);
			this.chart.TabIndex = 0;
			this.chart.TabStop = false;
			this.chart.UseDoubleBuffer = true;
			this.chart.ChartChanged += new System.EventHandler(this.chart_ChartChanged);
			this.chart.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chart_MouseMove);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonClose.Location = new System.Drawing.Point(553, 512);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonClose.Size = new System.Drawing.Size(104, 23);
			this.buttonClose.TabIndex = 0;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// buttonConfigureGraph
			// 
			this.buttonConfigureGraph.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonConfigureGraph.Location = new System.Drawing.Point(4, 10);
			this.buttonConfigureGraph.Name = "buttonConfigureGraph";
			this.buttonConfigureGraph.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonConfigureGraph.Size = new System.Drawing.Size(109, 21);
			this.buttonConfigureGraph.TabIndex = 3;
			this.buttonConfigureGraph.Text = "Configure Graph";
			this.buttonConfigureGraph.Click += new System.EventHandler(this.buttonConfigureGraph_Click);
			// 
			// buttonSaveImage
			// 
			this.buttonSaveImage.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSaveImage.Location = new System.Drawing.Point(4, 33);
			this.buttonSaveImage.Name = "buttonSaveImage";
			this.buttonSaveImage.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonSaveImage.Size = new System.Drawing.Size(109, 21);
			this.buttonSaveImage.TabIndex = 4;
			this.buttonSaveImage.Text = "Save Graph (Image)";
			this.buttonSaveImage.Click += new System.EventHandler(this.buttonSaveImage_Click);
			// 
			// buttonPrint
			// 
			this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrint.Location = new System.Drawing.Point(4, 56);
			this.buttonPrint.Name = "buttonPrint";
			this.buttonPrint.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonPrint.Size = new System.Drawing.Size(109, 21);
			this.buttonPrint.TabIndex = 5;
			this.buttonPrint.Text = "Print Graph";
			this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// groupBoxAxes
			// 
			this.groupBoxAxes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBoxAxes.Controls.Add(this.radioButtonAxisY2);
			this.groupBoxAxes.Controls.Add(this.radioButtonAxisY1);
			this.groupBoxAxes.Controls.Add(this.radioButtonAxisX);
			this.groupBoxAxes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxAxes.Location = new System.Drawing.Point(5, 510);
			this.groupBoxAxes.Name = "groupBoxAxes";
			this.groupBoxAxes.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.groupBoxAxes.Size = new System.Drawing.Size(123, 26);
			this.groupBoxAxes.TabIndex = 7;
			this.groupBoxAxes.TabStop = false;
			// 
			// radioButtonAxisY2
			// 
			this.radioButtonAxisY2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonAxisY2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButtonAxisY2.Location = new System.Drawing.Point(81, 9);
			this.radioButtonAxisY2.Name = "radioButtonAxisY2";
			this.radioButtonAxisY2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.radioButtonAxisY2.Size = new System.Drawing.Size(40, 14);
			this.radioButtonAxisY2.TabIndex = 2;
			this.radioButtonAxisY2.Text = "Y2";
			this.radioButtonAxisY2.CheckedChanged += new System.EventHandler(this.radioButtonAxisY2_CheckedChanged);
			// 
			// radioButtonAxisY1
			// 
			this.radioButtonAxisY1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonAxisY1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButtonAxisY1.Location = new System.Drawing.Point(42, 9);
			this.radioButtonAxisY1.Name = "radioButtonAxisY1";
			this.radioButtonAxisY1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.radioButtonAxisY1.Size = new System.Drawing.Size(40, 14);
			this.radioButtonAxisY1.TabIndex = 1;
			this.radioButtonAxisY1.Text = "Y1";
			this.radioButtonAxisY1.CheckedChanged += new System.EventHandler(this.radioButtonAxisY1_CheckedChanged);
			// 
			// radioButtonAxisX
			// 
			this.radioButtonAxisX.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.radioButtonAxisX.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButtonAxisX.Location = new System.Drawing.Point(7, 9);
			this.radioButtonAxisX.Name = "radioButtonAxisX";
			this.radioButtonAxisX.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.radioButtonAxisX.Size = new System.Drawing.Size(25, 14);
			this.radioButtonAxisX.TabIndex = 0;
			this.radioButtonAxisX.Text = "X";
			this.radioButtonAxisX.CheckedChanged += new System.EventHandler(this.radioButtonAxisX_CheckedChanged);
			// 
			// groupBoxMaxMin
			// 
			this.groupBoxMaxMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBoxMaxMin.Controls.Add(this.panel1);
			this.groupBoxMaxMin.Controls.Add(this.hScrollBarAxisMin);
			this.groupBoxMaxMin.Controls.Add(this.hScrollBarAxisMax);
			this.groupBoxMaxMin.Controls.Add(this.labelAxisMin);
			this.groupBoxMaxMin.Controls.Add(this.labelAxisMax);
			this.groupBoxMaxMin.Controls.Add(this.labelAxisMaxCaption);
			this.groupBoxMaxMin.Controls.Add(this.labelAxisMinCaption);
			this.groupBoxMaxMin.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBoxMaxMin.Location = new System.Drawing.Point(5, 469);
			this.groupBoxMaxMin.Name = "groupBoxMaxMin";
			this.groupBoxMaxMin.Size = new System.Drawing.Size(169, 46);
			this.groupBoxMaxMin.TabIndex = 6;
			this.groupBoxMaxMin.TabStop = false;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(207)), ((System.Byte)(200)), ((System.Byte)(169)));
			this.panel1.Location = new System.Drawing.Point(4, 24);
			this.panel1.Name = "panel1";
			this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.panel1.Size = new System.Drawing.Size(136, 1);
			this.panel1.TabIndex = 31;
			// 
			// hScrollBarAxisMin
			// 
			this.hScrollBarAxisMin.LargeChange = 1;
			this.hScrollBarAxisMin.Location = new System.Drawing.Point(135, 8);
			this.hScrollBarAxisMin.Maximum = 2020;
			this.hScrollBarAxisMin.Minimum = 1990;
			this.hScrollBarAxisMin.Name = "hScrollBarAxisMin";
			this.hScrollBarAxisMin.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.hScrollBarAxisMin.Size = new System.Drawing.Size(28, 15);
			this.hScrollBarAxisMin.TabIndex = 0;
			this.hScrollBarAxisMin.Value = 1990;
			this.hScrollBarAxisMin.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBarAxisMin_Scroll);
			// 
			// hScrollBarAxisMax
			// 
			this.hScrollBarAxisMax.LargeChange = 1;
			this.hScrollBarAxisMax.Location = new System.Drawing.Point(135, 28);
			this.hScrollBarAxisMax.Name = "hScrollBarAxisMax";
			this.hScrollBarAxisMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.hScrollBarAxisMax.Size = new System.Drawing.Size(28, 15);
			this.hScrollBarAxisMax.TabIndex = 1;
			this.hScrollBarAxisMax.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBarAxisMax_Scroll);
			// 
			// labelAxisMin
			// 
			this.labelAxisMin.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAxisMin.Location = new System.Drawing.Point(31, 8);
			this.labelAxisMin.Name = "labelAxisMin";
			this.labelAxisMin.Size = new System.Drawing.Size(101, 15);
			this.labelAxisMin.TabIndex = 30;
			this.labelAxisMin.Text = "Min value";
			this.labelAxisMin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelAxisMax
			// 
			this.labelAxisMax.BackColor = System.Drawing.Color.Transparent;
			this.labelAxisMax.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAxisMax.Location = new System.Drawing.Point(31, 28);
			this.labelAxisMax.Name = "labelAxisMax";
			this.labelAxisMax.Size = new System.Drawing.Size(101, 15);
			this.labelAxisMax.TabIndex = 29;
			this.labelAxisMax.Text = "Max value";
			this.labelAxisMax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelAxisMaxCaption
			// 
			this.labelAxisMaxCaption.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAxisMaxCaption.Location = new System.Drawing.Point(3, 28);
			this.labelAxisMaxCaption.Name = "labelAxisMaxCaption";
			this.labelAxisMaxCaption.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.labelAxisMaxCaption.Size = new System.Drawing.Size(29, 15);
			this.labelAxisMaxCaption.TabIndex = 28;
			this.labelAxisMaxCaption.Text = "Max:";
			this.labelAxisMaxCaption.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelAxisMinCaption
			// 
			this.labelAxisMinCaption.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAxisMinCaption.Location = new System.Drawing.Point(3, 8);
			this.labelAxisMinCaption.Name = "labelAxisMinCaption";
			this.labelAxisMinCaption.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.labelAxisMinCaption.Size = new System.Drawing.Size(29, 15);
			this.labelAxisMinCaption.TabIndex = 27;
			this.labelAxisMinCaption.Text = "Min:";
			this.labelAxisMinCaption.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// buttonResetGraphValues
			// 
			this.buttonResetGraphValues.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonResetGraphValues.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonResetGraphValues.Location = new System.Drawing.Point(131, 517);
			this.buttonResetGraphValues.Name = "buttonResetGraphValues";
			this.buttonResetGraphValues.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.buttonResetGraphValues.Size = new System.Drawing.Size(41, 19);
			this.buttonResetGraphValues.TabIndex = 8;
			this.buttonResetGraphValues.Text = "Reset";
			this.buttonResetGraphValues.Click += new System.EventHandler(this.buttonResetGraphValues_Click);
			// 
			// labelAxisUnitMajor
			// 
			this.labelAxisUnitMajor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelAxisUnitMajor.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelAxisUnitMajor.Location = new System.Drawing.Point(548, 484);
			this.labelAxisUnitMajor.Name = "labelAxisUnitMajor";
			this.labelAxisUnitMajor.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.labelAxisUnitMajor.Size = new System.Drawing.Size(108, 15);
			this.labelAxisUnitMajor.TabIndex = 31;
			this.labelAxisUnitMajor.Text = "Unit value";
			this.labelAxisUnitMajor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.labelAxisUnitMajor.Visible = false;
			// 
			// pictureBoxHelp
			// 
			this.pictureBoxHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBoxHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp.Image")));
			this.pictureBoxHelp.Location = new System.Drawing.Point(641, 6);
			this.pictureBoxHelp.Name = "pictureBoxHelp";
			this.pictureBoxHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBoxHelp.TabIndex = 91;
			this.pictureBoxHelp.TabStop = false;
			this.pictureBoxHelp.Click += new System.EventHandler(this.pictureBoxHelp_Click);
			// 
			// labelTitle
			// 
			this.labelTitle.BackColor = System.Drawing.Color.Transparent;
			this.labelTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(40)), ((System.Byte)(40)), ((System.Byte)(40)));
			this.labelTitle.Location = new System.Drawing.Point(5, 2);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.labelTitle.Size = new System.Drawing.Size(623, 28);
			this.labelTitle.TabIndex = 92;
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox3
			// 
			this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox3.Controls.Add(this.buttonPrint);
			this.groupBox3.Controls.Add(this.buttonConfigureGraph);
			this.groupBox3.Controls.Add(this.buttonSaveImage);
			this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox3.Location = new System.Drawing.Point(428, 460);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(118, 80);
			this.groupBox3.TabIndex = 94;
			this.groupBox3.TabStop = false;
			// 
			// buttonSyncAxes
			// 
			this.buttonSyncAxes.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSyncAxes.Location = new System.Drawing.Point(4, 33);
			this.buttonSyncAxes.Name = "buttonSyncAxes";
			this.buttonSyncAxes.Size = new System.Drawing.Size(109, 21);
			this.buttonSyncAxes.TabIndex = 2;
			this.buttonSyncAxes.Text = "Sync Y Axes";
			this.buttonSyncAxes.Click += new System.EventHandler(this.buttonSyncAxes_Click);
			// 
			// checkBoxZoom
			// 
			this.checkBoxZoom.Appearance = System.Windows.Forms.Appearance.Button;
			this.checkBoxZoom.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxZoom.Location = new System.Drawing.Point(4, 10);
			this.checkBoxZoom.Name = "checkBoxZoom";
			this.checkBoxZoom.Size = new System.Drawing.Size(109, 21);
			this.checkBoxZoom.TabIndex = 1;
			this.checkBoxZoom.Text = "Zoom";
			this.checkBoxZoom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.checkBoxZoom.CheckedChanged += new System.EventHandler(this.checkBoxZoom_CheckedChanged);
			// 
			// buttonLegendPopup
			// 
			this.buttonLegendPopup.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonLegendPopup.Location = new System.Drawing.Point(4, 33);
			this.buttonLegendPopup.Name = "buttonLegendPopup";
			this.buttonLegendPopup.Size = new System.Drawing.Size(109, 21);
			this.buttonLegendPopup.TabIndex = 97;
			this.buttonLegendPopup.Text = "Legend Pop-up";
			this.buttonLegendPopup.Click += new System.EventHandler(this.buttonLegendPopup_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
			this.groupBox1.Controls.Add(this.buttonSetYAxesToZero);
			this.groupBox1.Controls.Add(this.checkBoxZoom);
			this.groupBox1.Controls.Add(this.buttonSyncAxes);
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(305, 460);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(118, 80);
			this.groupBox1.TabIndex = 98;
			this.groupBox1.TabStop = false;
			// 
			// buttonSetYAxesToZero
			// 
			this.buttonSetYAxesToZero.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSetYAxesToZero.Location = new System.Drawing.Point(4, 56);
			this.buttonSetYAxesToZero.Name = "buttonSetYAxesToZero";
			this.buttonSetYAxesToZero.Size = new System.Drawing.Size(109, 21);
			this.buttonSetYAxesToZero.TabIndex = 3;
			this.buttonSetYAxesToZero.Text = "Set Y Axes to Zero";
			this.buttonSetYAxesToZero.Click += new System.EventHandler(this.buttonSetYAxesToZero_Click);
			// 
			// buttonShowHideLegend
			// 
			this.buttonShowHideLegend.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonShowHideLegend.Location = new System.Drawing.Point(4, 10);
			this.buttonShowHideLegend.Name = "buttonShowHideLegend";
			this.buttonShowHideLegend.Size = new System.Drawing.Size(109, 21);
			this.buttonShowHideLegend.TabIndex = 3;
			this.buttonShowHideLegend.Text = "Hide Legend";
			this.buttonShowHideLegend.Click += new System.EventHandler(this.buttonShowHideLegend_Click);
			// 
			// labelStatus
			// 
			this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelStatus.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelStatus.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelStatus.Location = new System.Drawing.Point(4, 32);
			this.labelStatus.Name = "labelStatus";
			this.labelStatus.Size = new System.Drawing.Size(659, 432);
			this.labelStatus.TabIndex = 99;
			this.labelStatus.Text = "Preparing graph...";
			this.labelStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.labelStatus.Visible = false;
			this.labelStatus.Paint += new System.Windows.Forms.PaintEventHandler(this.labelStatus_Paint);
			// 
			// labelStatus2
			// 
			this.labelStatus2.BackColor = System.Drawing.Color.Transparent;
			this.labelStatus2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelStatus2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.labelStatus2.Location = new System.Drawing.Point(256, 240);
			this.labelStatus2.Name = "labelStatus2";
			this.labelStatus2.Size = new System.Drawing.Size(144, 16);
			this.labelStatus2.TabIndex = 100;
			this.labelStatus2.Text = "Preparing graph...";
			this.labelStatus2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// buttonTest2
			// 
			this.buttonTest2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonTest2.Location = new System.Drawing.Point(596, 468);
			this.buttonTest2.Name = "buttonTest2";
			this.buttonTest2.Size = new System.Drawing.Size(36, 20);
			this.buttonTest2.TabIndex = 101;
			this.buttonTest2.Text = "test";
			this.buttonTest2.Visible = false;
			this.buttonTest2.Click += new System.EventHandler(this.buttonTest2_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
			this.groupBox2.Controls.Add(this.buttonShowHideLegend);
			this.groupBox2.Controls.Add(this.buttonLegendPopup);
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Location = new System.Drawing.Point(182, 460);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(118, 80);
			this.groupBox2.TabIndex = 102;
			this.groupBox2.TabStop = false;
			// 
			// GraphViewerForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(667, 542);
			this.Controls.Add(this.chart);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBoxAxes);
			this.Controls.Add(this.buttonTest2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.pictureBoxHelp);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.labelAxisUnitMajor);
			this.Controls.Add(this.buttonResetGraphValues);
			this.Controls.Add(this.groupBoxMaxMin);
			this.Controls.Add(this.labelStatus2);
			this.Controls.Add(this.labelStatus);
			this.helpProvider1.SetHelpKeyword(this, "Graphing.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MinimumSize = new System.Drawing.Size(675, 575);
			this.Name = "GraphViewerForm";
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.helpProvider1.SetShowHelp(this, true);
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.Resize += new System.EventHandler(this.GraphViewerForm_Resize);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GraphViewerForm_KeyPress);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.GraphViewerForm_Paint);
			((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
			this.groupBoxAxes.ResumeLayout(false);
			this.groupBoxMaxMin.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Load Chores *****/

		//mam - add yAxis2 and showY2Axis parameters
		//mam - no longer need this routine
		//		public static void	ShowForm(ArrayList selectedUnits, GraphYAxis yAxis, GraphYAxis yAxis2, bool showY2Axis, Form owner)
		//		{
		//			GraphViewerForm form = new GraphViewerForm();
		//			
		//			form.m_graphUnits = selectedUnits;
		//			form.m_yAxis = yAxis;
		//
		//			//mam
		//			form.m_yAxis2 = yAxis2;
		//			form.showY2Axis = showY2Axis;
		//			//</mam>
		//
		//			form.Owner = owner;
		//			form.Show();
		//		}
		//</mam>

		//mam
		public void SetValues(ArrayList selectedUnits, GraphYAxis yAxis, GraphYAxis yAxis2, bool showY2Axis, string unitType, Form owner, Form parentForm, ref object[] objGraphSettings)
		{
			m_graphUnits = selectedUnits;
			m_yAxis = yAxis;

			m_yAxis2 = yAxis2;
			this.showY2Axis = showY2Axis;
			this.unitType = unitType;
			this.objGraphSettings = objGraphSettings;
			this.chartPropString = objGraphSettings.GetValue(0).ToString();

			this.Owner = owner;
			this.parentForm = parentForm;
			//this.parentForm.Hide();
			this.Show();
		}
		//</mam>

		//mam
		private void SetValuesResetProperties(ArrayList selectedUnits, GraphYAxis yAxis, GraphYAxis yAxis2, bool showY2Axis, string unitType, Form owner, Form parentForm, ref object[] objGraphSettings)
		{
			m_graphUnits = selectedUnits;
			m_yAxis = yAxis;

			m_yAxis2 = yAxis2;
			this.showY2Axis = showY2Axis;
			this.unitType = unitType;
			this.objGraphSettings = objGraphSettings;
			this.chartPropString = objGraphSettings.GetValue(0).ToString();
		}
		//</mam>

		protected override void OnClosing(CancelEventArgs e)
		{
			if (!isFormLegend)
			{
				// Save our form state
				Drive.Configuration.FormState formState = 
					new Drive.Configuration.FormState(this);

				Drive.Configuration.AppSettings.Settings.
					SetSetting(@"ScreenSettings", 
					this.Name, formState.ToString());

				//mam
				SaveChartProperties();
				//</mam>
			}

			base.OnClosing(e);
			this.Dispose(true);
		}

		protected override void OnLoad(EventArgs e)
		{
			//mam
			m_initialized = false;
			this.chart.Visible = false;
			//</mam>

			Drive.Configuration.FormState formState = 
				new Drive.Configuration.FormState(
				Drive.Configuration.AppSettings.
				Settings.GetSetting("ScreenSettings",
				this.Name));
			formState.RestoreState(this);

			SetChartTitle("Current Year");

			// Load the graph
			LoadGraph();

			//mam
			//SetChartTitle("Current Year");
			AdjustAxisBounds();
			InitControls();
			PopulateDataArray();
			RestoreChartProperties();
			SetBitmaps();
			//</mam>

			//mam
			chart.ChartArea.AxisX.ScrollBar.Appearance = ScrollBarAppearanceEnum.Flat;
			chart.ChartArea.AxisY.ScrollBar.Appearance = ScrollBarAppearanceEnum.Flat;
			chart.ChartArea.AxisY2.ScrollBar.Appearance = ScrollBarAppearanceEnum.Flat;
			
			buttonSyncAxes.Enabled = false;
			if (showY2Axis)
			{
				if (m_yAxis == m_yAxis2)
				{
					SyncAxes(true);
				}

				buttonSyncAxes.Enabled = false;

				string formatStringY1 = chart.ChartArea.AxisY.AnnoFormatString;
				string formatStringY2 = chart.ChartArea.AxisY2.AnnoFormatString;
				if (formatStringY1 == formatStringY2)
				{
					buttonSyncAxes.Enabled = true;
				}
				if ((formatStringY1 == "D1" && formatStringY2 == "F2") || (formatStringY2 == "D1" && formatStringY1 == "F2"))
				{
					buttonSyncAxes.Enabled = true;
				}
				if ((m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
					|| (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
				{
					buttonSyncAxes.Enabled = false;
				}
			}

			buttonSetYAxesToZero.Enabled = true;
			if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				if (!showY2Axis)
				{
					buttonSetYAxesToZero.Enabled = false;
				}
				else if (showY2Axis && (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
				{
					buttonSetYAxesToZero.Enabled = false;
				}
			}

			//use value labels if Condition and/or LOS
			if (showY2Axis && (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
			{
				chart.ChartArea.AxisY2.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.ValueLabels;
			}

			checkBoxZoom.Checked = false;
			ShowZoom(false);
			this.chart.Visible = true;
			SetLegendButtonText();
			GraphViewerForm_Resize(null, null);
			//</mam>

			m_initialized = true;
			base.OnLoad(e);

			//mam 050806 - add this so x- and y-axis max and min will be the last things to be set
			CheckAxisMaxMinDifference(false);
		}

		#endregion /***** Load Chores *****/

		#region /***** Methods *****/

		//mam
		private void InitControls()
		{
			chart.Refresh();
			// store the initial axis values to be used when the graph values are reset
			axisMinXDefault = (int)chart.ChartArea.AxisX.Min;
			axisMaxXDefault = (int)chart.ChartArea.AxisX.Max;
			axisMinY1Default = chart.ChartArea.AxisY.Min;
			axisMaxY1Default = chart.ChartArea.AxisY.Max;
			axisMinY2Default = chart.ChartArea.AxisY2.Min;
			axisMaxY2Default = chart.ChartArea.AxisY2.Max;
			axisUnitMajorXDefault = chart.ChartArea.AxisX.UnitMajor;
			axisUnitMajorY1Default = chart.ChartArea.AxisY.UnitMajor;
			axisUnitMajorY2Default = chart.ChartArea.AxisY2.UnitMajor;
			axisUnitMinorXDefault = chart.ChartArea.AxisX.UnitMinor;
			axisUnitMinorY1Default = chart.ChartArea.AxisY.UnitMinor;
			axisUnitMinorY2Default = chart.ChartArea.AxisY2.UnitMinor;

			unitChangeXDefault = (int)axisUnitMajorXDefault;
			unitChangeY1Default = axisUnitMajorY1Default;
			unitChangeY2Default = axisUnitMajorY2Default;

			// set the auto major and minor values to false
			chart.ChartArea.AxisY.AutoMajor = false;
			chart.ChartArea.AxisY.AutoMinor = false;
			chart.ChartArea.AxisY2.AutoMajor = false;
			chart.ChartArea.AxisY2.AutoMinor = false;

			// set unitChange values
			unitChangeX = 1;
			unitChangeY1 = this.chart.ChartArea.AxisY.UnitMajor;

			if (showY2Axis)
			{
				unitChangeY2 = this.chart.ChartArea.AxisY2.UnitMajor;
			}

			//comment to see what happens
			CheckAxisMaxMinDifference(true);

			// reset graph and label values
			ResetGraphValues(true);
			RefreshDisplayValues(true);

			// set user scroll properties
			hScrollBarAxisMin.SmallChange = 1;
			hScrollBarAxisMin.LargeChange = 1;
			hScrollBarAxisMin.Minimum = 0;
			hScrollBarAxisMin.Maximum = 10000;
			hScrollBarAxisMin.Value = 5000;

			hScrollBarAxisMax.SmallChange = 1;
			hScrollBarAxisMax.LargeChange = 1;
			hScrollBarAxisMax.Minimum = 0;
			hScrollBarAxisMax.Maximum = 10000;
			hScrollBarAxisMax.Value = 5000;

			// change default color from yellow to green
			chart.ChartGroups[0].ChartData[0].SymbolStyle.Color = Color.ForestGreen;
			if (showY2Axis)
			{
				this.chart.ChartGroups[1].ChartData[0].SymbolStyle.Color = Color.ForestGreen;
			}

			// set y1- and y2-axis labels
			chart.ChartArea.AxisY.ValueLabels.Add(1, "5");
			chart.ChartArea.AxisY.ValueLabels.Add(2, "4");
			chart.ChartArea.AxisY.ValueLabels.Add(3, "3");
			chart.ChartArea.AxisY.ValueLabels.Add(4, "2");
			chart.ChartArea.AxisY.ValueLabels.Add(5, "1");

			chart.ChartArea.AxisY2.ValueLabels.Add(1, "5");
			chart.ChartArea.AxisY2.ValueLabels.Add(2, "4");
			chart.ChartArea.AxisY2.ValueLabels.Add(3, "3");
			chart.ChartArea.AxisY2.ValueLabels.Add(4, "2");
			chart.ChartArea.AxisY2.ValueLabels.Add(5, "1");

			//use value labels if Condition and/or LOS
			if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				chart.ChartArea.AxisY.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.ValueLabels;
			}

			//use value labels if Condition and/or LOS
			if (showY2Axis && (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
			{
				chart.ChartArea.AxisY2.AnnoMethod = C1.Win.C1Chart.AnnotationMethodEnum.ValueLabels;
			}

			// set initial values
			axisCurrent = "Y1";
			radioButtonAxisY1.Checked = true;
			radioButtonAxisY2.Enabled = showY2Axis;

			CheckAxisMaxMinDifference(false);
		}
		//</mam>

		//mam
		private void CheckAxisMaxMinDifference(bool setDefaultValues)
		{
			// if the difference between max and min is too great, the labels will 
			//	merge together to look like a vertical stripe, so modify the major and minor tick distances

			//x axis
			long tempValue = 0;

			if ((long)chart.ChartArea.AxisX.UnitMajor > 0)
			{
				tempValue = ((long)chart.ChartArea.AxisX.Max - (long)chart.ChartArea.AxisX.Min) / (long)chart.ChartArea.AxisX.UnitMajor;

				if (tempValue > 10)
				{
					//if (chart.ChartArea.AxisX.AnnotationRotation == 0)
					{
						chart.ChartArea.AxisX.AnnotationRotation = 90;
					}
				}

				if (tempValue > 20)
				{
					if (setDefaultValues)
					{
						axisUnitMajorXDefault = (int)(chart.ChartArea.AxisX.Max - (int)chart.ChartArea.AxisX.Min) / 20;
						//axisUnitMinorXDefault = (int)axisUnitMajorXDefault / 2;
						axisUnitMinorXDefault = 1;
					}
					unitChangeX = ((int)chart.ChartArea.AxisX.Max - (int)chart.ChartArea.AxisX.Min) / 20;
					chart.ChartArea.AxisX.UnitMajor = unitChangeX;
					//chart.ChartArea.AxisX.UnitMinor = (int)(unitChangeX / 2);
					//chart.ChartArea.AxisX.UnitMinor = 1;
				}
			}

			//******************************************

			//y1 axis

			if (chart.ChartArea.AxisY.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
			{
				//a unit of change of less than one is too small when dealing with dollar amounts
				if (chart.ChartArea.AxisY.UnitMajor < 1)
				{
					unitChangeY1 = 1;
					chart.ChartArea.AxisY.UnitMajor = 1;
					chart.ChartArea.AxisY.UnitMinor = 1;

					//the max and min must be at least 10 units apart
					if (chart.ChartArea.AxisY.Max - chart.ChartArea.AxisY.Min < 10)
					{
						chart.ChartArea.AxisY.Max += 10;
						axisMaxY1 = chart.ChartArea.AxisY.Max;
						if (setDefaultValues)
						{
							unitChangeY1Default = unitChangeY1;
							axisMaxY1Default = axisMaxY1;
							axisUnitMajorY1Default = chart.ChartArea.AxisY.UnitMajor;
							axisUnitMinorY1Default = chart.ChartArea.AxisY.UnitMinor;
						}
					}
				}

				if ((long)chart.ChartArea.AxisY.UnitMajor > 0)
				{
					tempValue = ((long)chart.ChartArea.AxisY.Max - (long)chart.ChartArea.AxisY.Min) / (long)chart.ChartArea.AxisY.UnitMajor;
					if (tempValue > 20)
					{
						//limit the number of labels along the y axis to 20 or else they blend together to form a vertical stripe
						if (setDefaultValues)
						{
							//set the default values if this routine is called when the graph is being initially populated
							axisUnitMajorY1Default = (chart.ChartArea.AxisY.Max - chart.ChartArea.AxisY.Min) / 20;
							axisUnitMinorY1Default = axisUnitMajorY1Default / 2;
						}
						unitChangeY1 = (chart.ChartArea.AxisY.Max - chart.ChartArea.AxisY.Min) / 20;
						chart.ChartArea.AxisY.UnitMajor = unitChangeY1;
						chart.ChartArea.AxisY.UnitMinor = unitChangeY1 / 2;
					}
				}
			}
			
			//******************************************

			//y2 axis
			if (showY2Axis && chart.ChartArea.AxisY2.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
			{
				//a unit of change of less than one is too small when dealing with dollar amounts
				if (chart.ChartArea.AxisY2.UnitMajor < 1)
				{
					unitChangeY2 = 1;
					chart.ChartArea.AxisY2.UnitMajor = 1;
					chart.ChartArea.AxisY2.UnitMinor = 1;

					//the max and min must be at least 10 units apart
					if (chart.ChartArea.AxisY2.Max - chart.ChartArea.AxisY2.Min < 10)
					{
						chart.ChartArea.AxisY2.Max += 10;
						axisMaxY2 = chart.ChartArea.AxisY2.Max;
						if (setDefaultValues)
						{
							unitChangeY2Default = unitChangeY2;
							axisMaxY2Default = axisMaxY2;
							axisUnitMajorY2Default = chart.ChartArea.AxisY2.UnitMajor;
							axisUnitMinorY2Default = chart.ChartArea.AxisY2.UnitMinor;
						}
					}
				}

				if ((long)chart.ChartArea.AxisY2.UnitMajor > 0)
				{
					tempValue = ((long)chart.ChartArea.AxisY2.Max - (long)chart.ChartArea.AxisY2.Min) / (long)chart.ChartArea.AxisY2.UnitMajor;
					if (tempValue > 20)
					{
						if (setDefaultValues)
						{
							axisUnitMajorY2Default = (chart.ChartArea.AxisY2.Max - chart.ChartArea.AxisY2.Min) / 20;
							axisUnitMinorY2Default = axisUnitMajorY2Default / 2;
						}
						unitChangeY2 = (chart.ChartArea.AxisY2.Max - chart.ChartArea.AxisY2.Min) / 20;
						if (unitChangeY2 < 1)
						{
							unitChangeY2 = 1;
						}
						chart.ChartArea.AxisY2.UnitMajor = unitChangeY2;
						chart.ChartArea.AxisY2.UnitMinor = unitChangeY2 / 2;
					}
				}
			}
		}
		//</mam>

		private void		LoadGraph()
		{
			// Clear the designer values
			chart.ChartGroups.Group0.ChartData.SeriesList.Clear();

			//mam
			chart.ChartGroups.Group1.ChartData.SeriesList.Clear();
			//</mam>

			chart.ChartArea.AxisY.Text = EnumHandlers.GetGraphYAxisString(m_yAxis);
			chart.ChartArea.AxisY.AnnoFormatString = EnumHandlers.GetGraphYAxisFormatString(m_yAxis);

			//SetChartTitle();

			if (m_yAxis != GraphYAxis.ConditionAndLOS)
				AddChartSeries(m_yAxis, false);
			else
			{
				AddChartSeries(GraphYAxis.LOS, false);
				AddChartSeries(GraphYAxis.Condition, false);
			}

			//mam
			// use 3D bar graph when the y2 axis is shown, regardless of data type
			if (showY2Axis)
			{
				chart.ChartGroups[0].ChartType = C1.Win.C1Chart.Chart2DTypeEnum.Bar;
				chart.ChartGroups[0].Use3D = true;
				chart.ChartGroups[0].Stacked  = false;

				chart.ChartGroups[1].ChartType = C1.Win.C1Chart.Chart2DTypeEnum.Bar;
				chart.ChartGroups[1].Use3D = true;
				chart.ChartGroups[1].Stacked  = false;
			}
			else if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				chart.ChartGroups[0].ChartType = C1.Win.C1Chart.Chart2DTypeEnum.Bar;
				chart.ChartGroups[0].Use3D = false;
				chart.ChartGroups[0].Stacked  = false;
			}
			//</mam>

			if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || 
				m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				//mam - moved this code to AdjustAxisBounds()
				//chart.ChartArea.AxisY.Reversed = true;
				//chart.ChartArea.AxisY.Min = 0;
				//chart.ChartArea.AxisY.Max = 5;
				//</mam>
			}
			else
			{
				chart.ChartArea.AxisY.AutoOrigin = false;
				chart.ChartArea.AxisY.Origin = 0.0;
			}

			//mam - add a second y-axis
			if (!showY2Axis)
				return;

			if (m_yAxis2 != GraphYAxis.ConditionAndLOS)
				AddChartSeries(m_yAxis2, true);
			else
			{
				AddChartSeries(GraphYAxis.LOS, true);
				AddChartSeries(GraphYAxis.Condition, true);
			}

			if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || 
				m_yAxis2 == GraphYAxis.ConditionAndLOS)
			{
				//mam - moved this code to AdjustAxisBounds()
				//chart.ChartArea.AxisY2.Reversed = true;
				//chart.ChartArea.AxisY2.Min = 0;
				//chart.ChartArea.AxisY2.Max = 5;
				//</mam>
			}
			else
			{
				chart.ChartArea.AxisY2.AutoOrigin = false;
				chart.ChartArea.AxisY2.Origin = 0.0;
			}
			chart.ChartArea.AxisY2.Visible = true;
			//</mam>
		}

		private void AddChartSeries(GraphYAxis yAxis, bool isY2)
		{
			GraphUnit		graphUnit;
			IGraphableUnit	unit;
			ChartDataSeries dataSeries = new ChartDataSeries();
			ChartDataSeries dataSeriesTest = new ChartDataSeries();
			int				dataPos;
			int				curYear = 0;
			decimal			curValue;

			//mam 050806
			DateTime curDateInspected = DateTime.Now;
			string yearForLabel = string.Empty;
			Hashtable hashTableUnitInfo = new Hashtable();

			//<mam>
			bool isNA = false;
			//</mam>

			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			int roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			try
			{
				// Go through and add all of the series

				//if there are more than 20 data points, the legend will take up too much space, so hide it
				if (m_graphUnits.Count > 20 || (showY2Axis && m_graphUnits.Count > 10))
				{
					this.chart.Legend.Visible = false;
					SetLegendButtonText();
				}

				if (isY2)
					billionErrY2 = 0;
				else
					billionErrY1 = 0;

				//mam 090105
				GraphUnit graphUnitSearch;
				int graphIDLength = 5;
				int graphYearLength = 4;
				int newIDCounter = 0;
				int checkYear = 0;

				bool addDuplicateSeries = false;
				bool multipleYears = false;

				string[] sameGraphFacilityYear = new string[m_graphUnits.Count];
				for (int i = 0; i < m_graphUnits.Count; i++)
				{
					sameGraphFacilityYear[i] = string.Empty;
				}

				//check whether the graph will contain data from multiple years (this will affect the data series labels)
				for (int pos = 0; pos < m_graphUnits.Count; pos++)
				{
					graphUnit = (GraphUnit)m_graphUnits[pos];
					if (pos == 0)
					{
						checkYear = graphUnit.FacilityYear;
					}
					if (checkYear != graphUnit.FacilityYear)
					{
						multipleYears = true;
						break;
					}
				}

				//mam 050806
				if (m_graphUnits.Count > 0)
				{
					graphUnit = (GraphUnit)m_graphUnits[0];
					if (graphUnit[0] is Facility || graphUnit[0] is TreatmentProcess)
					{
						SetChartTitle("Current Year");
					}
					else
					{
						SetChartTitle("Inspection Year");
					}
				}

				for (int pos = 0; pos < m_graphUnits.Count; pos++)
				{
					//search for another graphUnit with the same name
					//if found, check if parent has same name
					//if so, check if FacilityID and Year are different

					graphUnit = (GraphUnit)m_graphUnits[pos];

					//assign a temporary value
					graphUnitSearch = graphUnit;

					//check for other graphUnits with the same name, same parent name, and different facilityid 
					//	and different facility year
					bool sameGraphUnitFound = false;

					//mam 050806 - moved Facilities into the if block below so that they can be checked for relating
//					if (graphUnit[0] is WAM.Data.Facility)
//					{
//						graphUnit.GraphID = newIDCounter.ToString().PadLeft(graphIDLength, '0') + graphUnit.FacilityYear.ToString().PadLeft(graphYearLength, '0');
//					}
//					else
					{
						//mam 050806 - added Facilities here
						//if the item to graph is a Facility, check that the Facility names are the same
						//	and the InfosetIDs are different
						if (WAM.Common.Globals.AllowGraphNameMatching)
						{
							if (graphUnit[0] is WAM.Data.Facility)
							{
								//find facility with same name but different infoset
								for (int pos2 = 0; pos2 <= pos; pos2++)
								{
									graphUnitSearch = (GraphUnit)m_graphUnits[pos2];

									//mam 050806 - add length check on sameGraphFacilityYear
									//if (graphUnitSearch.GraphID != null && graphUnitSearch.GraphID.Length > 0)
									if (graphUnitSearch.GraphID != null && graphUnitSearch.GraphID.Length > 0
										&& sameGraphFacilityYear[pos2].Length > 0)
									{
										if (graphUnitSearch.ShortName.Equals(graphUnit.ShortName) 
											&& graphUnitSearch.FacilityID != graphUnit.FacilityID
											&& graphUnitSearch.FacilityYear != graphUnit.FacilityYear
											&& sameGraphFacilityYear[pos2].IndexOf(graphUnit.FacilityYear.ToString()) < 0
											&& graphUnitSearch.InfosetID != graphUnit.InfosetID)
										{
											//a graph unit has been found that has the same name, but different InfosetID
											sameGraphUnitFound = true;
											sameGraphFacilityYear[pos2] += graphUnit.FacilityYear.ToString() + ";";

											break;
										}
									}
								}						
							}
							else if (graphUnit[0] is WAM.Data.TreatmentProcess)
							{
								for (int pos2 = 0; pos2 <= pos; pos2++)
								{
									graphUnitSearch = (GraphUnit)m_graphUnits[pos2];

									//mam 050806 - add length check on sameGraphFacilityYear
									//if (graphUnitSearch.GraphID != null && graphUnitSearch.GraphID.Length > 0)
									if (graphUnitSearch.GraphID != null && graphUnitSearch.GraphID.Length > 0
										&& sameGraphFacilityYear[pos2].Length > 0)
									{
										if (graphUnitSearch.ShortName.Equals(graphUnit.ShortName) 
											&& graphUnitSearch.FacilityID != graphUnit.FacilityID
											&& graphUnitSearch.FacilityYear != graphUnit.FacilityYear
											&& sameGraphFacilityYear[pos2].IndexOf(graphUnit.FacilityYear.ToString()) < 0)
										{
											//a graph unit has been found that has the same name, but different FacilityID
											sameGraphUnitFound = true;
											sameGraphFacilityYear[pos2] += graphUnit.FacilityYear.ToString() + ";";
											break;
										}
									}
								}						
							}
							else
							{
								//check the parents of the item to graph to see if the parent names are the same (up to but not 
								//	including Facility - we expect that the Facility names will be different; if the parent names 
								//	are the same and the FacilityIDs are different, go ahead and put the items in the same series
								for (int pos2 = 0; pos2 <= pos; pos2++)
								{
									graphUnitSearch = (GraphUnit)m_graphUnits[pos2];

									//mam 050806 - add length check on sameGraphFacilityYear
									if (graphUnitSearch.GraphID != null && graphUnitSearch.GraphID.Length > 0
										&& sameGraphFacilityYear[pos2].Length > 0)
									{
										//mam 050806 - use inspection year rather than facility year for 
										//	major components and disciplines
										//if (graphUnitSearch.ShortName.Equals(graphUnit.ShortName) 
										//	&& graphUnitSearch.ParentName.Equals(graphUnit.ParentName)
										//	&& graphUnitSearch.FacilityID != graphUnit.FacilityID
										//	&& graphUnitSearch.FacilityYear != graphUnit.FacilityYear
										//	&& sameGraphFacilityYear[pos2].IndexOf(graphUnit.FacilityYear.ToString()) < 0)
										if (graphUnitSearch.ShortName.Equals(graphUnit.ShortName) 
											&& graphUnitSearch.ParentName.Equals(graphUnit.ParentName)
											&& graphUnitSearch.FacilityID != graphUnit.FacilityID
											&& graphUnitSearch.InspectionYear != graphUnit.InspectionYear
											&& sameGraphFacilityYear[pos2].IndexOf(graphUnit.InspectionYear.ToString()) < 0)
										{
											//a graph unit has been found that has the same name, same parent name, 
											//	but different FacilityID
											sameGraphUnitFound = true;
											//mam 050806 - use inspection year rather than facility year for 
											//	major components and disciplines
											//sameGraphFacilityYear[pos2] += graphUnit.FacilityYear.ToString() + ";";
											sameGraphFacilityYear[pos2] += graphUnit.InspectionYear.ToString() + ";";
											break;
										}
									}
								}
							}
						}
					
						//mam 050806 - use InspectionYear or leave as FacilityYear here? - left as FacilityYear
						if (sameGraphUnitFound)
						{
							//set the current graphUnit's graphID to be the same as the graph unit just found
							graphUnit.GraphID = graphUnitSearch.GraphID.ToString().Substring(0, graphIDLength) 
								+ graphUnit.FacilityYear.ToString().PadLeft(graphYearLength, '0');
						}
						else
						{
							//there is no matching graph unit, so assign a new GraphID
							sameGraphFacilityYear[pos] += graphUnit.FacilityYear.ToString() + ";";
							++newIDCounter;
							graphUnit.GraphID = newIDCounter.ToString().PadLeft(graphIDLength, '0') + graphUnit.FacilityYear.ToString().PadLeft(graphYearLength, '0');
						}
					}
				}
				//</mam>

				for (int pos = 0; pos < m_graphUnits.Count; pos++)
				{
					decimal valueLow = 0;

					graphUnit = (GraphUnit)m_graphUnits[pos];

					//mam 050806
					yearForLabel = graphUnit.InspectionYear.ToString();
					if (graphUnit[0] is Facility || graphUnit[0] is TreatmentProcess)
					{
						yearForLabel = graphUnit.FacilityYear.ToString();
					}

					//mam
					if (isY2)
					{
						//mam 090105

						//dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList.AddNewSeries();

						//go through each existing series to see if one of them has the same GraphID
						//if an existing series does have the same GraphID as the current graphUnit, 
						//	add the current graphUnit to the existing series; otherwise, add a new series
						//if the facility year is the same, add a new series, but use the same colors as the existing series
						//if the facility year is different, add to the existing series
						int i = 0;
						int seriesCount = chart.ChartGroups.Group1.ChartData.SeriesList.Count;
						int sameYearIndex = -1;
						int diffYearIndex = -1;
						bool seriesFound = false;
						for (i = 0; i < seriesCount; i++)
						{
							//check graphID; disregard facility year
							if (chart.ChartGroups.Group1.ChartData.SeriesList[i].Tag.ToString().Substring(0, graphIDLength) 
								== graphUnit.GraphID.ToString().Substring(0, graphIDLength))
							{
								seriesFound = true;

								//same year
								if (chart.ChartGroups.Group1.ChartData.SeriesList[i].Tag.ToString().Substring(graphIDLength, graphYearLength) 
									== graphUnit.GraphID.ToString().Substring(graphIDLength, graphYearLength))
								{
									sameYearIndex = i;
								}
									//different year
								else
								{
									diffYearIndex = i;
								}
								//break;
							}
						}
						//bool addDuplicateSeries = false;
						if (seriesFound)
						{
							//a series already exists with the same GraphID, so add the current graphUnit to the existing series

							if (sameYearIndex > -1)
							{
								dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList.AddNewSeries();
								dataSeries.Tag = graphUnit.GraphID.ToString();
								//dataSeries.LineStyle.Color = chart.ChartGroups.Group1.ChartData.SeriesList[sameYearIndex].LineStyle.Color;
								//dataSeries.SymbolStyle.Color = chart.ChartGroups.Group1.ChartData.SeriesList[i].SymbolStyle.Color;
								//dataSeries.SymbolStyle.Shape = chart.ChartGroups.Group1.ChartData.SeriesList[i].SymbolStyle.Shape;
							}
							else
							{
								dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList[diffYearIndex];

								addDuplicateSeries = true;
								//dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList.AddNewSeries();
								//dataSeries.Tag = graphUnit.GraphID.ToString();
							}
						}
						else
						{
							dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList.AddNewSeries();
							dataSeries.Tag = graphUnit.GraphID.ToString();
						}
						//</mam>

						if ((int)dataSeries.SymbolStyle.Shape == (int)SymbolShapeEnum.HorizontalLine 
							|| (int)dataSeries.SymbolStyle.Shape == (int)SymbolShapeEnum.VerticalLine)
						{
							SymbolShapeEnum[] shapeEnums = (SymbolShapeEnum[])Enum.GetValues(typeof(SymbolShapeEnum));
							dataSeries.SymbolStyle.Shape = shapeEnums[(int)dataSeries.SymbolStyle.Shape + 4];
						}
						if (m_yAxis2 != GraphYAxis.ConditionAndLOS)
						{
							if (Convert.ToBoolean(objGraphSettings.GetValue(1)))
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = graphUnit.NameWithInfoset;
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.NameWithInfoset + " (" + graphUnit.FacilityYear.ToString() + ")"; 
									dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.NameWithInfoset 
										+ " (" + yearForLabel + ") Y2"; 
								}
								else
								{
									dataSeries.Label = graphUnit.NameWithInfoset + " Y2";

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
							else
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = graphUnit.Name;
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.Name + " (" + graphUnit.FacilityYear.ToString() + ")";
									dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.Name 
										+ " (" + yearForLabel + ") Y2";
								}
								else
								{
									dataSeries.Label = graphUnit.Name + " Y2";

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ") Y2";
									}
								}
								//</mam>
							}
						}
						else
						{
							if (Convert.ToBoolean(objGraphSettings.GetValue(1)))
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis));
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis))
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis))
										+ " (" + yearForLabel + ") + Y2"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = string.Format("{0} {1}", graphUnit.NameWithInfoset + " Y2", EnumHandlers.GetGraphYAxisString(yAxis));

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ") + Y2";
									}
								}
								//</mam>
							}
							else
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis));
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis))
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis))
										+ " (" + yearForLabel + ") Y2"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = string.Format("{0} {1} Y2", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis));

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
						}
					}
					else
					{
						//</mam>

						//mam 090105

						//dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList.AddNewSeries();

						//go through each existing series to see if one of them has the same GraphID
						//if an existing series does have the same GraphID as the current graphUnit, 
						//	add the current graphUnit to the existing series; otherwise, add a new series
						//if the facility year is the same, add a new series, but use the same colors as the existing series
						//if the facility year is different, add to the existing series
						int i = 0;
						int seriesCount = chart.ChartGroups.Group0.ChartData.SeriesList.Count;
						int sameYearIndex = -1;
						int diffYearIndex = -1;
						bool seriesFound = false;
						for (i = 0; i < seriesCount; i++)
						{
							//check graphID; disregard facility year
							if (chart.ChartGroups.Group0.ChartData.SeriesList[i].Tag.ToString().Substring(0, graphIDLength) 
								== graphUnit.GraphID.ToString().Substring(0, graphIDLength))
							{
								seriesFound = true;

								//same year
								if (chart.ChartGroups.Group0.ChartData.SeriesList[i].Tag.ToString().Substring(graphIDLength, graphYearLength) 
									== graphUnit.GraphID.ToString().Substring(graphIDLength, graphYearLength))
								{
									sameYearIndex = i;
								}
									//different year
								else
								{
									diffYearIndex = i;
								}
								//break;
							}
						}
						if (seriesFound)
						{
							//a series already exists with the same GraphID, so add the current graphUnit to the existing series

							if (sameYearIndex > -1)
							{
								dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList.AddNewSeries();
								dataSeries.Tag = graphUnit.GraphID.ToString();
								//dataSeries.LineStyle.Color = chart.ChartGroups.Group0.ChartData.SeriesList[sameYearIndex].LineStyle.Color;
								//dataSeries.SymbolStyle.Color = chart.ChartGroups.Group0.ChartData.SeriesList[i].SymbolStyle.Color;
								//dataSeries.SymbolStyle.Shape = chart.ChartGroups.Group0.ChartData.SeriesList[i].SymbolStyle.Shape;
							}
							else
							{
								dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList[diffYearIndex];

								addDuplicateSeries = true;
								//dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList.AddNewSeries();
								//dataSeries.Tag = graphUnit.GraphID.ToString();
							}
						}
						else
						{
							dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList.AddNewSeries();
							dataSeries.Tag = graphUnit.GraphID.ToString();
						}
						//</mam>

						if ((int)dataSeries.SymbolStyle.Shape == (int)SymbolShapeEnum.HorizontalLine 
							|| (int)dataSeries.SymbolStyle.Shape == (int)SymbolShapeEnum.VerticalLine)
						{
							SymbolShapeEnum[] shapeEnums = (SymbolShapeEnum[])Enum.GetValues(typeof(SymbolShapeEnum));
							dataSeries.SymbolStyle.Shape = shapeEnums[(int)dataSeries.SymbolStyle.Shape - 4];
						}

						if (m_yAxis != GraphYAxis.ConditionAndLOS)
						{
							if (Convert.ToBoolean(objGraphSettings.GetValue(1)))
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = graphUnit.NameWithInfoset;
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.NameWithInfoset 
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.NameWithInfoset 
										+ " (" + yearForLabel + ")"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = graphUnit.NameWithInfoset;

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
							else
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = graphUnit.Name;
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.Name 
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + graphUnit.Name 
										+ " (" + yearForLabel + ")"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = graphUnit.Name;

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
						}
						else
						{
							if (Convert.ToBoolean(objGraphSettings.GetValue(1)))
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis));
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis))
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis))
										+ " (" + yearForLabel + ")"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = string.Format("{0} {1}", graphUnit.NameWithInfoset, EnumHandlers.GetGraphYAxisString(yAxis));

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
							else
							{
								//mam 090105 - commented this line:
								//dataSeries.Label = string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis));
								//</mam>

								//mam 090105 - modify series label to include graphUnits added to the series

								if (addDuplicateSeries)
								{
									addDuplicateSeries = false;

									//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
									//dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis))
									//	+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
									dataSeries.Label = dataSeries.Label + Environment.NewLine + string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis))
										+ " (" + graphUnit.FacilityYear.ToString() + ")"; //+ Environment.NewLine + dataSeries.Label;
								}
								else
								{
									dataSeries.Label = string.Format("{0} {1}", graphUnit.Name, EnumHandlers.GetGraphYAxisString(yAxis));

									if (multipleYears)
									{
										//mam 050806 - change from graphUnit.FacilityYear.ToString() to yearForLabel
										//dataSeries.Label += " (" + graphUnit.FacilityYear.ToString() + ")";
										dataSeries.Label += " (" + yearForLabel + ")";
									}
								}
								//</mam>
							}
						}
					}
				
					for (dataPos = 0; dataPos < graphUnit.Count; dataPos++)
					{
						//mam
						isNA = false;
						//</mam>

						unit = graphUnit[dataPos];

						//mam - need a way to get only pipes or only nodes for graphing
						if (unit is WAM.Data.DisciplinePipe)
							curValue = unit.GetYAxisValue(yAxis, true, false);
						else if (unit is WAM.Data.DisciplineNode)
							curValue = unit.GetYAxisValue(yAxis, false, true);
						else
						//</mam>

							curValue = unit.GetYAxisValue(yAxis);

						//mam - determine n/a for Component and MSL LOS
						if (yAxis == GraphYAxis.LOS )
						{
							if (curValue == 0)
								curValue = -1;
						}
						//</mam>

						//mam - determine n/a for pipes and nodes
						if (yAxis == GraphYAxis.Criticality || yAxis == GraphYAxis.Vulnerability || yAxis == GraphYAxis.Risk)
						{
							if (curValue == -1)
								isNA = true;
						}

						//mam - since the axis values on the graph are reversed for LOS and Condition, we have to "reverse"
						//	the LOS or Condition value so that it will appear in the proper place in the graph
						if (yAxis == GraphYAxis.LOS || yAxis == GraphYAxis.Condition || yAxis == GraphYAxis.ConditionAndLOS)
						{
							if (curValue == -1)
								isNA = true;
							else
								curValue = 5 - (curValue - 1);

							if (curValue == 6)
								curValue = 5;
						}
						//</mam>

						if (isY2)
						{
							if (chart.ChartArea.AxisY2.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
								curValue = WAMRounding.RoundNumber(curValue, roundDigit);
						}
						else
						{
							if (chart.ChartArea.AxisY.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
								curValue = WAMRounding.RoundNumber(curValue, roundDigit);
						}

						//mam 090105 - moved this line up
						//curYear = unit.GetYearValue();
						//mam 050806 - get inspection year if discipline (GetInspectionYear returns FacilityYear for other types)
						curYear = unit.GetInspectionYear();

						dataSeries.X.Add(curYear);

						//mam - if value is n/a, don't graph it, because there is no place on the graph to show n/a values
						if (isNA)
							continue;
						//</mam>

						dataSeries.Y.Add(curValue);

						//mam
						if (pos == 0)
						{
							valueLow = curValue;
							valueYearLow = curYear;
							valueYearHigh = curYear;
						}

						if (curValue < valueLow)
							valueLow = curValue;

						if (curYear < valueYearLow)
							valueYearLow = curYear;

						if (curYear > valueYearHigh)
							valueYearHigh = curYear;
						//</mam>
					}

					if (isY2)
						valueLow2 = valueLow;
					else
						valueLow1 = valueLow;
				}

				//mam
				if (!isY2)
				{
					if (m_graphUnits.Count == 1  && valueLow1 > 999999999)
					{
						billionErrY1 = valueLow1;
					}
				}
				if (isY2 && m_graphUnits.Count == 1  && valueLow2 > 999999999)
				{
					billionErrY2 = valueLow2;
				}
				//</mam>
			}

			catch(Exception ex)
			{
				MessageBox.Show(ex.Message.ToString());
			}
		}

		//mam
		private void SetChartTitle(string yearTypeString)
		{
			if (showY2Axis)
				this.labelTitle.Text = string.Format("{0}  and  {1}  vs  " + yearTypeString, chart.ChartArea.AxisY.Text, chart.ChartArea.AxisY2.Text);
			else
				this.labelTitle.Text = string.Format("{0}  vs  " + yearTypeString, chart.ChartArea.AxisY.Text);

			//mam
			if (showY2Axis)
			{
				chart.ChartArea.AxisY2.Text = EnumHandlers.GetGraphYAxisString(m_yAxis2);
				chart.ChartArea.AxisY2.AnnoFormatString = EnumHandlers.GetGraphYAxisFormatString(m_yAxis2);
				chart.Header.Text = string.Format("{0}\n{1}  and  {2}  vs  " + yearTypeString, 
					unitType, chart.ChartArea.AxisY.Text, chart.ChartArea.AxisY2.Text);
				this.Text = string.Format("Graph: {0}: {1}  and  {2}  vs  " + yearTypeString, 
					unitType, chart.ChartArea.AxisY.Text, chart.ChartArea.AxisY2.Text);
			}
			else
				//</mam>
			{
				chart.Header.Text = string.Format("{0}\n{1}  vs  " + yearTypeString, 
					unitType, chart.ChartArea.AxisY.Text, chart.ChartArea.AxisY2.Text);
				this.Text = string.Format("Graph: {0}: {1}  vs  " + yearTypeString, 
					unitType, chart.ChartArea.AxisY.Text, chart.ChartArea.AxisY2.Text);
			}

			this.chart.ChartArea.AxisX.Text = yearTypeString;
		}
		//</mam>

		//mam
		private void AdjustAxisBounds()
		{
			//calling GetImage refreshes the max and min values of the axes to the proper values
			chart.GetImage();

			// adjust x axis
			if (valueYearLow < (int)(this.chart.ChartArea.AxisX.Min + (int)this.chart.ChartArea.AxisX.UnitMinor))
			{
				int minValue = (int)this.chart.ChartArea.AxisX.Min;
				minValue -= (int)this.chart.ChartArea.AxisX.UnitMajor;

				this.chart.ChartArea.AxisX.ScrollBar.Min = minValue;
				this.chart.ChartArea.AxisX.Min = minValue;
			}

			if (valueYearHigh == (int)(this.chart.ChartArea.AxisX.Max))
			{
				double maxValue = this.chart.ChartArea.AxisX.Max;
				maxValue += this.chart.ChartArea.AxisX.UnitMajor;
				this.chart.ChartArea.AxisX.ScrollBar.Max = maxValue;
				this.chart.ChartArea.AxisX.Max = maxValue;
			}

			axisMinX = (int)this.chart.ChartArea.AxisX.Min - 10;
			axisMaxX = (int)this.chart.ChartArea.AxisX.Max + 10;

			// adjust y axis
			if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				//chart.ChartArea.AxisY.Reversed = true;
				this.chart.ChartArea.AxisY.ScrollBar.Min = 1;
				this.chart.ChartArea.AxisY.ScrollBar.Max = 5;

				axisMinY1 = 1;
				axisMaxY1 = 5;
				chart.ChartArea.AxisY.SetMinMax(axisMinY1, axisMaxY1);
			}
			else
			{
				//the chart automatically uses a large negative value for the max if only one data point is graphed and
				//	that data point has a value > 1 billion
				if (billionErrY1 > 0)
				{
					this.chart.ChartArea.AxisY.Max = (double)billionErrY1 + 10;
					this.chart.ChartArea.AxisY.Min = (double)billionErrY1 - 10;
				}

				if (valueLow1 < (decimal)(this.chart.ChartArea.AxisY.Min + this.chart.ChartArea.AxisY.UnitMinor))
				{
					double minValue = this.chart.ChartArea.AxisY.Min;
					minValue -= this.chart.ChartArea.AxisY.UnitMajor;
					this.chart.ChartArea.AxisY.ScrollBar.Min = minValue;
					this.chart.ChartArea.AxisY.Min = minValue;
				}

				axisMinY1 = -chart.ChartArea.AxisY.UnitMajor;
				axisMaxY1 = this.chart.ChartArea.AxisY.Max * 2;
			}

			// adjust y2 axis
			if (showY2Axis)
			{
				if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
				{
					//chart.ChartArea.AxisY2.Reversed = true;
					this.chart.ChartArea.AxisY2.ScrollBar.Min = 1;
					this.chart.ChartArea.AxisY2.ScrollBar.Max = 5;

					axisMinY2 = 1;
					axisMaxY2 = 5;
					chart.ChartArea.AxisY2.SetMinMax(axisMinY2, axisMaxY2);
				}
				else
				{
					//the chart automatically uses a large negative value for the max if only one data point is graphed and
					//	that data point has a value > 1 billion
					if (billionErrY2 > 0)
					{
						this.chart.ChartArea.AxisY2.Max = (double)billionErrY2 + 10;
						this.chart.ChartArea.AxisY2.Min = (double)billionErrY2 - 10;
					}

					if (valueLow2 < (decimal)(this.chart.ChartArea.AxisY2.Min + this.chart.ChartArea.AxisY2.UnitMinor))
					{
						double minValue = this.chart.ChartArea.AxisY2.Min;
						minValue -= this.chart.ChartArea.AxisY2.UnitMajor;
						this.chart.ChartArea.AxisY2.ScrollBar.Min = minValue;
						this.chart.ChartArea.AxisY2.Min = minValue;
					}

					axisMinY2 = -chart.ChartArea.AxisY2.UnitMajor;
					axisMaxY2 = this.chart.ChartArea.AxisY2.Max * 2;
				}
			}

			//if (m_graphUnits.Count == 1)
			//{
			//	buttonConfigureGraph.Enabled = false;
			//}
		}
		//</mam>

		//mam
		private void SetBitmaps()
		{
			Bitmap b = (Bitmap)pictureBoxHelp.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxHelp.Image = b;
		}
		//</mam>

		//mam
		private void ResetGraphValues(bool resetAll)
		{
			if (axisCurrent == "X" || resetAll)
			{
				this.chart.ChartArea.AxisX.UnitMajor = axisUnitMajorXDefault;
				this.chart.ChartArea.AxisX.UnitMinor = axisUnitMinorXDefault;
				this.chart.ChartArea.AxisX.ScrollBar.Scale = 1;
				this.chart.ChartArea.AxisX.ScrollBar.Min = axisMinXDefault;
				this.chart.ChartArea.AxisX.ScrollBar.Max = axisMaxXDefault;
				this.chart.ChartArea.AxisX.SetMinMax(axisMinXDefault, axisMaxXDefault);
				unitChangeX = unitChangeXDefault;
			}

			if (axisCurrent == "Y1" || resetAll)
			{
				this.chart.ChartArea.AxisY.UnitMajor = axisUnitMajorY1Default;
				this.chart.ChartArea.AxisY.UnitMinor = axisUnitMinorY1Default;
				this.chart.ChartArea.AxisY.ScrollBar.Scale = 1;
				this.chart.ChartArea.AxisY.ScrollBar.Min = axisMinY1Default;
				this.chart.ChartArea.AxisY.ScrollBar.Max = axisMaxY1Default;
				this.chart.ChartArea.AxisY.SetMinMax(axisMinY1Default, axisMaxY1Default);
				unitChangeY1 = unitChangeY1Default;

				if (chart.ChartArea.AxisY.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
				{
					if (unitChangeY1 < 1)
						unitChangeY1 = 1;
				}
			}

			if (axisCurrent == "Y2" || resetAll)
			{
				this.chart.ChartArea.AxisY2.UnitMajor = axisUnitMajorY2Default;
				this.chart.ChartArea.AxisY2.UnitMinor = axisUnitMinorY2Default;
				this.chart.ChartArea.AxisY2.ScrollBar.Scale = 1;
				this.chart.ChartArea.AxisY2.ScrollBar.Min = axisMinY2Default;
				this.chart.ChartArea.AxisY2.ScrollBar.Max = axisMaxY2Default;
				this.chart.ChartArea.AxisY2.SetMinMax(axisMinY2Default, axisMaxY2Default);
				unitChangeY2 = unitChangeY2Default;

				if (showY2Axis && chart.ChartArea.AxisY2.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
				{
					if (unitChangeY2 < 1)
						unitChangeY2 = 1;
				}
			}

			RefreshDisplayValues(resetAll);
		}
		//</mam>

		//mam
		private void RefreshDisplayValues(bool resetAll)
		{
			string formatString = "";
			this.chart.Refresh();

			if (axisCurrent == "X" || resetAll)
			{
				labelAxisMax.Text = chart.ChartArea.AxisX.Max.ToString();
				labelAxisMin.Text = chart.ChartArea.AxisX.Min.ToString();
				labelAxisMax.Refresh();
				labelAxisMin.Refresh();
			}

			if (axisCurrent == "Y1" || resetAll)
			{
				formatString = chart.ChartArea.AxisY.AnnoFormatString;
				if (formatString == "D1" || formatString == "F2")
				{
					if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
					{
						int curMin = 5 - ((int)chart.ChartArea.AxisY.Max - 1);
						int curMax = 5 - ((int)chart.ChartArea.AxisY.Min - 1);

						labelAxisMax.Text = curMax.ToString();
						labelAxisMin.Text = curMin.ToString();
					}
					else
					{
						labelAxisMax.Text = chart.ChartArea.AxisY.Max.ToString();
						labelAxisMin.Text = chart.ChartArea.AxisY.Min.ToString();
					}
				}
				else
				{
					labelAxisMax.Text = chart.ChartArea.AxisY.Max.ToString(formatString);
					labelAxisMin.Text = chart.ChartArea.AxisY.Min.ToString(formatString);
				}
				labelAxisMax.Refresh();
				labelAxisMin.Refresh();
			}

			if (axisCurrent == "Y2" || resetAll)
			{
				formatString = chart.ChartArea.AxisY2.AnnoFormatString;
				if (formatString == "D1" || formatString == "F2")
				{
					if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
					{
						int curMin = 5 - ((int)chart.ChartArea.AxisY2.Max - 1);
						int curMax = 5 - ((int)chart.ChartArea.AxisY2.Min - 1);
						labelAxisMax.Text = curMax.ToString();
						labelAxisMin.Text = curMin.ToString();
					}
					else
					{
						labelAxisMax.Text = chart.ChartArea.AxisY2.Max.ToString();
						labelAxisMin.Text = chart.ChartArea.AxisY2.Min.ToString();
					}
				}
				else
				{
					labelAxisMax.Text = chart.ChartArea.AxisY2.Max.ToString(formatString);
					labelAxisMin.Text = chart.ChartArea.AxisY2.Min.ToString(formatString);
				}
				labelAxisMax.Refresh();
				labelAxisMin.Refresh();
			}
		}
		//</mam>

		//mam
		private void SetControls()
		{
			if ((radioButtonAxisY1.Checked && (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS))
				|| (radioButtonAxisY2.Checked && (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)))
			{
				//disable changing of min and max values for Condition and LOS
				EnableControls(true, false);
			}
			else
			{
				EnableControls(true, false);
			}
		}
		//</mam>

		//mam
		private void EnableControls(bool enableControl, bool includeAxes)
		{
			groupBoxMaxMin.Enabled = enableControl;
			buttonResetGraphValues.Enabled = enableControl;

			if (includeAxes)
			{
				groupBoxAxes.Enabled = enableControl;
			}
		}
		//</mam>

		//mam
		private void ShowZoom(bool showZoom)
		{
			try
			{
				this.chart.ChartArea.AxisX.ScrollBar.Visible = showZoom;
				this.chart.ChartArea.AxisY.ScrollBar.Visible = showZoom;
				if (showY2Axis)
					this.chart.ChartArea.AxisY2.ScrollBar.Visible = showZoom;

				//go through ridiculous machinations to make scrollbars show under certain circumstances
				//	(they don't show if the user has just used the Configure Graph button)
				if (showZoom)
				{
					this.chart.Refresh();
					this.chart.GetImage();
					this.chart.ChartArea.AxisY.ScrollBar.Visible = false;
					this.chart.ChartArea.AxisY.ScrollBar.Visible = true;

					if (showY2Axis)
					{
						this.chart.ChartArea.AxisY2.ScrollBar.Visible = false;
						this.chart.ChartArea.AxisY2.ScrollBar.Visible = true;
					}

					this.chart.Refresh();
					this.chart.GetImage();
				}

				if (showY2Axis)
					this.chart.ChartArea.AxisY2.ScrollBar.Visible = showZoom;

				if (chart.ChartArea.AxisX.ScrollBar.Visible)
				{
					EnableControls(false, true);
				}
				else
				{
					EnableControls(true, true);

					long newMin = (long)chart.ChartArea.AxisX.Min;
					long newMax = (long)chart.ChartArea.AxisX.Max;
					SetAxisValues(ref newMin, ref newMax, 
						(long)chart.ChartArea.AxisX.ScrollBar.Min, (long)chart.ChartArea.AxisX.ScrollBar.Max, (long)unitChangeX);
					chart.ChartArea.AxisX.SetMinMax(newMin, newMax);

					//sync the scrollbar max and min to the axis max and min
					if (chart.ChartArea.AxisY.AnnoFormatString == "D1" || chart.ChartArea.AxisY.AnnoFormatString == "F2")
					{
						double newMinY1 = (double)chart.ChartArea.AxisY.Min;
						double newMaxY1 = (double)chart.ChartArea.AxisY.Max;
						SetAxisValues(ref newMinY1, ref newMaxY1, 
							(double)chart.ChartArea.AxisY.ScrollBar.Min, (double)chart.ChartArea.AxisY.ScrollBar.Max, 
							(double)unitChangeY1);
						chart.ChartArea.AxisY.SetMinMax(newMinY1, newMaxY1);
					}
					else
					{
						newMin = (long)chart.ChartArea.AxisY.Min;
						newMax = (long)chart.ChartArea.AxisY.Max;
						SetAxisValues(ref newMin, ref newMax, 
							(long)chart.ChartArea.AxisY.ScrollBar.Min, (long)chart.ChartArea.AxisY.ScrollBar.Max, (long)unitChangeY1);
						chart.ChartArea.AxisY.SetMinMax(newMin, newMax);
					}

					if (showY2Axis)
					{
						if (chart.ChartArea.AxisY2.AnnoFormatString == "D1" || chart.ChartArea.AxisY2.AnnoFormatString == "F2")
						{
							double newMinY2 = (double)chart.ChartArea.AxisY2.Min;
							double newMaxY2 = (double)chart.ChartArea.AxisY2.Max;
							SetAxisValues(ref newMinY2, ref newMaxY2, 
								(double)chart.ChartArea.AxisY2.ScrollBar.Min, (double)chart.ChartArea.AxisY2.ScrollBar.Max, 
								(double)unitChangeY2);
							chart.ChartArea.AxisY2.SetMinMax(newMinY2, newMaxY2);
						}
						else
						{
							newMin = (long)chart.ChartArea.AxisY2.Min;
							newMax = (long)chart.ChartArea.AxisY2.Max;
							SetAxisValues(ref newMin, ref newMax, 
								(long)chart.ChartArea.AxisY2.ScrollBar.Min, (long)chart.ChartArea.AxisY2.ScrollBar.Max, (long)unitChangeY2);
							chart.ChartArea.AxisY2.SetMinMax(newMin, newMax);
						}
					}
					RefreshDisplayValues(false);
				}
			}
			catch(Exception	ex)
			{
				MessageBox.Show(ex.Message.ToString());
			}
		}
		//</mam>

		//mam
		private void SetAxisValues(ref long newMinAxis, ref long newMaxAxis, long newMinScroll, long newMaxScroll, long curUnitChange)
		{
			if (newMinScroll == newMinAxis && newMaxScroll != newMaxAxis && curUnitChange != 0)
			{
				//modify the max value
				if ((newMaxAxis - newMinAxis) % (long)curUnitChange != 0 || curUnitChange == 1)
				{
					double multiplier = ((newMaxAxis - newMinAxis) / (long)curUnitChange);
					multiplier = Math.Round(multiplier + 0.6, 0);
					newMaxAxis = newMinAxis + (long)curUnitChange * (long)multiplier;
				}
			}
			else if (newMaxScroll == newMaxAxis && newMinScroll != newMinAxis && curUnitChange != 0)
			{
				//modify the min value
				if ((long)(newMaxAxis - newMinAxis) % (long)curUnitChange != 0 || curUnitChange == 1)
				{
					double multiplier = ((newMaxAxis - newMinAxis) / (long)curUnitChange);
					multiplier = Math.Round(multiplier + 0.6, 0);
					newMinAxis = newMaxAxis - (long)curUnitChange * (long)multiplier;
				}
			}
			else if (newMaxScroll != newMaxAxis && newMinScroll != newMinAxis && curUnitChange != 0)
			{
				//modify both the max and the min values
				if (newMinAxis % (long)curUnitChange != 0 || curUnitChange == 1)
				{
					newMinAxis = (int)(newMinAxis / (long)curUnitChange) * (long)curUnitChange;
				}
				if (newMaxAxis % (long)curUnitChange != 0 || curUnitChange == 1)
				{
					newMaxAxis = (int)(newMaxAxis / (long)curUnitChange + 1) * (long)curUnitChange;
				}
			}
		}
		//</mam>

		//mam
		private void SetAxisValues(ref double newMinAxis, ref double newMaxAxis, double newMinScroll, double newMaxScroll, double curUnitChange)
		{
			if (newMinScroll == newMinAxis && newMaxScroll != newMaxAxis && curUnitChange != 0)
			{
				//modify the max value
				if ((newMaxAxis - newMinAxis) % curUnitChange != 0 || curUnitChange == 1)
				{
					double multiplier = ((newMaxAxis - newMinAxis) / curUnitChange);
					multiplier = Math.Round(multiplier + 0.6, 0);
					newMaxAxis = newMinAxis + curUnitChange * multiplier;
				}
			}
			else if (newMaxScroll == newMaxAxis && newMinScroll != newMinAxis && curUnitChange != 0)
			{
				//modify the min value
				if ((newMaxAxis - newMinAxis) % curUnitChange != 0 || curUnitChange == 1)
				{
					double multiplier = ((newMaxAxis - newMinAxis) / curUnitChange);
					multiplier = Math.Round(multiplier + 0.6, 0);
					newMinAxis = newMaxAxis - curUnitChange * multiplier;
				}
			}
			else if (newMaxScroll != newMaxAxis && newMinScroll != newMinAxis && curUnitChange != 0)
			{
				//modify both the max and the min values
				if (newMinAxis % curUnitChange != 0 || curUnitChange == 1)
				{
					newMinAxis = newMinAxis / curUnitChange * curUnitChange;
				}
				if (newMaxAxis % curUnitChange != 0 || curUnitChange == 1)
				{
					newMaxAxis = (newMaxAxis / curUnitChange + 1) * curUnitChange;
				}
			}
		}
		//</mam>

		//mam
		private void SyncAxes(bool syncDefaultValues)
		{
			//set the Y2 axis values equal to the Y axis values
			if (showY2Axis)
			{
				chart.ChartArea.AxisY2.ScrollBar.Min = chart.ChartArea.AxisY.ScrollBar.Min;
				chart.ChartArea.AxisY2.ScrollBar.Max = chart.ChartArea.AxisY.ScrollBar.Max;

				chart.ChartArea.AxisY2.UnitMinor = chart.ChartArea.AxisY.UnitMinor;
				chart.ChartArea.AxisY2.UnitMajor = chart.ChartArea.AxisY.UnitMajor;
				chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY.Min, chart.ChartArea.AxisY.Max);

				if (syncDefaultValues)
				{
					axisMinY2Default = axisMinY1Default;
					axisMaxY2Default = axisMaxY1Default;
					axisUnitMajorY2Default = axisUnitMajorY1Default;
					axisUnitMinorY2Default = axisUnitMinorY1Default;
				}
			}

			RefreshDisplayValues(false);
		}
		//</mam>

		private void chart_ChartChanged(object sender, System.EventArgs e)
		{
			if (!m_initialized || !chart.ChartArea.AxisX.ScrollBar.Visible)
				return;
			
			return;

			//not using this code

//			//when the scrollbar scale is changed, the axis max gets set to a different value,
//			//	so it must be returned to its correct value
//
//			if (chart.ChartArea.AxisX.ScrollBar.Scale != axisScrollBarScaleX)
//			{
//				//chart.ChartArea.AxisX.SetMinMax(chart.ChartArea.AxisX.ScrollBar.Min, chart.ChartArea.AxisX.ScrollBar.Max);
//				axisScrollBarScaleX = chart.ChartArea.AxisX.ScrollBar.Scale;
//				RefreshDisplayValues(false);
//			}
//
//			if (chart.ChartArea.AxisY.ScrollBar.Scale != axisScrollBarScaleY1)
//			{
//				//chart.ChartArea.AxisY.SetMinMax(chart.ChartArea.AxisY.ScrollBar.Min, chart.ChartArea.AxisY.ScrollBar.Max);
//				axisScrollBarScaleY1 = chart.ChartArea.AxisY.ScrollBar.Scale;
//				RefreshDisplayValues(false);
//			}
//
//			if (chart.ChartArea.AxisY2.ScrollBar.Scale != axisScrollBarScaleY2)
//			{
//				//chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY2.ScrollBar.Min, chart.ChartArea.AxisY2.ScrollBar.Max);
//				axisScrollBarScaleY2 = chart.ChartArea.AxisY2.ScrollBar.Scale;
//				RefreshDisplayValues(false);
//			}
		}

		private void SaveChartProperties()
		{
			this.chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
			this.chart.ChartGroups.Group1.ChartData.SeriesList.Clear();

			chartPropString = this.chart.SaveChartToString(true);
			objGraphSettings.SetValue(chartPropString, 0);
		}

		private void RestoreChartProperties()
		{
			int seriesListCount = chart.ChartGroups.Group0.ChartData.SeriesList.Count;
			int seriesListCountY2 = chart.ChartGroups.Group1.ChartData.SeriesList.Count;

			//save various chart properties that get overwritten by LoadChartFromString
			string chartHeader = this.chart.Header.Text;
			string axisTextX = this.chart.ChartArea.AxisX.Text;
			string formatStringX = this.chart.ChartArea.AxisX.AnnoFormatString;
			double gridMajorSpacingX = this.chart.ChartArea.AxisX.GridMajor.Spacing;
			double gridMinorSpacingX = this.chart.ChartArea.AxisX.GridMinor.Spacing;
			string axisTextY1 = this.chart.ChartArea.AxisY.Text;
			string formatStringY1 = this.chart.ChartArea.AxisY.AnnoFormatString;
			double gridMajorSpacingY1 = this.chart.ChartArea.AxisY.GridMajor.Spacing;
			double gridMinorSpacingY1 = this.chart.ChartArea.AxisY.GridMinor.Spacing;
			string axisTextY2 = this.chart.ChartArea.AxisY2.Text;
			string formatStringY2 = this.chart.ChartArea.AxisY2.AnnoFormatString;
			double gridMajorSpacingY2 = this.chart.ChartArea.AxisY2.GridMajor.Spacing;
			double gridMinorSpacingY2 = this.chart.ChartArea.AxisY2.GridMinor.Spacing;


			double curAxisMaxX = this.chart.ChartArea.AxisX.Max;
			double curAxisMinX = this.chart.ChartArea.AxisX.Min;
			double curAxisUnitMajorX = this.chart.ChartArea.AxisX.UnitMajor;
			double curAxisUnitMinorX = this.chart.ChartArea.AxisX.UnitMinor;
			double curAxisOriginX = this.chart.ChartArea.AxisX.Origin;

			double curAxisMaxY1 = this.chart.ChartArea.AxisY.Max;
			double curAxisMinY1 = this.chart.ChartArea.AxisY.Min;
			double curAxisUnitMajorY1 = this.chart.ChartArea.AxisY.UnitMajor;
			double curAxisUnitMinorY1 = this.chart.ChartArea.AxisY.UnitMinor;
			double curAxisOriginY1 = this.chart.ChartArea.AxisY.Origin;

			double curAxisMaxY2 = this.chart.ChartArea.AxisY2.Max;
			double curAxisMinY2 = this.chart.ChartArea.AxisY2.Min;
			double curAxisUnitMajorY2 = this.chart.ChartArea.AxisY2.UnitMajor;
			double curAxisUnitMinorY2 = this.chart.ChartArea.AxisY2.UnitMinor;
			double curAxisOriginY2 = this.chart.ChartArea.AxisY2.Origin;

			C1.Win.C1Chart.AnnotationMethodEnum[] annoEnums = (AnnotationMethodEnum[])Enum.GetValues(typeof(AnnotationMethodEnum));
			int curAxisAnnoMethodY1 = (int)chart.ChartArea.AxisY.AnnoMethod;
			int curAxisAnnoMethodY2 = (int)chart.ChartArea.AxisY2.AnnoMethod;

			C1.Win.C1Chart.FormatEnum[] formatEnums = (FormatEnum[])Enum.GetValues(typeof(FormatEnum));
			int curAxisAnnoFormatY1 = (int)chart.ChartArea.AxisY.AnnoFormat;
			int curAxisAnnoFormatY2 = (int)chart.ChartArea.AxisY2.AnnoFormat;

			string curAxisFormatStringY1 = chart.ChartArea.AxisY.AnnoFormatString;
			string curAxisFormatStringY2 = chart.ChartArea.AxisY2.AnnoFormatString;

			//load the chart properties (and whatever chart data was saved with the properties, 
			//	although it probably isn't the correct data)
			if (chartPropString.Length > 0)
				this.chart.LoadChartFromString(chartPropString);

			//replace the loaded chart data with the correct data
			this.chart.ChartGroups.Group0.ChartData.SeriesList.Clear();
			this.chart.ChartGroups.Group1.ChartData.SeriesList.Clear();

			for (int i = 0; i < seriesListCount; i++)
			{
				ChartDataSeries dataSeries = chart.ChartGroups.Group0.ChartData.SeriesList.AddNewSeries();
				dataSeries.X.CopyDataIn(((ChartDataSeries)dataPointArrayListGroup0[i]).X.CopyDataOut());
				dataSeries.Y.CopyDataIn(((ChartDataSeries)dataPointArrayListGroup0[i]).Y.CopyDataOut());
				dataSeries.SymbolStyle.Color = ((ChartDataSeries)dataPointArrayListGroup0[i]).SymbolStyle.Color;
				dataSeries.SymbolStyle.Shape = ((ChartDataSeries)dataPointArrayListGroup0[i]).SymbolStyle.Shape;
				dataSeries.LineStyle.Color = ((ChartDataSeries)dataPointArrayListGroup0[i]).LineStyle.Color;
				dataSeries.Label = ((ChartDataSeries)dataPointArrayListGroup0[i]).Label;
			}
			for (int i = 0; i < seriesListCountY2; i++)
			{
				ChartDataSeries dataSeries = chart.ChartGroups.Group1.ChartData.SeriesList.AddNewSeries();
				dataSeries.X.CopyDataIn(((ChartDataSeries)dataPointArrayListGroup1[i]).X.CopyDataOut());
				dataSeries.Y.CopyDataIn(((ChartDataSeries)dataPointArrayListGroup1[i]).Y.CopyDataOut());
				dataSeries.SymbolStyle.Color = ((ChartDataSeries)dataPointArrayListGroup1[i]).SymbolStyle.Color;
				dataSeries.SymbolStyle.Shape = ((ChartDataSeries)dataPointArrayListGroup1[i]).SymbolStyle.Shape;
				dataSeries.LineStyle.Color = ((ChartDataSeries)dataPointArrayListGroup1[i]).LineStyle.Color;
				dataSeries.Label = ((ChartDataSeries)dataPointArrayListGroup1[i]).Label;
			}

			ResetGraphValues(true);
			RefreshDisplayValues(false);

			//restore various chart properties that were overwritten by LoadChartFromString
			this.chart.Header.Text = chartHeader;
			this.chart.ChartArea.AxisX.Text = axisTextX;
			this.chart.ChartArea.AxisX.AnnoFormatString = formatStringX;
			this.chart.ChartArea.AxisX.GridMajor.Spacing = gridMajorSpacingX;
			this.chart.ChartArea.AxisX.GridMinor.Spacing = gridMinorSpacingX;
			this.chart.ChartArea.AxisY.Text = axisTextY1;
			this.chart.ChartArea.AxisY.AnnoFormatString = formatStringY1;
			this.chart.ChartArea.AxisY.GridMajor.Spacing = gridMajorSpacingY1;
			this.chart.ChartArea.AxisY.GridMinor.Spacing = gridMinorSpacingY1;
			this.chart.ChartArea.AxisY2.Text = axisTextY2;
			this.chart.ChartArea.AxisY2.AnnoFormatString = formatStringY2;
			this.chart.ChartArea.AxisY2.GridMajor.Spacing = gridMajorSpacingY2;
			this.chart.ChartArea.AxisY2.GridMinor.Spacing = gridMinorSpacingY2;
			
			
			this.chart.ChartArea.AxisX.SetMinMax(curAxisMinX, curAxisMaxX);
			this.chart.ChartArea.AxisX.UnitMajor = curAxisUnitMajorX;
			this.chart.ChartArea.AxisX.UnitMinor = curAxisUnitMinorX;
			this.chart.ChartArea.AxisX.Origin = curAxisOriginX;

			this.chart.ChartArea.AxisY.SetMinMax(curAxisMinY1, curAxisMaxY1);
			this.chart.ChartArea.AxisY.UnitMajor = curAxisUnitMajorY1;
			this.chart.ChartArea.AxisY.UnitMinor = curAxisUnitMinorY1;
			this.chart.ChartArea.AxisY.Origin = curAxisOriginY1;

			this.chart.ChartArea.AxisY2.SetMinMax(curAxisMinY2, curAxisMaxY2);
			this.chart.ChartArea.AxisY2.UnitMajor = curAxisUnitMajorY2;
			this.chart.ChartArea.AxisY2.UnitMinor = curAxisUnitMinorY2;
			this.chart.ChartArea.AxisY2.Origin = curAxisOriginY2;

			chart.ChartArea.AxisY.AnnoMethod = annoEnums[curAxisAnnoMethodY1];
			chart.ChartArea.AxisY2.AnnoMethod = annoEnums[curAxisAnnoMethodY2];
			chart.ChartArea.AxisY.AnnoFormat = formatEnums[curAxisAnnoFormatY1];
			chart.ChartArea.AxisY2.AnnoFormat = formatEnums[curAxisAnnoFormatY2];
			chart.ChartArea.AxisY.AnnoFormatString = curAxisFormatStringY1;
			chart.ChartArea.AxisY2.AnnoFormatString = curAxisFormatStringY2;

			//if there are more than 20 data points, the legend will take up too much space, so hide it
			if (m_graphUnits.Count > 20 || (showY2Axis && m_graphUnits.Count > 10))
			{
				this.chart.Legend.Visible = false;
				SetLegendButtonText();
			}

			//this.chart.Refresh();
			//this.chart.GetImage();
		}

		private void PopulateDataArray()
		{
			dataPointArrayListGroup0.Clear();
			for (int i = 0; i < chart.ChartGroups.Group0.ChartData.SeriesList.Count; i++)
			{
				dataPointArrayListGroup0.Add(chart.ChartGroups.Group0.ChartData.SeriesList[i]);
			}
			if (showY2Axis)
			{
				dataPointArrayListGroup1.Clear();
				for (int i = 0; i < chart.ChartGroups.Group1.ChartData.SeriesList.Count; i++)
				{
					dataPointArrayListGroup1.Add(chart.ChartGroups.Group1.ChartData.SeriesList[i]);
				}
			}
		}

		private void ShowLegendPopup()
		{
			try
			{
				formLegend.Close();
			}
			catch
			{
			}

			formLegend = new GraphViewerForm();

			chartPropString = this.chart.SaveChartToString(true);
			objGraphSettings.SetValue(chartPropString, 0);
			formLegend.ShowInTaskbar = false;

			formLegend.isFormLegend = true;
			formLegend.WindowState = System.Windows.Forms.FormWindowState.Normal;
			//formLegend.FormBorderStyle = FormBorderStyle.SizableToolWindow;
			formLegend.MaximizeBox = true;
			formLegend.MinimizeBox = false;
			formLegend.labelStatus.Visible = false;
			formLegend.labelStatus.Text = "";
			
			formLegend.SetValues(this.m_graphUnits, this.m_yAxis, this.m_yAxis2, this.showY2Axis, this.unitType, this, this, ref objGraphSettings);
			formLegend.chart.Size = new Size(390, 110);
			formLegend.chart.Location = new Point(4, 2);

			formLegend.WindowState = System.Windows.Forms.FormWindowState.Normal;
			formLegend.MinimumSize = new Size(400, 200);
			formLegend.Size = new Size(400, 200);

			//set legend properties
			formLegend.chart.Legend.Compass = CompassEnum.South;
			//formLegend.chart.Legend.Orientation = LegendOrientationEnum.Horizontal;
			//formLegend.chart.Legend.Orientation = LegendOrientationEnum.HorizontalVariableItemWidth;
			//formLegend.chart.Legend.Orientation = LegendOrientationEnum.VerticalVariableItemHeight;
			formLegend.chart.Legend.Orientation = LegendOrientationEnum.Auto;
			formLegend.chart.Legend.Style.Autowrap = false;
			formLegend.chart.Legend.Style.ForeColor = Color.Black;
			formLegend.chart.Legend.Style.BackColor = Color.White;
			formLegend.chart.Legend.Style.GradientStyle = GradientStyleEnum.None;
			formLegend.chart.Legend.Style.HatchStyle = HatchStyleEnum.None;
			formLegend.chart.Legend.Style.HorizontalAlignment = AlignHorzEnum.Center;
			formLegend.chart.Legend.Style.VerticalAlignment = AlignVertEnum.Top;
			formLegend.chart.Legend.Style.Opaque = true;
			formLegend.chart.Legend.Style.Rotation = RotationEnum.Rotate0;
			formLegend.chart.Legend.Style.Border.BorderStyle = BorderStyleEnum.Solid;
			formLegend.chart.Legend.Style.Border.Color = Color.Black;
			formLegend.chart.Legend.Style.Border.Thickness = 1;
			formLegend.chart.Legend.Location = new Point(0, 0);
			formLegend.chart.Legend.Visible = true;

			formLegend.labelStatus.Visible = false;
			formLegend.labelTitle.Visible = false;
			formLegend.pictureBoxHelp.Visible = false;
			formLegend.chart.ChartArea.Visible = false;
			formLegend.chart.ChartArea.AxisX.Visible = false;
			formLegend.chart.ChartArea.AxisY.Visible = false;
			formLegend.chart.ChartArea.AxisY2.Visible = false;
			formLegend.chart.Header.Visible = false;
			formLegend.groupBoxMaxMin.Visible = false;
			formLegend.groupBoxAxes.Visible = false;
			formLegend.buttonResetGraphValues.Visible = false;
			formLegend.groupBox1.Visible = false;
			formLegend.groupBox2.Visible = false;
			formLegend.buttonConfigureGraph.Visible = false;

			//need to reset the size here or it doesn't "take"
			formLegend.chart.Size = new Size(390, 110);
		}

		private void SetLegendButtonText()
		{
			if (this.chart.Legend.Visible)
				buttonShowHideLegend.Text = "Hide Legend";
			else
				buttonShowHideLegend.Text = "Show Legend";
		}

		#endregion /***** Methods *****/

		#region /***** Click Events *****/

		private void buttonConfigureGraph_Click(object sender, System.EventArgs e)
		{
			bool isZoom = chart.ChartArea.AxisX.ScrollBar.Visible;
			ShowZoom(false);
			try
			{
				chart.ShowProperties();
			}
			catch
			{
				//MessageBox.Show("Chart error");
			}

			//don't allow Cond or LOS axes to be reversed (because the bars don't reverse)
			bool showMessage = false;
			if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
			{
				if (chart.ChartArea.AxisY.Reversed == true)
				{
					chart.ChartArea.AxisY.Reversed = false;
					showMessage = true;
				}
			}
			if (showY2Axis && (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
			{
				if (chart.ChartArea.AxisY2.Reversed == true)
				{
					chart.ChartArea.AxisY2.Reversed = false;
					showMessage = true;
				}
			}
			if (showMessage == true)
			{
				showMessage = false;
				MessageBox.Show("You have set the Reversed property to true.  Condition and Level of Service axes cannot be reversed.", "Graph", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
			}

			//sync labels with potential new axis values after configuring the graph
			CheckAxisMaxMinDifference(false);
			RefreshDisplayValues(false);

			ShowZoom(isZoom);
			SetLegendButtonText();
			//chart.Refresh();
			//chart.GetImage();
		}

		private void buttonSaveImage_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog	sfd = new SaveFileDialog();

			sfd.AddExtension = true;
			sfd.CheckPathExists = true;
			sfd.OverwritePrompt = true;
			sfd.Filter = "JPEG Image File (*.jpg)|*.jpg|GIF Image File (*.gif)|*.gif|Windows Bitmap (*.bmp)|*.bmp";

			if (sfd.ShowDialog(this) == DialogResult.OK)
			{
				System.Drawing.Imaging.ImageFormat format = 
					System.Drawing.Imaging.ImageFormat.Jpeg;

				switch (sfd.FilterIndex)
				{
					case 0:
						break;
					case 1:
						format = System.Drawing.Imaging.ImageFormat.Gif;
						break;
					case 2:
						format = System.Drawing.Imaging.ImageFormat.Bmp;
						break;
					default:
						break;
				}

				Size size = new Size(chart.Width, chart.Height);

				chart.SaveImage(sfd.FileName, format, size);
			}
		}

		private void buttonPrint_Click(object sender, System.EventArgs e)
		{
			chart.PrintChart(PrintScaleEnum.ScaleToFit);
		}

		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void GraphViewerForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void GraphViewerForm_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)27)
			{
				this.Close();
			}
		}

		private void hScrollBarAxisMin_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			long newValue2 = 0;
			double newValue3 = 0;

			switch (axisCurrent)
			{
				case "X":
				{
					if (e.NewValue > hScrollBarAxisMin.Value)
					{
						//scroll up
						newValue2 = (long)chart.ChartArea.AxisX.Min + (long)unitChangeX;
						if (newValue2 <= axisMaxX)
						{
							if (newValue2 < (long)chart.ChartArea.AxisX.Max)
							{
								chart.ChartArea.AxisX.ScrollBar.Min = newValue2;
								chart.ChartArea.AxisX.Min = newValue2;
							}
						}
					}
					else if (e.NewValue < hScrollBarAxisMin.Value)
					{
						//scroll down
						newValue2 = (long)chart.ChartArea.AxisX.Min - (long)unitChangeX;
						if (newValue2 >= axisMinX)
						{
							chart.ChartArea.AxisX.ScrollBar.Min = newValue2;
							chart.ChartArea.AxisX.Min = newValue2;
						}
					}
					else
					{
						return;
					}

					this.chart.Refresh();
					RefreshDisplayValues(false);

					break;
				}

				case "Y1":
				{
					if (e.NewValue > hScrollBarAxisMin.Value)
					{
						//scroll up
						if (chart.ChartArea.AxisY.AnnoFormatString == "D1" || chart.ChartArea.AxisY.AnnoFormatString == "F2")
						{
							//newValue3 = chart.ChartArea.AxisY.Min + unitChangeY1;
							if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY.Max - 1) + unitChangeY1;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY.Min + unitChangeY1;
							}

							//here
							if (newValue3 <= axisMaxY1)
							{
								if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
								{
									if (newValue3 < 5 - ((int)chart.ChartArea.AxisY.Min - 1))
									{
										newValue3 = 5 - (newValue3 - 1);
										chart.ChartArea.AxisY.ScrollBar.Max = newValue3;
										chart.ChartArea.AxisY.Max = newValue3;
									}
								}
								else
								{
									if (newValue3 < chart.ChartArea.AxisY.Max)
									{
										chart.ChartArea.AxisY.ScrollBar.Min = newValue3;
										chart.ChartArea.AxisY.Min = newValue3;
									}
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY.Min + (long)unitChangeY1;
							if (newValue2 <= axisMaxY1)
							{
								if (newValue2 < (long)chart.ChartArea.AxisY.Max)
								{
									chart.ChartArea.AxisY.ScrollBar.Min = newValue2;
									chart.ChartArea.AxisY.Min = newValue2;
								}
							}
						}
					}
					else if (e.NewValue < hScrollBarAxisMin.Value)
					{
						//scroll down
						if (chart.ChartArea.AxisY.AnnoFormatString == "D1" || chart.ChartArea.AxisY.AnnoFormatString == "F2")
						{
							//newValue3 = chart.ChartArea.AxisY.Min - unitChangeY1;
							if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY.Max - 1) - unitChangeY1;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY.Min - unitChangeY1;
							}

							if (newValue3 >= axisMinY1)
							{
								if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
								{
									newValue3 = 5 - (newValue3 - 1);
									chart.ChartArea.AxisY.ScrollBar.Max = newValue3;
									chart.ChartArea.AxisY.Max = newValue3;
								}
								else
								{
									chart.ChartArea.AxisY.ScrollBar.Min = newValue3;
									chart.ChartArea.AxisY.Min = newValue3;
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY.Min - (long)unitChangeY1;
							if (newValue2 >= axisMinY1)
							{
								chart.ChartArea.AxisY.ScrollBar.Min = newValue2;
								chart.ChartArea.AxisY.Min = newValue2;
							}
						}
					}
					else
					{
						return;
					}

					this.chart.Refresh();
					RefreshDisplayValues(false);

					break;
				}

				case "Y2":
				{
					if (e.NewValue > hScrollBarAxisMin.Value)
					{
						//scroll up
						if (chart.ChartArea.AxisY2.AnnoFormatString == "D1" || chart.ChartArea.AxisY2.AnnoFormatString == "F2")
						{
							//newValue3 = chart.ChartArea.AxisY2.Min + unitChangeY2;
							if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY2.Max - 1) + unitChangeY2;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY2.Min + unitChangeY2;
							}

							if (newValue3 <= axisMaxY2)
							{
								if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
								{
									if (newValue3 < 5 - ((int)chart.ChartArea.AxisY2.Min - 1))
									{
										newValue3 = 5 - (newValue3 - 1);
										chart.ChartArea.AxisY2.ScrollBar.Max = newValue3;
										chart.ChartArea.AxisY2.Max = newValue3;
									}
								}
								else
								{
									if (newValue3 < chart.ChartArea.AxisY2.Max)
									{
										chart.ChartArea.AxisY2.ScrollBar.Min = newValue3;
										chart.ChartArea.AxisY2.Min = newValue3;
									}
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY2.Min + (long)unitChangeY2;
							if (newValue2 <= axisMaxY2)
							{
								if (newValue2 < (long)chart.ChartArea.AxisY2.Max)
								{
									chart.ChartArea.AxisY2.ScrollBar.Min = newValue2;
									chart.ChartArea.AxisY2.Min = newValue2;
								}
							}
						}
					}
					else if (e.NewValue < hScrollBarAxisMin.Value)
					{
						//scroll down
						if (chart.ChartArea.AxisY2.AnnoFormatString == "D1" || chart.ChartArea.AxisY2.AnnoFormatString == "F2")
						{
							//newValue3 = chart.ChartArea.AxisY2.Min - unitChangeY2;
							if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY2.Max - 1) - unitChangeY2;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY2.Min - unitChangeY2;
							}

							if (newValue3 >= axisMinY2)
							{
								if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
								{
									newValue3 = 5 - (newValue3 - 1);
									chart.ChartArea.AxisY2.ScrollBar.Max = newValue3;
									chart.ChartArea.AxisY2.Max = newValue3;
								}
								else
								{
									chart.ChartArea.AxisY2.ScrollBar.Min = newValue3;
									chart.ChartArea.AxisY2.Min = newValue3;
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY2.Min - (long)unitChangeY2;
							if (newValue2 >= axisMinY2)
							{
								chart.ChartArea.AxisY2.ScrollBar.Min = newValue2;
								chart.ChartArea.AxisY2.Min = newValue2;
							}
						}
					}
					else
					{
						return;
					}

					this.chart.Refresh();
					RefreshDisplayValues(false);

					break;
				}
			}
		}

		private void hScrollBarAxisMax_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			long newValue2 = 0;
			double newValue3 = 0;

			switch (axisCurrent)
			{
				case "X":
				{
					if (e.NewValue > hScrollBarAxisMax.Value)
					{
						//scroll up
						newValue2 = (long)chart.ChartArea.AxisX.Max + (long)unitChangeX;
						if (newValue2 <= axisMaxX)
						{
							chart.ChartArea.AxisX.ScrollBar.Max = newValue2;
							chart.ChartArea.AxisX.SetMinMax(chart.ChartArea.AxisX.Min, newValue2);
						}
					}
					else if (e.NewValue < hScrollBarAxisMax.Value)
					{
						//scroll down
						newValue2 = (long)chart.ChartArea.AxisX.Max - (long)unitChangeX;
						if (newValue2 >= axisMinX)
						{
							if (newValue2 > (long)chart.ChartArea.AxisX.Min)
							{
								chart.ChartArea.AxisX.ScrollBar.Max = newValue2;
								chart.ChartArea.AxisX.SetMinMax(chart.ChartArea.AxisX.Min, newValue2);
							}
						}
					}
					else
					{
						return;
					}

					this.chart.Refresh();
					RefreshDisplayValues(false);

					break;
				}

				case "Y1":
				{
					if (e.NewValue > hScrollBarAxisMax.Value)
					{
						//scroll up
						if (chart.ChartArea.AxisY.AnnoFormatString == "D1" || chart.ChartArea.AxisY.AnnoFormatString == "F2")
						{
							if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY.Min - 1) + unitChangeY1;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY.Max + unitChangeY1;
							}

							if (newValue3 <= axisMaxY1)
							{
								if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
								{
									newValue3 = 5 - (newValue3 - 1);
									chart.ChartArea.AxisY.ScrollBar.Min = newValue3;
									chart.ChartArea.AxisY.SetMinMax(newValue3, chart.ChartArea.AxisY.Max);
								}
								else
								{
									chart.ChartArea.AxisY.ScrollBar.Max = newValue3;
									chart.ChartArea.AxisY.SetMinMax(chart.ChartArea.AxisY.Min, newValue3);
								}
							}
						}
						else
						{

							newValue2 = (long)chart.ChartArea.AxisY.Max + (long)unitChangeY1;
							if (newValue2 <= axisMaxY1)
							{
								chart.ChartArea.AxisY.ScrollBar.Max = newValue2;
								chart.ChartArea.AxisY.SetMinMax(chart.ChartArea.AxisY.Min, newValue2);
							}
						}
					}
					else if (e.NewValue < hScrollBarAxisMax.Value)
					{
						//scroll down
						if (chart.ChartArea.AxisY.AnnoFormatString == "D1" || chart.ChartArea.AxisY.AnnoFormatString == "F2")
						{
							if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY.Min - 1) - unitChangeY1;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY.Max - unitChangeY1;
							}

							if (newValue3 >= axisMinY1)
							{
								if (m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS)
								{
									if (newValue3 > 5 - ((int)chart.ChartArea.AxisY.Max - 1))
									{
										newValue3 = 5 - (newValue3 - 1);
										chart.ChartArea.AxisY.ScrollBar.Min = newValue3;
										chart.ChartArea.AxisY.SetMinMax(newValue3, chart.ChartArea.AxisY.Max);
									}
								}
								else
								{
									if (newValue3 > chart.ChartArea.AxisY.Min)
									{
										chart.ChartArea.AxisY.ScrollBar.Max = newValue3;
										chart.ChartArea.AxisY.SetMinMax(chart.ChartArea.AxisY.Min, newValue3);
									}
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY.Max - (long)unitChangeY1;
							if (newValue2 >= axisMinY1)
							{
								if (newValue2 > (long)chart.ChartArea.AxisY.Min)
								{
									chart.ChartArea.AxisY.ScrollBar.Max = newValue2;
									chart.ChartArea.AxisY.SetMinMax(chart.ChartArea.AxisY.Min, newValue2);
								}
							}
						}
					}
					else
					{
						return;
					}
					
					this.chart.Refresh();
					RefreshDisplayValues(false);
					
					break;
				}

				case "Y2":
				{
					if (e.NewValue > hScrollBarAxisMax.Value)
					{
						//scroll up
						if (chart.ChartArea.AxisY2.AnnoFormatString == "D1" || chart.ChartArea.AxisY2.AnnoFormatString == "F2")
						{
							if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY2.Min - 1) + unitChangeY2;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY2.Max + unitChangeY2;
							}

							if (newValue3 <= axisMaxY2)
							{
								if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
								{
									newValue3 = 5 - (newValue3 - 1);
									chart.ChartArea.AxisY2.ScrollBar.Min = newValue3;
									chart.ChartArea.AxisY2.SetMinMax(newValue3, chart.ChartArea.AxisY2.Max);
								}
								else
								{
									chart.ChartArea.AxisY2.ScrollBar.Max = newValue3;
									chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY2.Min, newValue3);
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY2.Max + (long)unitChangeY2;
							if (newValue2 <= axisMaxY2)
							{
								chart.ChartArea.AxisY2.ScrollBar.Max = newValue2;
								chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY2.Min, newValue2);
							}
						}
					}
					else if (e.NewValue < hScrollBarAxisMax.Value)
					{
						//scroll down
						if (chart.ChartArea.AxisY2.AnnoFormatString == "D1" || chart.ChartArea.AxisY2.AnnoFormatString == "F2")
						{
							if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
							{
								newValue3 = 5 - ((int)chart.ChartArea.AxisY2.Min - 1) - unitChangeY2;
							}
							else
							{
								newValue3 = chart.ChartArea.AxisY2.Max - unitChangeY2;
							}

							if (newValue3 >= axisMinY2)
							{
								if (m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS)
								{
									if (newValue3 > 5 - ((int)chart.ChartArea.AxisY2.Max - 1))
									{
										newValue3 = 5 - (newValue3 - 1);
										chart.ChartArea.AxisY2.ScrollBar.Min = newValue3;
										chart.ChartArea.AxisY2.SetMinMax(newValue3, chart.ChartArea.AxisY2.Max);
									}
								}
								else
								{
									if (newValue3 > chart.ChartArea.AxisY2.Min)
									{
										chart.ChartArea.AxisY2.ScrollBar.Max = newValue3;
										chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY2.Min, newValue3);
									}
								}
							}
						}
						else
						{
							newValue2 = (long)chart.ChartArea.AxisY2.Max - (long)unitChangeY2;
							if (newValue2 >= axisMinY2)
							{
								if (newValue2 > (long)chart.ChartArea.AxisY2.Min)
								{
									chart.ChartArea.AxisY2.ScrollBar.Max = newValue2;
									chart.ChartArea.AxisY2.SetMinMax(chart.ChartArea.AxisY2.Min, newValue2);
								}
							}
						}
					}
					else
					{
						return;
					}

					this.chart.Refresh();
					RefreshDisplayValues(false);

					break;
				}
			}
		}

		//mam
		private void buttonResetGraphValues_Click(object sender, System.EventArgs e)
		{
			ResetGraphValues(false);
		}
		//</mam>


		private void radioButtonAxisX_CheckedChanged(object sender, System.EventArgs e)
		{
			axisCurrent = "X";
			RefreshDisplayValues(false);
		}

		private void radioButtonAxisY1_CheckedChanged(object sender, System.EventArgs e)
		{
			axisCurrent = "Y1";
			RefreshDisplayValues(false);
			SetControls();
		}

		private void radioButtonAxisY2_CheckedChanged(object sender, System.EventArgs e)
		{
			axisCurrent = "Y2";
			RefreshDisplayValues(false);
			SetControls();
		}

		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphsNewView.htm");
		}

		private void pictureBoxHelp_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "GraphsNewView.htm");
		}

		//mam
		private void checkBoxZoom_CheckedChanged(object sender, System.EventArgs e)
		{
			ShowZoom(checkBoxZoom.Checked);
		}
		//</mam>

		//mam
		private void buttonSyncAxes_Click(object sender, System.EventArgs e)
		{
			SyncAxes(false);
		}

		private void chart_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			//don't show the labels
			return;

//			C1.Win.C1Chart.Label lbl = null;
//			string labelText = "";
//
//			if (this.chart.ChartLabels.LabelsCollection.Count == 0)
//			{
//				lbl = this.chart.ChartLabels.LabelsCollection.AddNewLabel();
//			}
//			else
//			{
//				lbl = this.chart.ChartLabels.LabelsCollection[0];
//			}
//
//			int si = 0, pi = 0, d = 0;
//			int showAxisLabel = 0;
//
////			if (showY2Axis)
////			{
////				if (this.chart.ChartGroups[1].CoordToDataIndex(e.X, e.Y, C1.Win.C1Chart.CoordinateFocusEnum.XandYCoord, ref si, ref pi, ref d))
////				{
////					MessageBox.Show("hello");
////				}
////			}
//
//			if (this.chart.ChartGroups[1].CoordToDataIndex(e.X, e.Y, C1.Win.C1Chart.CoordinateFocusEnum.XandYCoord, ref si, ref pi, ref d))
//				showAxisLabel = 1;
//			else
//				showAxisLabel = 0;
//
//			//if (this.chart.ChartGroups[0].CoordToDataIndex(e.X, e.Y, C1.Win.C1Chart.CoordinateFocusEnum.XandYCoord, ref si, ref pi, ref d))
//			//	showAxisLabel = 0;
//
//			if (this.chart.ChartGroups[showAxisLabel].CoordToDataIndex(e.X, e.Y, C1.Win.C1Chart.CoordinateFocusEnum.XandYCoord, ref si, ref pi, ref d))
//			{
//				if (d == 0)
//				{
//					lbl.AttachMethod = C1.Win.C1Chart.AttachMethodEnum.DataIndex;
//					lbl.AttachMethodData.GroupIndex = showAxisLabel;
//					lbl.AttachMethodData.SeriesIndex = si;
//					lbl.AttachMethodData.PointIndex = pi;
//					lbl.Compass = C1.Win.C1Chart.LabelCompassEnum.Radial;
//					lbl.Compass = C1.Win.C1Chart.LabelCompassEnum.NorthEast;
//					lbl.Offset = 10;
//					lbl.Connected = true;
//					//lbl.Style.BackColor = Color.LightSalmon;
//					lbl.Style.BackColor = Color.MistyRose;
//					lbl.Style.Border.Thickness = 1;
//					lbl.Style.Border.Color = Color.Black;
//					labelText = chart.ChartGroups[showAxisLabel].ChartData.SeriesList[si].Label.ToString();
//	
//					string[] eqnSplit = null;
//					string delimStr = "/";
//					char[] delimiter = delimStr.ToCharArray();
//
//					try
//					{
//						eqnSplit = labelText.Split(delimiter, 10);
//					}
//					catch(Exception ex)
//					{
//						System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
//					}
//
//					if (eqnSplit.Length > 0)
//					{
//						labelText = "";
//						try
//						{
//							System.Diagnostics.Debug.WriteLine(eqnSplit.Length.ToString());
//							for (int j = 0; j < eqnSplit.Length; j++)
//							{
//								labelText += eqnSplit[j].Trim() + "\n";
//							}
//
//							labelText = labelText.Replace("Mechanical\nElectrical\nInstrumentation\nPiping", "Mechanical / Electrical / Instrumentation / Piping");
//							labelText = labelText.Replace("Structural\nArchitectural", "Structural / Architectural");
//							labelText = labelText.Replace("Civil\nSitework", "Civil / Sitework");
//							labelText = labelText.Replace("Nodes\nAppurtenances", "Nodes / Appurtenances");
//						}
//						catch(Exception ex)
//						{
//							System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
//						}
//					}
//
//					if (chart.ChartArea.AxisY.AnnoFormatString == EnumHandlers.GetGraphYAxisFormatString(GraphYAxis.AcquisitionCost))
//						labelText += string.Format("{0:$#,##0}", chart.ChartGroups[showAxisLabel].ChartData.SeriesList[si].Y[pi]);
//					else
//						labelText += chart.ChartGroups[showAxisLabel].ChartData.SeriesList[si].Y[pi].ToString();
//
//					lbl.Text = labelText;
//					lbl.Visible = true;
//				}
//				else
//				{
//					lbl.Visible = false;
//				}
//			}
		}

		private void labelStatus_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		private void GraphViewerForm_Resize(object sender, System.EventArgs e)
		{
			//make sure the chart header is always centered by resizing it to be almost the width of the form
			this.chart.Header.Size = new Size(this.Width - 50, this.chart.Header.Size.Height);
		}

		private void buttonShowHideLegend_Click(object sender, System.EventArgs e)
		{
			this.chart.Legend.Visible = !this.chart.Legend.Visible;
			SetLegendButtonText();
		}

		private void buttonLegendPopup_Click(object sender, System.EventArgs e)
		{
			ShowLegendPopup();
		}

		private void buttonSetYAxesToZero_Click(object sender, System.EventArgs e)
		{
			//don't set Cond and LOS axes to zero
			if (!(m_yAxis == GraphYAxis.LOS || m_yAxis == GraphYAxis.Condition || m_yAxis == GraphYAxis.ConditionAndLOS))
			{
				this.chart.ChartArea.AxisY.SetMinMax(0, chart.ChartArea.AxisY.Max);
			}

			if (showY2Axis)
			{
				if (!(m_yAxis2 == GraphYAxis.LOS || m_yAxis2 == GraphYAxis.Condition || m_yAxis2 == GraphYAxis.ConditionAndLOS))
				{
					this.chart.ChartArea.AxisY2.SetMinMax(0, chart.ChartArea.AxisY2.Max);
				}
			}

			CheckAxisMaxMinDifference(false);
			RefreshDisplayValues(false);
		}

		private void buttonTest2_Click(object sender, System.EventArgs e)
		{
			chart.ChartArea.AxisX.AnnotationRotation = 0;
		}

		//</mam>

		#endregion /***** Click Events *****/
	}
}