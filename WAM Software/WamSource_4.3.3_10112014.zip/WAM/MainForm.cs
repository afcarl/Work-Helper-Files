using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using WAM.Data;
using WAM.UI;
using WAM.UI.MainViews;

//mam 102309
using WAM.Common;

//mam 12192011
using System.Text.RegularExpressions;

namespace WAM
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region /***** Variables *****/

		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItemFile;
		private System.Windows.Forms.MenuItem menuItemFile_Exit;
		private System.Windows.Forms.MenuItem menuItemEdit;
		private System.Windows.Forms.MenuItem menuItemEdit_AddFacility;
		private System.Windows.Forms.MenuItem menuItemEdit_AddNode;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItemReports;
		private System.Windows.Forms.MenuItem menuItemHelp;
		private System.Windows.Forms.MenuItem menuItemHelp_About;
		private System.Windows.Forms.MenuItem menuItemReports_FacilityReport;
		private System.Windows.Forms.ImageList imageListToolbar;
		private System.Windows.Forms.MenuItem menuItemEdit_DeleteNode;
		private System.Windows.Forms.MenuItem menuItemEdit_ChangeSortOrder;
		private System.Windows.Forms.MenuItem menuItemFile_Import;
		private System.Windows.Forms.MenuItem menuItemImport_PreviousVersion;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItemFile_InfoSetManagement;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.MenuItem menuItemFile_Import_Nodes;
		private System.Windows.Forms.MenuItem menuItemFile_Import_Pipes;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItemFile_Import_InfoSet;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItemEdit_20CitiesENR;
		private System.Windows.Forms.MenuItem menuItemEdit_CustomENR;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItemEdit_GlobalUpdate;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItemGraph_SetupGraph;
		private System.Windows.Forms.MenuItem menuItemReports_FieldSheets;
		private ArrayList nodesExpandedMainForm = new ArrayList();

		//mam
		public static bool currentlyImporting = false;
		public static string currentDatabaseImageFolder = "";
		string databaseToLoad = "";
		private System.Windows.Forms.MenuItem menuItemFileLoadDatabase;
		private System.Windows.Forms.MenuItem menuItemFileSaveDatabaseAs;
		//private bool pinTabs = false;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItemEditDeleteDatabase;
		private System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
		private System.IO.Stream toolbarImageFile = null;
		private Image toolbarImage = null;
		private static bool eqnFormOpen = false;
		WAM.UI.EquationViewer equationViewer = null;
		public System.Windows.Forms.ImageList imageListTree;
		ToolTip toolTip = new ToolTip();
		private System.Windows.Forms.MenuItem menuItemFilePipeTemplate;
		private System.Windows.Forms.MenuItem menuItemFileNodeTemplate;

		//mam - comment unused variables
		//private string		m_currentFacility = "";
		//private string		m_currentProcess = "";
		//</mam>

		private System.Windows.Forms.Panel panelLeft;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.TextBox textBoxCurrentDatabase;
		private System.Windows.Forms.Label labelCurrentDatabase;
		private System.Windows.Forms.TreeView treeViewFacility;
		private System.Windows.Forms.Panel panelRight;
		private WAM.UI.MainViews.DisciplineLandControl disciplineLandControl1;
		private WAM.UI.MainViews.DisciplineNodesControl disciplineNodesControl1;
		private WAM.UI.MainViews.DisciplineMechControl disciplineMechControl1;
		private System.Windows.Forms.Label labelDataType;
		private WAM.UI.MainViews.DisciplinePipeControl disciplinePipeControl1;
		private WAM.UI.MainViews.FacilityControl facilityControl1;
		private WAM.UI.MainViews.InfoSetControl infoSetControl1;
		private WAM.UI.MainViews.DisciplineStructControl disciplineStructControl1;
		private WAM.UI.AssetListControl assetListControl1;
		private WAM.UI.MainViews.MajorComponentControl majorComponentControl1;
		private WAM.UI.MainViews.TreatmentProcessControl treatmentProcessControl1;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCopy;
		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.PictureBox pictureBoxToolbarHelp;
		private System.Windows.Forms.PictureBox pictureBoxToolbarEquationBox;
		private System.Windows.Forms.PictureBox pictureBoxToolbarDelete;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private System.Windows.Forms.Panel panelToolboxOuter;
		private System.Windows.Forms.Panel panelToolboxInner;
		private System.Windows.Forms.MenuItem menuItemEdit_CopyNode;
		private System.Windows.Forms.MenuItem menuItemView;
		private System.Windows.Forms.MenuItem menuItemViewEquationViewer;
		private System.Windows.Forms.MenuItem menuItemHelpContents;
		private System.Windows.Forms.MenuItem menuItemHelpIndex;
		private System.Windows.Forms.MenuItem menuItemHelpSearch;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.PictureBox pictureBoxToolbarPreferences;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItemEdit_Preferences;
		private System.Windows.Forms.MenuItem menuItemFileCompactDatabase;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItemFile_ImportTextFile;
		private System.Windows.Forms.MenuItem menuItemFile_ImportTextFileTemplate;

		//mam 112806
		private delegate void AddNodeDelegate(TreeNode delegateNode);
		private AddNodeDelegate addNodeDelegate;
		private delegate void AddNodeDelegateSpecifyParent(TreeNode delegateNode, TreeNode delegateNodeParent);
		private AddNodeDelegateSpecifyParent addNodeDelegateSpecifyParent;
		private System.Windows.Forms.MenuItem menuItemEdit_ImageFolder;
		private System.Windows.Forms.MenuItem menuItem14;

		//mam 11142011
		private bool continueImport;
		private System.Windows.Forms.Panel panelVersionNotes;
		private System.Windows.Forms.TextBox textBoxVersionNotes;
		private System.Windows.Forms.Label labelVersionNotes;
		private System.Windows.Forms.Panel panelVersionNotesContainer;
		private System.Windows.Forms.Label labelVersionClose;

		//private int optionAutoSave = 1;
		//private string optionsMainList = "";
		//</mam>

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		private static MainForm mainForm = null;

		public MainForm()
		{
			//mam
			GetOptionSettingsFromFile();
			//</mam>

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.form_HelpRequested);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion /***** Construction and Disposal *****/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItemFile = new System.Windows.Forms.MenuItem();
			this.menuItemFileLoadDatabase = new System.Windows.Forms.MenuItem();
			this.menuItemFileSaveDatabaseAs = new System.Windows.Forms.MenuItem();
			this.menuItemFileCompactDatabase = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItemFile_InfoSetManagement = new System.Windows.Forms.MenuItem();
			this.menuItemFile_Import = new System.Windows.Forms.MenuItem();
			this.menuItemFile_Import_InfoSet = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItemFile_ImportTextFile = new System.Windows.Forms.MenuItem();
			this.menuItemFile_ImportTextFileTemplate = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItemFile_Import_Pipes = new System.Windows.Forms.MenuItem();
			this.menuItemFile_Import_Nodes = new System.Windows.Forms.MenuItem();
			this.menuItemFilePipeTemplate = new System.Windows.Forms.MenuItem();
			this.menuItemFileNodeTemplate = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItemImport_PreviousVersion = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItemFile_Exit = new System.Windows.Forms.MenuItem();
			this.menuItemEdit = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_AddFacility = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_AddNode = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_CopyNode = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_DeleteNode = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItemEditDeleteDatabase = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_ChangeSortOrder = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_20CitiesENR = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_CustomENR = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_ImageFolder = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_GlobalUpdate = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItemEdit_Preferences = new System.Windows.Forms.MenuItem();
			this.menuItemView = new System.Windows.Forms.MenuItem();
			this.menuItemViewEquationViewer = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItemGraph_SetupGraph = new System.Windows.Forms.MenuItem();
			this.menuItemReports = new System.Windows.Forms.MenuItem();
			this.menuItemReports_FacilityReport = new System.Windows.Forms.MenuItem();
			this.menuItemReports_FieldSheets = new System.Windows.Forms.MenuItem();
			this.menuItemHelp = new System.Windows.Forms.MenuItem();
			this.menuItemHelpContents = new System.Windows.Forms.MenuItem();
			this.menuItemHelpIndex = new System.Windows.Forms.MenuItem();
			this.menuItemHelpSearch = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItemHelp_About = new System.Windows.Forms.MenuItem();
			this.imageListToolbar = new System.Windows.Forms.ImageList(this.components);
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.panelLeft = new System.Windows.Forms.Panel();
			this.panelVersionNotesContainer = new System.Windows.Forms.Panel();
			this.panelVersionNotes = new System.Windows.Forms.Panel();
			this.labelVersionClose = new System.Windows.Forms.Label();
			this.labelVersionNotes = new System.Windows.Forms.Label();
			this.textBoxVersionNotes = new System.Windows.Forms.TextBox();
			this.panelToolboxOuter = new System.Windows.Forms.Panel();
			this.panelToolboxInner = new System.Windows.Forms.Panel();
			this.pictureBoxToolbarPreferences = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarCopy = new System.Windows.Forms.PictureBox();
			this.buttonTest = new System.Windows.Forms.Button();
			this.pictureBoxToolbarHelp = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarEquationBox = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarDelete = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.textBoxCurrentDatabase = new System.Windows.Forms.TextBox();
			this.labelCurrentDatabase = new System.Windows.Forms.Label();
			this.treeViewFacility = new System.Windows.Forms.TreeView();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.panelRight = new System.Windows.Forms.Panel();
			this.facilityControl1 = new WAM.UI.MainViews.FacilityControl();
			this.disciplineLandControl1 = new WAM.UI.MainViews.DisciplineLandControl();
			this.disciplineNodesControl1 = new WAM.UI.MainViews.DisciplineNodesControl();
			this.disciplineMechControl1 = new WAM.UI.MainViews.DisciplineMechControl();
			this.labelDataType = new System.Windows.Forms.Label();
			this.disciplinePipeControl1 = new WAM.UI.MainViews.DisciplinePipeControl();
			this.infoSetControl1 = new WAM.UI.MainViews.InfoSetControl();
			this.disciplineStructControl1 = new WAM.UI.MainViews.DisciplineStructControl();
			this.assetListControl1 = new WAM.UI.AssetListControl();
			this.majorComponentControl1 = new WAM.UI.MainViews.MajorComponentControl();
			this.treatmentProcessControl1 = new WAM.UI.MainViews.TreatmentProcessControl();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.panelLeft.SuspendLayout();
			this.panelVersionNotesContainer.SuspendLayout();
			this.panelVersionNotes.SuspendLayout();
			this.panelToolboxOuter.SuspendLayout();
			this.panelToolboxInner.SuspendLayout();
			this.panelRight.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItemFile,
																					 this.menuItemEdit,
																					 this.menuItemView,
																					 this.menuItem5,
																					 this.menuItemReports,
																					 this.menuItemHelp});
			// 
			// menuItemFile
			// 
			this.menuItemFile.Index = 0;
			this.menuItemFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemFileLoadDatabase,
																						 this.menuItemFileSaveDatabaseAs,
																						 this.menuItemFileCompactDatabase,
																						 this.menuItem6,
																						 this.menuItemFile_InfoSetManagement,
																						 this.menuItemFile_Import,
																						 this.menuItem3,
																						 this.menuItemFile_Exit});
			this.menuItemFile.Text = "&File";
			this.menuItemFile.Click += new System.EventHandler(this.menuItemFile_Click);
			this.menuItemFile.Select += new System.EventHandler(this.menuItemFile_Select);
			// 
			// menuItemFileLoadDatabase
			// 
			this.menuItemFileLoadDatabase.Index = 0;
			this.menuItemFileLoadDatabase.Text = "&Load Database...";
			this.menuItemFileLoadDatabase.Visible = false;
			this.menuItemFileLoadDatabase.Click += new System.EventHandler(this.menuItemFileLoadDatabase_Click);
			// 
			// menuItemFileSaveDatabaseAs
			// 
			this.menuItemFileSaveDatabaseAs.Index = 1;
			this.menuItemFileSaveDatabaseAs.Text = "&Copy Database...";
			this.menuItemFileSaveDatabaseAs.Visible = false;
			this.menuItemFileSaveDatabaseAs.Click += new System.EventHandler(this.menuItemFileSaveDatabaseAs_Click);
			// 
			// menuItemFileCompactDatabase
			// 
			this.menuItemFileCompactDatabase.Index = 2;
			this.menuItemFileCompactDatabase.Text = "Com&pact Database...";
			this.menuItemFileCompactDatabase.Visible = false;
			this.menuItemFileCompactDatabase.Click += new System.EventHandler(this.menuItemFileCompactDatabase_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 3;
			this.menuItem6.Text = "-";
			this.menuItem6.Visible = false;
			// 
			// menuItemFile_InfoSetManagement
			// 
			this.menuItemFile_InfoSetManagement.Index = 4;
			this.menuItemFile_InfoSetManagement.Text = "&InfoSet Management...";
			this.menuItemFile_InfoSetManagement.Click += new System.EventHandler(this.menuItemFile_InfoSetManagement_Click);
			// 
			// menuItemFile_Import
			// 
			this.menuItemFile_Import.Index = 5;
			this.menuItemFile_Import.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																								this.menuItemFile_Import_InfoSet,
																								this.menuItem2,
																								this.menuItemFile_ImportTextFile,
																								this.menuItemFile_ImportTextFileTemplate,
																								this.menuItem12,
																								this.menuItemFile_Import_Pipes,
																								this.menuItemFile_Import_Nodes,
																								this.menuItemFilePipeTemplate,
																								this.menuItemFileNodeTemplate,
																								this.menuItem7,
																								this.menuItemImport_PreviousVersion});
			this.menuItemFile_Import.Text = "I&mport";
			// 
			// menuItemFile_Import_InfoSet
			// 
			this.menuItemFile_Import_InfoSet.Index = 0;
			this.menuItemFile_Import_InfoSet.Text = "Import &InfoSet from Another Database";
			this.menuItemFile_Import_InfoSet.Click += new System.EventHandler(this.menuItemFile_Import_InfoSet_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "-";
			// 
			// menuItemFile_ImportTextFile
			// 
			this.menuItemFile_ImportTextFile.Index = 2;
			this.menuItemFile_ImportTextFile.Text = "Import from &Excel File...";
			this.menuItemFile_ImportTextFile.Click += new System.EventHandler(this.menuItemFile_ImportTextFile_Click);
			// 
			// menuItemFile_ImportTextFileTemplate
			// 
			this.menuItemFile_ImportTextFileTemplate.Index = 3;
			this.menuItemFile_ImportTextFileTemplate.Text = "Create Example Import File";
			this.menuItemFile_ImportTextFileTemplate.Visible = false;
			this.menuItemFile_ImportTextFileTemplate.Click += new System.EventHandler(this.menuItemFile_ImportTextFileTemplate_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 4;
			this.menuItem12.Text = "-";
			// 
			// menuItemFile_Import_Pipes
			// 
			this.menuItemFile_Import_Pipes.Index = 5;
			this.menuItemFile_Import_Pipes.Text = "Import &Pipes Data";
			this.menuItemFile_Import_Pipes.Click += new System.EventHandler(this.menuItemFile_Import_Pipes_Click);
			// 
			// menuItemFile_Import_Nodes
			// 
			this.menuItemFile_Import_Nodes.Index = 6;
			this.menuItemFile_Import_Nodes.Text = "Import &Nodes / Appurtenances Data";
			this.menuItemFile_Import_Nodes.Click += new System.EventHandler(this.menuItemFile_Import_Nodes_Click);
			// 
			// menuItemFilePipeTemplate
			// 
			this.menuItemFilePipeTemplate.Index = 7;
			this.menuItemFilePipeTemplate.Text = "Create Example Pipe Import File";
			this.menuItemFilePipeTemplate.Click += new System.EventHandler(this.menuItemFilePipeTemplate_Click);
			// 
			// menuItemFileNodeTemplate
			// 
			this.menuItemFileNodeTemplate.Index = 8;
			this.menuItemFileNodeTemplate.Text = "Create Example Node Import File";
			this.menuItemFileNodeTemplate.Click += new System.EventHandler(this.menuItemFileNodeTemplate_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 9;
			this.menuItem7.Text = "-";
			this.menuItem7.Visible = false;
			// 
			// menuItemImport_PreviousVersion
			// 
			this.menuItemImport_PreviousVersion.Index = 10;
			this.menuItemImport_PreviousVersion.Text = "Import from Previous &Version";
			this.menuItemImport_PreviousVersion.Visible = false;
			this.menuItemImport_PreviousVersion.Click += new System.EventHandler(this.menuItemImport_PreviousVersion_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 6;
			this.menuItem3.Text = "-";
			// 
			// menuItemFile_Exit
			// 
			this.menuItemFile_Exit.Index = 7;
			this.menuItemFile_Exit.Text = "E&xit";
			this.menuItemFile_Exit.Click += new System.EventHandler(this.menuItemFile_Exit_Click);
			// 
			// menuItemEdit
			// 
			this.menuItemEdit.Index = 1;
			this.menuItemEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemEdit_AddFacility,
																						 this.menuItemEdit_AddNode,
																						 this.menuItemEdit_CopyNode,
																						 this.menuItemEdit_DeleteNode,
																						 this.menuItem9,
																						 this.menuItemEditDeleteDatabase,
																						 this.menuItem4,
																						 this.menuItemEdit_ChangeSortOrder,
																						 this.menuItem1,
																						 this.menuItemEdit_20CitiesENR,
																						 this.menuItemEdit_CustomENR,
																						 this.menuItem14,
																						 this.menuItemEdit_ImageFolder,
																						 this.menuItem8,
																						 this.menuItemEdit_GlobalUpdate,
																						 this.menuItem10,
																						 this.menuItemEdit_Preferences});
			this.menuItemEdit.Text = "&Edit";
			this.menuItemEdit.Popup += new System.EventHandler(this.menuItemEdit_Popup);
			// 
			// menuItemEdit_AddFacility
			// 
			this.menuItemEdit_AddFacility.Index = 0;
			this.menuItemEdit_AddFacility.Text = "Add New &Facility / System...";
			this.menuItemEdit_AddFacility.Click += new System.EventHandler(this.menuItemEdit_AddFacility_Click);
			// 
			// menuItemEdit_AddNode
			// 
			this.menuItemEdit_AddNode.Index = 1;
			this.menuItemEdit_AddNode.Text = "Add &New ...";
			this.menuItemEdit_AddNode.Click += new System.EventHandler(this.menuItemEdit_AddNode_Click);
			// 
			// menuItemEdit_CopyNode
			// 
			this.menuItemEdit_CopyNode.Index = 2;
			this.menuItemEdit_CopyNode.Text = "&Copy Node";
			this.menuItemEdit_CopyNode.Click += new System.EventHandler(this.menuItemEdit_CopyNode_Click);
			// 
			// menuItemEdit_DeleteNode
			// 
			this.menuItemEdit_DeleteNode.Index = 3;
			this.menuItemEdit_DeleteNode.Text = "&Delete Node";
			this.menuItemEdit_DeleteNode.Click += new System.EventHandler(this.menuItemEdit_DeleteNode_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 4;
			this.menuItem9.Text = "-";
			// 
			// menuItemEditDeleteDatabase
			// 
			this.menuItemEditDeleteDatabase.Index = 5;
			this.menuItemEditDeleteDatabase.Text = "Delete Database...";
			this.menuItemEditDeleteDatabase.Visible = false;
			this.menuItemEditDeleteDatabase.Click += new System.EventHandler(this.menuItemEditDeleteDatabase_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 6;
			this.menuItem4.Text = "-";
			this.menuItem4.Visible = false;
			// 
			// menuItemEdit_ChangeSortOrder
			// 
			this.menuItemEdit_ChangeSortOrder.Index = 7;
			this.menuItemEdit_ChangeSortOrder.Text = "Change &Sort Order...";
			this.menuItemEdit_ChangeSortOrder.Click += new System.EventHandler(this.menuItemEdit_ChangeSortOrder_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 8;
			this.menuItem1.Text = "-";
			// 
			// menuItemEdit_20CitiesENR
			// 
			this.menuItemEdit_20CitiesENR.Index = 9;
			this.menuItemEdit_20CitiesENR.Text = "Edit Default (20 Cities) ENR &Table...";
			this.menuItemEdit_20CitiesENR.Click += new System.EventHandler(this.menuItemEdit_20CitiesENR_Click);
			// 
			// menuItemEdit_CustomENR
			// 
			this.menuItemEdit_CustomENR.Index = 10;
			this.menuItemEdit_CustomENR.Text = "Edit Custom &ENR Tables...";
			this.menuItemEdit_CustomENR.Click += new System.EventHandler(this.menuItemEdit_CustomENR_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 11;
			this.menuItem14.Text = "-";
			// 
			// menuItemEdit_ImageFolder
			// 
			this.menuItemEdit_ImageFolder.Index = 12;
			this.menuItemEdit_ImageFolder.Text = "WAM Image Folder...";
			this.menuItemEdit_ImageFolder.Click += new System.EventHandler(this.menuItemEdit_ImageFolder_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 13;
			this.menuItem8.Text = "-";
			// 
			// menuItemEdit_GlobalUpdate
			// 
			this.menuItemEdit_GlobalUpdate.Index = 14;
			this.menuItemEdit_GlobalUpdate.Text = "&Global Update...";
			this.menuItemEdit_GlobalUpdate.Click += new System.EventHandler(this.menuItemEdit_GlobalUpdate_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 15;
			this.menuItem10.Text = "-";
			// 
			// menuItemEdit_Preferences
			// 
			this.menuItemEdit_Preferences.Index = 16;
			this.menuItemEdit_Preferences.Text = "Preferences...";
			this.menuItemEdit_Preferences.Click += new System.EventHandler(this.menuItemEdit_Preferences_Click);
			// 
			// menuItemView
			// 
			this.menuItemView.Index = 2;
			this.menuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemViewEquationViewer});
			this.menuItemView.Text = "&View";
			this.menuItemView.Popup += new System.EventHandler(this.menuItemView_Popup);
			// 
			// menuItemViewEquationViewer
			// 
			this.menuItemViewEquationViewer.Index = 0;
			this.menuItemViewEquationViewer.Text = "&Equation Viewer...";
			this.menuItemViewEquationViewer.Click += new System.EventHandler(this.menuItemViewEquationViewer_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 3;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItemGraph_SetupGraph});
			this.menuItem5.Text = "&Graphs";
			this.menuItem5.Select += new System.EventHandler(this.menuItem5_Select);
			// 
			// menuItemGraph_SetupGraph
			// 
			this.menuItemGraph_SetupGraph.Index = 0;
			this.menuItemGraph_SetupGraph.Text = "&Create Graph...";
			this.menuItemGraph_SetupGraph.Click += new System.EventHandler(this.menuItemGraph_SetupGraph_Click);
			// 
			// menuItemReports
			// 
			this.menuItemReports.Index = 4;
			this.menuItemReports.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							this.menuItemReports_FacilityReport,
																							this.menuItemReports_FieldSheets});
			this.menuItemReports.Text = "&Reports";
			this.menuItemReports.Select += new System.EventHandler(this.menuItemReports_Select);
			// 
			// menuItemReports_FacilityReport
			// 
			this.menuItemReports_FacilityReport.Index = 0;
			this.menuItemReports_FacilityReport.Text = "&Create Reports...";
			this.menuItemReports_FacilityReport.Click += new System.EventHandler(this.menuItemReports_FacilityReport_Click);
			// 
			// menuItemReports_FieldSheets
			// 
			this.menuItemReports_FieldSheets.Index = 1;
			this.menuItemReports_FieldSheets.Text = "&Field Sheets...";
			this.menuItemReports_FieldSheets.Click += new System.EventHandler(this.menuItemReports_FieldSheets_Click);
			// 
			// menuItemHelp
			// 
			this.menuItemHelp.Index = 5;
			this.menuItemHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemHelpContents,
																						 this.menuItemHelpIndex,
																						 this.menuItemHelpSearch,
																						 this.menuItem13,
																						 this.menuItemHelp_About});
			this.menuItemHelp.Text = "&Help";
			this.menuItemHelp.Select += new System.EventHandler(this.menuItemHelp_Select);
			// 
			// menuItemHelpContents
			// 
			this.menuItemHelpContents.Index = 0;
			this.menuItemHelpContents.Text = "&Contents...";
			this.menuItemHelpContents.Click += new System.EventHandler(this.menuItemHelpContents_Click);
			// 
			// menuItemHelpIndex
			// 
			this.menuItemHelpIndex.Index = 1;
			this.menuItemHelpIndex.Text = "&Index...";
			this.menuItemHelpIndex.Click += new System.EventHandler(this.menuItemHelpIndex_Click);
			// 
			// menuItemHelpSearch
			// 
			this.menuItemHelpSearch.Index = 2;
			this.menuItemHelpSearch.Text = "&Search";
			this.menuItemHelpSearch.Visible = false;
			this.menuItemHelpSearch.Click += new System.EventHandler(this.menuItemHelpSearch_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 3;
			this.menuItem13.Text = "-";
			// 
			// menuItemHelp_About
			// 
			this.menuItemHelp_About.Index = 4;
			this.menuItemHelp_About.Text = "&About Water / Wastewater Asset Manager...";
			this.menuItemHelp_About.Click += new System.EventHandler(this.menuItemHelp_About_Click);
			// 
			// imageListToolbar
			// 
			this.imageListToolbar.ImageSize = new System.Drawing.Size(16, 15);
			this.imageListToolbar.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListToolbar.ImageStream")));
			this.imageListToolbar.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// panelLeft
			// 
			this.panelLeft.Controls.Add(this.panelVersionNotesContainer);
			this.panelLeft.Controls.Add(this.panelToolboxOuter);
			this.panelLeft.Controls.Add(this.textBoxCurrentDatabase);
			this.panelLeft.Controls.Add(this.labelCurrentDatabase);
			this.panelLeft.Controls.Add(this.treeViewFacility);
			this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.panelLeft.Location = new System.Drawing.Point(0, 0);
			this.panelLeft.Name = "panelLeft";
			this.panelLeft.Size = new System.Drawing.Size(216, 537);
			this.panelLeft.TabIndex = 0;
			// 
			// panelVersionNotesContainer
			// 
			this.panelVersionNotesContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.panelVersionNotesContainer.BackColor = System.Drawing.SystemColors.ControlDark;
			this.panelVersionNotesContainer.Controls.Add(this.panelVersionNotes);
			this.panelVersionNotesContainer.Location = new System.Drawing.Point(8, 276);
			this.panelVersionNotesContainer.Name = "panelVersionNotesContainer";
			this.panelVersionNotesContainer.Size = new System.Drawing.Size(204, 120);
			this.panelVersionNotesContainer.TabIndex = 138;
			this.panelVersionNotesContainer.Visible = false;
			// 
			// panelVersionNotes
			// 
			this.panelVersionNotes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelVersionNotes.BackColor = System.Drawing.SystemColors.Control;
			this.panelVersionNotes.Controls.Add(this.labelVersionClose);
			this.panelVersionNotes.Controls.Add(this.labelVersionNotes);
			this.panelVersionNotes.Controls.Add(this.textBoxVersionNotes);
			this.panelVersionNotes.Location = new System.Drawing.Point(2, 2);
			this.panelVersionNotes.Name = "panelVersionNotes";
			this.panelVersionNotes.Size = new System.Drawing.Size(200, 116);
			this.panelVersionNotes.TabIndex = 137;
			// 
			// labelVersionClose
			// 
			this.labelVersionClose.BackColor = System.Drawing.Color.Transparent;
			this.labelVersionClose.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelVersionClose.Location = new System.Drawing.Point(182, 5);
			this.labelVersionClose.Name = "labelVersionClose";
			this.labelVersionClose.Size = new System.Drawing.Size(13, 15);
			this.labelVersionClose.TabIndex = 2;
			this.labelVersionClose.Text = "X";
			// 
			// labelVersionNotes
			// 
			this.labelVersionNotes.BackColor = System.Drawing.Color.Transparent;
			this.labelVersionNotes.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelVersionNotes.Location = new System.Drawing.Point(6, 5);
			this.labelVersionNotes.Name = "labelVersionNotes";
			this.labelVersionNotes.Size = new System.Drawing.Size(99, 15);
			this.labelVersionNotes.TabIndex = 1;
			this.labelVersionNotes.Text = "Version Notes:";
			// 
			// textBoxVersionNotes
			// 
			this.textBoxVersionNotes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxVersionNotes.Location = new System.Drawing.Point(4, 24);
			this.textBoxVersionNotes.Multiline = true;
			this.textBoxVersionNotes.Name = "textBoxVersionNotes";
			this.textBoxVersionNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxVersionNotes.Size = new System.Drawing.Size(192, 88);
			this.textBoxVersionNotes.TabIndex = 0;
			this.textBoxVersionNotes.Text = "";
			// 
			// panelToolboxOuter
			// 
			this.panelToolboxOuter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelToolboxOuter.AutoScroll = true;
			this.panelToolboxOuter.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(127)), ((System.Byte)(157)), ((System.Byte)(185)));
			this.panelToolboxOuter.Controls.Add(this.panelToolboxInner);
			this.panelToolboxOuter.Location = new System.Drawing.Point(3, 4);
			this.panelToolboxOuter.Name = "panelToolboxOuter";
			this.panelToolboxOuter.Size = new System.Drawing.Size(212, 34);
			this.panelToolboxOuter.TabIndex = 136;
			// 
			// panelToolboxInner
			// 
			this.panelToolboxInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelToolboxInner.BackColor = System.Drawing.SystemColors.Control;
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarPreferences);
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarCopy);
			this.panelToolboxInner.Controls.Add(this.buttonTest);
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarHelp);
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarEquationBox);
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarDelete);
			this.panelToolboxInner.Controls.Add(this.pictureBoxToolbarAdd);
			this.panelToolboxInner.Location = new System.Drawing.Point(1, 1);
			this.panelToolboxInner.Name = "panelToolboxInner";
			this.panelToolboxInner.Size = new System.Drawing.Size(210, 32);
			this.panelToolboxInner.TabIndex = 0;
			// 
			// pictureBoxToolbarPreferences
			// 
			this.pictureBoxToolbarPreferences.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarPreferences.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarPreferences.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarPreferences.Image")));
			this.pictureBoxToolbarPreferences.Location = new System.Drawing.Point(135, 6);
			this.pictureBoxToolbarPreferences.Name = "pictureBoxToolbarPreferences";
			this.pictureBoxToolbarPreferences.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarPreferences.TabIndex = 141;
			this.pictureBoxToolbarPreferences.TabStop = false;
			this.pictureBoxToolbarPreferences.Click += new System.EventHandler(this.pictureBoxToolbarPreferences_Click);
			// 
			// pictureBoxToolbarCopy
			// 
			this.pictureBoxToolbarCopy.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCopy.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCopy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCopy.Image")));
			this.pictureBoxToolbarCopy.Location = new System.Drawing.Point(31, 6);
			this.pictureBoxToolbarCopy.Name = "pictureBoxToolbarCopy";
			this.pictureBoxToolbarCopy.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCopy.TabIndex = 140;
			this.pictureBoxToolbarCopy.TabStop = false;
			this.pictureBoxToolbarCopy.Click += new System.EventHandler(this.pictureBoxToolbarCopy_Click);
			// 
			// buttonTest
			// 
			this.buttonTest.Location = new System.Drawing.Point(84, 6);
			this.buttonTest.Name = "buttonTest";
			this.buttonTest.Size = new System.Drawing.Size(20, 20);
			this.buttonTest.TabIndex = 139;
			this.buttonTest.Visible = false;
			this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
			// 
			// pictureBoxToolbarHelp
			// 
			this.pictureBoxToolbarHelp.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarHelp.Image")));
			this.pictureBoxToolbarHelp.Location = new System.Drawing.Point(183, 6);
			this.pictureBoxToolbarHelp.Name = "pictureBoxToolbarHelp";
			this.pictureBoxToolbarHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarHelp.TabIndex = 138;
			this.pictureBoxToolbarHelp.TabStop = false;
			this.pictureBoxToolbarHelp.Click += new System.EventHandler(this.pictureBoxToolbarHelp_Click);
			// 
			// pictureBoxToolbarEquationBox
			// 
			this.pictureBoxToolbarEquationBox.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarEquationBox.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarEquationBox.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarEquationBox.Image")));
			this.pictureBoxToolbarEquationBox.Location = new System.Drawing.Point(159, 6);
			this.pictureBoxToolbarEquationBox.Name = "pictureBoxToolbarEquationBox";
			this.pictureBoxToolbarEquationBox.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarEquationBox.TabIndex = 137;
			this.pictureBoxToolbarEquationBox.TabStop = false;
			this.pictureBoxToolbarEquationBox.Click += new System.EventHandler(this.pictureBoxToolbarEquationBox_Click);
			// 
			// pictureBoxToolbarDelete
			// 
			this.pictureBoxToolbarDelete.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarDelete.Image")));
			this.pictureBoxToolbarDelete.Location = new System.Drawing.Point(55, 6);
			this.pictureBoxToolbarDelete.Name = "pictureBoxToolbarDelete";
			this.pictureBoxToolbarDelete.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarDelete.TabIndex = 136;
			this.pictureBoxToolbarDelete.TabStop = false;
			this.pictureBoxToolbarDelete.Click += new System.EventHandler(this.pictureBoxToolbarDelete_Click);
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(7, 6);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 135;
			this.pictureBoxToolbarAdd.TabStop = false;
			this.pictureBoxToolbarAdd.Click += new System.EventHandler(this.pictureBoxToolbarAdd_Click);
			// 
			// textBoxCurrentDatabase
			// 
			this.textBoxCurrentDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxCurrentDatabase.BackColor = System.Drawing.SystemColors.Control;
			this.textBoxCurrentDatabase.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.textBoxCurrentDatabase.Location = new System.Drawing.Point(3, 512);
			this.textBoxCurrentDatabase.Name = "textBoxCurrentDatabase";
			this.textBoxCurrentDatabase.ReadOnly = true;
			this.textBoxCurrentDatabase.Size = new System.Drawing.Size(212, 20);
			this.textBoxCurrentDatabase.TabIndex = 124;
			this.textBoxCurrentDatabase.TabStop = false;
			this.textBoxCurrentDatabase.Text = "";
			// 
			// labelCurrentDatabase
			// 
			this.labelCurrentDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCurrentDatabase.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(224)), ((System.Byte)(192)));
			this.labelCurrentDatabase.Location = new System.Drawing.Point(11, 512);
			this.labelCurrentDatabase.Name = "labelCurrentDatabase";
			this.labelCurrentDatabase.Size = new System.Drawing.Size(8, 18);
			this.labelCurrentDatabase.TabIndex = 123;
			this.labelCurrentDatabase.Visible = false;
			// 
			// treeViewFacility
			// 
			this.treeViewFacility.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treeViewFacility.HideSelection = false;
			this.treeViewFacility.ImageIndex = -1;
			this.treeViewFacility.Location = new System.Drawing.Point(3, 36);
			this.treeViewFacility.Name = "treeViewFacility";
			this.treeViewFacility.SelectedImageIndex = -1;
			this.treeViewFacility.Size = new System.Drawing.Size(212, 471);
			this.treeViewFacility.TabIndex = 122;
			this.treeViewFacility.Resize += new System.EventHandler(this.treeViewFacility_Resize);
			this.treeViewFacility.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewFacility_AfterSelect);
			this.treeViewFacility.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewFacility_BeforeSelect);
			this.treeViewFacility.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeViewFacility_BeforeExpand);
			// 
			// splitter1
			// 
			this.splitter1.BackColor = System.Drawing.SystemColors.Control;
			this.splitter1.Location = new System.Drawing.Point(216, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(6, 537);
			this.splitter1.TabIndex = 1;
			this.splitter1.TabStop = false;
			// 
			// panelRight
			// 
			this.panelRight.Controls.Add(this.facilityControl1);
			this.panelRight.Controls.Add(this.disciplineLandControl1);
			this.panelRight.Controls.Add(this.disciplineNodesControl1);
			this.panelRight.Controls.Add(this.disciplineMechControl1);
			this.panelRight.Controls.Add(this.labelDataType);
			this.panelRight.Controls.Add(this.disciplinePipeControl1);
			this.panelRight.Controls.Add(this.infoSetControl1);
			this.panelRight.Controls.Add(this.disciplineStructControl1);
			this.panelRight.Controls.Add(this.assetListControl1);
			this.panelRight.Controls.Add(this.majorComponentControl1);
			this.panelRight.Controls.Add(this.treatmentProcessControl1);
			this.panelRight.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelRight.Location = new System.Drawing.Point(222, 0);
			this.panelRight.Name = "panelRight";
			this.panelRight.Size = new System.Drawing.Size(490, 537);
			this.panelRight.TabIndex = 4;
			// 
			// facilityControl1
			// 
			this.facilityControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.facilityControl1.AutoScroll = true;
			this.facilityControl1.AutoScrollMinSize = new System.Drawing.Size(616, 450);
			this.facilityControl1.BackColor = System.Drawing.SystemColors.Control;
			this.facilityControl1.Location = new System.Drawing.Point(1, 30);
			this.facilityControl1.Name = "facilityControl1";
			this.facilityControl1.Size = new System.Drawing.Size(489, 505);
			this.facilityControl1.TabControlIndex = 0;
			this.facilityControl1.TabIndex = 109;
			this.facilityControl1.Visible = false;
			// 
			// disciplineLandControl1
			// 
			this.disciplineLandControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineLandControl1.AutoScroll = true;
			this.disciplineLandControl1.AutoScrollMinSize = new System.Drawing.Size(700, 660);
			this.disciplineLandControl1.Location = new System.Drawing.Point(1, 30);
			this.disciplineLandControl1.Name = "disciplineLandControl1";
			this.disciplineLandControl1.Size = new System.Drawing.Size(489, 505);
			this.disciplineLandControl1.TabControlIndex = 0;
			this.disciplineLandControl1.TabIndex = 113;
			this.disciplineLandControl1.Visible = false;
			// 
			// disciplineNodesControl1
			// 
			this.disciplineNodesControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineNodesControl1.AutoScroll = true;
			this.disciplineNodesControl1.AutoScrollMinSize = new System.Drawing.Size(700, 600);
			this.disciplineNodesControl1.Location = new System.Drawing.Point(1, 30);
			this.disciplineNodesControl1.Name = "disciplineNodesControl1";
			this.disciplineNodesControl1.Size = new System.Drawing.Size(489, 505);
			this.disciplineNodesControl1.TabControlIndex = 0;
			this.disciplineNodesControl1.TabIndex = 117;
			this.disciplineNodesControl1.Visible = false;
			// 
			// disciplineMechControl1
			// 
			this.disciplineMechControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineMechControl1.AutoScroll = true;
			this.disciplineMechControl1.AutoScrollMinSize = new System.Drawing.Size(700, 660);
			this.disciplineMechControl1.Location = new System.Drawing.Point(1, 30);
			this.disciplineMechControl1.Name = "disciplineMechControl1";
			this.disciplineMechControl1.Size = new System.Drawing.Size(489, 505);
			this.disciplineMechControl1.TabControlIndex = 0;
			this.disciplineMechControl1.TabIndex = 111;
			this.disciplineMechControl1.Visible = false;
			// 
			// labelDataType
			// 
			this.labelDataType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelDataType.BackColor = System.Drawing.Color.Transparent;
			this.labelDataType.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDataType.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(145)), ((System.Byte)(185)));
			this.labelDataType.Location = new System.Drawing.Point(0, 4);
			this.labelDataType.Name = "labelDataType";
			this.labelDataType.Size = new System.Drawing.Size(566, 23);
			this.labelDataType.TabIndex = 119;
			// 
			// disciplinePipeControl1
			// 
			this.disciplinePipeControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplinePipeControl1.AutoScroll = true;
			this.disciplinePipeControl1.AutoScrollMinSize = new System.Drawing.Size(700, 600);
			this.disciplinePipeControl1.Location = new System.Drawing.Point(1, 30);
			this.disciplinePipeControl1.Name = "disciplinePipeControl1";
			this.disciplinePipeControl1.Size = new System.Drawing.Size(489, 505);
			this.disciplinePipeControl1.TabControlIndex = 0;
			this.disciplinePipeControl1.TabIndex = 118;
			this.disciplinePipeControl1.Visible = false;
			// 
			// infoSetControl1
			// 
			this.infoSetControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.infoSetControl1.BackColor = System.Drawing.SystemColors.Control;
			this.infoSetControl1.Location = new System.Drawing.Point(1, 30);
			this.infoSetControl1.Name = "infoSetControl1";
			this.infoSetControl1.Size = new System.Drawing.Size(489, 505);
			this.infoSetControl1.TabIndex = 110;
			this.infoSetControl1.Visible = false;
			// 
			// disciplineStructControl1
			// 
			this.disciplineStructControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineStructControl1.AutoScroll = true;
			this.disciplineStructControl1.AutoScrollMinSize = new System.Drawing.Size(700, 660);
			this.disciplineStructControl1.Location = new System.Drawing.Point(1, 30);
			this.disciplineStructControl1.Name = "disciplineStructControl1";
			this.disciplineStructControl1.Size = new System.Drawing.Size(489, 505);
			this.disciplineStructControl1.TabControlIndex = 0;
			this.disciplineStructControl1.TabIndex = 112;
			this.disciplineStructControl1.Visible = false;
			// 
			// assetListControl1
			// 
			this.assetListControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.assetListControl1.AutoScroll = true;
			this.assetListControl1.AutoScrollMinSize = new System.Drawing.Size(540, 396);
			this.assetListControl1.Location = new System.Drawing.Point(1, 30);
			this.assetListControl1.Name = "assetListControl1";
			this.assetListControl1.Size = new System.Drawing.Size(489, 505);
			this.assetListControl1.TabIndex = 116;
			this.assetListControl1.Visible = false;
			// 
			// majorComponentControl1
			// 
			this.majorComponentControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.majorComponentControl1.AutoScroll = true;
			this.majorComponentControl1.AutoScrollMinSize = new System.Drawing.Size(698, 700);
			this.majorComponentControl1.Location = new System.Drawing.Point(1, 30);
			this.majorComponentControl1.Name = "majorComponentControl1";
			this.majorComponentControl1.Size = new System.Drawing.Size(489, 505);
			this.majorComponentControl1.TabControlIndex = 0;
			this.majorComponentControl1.TabIndex = 114;
			this.majorComponentControl1.Visible = false;
			// 
			// treatmentProcessControl1
			// 
			this.treatmentProcessControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treatmentProcessControl1.AutoScroll = true;
			this.treatmentProcessControl1.AutoScrollMinSize = new System.Drawing.Size(616, 452);
			this.treatmentProcessControl1.Location = new System.Drawing.Point(1, 30);
			this.treatmentProcessControl1.Name = "treatmentProcessControl1";
			this.treatmentProcessControl1.Size = new System.Drawing.Size(489, 505);
			this.treatmentProcessControl1.TabControlIndex = 0;
			this.treatmentProcessControl1.TabIndex = 115;
			this.treatmentProcessControl1.Visible = false;
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(712, 537);
			this.Controls.Add(this.panelRight);
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.panelLeft);
			this.helpProvider1.SetHelpKeyword(this, "Welcome.htm");
			this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.helpProvider1.SetShowHelp(this, true);
			this.Text = "Water / Wastewater Asset Manager";
			this.Resize += new System.EventHandler(this.MainForm_Resize);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
			this.panelLeft.ResumeLayout(false);
			this.panelVersionNotesContainer.ResumeLayout(false);
			this.panelVersionNotes.ResumeLayout(false);
			this.panelToolboxOuter.ResumeLayout(false);
			this.panelToolboxInner.ResumeLayout(false);
			this.panelRight.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region /***** Main Entry Point *****/
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// 

		[STAThread]
		static void Main() 
		{
			try
			{
				//mam - make sure the WAM.xml file has data in it (it's OK if it doesn't exist, but
				//	if it does exist, it must have data in it)
				//	Note: we could change this code to check tags and values for validity for an existing WAM.xml file!!!
				string iniPath = string.Format(@"{0}\WAM.xml", Drive.IO.Directory.GetApplicationPath());

				//mam 102309 - no longer using mdb
				//string filePath = string.Format(@"{0}\WAM.mdb", Drive.IO.Directory.GetApplicationPath());

				if (System.IO.File.Exists(iniPath))
				{
					System.IO.StreamReader reader = new System.IO.StreamReader(@iniPath);
					try   
					{    
						// if file is empty
						if (reader.Peek() == -1)
						{
							reader.Close();
							System.Text.StringBuilder builder = new System.Text.StringBuilder(100);
							builder.Append("<WAMSettings>");

							builder.Append("<Defaults>");
							builder.Append("<LastInfoSet>1</LastInfoSet>");
							builder.Append("</Defaults>");

							//mam 102309 - no longer using mdb
							//builder.Append("<DBConnection>");
							//builder.Append("<LastSource>" + @filePath + "</LastSource>");
							//builder.Append("</DBConnection>");

							//mam 01042012 - we're using the preferences form to set read-only text box color, 
							//	so there's no need to create these tags here
							////mam 12192011
							//builder.Append("<ReadOnlyBackgroundColor>");
							//builder.Append("<NumericTextBoxesRgb></NumericTextBoxesRgb>");
							//builder.Append("<AssetNameTextBoxesRgb></AssetNameTextBoxesRgb>");
							//builder.Append("<ScreenRgb></ScreenRgb>");
							//builder.Append("</ReadOnlyBackgroundColor>");

							builder.Append("</WAMSettings>");

							WAM.Common.CommonTasks.WriteXMLFile(builder.ToString(), "WAM.xml", System.IO.FileMode.OpenOrCreate);
						}
					}
					finally
					{
						reader.Close();
					}
				}
				//</mam>

				//mam 12192011
				else
				{
					//mam 12192011
					Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "NumericTextBoxesRgb", "");
					Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "AssetNameTextBoxesRgb", "");
					Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "ScreenRgb", "");
					Drive.Configuration.AppSettings.Settings.Save();
				}

				//----------------------------------------------------------
				//mam 102309 - check SQL Server database connection
				bool connSuccess = false;
				string checkDbConnString = WAM.Common.Globals.WamSqlConnectionString;
				string errorMessage = "";
				//MessageBox.Show(checkDbConnString);
				if (checkDbConnString != "")
				{
					System.Data.SqlClient.SqlConnection sqlConn = null;
					try
					{
						sqlConn = new System.Data.SqlClient.SqlConnection(checkDbConnString);
						sqlConn.Open();
						connSuccess = true;
					}
					catch(Exception ex)
					{
						errorMessage = ex.Message;
					}
					finally
					{
						if (sqlConn.State == ConnectionState.Open)
						{
							sqlConn.Close();
						}
						sqlConn = null;
					}

					if (!connSuccess)
					{
						System.Text.StringBuilder extraMessage = new System.Text.StringBuilder();
						extraMessage.Append(Environment.NewLine + Environment.NewLine 
							+ "Please check the connection string in the WAM.exe.config file.");

						//mam 03202012 - don't show this part of the message
						//extraMessage.Append(Environment.NewLine + Environment.NewLine 
						//	+ "Would you like to view the help file topic on connecting to the WAM SQL Server database?");

						if (MessageBox.Show("An error has occurred: " + errorMessage + extraMessage, 
							"Error Connecting to Database", MessageBoxButtons.YesNo, 
							MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
						{
							//open the help file to the connection string topic
							try
							{
								//MainForm thisForm = new MainForm();
								//thisForm.ShowConnectionStringHelpTopic();
								//System.Diagnostics.Process process = new System.Diagnostics.Process();
								//process.StartInfo.FileName = "WAMHelp.chm";
								//process.StartInfo.Arguments = "ConnectingToSqlServer.htm";
								//process.Start();
								System.Diagnostics.Process.Start("WAMHelp.chm");
							}
							catch (Exception ex)
							{
								MessageBox.Show("An error has occurred: " + ex.Message, 
									"Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							}
						}

						return;
					}
				}

				//mam 03202012 - determine if user has write permission
				WAM.Common.Globals.UserHasWritePermission = WAM.Common.CommonTasks.GetUserWritePermission();
				//MessageBox.Show("has write perm = " + WAM.Common.Globals.UserHasWritePermission.ToString());

				//mam 07072011
				WAM.Common.CommonTasks.LoadCriticalities();

				//----------------------------------------------------------

				//*************************

				//mam 102309 - no need to do this

				//The installation routine for version 2.1.1.0 creates a file called OriginalDataBackupXzc888.dat,
				//	which is a copy of OriginalData.dat, which has been removed by the installation routine,
				//	although it shouldn't be.  The installation routine also won't cooperate by copying/renaming
				//	OriginalDataBackupXzc888.dat to OriginalData.dat, so do it here

				//				try
				//				{
				//					//get the application path
				//					string appPath = Application.StartupPath;
				//
				//					//if the backup dat file exists, but not OriginalData.dat, make a copy
				//					if (System.IO.File.Exists(appPath + @"\OriginalDataBackupXzc888.dat")
				//						&& !System.IO.File.Exists(appPath + @"\OriginalData.dat"))
				//					{
				//						System.IO.File.Copy(appPath + @"\OriginalDataBackupXzc888.dat", appPath + @"\OriginalData.dat", false);
				//
				//						//if the copy was successful, delete OriginalDataBackupXzc888.dat
				//						if (System.IO.File.Exists(appPath + @"\OriginalDataBackupXzc888.dat")
				//							&& System.IO.File.Exists(appPath + @"\OriginalData.dat"))
				//						{
				//							System.IO.File.Delete(appPath + @"\OriginalDataBackupXzc888.dat");
				//						}
				//					}
				//				}
				//				catch
				//				{
				//				}
				//*************************

				//mam 102309 - no need to do this

				//test the connection to the database - if it fails, don't allow the app to open
				//				try
				//				{
				//					//before checking
				//
				//					//mam 102309
				//					//System.Data.OleDb.OleDbConnection sqlConnection = 
				//					//	new System.Data.OleDb.OleDbConnection(WAM.Data.WAMSource.CurrentSource.ConnectionString);
				//					System.Data.SqlClient.SqlConnection sqlConnection = 
				//						new System.Data.SqlClient.SqlConnection(Globals.WamSqlConnectionString);
				//
				//					sqlConnection.Open();
				//					sqlConnection.Close();
				//				}
				//				catch(Exception ex)
				//				{
				//					System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
				//					builder.Append("An error has occurred.  The application cannot open because the database");
				//					builder.Append("\r\n\r\n");
				//					builder.AppendFormat(@"'{0}'", WAM.Data.WAMSource.CurrentSource.DataPath.ToString());
				//					builder.Append("\r\n\r\ncannot be found.");
				//					MessageBox.Show(builder.ToString(), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
				//					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//					return;
				//				}

				//mam 102309 - no need to do this
				//				//verify that the database is a valid WAM database - if it isn't, don't allow the app to open
				//				WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();
				//				if (!verify.VerifyTableNamesAndFields(WAM.Data.WAMSource.CurrentSource.DataPath.ToString()))
				//				{
				//					System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
				//					builder.Append("An error has occurred.  The Water and Wastewater Asset Manager cannot open because the database");
				//					builder.Append("\r\n\r\n");
				//					builder.AppendFormat(@"'{0}'", WAM.Data.WAMSource.CurrentSource.DataPath.ToString());
				//					builder.Append("\r\n\r\nis not in the proper format.");
				//					MessageBox.Show(builder.ToString(), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
				//					return;
				//				}

				//mam 102309 - disable
				//				try
				//				{
				//					WAM.Common.Update4 update4 = new WAM.Common.Update4(WAM.Data.WAMSource.CurrentSource.DataPath);
				//					bool resultUpdate4 = update4.PerformUpdate();
				//					update4 = null;
				//				}
				//				catch
				//				{
				//				}

				//mam 102309 - disable
				//mam - perform database updates
				//bool resultUpdate = false;


				//mam 102309 - don't perform updates for now
				//				WAM.Common.Update1 update1 = new WAM.Common.Update1(WAM.Data.WAMSource.CurrentSource.ConnectionString);
				//				resultUpdate = update1.PerformUpdate();
				//				update1 = null;
				//
				//				WAM.Common.Update2 update2 = new WAM.Common.Update2(WAM.Data.WAMSource.CurrentSource.ConnectionString);
				//				resultUpdate = update2.PerformUpdate();
				//				update2 = null;
				//
				//				WAM.Common.Update3 update3 = new WAM.Common.Update3(WAM.Data.WAMSource.CurrentSource.ConnectionString);
				//				resultUpdate = update3.PerformUpdate();
				//				update3 = null;
				//
				//				WAM.Common.Update4 update4All = new WAM.Common.Update4("");
				//				resultUpdate = update4All.PerformUpdate();
				//				update4All = null;

				//</mam>

				// Show splash screen
				SplashScreenForm form = new SplashScreenForm();

				form.Show();

				WAM.Data.CacheManager.GetCacheForInfoSetID(InfoSet.CurrentID);
				form.Close();
				form.Dispose();

				mainForm = new MainForm();
				try
				{
					Application.Run(mainForm);
				}
				catch(Exception ex)
				{
					WAM.Common.CommonTasks.ShowErrorMessage("MainForm", "An error has occurred: " + ex.Message);
				}
			}
			catch(Exception ex)
			{
				//System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
				WAM.Common.CommonTasks.ShowErrorMessage("MainForm", "An error has occurred: " + ex.Message);
			}
		}

		#endregion /***** Main Entry Point *****/

		#region /***** Methods *****/

		//mam 11142011
		private void AllowContinueAccessImport(bool continueImport)
		{
			this.continueImport = continueImport;
		}

		public static bool CreateWAMDatabaseFile()
		{
			//mam 102309 - no need to do this
			return true;

			//			try
			//			{
			//				//always create a WAM.mdb file if one doesn't exist - preferably from OriginalData.dat, 
			//				//	but if that doesn't exist, then use FreshWAM.dat from the app folder or, if that
			//				//	doesn't exist, use the embedded FreshWAM.dat
			//
			//				// Check whether WAM.mdb already exists
			//				string dbPath = string.Format(@"{0}\WAM.mdb", Drive.IO.Directory.GetApplicationPath());
			//
			//				//if there is no WAM.mdb database, create it
			//				if (!System.IO.File.Exists(dbPath))
			//				{
			//					//mam - copy the database that contains the fixed infoset, if it exists, rather than copying FreshWAM.dat
			//					string dbClean = string.Format(@"{0}\FreshWAM.dat", Drive.IO.Directory.GetApplicationPath());
			//					string dbCleanFixed = string.Format(@"{0}\OriginalData.dat", Drive.IO.Directory.GetApplicationPath());
			//
			//					//if neither OriginalData.dat or FreshWAM.dat files are in the application folder, use the embedded FreshWAM.dat
			//					if (!System.IO.File.Exists(dbClean) && !System.IO.File.Exists(dbCleanFixed))
			//					{
			//						string fileName = "";
			//						fileName = string.Format(@"{0}\WAM.mdb", Drive.IO.Directory.GetApplicationPath());
			//
			//						try
			//						{
			//							System.Reflection.Assembly thisExeWAM = System.Reflection.Assembly.GetExecutingAssembly();
			//							Stream stream = thisExeWAM.GetManifestResourceStream("WAM.Files.FreshWAM.dat");
			//							byte[] byteArray = ReadFully(stream, 0);
			//							FileStream fileStream = new FileStream(fileName, System.IO.FileMode.CreateNew);
			//							BinaryWriter binaryWriter = new BinaryWriter(fileStream);
			//							binaryWriter.Write(byteArray);
			//							binaryWriter.Flush();
			//							binaryWriter.Close();
			//
			//							if (stream != null)
			//								stream.Close();
			//
			//							if (fileStream != null)
			//								fileStream.Close();
			//
			//							byteArray = null;
			//						}
			//						catch(Exception ex)
			//						{
			//							System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			//						}
			//						finally
			//						{
			//						}
			//					}
			//					else
			//					{
			//						//if OriginalData.dat exists, use it to create WAM.mdb
			//						if (System.IO.File.Exists(dbCleanFixed))
			//						{
			//							try
			//							{
			//								//create WAM.db based on the fixed data database
			//								System.IO.File.Copy(dbCleanFixed, dbPath, true);
			//
			//								//set the WAM.mdb file attributes to normal
			//								System.IO.File.SetAttributes(dbPath, 
			//									System.IO.FileAttributes.Normal);
			//
			//								//update the newly-created database with the image folder name
			//								WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			//								string connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(dbPath);
			//
			//								//it shouldn't be necessary to create the DatabaseInfo table, as the OriginalData database
			//								//	should be an up-to-date database with all new tables and fields
			//								dataAccess.ExecuteCommand(
			//									@"CREATE TABLE DatabaseInfo (DatabaseImageFolder VARCHAR (255) WITH COMPRESSION)", 
			//									connectionString);
			//								dataAccess.ExecuteCommand(
			//									"UPDATE DatabaseInfo SET DatabaseImageFolder = 'WAM'", connectionString);
			//							}
			//							catch(Exception ex)
			//							{
			//								System.Diagnostics.Debug.WriteLine("Error in startup regarding OriginalData.dat.  " + ex.Message.ToString());
			//							}
			//						}
			//						else
			//						{
			//							//use FreshWAM.dat to create WAM.mdb
			//							try
			//							{
			//								//create WAM.db based on the fresh wam database
			//								System.IO.File.Copy(dbClean, dbPath, true);
			//
			//								//set the WAM.mdb file attributes to normal
			//								System.IO.File.SetAttributes(dbPath, 
			//									System.IO.FileAttributes.Normal);
			//							}
			//							catch(Exception ex)
			//							{
			//								System.Diagnostics.Debug.WriteLine("Error in startup regarding FreshWam.mdb.  " + ex.Message.ToString());
			//							}
			//						}
			//					}
			//
			//					//					//make sure the WAM.mdb file was created
			//					//					if (!System.IO.File.Exists(dbPath))
			//					//					{
			//					//						MessageBox.Show("Unable to find database.", "Database Not Found",
			//					//							MessageBoxButtons.OK, MessageBoxIcon.Stop);
			//					//						return;
			//					//					}
			//				}
			//			}
			//			catch(Exception ex)
			//			{
			//				System.Diagnostics.Debug.Assert(false, ex.Message.ToString());
			//				return false;
			//			}
			//
			//			return true;
		}

		private static byte[] ReadFully (Stream stream, int initialLength)
		{
			// If we've been passed an unhelpful initial length, just use 32K.
			if (initialLength < 1)
			{
				initialLength = 32768;
			}
    
			byte[] buffer = new byte[initialLength];
			int read=0;
    
			int chunk;
			while ( (chunk = stream.Read(buffer, read, buffer.Length-read)) > 0)
			{
				read += chunk;
        
				// If we've reached the end of our buffer, check to see if there's any more information
				if (read == buffer.Length)
				{
					int nextByte = stream.ReadByte();
            
					// End of stream? If so, we're done
					if (nextByte==-1)
					{
						return buffer;
					}
            
					// Nope. Resize the buffer, put in the byte we've just read, and continue
					byte[] newBuffer = new byte[buffer.Length*2];
					Array.Copy(buffer, newBuffer, buffer.Length);
					newBuffer[read]=(byte)nextByte;
					buffer = newBuffer;
					read++;
				}
			}
			// Buffer is now too big. Shrink it.
			byte[] ret = new byte[read];
			Array.Copy(buffer, ret, read);
			return ret;
		}
		public static Form	AppForm
		{
			get { return mainForm; }
		}

		//mam
		public static bool viewEquation
		{
			get { return eqnFormOpen; }
			set { eqnFormOpen = value; }
		}
		//</mam>

		//mam
		public bool viewEquation2
		{
			get { return eqnFormOpen; }
			set 
			{ 
				eqnFormOpen = value; 
				if (!eqnFormOpen)
				{
					UpdateEquationControls();
				}
			}
		}
		//</mam>

		private void GetOptionSettingsFromFile()
		{
			int roundPerform = 0;
			int roundDigit = 0;
			int graphMatch = 0;
			int showTab = 0;
			int showFacValTab = 0;
			try
			{
				roundPerform = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "Rounding", 0);
				roundDigit = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "RoundingDigit", 4);

				graphMatch = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "GraphNameMatching", 0);
				showTab = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "DisplayCostTab", 0);
				showFacValTab = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "DisplayFacValTab", 0);
			}
			catch
			{
				roundPerform = 0;
				roundDigit = 4;

				graphMatch = 1;
				graphMatch = 0;
			}
			
			if (roundPerform != 0 && roundPerform != 1)
				roundPerform = 0;
			if (roundDigit.ToString().Length != 1)
				roundDigit = 4;
			if ("0123456789".IndexOf(roundDigit.ToString()) == -1)
				roundDigit = 4;

			if (graphMatch != 0 && graphMatch != 1)
				graphMatch = 1;
			if (showTab != 0 && showTab != 1)
				showTab = 0;
			if (showFacValTab != 0 && showFacValTab != 1)
				showFacValTab = 0;

			WAM.Common.Globals.AllowRounding = Convert.ToBoolean(roundPerform);
			WAM.Common.Globals.AllowRoundingDigit = roundDigit;

			WAM.Common.Globals.AllowGraphNameMatching = Convert.ToBoolean(graphMatch);
			WAM.Common.Globals.ShowCostTab = Convert.ToBoolean(showTab);
			WAM.Common.Globals.ShowFacilityValuationTab = Convert.ToBoolean(showFacValTab);

			//************************************

			//mam 01042012
			//this defaults to true, but let's set it to true here just in case the default ever changes
			//why set it here? -  just leave the default as is
			//WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets = true;
			try
			{
				string showZero = Drive.Configuration.AppSettings.Settings.GetSetting("RetiredAssets", "ShowCostsZero").Trim();
				if (showZero != null && (string.Compare(showZero, "false", true) == 0 || showZero == "0"))
				{
					//only set it to false if the value in the WAM.xml file is "false" or "0"
					WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets = false;
				}
			}
			catch
			{
				//we don't care why or if it failed
			}

			//why do this here? - it is not necessary
			//Drive.Configuration.AppSettings.Settings.SetSetting(@"RetiredAssets", "ShowCostsZero", WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets.ToString());

			//************************************

			//mam 01222012
			int useFacCrit = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "FacilityCriticality", 1);
			WAM.Common.Globals.ApplyFacilityCriticalityFactor = useFacCrit == 1 ? true : false;

			//************************************

			//mam 03202012
			int wamSetPhotoFileName = Drive.Configuration.AppSettings.Settings.GetSettingInt("Options", "WamSetPhotoFileName", 1);
			WAM.Common.Globals.AllowWamToCreatePhotoFileNames = wamSetPhotoFileName == 1 ? true : false;

			//************************************

			//mam 01042012 - updated this to use preferences form
			//mam 12192011
			//var rgbRegex = /^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/;
			//Regex regex = new Regex(@"^\$?(\d{1,3}(\,\d{3})*|(\d+)|(\d{0}))(\.\d{" + numberOfDecimals + "})?$");

			WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric = false;
			WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames = false;
			WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen = false;

			//Regex regexRgb = new Regex(@"/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/");
			//Regex regexRgb = new Regex(@"^\(\d+),(\d+),(\d+)$");
			//Regex regex = new Regex("[1-9][0-9][0-9][0-9]");
			Regex regexRgb = new Regex(@"^\b(\d+),(\d+),(\d+)\b");

			//string readOnlyNumericRgb = string.Empty;
			//string readOnlyAssetNamesRgb = string.Empty;
			//string readOnlyScreenRgb = string.Empty;
			string readOnlyRgb = string.Empty;

			Color color;
			bool useCustomColor = false;

			try
			{
				string useCustom = Drive.Configuration.AppSettings.Settings.GetSetting("ReadOnlyBackgroundColor", "UseCustomColor").Trim();
				if (useCustom != null && useCustom != "" && (string.Compare(useCustom, "true", true) == 0 || useCustom == "1"))
				{
					//only set it to true if the value in the WAM.xml file is "true" or "1"
					useCustomColor = true;
				}
			}
			catch
			{
				//we don't care why or if it failed
			}

			//if (useCustomColor)
			{
				try
				{
					readOnlyRgb = Drive.Configuration.AppSettings.Settings.GetSetting("ReadOnlyBackgroundColor", "NumericTextBoxesRgb");
					readOnlyRgb = readOnlyRgb.Replace(" ", "");
					//MessageBox.Show("readOnlyNumericRgb = " + readOnlyNumericRgb);
					Match match = regexRgb.Match(readOnlyRgb);
					//MessageBox.Show("match success = " + match.Success.ToString());
					if (match.Success)
					{
						string[] rgb = readOnlyRgb.Split(',');
						color = Color.FromArgb(Convert.ToInt32(rgb[0]), Convert.ToInt32(rgb[1]), Convert.ToInt32(rgb[2]));
						WAM.Common.Globals.ReadOnlyBackgroundColorNumeric = color;
						WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric = useCustomColor;
					}
				}
				catch
				{
					//we don't care why or if it failed
				}

				try
				{
					readOnlyRgb = Drive.Configuration.AppSettings.Settings.GetSetting("ReadOnlyBackgroundColor", "AssetNameTextBoxesRgb");
					readOnlyRgb = readOnlyRgb.Replace(" ", "");
					Match match = regexRgb.Match(readOnlyRgb);
					if (match.Success)
					{
						string[] rgb = readOnlyRgb.Split(',');
						color = Color.FromArgb(Convert.ToInt32(rgb[0]), Convert.ToInt32(rgb[1]), Convert.ToInt32(rgb[2]));
						WAM.Common.Globals.ReadOnlyBackgroundColorAssetNames = color;
						WAM.Common.Globals.ApplyReadOnlyBackgroundColorAssetNames = useCustomColor;
					}
				}
				catch
				{
					//we don't care why or if it failed
				}
				try
				{
					readOnlyRgb = Drive.Configuration.AppSettings.Settings.GetSetting("ReadOnlyBackgroundColor", "ScreenRgb");
					readOnlyRgb = readOnlyRgb.Replace(" ", "");
					Match match = regexRgb.Match(readOnlyRgb);
					if (match.Success)
					{
						string[] rgb = readOnlyRgb.Split(',');
						color = Color.FromArgb(Convert.ToInt32(rgb[0]), Convert.ToInt32(rgb[1]), Convert.ToInt32(rgb[2]));
						WAM.Common.Globals.ReadOnlyBackgroundColorScreen = color;
						
						useCustomColor = false;
						string useCustomColorScreen = Drive.Configuration.AppSettings.Settings.GetSetting("ReadOnlyBackgroundColor", "UseCustomColorScreen").Trim();
						if (useCustomColorScreen != null && useCustomColorScreen != "" && (string.Compare(useCustomColorScreen, "true", true) == 0 || useCustomColorScreen == "1"))
						{
							//only set it to true if the value in the WAM.xml file is "true" or "1"
							useCustomColor = true;
						}

						WAM.Common.Globals.ApplyReadOnlyBackgroundColorScreen = useCustomColor;
					}
				}
				catch
				{
					//we don't care why or if it failed
				}
			}
			//************************************
		}
		//</mam>

		protected override void OnClosing(CancelEventArgs e)
		{
			// Save our form state
			Drive.Configuration.FormState formState = 
				new Drive.Configuration.FormState(this);

			Drive.Configuration.AppSettings.Settings.
				SetSetting(@"ScreenSettings", 
				"MainForm", formState.ToString());

			facilityControl1.SaveOptions();

			//mam - setting all sub-controls to null (below) doesn't necessarily work, so call 
			//	SaveCurrentDisplay() to save the current form
			SaveCurrentDisplay();
			//</mam>

			// Set all sub-controls to null so that they will save their
			// information
			infoSetControl1.SetInfoSet(null);
			facilityControl1.SetFacility(null);
			treatmentProcessControl1.SetProcess(null);
			majorComponentControl1.SetComponent(null);
			disciplineMechControl1.SetDiscipline(null);
			disciplineStructControl1.SetDiscipline(null);
			disciplineLandControl1.SetDiscipline(null);
			disciplineNodesControl1.SetDiscipline(null);
			disciplinePipeControl1.SetDiscipline(null);
			assetListControl1.SetComponent(null);

			base.OnClosing(e);
		}

		protected override void OnLoad(EventArgs e)
		{
			try
			{
				Drive.Configuration.FormState formState = 
					new Drive.Configuration.FormState(
					Drive.Configuration.AppSettings.
					Settings.GetSetting("ScreenSettings",
					"MainForm"));
				formState.RestoreState(this);
				CheckFormProperties();

				//mam 03202012
				this.menuItemFile_Import_InfoSet.Text = "Import from a WAM Access Database";
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("MainForm.OnLoad Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.OnDataChanged));
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.OnDataChanged));

			// Set up the toolbar
			System.IO.Stream file = thisExe.GetManifestResourceStream("WAM.Graphics.WAMToolbar.bmp");

			// Set up the app icon
			//mam - change icon to one that looks a little better
			//file = thisExe.GetManifestResourceStream("WAM.Graphics.WAMApp.ico");
			file = thisExe.GetManifestResourceStream("WAM.Graphics.Logo1632.ico");
			this.Icon = new Icon(file);

			disciplineMechControl1.ViewAssets += 
				new DisciplineMechControl.ViewAssetHandler(this.OnViewAssets);

			treeViewFacility.ImageList = this.imageListTree;
			treeViewFacility.ImageIndex = 1;
			treeViewFacility.SelectedImageIndex = 1;

			PopulateTree();

			treeViewFacility_AfterSelect(null, null);

			//mam 102309 - don't display database name
			//			//mam
			//			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			//			string currentDB = commonTasks.GetCurrentDatabaseName(true);
			//			if (currentDB == "")
			//			{
			//				this.textBoxCurrentDatabase.Text = "No database found";
			//			}
			//			else
			//			{
			//				this.textBoxCurrentDatabase.Text = currentDB;
			//			}
			//			//</mam>

			//mam 11142011 - instead, display WAM version and build date
			this.textBoxCurrentDatabase.Text = string.Format(" WAM {0}", Application.ProductVersion.ToString().Substring(0, 5));
			try
			{
				object[] assembyConfigAttribute = System.Reflection.Assembly.GetEntryAssembly().GetCustomAttributes(typeof(System.Reflection.AssemblyConfigurationAttribute), false);
				if (assembyConfigAttribute.Length > 0) 
				{
					System.Reflection.AssemblyConfigurationAttribute item = (System.Reflection.AssemblyConfigurationAttribute)assembyConfigAttribute[0];
					DateTime buildDate = DateTime.Parse(item.Configuration);
					textBoxCurrentDatabase.Text += string.Format("      Build Date: {0}", buildDate.ToString("MM/dd/yyyy"));
				}

				//mam 11142011
				SetVersionNotes();
			}
			catch
			{
				//we don't care why or if it failed
			}

			//mam
			SetToolTips();
			//</mam>

			//create the FieldSheet.xml file
			try
			{
				WAM.Common.StartUpChores startUpChores = new WAM.Common.StartUpChores();
				startUpChores.CreateFieldSheetFileFromDatabase();

				//mam 102309 - no need to do this
				//string imagePath = Drive.IO.Directory.GetApplicationPath();
				//imagePath = string.Format(@"{0}\Images", imagePath);
				//imagePath += @"\" + treeViewFacility.Nodes[0].Text;
				//currentDatabaseImageFolder = startUpChores.SetDatabaseImageFolderName(@imagePath);
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}

			//mam - set control availability depending on whether infoset is editable or not
			SetControls();
			SetBitmaps();
			if (treeViewFacility.Nodes.Count > 0 && treeViewFacility.Nodes[0].Nodes.Count > 0)
				treeViewFacility.SelectedNode = treeViewFacility.Nodes[0].Nodes[0];
			//</mam>

			//mam 11142011 - set this visible for testing only
			//buttonTest.Visible = true;

			//mam 03202012
			WAM.Common.Globals.SortedListExportImportTabNames.Clear();
			WAM.Common.Globals.SortedListExportImportTabNames.Add(0, "WAM Facility");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(1, "WAM Process");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(2, "WAM Comp MSC");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(3, "WAM Comp PN");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(4, "WAM Disc Mech");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(5, "WAM Disc Struct");
			WAM.Common.Globals.SortedListExportImportTabNames.Add(6, "WAM Disc Civil");

			base.OnLoad(e);
		}

		//mam 11142011
		private void SetVersionNotes()
		{
			textBoxVersionNotes.ReadOnly = true;
			textBoxCurrentDatabase.Click += new EventHandler(textBoxCurrentDatabase_Click);
			panelVersionNotes.Click += new EventHandler(panelVersionNotes_Click);
			panelVersionNotesContainer.Click += new EventHandler(panelVersionNotes_Click);
			labelVersionNotes.Click += new EventHandler(labelVersionClose_Click);
			labelVersionClose.Click += new EventHandler(labelVersionClose_Click);

			string stringNotes = string.Empty;
			System.Text.StringBuilder builder = new System.Text.StringBuilder();

			//4.0
			builder.Append("Version 4.0:" + Environment.NewLine + "Moved from Access to SQL Server database.");

			//4.1.0
			stringNotes = "Modified criticalities; added Rehabilitation fields, Planning Mode, and Asset Class; modified SQL Server database.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.1:" + Environment.NewLine + stringNotes);

			//4.1.1
			stringNotes = "Allowed user mapping of criticalities from Access to SQL Server when importing from Access database; changed Carollo logo.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.1.1:" + Environment.NewLine + stringNotes);

			//4.1.2
			stringNotes = "Corrected Discipline photo display.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.1.2:" + Environment.NewLine + stringNotes);

			//4.1.3
			stringNotes = "Additional correction to Discipline photo display.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.1.3:" + Environment.NewLine + stringNotes);

			//mam 01222012
			//4.2.0
			stringNotes = "Added Facility Criticality, added Constraint Viewer, added Rehabilitation and Replacement fields,"
				+ " modified Rehabiliation and and Replacement calculations, added timing constraints,"
				+ " set retired asset costs to zero in reports, custom background color for read-only text boxes.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.2:" + Environment.NewLine + stringNotes);

			//mam 03202012
			//4.3.0
			stringNotes = "Added user-named photos, 'Import Format' report.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.3:" + Environment.NewLine + stringNotes);

			//mam 06212012
			//4.3.1
			stringNotes = "Reduced time to open report screen.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.3.1:" + Environment.NewLine + stringNotes);

			//mam 10112014
			//4.3.2
			stringNotes = "Cleared all cells in the WAM import grid prior to loading a new Excel file into the import grid.";
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.3.2:" + Environment.NewLine + stringNotes);

			//mam 10112014
			//4.3.3
			stringNotes = "Increased the maximum allowed value for Mechanical Discipline Run Hours in the import grid from 32,767 to 2,147,483,647.";
			builder.Append(Environment.NewLine + "Access the import grid by clicking");
			builder.Append(Environment.NewLine + "File > Import > ImportFromExcelFile");
			builder.Append(Environment.NewLine + "in the menu.");
			builder.Append(Environment.NewLine + Environment.NewLine + "Version 4.3.3:" + Environment.NewLine + stringNotes);

			textBoxVersionNotes.Text = builder.ToString();
		}

		//mam
		private void CheckFormProperties()
		{
			if (this.WindowState == FormWindowState.Minimized || this.Width < 250 || this.Height < 150 )
			{
				try
				{
					this.WindowState = FormWindowState.Normal;
					this.Size = new Size(620, 520);
					splitter1.SplitPosition = 200;
				}
				catch
				{
				}
			}
			if (Math.Abs(this.Left) > 2000 || Math.Abs(this.Top) > 2000)
			{
				try
				{
					this.Left = 0;
					this.Top = 0;
				}
				catch
				{
				}
			}
		}
		//</mam>

		//mam
		private void messageSelectedDatabase(string selDB)
		{
			databaseToLoad = selDB;
		}
		//</mam>

		//mam
		private void SetToolTips()
		{
			// Set up the delays for the ToolTip.
			//toolTip.AutoPopDelay = 2500;
			//toolTip.InitialDelay = 500;
			//toolTip.ReshowDelay = 0;

			toolTip.AutoPopDelay = 0;
			toolTip.InitialDelay = 0;
			toolTip.ReshowDelay = 0;

			// Force the ToolTip text to be displayed whether or not the form is active.
			toolTip.ShowAlways = true;
      
			// Set up the ToolTip text for the Button and Checkbox.
			toolTip.SetToolTip(this.pictureBoxToolbarAdd, "Add a new Facility");
			toolTip.SetToolTip(this.pictureBoxToolbarCopy, "Copy the selected item");

			//mam 11142011 - change this to the version information
			//toolTip.SetToolTip(this.textBoxCurrentDatabase, "The currently loaded database");
			toolTip.SetToolTip(this.textBoxCurrentDatabase, "Click for information on WAM versions");

			//mam 11142011 - new tool tip
			toolTip.SetToolTip(this.labelVersionClose, "Click to hide version information");

			toolTip.SetToolTip(this.pictureBoxToolbarDelete, "Delete the selected item");
			toolTip.SetToolTip(this.pictureBoxToolbarPreferences, "Display the user preferences");
			toolTip.SetToolTip(this.pictureBoxToolbarEquationBox, "Show the Equation Viewer");
			toolTip.SetToolTip(this.pictureBoxToolbarHelp, "Help");
		}
		//</mam>

		//mam
		private void SetToolTips(NodeType nodeType)
		{
			switch (nodeType)
			{
				case NodeType.InfoSet:
					toolTip.SetToolTip(this.pictureBoxToolbarAdd, 
						string.Format("Add {0}...", NodeTypeHandler.GetNodeTypeString(nodeType + 1)));
					break;
				case NodeType.Facility:
					toolTip.SetToolTip(this.pictureBoxToolbarAdd, 
						string.Format("Add {0}...", NodeTypeHandler.GetNodeTypeString(nodeType + 1)));
					toolTip.SetToolTip(this.pictureBoxToolbarCopy, 
						string.Format("Copy {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					toolTip.SetToolTip(this.pictureBoxToolbarDelete, 
						string.Format("Delete {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					break;
				case NodeType.TreatmentProcess:
					toolTip.SetToolTip(this.pictureBoxToolbarAdd, 
						string.Format("Add {0}...", NodeTypeHandler.GetNodeTypeString(nodeType + 1)));
					toolTip.SetToolTip(this.pictureBoxToolbarCopy, 
						string.Format("Copy {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					toolTip.SetToolTip(this.pictureBoxToolbarDelete, 
						string.Format("Delete {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					break;
				case NodeType.MajorComponent:
					toolTip.SetToolTip(this.pictureBoxToolbarCopy, 
						string.Format("Copy {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					toolTip.SetToolTip(this.pictureBoxToolbarDelete, 
						string.Format("Delete {0}", NodeTypeHandler.GetNodeTypeString(nodeType)));
					break;
				default:
					break;
			}
		}
		//</mam>

		private void		OnViewAssets(object sender, EventArgs e)
		{
			TreeNode		assetNode = null;

			if (sender is Discipline)
			{
				if (treeViewFacility.SelectedNode != null)
				{
					if (object.ReferenceEquals(sender, treeViewFacility.SelectedNode.Tag))
						assetNode = treeViewFacility.SelectedNode.Nodes[0];
				}

				if (assetNode == null)
				{
					assetNode = FindDisciplineNode((Discipline)sender);
					if (assetNode != null)
						assetNode = assetNode.Nodes[0];
					else
						assetNode = null;
				}
			}

			if (assetNode != null)
				treeViewFacility.SelectedNode = assetNode;
		}

		//mam 03202012
		public bool RenameFacilityNode(int facilityId, string facilityName)
		{
			try
			{
				if (treeViewFacility.Nodes.Count < 1)
				{
					return false;
				}

				TreeNode root = treeViewFacility.Nodes[0];
				TreeNode facilityNode = root.FirstNode;

				while (facilityNode != null)
				{
					if (facilityNode.Tag != null && ((Facility)facilityNode.Tag).ID == facilityId)
					{
						//change node text
						((Facility)facilityNode.Tag).Name = facilityName;
						facilityNode.Text = facilityName;

						//if the facility node is selected, change the facility name in the facility form text box
						TreeNode node = treeViewFacility.SelectedNode;
						if (node != null && node.Tag is Facility && ((Facility)node.Tag).ID == facilityId)
						{
							facilityControl1.SetFacilityNameTextBox(facilityName);
						}

						return true;
					}

					facilityNode = facilityNode.NextNode;
				}
			}
			catch(Exception ex)
			{
				throw ex;
			}

			return false;
		}

		//mam 03202012
		public bool RenameTreatmentProcessNode(int facilityId, int processId, string processName)
		{
			try
			{
				// Find the parent node
				TreeNode facilityNode = FindFacilityNode(facilityId);
				if (facilityNode == null)
				{
					return false;
				}

				TreeNode processNode = facilityNode.FirstNode;
				while (processNode != null)
				{
					if (processNode.Tag != null && ((TreatmentProcess)processNode.Tag).ID == processId)
					{
						//change node text
						((TreatmentProcess)processNode.Tag).Name = processName;
						processNode.Text = processName;

						//if the process node is selected, change the process name in the process form text box
						TreeNode node = treeViewFacility.SelectedNode;
						if (node != null && node.Tag is TreatmentProcess && ((TreatmentProcess)node.Tag).ID == processId)
						{
							treatmentProcessControl1.SetProcessNameTextBox(processName);
						}

						return true;
					}

					processNode = processNode.NextNode;
				}
			}
			catch(Exception ex)
			{
				throw ex;
			}

			return false;
		}

		//mam 03202012
		public bool RenameMajorComponentNode(int processId, int componentId, string componentName)
		{
			try
			{
				// Find the parent node
				TreeNode processNode = FindTreatmentProcessNode(processId);
				if (processNode == null)
				{
					return false;
				}

				TreeNode componentNode = processNode.FirstNode;
				while (componentNode != null)
				{
					if (componentNode.Tag != null && ((MajorComponent)componentNode.Tag).ID == componentId)
					{
						//change node text
						((MajorComponent)componentNode.Tag).Name = componentName;
						componentNode.Text = componentName;

						//if the component node is selected, change the component name in the component form text box
						TreeNode node = treeViewFacility.SelectedNode;
						if (node != null && node.Tag is MajorComponent && ((MajorComponent)node.Tag).ID == componentId)
						{
							majorComponentControl1.SetComponentNameTextBox(componentName);
						}

						return true;
					}

					componentNode = componentNode.NextNode;
				}
			}
			catch(Exception ex)
			{
				throw ex;
			}

			return false;
		}

		private TreeNode	FindFacilityNode(int facilityID)
		{
			if (treeViewFacility.Nodes.Count < 1)
				return null;

			TreeNode		root = treeViewFacility.Nodes[0];
			TreeNode		facilityNode = root.FirstNode;

			while (facilityNode != null)
			{
				if (facilityNode.Tag != null && 
					((Facility)facilityNode.Tag).ID == facilityID)
					return facilityNode;

				facilityNode = facilityNode.NextNode;
			}

			return null;
		}

		private TreeNode	FindTreatmentProcessNode(int processID)
		{
			TreatmentProcess process;
			TreeNode		facilityNode;
			TreeNode		processNode;

			process = CacheManager.GetTreatmentProcess(InfoSet.CurrentID, processID);
			if (process == null)
				return null;

			// Find the parent node
			facilityNode = FindFacilityNode(process.FacilityID);
			if (facilityNode == null)
				return null;

			// Look through the children of the facility
			processNode = facilityNode.FirstNode;
			while (processNode != null)
			{
				if (processNode.Tag != null && 
					((TreatmentProcess)processNode.Tag).ID == processID)
					return processNode;

				processNode = processNode.NextNode;
			}

			return null;
		}

		private TreeNode	FindMajorComponentNode(int componentID)
		{
			MajorComponent	component;
			TreeNode		processNode;
			TreeNode		componentNode;

			component = CacheManager.GetMajorComponent(InfoSet.CurrentID, componentID);
			if (component == null)
				return null;

			// Find the parent node
			processNode = FindTreatmentProcessNode(component.ProcessID);
			if (processNode == null)
				return null;

			// Look through the children of the process
			componentNode = processNode.FirstNode;
			while (componentNode != null)
			{
				if (componentNode.Tag != null && 
					((MajorComponent)componentNode.Tag).ID == componentID)
					return componentNode;

				componentNode = componentNode.NextNode;
			}
			return null;
		}

		private TreeNode	FindDisciplineNode(Discipline discipline)
		{
			TreeNode		componentNode =
				FindMajorComponentNode(discipline.ComponentID);
			TreeNode		disciplineNode;

			if (componentNode == null)
				return null;

			// Look through the disciplines
			disciplineNode = componentNode.FirstNode;	
			while (disciplineNode != null)
			{
				if (disciplineNode.Tag != null && 
					((Discipline)disciplineNode.Tag).Type == discipline.Type)
					return disciplineNode;

				disciplineNode = disciplineNode.NextNode;
			}
			return null;
		}

		//mam 07072011 - new method
		public bool SetNodeTagFacility(Facility fac, Facility facSet)
		{
			TreeNode nodeFound = FindFacilityNode(fac.ID);
			nodeFound.Tag = facSet;

			return true;
		}

		//mam 07072011 - new method
		public bool SetNodeTagTreatmentProcess(TreatmentProcess proc, TreatmentProcess procSet)
		{
			TreeNode nodeFound = FindTreatmentProcessNode(proc.ID);
			nodeFound.Tag = procSet;

			return true;
		}

		//mam 07072011 - new method
		public bool SetNodeTagMajorComponent(MajorComponent comp, MajorComponent compSet)
		{
			TreeNode nodeFound = FindMajorComponentNode(comp.ID);
			nodeFound.Tag = compSet;

			return true;
		}

		//mam 07072011 - new method
		public bool SetNodeTagDiscipline(Discipline disc, Discipline discSet)
		{
			TreeNode nodeFound = FindDisciplineNode(disc);
			nodeFound.Tag = discSet;

			return true;
		}

		//mam 102309
		//private void OnDataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void OnDataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			if (e.Action == Drive.Synchronization.SyncAction.Delete)
				return;

			if (e.ChangedObject is Facility)
			{
				Facility	facility = ((Facility)e.ChangedObject);

				// Update the facility node in the tree
				TreeNode	node = FindFacilityNode(facility.ID);

				if (node != null && node.Text != facility.Name)
					node.Text = facility.Name;
			}
			else if (e.ChangedObject is TreatmentProcess)
			{
				TreatmentProcess process = ((TreatmentProcess)e.ChangedObject);

				// Update the facility node in the tree
				TreeNode	node = FindTreatmentProcessNode(process.ID);

				if (node != null && node.Text != process.Name)
					node.Text = process.Name;
			}
			else if (e.ChangedObject is MajorComponent)
			{
				MajorComponent component = ((MajorComponent)e.ChangedObject);

				// Update the facility node in the tree
				TreeNode	node = FindMajorComponentNode(component.ID);

				if (node != null && node.Text != component.Name)
					node.Text = component.Name;
			}
			else if (e.ChangedObject is Discipline)
			{
				Discipline	discipline = ((Discipline)e.ChangedObject);
				TreeNode	node = FindDisciplineNode(discipline);

				if (node != null)
				{
					if (discipline.ConditionRanking == CondRank.No)
						node.ForeColor = Color.FromArgb(255, 0, 0);
					else
						node.ForeColor = Color.FromArgb(0, 0, 0);
				}
			}
		}

		private void		menuItemEdit_AddFacility_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			PerformPreAddTasks();
			AddFacility(string.Empty, false);
		}

		private void menuItemEdit_AddNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			PerformPreAddTasks();
			AddNode();
		}

		//mam
		private void menuItemEdit_CopyNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to copy data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			CopyNode();
		}
		//</mam>

		private void menuItemEdit_DeleteNode_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			DeleteNode();
		}

		//mam 11142011
		private void textBoxCurrentDatabase_Click(object sender, EventArgs e)
		{
			int locX = textBoxCurrentDatabase.Location.X + 3;
			int locY = textBoxCurrentDatabase.Location.Y - panelVersionNotesContainer.Height - 8;
			panelVersionNotesContainer.Location = new System.Drawing.Point(locX, locY);
			panelVersionNotesContainer.Visible = !panelVersionNotesContainer.Visible;
		}
		private void panelVersionNotes_Click(object sender, EventArgs e)
		{
			panelVersionNotesContainer.Visible = !panelVersionNotesContainer.Visible;
		}
		private void labelVersionClose_Click(object sender, EventArgs e)
		{
			panelVersionNotesContainer.Visible = false;
		}
		//</mam>

		private NodeType	GetSelectedNodeType()
		{
			if (treeViewFacility.SelectedNode == null)
				return NodeType.NoneSelected;

			TreeNode		node = treeViewFacility.SelectedNode;

			if (node.Tag is InfoSet)
				return NodeType.InfoSet;
			else if (node.Tag is Facility)
				return NodeType.Facility;
			else if (node.Tag is TreatmentProcess)
				return NodeType.TreatmentProcess;
			else if (node.Tag is MajorComponent)
			{
				// Check to see if it is a component or asset list node
				if (node.Parent.Tag is DisciplineMech)
					return NodeType.AssetList;
				else
					return NodeType.MajorComponent;
			}
			else if (node.Tag is DisciplineMech)
				return NodeType.DisciplineMech;
			else if (node.Tag is DisciplineStruct)
				return NodeType.DisciplineStruct;
			else if (node.Tag is DisciplineLand)
				return NodeType.DisciplineLand;
			else if (node.Tag is DisciplinePipe)
				return NodeType.DisciplinePipe;
			else // if (node.Tag is DisciplineNode)
				return NodeType.DisciplineNode;
		}

		//mam 050806 - added newFacilityName parameter; changed from void to int
		public int AddFacility(string newFacilityName, bool useDelegate)
		{
			//MessageBox.Show("Add Facility");
			// When adding a facility, just prompt for the name of the facility and add it

			//mam 050806 - added newFacilityName
			int newFacilityID = 0;
			string name = newFacilityName;

			if (name == null || name.Length == 0)
			{
				name = UI.NewObjectNameForm.ShowForm(UI.NodeType.Facility, "", InfoSet.CurrentID, 0, this);
			}

			if (name.Length > 0)
			{
				Facility	facility = new Facility(0);
				TreeNode	newNode;

				facility.Name = name;
				facility.InfoSetID = InfoSet.CurrentID;

				//mam 102309
				//DataAccess dataAccess = new DataAccess();
				//int facilityId = dataAccess.ExecuteCommandReturnAutoID(facility.GetInsertSql());
				//facility = new Facility(facilityId);
				//facility.InfoSetID = InfoSet.CurrentID;

				//mam 07072011 - added bool success
				//mam 07072011 - no we're not
				//mam 102309 - no longer necessary as we are saving the component manually, above
				bool success = facility.Save();

				//mam 07072011
				if (!success)
				{
					if (!useDelegate)
					{
						//not adding an imported node
						Common.CommonTasks.ShowErrorMessage("AddFacility", "An error occurred while adding the Facility.");
					}

					return 0;
				}

				//mam 050806
				newFacilityID = facility.ID;

				newNode = new TreeNode(facility.Name);
				newNode.Tag = facility;

				//mam - add image
				newNode.ImageIndex = 1;
				newNode.SelectedImageIndex = 1;
				//</mam>

				if (useDelegate)
				{
					treeViewFacility.Invoke(addNodeDelegate, new object[] { newNode });
					return newFacilityID;
				}
				else
				{
					treeViewFacility.Nodes[0].Nodes.Add(newNode);
					treeViewFacility.Nodes[0].Expand();
				}
			}

			//mam
			NodeType type = GetSelectedNodeType();
			SetToolTips(type);
			//</mam>

			//mam 050806
			return newFacilityID;
		}

		private void AddNodeUsingDelegate(TreeNode delegateNode)
		{
			treeViewFacility.Nodes[0].Nodes.Add(delegateNode);
		}

		private void AddNodeUsingDelegateSpecifyParentNode(TreeNode delegateNode, TreeNode delegateParentNode)
		{
			delegateParentNode.Nodes.Add(delegateNode);
			//treeViewFacility.Nodes[0].Nodes[delegateParentNode.Index].Nodes.Add(delegateNode);
		}

		//		//mam 050806 - added newFacilityName parameter; changed from void to int
		//		public int AddFacility(string newFacilityName)
		//		{
		//			// When adding a facility, just prompt for the name of the facility and add it
		//
		//			//mam 050806 - added newFacilityName
		//			int newFacilityID = 0;
		//			string name = newFacilityName;
		//
		//			if (name == null || name.Length == 0)
		//			{
		//				name = UI.NewObjectNameForm.ShowForm(UI.NodeType.Facility, "", this);
		//			}
		//
		//			if (name.Length > 0)
		//			{
		//				Facility	facility = new Facility(0);
		//				TreeNode	newNode;
		//
		//				facility.Name = name;
		//				facility.InfoSetID = InfoSet.CurrentID;
		//				facility.Save();
		//
		//				//mam 050806
		//				newFacilityID = facility.ID;
		//
		//				newNode = new TreeNode(facility.Name);
		//				newNode.Tag = facility;
		//
		//				//mam - add image
		//				newNode.ImageIndex = 1;
		//				newNode.SelectedImageIndex = 1;
		//				//</mam>
		//
		//				treeViewFacility.Nodes[0].Nodes.Add(newNode);
		//				treeViewFacility.Nodes[0].Expand();
		//			}
		//
		//			//mam
		//			NodeType type = GetSelectedNodeType();
		//			SetToolTips(type);
		//			//</mam>
		//
		//			//mam 050806
		//			return newFacilityID;
		//		}

		private void		AddNode()
		{
			// Check to see what type of node is selected
			NodeType		type = GetSelectedNodeType();
			TreeNode		treeNode = treeViewFacility.SelectedNode;

			//mam 07072011
			C1.Win.C1FlexGrid.C1FlexGrid gridErrors = Common.CommonTasks.GetErrorGrid();

			if (type != NodeType.Facility && type != NodeType.TreatmentProcess)
				return;

			type++;

			// When adding a facility, just prompt for the name of the facility and add it
			TreeNode	newNode = null;

			//mam 07072011
			//C1.Win.C1FlexGrid.C1FlexGrid gridErrors = Common.CommonTasks.GetErrorGrid();
			bool success = false;

			switch (type)
			{
				case NodeType.TreatmentProcess:
					string name = UI.NewObjectNameForm.ShowForm(type, "", InfoSet.CurrentID, ((Facility)treeNode.Tag).ID, this);
					if (name.Length == 0)
						break;
					TreatmentProcess process = new TreatmentProcess(0);
					process.Name = name;
					process.FacilityID = ((Facility)treeNode.Tag).ID;
					process.InfoSetID = InfoSet.CurrentID;

					//mam 102309
					//DataAccess dataAccess = new DataAccess();
					//int processId = dataAccess.ExecuteCommandReturnAutoID(process.GetInsertSqlForCopy());
					//process = new TreatmentProcess(processId);
					//process.InfoSetID = InfoSet.CurrentID;

					//mam 07072011 - added bool success
					//mam 07072011 - no we're not
					//mam 102309 - no longer necessary as we are saving the component manually, above
					//process.Save();
					success = process.Save();

					//mam 07072011
					if (!success)
					{
						Common.CommonTasks.ShowErrorMessage("AddNode", "An error occurred while adding the Treatment Process");
						//Common.CommonTasks.PopulateErrorGridRow(gridErrors, "An error occurred while saving the Treatment Process " + name + ".");
						return;
					}

					((Facility)treeNode.Tag).RefreshTotals();
					newNode = new TreeNode(process.Name);
					newNode.Tag = process;

					//mam - add image
					newNode.ImageIndex = 2;
					newNode.SelectedImageIndex = 2;
					//</mam>

					break;
				case NodeType.MajorComponent:

					//mam 03202012 - added InfoSet.CurrentID
					//MajorComponent component = UI.NewComponentForm.ShowForm(((TreatmentProcess)treeNode.Tag).ID, this);
					MajorComponent component = UI.NewComponentForm.ShowForm(InfoSet.CurrentID, ((TreatmentProcess)treeNode.Tag).ID, this);

					//mam 07072011
					if (component == null)
					{
						Common.CommonTasks.ShowErrorMessage("AddNode", "An error occurred while adding the Major Component");
						//Common.CommonTasks.PopulateErrorGridRow(gridErrors, "An error occurred while saving the Major Component.");
						return;
					}

					//mam 07072011
					//if (component == null)
					//	break;
					((TreatmentProcess)treeNode.Tag).RefreshTotals();
					newNode = new TreeNode(component.Name);
					newNode.Tag = component;

					//mam - add image
					newNode.ImageIndex = 3;
					newNode.SelectedImageIndex = 3;
					//</mam>

					//mam 102309
					AddDisciplinesToDatabaseForImportedComponent(component, component.MechStructDisciplines, false, ref gridErrors);

					if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
					{
						//mam 07072011 - errors occurred when creating the new component (either during creation of the component, or one of the disciplines)
						//	we don't really care why it failed - remove it from the database, if it exists
						success = component.Delete();
						//success = dataAccess.ExecuteCommand("DELETE FROM MajorComponents WHERE component_id = " + component.ID.ToString());
						if (success)
						{
							Drive.Synchronization.SyncAction del = Drive.Synchronization.SyncAction.Delete;
							Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(component, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(component, del));
						}
						else
						{
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error during clean-up of failed Major Component creation");
						}
							
						ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(gridErrors, "Errors Occurred", "Errors");
						errorDisplay.ShowInTaskbar = false;
						errorDisplay.ShowDialog(this);
						return;
					}

					AddDisciplineNodes(newNode);

					//					//Refresh the current view to take into account the new data
					//					//	(only if the parent of the new node already has nodes (not if it has only
					//					//	a placeholder node)
					//					if (newNode != null)
					//					{
					//						TreeNode treeNode = FindTreatmentProcessNode(parentID);
					//						if (treeNode != null && (treeNode.Nodes.Count == 0
					//							|| (treeNode.Nodes.Count > 0 && treeNode.Nodes[0].Tag != null)))
					//						{
					//							//mam 112806 - comment because it uses the main thread
					//							//treeNode.Nodes.Add(newNode);
					//							treeViewFacility.Invoke(addNodeDelegateSpecifyParent, new object[] { newNode, treeNode });
					//
					//							//mam 112806 - comment because it uses the main thread
					//							//treeViewFacility_AfterSelect(null, null);
					//						}
					//					}


					break;
			}

			// Refresh the current view to take into account the new data
			if (newNode != null)
			{
				treeNode.Nodes.Add(newNode);
				treeNode.Expand();
				treeViewFacility_AfterSelect(null, null);
			}
		}

		//mam 07072011 - added gridErrors and cip planning id
		//mam 050806
		//public int AddNodeForImportedData(NodeType type, int parentID, string nodeText, bool isCompMSC)
		//public object AddNodeForImportedData(NodeType type, int parentID, string nodeText, bool isCompMSC, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		public object AddNodeForImportedData(NodeType type, int parentID, string nodeText, bool isCompMSC, int cipPlanningId, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//this routine is called only from ImportFromTextFile.ImportData2()

			try
			{
				//mam 112806 - comment for now because it seems unnecessary in this situation and may cause threading problems
				//PerformPreAddTasks();

				TreeNode newNode = null;
				string name = nodeText;

				//mam 102309
				DataAccess dataAccess = new DataAccess();

				//mam 07072011
				bool success = false;

				switch (type)
				{
					case NodeType.TreatmentProcess:
						//string name = UI.NewObjectNameForm.ShowForm(type, "", this);
						//string name = "Test";
						//if (name.Length == 0)
						//	break;

						TreatmentProcess process = new TreatmentProcess(0);
						process.Name = name;

						//process.FacilityID = ((Facility)treeNode.Tag).ID;
						process.FacilityID = parentID;
						process.InfoSetID = InfoSet.CurrentID;

						//mam 102309 - save the process manually because we're not getting the new ID back from the Drive library
						//DataAccess dataAccess = new DataAccess();
						//int processId = dataAccess.ExecuteCommandReturnAutoID(process.GetInsertSqlForCopy());
						//process = new TreatmentProcess(processId);
						//process.InfoSetID = InfoSet.CurrentID;

						//mam 07072011 - added bool success
						//mam 07072011 - no we're not
						//mam 102309 - no longer necessary as we are saving the component manually, above
						success = process.Save();

						//mam 07072011
						if (!success)
						{
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Treatment Process " + nodeText + ".");
							return null;
						}

						Facility newProcessParentFacility = CacheManager.GetFacility(process.InfoSetID, parentID);
						//((Facility)treeNode.Tag).RefreshTotals();
						newProcessParentFacility.RefreshTotals();
						newNode = new TreeNode(process.Name);
						newNode.Tag = process;

						newNode.ImageIndex = 2;
						newNode.SelectedImageIndex = 2;

						if (newNode != null)
						{
							TreeNode treeNode = FindFacilityNode(parentID);

							//mam 112806 - comment because it uses the main thread
							//treeNode.Nodes.Add(newNode);
							//treeViewFacility.Nodes[treeNode.Index].Nodes.Add(newNode); - was this being used?
							treeViewFacility.Invoke(addNodeDelegateSpecifyParent, new object[] { newNode, treeNode });
							
							//mam 112806 - comment because it uses the main thread
							//treeViewFacility_AfterSelect(null, null);
						}

						//return process.ID;
						return process;

					case NodeType.MajorComponent:
						//MajorComponent component = UI.NewComponentForm.ShowForm(
						//	((TreatmentProcess)treeNode.Tag).ID, this);
						MajorComponent component = new MajorComponent(0);
						if (component == null)
							break;
						component.MechStructDisciplines = isCompMSC;
						component.Name = name;
						component.ProcessID = parentID;
						component.InfoSetID = InfoSet.CurrentID;

						//mam 07072011
						if (cipPlanningId > 0)
						{
							component.CipPlanningId = cipPlanningId;
						}

						//mam 102309 - save the component manually because we're not getting the new ID back from the Drive library
						//DataAccess dataAccess = new DataAccess();
						//int componentId = dataAccess.ExecuteCommandReturnAutoID(component.GetInsertSqlForCopy());
						//component = new MajorComponent(componentId);
						//component.InfoSetID = InfoSet.CurrentID;

						//mam 07072011 - added bool success
						//mam 07072011 - no we're not
						//mam 102309 - no longer necessary as we are saving the component manually, above
						success = component.Save();

						//mam 07072011
						if (!success)
						{
							Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Major Component " + nodeText + ".");
							return null;
						}

						//mam 07072011 - insert default criticality values into new Major Component
						//need to change this to get values from imported data, if available
						//	it's ok as it is
						component.InsertCriticalityValuesAllDefault();

						//mam 102309
						//Drive.Synchronization.SyncAction add = Drive.Synchronization.SyncAction.Add;
						//Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(component, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(component, add));

						//((TreatmentProcess)treeNode.Tag).RefreshTotals();
						TreatmentProcess newComponentParentProcess = CacheManager.GetTreatmentProcess(component.InfoSetID, parentID);
						newComponentParentProcess.RefreshTotals();
						newNode = new TreeNode(component.Name);
						newNode.Tag = component;

						newNode.ImageIndex = 3;
						newNode.SelectedImageIndex = 3;

						//mam 07072011 - added gridErrors
						//mam 102309 - add a new method to add the disciplines to the database and the cache
						AddDisciplinesToDatabaseForImportedComponent(component, isCompMSC, true, ref gridErrors);

						AddDisciplineNodes(newNode);

						//Refresh the current view to take into account the new data
						//	(only if the parent of the new node already has nodes (not if it has only
						//	a placeholder node)
						if (newNode != null)
						{
							TreeNode treeNode = FindTreatmentProcessNode(parentID);
							if (treeNode != null && (treeNode.Nodes.Count == 0
								|| (treeNode.Nodes.Count > 0 && treeNode.Nodes[0].Tag != null)))
							{
								//mam 112806 - comment because it uses the main thread
								//treeNode.Nodes.Add(newNode);
								treeViewFacility.Invoke(addNodeDelegateSpecifyParent, new object[] { newNode, treeNode });

								//mam 112806 - comment because it uses the main thread
								//treeViewFacility_AfterSelect(null, null);
							}
						}

						//return component.ID;
						return component;

						//					case NodeType.DisciplineMech:
						//						DisciplineMech discipline = new DisciplineMech(0);
						//						if (discipline == null)
						//							break;
						//						//discipline.MechStructDisciplines = isCompMSC;
						//						//discipline.Name = name;
						//						discipline.ComponentID = parentID;
						//						discipline.InfoSetID = InfoSet.CurrentID;
						//						discipline.Save();
						//
						//						MajorComponent newDisciplineParentComponent = CacheManager.GetMajorComponent(discipline.InfoSetID, parentID);
						//						newDisciplineParentComponent.RefreshTotals();
						////						newNode = new TreeNode(discipline.Name);
						////						newNode.Tag = discipline;
						////
						////						newNode.ImageIndex = 3;
						////						newNode.SelectedImageIndex = 3;
						//
						//						//Refresh the current view to take into account the new data
						//						//	(only if the parent of the new node already has nodes (not if it has only
						//						//	a placeholder node)
						//						//if (newNode != null)
						//						{
						//							TreeNode treeNode = FindMajorComponentNode(parentID);
						//							if (treeNode != null && (treeNode.Nodes.Count == 0
						//								|| (treeNode.Nodes.Count > 0 && treeNode.Nodes[0].Tag != null)))
						//							{
						//								AddDisciplineNodes(newNode);
						//								//treeNode.Nodes.Add(newNode);
						//								////treeNode.Expand();
						//								//treeViewFacility_AfterSelect(null, null);
						//							}
						//						}
						//
						//						//return component.ID;
						//						return discipline;
				}

				return null;
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, "An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return null;
			}
		}

		//mam 07072011 - added gridErrors
		//mam 102309
		private void AddDisciplinesToDatabaseForImportedComponent(MajorComponent majorComponent, bool isCompMSC, bool forImport, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//DataAccess dataAccess = new DataAccess();
			Discipline newDiscipline = null;
			//Drive.Synchronization.SyncAction add = Drive.Synchronization.SyncAction.Add;
			//int disciplineId = 0;
			//int test = 0;
			//DisciplineCache disciplineCache = CacheManager.GetDisciplineCache(majorComponent.InfoSetID);

			//Discipline[] disciplines;

			//mam 07072011
			bool success = false;

			if (isCompMSC)
			{
				//case DisciplineType.Mechanical:
				newDiscipline = new DisciplineMech(0);
				newDiscipline.ComponentID = majorComponent.ID;
				newDiscipline.InfoSetID = majorComponent.InfoSetID;

				//mam 07072011
				//use this only when adding a discipline, not when importing
				// no, use it for import as well
				//if (!forImport)
				{
					//mam 01222012
					newDiscipline.InstallationYear = newDiscipline.GetInstallationYearDefault();
					newDiscipline.InspectionYear = newDiscipline.GetInspectionDateDefault();
					((DisciplineMech)newDiscipline).DateInspected = newDiscipline.InspectionYear;

					//newDiscipline.RehabInterval = Math.Round(newDiscipline.OrgUsefulLife / 2.0m, 1);
					newDiscipline.RehabYearLast = newDiscipline.GetRehabYearLastDefault();
				}

				//mam 07072011 - added bool success
				success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Mech Discipline for " + majorComponent.Name + ".");
					return;
				}

				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				newDiscipline.ComponentID = majorComponent.ID;
				//				//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
				//				disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
				//				newDiscipline = new DisciplineMech(disciplineId);
				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
				//				disciplineCache.AddDisciplineToCache(majorComponent.ID, newDiscipline);

				//importAssetList = true;
				//break;
			
				//disciplines = CacheManager.GetDisciplines(majorComponent.InfoSetID, majorComponent.ID);
				//test = disciplines.Length;

				//case DisciplineType.Structural:
				newDiscipline = new DisciplineStruct(0);
				newDiscipline.ComponentID = majorComponent.ID;
				newDiscipline.InfoSetID = majorComponent.InfoSetID;

				//mam 07072011
				//use this only when adding a discipline, not when importing
				// no, use it for import as well
				//if (!forImport)
				{
					//mam 01222012
					newDiscipline.InstallationYear = newDiscipline.GetInstallationYearDefault();
					newDiscipline.InspectionYear = newDiscipline.GetInspectionDateDefault();
					((DisciplineStruct)newDiscipline).DateInspected = newDiscipline.InspectionYear;

					//newDiscipline.RehabInterval = Math.Round(newDiscipline.OrgUsefulLife / 2.0m, 1);
					newDiscipline.RehabYearLast = newDiscipline.GetRehabYearLastDefault();
				}

				//mam 07072011 - added bool success
				success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Struct Discipline for " + majorComponent.Name + ".");
					return;
				}

				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				newDiscipline.ComponentID = majorComponent.ID;
				//				//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
				//				disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
				//				newDiscipline = new DisciplineStruct(disciplineId);
				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
				//				disciplineCache.AddDisciplineToCache(majorComponent.ID, newDiscipline);

				//break;

				//disciplines = CacheManager.GetDisciplines(majorComponent.InfoSetID, majorComponent.ID);
				//test = disciplines.Length;

				//case DisciplineType.Land:
				newDiscipline = new DisciplineLand(0);
				newDiscipline.ComponentID = majorComponent.ID;
				newDiscipline.InfoSetID = majorComponent.InfoSetID;

				//mam 07072011 - assign default values
				//use this only when adding a discipline, not when importing
				// no, use it for import as well
				//if (!forImport)
				{
					//mam 01222012
					newDiscipline.InstallationYear = newDiscipline.GetInstallationYearDefault();
					newDiscipline.InspectionYear = newDiscipline.GetInspectionDateDefault();
					((DisciplineLand)newDiscipline).DateInspected = newDiscipline.InspectionYear;

					//newDiscipline.RehabInterval = Math.Round(newDiscipline.OrgUsefulLife / 2.0m, 1);
					newDiscipline.RehabYearLast = newDiscipline.GetRehabYearLastDefault();
				}

				//mam 07072011 - added bool success
				success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Land Discipline for " + majorComponent.Name + ".");
					return;
				}

				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				newDiscipline.ComponentID = majorComponent.ID;
				//				//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
				//				disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
				//				newDiscipline = new DisciplineLand(disciplineId);
				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
				//				disciplineCache.AddDisciplineToCache(majorComponent.ID, newDiscipline);

				//break;

				//disciplines = CacheManager.GetDisciplines(majorComponent.InfoSetID, majorComponent.ID);
				//test = disciplines.Length;
			}
			else
			{
				//case DisciplineType.Pipes:
				newDiscipline = new DisciplinePipe(0);
				newDiscipline.ComponentID = majorComponent.ID;
				newDiscipline.InfoSetID = majorComponent.InfoSetID;

				//mam 03202012
				newDiscipline.InstallationYear = newDiscipline.GetInstallationYearDefault();
				newDiscipline.InspectionYear = newDiscipline.GetInspectionDateDefault();
				((DisciplinePipe)newDiscipline).DateInspected = newDiscipline.InspectionYear;

				//mam 07072011 - added bool success
				success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Pipe Discipline for " + majorComponent.Name + ".");
					return;
				}

				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				newDiscipline.ComponentID = majorComponent.ID;
				//				//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
				//				disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
				//				newDiscipline = new DisciplinePipe(disciplineId);
				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
				//				disciplineCache.AddDisciplineToCache(majorComponent.ID, newDiscipline);
				//				//importPipeData = true;
				//				//break;

				//case DisciplineType.Nodes:
				newDiscipline = new DisciplineNode(0);
				newDiscipline.ComponentID = majorComponent.ID;
				newDiscipline.InfoSetID = majorComponent.InfoSetID;

				//mam 03202012
				newDiscipline.InstallationYear = newDiscipline.GetInstallationYearDefault();
				newDiscipline.InspectionYear = newDiscipline.GetInspectionDateDefault();
				((DisciplineNode)newDiscipline).DateInspected = newDiscipline.InspectionYear;

				//mam 07072011 - added bool success
				success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "An error occurred while saving the Node Discipline for " + majorComponent.Name + ".");
					return;
				}

				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				newDiscipline.ComponentID = majorComponent.ID;
				//				//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
				//				disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
				//				newDiscipline = new DisciplineNode(disciplineId);
				//				newDiscipline.InfoSetID = majorComponent.InfoSetID;
				//				Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
				//				disciplineCache.AddDisciplineToCache(majorComponent.ID, newDiscipline);
				//				//importNodeData = true;
				//				//break;
			}

			//newDiscipline.ComponentID = majorComponent.ID;
			//newDiscipline.InfoSetID = majorComponent.InfoSetID;
			//newDiscipline.Save();

			//newDiscipline.InfoSetID = majorComponent.InfoSetID;
			//Drive.Synchronization.SyncAction add = Drive.Synchronization.SyncAction.Add;
			//Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newDiscipline, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newDiscipline, add));
		}

		//mam 03202012 - this is the old method that is no longer used
		//mam 102309 - no longer deleting photos
		//mam 102309 - yes, we are
//		private bool DeletePhotos(string imagePath, string formattedID)
//		{
//			System.IO.DirectoryInfo dir;
//			System.IO.FileInfo[] files;
//			ArrayList arrayFiles = new ArrayList();
//			string photoDirectory = @imagePath;
//
//			if (!System.IO.Directory.Exists(photoDirectory))
//				return false;
//
//			dir = new System.IO.DirectoryInfo(photoDirectory);
//			files = dir.GetFiles(formattedID);
//			arrayFiles.AddRange(files);
//
//			try
//			{
//				for (int i = 0; i < arrayFiles.Count; i++)
//					System.IO.File.Delete(photoDirectory + @"\" + arrayFiles[i].ToString());
//			}
//			catch
//			{
//				return false;
//			}
//
//			return true;
//		}

		//mam 03202012
		private bool DeletePhotos(string imagePath, int assetId, NodeType nodeType)
		{
			//System.IO.DirectoryInfo dir;
			ArrayList arrayFiles = new ArrayList();
			string photoDirectory = @imagePath;

			if (!System.IO.Directory.Exists(photoDirectory))
			{
				return false;
			}

			SortedList sortedList = Common.CommonTasks.GetPhotosToDelete(assetId, nodeType);

			string errorMessage = "";
			for (int i = 0; i < sortedList.Count; i++)
			{
				try
				{
					System.IO.File.Delete(photoDirectory + @"\" + sortedList[i].ToString());
				}
				catch (FileNotFoundException)
				{
					//keep going - we are deleting the file, so if it already doesn't exist, so be it
				}
				catch (System.Security.SecurityException ex)
				{
					//break out of loop
					errorMessage = ex.Message;
				}
				catch (IOException ex)
				{
					//break out of loop
					errorMessage = ex.Message;
				}
				catch (Exception ex)
				{
					//break out of loop
					errorMessage = ex.Message;
				}
			}

			if (errorMessage != "")
			{
				Common.CommonTasks.ShowErrorMessage("Delete Photos", errorMessage);
				return false;
			}

			return true;
		}

		private void		DeleteNode()
		{
			// Check to see what type of node is selected
			NodeType		type = GetSelectedNodeType();
			TreeNode		node = treeViewFacility.SelectedNode;

			DialogResult	result;

			//mam - changed YesNoCancel to YesNo and changed message to display node text and check for children
			if (treeViewFacility.SelectedNode.Nodes.Count > 0)
			{
				result = MessageBox.Show(this,
					"Warning: By deleting this item, you will delete all information and photos for this item and all items below it.\n\nDo you want to delete  '" + treeViewFacility.SelectedNode.Text + "'  ?",
					"Delete Item?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			}
			else
			{
				result = MessageBox.Show(this,
					"Delete  '" + treeViewFacility.SelectedNode.Text + "'  ?",
					"Delete Item?", MessageBoxButtons.YesNo, 
					MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
			}
			//</mam>

			if (result != DialogResult.Yes)
				return;

			this.Cursor = Cursors.WaitCursor;
			try
			{
				if (type == NodeType.Facility)
				{
					//mam 102309 - no longer deleting photos
					//mam 102309 - yes, we are
					//mam - delete photos
					string imagePath = ((InfoSet)treeViewFacility.Nodes[0].Tag).GetImagePath();

					//mam 03202012 - no longer needed
					//string formattedID = string.Format(@"{0:D4}*.jpg", ((Facility)node.Tag).ID);

					//mam 03202012 - use new DeletePhotos method
					//DeletePhotos(imagePath, formattedID);
					DeletePhotos(imagePath, ((Facility)node.Tag).ID, NodeType.Facility);

					//</mam>

					((Facility)node.Tag).Delete();
					node.Remove();

					//treeViewFacility.ResumeLayout();
				}
				else if (type == NodeType.TreatmentProcess)
				{
					//mam 102309 - no longer deleting photos
					//mam 102309 - yes, we are
					//mam - delete photos
					string imagePath = ((InfoSet)treeViewFacility.Nodes[0].Tag).GetImagePath();

					//mam 03202012 - no longer needed
					//string formattedID = string.Format(@"{0:D4}-{1:D4}*.jpg", 
					//	((TreatmentProcess)node.Tag).FacilityID, ((TreatmentProcess)node.Tag).ID);

					//mam 03202012 - use new DeletePhotos method
					//DeletePhotos(imagePath, formattedID);
					DeletePhotos(imagePath, ((TreatmentProcess)node.Tag).ID, NodeType.TreatmentProcess);

					//</mam>

					((TreatmentProcess)node.Tag).Delete();
					node.Remove();
				}
				else if (type == NodeType.MajorComponent)
				{
					//mam 102309 - no longer deleting photos
					//mam 102309 - yes, we are
					//mam - delete photos
					string imagePath = ((InfoSet)treeViewFacility.Nodes[0].Tag).GetImagePath();

					//mam 03202012 - no longer needed
					//string formattedID = string.Format(@"{0:D4}-{1:D4}-{2:D4}*.jpg", 
					//	((Facility)node.Parent.Parent.Tag).ID, ((MajorComponent)node.Tag).ProcessID, ((MajorComponent)node.Tag).ID);

					//mam 03202012 - use new DeletePhotos method
					//DeletePhotos(imagePath, formattedID);
					DeletePhotos(imagePath, ((MajorComponent)node.Tag).ID, NodeType.MajorComponent);

					//</mam>

					((MajorComponent)node.Tag).Delete();
					node.Remove();
				}
			}
			catch (Exception ex)
			{
				WAM.Common.CommonTasks.ShowErrorMessage("MainForm", "An error has occurred: " + ex.Message);
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}

		private void		PopulateTree()
		{
			treeViewFacility.BeginUpdate();
			treeViewFacility.Nodes.Clear();

			TreeNode		root;
			InfoSet			infoSet = new InfoSet(InfoSet.CurrentID);

			root = new TreeNode(infoSet.Name);
			root.Tag = infoSet;

			//mam - add image
			root.ImageIndex = 0;
			root.SelectedImageIndex = 0;
			//</mam>

			treeViewFacility.Nodes.Add(root);

			// Get the root nodes (facilities)
			Facility[]		facilities = 
				CacheManager.GetFacilities(InfoSet.CurrentID);
			Facility		facility;
			TreeNode		node;
			TreeNode		placeHolder;

			for (int pos = 0; pos < facilities.Length; pos++)
			{
				facility = facilities[pos];
				node = new TreeNode(facility.Name);
				node.Tag = facility;

				//mam - add image
				node.ImageIndex = 1;
				node.SelectedImageIndex = 1;
				//</mam>

				root.Nodes.Add(node);

				if (facility.HasChildren)
				{
					placeHolder = new TreeNode("*PH*");
					placeHolder.Tag = null;
					node.Nodes.Add(placeHolder);
				}
			}

			root.Expand();
			
			//mam 102309 - no need to do this - no longer using Access, so no need to use database name
			//			//mam - last minute fix to set the currentDatabaseImageFolder variable so the image folder doesn't get
			//			//	created directly under the Images folder when it actually should be in a database-named folder
			//			if (treeViewFacility.Nodes.Count > 0)
			//			{
			//				string imagePath = Drive.IO.Directory.GetApplicationPath();
			//				imagePath = string.Format(@"{0}\Images", imagePath);
			//				imagePath += @"\" + treeViewFacility.Nodes[0].Text;
			//				WAM.Common.StartUpChores startUpChores = new WAM.Common.StartUpChores();
			//				currentDatabaseImageFolder = startUpChores.SetDatabaseImageFolderName(@imagePath);
			//			}
			//			//</mam>

			treeViewFacility.SelectedNode = root;
			treeViewFacility.EndUpdate();
		}

		private void		AddProcessNodes(TreeNode facilityNode)
		{
			treeViewFacility.BeginUpdate();

			// Get the root nodes (facilities)
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(InfoSet.CurrentID, 
				((Facility)facilityNode.Tag).ID);
			TreatmentProcess process;
			TreeNode		node;
			TreeNode		placeHolder;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				node = new TreeNode(process.Name);
				node.Tag = process;

				//mam - add image
				node.ImageIndex = 2;
				node.SelectedImageIndex = 2;
				//</mam>

				facilityNode.Nodes.Add(node);

				if (process.HasChildren)
				{
					placeHolder = new TreeNode("*PH*");
					placeHolder.Tag = null;
					node.Nodes.Add(placeHolder);
				}
			}

			treeViewFacility.EndUpdate();
		}

		private void		AddMajorComponentNodes(TreeNode processNode)
		{
			treeViewFacility.BeginUpdate();

			// Get the root nodes (facilities)
			MajorComponent[] components = 
				CacheManager.GetComponents(InfoSet.CurrentID, 
				((TreatmentProcess)processNode.Tag).ID);
			MajorComponent	component;
			TreeNode		node;
			TreeNode		placeHolder;

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				node = new TreeNode(component.Name);
				node.Tag = component;

				//mam - add image
				node.ImageIndex = 3;
				node.SelectedImageIndex = 3;
				//</mam>

				processNode.Nodes.Add(node);

				placeHolder = new TreeNode("*PH*");
				placeHolder.Tag = null;
				node.Nodes.Add(placeHolder);
			}

			treeViewFacility.EndUpdate();
		}

		private void		AddDisciplineNodes(TreeNode componentNode)
		{
			treeViewFacility.BeginUpdate();

			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(InfoSet.CurrentID, 
				((MajorComponent)componentNode.Tag).ID);
			Discipline		discipline;
			TreeNode		node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				node = new TreeNode(discipline.Name);
				node.Tag = discipline;

				//mam - add image
				node.ImageIndex = 4;
				node.SelectedImageIndex = 4;
				//</mam>

				componentNode.Nodes.Add(node);
				if (discipline.ID == 0 || discipline.ConditionRanking == CondRank.No)
					node.ForeColor = Color.FromArgb(255, 0, 0);

				if (discipline is DisciplineMech)
				{
					TreeNode assetNode;

					assetNode = new TreeNode("Asset List");
					assetNode.Tag = (MajorComponent)componentNode.Tag;

					//mam - add image
					assetNode.ImageIndex = 5;
					assetNode.SelectedImageIndex = 5;
					//</mam>

					node.Nodes.Add(assetNode);
				}
			}

			treeViewFacility.EndUpdate();
		}

		private void		treeViewFacility_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			// Check to see if there is a placeholder as a child; if so, 
			// need to populate children for real
			TreeNode		node = e.Node;

			//mam 03202012 - when importing, a child node could be added to a pre-existing node in the tree (importing a process to an existing, non-imported facility,
			//	for instance).  Prior to importing, if that facility node had never been expanded by the user, it will contain one node (a placholder node) 
			//	that represents all the processes in that facility.  When the user expands the facility node, the placeholder node is replaced with all the process nodes.  
			//	The code here checks for that one placeholder node and, if it exists, replaces it with the real nodes.  During an import, one or more process nodes could be
			//	added to the unexpanded facility, causing the process node count to be > 1, while the placeholder node still exists.  So we must check for the existence 
			//	of child nodes, not the existence of just one child node.  )Imported nodes are always added to the parent node, and never inserted into the first position,
			//	so the placeholder node will always be the first node.)

			//if (node.Nodes.Count == 1)
			if (node.Nodes.Count > 0)
			{
				// Check to see if it is a placeholder node
				if (node.Nodes[0].Tag == null)
				{
					node.Nodes.Clear();

					if (node.Tag is Facility)
						AddProcessNodes(node);
					else if (node.Tag is TreatmentProcess)
						AddMajorComponentNodes(node);
					else if (node.Tag is MajorComponent)
						AddDisciplineNodes(node);
				}
			}
		}

		private void treeViewFacility_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			// Check to see what type of node is selected
			
			//mam
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			//</mam>

			NodeType		type = GetSelectedNodeType();

			//mam - no longer need this variable
			//bool			enableDelete = false;
			//</mam>

			TreeNode		node = treeViewFacility.SelectedNode;

			//enableDelete = false;
			infoSetControl1.Visible = (type == NodeType.InfoSet);
			facilityControl1.Visible = (type == NodeType.Facility);
			treatmentProcessControl1.Visible = (type == NodeType.TreatmentProcess);
			majorComponentControl1.Visible = (type == NodeType.MajorComponent);
			disciplineMechControl1.Visible = (type == NodeType.DisciplineMech);
			disciplineStructControl1.Visible = (type == NodeType.DisciplineStruct);
			disciplineLandControl1.Visible = (type == NodeType.DisciplineLand);
			disciplineNodesControl1.Visible = (type == NodeType.DisciplineNode);
			disciplinePipeControl1.Visible = (type == NodeType.DisciplinePipe);
			assetListControl1.Visible = (type == NodeType.AssetList);

			//mam
			//int currentTabIndex = 0;
			labelDataType.Text = NodeTypeHandler.GetNodeTypeString(type);
			SetToolTips(type);
			menuItemEdit_ChangeSortOrder.Enabled = false;
			//</mam>

			switch (type)
			{
				case NodeType.InfoSet:
					infoSetControl1.SetInfoSet(node.Tag as InfoSet);
					break;
				case NodeType.Facility:
					facilityControl1.SetFacility(node.Tag as Facility);

					//mam
					facilityControl1.SetEquationControls();
					//menuItemEdit_ChangeSortOrder.Enabled = true;
					//</mam>

					//enableDelete = true;
					break;
				case NodeType.TreatmentProcess:
					treatmentProcessControl1.SetProcess(node.Tag as TreatmentProcess);
					//enableDelete = true;

					//mam
					treatmentProcessControl1.SetEquationControls();
					//menuItemEdit_ChangeSortOrder.Enabled = true;
					//</mam>

					break;
				case NodeType.MajorComponent:

					//mam
					//majorComponentControl1.SuspendLayout();
					//currentTabIndex = majorComponentControl1.TabControlIndex;
					//</mam>
					
					majorComponentControl1.SetComponent(node.Tag as MajorComponent);

					//enableDelete = true;

					//mam
					majorComponentControl1.SetEquationControls();
					//</mam>

					//mam 07072011
					majorComponentControl1.SetAssetClass();

					//mam
					//majorComponentControl1.TabControlIndex = currentTabIndex;
					//majorComponentControl1.ResumeLayout();
					//</mam>

					break;
				case NodeType.DisciplineMech:
					disciplineMechControl1.SetDiscipline(node.Tag as DisciplineMech);

					//mam
					disciplineMechControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineStruct:
					disciplineStructControl1.SetDiscipline(node.Tag as DisciplineStruct);

					//mam
					disciplineStructControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineLand:
					disciplineLandControl1.SetDiscipline(node.Tag as DisciplineLand);

					//mam
					disciplineLandControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineNode:
					disciplineNodesControl1.SetDiscipline(node.Tag as DisciplineNode);

					//mam
					disciplineNodesControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplinePipe:
					disciplinePipeControl1.SetDiscipline(node.Tag as DisciplinePipe);

					//mam
					disciplinePipeControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.AssetList:
					assetListControl1.SetComponent(node.Tag as MajorComponent);
					break;
				default:
					break;
			}

			//mam
			this.Cursor = System.Windows.Forms.Cursors.Default;
			//</mam>

			//mam - disable toolbar buttons if fixed infoset
			SetControls();
			//SetToolTips(type);
			//</mam>

			//mam 03202012 - set the focus back on the tree so it isn't set to a text box on the form
			this.treeViewFacility.Focus();
		}

		private void menuItemEdit_Popup(object sender, System.EventArgs e)
		{
			SaveCurrentDisplay();

			treeViewFacility.Focus();

			// Check to see what type of node is selected
			NodeType		type = GetSelectedNodeType();

			switch (type)
			{
				case NodeType.Facility:
				case NodeType.TreatmentProcess:
					menuItemEdit_AddNode.Text = string.Format("Add &New {0}...", 
						NodeTypeHandler.GetNodeTypeString(type + 1));
					menuItemEdit_AddNode.Visible = true;

					//mam - don't allow adding of nodes if infoset is fixed
					if (InfoSet.IsFixed)
					{
						menuItemEdit_AddNode.Enabled = false;
					}
					//</mam>

					//mam
					menuItemEdit_CopyNode.Text = "&" + toolTip.GetToolTip(this.pictureBoxToolbarCopy);
					menuItemEdit_CopyNode.Visible = true;
					//</mam>

					menuItemEdit_DeleteNode.Text = string.Format("&Delete {0}...",
						NodeTypeHandler.GetNodeTypeString(type));
					menuItemEdit_DeleteNode.Visible = true;

					//mam - don't allow deleting of nodes if infoset is fixed
					if (InfoSet.IsFixed)
					{
						menuItemEdit_DeleteNode.Enabled = false;
						menuItemEdit_CopyNode.Enabled = false;
					}
					//</mam>

					break;
				case NodeType.MajorComponent:
					menuItemEdit_AddNode.Visible = false;

					//mam
					menuItemEdit_CopyNode.Text = "&" + toolTip.GetToolTip(this.pictureBoxToolbarCopy);
					menuItemEdit_CopyNode.Visible = true;
					//</mam>

					menuItemEdit_DeleteNode.Text = string.Format("&Delete {0}...",
						NodeTypeHandler.GetNodeTypeString(type));
					menuItemEdit_DeleteNode.Visible = true;

					//mam - don't allow deleting of nodes if infoset is fixed
					if (InfoSet.IsFixed)
					{
						menuItemEdit_DeleteNode.Enabled = false;
						menuItemEdit_CopyNode.Enabled = false;
					}

					//</mam>

					break;
				default:
					menuItemEdit_AddNode.Visible = false;
					menuItemEdit_DeleteNode.Visible = false;
					menuItemEdit_CopyNode.Visible = false;
					break;
			}

			menuItemEdit_CustomENR.Enabled = true;
			if (InfoSet.IsFixed)
			{
				menuItemEdit_CustomENR.Enabled = false;
			}

			menuItemEdit_GlobalUpdate.Enabled = 
				(type != NodeType.InfoSet && type != NodeType.NoneSelected);

			Facility facility = GetFacilityForSelectedNode();
			if (facility != null)
			{
				menuItemEdit_GlobalUpdate.Enabled = !InfoSet.IsFixed;
			}
			//</mam>
		}

		//mam
		private void menuItemView_Popup(object sender, System.EventArgs e)
		{
			SaveCurrentDisplay();
		}
		//</mam>

		//mam
		private void menuItemViewEquationViewer_Click(object sender, System.EventArgs e)
		{
			pictureBoxToolbarEquationBox_Click(null, null);
		}
		//</mam>

		private void menuItemHelp_About_Click(object sender, System.EventArgs e)
		{
			// Show the about box
			SplashScreenForm.ShowAboutForm(this);
		}

		//mam
		private void menuItemHelpContents_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.TableOfContents);
		}
		//</mam>

		//mam
		private void menuItemHelpIndex_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Index);
		}
		//</mam>

		//mam
		private void menuItemHelpSearch_Click(object sender, System.EventArgs e)
		{
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.KeywordIndex);
		}
		//</mam>

		private void menuItemEdit_ChangeSortOrder_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to update data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			TreeNode		node = treeViewFacility.SelectedNode;

			if (node == null)
				return;

			if (node.Tag is InfoSet || node.Tag is Facility ||
				node.Tag is TreatmentProcess)
			{
				if (ChangeSortOrderForm.ShowForm(node.Tag, this))
				{
					PopulateTree();
				}
			}
		}

		//mam 102309 - no longer allowing import from version 1 of WAM
		private void menuItemImport_PreviousVersion_Click(object sender, System.EventArgs e)
		{
			//UI.Import.ImportFromWWAMForm.ShowForm(this);
			//PopulateTree();
		}

		//mam
		private void menuItemFileLoadDatabase_Click(object sender, System.EventArgs e)
		{
			//mam 102309 - no longer storing data in Access databases
			//			try
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			//
			//				UpdateCurrentDisplay();
			//				SaveCurrentDisplay();
			//
			//				databaseToLoad = "";
			//				DatabaseLoad databaseLoad = new DatabaseLoad();
			//				databaseLoad.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			//				databaseLoad.OnSelectedDatabase += new DatabaseLoad.SelectedDatabase(this.messageSelectedDatabase);
			//
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//
			//				databaseLoad.ShowDialog(this);
			//
			//				if (databaseLoad.DialogResult == DialogResult.OK)
			//				{
			//					if (databaseToLoad.Length > 0)
			//					{
			//						if (!LoadDatabase(databaseToLoad))
			//							MessageBox.Show("An error has occurred.  The database was not loaded.", "Load Database", 
			//								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			//					}
			//					else
			//					{
			//						MessageBox.Show("There is no database to load.", "Load Database", 
			//							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			//					}
			//				}
			//				else
			//				{
			//					//MessageBox.Show("Cancelled");
			//				}
			//			}
			//			finally
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//			}
		}
		//</mam>

		
		//mam
		private void menuItemFileSaveDatabaseAs_Click(object sender, System.EventArgs e)
		{
			//mam 102309 - no longer storing data in Access databases
			//			try
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			//			
			//				UpdateCurrentDisplay();
			//				SaveCurrentDisplay();
			//
			//				DatabaseSave databaseSave = new DatabaseSave();
			//				databaseSave.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			//
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//
			//				databaseSave.ShowDialog(this);
			//			}
			//			finally
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//			}
		}
		//</mam>

		//mam
		private void menuItemFileCompactDatabase_Click(object sender, System.EventArgs e)
		{
			//mam 102309 - no longer allowing user to compact Access databases
			//			try
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			//			
			//				UpdateCurrentDisplay();
			//				SaveCurrentDisplay();
			//
			//				DatabaseCompact databaseCompact = new DatabaseCompact();
			//				databaseCompact.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			//
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//
			//				databaseCompact.ShowDialog(this);
			//			}
			//			finally
			//			{
			//				this.Cursor = System.Windows.Forms.Cursors.Default;
			//			}
		}
		//</mam>

		private void menuItemFile_InfoSetManagement_Click(object sender, System.EventArgs e)
		{
			UI.SelectInfoSetForm.ShowForm(this);
			PopulateTree();

			//mam
			if (treeViewFacility.Nodes.Count > 0 && treeViewFacility.Nodes[0].Nodes.Count > 0)
				treeViewFacility.SelectedNode = treeViewFacility.Nodes[0].Nodes[0];
			SetControls();
			//</mam>
		}

		private void menuItemFile_Import_Nodes_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to import data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			WAM.UI.Import.ImportPipeNodeForm.ImportDataFile(false, this);
			PopulateTree();
		}

		private void menuItemFile_Import_Pipes_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to import data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			WAM.UI.Import.ImportPipeNodeForm.ImportDataFile(true, this);
			PopulateTree();
		}

		private void menuItemReports_FacilityReport_Click(object sender, System.EventArgs e)
		{
			UpdateCurrentDisplay();
			SaveCurrentDisplay();
			GetExpandedNodes();

			//make sure Reports.xml file exists
			string filePath = string.Format(@"{0}\Reports.xml", Drive.IO.Directory.GetApplicationPath());
			if (!System.IO.File.Exists(filePath))
			{
				System.Windows.Forms.MessageBox.Show("The report file (Reports.xml) cannot be found.", "Cannot Find Report File",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
				return;
			}
			//</mam>
			WAM.UI.ReportFilterForm.ShowForm(this, nodesExpandedMainForm);
		}

		//mam 11142011
		public void ContinueAccessImport(bool continueImport)
		{
			this.continueImport = continueImport;
		}

		private void menuItemFile_Import_InfoSet_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to import data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam 11142011
			//WAM.UI.Import.AccessImportCritMap.ShowForm(this);
			continueImport = false;
			WAM.UI.Import.AccessImportCritMap accessImportCritMap = new WAM.UI.Import.AccessImportCritMap();
			accessImportCritMap.AllowAccessImport += new WAM.UI.Import.AccessImportCritMap.AccessImportDelegate(ContinueAccessImport);
			accessImportCritMap.ShowDialog();
			if (continueImport)
			{
				WAM.UI.Import.ImportFromWAMForm.ShowForm(this);
			}
		}

		private void menuItemFile_Exit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void menuItemEdit_20CitiesENR_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam 102309 - no longer using Jet
			//			//mam - check for the existence of the database
			//			string dbPath = string.Format(@"{0}\20CitiesENR.mdb", Drive.IO.Directory.GetApplicationPath());
			//			if (!System.IO.File.Exists(dbPath))
			//			{
			//				System.Windows.Forms.MessageBox.Show("The ENR database file (20CitiesENR.mdb) cannot be found.", "Cannot Find Database",
			//					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			//				return;
			//			}
			//			//</mam>

			Manage20CitiesENRForm.ShowForm(this);
			RefreshCurrentView();
		}

		private void RefreshCurrentView()
		{
			// Refresh the current view
			treeViewFacility_AfterSelect(null, null);
		}

		private Facility GetFacilityForSelectedNode()
		{
			NodeType		type = GetSelectedNodeType();
			Facility		facility = null;
			TreatmentProcess process = null;
			object			selectedObject = GetSelectedNodeObject();

			switch (type)
			{
				case NodeType.Facility:
					facility = selectedObject as Facility;
					break;
				case NodeType.TreatmentProcess:
					process = selectedObject as TreatmentProcess;
					facility = CacheManager.GetFacility(InfoSet.CurrentID, process.FacilityID);
					break;
				case NodeType.MajorComponent:
				case NodeType.AssetList:
					MajorComponent component = selectedObject as MajorComponent;
					process = CacheManager.GetTreatmentProcess(InfoSet.CurrentID, component.ProcessID);
					facility = CacheManager.GetFacility(InfoSet.CurrentID, process.FacilityID);
					break;
				case NodeType.DisciplineMech:
				case NodeType.DisciplineStruct:
				case NodeType.DisciplineLand:
				case NodeType.DisciplineNode:
				case NodeType.DisciplinePipe:
					facility = ((Discipline)selectedObject).GetFacility();
					break;
			}

			return facility;
		}

		private void menuItemEdit_CustomENR_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			//mam - no longer tying ENR tables only to one facility
			Facility		facility = GetFacilityForSelectedNode();

			if (facility != null)
			{
				ManageCustomENRForm.ShowForm(facility, this);

				//mam - update facility with possible new ENR values
				if (facility.UsesCustomENRTable)
					facility.LoadCustomENRValues(facility.CustomENRListID);
				//</mam>
			}
			else
			{
				ManageCustomENRForm.ShowForm(null, this);
			}

			// refresh the current view
			//mam
			RefreshCurrentView();
			//</mam>
		}

		private object GetSelectedNodeObject()
		{
			TreeNode		node = treeViewFacility.SelectedNode;

			if (node == null)
				return null;

			return node.Tag;
		}

		private ArrayList GetExpandedNodes()
		{
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();

			//return commonTasks.RecordTreeExpandedState(treeViewFacility);
			nodesExpandedMainForm = commonTasks.RecordTreeExpandedState(treeViewFacility);

			commonTasks = null;

			return nodesExpandedMainForm;
		}

		private void menuItemEdit_GlobalUpdate_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to update data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			Facility		facility = GetFacilityForSelectedNode();

			GlobalUpdateForm.ShowForm(facility, this);
			// Refresh the current screen
			treeViewFacility_AfterSelect(null, null);
			RefreshCurrentView();
		}

		//mam
		private void menuItemEdit_Preferences_Click(object sender, System.EventArgs e)
		{
			ShowPreferences();
		}
		//</mam>

		private void menuItemGraph_SetupGraph_Click(object sender, System.EventArgs e)
		{
			UpdateCurrentDisplay();
			SaveCurrentDisplay();

			//mam
			GetExpandedNodes();
			//</mam>

			//mam - added nodesExpandedMainForm parameter
			GraphBuilderForm.ShowForm(this, nodesExpandedMainForm);
			//</mam>
		}

		private void menuItemReports_FieldSheets_Click(object sender, System.EventArgs e)
		{
			//mam - new code to select and print field sheets

			//mam
			UpdateCurrentDisplay();
			SaveCurrentDisplay();
			GetExpandedNodes();
			//</mam>

			//make sure Reports.xml file exists
			string filePath = string.Format(@"{0}\Reports.xml", Drive.IO.Directory.GetApplicationPath());
			if (!System.IO.File.Exists(filePath))
			{
				System.Windows.Forms.MessageBox.Show("The report file (Reports.xml) cannot be found.", "Cannot Find Report File",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
				return;
			}
			//</mam>

			//mam
			WAM.UI.FieldSheet.ShowForm(this, nodesExpandedMainForm);
			//</mam>
		}

		private void MainForm_Resize(object sender, System.EventArgs e)
		{
			try
			{
				if (splitter1.SplitPosition > this.Width - 100 && this.WindowState != FormWindowState.Minimized)
					splitter1.SplitPosition = this.Width - 200;
			}
			catch
			{
			}
		}

		private void MainForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//WAM.UI.FX.FX.PaintGradient(sender, e, this.Height, this.Width);
		}

		//mam
		private void button1_Click(object sender, System.EventArgs e)
		{
			WAM.UI.FieldSheet form = new FieldSheet();
			form.ShowDialog();
		}
		//</mam>

		//mam
		private bool LoadDatabase(string loadDatabase)
		{
			//mam 102309 - no longer storing data in Access databases
			return true;

			//			if (loadDatabase.Length == 0)
			//				return false;
			//
			//			//note the existing database, in case there's an error and we have to reload it
			//			string currentDatabase = Drive.Configuration.AppSettings.Settings.GetSetting("DBConnection", "LastSource");
			//
			//			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();
			//
			//			if (verify.VerifyTableNamesAndFields(loadDatabase))
			//			{
			//				string dbPath = string.Format(@"{0}\" + loadDatabase, Drive.IO.Directory.GetApplicationPath());
			//				Drive.Data.OleDb.Jet40DataSource dataSource = new Drive.Data.OleDb.Jet40DataSource(dbPath);
			//
			//				InfoSet[] infoSets = null;
			//
			//				try
			//				{
			//					bool resultUpdate = false;
			//					WAM.Common.Update4 update4 = new WAM.Common.Update4(dbPath);
			//					resultUpdate = update4.PerformUpdate();
			//					update4 = null;
			//				}
			//				catch
			//				{
			//				}
			//
			//				try
			//				{
			//					WAM.Data.WAMSource.CurrentSource = dataSource;
			//
			//					Drive.Configuration.AppSettings.Settings.Save();
			//
			//					//perform database updates
			//
			//					//mam 102309 - don't perform updates for now
			////					bool resultUpdate = false;
			////					WAM.Common.Update1 update1 = new WAM.Common.Update1(WAM.Data.WAMSource.CurrentSource.ConnectionString);
			////					resultUpdate = update1.PerformUpdate();
			////
			////					WAM.Common.Update2 update2 = new WAM.Common.Update2(WAM.Data.WAMSource.CurrentSource.ConnectionString);
			////					resultUpdate = update2.PerformUpdate();
			////
			////					WAM.Common.Update3 update3 = new WAM.Common.Update3(WAM.Data.WAMSource.CurrentSource.ConnectionString);
			////					resultUpdate = update3.PerformUpdate();
			////
			////					update1 = null;
			////					update2 = null;
			////					update3 = null;
			//					//
			//
			//					try
			//					{
			//						infoSets = InfoSet.LoadAll(dataSource.ConnectionString);
			//					}
			//					catch (Exception ex)
			//					{
			//						System.Diagnostics.Trace.WriteLine(ex.Message);
			//						infoSets = new InfoSet[0];
			//					}
			//
			//					if (infoSets.Length == 0)
			//					{
			//						// Create a default info set
			//						InfoSet		defaultSet = new InfoSet(0);
			//
			//						defaultSet.Name = "Default";
			//						defaultSet.Save();
			//
			//						Drive.Configuration.AppSettings.Settings.SetSetting(
			//							"Defaults", "LastInfoSet", defaultSet.ID.ToString());
			//
			//						InfoSet.CurrentID = defaultSet.ID;
			//						LoadCacheForm.ShowForm(defaultSet.ID, this, true);
			//					}
			//					else
			//					{
			//						InfoSet infoSet = new InfoSet(infoSets[0].ID);
			//						InfoSet.CurrentID = infoSet.ID;
			//						LoadCacheForm.ShowForm(infoSet.ID, this, true);
			//					}
			//
			//					//create the FieldSheet.xml file
			//					try
			//					{
			//						WAM.Common.StartUpChores startUpChores = new WAM.Common.StartUpChores();
			//						startUpChores.CreateFieldSheetFileFromDatabase();
			//					}
			//					catch(Exception ex)
			//					{
			//						System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			//					}
			//
			//					PopulateTree();
			//
			//					try
			//					{
			//						WAM.Common.StartUpChores startUpChores = new WAM.Common.StartUpChores();
			//						//startUpChores.SetDatabaseImageFolderName(infosetFolderPath);
			//						string imagePath = Drive.IO.Directory.GetApplicationPath();
			//						imagePath = string.Format(@"{0}\Images", imagePath);
			//						imagePath += @"\" + treeViewFacility.Nodes[0].Text;
			//						currentDatabaseImageFolder = startUpChores.SetDatabaseImageFolderName(@imagePath);
			//					}
			//					catch
			//					{
			//						currentDatabaseImageFolder = "";
			//					}
			//
			//					string currentDB = "";
			//					if (dbPath != null && dbPath.Length != 0)
			//					{
			//						currentDB = Drive.IO.Directory.GetFileNameFromPath(dbPath, true);
			//
			//						//mam 090105 - added a check to make sure there is no connection string data in the string
			//						//	returned from Drive
			//						currentDB = WAM.Common.CommonTasks.RemoveConnectionDataFromStringToGetFileName(currentDB);
			//					}
			//
			//					if (currentDB == null || currentDB.Length == 0)
			//					{
			//						this.textBoxCurrentDatabase.Text = "No database found";
			//					}
			//					else
			//					{
			//						this.textBoxCurrentDatabase.Text = currentDB;
			//					}
			//
			//					if (treeViewFacility.Nodes.Count > 0 && treeViewFacility.Nodes[0].Nodes.Count > 0)
			//						treeViewFacility.SelectedNode = treeViewFacility.Nodes[0].Nodes[0];
			//				}
			//				catch (Exception ex)
			//				{
			//					System.Diagnostics.Trace.WriteLine(ex.Message);
			//
			//					//note the previous database in the app settings
			//					if (currentDatabase != null && currentDatabase.Length != 0)
			//						Drive.Configuration.AppSettings.Settings.SetSetting("DBConnection", currentDatabase);
			//				}
			//			}
			//			else
			//			{
			//				MessageBox.Show(loadDatabase + " is not valid");
			//				return false;
			//			}
			//
			//			return true;
		}
		//</mam>

		private void menuItemFile_Select(object sender, System.EventArgs e)
		{
			//mam - update the data in the active form
			SaveCurrentDisplay();
		}

		private void menuItem5_Select(object sender, System.EventArgs e)
		{
			//mam - update the data in the active form
			SaveCurrentDisplay();
		}

		private void menuItemReports_Select(object sender, System.EventArgs e)
		{
			//mam - update the data in the active form
			SaveCurrentDisplay();
		}

		private void menuItemHelp_Select(object sender, System.EventArgs e)
		{
			//mam - update the data in the active form
			//SaveCurrentDisplay();
			if (facilityControl1 != null)
				facilityControl1.HideGrid();
		}
		//</mam>

		//mam
		private void UpdateCurrentDisplay()
		{
			NodeType		type = GetSelectedNodeType();
			TreeNode		node = treeViewFacility.SelectedNode;
			int				currentTabIndex = 0;

			switch (type)
			{
					//case NodeType.InfoSet:
					//	infoSetControl1.SetInfoSet(node.Tag as InfoSet);
					//	break;
				case NodeType.Facility:
					currentTabIndex = facilityControl1.TabControlIndex;
					if (currentTabIndex == 0)
					{
						facilityControl1.SetFacility(node.Tag as Facility);
						facilityControl1.TabControlIndex = currentTabIndex;
					}
					else if (currentTabIndex == 1)
					{
						facilityControl1.SetFacilityFunded(node.Tag as Facility);
						facilityControl1.TabControlIndex = currentTabIndex;
					}
					break;
				case NodeType.TreatmentProcess:
					currentTabIndex = treatmentProcessControl1.TabControlIndex;
					if (currentTabIndex == 0)
					{
						treatmentProcessControl1.SetProcess(node.Tag as TreatmentProcess);
						treatmentProcessControl1.TabControlIndex = currentTabIndex;
					}
					break;
				case NodeType.MajorComponent:
					currentTabIndex = majorComponentControl1.TabControlIndex;
					if (currentTabIndex == 0)
					{
						majorComponentControl1.SetComponent(node.Tag as MajorComponent);
						majorComponentControl1.TabControlIndex = currentTabIndex;
					}
					break;
				case NodeType.DisciplineMech:
					currentTabIndex = disciplineMechControl1.TabControlIndex;
					if (currentTabIndex == 0 || currentTabIndex == 1)
					{
						disciplineMechControl1.SetDiscipline(node.Tag as DisciplineMech);
						disciplineMechControl1.TabControlIndex = currentTabIndex;
					}

					//mam
					disciplineMechControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineStruct:
					currentTabIndex = disciplineStructControl1.TabControlIndex;
					if (currentTabIndex == 0 || currentTabIndex == 1)
					{
						disciplineStructControl1.SetDiscipline(node.Tag as DisciplineStruct);
						disciplineStructControl1.TabControlIndex = currentTabIndex;
					}

					//mam
					disciplineStructControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineLand:
					currentTabIndex = disciplineLandControl1.TabControlIndex;
					if (currentTabIndex == 0 || currentTabIndex == 1)
					{
						disciplineLandControl1.SetDiscipline(node.Tag as DisciplineLand);
						disciplineLandControl1.TabControlIndex = currentTabIndex;
					}

					//mam
					disciplineLandControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplineNode:
					currentTabIndex = disciplineNodesControl1.TabControlIndex;
					if (currentTabIndex == 0)
					{
						disciplineNodesControl1.SetDiscipline(node.Tag as DisciplineNode);
						disciplineNodesControl1.TabControlIndex = currentTabIndex;
					}

					//mam
					disciplineNodesControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.DisciplinePipe:
					currentTabIndex = disciplinePipeControl1.TabControlIndex;
					if (currentTabIndex == 0)
					{
						disciplinePipeControl1.SetDiscipline(node.Tag as DisciplinePipe);
						disciplinePipeControl1.TabControlIndex = currentTabIndex;
					}

					//mam
					disciplinePipeControl1.SetEquationControls();
					//</mam>

					break;
				case NodeType.AssetList:
					assetListControl1.SetComponent(node.Tag as MajorComponent);
					break;
				default:
					break;
			}
		}
		//</mam>

		//mam
		private void UpdateEquationControls()
		{
			NodeType		type = GetSelectedNodeType();
			TreeNode		node = treeViewFacility.SelectedNode;
			switch (type)
			{
				case NodeType.InfoSet:
					break;
				case NodeType.Facility:
					facilityControl1.SetEquationControls();
					break;
				case NodeType.TreatmentProcess:
					treatmentProcessControl1.SetEquationControls();
					break;
				case NodeType.MajorComponent:
					majorComponentControl1.SetEquationControls();
					break;
				case NodeType.DisciplineMech:
					disciplineMechControl1.SetEquationControls();
					break;
				case NodeType.DisciplineStruct:
					disciplineStructControl1.SetEquationControls();
					break;
				case NodeType.DisciplineLand:
					disciplineLandControl1.SetEquationControls();
					break;
				case NodeType.DisciplineNode:
					disciplineNodesControl1.SetEquationControls();
					break;
				case NodeType.DisciplinePipe:
					disciplinePipeControl1.SetEquationControls();
					break;
				case NodeType.AssetList:
					break;
				default:
					break;
			}
		}
		//</mam>

		private void menuItemEditDeleteDatabase_Click(object sender, System.EventArgs e)
		{
			UpdateCurrentDisplay();
			SaveCurrentDisplay();

			MessageBox.Show("The 'Delete Database' feature is not yet available.", "Delete Database", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		//mam
		private void SaveCurrentDisplay()
		{
			//need to check the dirty flag before saving
			//update: just save the data
			NodeType		type = GetSelectedNodeType();
			TreeNode		node = treeViewFacility.SelectedNode;

			if (facilityControl1 != null)
				facilityControl1.HideGrid();

			switch (type)
			{
				case NodeType.Facility:
					facilityControl1.SaveData();
					break;
				case NodeType.TreatmentProcess:
					treatmentProcessControl1.SaveData();
					break;
				case NodeType.MajorComponent:
					majorComponentControl1.SaveData();

					//mam 07072011 - it's ok to not save criticality values here because this is for saving any screen data that may have changed
					//	- the criticality values are saved immediately when they are changed, so it is unnecessary to save them again here

					break;
				case NodeType.DisciplineMech:
					disciplineMechControl1.SaveData();
					break;
				case NodeType.DisciplineStruct:
					disciplineStructControl1.SaveData();
					break;
				case NodeType.DisciplineLand:
					disciplineLandControl1.SaveData();
					break;
				case NodeType.DisciplineNode:
					disciplineNodesControl1.SaveData();
					break;
				case NodeType.DisciplinePipe:
					disciplinePipeControl1.SaveData();
					break;
					//case NodeType.AssetList:
					//assetListControl1.SaveData();
					//break;
				default:
					break;
			}
		}
		//</mam>

		//mam
		private void treeViewFacility_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			if (treeViewFacility.SelectedNode != null)
			{
				SaveCurrentDisplay();
			}
		}
		//</mam>

		//mam - set controls for default or regular infosets
		private void SetControls()
		{
			bool isFixedInfoset = InfoSet.IsFixed;

			if (isFixedInfoset)
			{
				pictureBoxToolbarAdd.Enabled = false;
				pictureBoxToolbarCopy.Enabled = false;
				pictureBoxToolbarDelete.Enabled = false;

				toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOff8.bmp");
				toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
				this.pictureBoxToolbarAdd.Image = toolbarImage;

				toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonCopyOff8.bmp");
				toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
				this.pictureBoxToolbarCopy.Image = toolbarImage;

				toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOff8.bmp");
				toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
				this.pictureBoxToolbarDelete.Image = toolbarImage;

				menuItemFile_Import_Nodes.Enabled = false;
				menuItemFile_Import_Pipes.Enabled = false;
				menuItemEdit_AddFacility.Enabled = false;
				menuItemEdit_AddNode.Enabled = false;
				menuItemEdit_CopyNode.Enabled = false;
				menuItemEdit_DeleteNode.Enabled = false;
				menuItemEdit_ChangeSortOrder.Enabled = false;
				menuItemEdit_20CitiesENR.Enabled = false;
				menuItemEdit_CustomENR.Enabled = false;
				menuItemEdit_GlobalUpdate.Enabled = false;
			}
			else
			{
				NodeType type = GetSelectedNodeType();

				//toolbar buttons *******************
				if (type == NodeType.Facility || type == NodeType.TreatmentProcess || type == NodeType.MajorComponent)
				{
					pictureBoxToolbarCopy.Enabled = true;
					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonCopyOn8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarCopy.Image = toolbarImage;

					pictureBoxToolbarDelete.Enabled = true;

					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOn8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarDelete.Image = toolbarImage;
				}
				else
				{
					pictureBoxToolbarCopy.Enabled = false;
					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonCopyOff8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarCopy.Image = toolbarImage;

					pictureBoxToolbarDelete.Enabled = false;

					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOff8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarDelete.Image = toolbarImage;
				}

				if (type == NodeType.InfoSet || type == NodeType.Facility || type == NodeType.TreatmentProcess)
				{
					pictureBoxToolbarAdd.Enabled = true;

					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarAdd.Image = toolbarImage;

				}
				else
				{
					pictureBoxToolbarAdd.Enabled = false;

					toolbarImageFile = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOff8.bmp");
					toolbarImage = (Bitmap)Bitmap.FromStream(toolbarImageFile);
					this.pictureBoxToolbarAdd.Image = toolbarImage;
				}

				//menu items ************************

				menuItemFile_Import_Nodes.Enabled = true;
				menuItemFile_Import_Pipes.Enabled = true;
				menuItemEdit_AddFacility.Enabled = true;
				menuItemEdit_20CitiesENR.Enabled = true;
				menuItemEdit_CustomENR.Enabled = true;

				menuItemEdit_AddNode.Enabled = (type == NodeType.Facility || type == NodeType.TreatmentProcess);
				menuItemEdit_CopyNode.Enabled = (type == NodeType.Facility || type == NodeType.TreatmentProcess 
					|| type == NodeType.MajorComponent);
				menuItemEdit_DeleteNode.Enabled = (type == NodeType.Facility || type == NodeType.TreatmentProcess 
					|| type == NodeType.MajorComponent);
				menuItemEdit_ChangeSortOrder.Enabled = (type == NodeType.InfoSet || type == NodeType.Facility || type == NodeType.TreatmentProcess);
				
				menuItemEdit_GlobalUpdate.Enabled = (type != NodeType.InfoSet && type != NodeType.NoneSelected);

				//enable Custom ENR menu item only when the selected facility 
				//	has the Use Custom ENR checkbox checked and is not in a fixed infoset
				//	and enable GlobalUpdate only when the infoset is not fixed
				Facility facility = GetFacilityForSelectedNode();

				if (facility != null)
				{
					menuItemEdit_GlobalUpdate.Enabled = !InfoSet.IsFixed;
				}
			}

			Bitmap b = (Bitmap)pictureBoxToolbarAdd.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarAdd.Image = b;

			b = (Bitmap)pictureBoxToolbarCopy.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarCopy.Image = b;

			b = (Bitmap)pictureBoxToolbarDelete.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarDelete.Image = b;
		}
		//</mam>

		//mam
		private void SetBitmaps()
		{
			//load toolbar pictureboxes with bitmaps
			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			//			System.Reflection.Assembly thisExe;
			//			thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			System.IO.Stream file = null;
			Image image = null;

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonAddOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarAdd.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarAdd);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonDeleteOff8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarDelete.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarDelete);

			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonEquationOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarEquationBox.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarEquationBox);
			
			file = thisExe.GetManifestResourceStream("WAM.Graphics.ButtonHelpOn8.bmp");
			image = (Bitmap)Bitmap.FromStream(file);
			this.pictureBoxToolbarHelp.Image = image;
			commonTasks.SetBitmap(pictureBoxToolbarHelp);

			//***************************

			Bitmap b = (Bitmap)pictureBoxToolbarAdd.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarAdd.Image = b;

			b = (Bitmap)pictureBoxToolbarCopy.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarCopy.Image = b;

			b = (Bitmap)pictureBoxToolbarDelete.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarDelete.Image = b;

			b = (Bitmap)pictureBoxToolbarEquationBox.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarEquationBox.Image = b;

			b = (Bitmap)pictureBoxToolbarPreferences.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBoxToolbarPreferences.Image = b;

			//b = (Bitmap)pictureBoxToolbarHelp.Image;
			//b.MakeTransparent(System.Drawing.Color.Fuchsia);
			//pictureBoxToolbarHelp.Image = b;

			commonTasks = null;
			file = null;
			image = null;
		}
		//</mam>

		//mam
		private void pictureBoxToolbarAdd_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to add data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (facilityControl1 != null)
				facilityControl1.HideGrid();

			PerformPreAddTasks();

			NodeType		type = GetSelectedNodeType();
			TreeNode		treeNode = treeViewFacility.SelectedNode;

			if (type == NodeType.InfoSet)
			{
				AddFacility(string.Empty, false);
			}
			else
			{
				AddNode();
			}

		}
		//</mam>

		//mam
		private void PerformPreAddTasks()
		{
			TreeNode node = treeViewFacility.SelectedNode;
			if (node == null)
				return;

			SaveCurrentDisplay();

			////mam 03202012 - this was changed in treeViewFacility_BeforeExpand and, although I can't see a situation in which it will be a problem in this method, 
			//	it has been changed here just in case there is a problem that I haven't thought of
			//it was changed in treeViewFacility_BeforeExpand due to a problem during importing
			//if (node.Nodes.Count == 1)
			if (node.Nodes.Count > 0)
			{
				// Check to see if it is a placeholder node
				if (node.Nodes[0].Tag == null)
				{
					node.Nodes.Clear();

					if (node.Tag is Facility)
						AddProcessNodes(node);
					else if (node.Tag is TreatmentProcess)
						AddMajorComponentNodes(node);
					else if (node.Tag is MajorComponent)
						AddDisciplineNodes(node);
				}
			}
		}
		//</mam>

		//mam
		private void pictureBoxToolbarDelete_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to delete data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (facilityControl1 != null)
				facilityControl1.HideGrid();

			DeleteNode();
			treeViewFacility.Focus();
		}
		//</mam>

		//mam
		private void pictureBoxToolbarCopy_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to copy data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			if (facilityControl1 != null)
				facilityControl1.HideGrid();

			CopyNode();
		}	
		//</mam>

		//mam
		private void pictureBoxToolbarEquationBox_Click(object sender, System.EventArgs e)
		{
			UpdateCurrentDisplay();
			SaveCurrentDisplay();

			// check whether the form is already open before opening a new one
			if (equationViewer == null ||equationViewer.IsDisposed)
			{
				equationViewer = new WAM.UI.EquationViewer(this);
			}
			else
			{
				equationViewer.WindowState = FormWindowState.Normal;
				this.Focus();
			}

			eqnFormOpen = true;
			UpdateEquationControls();
			equationViewer.Show();
		}
		//</mam>

		private void pictureBoxToolbarPreferences_Click(object sender, System.EventArgs e)
		{
			UpdateCurrentDisplay();
			SaveCurrentDisplay();

			if (facilityControl1 != null)
				facilityControl1.HideGrid();

			ShowPreferences();
		}

		private void ShowPreferences()
		{
			//mam 01222012
			bool curFacCrit = WAM.Common.Globals.ApplyFacilityCriticalityFactor;

			OptionsMain optionsMainForm = new OptionsMain(this);
			DialogResult dialogResult = optionsMainForm.ShowDialog();

			if (dialogResult == DialogResult.OK)
			{
				try
				{
					//rounding
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "Rounding", Convert.ToInt32(WAM.Common.Globals.AllowRounding).ToString());
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "RoundingDigit", WAM.Common.Globals.AllowRoundingDigit.ToString());

					//graphing
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "GraphNameMatching", Convert.ToInt32(WAM.Common.Globals.AllowGraphNameMatching).ToString());

					//display
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "DisplayCostTab", Convert.ToInt32(WAM.Common.Globals.ShowCostTab).ToString());
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "DisplayFacValTab", Convert.ToInt32(WAM.Common.Globals.ShowFacilityValuationTab).ToString());

					//*************************************
					//mam 01042012
					//retired asset cost display
					Drive.Configuration.AppSettings.Settings.SetSetting(@"RetiredAssets", "ShowCostsZero", WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets.ToString());

					//  <ReadOnlyBackgroundColor>
					//    <NumericTextBoxesRgb>255,100,0</NumericTextBoxesRgb>
					//    <AssetNameTextBoxesRgb>0,150,255</AssetNameTextBoxesRgb>
					//    <ScreenRgb></ScreenRgb>
					//  </ReadOnlyBackgroundColor>

					//read-only text box color
					//System.ComponentModel.TypeConverter converter = System.ComponentModel.TypeDescriptor.GetConverter(WAM.Common.Globals.ReadOnlyBackgroundColorNumeric);
					//string colorAsString = converter.ConvertToString(WAM.Common.Globals.ReadOnlyBackgroundColorNumeric);

					//if a custom color is being used for the read-only text boxes, save the color data
					bool useCustomColor = WAM.Common.Globals.ApplyReadOnlyBackgroundColorNumeric;
					Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "UseCustomColor", useCustomColor.ToString());
					//if (useCustomColor)
					{
						string colorRgb = WAM.Common.CommonTasks.ColorConvertToRgb(WAM.Common.Globals.ReadOnlyBackgroundColorNumeric);
						Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "NumericTextBoxesRgb", colorRgb);
						Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "AssetNameTextBoxesRgb", colorRgb);

						colorRgb = WAM.Common.CommonTasks.ColorConvertToRgb(WAM.Common.Globals.ReadOnlyBackgroundColorScreen);
						Drive.Configuration.AppSettings.Settings.SetSetting(@"ReadOnlyBackgroundColor", "ScreenRgb", colorRgb);
					}
					//*************************************
					
					//mam 01222012
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "FacilityCriticality", Convert.ToInt32(WAM.Common.Globals.ApplyFacilityCriticalityFactor).ToString());

					//mam 03202012
					Drive.Configuration.AppSettings.Settings.SetSetting(@"Options", "WamSetPhotoFileName", Convert.ToInt32(WAM.Common.Globals.AllowWamToCreatePhotoFileNames).ToString());

					//make sure data is written to the WAM.xml file
					Drive.Configuration.AppSettings.Settings.Save();
				}
				catch
				{
				}

				//UpdateCurrentDisplay();
				NodeType type = GetSelectedNodeType();
				switch (type)
				{
					case NodeType.Facility:
						facilityControl1.SetTabVisibility();

						//mam 01222012 - added argument
						//mam 050806 - must call RefreshData or change in rounding won't affect the current facility display
						//facilityControl1.RefreshData();
						facilityControl1.RefreshData(true);

						break;
					case NodeType.TreatmentProcess:
						treatmentProcessControl1.SetTabVisibility();

						//mam 01222012
						if (curFacCrit != WAM.Common.Globals.ApplyFacilityCriticalityFactor)
						{
							treatmentProcessControl1.RefreshData(true);
						}

						//mam 01042012
						treatmentProcessControl1.SetReadOnlyTextBoxBackgroundColorBulk();

						break;
					case NodeType.MajorComponent:
						majorComponentControl1.SetTabVisibility();

						//mam 01222012
						if (curFacCrit != WAM.Common.Globals.ApplyFacilityCriticalityFactor)
						{
							majorComponentControl1.RefreshData(true);
						}

						//mam 01042012
						majorComponentControl1.SetReadOnlyTextBoxBackgroundColorBulk();

						break;

					//mam 01042012 - need to refresh read-only text box background color
					case NodeType.DisciplineLand:
						disciplineLandControl1.SetReadOnlyTextBoxBackgroundColorBulk();
						break;
					case NodeType.DisciplineMech:
						disciplineMechControl1.SetReadOnlyTextBoxBackgroundColorBulk();
						break;
					case NodeType.DisciplineStruct:
						disciplineStructControl1.SetReadOnlyTextBoxBackgroundColorBulk();
						break;
					case NodeType.DisciplinePipe:
						//mam 01222012
						disciplinePipeControl1.RefreshData(true);

						disciplinePipeControl1.SetReadOnlyTextBoxBackgroundColorBulk();
						break;
					case NodeType.DisciplineNode:
						//mam 01222012
						disciplineNodesControl1.RefreshData(true);

						disciplineNodesControl1.SetReadOnlyTextBoxBackgroundColorBulk();
						break;

					default:
						break;
				}
			}
		}
		//</mam>

		//mam
		private void form_HelpRequested(object sender, System.Windows.Forms.HelpEventArgs hlpEvent)
		{
			// This event is raised when the F1 key is pressed or the Help cursor is clicked

			Control requestingControl = (Control)sender;
			hlpEvent.Handled = true;
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.TableOfContents);
		}
		//</mam>

		//mam
		private void pictureBoxToolbarHelp_Click(object sender, System.EventArgs e)
		{
			if (facilityControl1 != null)
				facilityControl1.HideGrid();
			Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.TableOfContents);

		}
		//</mam>

		//mam
		private void CopyNode()
		{
			//mam 07072011 - added try/catch
			try
			{
				C1.Win.C1FlexGrid.C1FlexGrid gridErrors = Common.CommonTasks.GetErrorGrid();

				//this.Cursor = Cursors.WaitCursor;

				UpdateCurrentDisplay();
				SaveCurrentDisplay();

				//the grid goes blank (white) unless refreshed
				this.RefreshCurrentView();
				this.Refresh();

				NodeType nodeType = GetSelectedNodeType();
				TreeNode nodeSelected = treeViewFacility.SelectedNode;

				if (nodeSelected == null)
				{
					MessageBox.Show("Please click on an item to copy.", "Copy",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}
				else if (nodeType == NodeType.InfoSet)
				{
					MessageBox.Show("To copy an InfoSet, click 'InfoSet Management' on the File menu.", "Copy",
						MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				this.Cursor = Cursors.WaitCursor;

				//mam 07072011
				bool success = false;

				switch (nodeType)
				{
					case NodeType.Facility:
						treeViewFacility.BeginUpdate();

						//mam 07072011 - get the discipline rehab interval and rehab next values for components in this facility that have
						//	planning mode = replacement - no, just get them all regardless of planning mode
						//Common.CommonTasks.GetRehabValuesForFacility(((Facility)nodeSelected.Tag).ID);

						//mam 07072011 - added bool success
						success = CopyNodeFacility(nodeSelected, ref gridErrors);

						//mam 07072011
						if (!success)
						{
							treeViewFacility.EndUpdate();
							//Common.CommonTasks.ShowErrorMessage("CopyNode", "An error occurred while copying a Facility.");

							if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
							{
								ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(gridErrors, "Errors Occurred While Copying", "Copy Errors");
								errorDisplay.ShowInTaskbar = false;
								errorDisplay.ShowDialog(this);
							}

							return;
						}

						//set sort order
						foreach(TreeNode treeNode in nodeSelected.Parent.Nodes)
						{
							((Facility)treeNode.Tag).SortOrder = treeNode.Index;
							((Facility)treeNode.Tag).Save();
						}

						CacheManager.GetFacilityCache(InfoSet.CurrentID).Sort();

						treeViewFacility.EndUpdate();
						break;
					case NodeType.TreatmentProcess:
						treeViewFacility.BeginUpdate();

						//mam 102309 - changed return type of CopyNodeProcess
						TreeNode newProcessNode = CopyNodeProcess((TreatmentProcess)nodeSelected.Tag, nodeSelected.Parent, 
							((TreatmentProcess)nodeSelected.Tag).FacilityID, true, ref gridErrors);

						//mam 07072011
						if (newProcessNode == null)
						{
							treeViewFacility.EndUpdate();
							//Common.CommonTasks.ShowErrorMessage("CopyNode", "An error occurred while copying a Treatment Process.");

							if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
							{
								ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(gridErrors, "Errors Occurred While Copying", "Copy Errors");
								errorDisplay.ShowInTaskbar = false;
								errorDisplay.ShowDialog(this);
							}

							return;
						}

						//set sort order
						foreach(TreeNode treeNode in nodeSelected.Parent.Nodes)
						{
							((TreatmentProcess)treeNode.Tag).SortOrder = treeNode.Index;
							((TreatmentProcess)treeNode.Tag).Save();
						}

						CacheManager.GetProcessCache(InfoSet.CurrentID).SortForFacility(
							((Facility)nodeSelected.Parent.Tag).ID);

						//mam 102309
						//nodeSelected.Parent.Nodes.Insert(nodeSelected.Index + 1, newProcessNode);

						treeViewFacility.EndUpdate();
						break;
					case NodeType.MajorComponent:
						treeViewFacility.BeginUpdate();

						//mam 07072011 - added bool success
						success = CopyNodeComponent((MajorComponent)nodeSelected.Tag, nodeSelected.Parent, 
							((TreatmentProcess)nodeSelected.Parent.Tag).FacilityID, ((TreatmentProcess)nodeSelected.Parent.Tag).FacilityID, 
							((TreatmentProcess)nodeSelected.Parent.Tag).ID, true, ref gridErrors); 

						//mam 07072011
						if (!success)
						{
							treeViewFacility.EndUpdate();
							//Common.CommonTasks.ShowErrorMessage("CopyNode", "An error occurred while copying a Major Component.");

							if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
							{
								ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(gridErrors, "Errors Occurred While Copying", "Copy Errors");
								errorDisplay.ShowInTaskbar = false;
								errorDisplay.ShowDialog(this);
							}

							return;
						}

						//set sort order
						foreach(TreeNode treeNode in nodeSelected.Parent.Nodes)
						{
							((MajorComponent)treeNode.Tag).SortOrder = treeNode.Index;
							((MajorComponent)treeNode.Tag).Save();

							//mam 07072011 - save criticality values here?
							//	no - this is setting the sort order - we've already created the node and saved it in CopyNodeComponent, above
						}

						CacheManager.GetComponentCache(InfoSet.CurrentID).SortForProcess(
							((TreatmentProcess)nodeSelected.Parent.Tag).ID);

						treeViewFacility.EndUpdate();
						break;
					case NodeType.AssetList:
					case NodeType.DisciplineMech:
					case NodeType.DisciplineStruct:
					case NodeType.DisciplineLand:
					case NodeType.DisciplineNode:
					case NodeType.DisciplinePipe:
						//facility = ((Discipline)selectedObject).GetFacility();
						break;
				}

				//mam 0707201 - if errors have occurred, show the user
				if (gridErrors.Rows.Count > gridErrors.Rows.Fixed)
				{
					ErrorDisplayMessage errorDisplay = new ErrorDisplayMessage(gridErrors, "Errors Occurred While Copying", "Copy Errors");
					errorDisplay.ShowInTaskbar = false;
					errorDisplay.ShowDialog(this);
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.ShowErrorMessage("MainForm.CopyNode", ex.Message);
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}
		//</mam>

		//mam
		private bool CopyNodeFacility(TreeNode nodeFacility, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			TreeNode newNode;
			TreeNode placeHolder;
			InfoSet infoSet = new InfoSet(InfoSet.CurrentID);
			Facility sourceFacility = 
				CacheManager.GetFacility(((Facility)nodeFacility.Tag).InfoSetID, ((Facility)nodeFacility.Tag).ID);
			Facility newFacility = new Facility(0);
			TreatmentProcess[] processes = CacheManager.GetProcesses(sourceFacility.InfoSetID, sourceFacility.ID);
			bool copyPhoto = true;
			string imagePath =  infoSet.GetImagePath();

			//string imagePathCopyTo = CreateImagesFolder("Copy of " + sourceFacility.Name);
			////string imagePathCopyTo = WAM.Common.CommonTasks.CreateImagesFolder("Copy of " + sourceFacility.Name);

			//string curDate = DateTime.Now.Ticks.ToString();
			//string curPath = Application.StartupPath;
			string curPath = WAM.Common.Globals.WamPhotoPath;
			//			if (!System.IO.Directory.Exists(curPath + "\\Images"))
			//			{
			//				System.IO.Directory.CreateDirectory(curPath + "\\Images");
			//			}
			if (!System.IO.Directory.Exists(curPath))
			{
				System.IO.Directory.CreateDirectory(curPath);
			}
			////string imagePathCopyTo = curPath + "\\Images\\" + "Copy of " + sourceFacility.Name + "_" + curDate;
			//string imagePathCopyTo = curPath + "\\" + "Copy of " + sourceFacility.Name + "_" + curDate;

			//			bool successCreatePhotoFolder = false;
			//			try
			//			{
			//				System.IO.Directory.CreateDirectory(imagePathCopyTo);
			//				successCreatePhotoFolder = true;
			//			}
			//			catch
			//			{
			//			}
			//			if (!successCreatePhotoFolder)
			//			{
			//				try
			//				{
			//					imagePathCopyTo = curDate;
			//					System.IO.Directory.CreateDirectory(imagePathCopyTo);
			//					successCreatePhotoFolder = true;
			//				}
			//				catch
			//				{
			//				}
			//			}			

			newFacility.InfoSetID = InfoSet.CurrentID;
			sourceFacility.CopyTo(newFacility, "Copy of " + sourceFacility.Name, copyPhoto);

			//mam 07072011 - added bool success
			bool success = newFacility.Save();

			//mam 07072011
			if (!success)
			{
				//Common.CommonTasks.ShowErrorMessage("CopyNode", "An error occurred while copying a Facility.");
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error copying Facility " + sourceFacility.Name);
				return false;
			}

			//mam - this is no longer necessary, as only the Facilities.CustomENRListID field is copied, rather than
			//	copying the actual ENR Table values
			//if (sourceFacility.UsesCustomENRTable)
			//	sourceFacility.CopyENRTable(newFacility);
			//</mam>

			if (copyPhoto)
			{
				//mam 102309 - use new destination imagePathCopyTo, and check for different photo name
				//mam 102309 - no, restore to original method
				string copyPhoto1From = string.Format(@"{0}\{1:D4}-N.jpg", @imagePath, sourceFacility.ID);
				string copyPhoto1To = string.Format(@"{0}\{1:D4}-N.jpg", @imagePath, newFacility.ID);
				//string copyPhoto1From = string.Empty;
				//string copyPhoto1To = string.Empty;
				//				if (sourceFacility.PhotoNorth != "")
				//				{
				//					copyPhoto1From = @imagePath + "\\" + sourceFacility.PhotoNorth;
				//					copyPhoto1To = @imagePathCopyTo + "\\" + newFacility.PhotoNorth;
				//				}
				//				else
				//				{
				//					copyPhoto1From = string.Format(@"{0}\{1:D4}-N.jpg", @imagePath, sourceFacility.ID);
				//					copyPhoto1To = string.Format(@"{0}\{1:D4}-N.jpg", imagePathCopyTo, newFacility.ID);
				//				}

				//mam 102309 - use new destination imagePathCopyTo, and check for different photo name
				//mam 102309 - no, restore to original method
				string copyPhoto2From = string.Format(@"{0}\{1:D4}-S.jpg", @imagePath, sourceFacility.ID);
				string copyPhoto2To = string.Format(@"{0}\{1:D4}-S.jpg", @imagePath, newFacility.ID);
				//				string copyPhoto2From = string.Empty;
				//				string copyPhoto2To = string.Empty;
				//				if (sourceFacility.PhotoSouth != "")
				//				{
				//					copyPhoto2From = @imagePath + "\\" + sourceFacility.PhotoSouth;
				//					copyPhoto2To = @imagePathCopyTo + "\\" + newFacility.PhotoSouth;
				//				}
				//				else
				//				{
				//					copyPhoto2From = string.Format(@"{0}\{1:D4}-S.jpg", @imagePath, sourceFacility.ID);
				//					copyPhoto2To = string.Format(@"{0}\{1:D4}-S.jpg", @imagePathCopyTo, newFacility.ID);
				//				}

				try
				{
					//if (System.IO.File.Exists(copyPhoto1From))
					System.IO.File.Copy(copyPhoto1From, copyPhoto1To, true);
				}
				catch
				{
				}

				try
				{
					//if (System.IO.File.Exists(copyPhoto2From))
					System.IO.File.Copy(copyPhoto2From, copyPhoto2To, true);
				}
				catch
				{
				}
			}

			newNode = new TreeNode(newFacility.Name);
			newNode.Tag = newFacility;

			newNode.ImageIndex = 1;
			newNode.SelectedImageIndex = 1;

			nodeFacility.Parent.Nodes.Insert(nodeFacility.Index + 1, newNode);

			if (sourceFacility.HasChildren)
			{
				placeHolder = new TreeNode("*PH*");
				placeHolder.Tag = null;
				//newNode.Nodes.Add(placeHolder);
			}

			for (int i = 0; i < processes.Length; i++)
			{
				//mam 07072011 - added return value
				TreeNode returnNode = CopyNodeProcess(processes[i], newNode, newFacility.ID, false, ref gridErrors);

				//mam 07072011
				if (returnNode == null)
				{
					return false;
				}
			}

			AddProcessNodes(newNode);

			return true;
		}
		//</mam>

		//mam
		//mam 07072011 - added gridErrors
		private TreeNode CopyNodeProcess(TreatmentProcess sourceProcess, TreeNode nodeNewFacility, 
			int newFacilityID, bool isSourceNode, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			TreeNode newNode = null;
			TreeNode placeHolder = null;
			TreatmentProcess newProcess = new TreatmentProcess(0);
			MajorComponent[] components = CacheManager.GetComponents(sourceProcess.InfoSetID, sourceProcess.ID);
			bool copyPhoto = true;

			//mam 07072011
			bool success = false;

			InfoSet infoSet = new InfoSet(InfoSet.CurrentID);
			string imagePath =  infoSet.GetImagePath();

			//			string imagePathCopyTo = newImageFolder;
			//			if (imagePathCopyTo == "")
			//			{
			//				//imagePathCopyTo = CreateImagesFolder("Copy of " + sourceProcess.Name);
			//				imagePathCopyTo = WAM.Common.CommonTasks.CreateImagesFolder("Copy of " + sourceProcess.Name);
			//			}

			newProcess.InfoSetID = sourceProcess.InfoSetID;
			newProcess.FacilityID = newFacilityID;

			if (isSourceNode)
				sourceProcess.CopyTo(newProcess, "Copy of " + sourceProcess.Name, copyPhoto);
			else
				sourceProcess.CopyTo(newProcess, sourceProcess.Name, copyPhoto);

			//mam 07072011 - added bool success
			success = newProcess.Save();

			//mam 07072011
			if (!success)
			{
				//Common.CommonTasks.ShowErrorMessage("CopyNodeProcess", "An error occurred while copying a Treatment Process");
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error copying Treatment Process " + sourceProcess.Name);
				return null;
			}

			if (nodeNewFacility != null)
			{
				((Facility)nodeNewFacility.Tag).RefreshTotals();
			}

			if (copyPhoto)
			{
				//mam 102309 - use new destination imagePathCopyTo, and check for different photo name
				//mam 102309 - no, restore original method
				string copyPhotoFrom = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", @imagePath, sourceProcess.FacilityID, sourceProcess.ID);
				string copyPhotoTo = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", @imagePath, newProcess.FacilityID, newProcess.ID);
				//				string copyPhotoFrom = string.Empty;
				//				string copyPhotoTo = string.Empty;
				//				if (sourceProcess.Photo != "")
				//				{
				//					copyPhotoFrom = @imagePath + "\\" + sourceProcess.Photo;
				//					copyPhotoTo = @imagePathCopyTo + "\\" + newProcess.Photo;
				//				}
				//				else
				//				{
				//					copyPhotoFrom = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", @imagePath, sourceProcess.FacilityID, sourceProcess.ID);
				//					copyPhotoTo = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", @imagePathCopyTo, newProcess.FacilityID, newProcess.ID);
				//				}

				try
				{
					//if (System.IO.File.Exists(copyPhotoFrom))
					System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
				}
				catch
				{
				}
			}

			//mam 07072011 - just use this code once, rather than repeatedly depending on save results
			newNode = new TreeNode(newProcess.Name);
			newNode.Tag = newProcess;
			newNode.ImageIndex = 2;
			newNode.SelectedImageIndex = 2;

			if (isSourceNode)
			{
				TreeNode nodeSelected = treeViewFacility.SelectedNode;
				nodeSelected.Parent.Nodes.Insert(nodeSelected.Index + 1, newNode);
				//nodeNewFacility.Nodes.Insert(treeViewFacility.SelectedNode.Index + 1, newNode);
				//nodeNewFacility.Nodes.Add(newNode);
				//}

				if (sourceProcess.HasChildren)
				{
					placeHolder = new TreeNode("*PH*");
					placeHolder.Tag = null;
					//newNode.Nodes.Add(placeHolder);
				}
			}

			//mam 07072011 - proc save was successful, but it has no components, so we must add the proc node to the tree here
			if (!isSourceNode && components.Length == 0)
			{
				//create proc node in tree
				TreeNode nodeSelected = treeViewFacility.SelectedNode;
				nodeNewFacility.Nodes.Add(newNode);
			}

			for (int i = 0; i < components.Length; i++)
			{
				//mam 07072011 - added bool success, gridErrors
				success = CopyNodeComponent(components[i], newNode, sourceProcess.FacilityID, 
					newFacilityID, newProcess.ID, false, ref gridErrors);

				if (!isSourceNode && !success)
				{
					//if we're not copying a process, then we must be copying a facility
					//if copying the component failed, we must add the process node to the tree here,
					//because the code that creates the process node won't be called
					TreeNode nodeSelected = treeViewFacility.SelectedNode;
					nodeNewFacility.Nodes.Add(newNode);
					return null;
				}
			}

			if (isSourceNode)
			{
				AddMajorComponentNodes(newNode);
			}

			return newNode;
		}
		//</mam>

		//mam
		private bool CopyNodeComponent(MajorComponent sourceComponent, TreeNode nodeNewProcess, 
			int sourceFacilityID, int newFacilityID, int newProcessID, bool isSourceNode, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			TreeNode newNode = null;
			TreeNode placeHolder = null;
			MajorComponent newComponent = new MajorComponent(0);
			bool copyPhoto = true;
			string copyPhotoFrom = "";
			string copyPhotoTo = "";

			InfoSet infoSet = new InfoSet(InfoSet.CurrentID);
			string imagePath =  infoSet.GetImagePath();

			//mam 102309
			//			string imagePathCopyTo = newImageFolder;
			//			if (imagePathCopyTo == "")
			//			{
			//				//imagePathCopyTo = CreateImagesFolder("Copy of " + sourceComponent.Name);
			//				imagePathCopyTo = WAM.Common.CommonTasks.CreateImagesFolder("Copy of " + sourceComponent.Name);
			//			}

			newComponent.InfoSetID = sourceComponent.InfoSetID;
			newComponent.ProcessID = newProcessID;

			if (isSourceNode)
				sourceComponent.CopyTo(newComponent, "Copy of " + sourceComponent.Name, copyPhoto);
			else
				sourceComponent.CopyTo(newComponent, sourceComponent.Name, copyPhoto);

			//mam 07072011 - added bool success
			bool success = newComponent.Save();

			//mam 07072011
			if (!success)
			{
				//Common.CommonTasks.ShowErrorMessage("CopyNodeComponent", "An error occurred while copying a Major Component");
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error copying Major Component " + sourceComponent.Name);
				return false;
			}

			//mam 07072011
			newComponent.InsertCriticalityValuesAllCopy(sourceComponent.ID, newComponent.ID);

			if (nodeNewProcess != null)
			{
				((TreatmentProcess)nodeNewProcess.Tag).RefreshTotals();
			}

			if (copyPhoto)
			{
				//mam 102309 - use new destination imagePathCopyTo, and check for different photo name
				//mam 102309 - no, restore original method
				copyPhotoFrom = string.Format(@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @imagePath, sourceFacilityID, sourceComponent.ProcessID, sourceComponent.ID);
				copyPhotoTo = string.Format(@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @imagePath, newFacilityID, newProcessID, newComponent.ID);
				//				copyPhotoFrom = string.Empty;
				//				copyPhotoTo = string.Empty;
				//				if (sourceComponent.Photo != "")
				//				{
				//					copyPhotoFrom = @imagePath + "\\" + sourceComponent.Photo;
				//					copyPhotoTo = @imagePathCopyTo + "\\" + newComponent.Photo;
				//				}
				//				else
				//				{
				//					copyPhotoFrom = string.Format(@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", imagePath, sourceFacilityID, sourceComponent.ProcessID, sourceComponent.ID);
				//					copyPhotoTo = string.Format(@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", @imagePathCopyTo, newFacilityID, newProcessID, newComponent.ID);
				//				}

				try
				{
					//if (System.IO.File.Exists(copyPhotoFrom))
					System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
				}
				catch
				{
				}
			}

			//mam 07072011 - move this code down
//			if (isSourceNode)
//			{
//				newNode = new TreeNode(newComponent.Name);
//				newNode.Tag = newComponent;
//
//				newNode.ImageIndex = 3;
//				newNode.SelectedImageIndex = 3;
//
//				nodeNewProcess.Nodes.Insert(treeViewFacility.SelectedNode.Index + 1, newNode);
//
//				placeHolder = new TreeNode("*PH*");
//				placeHolder.Tag = null;
//				newNode.Nodes.Add(placeHolder);
//			}

			//mam 07072011 - added bool success
			success = CopyNodeDiscipline(sourceComponent, newComponent, newNode, sourceFacilityID, newFacilityID, ref gridErrors);	//, int newProcessID, bool isSourceNode);

			//mam 07072011 - moved this code down from above
			if (isSourceNode && success)
			{
				newNode = new TreeNode(newComponent.Name);
				newNode.Tag = newComponent;

				newNode.ImageIndex = 3;
				newNode.SelectedImageIndex = 3;

				nodeNewProcess.Nodes.Insert(treeViewFacility.SelectedNode.Index + 1, newNode);

				placeHolder = new TreeNode("*PH*");
				placeHolder.Tag = null;
				newNode.Nodes.Add(placeHolder);
			}

			//mam 07072011
			//if copying disciplines failed, remove component from database and cache
			if (!success)
			{
				//mam 07072011 - errors occurred when creating the new component (either during creation of the component, or one of the disciplines)
				//	we don't really care why it failed - remove it from the database, if it exists
				//Common.CommonTasks.ShowErrorMessage("CopyNodeComponent", "An error occurred while copying a Discipline.");
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error copying Disciplines for Major Component " + sourceComponent.Name);
				bool successDelete = newComponent.Delete();
				if (successDelete)
				{
					Drive.Synchronization.SyncAction del = Drive.Synchronization.SyncAction.Delete;
					Drive.Data.SqlClient.SqlDALBase.InvokeChangeEvent(newComponent, new Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs(newComponent, del));
				}
				else
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error during clean-up of failed Major Component creation");
				}
			}

			return success;
		}
		//</mam>

		//mam
		private bool CopyNodeDiscipline(MajorComponent sourceComponent, MajorComponent newComponent, 
			TreeNode nodeNewComponent, int sourceFacilityID, int newFacilityID, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			int infoSetID = sourceComponent.InfoSetID;
			int sourceComponentID = sourceComponent.ID;
			int newComponentID = newComponent.ID;
			int sourceProcessID = sourceComponent.ProcessID;
			int newProcessID = newComponent.ProcessID;
			bool copyPhoto = true;

			InfoSet infoSet = new InfoSet(InfoSet.CurrentID);
			string imagePath =  infoSet.GetImagePath();

			//			string imagePathCopyTo = newImageFolder;
			//			if (imagePathCopyTo == "")
			//			{
			//				//imagePathCopyTo = CreateImagesFolder("Copy of " + newComponent.Name + "_Disciplines");
			//				imagePathCopyTo = WAM.Common.CommonTasks.CreateImagesFolder("Copy of " + newComponent.Name + "_Disciplines");
			//			}

			Discipline[] disciplines = CacheManager.GetDisciplines(sourceComponent.InfoSetID, sourceComponentID);
			Discipline newDiscipline = null;
			bool importAssetList = false;
			bool importPipeData = false;
			bool importNodeData = false;

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			//int disciplineId = 0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				importAssetList = false;
				importPipeData = false;
				importNodeData = false;

				switch (disciplines[pos].Type)
				{
					case DisciplineType.Mechanical:
						newDiscipline = new DisciplineMech(0);

						//mam 102309
						//						newDiscipline.InfoSetID = infoSetID;
						//						newDiscipline.ComponentID = newComponentID;
						//						//disciplines[pos].CopyTo(newDiscipline, copyPhoto);
						//						//disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
						//						disciplines[pos].CopyTo(newDiscipline, copyPhoto);
						//						//newDiscipline = new DisciplineMech(disciplineId);
						//						newDiscipline.Save();

						importAssetList = true;
						break;
					case DisciplineType.Structural:
						newDiscipline = new DisciplineStruct(0);

						//mam 102309
						//						newDiscipline.InfoSetID = infoSetID;
						//						newDiscipline.ComponentID = newComponentID;
						//						disciplines[pos].CopyTo(newDiscipline, copyPhoto);
						//						//disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
						//						//newDiscipline = new DisciplineStruct(disciplineId);
						//						newDiscipline.Save();

						break;
					case DisciplineType.Land:
						newDiscipline = new DisciplineLand(0);

						//mam 102309
						//						newDisciplineLand.InfoSetID = infoSetID;
						//						newDisciplineLand.ComponentID = newComponentID;
						//						disciplines[pos].CopyTo(newDisciplineLand, copyPhoto);
						//						//disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
						//						//newDiscipline = new DisciplineLand(disciplineId);
						//						newDisciplineLand.Save();

						break;
					case DisciplineType.Pipes:
						newDiscipline = new DisciplinePipe(0);

						//mam 102309
						//						newDisciplinePipe.InfoSetID = infoSetID;
						//						newDisciplinePipe.ComponentID = newComponentID;
						//						disciplines[pos].CopyTo(newDisciplinePipe, copyPhoto);
						//						//disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
						//						//newDiscipline = new DisciplinePipe(disciplineId);
						//						newDisciplinePipe.Save();

						importPipeData = true;
						break;
					case DisciplineType.Nodes:
						newDiscipline = new DisciplineNode(0);

						//mam 102309
						//						newDiscipline.InfoSetID = infoSetID;
						//						newDiscipline.ComponentID = newComponentID;
						//						disciplines[pos].CopyTo(newDiscipline, copyPhoto);
						//						//disciplineId = dataAccess.ExecuteCommandReturnAutoID(newDiscipline.GetInsertSqlForCopy());
						//						//newDiscipline = new DisciplineNode(disciplineId);
						//						newDiscipline.Save();

						importNodeData = true;
						break;
					default:
						continue;
				}

				newDiscipline.InfoSetID = infoSetID;
				newDiscipline.ComponentID = newComponentID;
				disciplines[pos].CopyTo(newDiscipline, copyPhoto, ref gridErrors);

				//mam 07072011 - added bool success
				bool success = newDiscipline.Save();

				//mam 07072011
				if (!success)
				{
					return false;
				}

				//mam - move this code past the loop so that it is executed only after all disciplines have been copied
				//if (nodeNewComponent != null)
				//{
				//	((MajorComponent)nodeNewComponent.Tag).RefreshTotals();
				//}
				//</mam>

				if (copyPhoto)
				{
					string copyPhotoFrom = "";
					string copyPhotoTo = "";

					switch (disciplines[pos].Type)
					{
						case DisciplineType.Mechanical:
						case DisciplineType.Structural:
						{
							//							if (newDiscipline.Photo != "")
							//							{
							//								copyPhotoFrom = @imagePath + "\\" + newDiscipline.Photo;
							//								copyPhotoTo = @imagePathCopyTo + "\\" + newDiscipline.Photo;
							//							}
							//							else
							//							{
							copyPhotoFrom = string.Format(
								@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @imagePath,
								sourceFacilityID, sourceProcessID, sourceComponentID, (int)disciplines[pos].Type);
							copyPhotoTo = string.Format(
								@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", @imagePath,
								newFacilityID, newProcessID, newComponentID, (int)newDiscipline.Type);
							//							}
							try
							{
								//if (System.IO.File.Exists(copyPhotoFrom))
								System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
							}
							catch
							{
							}
						}
							break;
						case DisciplineType.Land:
						{
							copyPhotoFrom = "";
							copyPhotoTo = "";

							for (int i = 1; i <= 3; i++)
							{
								//								if (i == 1)
								//								{
								//									if (((DisciplineLand)newDiscipline).Photo1 != "")
								//									{
								//										copyPhotoFrom = @imagePath + "\\" + ((DisciplineLand)newDiscipline).Photo1;
								//										copyPhotoTo = @imagePathCopyTo + "\\" + ((DisciplineLand)newDiscipline).Photo1;
								//									}
								//								}
								//								if (i == 2)
								//								{
								//									if (((DisciplineLand)newDiscipline).Photo2 != "")
								//									{
								//										copyPhotoFrom = @imagePath + "\\" + ((DisciplineLand)newDiscipline).Photo2;
								//										copyPhotoTo = @imagePathCopyTo + "\\" + ((DisciplineLand)newDiscipline).Photo2;
								//									}
								//								}
								//								if (i == 3)
								//								{
								//									if (((DisciplineLand)newDiscipline).Photo3 != "")
								//									{
								//										copyPhotoFrom = @imagePath + "\\" + ((DisciplineLand)newDiscipline).Photo3;
								//										copyPhotoTo = @imagePathCopyTo + "\\" + ((DisciplineLand)newDiscipline).Photo3;
								//									}
								//								}

								//								if (copyPhotoFrom == "")
								//								{
								copyPhotoFrom = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @imagePath,
									sourceFacilityID, sourceProcessID, sourceComponentID, (int)disciplines[pos].Type, i);
								copyPhotoTo = string.Format(
									@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-{5:D2}.jpg", @imagePath,
									newFacilityID, newProcessID, newComponentID, (int)newDiscipline.Type, i);
								//								}
								try
								{
									//if (System.IO.File.Exists(copyPhotoFrom))
									System.IO.File.Copy(copyPhotoFrom, copyPhotoTo, true);
								}
								catch
								{
								}
							}
							break;
						}
						default:
							//continue;
							break;
					}
				}

				if (importAssetList)
				{
					//mam 07072011 - added bool success
					success = ImportAssetList(sourceComponent, newComponent, infoSetID, ref gridErrors);
				}
				else if (importPipeData)
				{
					//mam 07072011 - added bool success
					success = ImportPipeData(disciplines[pos], newDiscipline, infoSetID, newComponent.Name, ref gridErrors);
				}
				else if (importNodeData)
				{
					//mam 07072011 - added bool success
					success = ImportNodeData(disciplines[pos], newDiscipline, infoSetID, newComponent.Name, ref gridErrors);
				}
			}

			//mam - moved this code from above to this location so that it is executed only after all disciplines have been copied
			if (nodeNewComponent != null)
			{
				((MajorComponent)nodeNewComponent.Tag).RefreshTotals();
			}
			//</mam>

			return true;
		}
		//</mam>

		//mam
		//mam 07072011 - added gridErros
		private bool ImportAssetList(MajorComponent sourceComponent, MajorComponent newComponent, int orgSetID
			, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//mam 07072011 - added try/catch

			try
			{
				//ComponentAsset[] sourceAssets = ComponentAsset.LoadAll(sourceConnection, sourceComponent.ID);
				ComponentAsset[] sourceAssets = CacheManager.GetAssets(orgSetID, sourceComponent.ID);
				ComponentAsset	sourceAsset = null;
				ComponentAsset	newAsset = null;

				for (int pos = 0; pos < sourceAssets.Length; pos++)
				{
					sourceAsset = sourceAssets[pos];

					newAsset = new ComponentAsset(0);
					sourceAsset.CopyTo(newAsset);
					newAsset.ComponentID = newComponent.ID;

					//mam 07072011 - added bool success
					if (!newAsset.Save())
					{
						Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error saving Assets for " + newComponent.Name + ".");
						return false;
					}
				}
			}
			catch
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error saving Assets for " + newComponent.Name + ".");
				return false;
			}

			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportPipeData(Discipline sourceDiscipline, Discipline newDiscipline, int orgSetID
			, string componentName, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//PipeData[]		sourceRecords = PipeData.LoadForDiscipline(sourceConnection, sourceDiscipline.ID);
			PipeData[]		sourceRecords = CacheManager.GetPipeDataForDiscipline(orgSetID, sourceDiscipline.ID);
			PipeData		sourceRec = null;
			PipeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new PipeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscPipeID = newDiscipline.ID;

				//mam 07072011 - added bool success
				bool success = newRec.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error creating Pipe " + newRec.IDNumber + " for " + componentName + ".");
					//return false;
				}

				//mam 07072011 - save crits
				newRec.InsertCriticalityValuesAllCopy(sourceRec.ID, newRec.ID);
			}

			//mam 07072011 - let's just go ahead and let this return true - if there are errors, we're adding them to the errors grid
			return true;
		}
		//</mam>

		//mam - copied from WAM\UI\Import\ImportFromWAMForm
		private bool		ImportNodeData(Discipline sourceDiscipline, Discipline newDiscipline, int orgSetID
			, string componentName, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//NodeData[]		sourceRecords = NodeData.LoadForDiscipline(sourceConnection, sourceDiscipline.ID);
			NodeData[]		sourceRecords = CacheManager.GetNodeDataForDiscipline(orgSetID, sourceDiscipline.ID);
			NodeData		sourceRec = null;
			NodeData		newRec = null;

			for (int pos = 0; pos < sourceRecords.Length; pos++)
			{
				sourceRec = sourceRecords[pos];

				newRec = new NodeData(0);
				sourceRec.CopyTo(newRec);
				newRec.DiscNodeID = newDiscipline.ID;

				//mam 07072011 - added bool success
				bool success = newRec.Save();

				//mam 07072011
				if (!success)
				{
					Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, "Error creating Node " + newRec.IDNumber + " for " + componentName + ".");
					//return false;
				}

				//mam 07072011 - save crits
				newRec.InsertCriticalityValuesAllCopy(sourceRec.ID, newRec.ID);
			}

			//mam 07072011 - let's just go ahead and let this return true - if there are errors, we're adding them to the errors grid
			return true;
		}
		//</mam>

		public void ShowEquation(string eqn)
		{
			equationViewer.ShowEquation(eqn);
		}

		public void PinEquation(string eqn)
		{
			equationViewer.PinEquation(eqn);
		}

		public void ClearEquationTextBox()
		{
			equationViewer.ClearEquationTextBox();
		}

		private void menuItemFilePipeTemplate_Click(object sender, System.EventArgs e)
		{
			CreateImportFile(NodeType.DisciplinePipe);
		}

		private void menuItemFileNodeTemplate_Click(object sender, System.EventArgs e)
		{
			CreateImportFile(NodeType.DisciplineNode);
		}
		//</mam>

		//mam 07072011
		private bool CreateImportFile(WAM.UI.NodeType nodeType)
		{
			System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
			//Stream streamSource = thisExe.GetManifestResourceStream("WAM.Files.PipeImportSource.txt");
			Stream streamSource;
			ArrayList arrayListCriticalities = new ArrayList();
			ArrayList arrayListFactors = new ArrayList();
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			DialogResult result;
			int counter = -1;
			int critNumber = 0;
			string fileName = string.Empty;
			string line = string.Empty;
			string critName = string.Empty;
			
			//fileName = string.Format(@"{0}\PipeImport.txt", Drive.IO.Directory.GetApplicationPath());
			arrayListCriticalities = Common.CommonTasks.LoadImportCritArray();

			//***
			if (nodeType == WAM.UI.NodeType.DisciplinePipe)
			{
				//importFile = thisExe.GetManifestResourceStream("WAM.Files.PipeImport.txt");
				fileName = string.Format(@"{0}\PipeImport.txt", Drive.IO.Directory.GetApplicationPath());
				streamSource = thisExe.GetManifestResourceStream("WAM.Files.PipeImportSource.txt");
			}
			else
			{
				//importFile = thisExe.GetManifestResourceStream("WAM.Files.NodeImport.txt");
				fileName = string.Format(@"{0}\NodeImport.txt", Drive.IO.Directory.GetApplicationPath());
				streamSource = thisExe.GetManifestResourceStream("WAM.Files.NodeImportSource.txt");
			}
	
			if (System.IO.File.Exists(fileName))
			{
				result = MessageBox.Show(this, "The file\r\n\r\n" + fileName + "\r\n\r\nalready exists.  Overwrite it?",
					"Overwrite File?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
				if (result == DialogResult.No)
				{
					//don't overwrite the file
					MessageBox.Show("The import file has not been created.",
						"Create Import File", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return false;
				}
			}
			//***

			//add factors to array list
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				int critId = ((CriticalityForImport)arrayListCriticalities[i]).CriticalityId;
				Criticality crit = Common.CommonTasks.Criticalities.ItemById(critId);
				arrayListFactors.Add(crit.CriticalityFactors);
			}

			try
			{
				int factorNumber = -1;
				using (StreamReader reader = new StreamReader(streamSource))
				{
					using (StreamWriter writer = new StreamWriter(fileName, false))
					{
						while ((line = reader.ReadLine()) != null)
						{
							counter++;

							if (counter == 0)
							{
								//header line
								for (int i = 0; i < arrayListCriticalities.Count; i++)
								{
									critNumber = i + 1;
									critName = "Criticality - " + ((CriticalityForImport)arrayListCriticalities[i]).CriticalityName;
									line = line.Replace("Crit" + critNumber.ToString(), critName);
								}
								for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
								{
									line = line.Replace("Crit" + i.ToString() + "\t", "");
								}
								writer.WriteLine(line);
							}
							else
							{
								factorNumber++;
								for (int i = 0; i < arrayListCriticalities.Count; i++)
								{
									//mam 03202012 - only one crit has four factors; use 3 here
									//factorNumber = factorNumber % 4;
									factorNumber = factorNumber % 3;

									critNumber = i + 1;
									string factorName = ((CriticalityFactorCollection)arrayListFactors[i]).Item(factorNumber).FactorName;
									if (factorName.ToUpper().IndexOf("INJUR") > -1 || (factorName.ToUpper().IndexOf("LOSS") > -1 && factorName.ToUpper().IndexOf("LIFE") > -1))
									{
										//factorName = ((CriticalityFactorCollection)arrayListFactors[i]).Item(0).FactorName;
										factorName = ((CriticalityFactorCollection)arrayListFactors[i]).GetDefaultFactorName();
									}
									line = line.Replace("Crit" + critNumber.ToString(), factorName);
								}
								for (int i = arrayListCriticalities.Count + 1; i <= 6; i++)
								{
									line = line.Replace("Crit" + i.ToString() + "\t", "");
								}
								writer.WriteLine(line);
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error has occurred.  The import file has not been created.\n\n" + ex.Message.ToString(),
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
			finally
			{
				//if (importFile != null)
				//	importFile.Close();
			}

			builder.Append("The import file was created successfully as\r\n\r\n");
			builder.Append(fileName);
			builder.Append("\r\n\r\nWould you like to open the file?");

			result = MessageBox.Show(this, builder.ToString(), 
				"Open File?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
			if (result == DialogResult.Yes)
			{
				//try to open the file in the default application
				try
				{
					System.Diagnostics.Process.Start(fileName);
				}
				catch
				{
					MessageBox.Show("An error has occurred.  The file cannot be opened.",
						"Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return false;
				}
			}

			return true;
		}

		//mam
		private bool CreateImportFilexxx(WAM.UI.NodeType nodeType)
		{
			System.IO.Stream importFile = null;
			System.IO.StreamReader streamReader = null;
			System.IO.StreamWriter streamWriter = null;
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			DialogResult result;
			string fileName = "";
			string importFileText = "";
	
			try
			{
				if (nodeType == WAM.UI.NodeType.DisciplinePipe)
				{
					importFile = thisExe.GetManifestResourceStream("WAM.Files.PipeImport.txt");
					fileName = string.Format(@"{0}\PipeImport.txt", Drive.IO.Directory.GetApplicationPath());
				}
				else
				{
					importFile = thisExe.GetManifestResourceStream("WAM.Files.NodeImport.txt");
					fileName = string.Format(@"{0}\NodeImport.txt", Drive.IO.Directory.GetApplicationPath());
				}
	
				if (System.IO.File.Exists(fileName))
				{
					result = MessageBox.Show(this, "The file\r\n\r\n" + fileName + "\r\n\r\nalready exists.  Overwrite it?",
						"Overwrite File?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
					if (result == DialogResult.No)
					{
						//don't overwrite the file
						MessageBox.Show("The import file has not been created.",
							"Create Import File", MessageBoxButtons.OK, MessageBoxIcon.Information);
						return false;
					}
				}

				if (importFile != null)
				{
					streamReader = new System.IO.StreamReader(importFile);
					importFileText = streamReader.ReadToEnd();
					streamWriter = new System.IO.StreamWriter(fileName, false);
					streamWriter.Write(importFileText);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error has occurred.  The import file has not been created.\n\n" + ex.Message.ToString(),
					"Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
			finally
			{
				if (streamReader != null)
					streamReader.Close();

				if (streamWriter != null)
					streamWriter.Close();

				if (importFile != null)
					importFile.Close();
			}

			builder.Append("The import file was created successfully as\r\n\r\n");
			builder.Append(fileName);
			builder.Append("\r\n\r\nWould you like to open the file?");

			result = MessageBox.Show(this, builder.ToString(), 
				"Open File?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
			if (result == DialogResult.Yes)
			{
				//try to open the file in the default application
				try
				{
					System.Diagnostics.Process.Start(fileName);
				}
				catch
				{
					MessageBox.Show("An error has occurred.  The file cannot be opened.",
						"Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return false;
				}
			}

			return true;
		}

		//mam
		private void treeViewFacility_Resize(object sender, System.EventArgs e)
		{
			if (panelToolboxInner.Width < 160)
			{
				pictureBoxToolbarPreferences.Location = new System.Drawing.Point(80, 6);
				pictureBoxToolbarEquationBox.Location = new System.Drawing.Point(104, 6);
				pictureBoxToolbarHelp.Location = new System.Drawing.Point(128, 6);
			}
			else
			{
				pictureBoxToolbarPreferences.Location = new System.Drawing.Point(
					panelToolboxInner.Width - 75, 6);
				pictureBoxToolbarEquationBox.Location = new System.Drawing.Point(
					panelToolboxInner.Width - 51, 6);
				pictureBoxToolbarHelp.Location = new System.Drawing.Point(
					panelToolboxInner.Width - 27, 6);
			}
		}

		private void menuItemFile_ImportTextFile_Click(object sender, System.EventArgs e)
		{
			addNodeDelegate = new AddNodeDelegate(AddNodeUsingDelegate);
			addNodeDelegateSpecifyParent = new AddNodeDelegateSpecifyParent(AddNodeUsingDelegateSpecifyParentNode);

			WAM.UI.Import.ImportFromTextFile importFromTextFile = new WAM.UI.Import.ImportFromTextFile(this, InfoSet.CurrentID);
			importFromTextFile.ShowDialog(this);

			addNodeDelegate = null;
			addNodeDelegateSpecifyParent = null;

			//mam 03202012 - set focus on tree so it's not on name text box in form
			treeViewFacility.Focus();
		}

		private void menuItemFile_ImportTextFileTemplate_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("This functionality is not yet available", "Functionality Not Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void menuItemFile_Click(object sender, System.EventArgs e)
		{
		
		}

		//mam 102309
		private void menuItemEdit_ImageFolder_Click(object sender, System.EventArgs e)
		{
			//mam 03202012 - if the user doesn't have write permission, display a message
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				MessageBox.Show(this, "You do not have the required permission to edit data.", "Permission Required", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			SetImageBasePath setImageBasePath = new SetImageBasePath();
			//setImageBasePath.ShowDialog(this);
			int posTop = this.Top + this.ClientSize.Height / 2 - setImageBasePath.ClientSize.Height / 2;
			int posLeft = this.Left + this.ClientSize.Width / 2 - setImageBasePath.ClientSize.Width / 2;
			setImageBasePath.StartPosition = FormStartPosition.Manual;
			setImageBasePath.Location = new System.Drawing.Point(posLeft, posTop);
			setImageBasePath.FormOwner = this;
			setImageBasePath.Show();
			setImageBasePath.TopMost = true;
		}
		//</mam>

		//mam 102309
		public void AfterChangeImageFolder()
		{
			NodeType		type = GetSelectedNodeType();
			TreeNode		node = treeViewFacility.SelectedNode;

			//if (type == NodeType.InfoSet)
		{
			RefreshCurrentView();
		}
		}

		#endregion /***** Methods *****/

		#region /***** Test Code *****/

		private void buttonTest_Click(object sender, System.EventArgs e)
		{
			NodeData[] nodeData1 = CacheManager.GetNodeDataForDiscipline(109, 1274);
			NodeData[] nodeData2 = CacheManager.GetNodeDataForDiscipline(109, 1275);
			NodeData[] nodeData3 = CacheManager.GetNodeDataForDiscipline(109, 1276);

			PipeData[] pipeData1 = CacheManager.GetPipeDataForDiscipline(109, 1272);
			PipeData[] pipeData2 = CacheManager.GetPipeDataForDiscipline(109, 1273);
			PipeData[] pipeData3 = CacheManager.GetPipeDataForDiscipline(109, 1274);

			MessageBox.Show(nodeData1.Length.ToString());
			MessageBox.Show(nodeData2.Length.ToString());
			MessageBox.Show(nodeData3.Length.ToString());
			MessageBox.Show(pipeData1.Length.ToString());
			MessageBox.Show(pipeData2.Length.ToString());
			MessageBox.Show(pipeData3.Length.ToString());

			//SetRepairCrits();
			//CheckRepairCrits();
		}

		private void CheckRepairCrits()
		{
			//*****************************

			//this code was used to set the Cost of Repair criticality values for all major components in the database
			//the crit value was determined by the total repair cost for each major component

			//all Cost of Repair crit values are correct

			DataAccess dataAccessCrit = new DataAccess();
			DataTable dataTable = new DataTable();

			Facility[] facilityCache = CacheManager.GetFacilities(109);
			foreach (Facility fac in facilityCache)
			{
				TreatmentProcess[] processCache = CacheManager.GetProcesses(fac.InfoSetID, fac.ID);
				foreach (TreatmentProcess proc in processCache)
				{
					MajorComponent[] componentCache = CacheManager.GetComponents(proc.InfoSetID, proc.ID);
					foreach (MajorComponent comp in componentCache)
					{
						Discipline[] disciplineCache = CacheManager.GetDisciplines(comp.InfoSetID, comp.ID);
						decimal repairCostTotal = 0;
						foreach (Discipline disc in disciplineCache)
						{
							repairCostTotal += disc.RepairCost;
						}

						//set the cost of repair crit value based on repair cost
						if (repairCostTotal < 5000)
						{
							//the value in the database should be 2
							dataTable = dataAccessCrit.GetDisconnectedDataTable("SELECT * FROM MajorComponentToCriticality WHERE component_id = " + comp.ID + " AND CriticalityId = 2 AND CriticalityScoreId != 2");
							if (dataTable == null)
							{
								MessageBox.Show("null table for comp id = " + comp.ID.ToString());
							}
							else if (dataTable.Rows.Count > 0)
							{
								MessageBox.Show("rows exist for comp id = " + comp.ID.ToString());
							}
						}
						else if (repairCostTotal <= 20000)
						{
							//the value in the database should be 4
							dataTable = dataAccessCrit.GetDisconnectedDataTable("SELECT * FROM MajorComponentToCriticality WHERE component_id = " + comp.ID + " AND CriticalityId = 2 AND CriticalityScoreId != 4");
							if (dataTable == null)
							{
								MessageBox.Show("null table for comp id = " + comp.ID.ToString());
							}
							else if (dataTable.Rows.Count > 0)
							{
								MessageBox.Show("rows exist for comp id = " + comp.ID.ToString());
							}
						}
						else if (repairCostTotal > 20000)
						{
							//the value in the database should be 6
							dataTable = dataAccessCrit.GetDisconnectedDataTable("SELECT * FROM MajorComponentToCriticality WHERE component_id = " + comp.ID + " AND CriticalityId = 2 AND CriticalityScoreId != 6");
							if (dataTable == null)
							{
								MessageBox.Show("null table for comp id = " + comp.ID.ToString());
							}
							else if (dataTable.Rows.Count > 0)
							{
								MessageBox.Show("rows exist for comp id = " + comp.ID.ToString());
							}
						}

						/*
						CriticalityToScoreId	CriticalityId	CriticalityScoreId	CriticalityFactor
						11						2				2					Less than $5000
						12						2				4					Between $5000 and $20000
						13						2				6					More than $20000
						*/
					}
				}
			}

			MessageBox.Show("finished");

			//*****************************

			//check the values
		}

		private void SetRepairCrits()
		{
			//*****************************

			//this code was used to set the Cost of Repair criticality values for all major components in the database
			//the crit value was determined by the total repair cost for each major component
			DataAccess dataAccessCrit = new DataAccess();

			Facility[] facilityCache = CacheManager.GetFacilities(109);
			foreach (Facility fac in facilityCache)
			{
				TreatmentProcess[] processCache = CacheManager.GetProcesses(fac.InfoSetID, fac.ID);
				foreach (TreatmentProcess proc in processCache)
				{
					MajorComponent[] componentCache = CacheManager.GetComponents(proc.InfoSetID, proc.ID);
					foreach (MajorComponent comp in componentCache)
					{
						Discipline[] disciplineCache = CacheManager.GetDisciplines(comp.InfoSetID, comp.ID);
						decimal repairCostTotal = 0;
						foreach (Discipline disc in disciplineCache)
						{
							repairCostTotal += disc.RepairCost;
						}

						//just for fun, let's see if there are any repair costs that are exactly 5000 or 20000
						//(there aren't any)
						//if (repairCostTotal == 5000)
						//{
						//	MessageBox.Show("5000");
						//}
						//if (repairCostTotal == 20000)
						//{
						//	MessageBox.Show("20000");
						//}
						//continue;

						//set the cost of repair crit value based on repair cost
						if (repairCostTotal > 20000)
						{
							dataAccessCrit.ExecuteCommand("UPDATE MajorComponentToCriticality SET CriticalityScoreId = 6 WHERE component_id = " + comp.ID + " AND CriticalityId = 2");
						}
						else if (repairCostTotal >= 5000)
						{
							dataAccessCrit.ExecuteCommand("UPDATE MajorComponentToCriticality SET CriticalityScoreId = 4 WHERE component_id = " + comp.ID + " AND CriticalityId = 2");
						}
						else	//less than 5000
						{
							dataAccessCrit.ExecuteCommand("UPDATE MajorComponentToCriticality SET CriticalityScoreId = 2 WHERE component_id = " + comp.ID + " AND CriticalityId = 2");
						}

						/*
						CriticalityToScoreId	CriticalityId	CriticalityScoreId	CriticalityFactor
						11						2				2					Less than $5000
						12						2				4					Between $5000 and $20000
						13						2				6					More than $20000
						*/
					}
				}
			}

			MessageBox.Show("finished");

			//*****************************

			//check the values
		}

		#endregion /***** Test Code *****/
	}
}

