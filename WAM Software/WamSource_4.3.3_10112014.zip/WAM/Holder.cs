using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM
{
	/// <summary>
	/// Summary description for Holder.
	/// </summary>
	public class Holder : System.Windows.Forms.Form
	{
		private WAM.UI.MainViews.DisciplineLandControl disciplineLandControl1;
		private WAM.UI.MainViews.DisciplineNodesControl disciplineNodesControl1;
		private WAM.UI.MainViews.DisciplineMechControl disciplineMechControl1;
		private System.Windows.Forms.Label labelDataType;
		private WAM.UI.MainViews.DisciplinePipeControl disciplinePipeControl1;
		private WAM.UI.MainViews.FacilityControl facilityControl1;
		private WAM.UI.MainViews.InfoSetControl infoSetControl1;
		private WAM.UI.MainViews.DisciplineStructControl disciplineStructControl1;
		private WAM.UI.AssetListControl assetListControl1;
		private WAM.UI.MainViews.MajorComponentControl majorComponentControl1;
		private WAM.UI.MainViews.TreatmentProcessControl treatmentProcessControl1;
		private System.Windows.Forms.TextBox textBoxCurrentDatabase;
		private System.Windows.Forms.Label labelCurrentDatabase;
		private System.Windows.Forms.TreeView treeViewFacility;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.PictureBox pictureBoxToolbarCopy;
		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.PictureBox pictureBoxToolbarHelp;
		private System.Windows.Forms.PictureBox pictureBoxToolbarEquationBox;
		private System.Windows.Forms.PictureBox pictureBoxToolbarDelete;
		private System.Windows.Forms.PictureBox pictureBoxToolbarAdd;
		private System.Windows.Forms.Panel panel3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Holder()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Holder));
			this.disciplineLandControl1 = new WAM.UI.MainViews.DisciplineLandControl();
			this.disciplineNodesControl1 = new WAM.UI.MainViews.DisciplineNodesControl();
			this.disciplineMechControl1 = new WAM.UI.MainViews.DisciplineMechControl();
			this.labelDataType = new System.Windows.Forms.Label();
			this.disciplinePipeControl1 = new WAM.UI.MainViews.DisciplinePipeControl();
			this.facilityControl1 = new WAM.UI.MainViews.FacilityControl();
			this.infoSetControl1 = new WAM.UI.MainViews.InfoSetControl();
			this.disciplineStructControl1 = new WAM.UI.MainViews.DisciplineStructControl();
			this.assetListControl1 = new WAM.UI.AssetListControl();
			this.majorComponentControl1 = new WAM.UI.MainViews.MajorComponentControl();
			this.treatmentProcessControl1 = new WAM.UI.MainViews.TreatmentProcessControl();
			this.textBoxCurrentDatabase = new System.Windows.Forms.TextBox();
			this.labelCurrentDatabase = new System.Windows.Forms.Label();
			this.treeViewFacility = new System.Windows.Forms.TreeView();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.pictureBoxToolbarCopy = new System.Windows.Forms.PictureBox();
			this.buttonTest = new System.Windows.Forms.Button();
			this.pictureBoxToolbarHelp = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarEquationBox = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarDelete = new System.Windows.Forms.PictureBox();
			this.pictureBoxToolbarAdd = new System.Windows.Forms.PictureBox();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4.SuspendLayout();
			this.panel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// disciplineLandControl1
			// 
			this.disciplineLandControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineLandControl1.AutoScroll = true;
			this.disciplineLandControl1.AutoScrollMinSize = new System.Drawing.Size(700, 480);
			this.disciplineLandControl1.Location = new System.Drawing.Point(304, 144);
			this.disciplineLandControl1.Name = "disciplineLandControl1";
			this.disciplineLandControl1.Size = new System.Drawing.Size(588, 521);
			this.disciplineLandControl1.TabControlIndex = 0;
			this.disciplineLandControl1.TabIndex = 102;
			this.disciplineLandControl1.Visible = false;
			// 
			// disciplineNodesControl1
			// 
			this.disciplineNodesControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineNodesControl1.AutoScroll = true;
			this.disciplineNodesControl1.AutoScrollMinSize = new System.Drawing.Size(700, 480);
			this.disciplineNodesControl1.Location = new System.Drawing.Point(304, 144);
			this.disciplineNodesControl1.Name = "disciplineNodesControl1";
			this.disciplineNodesControl1.Size = new System.Drawing.Size(588, 521);
			this.disciplineNodesControl1.TabControlIndex = 0;
			this.disciplineNodesControl1.TabIndex = 106;
			this.disciplineNodesControl1.Visible = false;
			// 
			// disciplineMechControl1
			// 
			this.disciplineMechControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineMechControl1.AutoScroll = true;
			this.disciplineMechControl1.AutoScrollMinSize = new System.Drawing.Size(700, 500);
			this.disciplineMechControl1.Location = new System.Drawing.Point(304, 144);
			this.disciplineMechControl1.Name = "disciplineMechControl1";
			this.disciplineMechControl1.Size = new System.Drawing.Size(588, 521);
			this.disciplineMechControl1.TabControlIndex = 0;
			this.disciplineMechControl1.TabIndex = 100;
			this.disciplineMechControl1.Visible = false;
			// 
			// labelDataType
			// 
			this.labelDataType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelDataType.BackColor = System.Drawing.Color.Transparent;
			this.labelDataType.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelDataType.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(145)), ((System.Byte)(185)));
			this.labelDataType.Location = new System.Drawing.Point(304, 120);
			this.labelDataType.Name = "labelDataType";
			this.labelDataType.Size = new System.Drawing.Size(588, 23);
			this.labelDataType.TabIndex = 108;
			// 
			// disciplinePipeControl1
			// 
			this.disciplinePipeControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplinePipeControl1.AutoScroll = true;
			this.disciplinePipeControl1.AutoScrollMinSize = new System.Drawing.Size(700, 480);
			this.disciplinePipeControl1.Location = new System.Drawing.Point(304, 144);
			this.disciplinePipeControl1.Name = "disciplinePipeControl1";
			this.disciplinePipeControl1.Size = new System.Drawing.Size(588, 521);
			this.disciplinePipeControl1.TabControlIndex = 0;
			this.disciplinePipeControl1.TabIndex = 107;
			this.disciplinePipeControl1.Visible = false;
			// 
			// facilityControl1
			// 
			this.facilityControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.facilityControl1.AutoScroll = true;
			this.facilityControl1.AutoScrollMinSize = new System.Drawing.Size(616, 450);
			this.facilityControl1.BackColor = System.Drawing.SystemColors.Control;
			this.facilityControl1.Location = new System.Drawing.Point(304, 144);
			this.facilityControl1.Name = "facilityControl1";
			this.facilityControl1.Size = new System.Drawing.Size(588, 521);
			this.facilityControl1.TabControlIndex = 0;
			this.facilityControl1.TabIndex = 98;
			this.facilityControl1.Visible = false;
			// 
			// infoSetControl1
			// 
			this.infoSetControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.infoSetControl1.BackColor = System.Drawing.SystemColors.Control;
			this.infoSetControl1.Location = new System.Drawing.Point(304, 144);
			this.infoSetControl1.Name = "infoSetControl1";
			this.infoSetControl1.Size = new System.Drawing.Size(588, 521);
			this.infoSetControl1.TabIndex = 99;
			this.infoSetControl1.Visible = false;
			// 
			// disciplineStructControl1
			// 
			this.disciplineStructControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.disciplineStructControl1.AutoScroll = true;
			this.disciplineStructControl1.AutoScrollMinSize = new System.Drawing.Size(700, 480);
			this.disciplineStructControl1.Location = new System.Drawing.Point(304, 144);
			this.disciplineStructControl1.Name = "disciplineStructControl1";
			this.disciplineStructControl1.Size = new System.Drawing.Size(588, 521);
			this.disciplineStructControl1.TabControlIndex = 0;
			this.disciplineStructControl1.TabIndex = 101;
			this.disciplineStructControl1.Visible = false;
			// 
			// assetListControl1
			// 
			this.assetListControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.assetListControl1.AutoScroll = true;
			this.assetListControl1.AutoScrollMinSize = new System.Drawing.Size(540, 396);
			this.assetListControl1.Location = new System.Drawing.Point(304, 144);
			this.assetListControl1.Name = "assetListControl1";
			this.assetListControl1.Size = new System.Drawing.Size(588, 518);
			this.assetListControl1.TabIndex = 105;
			this.assetListControl1.Visible = false;
			// 
			// majorComponentControl1
			// 
			this.majorComponentControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.majorComponentControl1.AutoScroll = true;
			this.majorComponentControl1.AutoScrollMinSize = new System.Drawing.Size(698, 472);
			this.majorComponentControl1.Location = new System.Drawing.Point(304, 144);
			this.majorComponentControl1.Name = "majorComponentControl1";
			this.majorComponentControl1.Size = new System.Drawing.Size(588, 521);
			this.majorComponentControl1.TabControlIndex = 0;
			this.majorComponentControl1.TabIndex = 103;
			this.majorComponentControl1.Visible = false;
			// 
			// treatmentProcessControl1
			// 
			this.treatmentProcessControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treatmentProcessControl1.AutoScroll = true;
			this.treatmentProcessControl1.AutoScrollMinSize = new System.Drawing.Size(616, 452);
			this.treatmentProcessControl1.Location = new System.Drawing.Point(304, 144);
			this.treatmentProcessControl1.Name = "treatmentProcessControl1";
			this.treatmentProcessControl1.Size = new System.Drawing.Size(588, 521);
			this.treatmentProcessControl1.TabControlIndex = 0;
			this.treatmentProcessControl1.TabIndex = 104;
			this.treatmentProcessControl1.Visible = false;
			// 
			// textBoxCurrentDatabase
			// 
			this.textBoxCurrentDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.textBoxCurrentDatabase.BackColor = System.Drawing.SystemColors.Control;
			this.textBoxCurrentDatabase.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.textBoxCurrentDatabase.Location = new System.Drawing.Point(40, 640);
			this.textBoxCurrentDatabase.Name = "textBoxCurrentDatabase";
			this.textBoxCurrentDatabase.ReadOnly = true;
			this.textBoxCurrentDatabase.Size = new System.Drawing.Size(208, 20);
			this.textBoxCurrentDatabase.TabIndex = 111;
			this.textBoxCurrentDatabase.TabStop = false;
			this.textBoxCurrentDatabase.Text = "";
			// 
			// labelCurrentDatabase
			// 
			this.labelCurrentDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.labelCurrentDatabase.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(224)), ((System.Byte)(192)));
			this.labelCurrentDatabase.Location = new System.Drawing.Point(48, 640);
			this.labelCurrentDatabase.Name = "labelCurrentDatabase";
			this.labelCurrentDatabase.Size = new System.Drawing.Size(8, 18);
			this.labelCurrentDatabase.TabIndex = 110;
			this.labelCurrentDatabase.Visible = false;
			// 
			// treeViewFacility
			// 
			this.treeViewFacility.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.treeViewFacility.HideSelection = false;
			this.treeViewFacility.ImageIndex = -1;
			this.treeViewFacility.Location = new System.Drawing.Point(40, 144);
			this.treeViewFacility.Name = "treeViewFacility";
			this.treeViewFacility.SelectedImageIndex = -1;
			this.treeViewFacility.Size = new System.Drawing.Size(208, 491);
			this.treeViewFacility.TabIndex = 109;
			// 
			// panel4
			// 
			this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel4.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panel4.Controls.Add(this.panel5);
			this.panel4.Location = new System.Drawing.Point(64, 56);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(212, 34);
			this.panel4.TabIndex = 135;
			// 
			// panel5
			// 
			this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel5.BackColor = System.Drawing.SystemColors.Control;
			this.panel5.Controls.Add(this.pictureBoxToolbarCopy);
			this.panel5.Controls.Add(this.buttonTest);
			this.panel5.Controls.Add(this.pictureBoxToolbarHelp);
			this.panel5.Controls.Add(this.pictureBoxToolbarEquationBox);
			this.panel5.Controls.Add(this.pictureBoxToolbarDelete);
			this.panel5.Controls.Add(this.pictureBoxToolbarAdd);
			this.panel5.Location = new System.Drawing.Point(1, 1);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(210, 32);
			this.panel5.TabIndex = 0;
			// 
			// pictureBoxToolbarCopy
			// 
			this.pictureBoxToolbarCopy.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarCopy.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarCopy.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarCopy.Image")));
			this.pictureBoxToolbarCopy.Location = new System.Drawing.Point(31, 6);
			this.pictureBoxToolbarCopy.Name = "pictureBoxToolbarCopy";
			this.pictureBoxToolbarCopy.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarCopy.TabIndex = 140;
			this.pictureBoxToolbarCopy.TabStop = false;
			// 
			// buttonTest
			// 
			this.buttonTest.Location = new System.Drawing.Point(111, 6);
			this.buttonTest.Name = "buttonTest";
			this.buttonTest.Size = new System.Drawing.Size(20, 20);
			this.buttonTest.TabIndex = 139;
			this.buttonTest.Visible = false;
			// 
			// pictureBoxToolbarHelp
			// 
			this.pictureBoxToolbarHelp.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarHelp.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarHelp.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarHelp.Image")));
			this.pictureBoxToolbarHelp.Location = new System.Drawing.Point(183, 6);
			this.pictureBoxToolbarHelp.Name = "pictureBoxToolbarHelp";
			this.pictureBoxToolbarHelp.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarHelp.TabIndex = 138;
			this.pictureBoxToolbarHelp.TabStop = false;
			// 
			// pictureBoxToolbarEquationBox
			// 
			this.pictureBoxToolbarEquationBox.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarEquationBox.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarEquationBox.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarEquationBox.Image")));
			this.pictureBoxToolbarEquationBox.Location = new System.Drawing.Point(159, 6);
			this.pictureBoxToolbarEquationBox.Name = "pictureBoxToolbarEquationBox";
			this.pictureBoxToolbarEquationBox.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarEquationBox.TabIndex = 137;
			this.pictureBoxToolbarEquationBox.TabStop = false;
			// 
			// pictureBoxToolbarDelete
			// 
			this.pictureBoxToolbarDelete.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarDelete.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarDelete.Image")));
			this.pictureBoxToolbarDelete.Location = new System.Drawing.Point(55, 6);
			this.pictureBoxToolbarDelete.Name = "pictureBoxToolbarDelete";
			this.pictureBoxToolbarDelete.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarDelete.TabIndex = 136;
			this.pictureBoxToolbarDelete.TabStop = false;
			// 
			// pictureBoxToolbarAdd
			// 
			this.pictureBoxToolbarAdd.BackColor = System.Drawing.SystemColors.Control;
			this.pictureBoxToolbarAdd.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBoxToolbarAdd.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxToolbarAdd.Image")));
			this.pictureBoxToolbarAdd.Location = new System.Drawing.Point(7, 6);
			this.pictureBoxToolbarAdd.Name = "pictureBoxToolbarAdd";
			this.pictureBoxToolbarAdd.Size = new System.Drawing.Size(20, 20);
			this.pictureBoxToolbarAdd.TabIndex = 135;
			this.pictureBoxToolbarAdd.TabStop = false;
			// 
			// panel3
			// 
			this.panel3.Location = new System.Drawing.Point(496, 24);
			this.panel3.Name = "panel3";
			this.panel3.TabIndex = 136;
			// 
			// Holder
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(864, 750);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.textBoxCurrentDatabase);
			this.Controls.Add(this.labelCurrentDatabase);
			this.Controls.Add(this.treeViewFacility);
			this.Controls.Add(this.disciplineLandControl1);
			this.Controls.Add(this.disciplineNodesControl1);
			this.Controls.Add(this.disciplineMechControl1);
			this.Controls.Add(this.labelDataType);
			this.Controls.Add(this.disciplinePipeControl1);
			this.Controls.Add(this.facilityControl1);
			this.Controls.Add(this.infoSetControl1);
			this.Controls.Add(this.disciplineStructControl1);
			this.Controls.Add(this.assetListControl1);
			this.Controls.Add(this.majorComponentControl1);
			this.Controls.Add(this.treatmentProcessControl1);
			this.Name = "Holder";
			this.Text = "Holder";
			this.panel4.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
