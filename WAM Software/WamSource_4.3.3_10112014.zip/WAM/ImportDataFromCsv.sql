USE WamTest
GO

DELETE FROM WamTest.dbo.InfoSets
DELETE FROM WamTest.dbo.Facilities
DELETE FROM WamTest.dbo.TreatmentProcesses
DELETE FROM WamTest.dbo.DisciplineLand
DELETE FROM WamTest.dbo.DisciplineMech
DELETE FROM WamTest.dbo.DisciplineStruct
DELETE FROM WamTest.dbo.MajorComponents
DELETE FROM WamTest.dbo.MajorComponentToCriticality
DELETE FROM WamTest.dbo.ErrorLog
DELETE FROM WamTest.dbo.CipPlanning
DELETE FROM WamTest.dbo.CriticalityToScore
DELETE FROM WamTest.dbo.CriticalityScore
DELETE FROM WamTest.dbo.Criticality
DELETE FROM WamTest.dbo.CustomENR
DELETE FROM WamTest.dbo.CustomENRList

BULK INSERT WamTest.dbo.CipPlanning FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\CipPlanning.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.Criticality FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\Criticality.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.CriticalityScore FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\CriticalityScore.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.CriticalityToScore FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\CriticalityToScore.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.CustomENR FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\CustomENR.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.CustomENRList FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\CustomENRList.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.InfoSets FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\InfoSets.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.Facilities FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\Facilities.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.TreatmentProcesses FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\TreatmentProcesses.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.MajorComponents FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\MajorComponents.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.DisciplineLand FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\DisciplineLand.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.DisciplineMech FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\DisciplineMech.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.DisciplineStruct FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\DisciplineStruct.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.ErrorLog FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\ErrorLog.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

BULK INSERT WamTest.dbo.MajorComponentToCriticality FROM 'C:\marti\programming\work\WAM\Documents\Sample files\ImportCsvIntoSqlServer\MajorComponentToCriticality.csv'
WITH (KEEPIDENTITY, KEEPNULLS, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n');
GO

SELECT * FROM WamTest.dbo.CipPlanning
SELECT * FROM WamTest.dbo.Criticality
SELECT * FROM WamTest.dbo.CriticalityScore
SELECT * FROM WamTest.dbo.CriticalityToScore
SELECT * FROM WamTest.dbo.CustomENR
SELECT * FROM WamTest.dbo.CustomENRList
SELECT * FROM WamTest.dbo.InfoSets
SELECT * FROM WamTest.dbo.Facilities
SELECT * FROM WamTest.dbo.TreatmentProcesses
SELECT * FROM WamTest.dbo.MajorComponents
SELECT * FROM WamTest.dbo.MajorComponentToCriticality
SELECT * FROM WamTest.dbo.DisciplineLand
SELECT * FROM WamTest.dbo.DisciplineMech
SELECT * FROM WamTest.dbo.DisciplineStruct
SELECT * FROM WamTest.dbo.ErrorLog