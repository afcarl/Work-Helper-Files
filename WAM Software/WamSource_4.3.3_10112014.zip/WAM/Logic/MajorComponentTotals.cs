using System;
using WAM.Data;

namespace WAM.Logic
{
	/// <summary>
	/// Summary description for CalcComponent.
	/// </summary>
	public class MajorComponentTotals
	{
		private int			m_infoSetID = 0;
		private int			m_processID = 0;

		public MajorComponentTotals(TreatmentProcess process)
		{
			m_processID = process.ID;
			m_infoSetID = process.InfoSetID;

			if (m_processID != 0)
				CacheManager.GetComponents(m_infoSetID, m_processID);
		}

		public MajorComponent[] GetMajorComponents()
		{
			return CacheManager.GetComponents(m_infoSetID, m_processID);
		}

		public int			ProcessID
		{
			get { return m_processID; }
			set { m_processID = value; }
		}

		public decimal		GetTotalOrgCost()
		{
			decimal			sumOrgCost = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				sumOrgCost += components[pos].GetComponentCost();
			}

			return sumOrgCost;
		}

		public decimal		GetTotalCurrentValue()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);
			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;
				total += components[pos].GetCurrentValue();
			}

			return total;
		}

		public decimal		GetTotalAcquisitionCost()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetAcquisitionCost();
			}

			return total;
		}

		//mam 091607 - new method
		public decimal		GetTotalAcquisitionCostRoundIndividualValues()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetAcquisitionCostRoundIndividualValues();
			}

			return total;
		}

		//mam 050806
		public decimal		GetTotalAcquisitionCostEscalated()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetAcquisitionCostEscalated();
			}

			return total;
		}

		public decimal		GetTotalReplacementValue()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetReplacementValue();
			}

			return total;
		}

		//mam 050806
		public int GetAverageReplacementValueYear()
		{
			int avgYear = 0;
			MajorComponent[] components = CacheManager.GetComponents(m_infoSetID, m_processID);

			//mam 112806
			int discCount = 0;

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				//mam 112806 - add check for null, and ReplacementValueYear = zero
				if (components[pos] == null || components[pos].GetReplacementValueYear() == 0)
					continue;

				discCount++;
				avgYear += components[pos].GetReplacementValueYear();
			}

			//mam 112806
			//return (int)(avgYear / components.Length);
			//return components.Length == 0 ? 0 : (int)(avgYear / components.Length);

			//mam 112806 - use discCount rather than components.Length
			return discCount == 0 ? 0 : (int)Math.Round((decimal)avgYear / discCount, 0);
		}

		//mam 050806
		public decimal		GetTotalRehabCost()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetRehabCost();
			}

			return total;
		}

		public decimal		GetTotalBookValue()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetBookValue();
			}

			return total;
		}

		public decimal		GetTotalSalvageValue()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetSalvageValue();
			}

			return total;
		}

		public decimal		GetTotalAnnualDepreciation()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetAnnualDepreciation();
			}

			return total;
		}

		public decimal		GetTotalCumulativeDepreciation()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;
				
				total += components[pos].GetCumulativeDepreciation();
			}

			return total;
		}

		public decimal		GetTotalEvaluatedValue()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetEvaluatedValue();
			}

			return total;
		}

		public decimal		GetTotalRepairCost()
		{
			decimal			sumRepairs = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				sumRepairs += components[pos].GetRepairCost();
			}

			return sumRepairs;
		}

		public decimal		GetTotalAnnualMaintenanceCost()
		{
			decimal			total = 0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				total += components[pos].GetAnnualMaintenanceCost();
			}

			return total;
		}

		public double		GetRankPercent()
		{
//			decimal			totalCurrentValue = GetTotalCurrentValue();
//			double			rankPercent = 0.0;
//
//			if (totalCurrentValue != 0)
//			{
//				rankPercent = 0.4113;
//				rankPercent *= Math.Pow((double)((double)
//					((GetTotalRepairCost() / totalCurrentValue) * 100m)), 0.583);
//				if (rankPercent > 5.0)
//					rankPercent = 5.0;
//			}
//
//			if (rankPercent < 1.0)
//				rankPercent = 1.0;
//
//			return rankPercent;

			//mam - new calculation for GetRankPercent
			DisciplineTotals totals = null;
			decimal			totalCurrentValue = GetTotalCurrentValue();
			decimal			rankPercent = 0m;
			decimal			sumRankValues = 0m;
			
			//get the average condition for each Major Component

			// Retrieve the component data for the current process
			MajorComponent[] components = CacheManager.GetComponents(m_infoSetID, m_processID);
			for (int pos = 0; pos < components.Length; pos++)
			{
				// Retrieve the sum of the Condition Percentage x Current Value

				if (components[pos] == null || components[pos].Retired)
					continue;

				totals = components[pos].GetDisciplineTotals();

				// get the average condition for the disciplines in the current component * the CV for the current component

				//mam - use interpolated method
				//sumRankValues += (decimal)totals.GetRankPercent() * components[pos].GetCurrentValue();
				sumRankValues += (decimal)totals.GetRankPercentInterpolated() * components[pos].GetCurrentValue();
			}

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				rankPercent += 1m;
				if (rankPercent > 5m)
					rankPercent = 5m;
			}

			//if totalCurrentValue = 0, there is not enough data to calculate the avg condition
			else
			{
				return 0.0;
			}

			if (rankPercent < 1.0m)
				rankPercent = 1.0m;

			return (double)Math.Round(rankPercent, 2);
			//</mam>
		}

		//mam
		public double		GetTotalRisk()
		{
			double			sumRisk = 0;
			MajorComponent	component;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (components[pos].Retired)
					continue;

				sumRisk += (component.CWPValue * component.GetRisk());
			}

			return sumRisk;

		}
		//</mam>

		public double		GetTotalOrgUsefulLife()
		{
			double			sumULOrg = 0;
			MajorComponent	component;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (components[pos].Retired)
					continue;

				sumULOrg += (component.CWPValue * component.GetOrgUsefulLife());
			}

			return sumULOrg;
		}

		public double		GetTotalRemainingUsefulLife()
		{
			double			sumULBook = 0;
			MajorComponent	component;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (components[pos].Retired)
					continue;

				sumULBook += (component.CWPValue * component.GetRemainingUsefulLife());
			}

			return sumULBook;
		}

		public double		GetTotalEvaluatedRemainingUsefulLife()
		{
			double			sumULEval = 0;
			MajorComponent	component;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (components[pos].Retired)
					continue;

				sumULEval += (component.CWPValue * component.GetEvaluatedRemainingUsefulLife());
			}

			return Math.Round(sumULEval, 1);
		}

		//mam
		public double		GetTotalEconomicUsefulLife()
		{
			double			sumULEval = 0;
			MajorComponent	component;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				if (components[pos].Retired)
					continue;

				sumULEval += (component.CWPValue * component.GetEconomicUsefulLife());
			}

			return Math.Round(sumULEval, 1);
		}
		//</mam>

		//mam - change this to get CV / TCV rather than CWPValue?
		//mam - no, just leave it as is
		public double		GetTotalCWPValue()
		{
			double			cwp = 0.0;
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, m_processID);

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos].Retired)
					continue;

				cwp += components[pos].CWPValue;
			}

			return cwp;
		}

		public double		GetCalcTotalCWP()
		{
			MajorComponent[] components = CacheManager.GetComponents(m_infoSetID, m_processID);
			double			total = 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//mam 091607 - use rounded values
			////decimal			currentValue = GetTotalCurrentValue();
			//decimal			currentValue = GetTotalAcquisitionCost();
			decimal			currentValue = GetTotalAcquisitionCostRoundIndividualValues();

			if (currentValue == 0)
				return 0.0;

			for (int pos = 0; pos < components.Length; pos++)
			{
				if (components[pos] == null || components[pos].Retired)
					continue;

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//mam 091607 - use rounded values
				//total += Math.Round(((double)(components[pos].GetCurrentValue() / currentValue)) * 100.0, 1);
				total += Math.Round(((double)(components[pos].GetAcquisitionCostRoundIndividualValues() / currentValue)) * 100.0, 1);
			}

			return total;
		}
	}
}
