using System;
using WAM.Data;

namespace WAM.Logic
{
	/// <summary>
	/// Summary description for CalcProcess.
	/// </summary>
	public class TreatmentProcessTotals
	{
		private int			m_infoSetID = 0;
		private int			m_facilityID = 0;

		public TreatmentProcessTotals(Facility facility)
		{
			m_facilityID = facility.ID;
			m_infoSetID = facility.InfoSetID;

			if (m_facilityID != 0)
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);
		}

		public TreatmentProcess[] GetTreatmentProcesses()
		{
			return CacheManager.GetProcesses(m_infoSetID, m_facilityID);
		}

		public int			FacilityID
		{
			get { return m_facilityID; }
			set { m_facilityID = value; }
		}

		public decimal		GetTotalOrgCost()
		{
			decimal			sumOrgCost = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCost += processes[pos].OrgCost;

			return sumOrgCost;
		}

		public decimal		GetTotalCurrentValue()
		{
			decimal			total = 0;

			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetCurrentValue();

			return total;
		}

		public decimal		GetTotalAcquisitionCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetAcquisitionCost();

			return total;
		}

		//mam 091607 - new method
		public decimal		GetTotalAcquisitionCostRoundIndividualValues()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetAcquisitionCostRoundIndividualValues();

			return total;
		}

		//mam 050806
		public decimal		GetTotalAcquisitionCostEscalated()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetAcquisitionCostEscalated();

			return total;
		}

		public decimal		GetTotalReplacementValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetReplacementValue();

			return total;
		}

		//mam 050806
		public int GetAverageReplacementValueYear()
		{
			int avgYear = 0;
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			//mam 112806
			int discCount = 0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				//mam 112806 - add check for ReplacementValueYear = zero
				if (processes[pos] == null || processes[pos].GetReplacementValueYear() == 0)
					continue;

				discCount++;
				avgYear += processes[pos].GetReplacementValueYear();
			}

			//mam 112806
			//return (int)(avgYear / processes.Length);
			//return processes.Length == 0 ? 0 : (int)(avgYear / processes.Length);

			//mam 112806 - use discCount rather than disciplines.Length
			return discCount == 0 ? 0 : (int)Math.Round((decimal)avgYear / discCount, 0);
		}

		//mam 050806
		public decimal		GetTotalRehabCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetRehabCost();

			return total;
		}

		public decimal		GetTotalBookValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetBookValue();

			return total;
		}

		public decimal		GetTotalSalvageValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetSalvageValue();

			return total;
		}

		public decimal		GetTotalAnnualDepreciation()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetAnnualDepreciation();

			return total;
		}

		public decimal		GetTotalCumulativeDepreciation()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetCumulativeDepreciation();

			return total;
		}

		public decimal		GetTotalEvaluatedValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetEvaluatedValue();

			return total;
		}

		public decimal		GetTotalRepairCost()
		{
			decimal			sumRepairs = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumRepairs += processes[pos].GetRepairCost();

			return sumRepairs;
		}

		public decimal		GetTotalAnnualMaintenanceCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetAnnualMaintenanceCost();

			return total;
		}

		public double		GetCalcTotalCWP()
		{
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, m_facilityID);
			double			total = 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//mam 091607 - use rounded values
			////decimal			currentValue = GetTotalCurrentValue();
			//decimal			currentValue = GetTotalAcquisitionCost();
			decimal			currentValue = GetTotalAcquisitionCostRoundIndividualValues();

			if (currentValue == 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (processes[pos] == null)
					continue;

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//mam 091607 - use rounded values
				//total += Math.Round(((double)(processes[pos].GetCurrentValue() / currentValue)) * 100.0, 1);
				total += Math.Round(((double)(processes[pos].GetAcquisitionCostRoundIndividualValues() / currentValue)) * 100.0, 1);
			}

			return total;
		}

		public double		GetRankPercent()
		{
//			decimal			totalCurrentValue = GetTotalCurrentValue();
//			double			rankPercent = 0.0;
//
//			if (totalCurrentValue != 0)
//			{
//				rankPercent = 0.4113;
//				rankPercent *= Math.Pow((double)((double)
//					((GetTotalRepairCost() / totalCurrentValue) * 100m)), 0.583);
//				if (rankPercent > 5.0)
//					rankPercent = 5.0;
//			}
//
//			if (rankPercent < 1.0)
//				rankPercent = 1.0;
//
//			return rankPercent;

			//mam - new calculation for GetRankPercent
			MajorComponentTotals totals = null;
			decimal			totalCurrentValue = GetTotalCurrentValue();
			decimal			rankPercent = 0m;
			decimal			sumRankValues = 0m;
			
			//get the average condition for each Major Component

			// Retrieve the component data for the current process
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, m_facilityID);
			for (int pos = 0; pos < processes.Length; pos++)
			{
				// Retrieve the sum of the Condition Percentage x Current Value

				totals = processes[pos].GetComponentTotals();

				// get the average condition for the disciplines in the current component * the CV for the current component
				sumRankValues += (decimal)totals.GetRankPercent() * processes[pos].GetCurrentValue();
			}

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				rankPercent += 1m;
				if (rankPercent > 5m)
					rankPercent = 5m;
			}

				//if totalCurrentValue = 0, there is not enough data to calculate the avg condition
			else
			{
				return 0.0;
			}

			if (rankPercent < 1.0m)
				rankPercent = 1.0m;

			return (double)Math.Round(rankPercent, 2);
			//</mam>
		}

		public double		GetTotalOrgUsefulLife()
		{
			double			sumULOrg = 0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				sumULOrg += (process.CWPValue * process.GetOrgUsefulLife());
			}

			return sumULOrg;
		}

		public double		GetTotalRemainingUsefulLife()
		{
			double			sumULBook = 0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				sumULBook += (process.CWPValue * process.GetRemainingUsefulLife());
			}

			return sumULBook;
		}

		public double		GetTotalEvaluatedRemainingUsefulLife()
		{
			double			sumULEval = 0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				sumULEval += (process.CWPValue * process.GetEvaluatedRemainingUsefulLife());
			}

			return sumULEval;
		}

		//mam
		public double		GetTotalEconomicUsefulLife()
		{
			double			sumULEcon = 0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				sumULEcon += (process.CWPValue * process.GetEconomicUsefulLife());
			}

			return sumULEcon;
		}
		//</mam>

		public double		GetTotalCWPValue()
		{
			double			cwp = 0.0;
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, m_facilityID);
			Facility		facility = CacheManager.GetFacility(m_infoSetID, m_facilityID);
			decimal			totalOrgCost = 0m;

			if (facility != null)
			{
				totalOrgCost = facility.GetOrgCost();
			}

			if (totalOrgCost == 0m)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				cwp += (double)(processes[pos].OrgCost / totalOrgCost);
			}

			return cwp;
		}

		public decimal		GetTotalOrgCostOrgVal()
		{
			decimal			sumOrgCostOrgVal = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCostOrgVal += processes[pos].OrgCostOrgVal;

			return sumOrgCostOrgVal;
		}

		public decimal		GetTotalOrgCostLessStrtLineDep()
		{
			decimal			sumOrgCostLSLD = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCostLSLD += processes[pos].GetOrgCostLessStrtLineDep();

			return sumOrgCostLSLD;
		}

		#region /***** Funded Methods *****/
		public decimal		GetFundedTotalCurrentValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedCurrentValue();

			return total;
		}

		public double		GetFundedCalcTotalCWP()
		{
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);
			double			total = 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//mam 091607 - get rounded values
			////decimal			currentValue = GetFundedTotalCurrentValue();
			//decimal			currentValue = GetFundedTotalAcquisitionCost();
			decimal			currentValue = GetFundedTotalAcquisitionCostRoundIndividualValues();

			if (currentValue == 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (processes[pos] == null || !processes[pos].IsFunded)
					continue;

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//mam 091607 - get rounded values
				////total += Math.Round(((double)(processes[pos].GetFundedCurrentValue() / currentValue)) * 100.0, 1);
				//total += Math.Round(((double)(processes[pos].GetFundedAcquisitionCost() / currentValue)) * 100.0, 1);
				total += Math.Round(((double)(processes[pos].GetFundedAcquisitionCostRoundIndividualValues() / currentValue)) * 100.0, 1);
			}

			return total;
		}

		public decimal		GetFundedTotalAcquisitionCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (!processes[pos].IsFunded)
					continue;

				total += processes[pos].GetFundedAcquisitionCost();
			}

			return total;
		}

		public decimal		GetFundedTotalAcquisitionCostRoundIndividualValues()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (!processes[pos].IsFunded)
					continue;

				total += processes[pos].GetFundedAcquisitionCostRoundIndividualValues();
			}

			return total;
		}

		//mam 050806
		public decimal		GetFundedTotalAcquisitionCostEscalated()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (!processes[pos].IsFunded)
					continue;

				total += processes[pos].GetFundedAcquisitionCostEscalated();
			}

			return total;
		}

		//mam 050806
		public decimal		GetFundedTotalRehabCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
			{
				if (!processes[pos].IsFunded)
					continue;

				total += processes[pos].GetFundedRehabCost();
			}

			return total;
		}

		public decimal		GetFundedTotalReplacementValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedReplacementValue();

			return total;
		}

		public decimal		GetFundedTotalBookValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedBookValue();

			return total;
		}

		public decimal		GetFundedTotalSalvageValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedSalvageValue();

			return total;
		}

		public decimal		GetFundedTotalAnnualDepreciation()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedAnnualDepreciation();

			return total;
		}

		public decimal		GetFundedTotalCumulativeDepreciation()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedCumulativeDepreciation();

			return total;
		}

		public decimal		GetFundedTotalEvaluatedValue()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedEvaluatedValue();

			return total;
		}

		public decimal		GetFundedTotalRepairCost()
		{
			decimal			sumRepairs = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumRepairs += processes[pos].GetFundedRepairCost();

			return sumRepairs;
		}

		public decimal		GetFundedTotalAnnualMaintenanceCost()
		{
			decimal			total = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				total += processes[pos].GetFundedAnnualMaintenanceCost();

			return total;
		}

		public decimal		GetFundedTotalOrgCost()
		{
			decimal			sumOrgCost = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCost += processes[pos].GetFundedCost();

			return sumOrgCost;
		}

		public double		GetFundedTotalOrgUsefulLife()
		{
			decimal			sumOrgCost = GetFundedTotalOrgCost();
			double			sumULOrg = 0;
			double			currentItem = 0.0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			if (sumOrgCost <= 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (process.IsFunded != true)
					continue;

				currentItem = ((double)process.GetFundedCost() * process.GetOrgUsefulLife());
				currentItem /= (double)sumOrgCost;
				sumULOrg += currentItem;
			}

			return sumULOrg;
		}

		public double		GetFundedTotalRemainingUsefulLife()
		{
			decimal			sumOrgCost = GetFundedTotalOrgCost();
			double			sumULBook = 0;
			double			currentItem = 0.0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			if (sumOrgCost <= 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (process.IsFunded != true)
					continue;

				currentItem = ((double)process.GetFundedCost() * process.GetRemainingUsefulLife());
				currentItem /= (double)sumOrgCost;
				sumULBook += currentItem;
			}

			return sumULBook;
		}

		public double		GetFundedTotalEvaluatedRemainingUsefulLife()
		{
			decimal			sumOrgCost = GetFundedTotalOrgCost();
			double			sumULEval = 0;
			double			currentItem = 0.0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			if (sumOrgCost <= 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (process.IsFunded != true)
					continue;

				currentItem = ((double)process.GetFundedCost() * process.GetEvaluatedRemainingUsefulLife());
				currentItem /= (double)sumOrgCost;
				sumULEval += currentItem;
			}

			return Math.Round(sumULEval, 1);
		}

		//mam
		public double		GetFundedTotalEconomicUsefulLife()
		{
			decimal			sumOrgCost = GetFundedTotalOrgCost();
			double			sumULEcon = 0;
			double			currentItem = 0.0;
			TreatmentProcess process;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			if (sumOrgCost <= 0)
				return 0.0;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (process.IsFunded != true)
					continue;

				currentItem = ((double)process.GetFundedCost() * process.GetEconomicUsefulLife());
				currentItem /= (double)sumOrgCost;
				sumULEcon += currentItem;
			}

			return Math.Round(sumULEcon, 1);
		}
		//</mam>

		public decimal		GetFundedTotalOrgCostOrgVal()
		{
			decimal			sumOrgCostOrgVal = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCostOrgVal += processes[pos].GetFundedOrgCostOrgVal();

			return sumOrgCostOrgVal;
		}

		public decimal		GetFundedTotalCostLessStrtLineDep()
		{
			decimal			sumOrgCostLSLD = 0;
			TreatmentProcess[] processes = 
				CacheManager.GetProcesses(m_infoSetID, m_facilityID);

			for (int pos = 0; pos < processes.Length; pos++)
				sumOrgCostLSLD += processes[pos].GetFundedCostLessStrtLineDep();

			return sumOrgCostLSLD;
		}
		#endregion /***** Funded Methods *****/
	}
}
