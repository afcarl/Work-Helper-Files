using System;
using System.Text;
using WAM.Data;

namespace WAM.Logic
{
	/// <summary>
	/// The UnitFilter class contains filter information and may be
	/// compared against the different types of units to determine if 
	/// the unit matches the filter or not
	/// </summary>
	public class UnitFilter
	{
		#region /***** Filter Enums *****/
		public enum FilterSource
		{
			Undefined = 0,
			AcquisitionCost = 1,
			CurrentValue = 2,
			ReplacementValue = 3,
			BookValue = 4,
			SalvageValue = 5,
			AnnualDepreciation = 6,
			CumulativeDepreciation = 7,
			EvaluatedValue = 8,
			RepairCost = 9,
			AnnualMaintCost = 10,
			InstallYear = 11,
			OriginalUL = 12,
			RemainingUL = 13,
			EvalRemainingUL = 14,
			ConditionRank = 15,
			LevelOfService = 16,
			OverallCriticality = 17,
			Vulnerability = 18,
			Risk = 19,
			ReplacementCost = 20,
			//mam
			InspectionYear = 21,
			EconomicUL = 22,
			//</mam>

			//mam 050806
			AcquisitionCostEscalated = 23,
			RehabCost = 24,
			ReplacementValueYear = 25,
			TreeNodeIndex = 100,

			//mam 07072011
			CipMode = 26,
			AssetClass = 27,
			RehabCostYear = 28,
			RehabInterval = 29,
			RehabNext = 30,
			RehabYearLast = 31,
			RehabYearNext = 32,
			NextReplacementYear = 33,

			//mam 01222012
			FacilityCriticality = 34,
			ReplacementNext = 35,
		}

		public enum FilterCompareTo
		{
			Value = 0,
			AcquisitionCost = 1,
			CurrentValue = 2,
			ReplacementValue = 3,
			BookValue = 4,
			SalvageValue = 5,
			AnnualDepreciation = 6,
			CumulativeDepreciation = 7,
			EvaluatedValue = 8,
			RepairCost = 9,
			AnnualMaintCost = 10,
			InstallYear = 11,
			OriginalUL = 12,
			RemainingUL = 13,
			EvalRemainingUL = 14,
			ConditionRank = 15,
			LevelOfService = 16,
			OverallCriticality = 17,
			Vulnerability = 18,
			Risk = 19,
			ReplacementCost = 20,
			//mam
			InspectionYear = 21,
			EconomicUL = 22,
			//</mam>

			//mam 050806
			AcquisitionCostEscalated = 23,
			RehabCost = 24,
			ReplacementValueYear = 25,
			TreeNodeIndex = 100,

			//mam 07072011
			CipMode = 26,
			AssetClass = 27,
			RehabCostYear = 28,
			RehabInterval = 29,
			RehabNext = 30,
			RehabYearLast = 31,
			RehabYearNext = 32,
			NextReplacementYear = 33,

			//mam 01222012
			FacilityCriticality = 34,
			ReplacementNext = 35,
		}

		public enum FilterOperator
		{
			GT = 0,			// Greater than
			GTE = 1,		// Greater than or Equal
			LT = 2,			// Less than
			LTE = 3,		// Less than or equal
			Equals = 4,
			Between = 5,
			OutsideOf = 6,

			//mam 07072011
			NotEquals = 7
		}

		//mam
		public enum FilterSourceSort
		{
			Undefined = 0,
			AcquisitionCost = 1,
			CurrentValue = 2,
			ReplacementValue = 3,
			BookValue = 4,
			SalvageValue = 5,
			AnnualDepreciation = 6,
			CumulativeDepreciation = 7,
			EvaluatedValue = 8,
			RepairCost = 9,
			AnnualMaintCost = 10,
			InstallYear = 11,
			OriginalUL = 12,
			RemainingUL = 13,
			EvalRemainingUL = 14,
			ConditionRank = 15,
			LevelOfService = 16,
			OverallCriticality = 17,
			Vulnerability = 18,
			Risk = 19,
			ReplacementCost = 20,
			//mam
			InspectionYear = 21,
			EconomicUL = 22,
			//</mam>

			//mam 050806
			AcquisitionCostEscalated = 23,
			RehabCost = 24,
			ReplacementValueYear = 25,
			TreeNodeIndex = 100,

			//mam 07072011
			CipMode = 26,
			AssetClass = 27,
			RehabCostYear = 28,
			RehabInterval = 29,
			RehabNext = 30,
			RehabYearLast = 31,
			RehabYearNext = 32,
			NextReplacementYear = 33,

			//mam 01222012
			FacilityCriticality = 34,
			ReplacementNext = 35,
		}
		//</mam>

		#endregion /***** Filter Enums *****/

		#region /***** Enum Handlers *****/
		public static string GetFilterSourceString(FilterSource source)
		{
			switch (source)
			{
				case FilterSource.Undefined:
					return "< Select Source >";
				case FilterSource.AcquisitionCost:
					return "Acquisition Cost";
				case FilterSource.CurrentValue:
					return "Current Value";
				case FilterSource.ReplacementValue:
					return "Replacement Value";
				case FilterSource.BookValue:
					return "Book Value";
				case FilterSource.SalvageValue:
					return "Salvage Value";
				case FilterSource.AnnualDepreciation:
					return "Annual Depreciation";
				case FilterSource.CumulativeDepreciation:
					return "Cumulative Depreciation";
				case FilterSource.EvaluatedValue:
					return "Evaluated Value";
				case FilterSource.RepairCost:
					return "Repair Cost";
				case FilterSource.AnnualMaintCost:
					return "Annual Maintenance Cost";
				case FilterSource.InstallYear:
					return "Install Year";
				case FilterSource.OriginalUL:
					return "Original Useful Life";
				case FilterSource.RemainingUL:
					return "Remaining Useful Life";
				case FilterSource.EvalRemainingUL:
					return "Evaluated Remaining Useful Life";
				case FilterSource.ConditionRank:
					return "Condition Ranking";
				case FilterSource.LevelOfService:
					return "Level of Service";
				case FilterSource.OverallCriticality:
					return "Overall Criticality";
				case FilterSource.Vulnerability:
					return "Vulnerability";
				case FilterSource.Risk:
					return "Risk";
				//mam
				case FilterSource.ReplacementCost:
					return "Replacement Cost";
				case FilterSource.InspectionYear:
					return "Inspection Year";
				case FilterSource.EconomicUL:
					return "Economic Remaining Useful Life";
				//</mam>

				//mam 050806
				case FilterSource.AcquisitionCostEscalated:
					return "Escalated Acquisition Cost";
				case FilterSource.RehabCost:
					//return "Rehabilitation Cost";
					return "Rehabilitation: Cost";
				case FilterSource.ReplacementValueYear:
					return "Replacement Value Year";

				//mam 07072011
				case FilterSource.CipMode:
					return "Planning Mode";
				case FilterSource.AssetClass:
					return "Asset Class";
				case FilterSource.RehabCostYear:
					return "Rehabilitation: Cost Year";
				case FilterSource.RehabInterval:
					//return "Rehabilitation Interval";
					return "Rehabilitation: Interval";
				case FilterSource.RehabNext:
					//return "Time to Next Rehabilitation";
					return "Rehabilitation: Time to Next";
				case FilterSource.RehabYearLast:
					//return "Last Rehabilitation Year";
					return "Rehabilitation: Last Rehabilitation Year";
				case FilterSource.RehabYearNext:
					//return "Next Rehabilitation Year";
					return "Rehabilitation: Next Rehabilitation Year";
				//mam 01222012 - changed return value
				case FilterSource.NextReplacementYear:
					//return "Next Replacement Year";
					return "Replacement: Next Replacement Year";

				//mam 01222012
				case FilterSource.FacilityCriticality:
					return "Facility Criticality Weighting Factor";
				case FilterSource.ReplacementNext:
					return "Replacement: Time to Next";
			}

			return "";
		}

		//mam
		public static string GetFilterSourceString(FilterSource source, WAM.UI.NodeType nodeType)
		{
			switch (source)
			{
				case FilterSource.Undefined:
					return "< Select Source >";
				case FilterSource.AcquisitionCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSource.AcquisitionCostEscalated:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Escalated Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSource.RehabCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						//return "Rehabilitation Cost";
						return "Rehabilitation: Cost";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.RehabCostYear:
					//if (nodeType.ToString().StartsWith("Discipline") || nodeType == WAM.UI.NodeType.NoneSelected)
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Rehabilitation: Cost Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.RehabInterval:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Rehabilitation Interval";
						return "Rehabilitation: Interval";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.RehabNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Time to Next Rehabilitation";
						return "Rehabilitation: Time to Next";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.RehabYearLast:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Last Rehabilitation Year";
						return "Rehabilitation: Last Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.RehabYearNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Next Rehabilitation Year";
						return "Rehabilitation: Next Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.NextReplacementYear:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//mam 01222012 - changed return value
						//return "Next Replacement Year";
						return "Replacement: Next Replacement Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.CipMode:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Planning Mode";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSource.AssetClass:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Asset Class";
					}
					else
					{
						return "";
					}

				//mam 01222012
				case FilterSource.FacilityCriticality:
					if (nodeType == WAM.UI.NodeType.Facility)
					{
						return "Facility Criticality Weighting Factor";
					}
					else
					{
						return "";
					}

				//mam 01222012
				case FilterSource.ReplacementNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Replacement: Time to Next";
					}
					else
					{
						return "";
					}

				case FilterSource.CurrentValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Current Value";
					}
					else
					{
						return "";
					}
				case FilterSource.ReplacementValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value";
					}
					else
					{
						return "";
					}
				case FilterSource.BookValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Book Value";
					}
					else
					{
						return "";
					}
				case FilterSource.SalvageValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Salvage Value";
					}
					else
					{
						return "";
					}
				case FilterSource.AnnualDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Annual Depreciation";
					}
					else
					{
						return "";
					}
				case FilterSource.CumulativeDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Cumulative Depreciation";
					}
					else
					{
						return "";
					}
				case FilterSource.EvaluatedValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Evaluated Value";
					}
					else
					{
						return "";
					}
				case FilterSource.RepairCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Repair Cost";
					}
					else
					{
						return "";
					}
				case FilterSource.AnnualMaintCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
					return "Annual Maintenance Cost";
					}
					else
					{
						return "";
					}
				case FilterSource.InstallYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent &&
						nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Install Year";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSource.ReplacementValueYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent &&
						nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value Year";
					}
					else
					{
						return "";
					}

				case FilterSource.OriginalUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Original Useful Life";
					}
					else
					{
						return "";
					}
				case FilterSource.RemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Remaining Useful Life";
					}
					else
					{
						return "";
					}
				case FilterSource.EvalRemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Evaluated Remaining Useful Life";
					}
					else
					{
						return "";
					}

				//mam
				case FilterSource.EconomicUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Economic Remaining Useful Life";
					}
					else
					{
						return "";
					}
				//</mam>
				
				case FilterSource.ConditionRank:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess)
					{
						return "Condition Ranking";
					}
					else
					{
						return "";
					}
				case FilterSource.LevelOfService:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Level of Service";
					}
					else
					{
						return "";
					}
				case FilterSource.OverallCriticality:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Overall Criticality";
					}
					else
					{
						return "";
					}
				case FilterSource.Vulnerability:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Vulnerability";
					}
					else
					{
						return "";
					}
				case FilterSource.Risk:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Risk";
					}
					else
					{
						return "";
					}
				case FilterSource.ReplacementCost:
					if (nodeType == WAM.UI.NodeType.AssetList)
					{
						return "Replacement Cost";
					}
					else
					{
						return "";
					}
				//mam
				case FilterSource.InspectionYear:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Inspection Year";
					}
					else
					{
						return "";
					}
				//</mam>
			}

			return "";
		}
		//</mam>

		public static string GetFilterCompareToString(FilterCompareTo compare)
		{
			switch (compare)
			{
				case FilterCompareTo.Value:
					return "< Specific Value(s) >";
				case FilterCompareTo.AcquisitionCost:
					return "Acquisition Cost";

				//mam 050806
				case FilterCompareTo.AcquisitionCostEscalated:
					return "Escalated Acquisition Cost";
				case FilterCompareTo.RehabCost:
					//return "Rehabilitation Cost";
					return "Rehabilitation: Cost";

				//mam 07072011
				case FilterCompareTo.CipMode:
					return "Planning Mode";
				case FilterCompareTo.AssetClass:
					return "Asset Class";
				case FilterCompareTo.RehabCostYear:
					return "Rehabilitation: Cost Year";
				case FilterCompareTo.RehabInterval:
					//return "Rehabilitation Interval";
					return "Rehabilitation: Interval";
				case FilterCompareTo.RehabNext:
					//return "Time to Next Rehabilitation";
					return "Rehabilitation: Time to Next";
				case FilterCompareTo.RehabYearLast:
					//return "Last Rehabilitation Year";
					return "Rehabilitation: Last Rehabilitation Year";
				case FilterCompareTo.RehabYearNext:
					//return "Next Rehabilitation Year";
					return "Rehabilitation: Next Rehabilitation Year";
				//mam 01222012 - changed return value
				case FilterCompareTo.NextReplacementYear:
					//return "Next ReplacementYear";
					return "Replacement: Next ReplacementYear";

				//mam 01222012
				case FilterCompareTo.FacilityCriticality:
					return "Facility Criticality Weighting Factor";

				//mam 01222012
				case FilterCompareTo.ReplacementNext:
					return "Replacement: Time to Next";

				case FilterCompareTo.CurrentValue:
					return "Current Value";
				case FilterCompareTo.ReplacementValue:
					return "Replacement Value";
				case FilterCompareTo.BookValue:
					return "Book Value";
				case FilterCompareTo.SalvageValue:
					return "Salvage Value";
				case FilterCompareTo.AnnualDepreciation:
					return "Annual Depreciation";
				case FilterCompareTo.CumulativeDepreciation:
					return "Cumulative Depreciation";
				case FilterCompareTo.EvaluatedValue:
					return "Evaluated Value";
				case FilterCompareTo.RepairCost:
					return "Repair Cost";
				case FilterCompareTo.AnnualMaintCost:
					return "Annual Maintenance Cost";

					//mam
				case FilterCompareTo.InstallYear:
					return "Install Year";
				//</mam>

				//mam 050806
				case FilterCompareTo.ReplacementValueYear:
					return "Replacement Value Year";

				case FilterCompareTo.OriginalUL:
					return "Original Useful Life";
				case FilterCompareTo.RemainingUL:
					return "Remaining Useful Life";
				case FilterCompareTo.EvalRemainingUL:
					return "Evaluated Remaining Useful Life";

				//mam
				case FilterCompareTo.EconomicUL:
					return "Economic Remaining Useful Life";
				//</mam>

				case FilterCompareTo.ConditionRank:
					return "Condition Ranking";
				case FilterCompareTo.LevelOfService:
					return "Level of Service";

				//mam
				case FilterCompareTo.OverallCriticality:
					return "Overall Criticality";
				case FilterCompareTo.Vulnerability:
					return "Vulnerability";
				case FilterCompareTo.Risk:
					return "Risk";
				case FilterCompareTo.ReplacementCost:
					return "Replacement Cost";
				case FilterCompareTo.InspectionYear:
					return "Inspection Year";
				//</mam>
			}

			return "";
		}

		//mam
		public static string GetFilterCompareToString(FilterCompareTo compare, WAM.UI.NodeType nodeType)
		{
			switch (compare)
			{
				case FilterCompareTo.Value:
					return "< Specific Value(s) >";
				case FilterCompareTo.AcquisitionCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterCompareTo.AcquisitionCostEscalated:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Escalated Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterCompareTo.RehabCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						//return "Rehabilitation Cost";
						return "Rehabilitation: Cost";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.RehabCostYear:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Rehabilitation: Cost Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.RehabInterval:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Rehabilitation Interval";
						return "Rehabilitation: Interval";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.RehabNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Time to Next Rehabilitation";
						return "Rehabilitation: Time to Next";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.RehabYearLast:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Last Rehabilitation Year";
						return "Rehabilitation: Last Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.RehabYearNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Next Rehabilitation Year";
						return "Rehabilitation: Next Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.NextReplacementYear:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Next Rehabilitation Year";
						return "Replacement: Next Replacement Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.CipMode:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Planning Mode";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterCompareTo.AssetClass:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Asset Class";
					}
					else
					{
						return "";
					}

				//mam 01222012
				case FilterCompareTo.FacilityCriticality:
					if (nodeType == WAM.UI.NodeType.Facility)
					{
						return "Facility Criticality Weighting Factor";
					}
					else
					{
						return "";
					}

				//mam 01222012
				case FilterCompareTo.ReplacementNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Replacement: Time to Next";
					}
					else
					{
						return "";
					}

				case FilterCompareTo.CurrentValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Current Value";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.ReplacementValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value";
					}
					else
					{
						return "";
					}

				case FilterCompareTo.BookValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Book Value";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.SalvageValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Salvage Value";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.AnnualDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Annual Depreciation";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.CumulativeDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Cumulative Depreciation";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.EvaluatedValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Evaluated Value";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.RepairCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Repair Cost";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.AnnualMaintCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Annual Maintenance Cost";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.InstallYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Install Year";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterCompareTo.ReplacementValueYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value Year";
					}
					else
					{
						return "";
					}

				case FilterCompareTo.OriginalUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Original Useful Life";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.RemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Remaining Useful Life";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.EvalRemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Evaluated Remaining Useful Life";
					}
					else
					{
						return "";
					}

				//mam
				case FilterCompareTo.EconomicUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Economic Remaining Useful Life";
					}
					else
					{
						return "";
					}
				//</mam>

				case FilterCompareTo.ConditionRank:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess)
					{
						return "Condition Ranking";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.LevelOfService:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Level of Service";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.OverallCriticality:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Overall Criticality";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.Vulnerability:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Vulnerability";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.Risk:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Risk";
					}
					else
					{
						return "";
					}
				case FilterCompareTo.ReplacementCost:
					if (nodeType == WAM.UI.NodeType.AssetList)
					{
						return "Replacement Cost";
					}
					else
					{
						return "";
					}
				//mam
				case FilterCompareTo.InspectionYear:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Inspection Year";
					}
					else
					{
						return "";
					}
				//</mam>
			}

			return "";
		}
		//</mam>

		public static string GetFilterOperatorString(FilterOperator op)
		{
			switch (op)
			{
				case FilterOperator.GT:
					return ">";
				case FilterOperator.GTE:
					return ">=";
				case FilterOperator.LT:
					return "<";
				case FilterOperator.LTE:
					return "<=";
				case FilterOperator.Equals:
					return "=";
				case FilterOperator.Between:
					return "Between";
				case FilterOperator.OutsideOf:
					return "Outside Range";

				////mam 07072011
				case FilterOperator.NotEquals:
					return "<>";
			}

			return "";
		}

		//mam 07072011
		//public static string GetFilterOperatorString2(FilterOperator op)
		//{
		//	switch (op)
		//	{
		//		case FilterOperator.Equals:
		//			return "=";
		//		case FilterOperator.NotEquals:
		//			return "<>";
		//	}
		//
		//	return "";
		//}

		//mam
		public static string GetFilterSourceStringSort(FilterSourceSort source)
		{
			switch (source)
			{
				case FilterSourceSort.Undefined:
					return "< Select a Field to Sort By >";
				case FilterSourceSort.AcquisitionCost:
					return "Acquisition Cost";

				//mam 050806
				case FilterSourceSort.AcquisitionCostEscalated:
					return "Escalated Acquisition Cost";
				case FilterSourceSort.RehabCost:
					//return "Rehabilitation Cost";
					return "Rehabilitation: Cost";

				//mam 07072011
				case FilterSourceSort.CipMode:
					return "Planning Mode";
				case FilterSourceSort.AssetClass:
					return "Asset Class";
				case FilterSourceSort.RehabCostYear:
					return "Rehabilitation: Cost Year";
				case FilterSourceSort.RehabInterval:
					//return "Rehabilitation Interval";
					return "Rehabilitation: Interval";
				case FilterSourceSort.RehabNext:
					//return "Time to Next Rehabilitation";
					return "Rehabilitation: Time to Next";
				case FilterSourceSort.RehabYearLast:
					//return "Last Rehabilitation Year";
					return "Rehabilitation: Last Rehabilitation Year";
				case FilterSourceSort.RehabYearNext:
					//return "Next Rehabilitation Year";
					return "Rehabilitation: Next Rehabilitation Year";
				//mam 01222012 - changed return value
				case FilterSourceSort.NextReplacementYear:
					//return "Next Replacement Year";
					return "Replacement: Next Replacement Year";

				//mam 01222012
				case FilterSourceSort.FacilityCriticality:
					return "Facility Criticality Weighting Factor";

				//mam 01222012
				case FilterSourceSort.ReplacementNext:
					return "Replacement: Time to Next";

				case FilterSourceSort.CurrentValue:
					return "Current Value";
				case FilterSourceSort.ReplacementValue:
					return "Replacement Value";
				case FilterSourceSort.BookValue:
					return "Book Value";
				case FilterSourceSort.SalvageValue:
					return "Salvage Value";
				case FilterSourceSort.AnnualDepreciation:
					return "Annual Depreciation";
				case FilterSourceSort.CumulativeDepreciation:
					return "Cumulative Depreciation";
				case FilterSourceSort.EvaluatedValue:
					return "Evaluated Value";
				case FilterSourceSort.RepairCost:
					return "Repair Cost";
				case FilterSourceSort.AnnualMaintCost:
					return "Annual Maintenance Cost";
				case FilterSourceSort.InstallYear:
					return "Install Year";
				case FilterSourceSort.OriginalUL:
					return "Original Useful Life";
				case FilterSourceSort.RemainingUL:
					return "Remaining Useful Life";
				case FilterSourceSort.EvalRemainingUL:
					return "Evaluated Remaining Useful Life";

				//mam
				case FilterSourceSort.EconomicUL:
					return "Economic Remaining Useful Life";
				//</mam>

				case FilterSourceSort.ConditionRank:
					return "Condition Ranking";
				case FilterSourceSort.LevelOfService:
					return "Level of Service";
				case FilterSourceSort.OverallCriticality:
					return "Overall Criticality";
				case FilterSourceSort.Vulnerability:
					return "Vulnerability";
				case FilterSourceSort.Risk:
					return "Risk";
				case FilterSourceSort.ReplacementCost:
					return "Replacement Cost";
				//mam
				case FilterSourceSort.InspectionYear:
					return "Inspection Year";
				//</mam>

				//mam 050806
				case FilterSourceSort.ReplacementValueYear:
					return "Replacement Value Year";
			}

			return "";
		}
		//</mam>

		//mam
		public static string GetFilterSourceStringSort(FilterSourceSort source, WAM.UI.NodeType nodeType)
		{
			switch (source)
			{
				case FilterSourceSort.Undefined:
					return "< Select a Field to Sort By >";
				case FilterSourceSort.AcquisitionCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSourceSort.AcquisitionCostEscalated:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Escalated Acquisition Cost";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSourceSort.RehabCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						//return "Rehabilitation Cost";
						return "Rehabilitation: Cost";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.RehabCostYear:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Rehabilitation: Cost Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.RehabInterval:
					//if (nodeType != WAM.UI.NodeType.AssetList)
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Rehabilitation Interval";
						return "Rehabilitation: Interval";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.RehabNext:
					//if (nodeType != WAM.UI.NodeType.AssetList)
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Time to Next Rehabilitation";
						return "Rehabilitation: Time to Next";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.RehabYearLast:
					//if (nodeType != WAM.UI.NodeType.AssetList)
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Last Rehabilitation Year";
						return "Rehabilitation: Last Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.RehabYearNext:
					//if (nodeType != WAM.UI.NodeType.AssetList)
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//return "Next Rehabilitation Year";
						return "Rehabilitation: Next Rehabilitation Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.NextReplacementYear:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						//mam 01222012 - changed return value
						//return "Next Replacement Year";
						return "Replacement: Next Replacement Year";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.CipMode:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Planning Mode";
					}
					else
					{
						return "";
					}

				//mam 07072011
				case FilterSourceSort.AssetClass:
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						return "Asset Class";
					}
					else
					{
						return "";
					}

				//mam 01222012
				case FilterSourceSort.FacilityCriticality:
					if (nodeType == WAM.UI.NodeType.Facility)
					{
						return "Facility Criticality Weighting Factor";
					}
					else
					{
						return "";
					}

				case FilterSourceSort.ReplacementNext:
					if (nodeType == WAM.UI.NodeType.DisciplineLand 
						|| nodeType == WAM.UI.NodeType.DisciplineMech 
						|| nodeType == WAM.UI.NodeType.DisciplineStruct 
						|| nodeType == WAM.UI.NodeType.NoneSelected)
					{
						return "Replacement: Time to Next";
					}
					else
					{
						return "";
					}

				case FilterSourceSort.CurrentValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Current Value";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.ReplacementValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value";
					}
					else
					{
						return "";
					}

				case FilterSourceSort.BookValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Book Value";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.SalvageValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Salvage Value";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.AnnualDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Annual Depreciation";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.CumulativeDepreciation:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Cumulative Depreciation";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.EvaluatedValue:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Evaluated Value";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.RepairCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Repair Cost";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.AnnualMaintCost:
					if (nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Annual Maintenance Cost";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.InstallYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Install Year";
					}
					else
					{
						return "";
					}

				//mam 050806
				case FilterSourceSort.ReplacementValueYear:
					if (nodeType != WAM.UI.NodeType.Facility &&
						nodeType != WAM.UI.NodeType.TreatmentProcess &&
						nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Replacement Value Year";
					}
					else
					{
						return "";
					}

				case FilterSourceSort.OriginalUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Original Useful Life";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.RemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Remaining Useful Life";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.EvalRemainingUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Evaluated Remaining Useful Life";
					}
					else
					{
						return "";
					}

				//mam
				case FilterSourceSort.EconomicUL:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Economic Remaining Useful Life";
					}
					else
					{
						return "";
					}
				//</mam>

				case FilterSourceSort.ConditionRank:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess)
					{
						return "Condition Ranking";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.LevelOfService:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Level of Service";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.OverallCriticality:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Overall Criticality";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.Vulnerability:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Vulnerability";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.Risk:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.DisciplineLand
						&& nodeType != WAM.UI.NodeType.DisciplineMech
						&& nodeType != WAM.UI.NodeType.DisciplineStruct
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Risk";
					}
					else
					{
						return "";
					}
				case FilterSourceSort.ReplacementCost:
					if (nodeType == WAM.UI.NodeType.AssetList)
					{
						return "Replacement Cost";
					}
					else
					{
						return "";
					}
				//mam
				case FilterSourceSort.InspectionYear:
					if (nodeType != WAM.UI.NodeType.Facility
						&& nodeType != WAM.UI.NodeType.TreatmentProcess
						&& nodeType != WAM.UI.NodeType.MajorComponent
						&& nodeType != WAM.UI.NodeType.AssetList)
					{
						return "Inspection Year";
					}
					else
					{
						return "";
					}
				//</mam>
			}

			return "";
		}
		//</mam>

		#endregion /***** Enum Handlers *****/

		#region / ***** Comparison ***** /

		private FilterSource m_filterSource = FilterSource.Undefined;
		private FilterCompareTo m_compareTo = FilterCompareTo.Value;
		private FilterOperator m_operator = FilterOperator.LTE;

		private decimal		m_compareVal1 = 0m;
		private decimal		m_compareVal2 = 0m;

		//mam 07072011
		private string m_compareVal1String = string.Empty;
		private string m_compareVal2String = string.Empty;

		public				UnitFilter()
		{
		}

		public FilterSource Source
		{
			get { return m_filterSource; }
			set { m_filterSource = value; }
		}

		public FilterCompareTo Compare
		{
			get { return m_compareTo; }
			set { m_compareTo = value; }
		}

		public FilterOperator Operator
		{
			get { return m_operator; }
			set { m_operator = value; }
		}

		public decimal		CompareVal1
		{
			get { return m_compareVal1; }
			set { m_compareVal1 = value; }
		}

		// Only used with Between and Outside Of operators
		public decimal		CompareVal2
		{
			get { return m_compareVal2; }
			set { m_compareVal2 = value; }
		}

		//mam 07072011
		public string CompareVal1String
		{
			get { return m_compareVal1String; }
			set { m_compareVal1String = value; }
		}

		//mam 07072011
		public string CompareVal2String
		{
			get { return m_compareVal2String; }
			set { m_compareVal2String = value; }
		}

		public string		Description
		{
			get
			{
				StringBuilder builder = new StringBuilder();

				// Build a text description of the filter
				if (m_filterSource == FilterSource.Undefined)
					return "Undefined";

				//mam 07072011 - allow user to filter by Asset Class, which is a string (every other filter is numeric)
				bool isAssetClass = false;
				if ((UnitFilter.FilterSource)m_filterSource == UnitFilter.FilterSource.AssetClass
					|| (UnitFilter.FilterSource)m_filterSource == UnitFilter.FilterSource.CipMode)
				{
					isAssetClass = true;
				}

				builder.Append(GetFilterSourceString(m_filterSource));
				builder.Append(' ');
				builder.Append(GetFilterOperatorString(m_operator));
				builder.Append(' ');

				// Here is where we branch based on compare target
				if (m_compareTo == FilterCompareTo.Value)
				{
					switch (m_operator)
					{
						case FilterOperator.Between:
						case FilterOperator.OutsideOf:
						{
							builder.AppendFormat("{0} and {1}", m_compareVal1, m_compareVal2);
							break;
						}
						default:
						{
							//mam 07072011 - check if filter is asset class
							if (isAssetClass)
							{
								builder.Append(m_compareVal1String);
							}
							else
							{
								builder.Append(m_compareVal1);
							}
							break;
						}
					}
				}
				else
				{
					builder.Append(GetFilterCompareToString(m_compareTo));
				}

				System.Diagnostics.Debug.WriteLine(builder.ToString());

				return builder.ToString();
			}
		}

		public bool			MatchesFilter(object obj)
		{
			// Get the primary value of the object
			decimal			primaryVal = 0m;
			IFilterable		filterObj = obj as IFilterable;
			bool			match = false;

			//mam 07072011
			string primaryValString = string.Empty;

			if (filterObj == null)
				return false;

			// Make sure that the LH value is valid
			if (!filterObj.IsLHValueValid(m_filterSource))
				return false;

			//mam 07072011 - filtering by asset class or planning mode
			bool isAssetClass = false;
			if ((UnitFilter.FilterSource)m_filterSource == UnitFilter.FilterSource.AssetClass
				|| (UnitFilter.FilterSource)m_filterSource == UnitFilter.FilterSource.CipMode)
			{
				isAssetClass = true;
				primaryValString = filterObj.GetLHValueString(m_filterSource);
			}
			else
			{
				primaryVal = filterObj.GetLHValue(m_filterSource);
			}

			if (m_compareTo != FilterCompareTo.Value)
			{
				// Make sure that the RH value is valid
				if (!filterObj.IsRHValueValid(m_compareTo))
					return false;

				decimal		secondaryVal = filterObj.GetRHValue(m_compareTo);

				// Perform the correct operation
				switch (m_operator)
				{
					case FilterOperator.GT:
						match = (primaryVal > secondaryVal);
						break;
					case FilterOperator.GTE:
						match = (primaryVal >= secondaryVal);
						break;
					case FilterOperator.LT:
						match = (primaryVal < secondaryVal);
						break;
					case FilterOperator.LTE:
						match = (primaryVal <= secondaryVal);
						break;
					case FilterOperator.Equals:
						match = (primaryVal == secondaryVal);
						break;
					// These operators not applicable with a direct field comparison
					case FilterOperator.Between:
					case FilterOperator.OutsideOf:
						match = false;
						break;
				}
			}
			else // Compare to the stored comparison values
			{
				if (isAssetClass)
				{
					switch (m_operator)
					{
						case FilterOperator.Equals:
							match = string.Compare(primaryValString, m_compareVal1String, true) == 0;
							break;
						case FilterOperator.NotEquals:
							match = string.Compare(primaryValString, m_compareVal1String, true) != 0;
							break;
					}
				}
				else
				{
					// Perform the correct operation
					switch (m_operator)
					{
						case FilterOperator.GT:
							match = (primaryVal > m_compareVal1);
							break;
						case FilterOperator.GTE:
							match = (primaryVal >= m_compareVal1);
							break;
						case FilterOperator.LT:
							match = (primaryVal < m_compareVal1);
							break;
						case FilterOperator.LTE:
							match = (primaryVal <= m_compareVal1);
							break;
						case FilterOperator.Equals:
						{
							match = (primaryVal == m_compareVal1);
							break;
						}
						case FilterOperator.Between:
							match = (primaryVal >= m_compareVal1 && primaryVal <= m_compareVal2);
							break;
						case FilterOperator.OutsideOf:
							//mam - changed this to be OR rather than AND.
							//	Although this works with the AND, it only works if the user enters a larger value in the
							//	first text box, and a smaller value in the second text box.  This seems counterintuitive, 
							//	especially since the Between operator calls for entering the smaller value in the first box,
							//	and the larger value in the second box
							//match = (primaryVal < m_compareVal1 && primaryVal > m_compareVal2);
							match = (primaryVal < m_compareVal1 || primaryVal > m_compareVal2);
							//</mam>
							break;
					}
				}
			}

			return match;
		}

		#endregion / ***** Comparison ***** /
	}
}