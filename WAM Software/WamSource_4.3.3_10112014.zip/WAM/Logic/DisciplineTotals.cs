using System;
using WAM.Data;

namespace WAM.Logic
{
	/// <summary>
	/// Summary description for DisciplineTotals.
	/// </summary>
	public class DisciplineTotals
	{
		int					m_infoSetID = 0;
		int					m_componentID = 0;

		public DisciplineTotals(MajorComponent component)
		{
			m_componentID = component.ID;
			m_infoSetID = component.InfoSetID;

			if (m_componentID != 0)
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
		}

		public Discipline[] GetDisciplines()
		{
			return CacheManager.GetDisciplines(m_infoSetID, m_componentID);
		}

		public int			ComponentID
		{
			get { return m_componentID; }
			set { m_componentID = value; }
		}

		public decimal		GetTotalOrgCost()
		{
			decimal			sumOrgCost = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				sumOrgCost += disciplines[pos].GetDisciplineCost();
			}

			return sumOrgCost;
		}

		public decimal		GetTotalCurrentValue()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].GetCurrentValue();
			}

			return total;
		}

		public decimal		GetTotalAcquisitionCost()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].AcquisitionCost;
			}

			return total;
		}

		//mam 091607 - new method
		public decimal		GetTotalAcquisitionCostRoundIndividualValues()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += Math.Round(disciplines[pos].AcquisitionCost, 0);
			}

			return total;
		}

		//mam 050806
		public decimal		GetTotalAcquisitionCostEscalated()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].AcquisitionCostEscalated;
			}

			return total;
		}

		public decimal		GetTotalReplacementValue()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].ReplacementValue;
			}

			return total;
		}

		//mam 050806
		public int GetAverageReplacementValueYear()
		{
			//decimal total = 0;
			int avgYear = 0;

			//mam 112806
			int discCount = 0;

			Discipline[] disciplines = CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			//Discipline discipline;
			//DisciplinePipe pipe;
			//DisciplineNode node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				//mam 112806 - add check for ReplacementValueYear = zero
				if (disciplines[pos] == null || disciplines[pos].ReplacementValueYear == 0)
					continue;

				discCount++;
				avgYear += disciplines[pos].ReplacementValueYear;
			}

			//mam 112806
			//return (int)(avgYear / disciplines.Length);
			//return disciplines.Length == 0 ? 0 : (int)(avgYear / disciplines.Length);

			//mam 112806 - use discCount rather than disciplines.Length
			return discCount == 0 ? 0 : (int)Math.Round((decimal)avgYear / discCount, 0);
		}

		//mam 050806
		public decimal		GetTotalRehabCost()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].RehabCost;
			}

			return total;
		}

		public decimal		GetTotalBookValue()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].GetBookValue();
			}

			return total;
		}

		public decimal		GetTotalSalvageValue()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].SalvageValue;
			}

			return total;
		}

		public decimal		GetTotalAnnualDepreciation()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].GetAnnualDepreciation();
			}

			return total;
		}

		public decimal		GetTotalCumulativeDepreciation()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].GetCumulativeDepreciation();
			}

			return total;
		}

		public decimal		GetTotalEvaluatedValue()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				//mam
				if (disciplines[pos].Type == DisciplineType.Land
					|| disciplines[pos].Type == DisciplineType.Mechanical
					|| disciplines[pos].Type == DisciplineType.Structural)
				{
					if (disciplines[pos].ConditionRanking != CondRank.No)
						total += disciplines[pos].GetEvaluatedValue();
				}
				else
				{
				//</mam>
					total += disciplines[pos].GetEvaluatedValue();
				}
			}

			return total;
		}

		public decimal		GetTotalRepairCost()
		{
			decimal			sumRepairs = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				//mam
				if (disciplines[pos].Type == DisciplineType.Land
					|| disciplines[pos].Type == DisciplineType.Mechanical
					|| disciplines[pos].Type == DisciplineType.Structural)
				{
					if (disciplines[pos].ConditionRanking != CondRank.No || disciplines[pos].OverrideRepairCost)
						sumRepairs += disciplines[pos].GetRepairCost();
				}
				else
				{
				//</mam>

					sumRepairs += disciplines[pos].GetRepairCost();
				}
			}

			return sumRepairs;
		}

		public decimal		GetTotalAnnualMaintCost()
		{
			decimal			total = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				total += disciplines[pos].AnnualMaintCost;
			}

			return total;
		}

		public double		GetCalcTotalCWP()
		{
			Discipline[]	disciplines = CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			double			total = 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//mam 091607 - use rounded values
			////decimal			currentValue = GetTotalCurrentValue();
			//decimal			currentValue = GetTotalAcquisitionCost();
			decimal			currentValue = GetTotalAcquisitionCostRoundIndividualValues();

			if (currentValue == 0)
				return 0.0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//mam 091607 - use rounded values
				//total += Math.Round(((double)(disciplines[pos].GetCurrentValue() / currentValue)) * 100.0, 1);
				total += Math.Round(((double)(disciplines[pos].AcquisitionCostRoundIndividualValues / currentValue)) * 100.0, 1);
			}

			return total;
		}

//		public double		GetRankPercent()
//		{
//			decimal			totalCurrentValue = GetTotalCurrentValue();
//			Discipline[]	disciplines = 
//				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
//			decimal			sumRankValues = 0m;
//			decimal			rankPercent = 0m;
//			bool			hasValidValue = false;
//
//			for (int pos = 0; pos < disciplines.Length; pos++)
//			{
//				if (disciplines[pos].ConditionRanking == CondRank.No || 
//					disciplines[pos].ConditionRanking == CondRank.C0)
//					continue;
//
//				//System.Windows.Forms.MessageBox.Show(disciplines[pos].Type.ToString());
//
//				hasValidValue = true;
//				sumRankValues += EnumHandlers.GetConditionRankValue(disciplines[pos].ConditionRanking) * 
//					disciplines[pos].GetCurrentValue();
//			}
//
//			// = (0.4021 * (((sum of (Condition Fraction * current value) / totalCurrentValue) * 100) ^ .5885)) + 1
//			if (totalCurrentValue != 0)
//			{
//				rankPercent = 0.4021M;
//				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);
//				rankPercent += 1m;
//				if (rankPercent > 5m)
//					rankPercent = 5m;
//			}
//
//			//mam - added the following code, because if totalCurrentValue = 0, 
//			//	there is not enough data to calculate the avg condition
//			else
//			{
//				hasValidValue = false;
//			}
//			//</mam>	
//
//			if (!hasValidValue)
//				return 0.0;
//
//			if (rankPercent < 1m)
//				rankPercent = 1m;
//
//			return (double)rankPercent;
//		}

		//mam - use an interpolated value for the Condition Rank value rather than the enumerated value
		public double		GetRankPercentInterpolated()
		{
			decimal			totalCurrentValue = GetTotalCurrentValue();
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			sumRankValues = 0m;
			decimal			rankPercent = 0m;
			bool			hasValidValue = false;

			//mam
			decimal avgCondition = 0;
			//</mam>

			for (int pos = 0; pos < disciplines.Length; pos++)
			{	
				if (disciplines[pos].ConditionRanking == CondRank.No || 
					disciplines[pos].ConditionRanking == CondRank.C0)
					continue;

				hasValidValue = true;
				if (disciplines[pos].Type == DisciplineType.Pipes || disciplines[pos].Type == DisciplineType.Nodes)
				{
					//mam - don't use rounding here
					//avgCondition = Math.Round((decimal)disciplines[pos].GetAverageConditionForInterpolatedRank(), 1);
					avgCondition = (decimal)disciplines[pos].GetAverageConditionForInterpolatedRank();
					avgCondition = (avgCondition - 1m) / 0.4021m;
					avgCondition = (decimal)Math.Pow((double)avgCondition, (double)(1 / 0.5885m));

					//added m to 100, but it doesn't change the calculation
					//sumRankValues += avgCondition * disciplines[pos].GetCurrentValue() / 100;
					sumRankValues += avgCondition * disciplines[pos].GetCurrentValue() / 100m;

					//decimal testValue1 = avgCondition * disciplines[pos].GetCurrentValue() / 100;
					//decimal testValue2 = avgCondition * disciplines[pos].GetCurrentValue() / 100m;
				}
				else
				{
					sumRankValues += EnumHandlers.GetConditionRankValue(disciplines[pos].ConditionRanking) * 
						disciplines[pos].GetCurrentValue();
				}
			}

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				rankPercent += 1m;
				if (rankPercent > 5m)
					rankPercent = 5m;
			}

			//mam - added the following code, because if totalCurrentValue = 0, 
			//	there is not enough data to calculate the avg condition
			else
			{
				hasValidValue = false;
			}
			//</mam>	

			if (!hasValidValue)
				return 0.0;

			if (rankPercent < 1m)
				rankPercent = 1m;

			return (double)rankPercent;
		}
		//</mam>

		//mam - need a way to get only pipes or only nodes for graphing
		public double		GetRankPercentInterpolated(bool pipesOnly, bool nodesOnly)
		{
			decimal			totalCurrentValue = GetTotalCurrentValue();
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			sumRankValues = 0m;
			decimal			rankPercent = 0m;
			bool			hasValidValue = false;

			//mam
			decimal avgCondition = 0;
			//</mam>

			for (int pos = 0; pos < disciplines.Length; pos++)
			{	
				if (disciplines[pos].ConditionRanking == CondRank.No || 
					disciplines[pos].ConditionRanking == CondRank.C0)
					continue;

				hasValidValue = true;
				if (disciplines[pos].Type == DisciplineType.Pipes || disciplines[pos].Type == DisciplineType.Nodes)
				{
					if ((disciplines[pos].Type == DisciplineType.Pipes && pipesOnly) 
						|| (disciplines[pos].Type == DisciplineType.Nodes && nodesOnly)
						|| (!pipesOnly && !nodesOnly))
					{
						if (disciplines[pos].GetCurrentValue() != 0)
						{
							if (disciplines[pos].Type == DisciplineType.Pipes)
								if (disciplines[pos].GetAllConditionNA((DisciplinePipe)disciplines[pos]))
									continue;
							if (disciplines[pos].Type == DisciplineType.Nodes)
								if (disciplines[pos].GetAllConditionNA((DisciplineNode)disciplines[pos]))
									continue;

							//mam - don't use rounding here
							//avgCondition = Math.Round((decimal)disciplines[pos].GetAverageConditionForInterpolatedRank(), 1);
							avgCondition = (decimal)disciplines[pos].GetAverageConditionForInterpolatedRank();
							avgCondition = (avgCondition - 1m) / 0.4021m;
							avgCondition = (decimal)Math.Pow((double)avgCondition, (double)(1 / 0.5885m));

							//added m to 100, but it doesn't change the calculation
							//sumRankValues += avgCondition * disciplines[pos].GetCurrentValue() / 100;
							sumRankValues += avgCondition * disciplines[pos].GetCurrentValue() / 100m;

							//decimal testValue1 = avgCondition * disciplines[pos].GetCurrentValue() / 100;
							//decimal testValue2 = avgCondition * disciplines[pos].GetCurrentValue() / 100m;
						}
					}
				}
				else
				{
					sumRankValues += EnumHandlers.GetConditionRankValue(disciplines[pos].ConditionRanking) * 
						disciplines[pos].GetCurrentValue();
				}
			}

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				//mam - this is for graphing, so don't bump up the value to 1 if value = 0
				if (rankPercent != 0)
					rankPercent += 1m;

				if (rankPercent > 5m)
					rankPercent = 5m;
			}

			//mam - added the following code, because if totalCurrentValue = 0, 
			//	there is not enough data to calculate the avg condition
			else
			{
				hasValidValue = false;
			}
			//</mam>	

			if (!hasValidValue)
				return 0.0;

			//mam - this is for graphing, so don't bump up the value to 1 if value = 0
			if (rankPercent != 0)
				if (rankPercent < 1m)
					rankPercent = 1m;

			return (double)rankPercent;
		}
		//</mam>

		public double		GetTotalOrgUsefulLife()
		{
			double			sumULOrg = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			totalCurrentValue = GetTotalCurrentValue();
			double			calcCWP;

			if (totalCurrentValue == 0)
				return 0.0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;

				calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
					totalCurrentValue);

				sumULOrg += (calcCWP * 
					disciplines[pos].OrgUsefulLife);
			}

			return Math.Round(sumULOrg, 1);
		}

		public double		GetTotalRemainingUsefulLife()
		{
			double			sumULBook = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			totalCurrentValue = GetTotalCurrentValue();
			double			calcCWP;

			if (totalCurrentValue == 0)
				return 0.0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;

				calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
					totalCurrentValue);

				sumULBook += (calcCWP * 
					disciplines[pos].GetRemainingUsefulLife());
			}

			return Math.Round(sumULBook, 1);
		}

		public double		GetTotalEvaluatedRemainingUsefulLife()
		{
			double			sumULEval = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			totalCurrentValue = GetTotalCurrentValue();
			double			calcCWP;

			if (totalCurrentValue == 0)
				return 0.0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;

				//mam
				if (disciplines[pos].Type == DisciplineType.Land
					|| disciplines[pos].Type == DisciplineType.Mechanical
					|| disciplines[pos].Type == DisciplineType.Structural)
				{
					if (disciplines[pos].ConditionRanking != CondRank.No)
					{
						calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
							totalCurrentValue);

						sumULEval += (calcCWP * 
							disciplines[pos].GetEvaluatedRemainingUsefulLife());
					}

				}
				else
				{
				//</mam>

					calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
						totalCurrentValue);

					sumULEval += (calcCWP * 
						disciplines[pos].GetEvaluatedRemainingUsefulLife());
				}
			}

			return Math.Round(sumULEval, 1);
		}

		//mam
		public double		GetTotalEconomicUsefulLife()
		{
			double			sumULEcon = 0;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(m_infoSetID, m_componentID);
			decimal			totalCurrentValue = GetTotalCurrentValue();
			double			calcCWP;

			if (totalCurrentValue == 0)
				return 0.0;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;

				if (disciplines[pos].Type == DisciplineType.Land
					|| disciplines[pos].Type == DisciplineType.Mechanical
					|| disciplines[pos].Type == DisciplineType.Structural)
				{
					if (disciplines[pos].ConditionRanking != CondRank.No)
					{
						calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
							totalCurrentValue);

						sumULEcon += (calcCWP * 
							disciplines[pos].GetEconomicUsefulLife());
					}

				}
				else
				{

					calcCWP = (double)(disciplines[pos].GetCurrentValue() / 
						totalCurrentValue);

					sumULEcon += (calcCWP * 
						disciplines[pos].GetEconomicUsefulLife());
				}
			}

			return Math.Round(sumULEcon, 1);
		}
		//</mam>

		//mam - change this to divide CV by TCV rather than get CWPAssetValue?
		//mam - just leave it as is
		public double		GetTotalCWPValue()
		{
			double			sumCWP = 0;
			Discipline[]	disciplines = CacheManager.GetDisciplines(m_infoSetID, m_componentID);

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				if (disciplines[pos] == null)
					continue;
				sumCWP += (disciplines[pos].CWPAssetValue);
			}

			return sumCWP;
		}

		public bool CheckIfAllNADiscipline(int curInfosetID, int curComponentID)
		{
			bool AllNA = true;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(curInfosetID, curComponentID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;
			
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllConditionNA())
						AllNA = false;
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllConditionNA())
						AllNA = false;
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					if (discipline.ConditionRanking != CondRank.No)
					{
						AllNA = false;
						break;
					}
				}
			}

			return AllNA;
		}

		public bool CheckIfAllNAVulnerability(int curInfosetID, int curComponentID)
		{
			bool AllNA = true;
			Discipline[]	disciplines = 
				CacheManager.GetDisciplines(curInfosetID, curComponentID);
			Discipline discipline;

			//CacheManager.GetPipeDataForDiscipline(m_infoSetID, ;
			//CacheManager.GetNodeDataForDiscipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;
			
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllERULZero() || pipe.GetAnyVulnerabilityOverridden())
						AllNA = false;
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllERULZero() || node.GetAnyVulnerabilityOverridden())
						AllNA = false;
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					AllNA = false;
					break;
				}
			}

			return AllNA;
		}
		//</mam>
	}
}
