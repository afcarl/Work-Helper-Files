using System;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for CompactJetDatabase.
	/// </summary>
	public class CompactJetDatabase
	{
		public CompactJetDatabase()
		{
		}

		public static bool CompactAccessDB(string connectionStringToCompact, string fileToCompact, string tempFileNameWithPathToCompactTo)
		{
			object objJRO = null;

			try
			{
				//System.Windows.Forms.MessageBox.Show("1 = " + connectionStringToCompact);
				//System.Windows.Forms.MessageBox.Show("2 = " + fileToCompact);
				//System.Windows.Forms.MessageBox.Show("3 = " + tempFileNameWithPathToCompactTo);

				object[] oParams;

				//create an instance of a Jet Replication Object
				objJRO = Activator.CreateInstance(Type.GetTypeFromProgID("JRO.JetEngine"));

				//filling Parameters array
				//change "Jet OLEDB:Engine Type=5" to an appropriate value or leave it as is if the database is JET4X format (access 2000, 2002)
				//(yes, jetengine5 is for JET4X - not a misprint)
				oParams = new object[] {
					connectionStringToCompact, string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password={0};Data Source={1};Jet OLEDB:Engine Type=5", 
										   WAM.Common.Globals.AccessPassword, tempFileNameWithPathToCompactTo)};

				//invoke a CompactDatabase method of a JRO object, and pass in parameters array
				objJRO.GetType().InvokeMember("CompactDatabase", System.Reflection.BindingFlags.InvokeMethod, null, objJRO, oParams);

				//the database has been compacted to a new file
				//remove the original database and rename the compacted file to the original database name
				//verify that the compacted file exists before deleting the original file
				if (!System.IO.File.Exists(tempFileNameWithPathToCompactTo))
					return false;

				System.IO.File.Delete(fileToCompact);
				System.IO.File.Move(tempFileNameWithPathToCompactTo, fileToCompact);

				//verify that the file has been renamed
				if (!System.IO.File.Exists(fileToCompact))
					return false;

				return true;
			}
			catch
			{
				return false;
			}
			finally
			{
				//clean up (just in case)
				System.Runtime.InteropServices.Marshal.ReleaseComObject(objJRO);
				objJRO=null;
			}
		}
	}
}
