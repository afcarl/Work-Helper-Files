using System;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for TreeViewItem.
	/// </summary>
	public class TreeViewItem
	{
		private int itemID;
		private int infoSetID;
		private int enumValue;
		private int nodeCount;
		private string itemDescription;
		private string itemTag = "";

		public TreeViewItem(int itemID, string itemDescription, int enumValue, string itemTag, int nodeCount, int infoSetID)
		{
			this.itemID = itemID;
			this.itemDescription = itemDescription;
			this.enumValue = enumValue;
			this.itemTag = itemTag;
			this.nodeCount = nodeCount;
			this.infoSetID = infoSetID;
		}

		public int ItemID
		{
			get
			{
				return itemID ;
			}
		}

		public int InfoSetID
		{
			get
			{
				return infoSetID ;
			}
		}

		public string ItemDescription
		{
			get
			{
				return itemDescription;
			}
		}

		public int EnumValue
		{
			get
			{
				return enumValue;
			}
		}

		public int NodeCount
		{
			get
			{
				return nodeCount;
			}
		}

		public string ItemTag
		{
			get
			{
				return itemTag;
			}
		}

		public override string ToString()
		{
			//return this.ItemID + " - " + this.ItemDescription;
			return this.itemTag;
		}
	}
}
