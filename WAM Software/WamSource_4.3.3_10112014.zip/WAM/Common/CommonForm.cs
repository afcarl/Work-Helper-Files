using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for CommonForm.
	/// </summary>
	public class CommonForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ImageList imageListTree;
		private System.Windows.Forms.ContextMenu mnuContextMenu;
		private System.Windows.Forms.MenuItem mnuItemSelectAll;
		private System.Windows.Forms.MenuItem mnuItemClearAll;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuItemSelectUnder;
		private System.Windows.Forms.MenuItem mnuItemClearUnder;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem mnuItemExpandAll;
		private System.Windows.Forms.MenuItem mnuItemCollapseAll;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem mnuItemView;
		private System.Windows.Forms.MenuItem mnuItemViewNormal;
		private System.Windows.Forms.MenuItem mnuItemViewSelected;
		private System.Windows.Forms.MenuItem mnuItemViewReport;
		private System.Windows.Forms.MenuItem mnuItemViewMainTree;
		private System.ComponentModel.IContainer components;

		public CommonForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CommonForm));
			this.imageListTree = new System.Windows.Forms.ImageList(this.components);
			this.mnuContextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuItemSelectAll = new System.Windows.Forms.MenuItem();
			this.mnuItemClearAll = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.mnuItemSelectUnder = new System.Windows.Forms.MenuItem();
			this.mnuItemClearUnder = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.mnuItemExpandAll = new System.Windows.Forms.MenuItem();
			this.mnuItemCollapseAll = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.mnuItemView = new System.Windows.Forms.MenuItem();
			this.mnuItemViewNormal = new System.Windows.Forms.MenuItem();
			this.mnuItemViewSelected = new System.Windows.Forms.MenuItem();
			this.mnuItemViewReport = new System.Windows.Forms.MenuItem();
			this.mnuItemViewMainTree = new System.Windows.Forms.MenuItem();
			// 
			// imageListTree
			// 
			this.imageListTree.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTree.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTree.ImageStream")));
			this.imageListTree.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// mnuContextMenu
			// 
			this.mnuContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.mnuItemSelectAll,
																						   this.mnuItemClearAll,
																						   this.menuItem3,
																						   this.mnuItemSelectUnder,
																						   this.mnuItemClearUnder,
																						   this.menuItem6,
																						   this.mnuItemExpandAll,
																						   this.mnuItemCollapseAll,
																						   this.menuItem9,
																						   this.mnuItemView});
			// 
			// mnuItemSelectAll
			// 
			this.mnuItemSelectAll.Index = 0;
			this.mnuItemSelectAll.Text = "&Select All";
			// 
			// mnuItemClearAll
			// 
			this.mnuItemClearAll.Index = 1;
			this.mnuItemClearAll.Text = "&Clear All";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "-";
			// 
			// mnuItemSelectUnder
			// 
			this.mnuItemSelectUnder.Index = 3;
			this.mnuItemSelectUnder.Text = "Select all items under";
			// 
			// mnuItemClearUnder
			// 
			this.mnuItemClearUnder.Index = 4;
			this.mnuItemClearUnder.Text = "Clear all items under";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "-";
			// 
			// mnuItemExpandAll
			// 
			this.mnuItemExpandAll.Index = 6;
			this.mnuItemExpandAll.Text = "E&xpand All";
			// 
			// mnuItemCollapseAll
			// 
			this.mnuItemCollapseAll.Index = 7;
			this.mnuItemCollapseAll.Text = "C&ollapse All";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 8;
			this.menuItem9.Text = "-";
			// 
			// mnuItemView
			// 
			this.mnuItemView.Index = 9;
			this.mnuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.mnuItemViewNormal,
																						this.mnuItemViewSelected,
																						this.mnuItemViewReport,
																						this.mnuItemViewMainTree});
			this.mnuItemView.Text = "View";
			// 
			// mnuItemViewNormal
			// 
			this.mnuItemViewNormal.Checked = true;
			this.mnuItemViewNormal.Index = 0;
			this.mnuItemViewNormal.Text = "User View";
			// 
			// mnuItemViewSelected
			// 
			this.mnuItemViewSelected.Index = 1;
			this.mnuItemViewSelected.Text = "Selected items only";
			// 
			// mnuItemViewReport
			// 
			this.mnuItemViewReport.Index = 2;
			this.mnuItemViewReport.Text = "Report Type items only";
			// 
			// mnuItemViewMainTree
			// 
			this.mnuItemViewMainTree.Index = 3;
			this.mnuItemViewMainTree.Text = "Same as Main Data Tree";
			// 
			// CommonForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "CommonForm";
			this.Text = "CommonForm";

		}
		#endregion
	}
}
