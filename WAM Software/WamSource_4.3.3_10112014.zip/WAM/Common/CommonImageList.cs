using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for CommonImageList.
	/// </summary>
	public class CommonImageList : System.Windows.Forms.Form
	{
		public System.Windows.Forms.ImageList imageListTreeMain;
		public System.Windows.Forms.ImageList imageListTreeReport;
		private System.ComponentModel.IContainer components;

		public CommonImageList()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CommonImageList));
			this.imageListTreeMain = new System.Windows.Forms.ImageList(this.components);
			this.imageListTreeReport = new System.Windows.Forms.ImageList(this.components);
			// 
			// imageListTreeMain
			// 
			this.imageListTreeMain.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTreeMain.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTreeMain.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTreeMain.ImageStream")));
			this.imageListTreeMain.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// imageListTreeReport
			// 
			this.imageListTreeReport.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
			this.imageListTreeReport.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListTreeReport.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListTreeReport.ImageStream")));
			this.imageListTreeReport.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// CommonImageList
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "CommonImageList";
			this.Text = "CommonImageList";

		}
		#endregion
	}
}
