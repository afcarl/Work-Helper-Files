using System;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Update1.
	/// </summary>
	public class Update1
	{
		private int keyCount = 0;
		private int indexCount = 0;
		private string useConnectionString;

		public Update1(string connectionString)
		{
			useConnectionString = connectionString;
		}

		public bool PerformUpdate()
		{
			//mam - perform database updates
			try
			{
				//mam 102309 - using Update1 only for importing Access database data - don't update enr data
				//UpdateENRValue();
				//UpdateENRValue2004();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateReportTemplate();
			}
			catch
			{
				//return false;
			}

			//let's not use the Preference table, as it will cause problems if we ever have multiple users
			//resultUpdate = update1.UpdatePreference();

			try
			{
				UpdateReportTemplate2();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateReportTemplate3();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateVulnerability();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateFieldSheet();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateCurrentValue();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateInfoSet();
			}
			catch
			{
				//return false;
			}

			try
			{
				//mam 102309 - no longer using DatabaseInfo table after switch to SQL Server
				//UpdateDatabaseInfo();
			}
			catch
			{
				//return false;
			}

			try
			{
				UpdateReportTemplateDecimal();
			}
			catch
			{
			}

			return true;

			//</mam>
		}

		#region /***** UpdateENRValue2003 *****/

		//mam 102309 - using Update1 only for importing Access database data - don't update enr data

//		public bool UpdateENRValue()
//		{
//			OleDbCommand	sqlCommand = null;
//			OleDbDataReader	dataReader = null;
//
//			int curENRValue2003 = 0;
//			bool hasENRValue = false;
//			bool returnValue = true;
//			string connectionStringENR = WAM.Data.WAMSource.ENRSource.ConnectionString;
//
//			string querySqlString = "SELECT enr_value FROM ENR20Cities WHERE enr_year = 2003";
//			//string updateSqlString = "UPDATE ENR20Cities SET enr_value = 6694 WHERE enr_year = 2003";
//			string insertSqlString = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2003, 6694)";
//
//			//check whether the year 2003 already exists in ENR20Cities table
//
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionStringENR);
//			OleDbCommand	dataCommand = null;
//
//			try
//			{
//				sqlConnection.Open();
//
//				dataCommand = new OleDbCommand(querySqlString, sqlConnection);
//				dataReader = dataCommand.ExecuteReader();
//
//				if (dataReader == null)
//					System.Windows.Forms.MessageBox.Show("dataReader is null");
//
//				while (dataReader.Read())
//				{
//					curENRValue2003 = (int)dataReader.GetValue(0);
//					hasENRValue	 = true;
//					break;
//				}
//				if (dataReader != null && !dataReader.IsClosed)
//					dataReader.Close();
//
//				if (!hasENRValue)
//				{
//					sqlCommand = new OleDbCommand(insertSqlString, sqlConnection);
//					sqlCommand.ExecuteNonQuery();
//				}
//			}
//			catch (OleDbException ex)
//			{
//				returnValue = false;
//				System.Diagnostics.Trace.WriteLine(
//					String.Format("Update1.UpdateENRValue Error: {0}\n", ex.Message));
//				//System.Diagnostics.Debug.Assert(false, ex.Message);
//			}
//			finally
//			{
//				if (dataReader != null && !dataReader.IsClosed)
//					dataReader.Close();
//
//				sqlConnection.Dispose();
//			}
//
//			return returnValue;
//		}

		#endregion /***** UpdateENRValue2003 *****/

		#region /***** UpdateReportTemplateTables *****/

		private int NextKey()
		{
			keyCount += 1;
			return keyCount;
		}

		private int NextIndex()
		{
			indexCount += 1;
			return indexCount;
		}

		public bool UpdateReportTemplate()
		{
			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			DataTable dataTable = dataAccess.GetTables("ReportTemplateNodesExpanded", useConnectionString);
			ArrayList resultLogTemplate = new ArrayList();
			bool result = false;

			resultLogTemplate.Add("Report Template update not attempted");

			if (dataTable == null)
			{
				//the table doesn't exist, so attempt to create the report template tables

				resultLogTemplate.Clear();

				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
					return false;

				StringBuilder builder = new StringBuilder(200);

				//****

				// create FilterReportLevel table
				try
				{
					resultLogTemplate.Add("Table FilterReportLevel start");

					builder.Append(@"CREATE TABLE FilterReportLevel (FilterReportLevelID LONG NOT NULL PRIMARY KEY,");
					builder.Append(" FilterReportLevel VARCHAR (50) WITH COMPRESSION NOT NULL,");
					builder.Append(" FilterReportLevelText VARCHAR (100) WITH COMPRESSION NOT NULL, SortBy INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();
					
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON FilterReportLevel (SortBy)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE FilterReportLevel ALTER COLUMN FilterReportLevelID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE FilterReportLevel ALTER COLUMN SortBy SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table FilterReportLevel not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table FilterReportLevel stop");
				}

				//****

				// create ReportTemplate table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplate start");

					builder.Append(@"CREATE TABLE ReportTemplate (ReportTemplateID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, InfoSetID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES InfoSets (infoset_id) ON UPDATE	CASCADE ON DELETE CASCADE, ReportType LONG NOT NULL,");
					builder.Append(" TemplateName VARCHAR (100) WITH COMPRESSION NOT NULL, ApplyFilter LONG, FilterOn INTEGER, MatchAny INTEGER,");
					builder.Append(" IncludePhotos INTEGER, DataTreeOrder INTEGER, SortBy1 INTEGER, SortBy2 INTEGER, SortBy3 INTEGER, SortBy4 INTEGER, SortBy5 INTEGER,");
					builder.Append(" Ascending1 INTEGER, Ascending2 INTEGER, Ascending3 INTEGER, Ascending4 INTEGER, Ascending5 INTEGER, SortBy INTEGER,");
					builder.Append(" UserName VARCHAR (50) WITH COMPRESSION, UserPassword VARCHAR (50) WITH COMPRESSION)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplate (InfoSetID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplate (SortBy)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN InfoSetID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN ReportType SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN ApplyFilter SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN FilterOn SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN MatchAny SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN IncludePhotos SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN DataTreeOrder SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy1 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy2 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy3 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy4 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy5 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending1 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending2 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending3 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending4 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending5 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplate not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplate stop");
				}

				//****

				// create ReportTemplateFilter table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateFilter start");

					builder.Append(@"CREATE TABLE ReportTemplateFilter (ReportTemplateFilterID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" ApplyFilter LONG, FilterSource LONG, FilterOperator LONG, FilterCompare LONG,");
					builder.Append(" FilterTextCompare1 DECIMAL, FilterTextCompare2 DECIMAL)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateFilter (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN ApplyFilter SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterSource SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterOperator SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterCompare SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare1 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare2 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateFilter not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateFilter stop");
				}

				//****

				// create ReportTemplateNodesCheckedAsset table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedAsset start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedAsset (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ComponentAssets (compasset_id) ON UPDATE CASCADE ON DELETE CASCADE)");
					
					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedAsset (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedAsset ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedAsset ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedAsset not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedAsset stop");
				}

				//****

				// create ReportTemplateNodesCheckedComp table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedComp start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedComp (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES MajorComponents (component_id) ON UPDATE CASCADE ON DELETE CASCADE)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedComp (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedComp ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedComp ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedComp not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedComp stop");
				}

				//****

				// create ReportTemplateNodesCheckedFac table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedFac start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedFac (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES Facilities (facility_id) ON UPDATE CASCADE ON DELETE CASCADE)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedFac (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedFac ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedFac ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedFac not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedFac stop");
				}

				//****

				// create ReportTemplateNodesCheckedProc table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedProc start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedProc (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES TreatmentProcesses (process_id) ON UPDATE CASCADE ON DELETE CASCADE)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedProc (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedProc ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedProc ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedProc not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedProc stop");
				}

				//****

				// create ReportTemplateNodesCheckedDiscLand table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscLand start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedDiscLand (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES DisciplineLand (disc3_id) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" DiscAll INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscLand (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscLand (DiscAll)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscLand ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscLand ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscLand ALTER COLUMN DiscAll SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscLand not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscLand stop");
				}

				//****

				// create ReportTemplateNodesCheckedDiscMech table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscMech start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedDiscMech (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES DisciplineMech (disc1_id) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" DiscAll INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscMech (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscMech (DiscAll)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscMech ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscMech ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscMech ALTER COLUMN DiscAll SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscMech not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscMech stop");
				}

				//****

				// create ReportTemplateNodesCheckedDiscStruct table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscStruct start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedDiscStruct (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES DisciplineStruct (disc2_id) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" DiscAll INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscStruct (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscStruct (DiscAll)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscStruct ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscStruct ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscStruct ALTER COLUMN DiscAll SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscStruct not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscStruct stop");
				}

				//****

				// create ReportTemplateNodesCheckedDiscNode table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscNode start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedDiscNode (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES DisciplineNodes (discnode_id) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" DiscAll INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscNode (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscNode (DiscAll)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscNode ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscNode ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscNode ALTER COLUMN DiscAll SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscNode not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscNode stop");
				}

				//****

				// create ReportTemplateNodesCheckedDiscPipe table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscPipe start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesCheckedDiscPipe (ReportTemplateNodesCheckedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES DisciplinePipes (discpipe_id) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" DiscAll INTEGER)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscPipe (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesCheckedDiscPipe (DiscAll)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscPipe ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscPipe ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesCheckedDiscPipe ALTER COLUMN DiscAll SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscPipe not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesCheckedDiscPipe stop");
				}

				//****

				// create ReportTemplateNodesExpanded table
				try
				{
					builder.Remove(0, builder.Length);
					resultLogTemplate.Add("Table ReportTemplateNodesExpanded start");

					builder.Append(@"CREATE TABLE ReportTemplateNodesExpanded (ReportTemplateNodesExpandedID IDENTITY(1,1) CONSTRAINT Key"); 
					builder.Append(NextKey());
					builder.Append(" PRIMARY KEY, ReportTemplateID LONG NOT NULL CONSTRAINT Key");
					builder.Append(NextKey());
					builder.Append(" REFERENCES ReportTemplate (ReportTemplateID) ON UPDATE CASCADE ON DELETE CASCADE,");
					builder.Append(" NodeID LONG NOT NULL)");

					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ReportTemplateNodesExpanded (ReportTemplateID) WITH DISALLOW NULL";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesExpanded ALTER COLUMN ReportTemplateID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplateNodesExpanded ALTER COLUMN NodeID SET DEFAULT 0";
					cmd.ExecuteNonQuery();
				}
				catch
				{
					resultLogTemplate.Add("Table ReportTemplateNodesExpanded not completed");
				}
				finally
				{
					resultLogTemplate.Add("Table ReportTemplateNodesExpanded stop");
				}

				cmd = null;

				//*******************************************************
				//DATA POPULATION

				//populate the FilterReportLevel table
				// note: should get these values from the enum

				//DataTable dataTable = dataAccess.GetTables("FilterReportLevel");
				dataTable = dataAccess.GetTables("FilterReportLevel", useConnectionString);
				if (dataTable != null)
				{
					DataSet dataSet = new DataSet();
					string queryString = @"SELECT * FROM FilterReportLevel";
					dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
					if (dataSet == null)
					{
						throw new Exception("Database Error.  Update1.UpdateReportTemplate.Population");
					}

					if (dataSet.Tables[0].Rows.Count > 0)
					{
						resultLogTemplate.Add("Data Population Table FilterReportLevel not completed - table already has data");
						return true;
					}

					DataRow dataRow;

					try
					{
						resultLogTemplate.Add("Data Population Table FilterReportLevel start");

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 0;
						dataRow["FilterReportLevel"] = "Facility";
						dataRow["FilterReportLevelText"] = "Facility / System";
						dataRow["SortBy"] = 0;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 1;
						dataRow["FilterReportLevel"] = "TreatmentProcess";
						dataRow["FilterReportLevelText"] = "Process / Basin / Zone";
						dataRow["SortBy"] = 1;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 2;
						dataRow["FilterReportLevel"] = "MajorComponent";
						dataRow["FilterReportLevelText"] = "Component / Subbasin / Subzone";
						dataRow["SortBy"] = 2;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 3;
						dataRow["FilterReportLevel"] = "Discipline";
						dataRow["FilterReportLevelText"] = "Discipline: All";
						dataRow["SortBy"] = 3;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 4;
						dataRow["FilterReportLevel"] = "DisciplineMech";
						dataRow["FilterReportLevelText"] = "Discipline: Mech / Elec / Instr / Piping";
						dataRow["SortBy"] = 4;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 5;
						dataRow["FilterReportLevel"] = "DisciplineStruct";
						dataRow["FilterReportLevelText"] = "Discipline: Struct / Arch";
						dataRow["SortBy"] = 5;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 6;
						dataRow["FilterReportLevel"] = "DisciplineLand";
						dataRow["FilterReportLevelText"] = "Discipline: Site / Land / Other";
						dataRow["SortBy"] = 6;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 7;
						dataRow["FilterReportLevel"] = "DisciplinePipe";
						dataRow["FilterReportLevelText"] = "Discipline: Pipes";
						dataRow["SortBy"] = 7;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 8;
						dataRow["FilterReportLevel"] = "DisciplineNode";
						dataRow["FilterReportLevelText"] = "Discipline: Nodes / Appurtenances";
						dataRow["SortBy"] = 8;
						dataSet.Tables[0].Rows.Add(dataRow);

						//DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["FilterReportLevelID"] = 9;
						dataRow["FilterReportLevel"] = "ComponentAsset";
						dataRow["FilterReportLevelText"] = "Asset List";
						dataRow["SortBy"] = 9;
						dataSet.Tables[0].Rows.Add(dataRow);

						result = dataAccess.UpdateDatabase(dataSet, queryString, useConnectionString);
						if (!result)
							resultLogTemplate.Add("Data Population Table FilterReportLevel not completed");
					}
					catch
					{
						resultLogTemplate.Add("Data Population Table FilterReportLevel not completed");
					}
					finally
					{
						resultLogTemplate.Add("Data Population Table FilterReportLevel stop");
					}
				}

				//*******************************************************
			}

			dataTable = null;
			dataAccess = null;

			return true;
		}

		public bool UpdateReportTemplate2()
		{
			// UpdateReportTemplate2 adds the extra two sortby fields to the ReportTemplate table, 
			// and populates them with zeroes

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			DataTable dataTable = dataAccess.GetTables("ReportTemplate", useConnectionString);
			ArrayList resultLogTemplate2 = new ArrayList();
			//bool result = false;

			resultLogTemplate2.Add("Report Template update2 not attempted");

			if (dataTable != null)
			{
				//the table exists, so attempt to add the fields

				resultLogTemplate2.Clear();

				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
					return false;

				//StringBuilder builder = new StringBuilder(200);

				//****

				// add fields to ReportTemplate table
				try
				{
					resultLogTemplate2.Add("Table ReportTemplate start");

					cmd.CommandText = @"ALTER TABLE ReportTemplate ADD COLUMN SortBy4 INTEGER";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ADD COLUMN SortBy5 INTEGER";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ADD COLUMN Ascending4 INTEGER";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ADD COLUMN Ascending5 INTEGER";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy4 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN SortBy5 SET DEFAULT 0";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending4 SET DEFAULT 1";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending5 SET DEFAULT 1";
					cmd.ExecuteNonQuery();

					//*******************************************************
					//DATA POPULATION

					cmd.CommandText = @"UPDATE ReportTemplate SET SortBy4 = 0 WHERE isnull(SortBy4)";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"UPDATE ReportTemplate SET SortBy5 = 0 WHERE isnull(SortBy5)";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"UPDATE ReportTemplate SET Ascending4 = 1 WHERE isnull(Ascending4)";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"UPDATE ReportTemplate SET Ascending5 = 1 WHERE isnull(Ascending5)";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending1 SET DEFAULT 1";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending2 SET DEFAULT 1";
					cmd.ExecuteNonQuery();
					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN Ascending3 SET DEFAULT 1";
					cmd.ExecuteNonQuery();

					//*******************************************************
				}
				catch
				{
					resultLogTemplate2.Add("Table ReportTemplate not completed");
				}
				finally
				{
					resultLogTemplate2.Add("Table ReportTemplate stop");
				}

				//****

				cmd = null;
			}

			dataTable = null;
			dataAccess = null;

			return true;
		}

		public bool UpdateReportTemplate3()
		{
			// UpdateReportTemplate3 adds the ReportFormat field and populates it with zeroes

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			DataTable dataTable = dataAccess.GetTables("ReportTemplate", useConnectionString);
			ArrayList resultLogTemplate3 = new ArrayList();
			//bool result = false;

			resultLogTemplate3.Add("Report Template update not attempted");

			if (dataTable != null)
			{
				//the table exists, so attempt to add the fields

				resultLogTemplate3.Clear();

				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
					return false;

				//StringBuilder builder = new StringBuilder(200);

				//****

				// add fields to ReportTemplate table
				try
				{
					resultLogTemplate3.Add("Table ReportTemplate start");

					cmd.CommandText = @"ALTER TABLE ReportTemplate ADD COLUMN ReportFormat INTEGER";
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN ReportFormat SET DEFAULT 0";
					cmd.ExecuteNonQuery();

					//*******************************************************
					//DATA POPULATION

					cmd.CommandText = @"UPDATE ReportTemplate SET ReportFormat = 0 WHERE isnull(ReportFormat)";
					cmd.ExecuteNonQuery();

					//*******************************************************
				}
				catch
				{
					resultLogTemplate3.Add("Table ReportTemplate not completed");
				}
				finally
				{
					resultLogTemplate3.Add("Table ReportTemplate stop");
				}

				//****

				cmd = null;
			}

			dataTable = null;
			dataAccess = null;

			return true;
		}

		#endregion /***** UpdateReportTemplateTables *****/

		#region /***** UpdateVulnerability *****/

		public bool UpdateVulnerability()
		{
			// UpdateVulnerability sets the MajorComponents, PipingComponents, and 
			//	NodeAppurtComponents tables for the changes to Vulnerability

			//MajorComponents:		Add field COPYcomponent_vulnerability (byte)
			//						Populate field with contents of component_vulnerability
			//						Change component_vulnerability from byte to double
			//						Populate component_vulnerability with probabilities based on COPYcomponent_vulnerability enum values

			//PipingComponents:		Add field COPYpipe_vulnerability (byte)
			//						Populate field with contents of pipe_vulnerability
			//						Add field pipe_vulnerability2 (double)
			//						Populate pipe_vulnerability2 with probabilities based on COPYpipe_vulnerability enum values

			//NodeAppurtComponents:	Add field COPYnode_vulnerability (byte)
			//						Populate field with contents of node_vulnerability
			//						Add field node_vulnerability2 (double)
			//						Populate node_vulnerability2 with probabilities based on COPYnode_vulnerability enum values

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			//DataTable dataTable = dataAccess.GetTables("MajorComponents");
			DataTable dataTable = dataAccess.GetFields("MajorComponents", useConnectionString);
			ArrayList resultLogVulnerability = new ArrayList();
			//bool result = false;
			//bool fieldFound = false;

			resultLogVulnerability.Add("Vulnerability MajorComponents not attempted");

			if (dataTable != null)
			{
				//the table exists, so attempt to change the data type

				resultLogVulnerability.Clear();

				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
					return false;

				//update the MajorComponents table
				try
				{
					resultLogVulnerability.Add("Vulnerability MajorComponents start");

					//fieldFound = false;
					for (int i = 0; i < dataTable.Rows.Count; i++) 
					{
						if (dataTable.Rows[i].ItemArray[3].ToString() == "component_vulnerability")
						{
							//fieldFound = true;

							//----------------------------------------
							//mam 102309 - the component_vulnerability field in one (or more) of the client databases
							//	is a long when it should be either a byte or a double - so just change it to a double.
							//	also, check for the existence of the COPYcomponent_vulnerability column to determine 
							//	whether to create it
 
							//change the field's data type to double
							int colType = (int)dataTable.Rows[i].ItemArray[11];
							bool colFound = false;
							cmd.CommandText = @"ALTER TABLE MajorComponents ALTER COLUMN component_vulnerability DOUBLE";
							cmd.ExecuteNonQuery();
							for (int z = 0; z < dataTable.Rows.Count; z++) 
							{
								if (dataTable.Rows[z].ItemArray[3].ToString() == "COPYcomponent_vulnerability")
								{
									colFound = true;
									break;
								}
							}
							//----------------------------------------

							//if field data type is byte
							//mam 102309
							//if ((int)dataTable.Rows[i].ItemArray[11] == 17)
							if (!colFound && (int)dataTable.Rows[i].ItemArray[11] == 17)
							{
								//before altering the field, copy it so we can go back to it, if necessary
								cmd.CommandText = @"ALTER TABLE MajorComponents ADD COLUMN COPYcomponent_vulnerability BYTE";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET COPYcomponent_vulnerability = component_vulnerability";
								cmd.ExecuteNonQuery();

								//change the field's data type from byte to double
								cmd.CommandText = @"ALTER TABLE MajorComponents ALTER COLUMN component_vulnerability DOUBLE";
								cmd.ExecuteNonQuery();

								//*******************************************************
								//DATA POPULATION

								//change the value to represent the probability, rather than the enumeration index
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.9 WHERE component_vulnerability = 0";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.7 WHERE component_vulnerability = 1";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.4 WHERE component_vulnerability = 2";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.2 WHERE component_vulnerability = 3";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.1 WHERE component_vulnerability = 4";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.05 WHERE component_vulnerability = 5";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.02 WHERE component_vulnerability = 6";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.01 WHERE component_vulnerability = 7";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE MajorComponents SET component_vulnerability = 0.0067 WHERE component_vulnerability = 8";
								cmd.ExecuteNonQuery();
								//*******************************************************
							}
							//MessageBox.Show(dataTable.Rows[i].ItemArray[3].ToString());
							//MessageBox.Show(dataTable.Rows[i].ItemArray[11].ToString());
						}
					}
					//******************************************
				}
				catch
				{
					resultLogVulnerability.Add("Vulnerability MajorComponents not completed");
				}
				finally
				{
					resultLogVulnerability.Add("Vulnerability MajorComponents stop");
				}

				//update the PipingComponents table
				try
				{
					dataTable = dataAccess.GetFields("PipingComponents", useConnectionString);
					resultLogVulnerability.Add("Vulnerability PipingComponents start");

					//fieldFound = false;
					for (int i = 0; i < dataTable.Rows.Count; i++) 
					{
						if (dataTable.Rows[i].ItemArray[3].ToString() == "pipe_vulnerability")
						{
							//fieldFound = true;

							//if field data type is byte
							if ((int)dataTable.Rows[i].ItemArray[11] == 17)
							{
								//before altering the field, copy it so we can go back to it, if necessary
								cmd.CommandText = @"ALTER TABLE PipingComponents ADD COLUMN COPYpipe_vulnerability BYTE";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET COPYpipe_vulnerability = pipe_vulnerability";
								cmd.ExecuteNonQuery();

//								//change the field's data type from byte to double
//								cmd.CommandText = @"ALTER TABLE PipingComponents ALTER COLUMN pipe_vulnerability DOUBLE";
//								cmd.ExecuteNonQuery();

								cmd.CommandText = @"ALTER TABLE PipingComponents ADD COLUMN pipe_vulnerability2 DOUBLE";
								cmd.ExecuteNonQuery();

								//*******************************************************
								//DATA POPULATION

								//change the value to represent the probability, rather than the enumeration index
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.9 WHERE pipe_vulnerability = 0";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.7 WHERE pipe_vulnerability = 1";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.4 WHERE pipe_vulnerability = 2";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.2 WHERE pipe_vulnerability = 3";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.1 WHERE pipe_vulnerability = 4";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.05 WHERE pipe_vulnerability = 5";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.02 WHERE pipe_vulnerability = 6";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.01 WHERE pipe_vulnerability = 7";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE PipingComponents SET pipe_vulnerability2 = 0.0067 WHERE pipe_vulnerability = 8";
								cmd.ExecuteNonQuery();
								//*******************************************************

							}
						}
					}
					//******************************************
				}
				catch
				{
					resultLogVulnerability.Add("Vulnerability PipingComponents not completed");
				}
				finally
				{
					resultLogVulnerability.Add("Vulnerability PipingComponents stop");
				}

				//update the NodeAppurtComponents table
				try
				{
					dataTable = dataAccess.GetFields("NodeAppurtComponents", useConnectionString);
					resultLogVulnerability.Add("Vulnerability NodeAppurtComponents start");

					//fieldFound = false;
					for (int i = 0; i < dataTable.Rows.Count; i++) 
					{
						if (dataTable.Rows[i].ItemArray[3].ToString() == "node_vulnerability")
						{
							//fieldFound = true;

							//PipingComponents:		Add field COPYpipe_vulnerability (byte)
							//						Populate field with contents of pipe_vulnerability
							//						Add field pipe_vulnerability2 (double)
							//						Populate pipe_vulnerability2 with probabilities based on COPYpipe_vulnerability enum values

							//if field data type is byte
							if ((int)dataTable.Rows[i].ItemArray[11] == 17)
							{
								//before altering the field, copy it so we can go back to it, if necessary
								cmd.CommandText = @"ALTER TABLE NodeAppurtComponents ADD COLUMN COPYnode_vulnerability BYTE";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET COPYnode_vulnerability = node_vulnerability";
								cmd.ExecuteNonQuery();

//								//change the field's data type from byte to double
//								cmd.CommandText = @"ALTER TABLE NodeAppurtComponents ALTER COLUMN node_vulnerability DOUBLE";
//								cmd.ExecuteNonQuery();

								cmd.CommandText = @"ALTER TABLE NodeAppurtComponents ADD COLUMN node_vulnerability2 DOUBLE";
								cmd.ExecuteNonQuery();

								//*******************************************************
								//DATA POPULATION

								//change the value to represent the probability, rather than the enumeration index
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.9 WHERE node_vulnerability = 0";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.7 WHERE node_vulnerability = 1";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.4 WHERE node_vulnerability = 2";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.2 WHERE node_vulnerability = 3";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.1 WHERE node_vulnerability = 4";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.05 WHERE node_vulnerability = 5";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.02 WHERE node_vulnerability = 6";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.01 WHERE node_vulnerability = 7";
								cmd.ExecuteNonQuery();
								cmd.CommandText = @"UPDATE NodeAppurtComponents SET node_vulnerability2 = 0.0067 WHERE node_vulnerability = 8";
								cmd.ExecuteNonQuery();
								//*******************************************************

							}
						}
					}
					//******************************************
				}
				catch
				{
					resultLogVulnerability.Add("Vulnerability NodeAppurtComponents not completed");
				}
				finally
				{
					resultLogVulnerability.Add("Vulnerability NodeAppurtComponents stop");
				}

				//****

				cmd = null;
			}

			dataTable = null;
			dataAccess = null;

			return true;
		}

		#endregion /***** UpdateVulnerability *****/

		#region /***** UpdateFieldSheet *****/

		public bool UpdateFieldSheet()
		{
			ArrayList resultLogFieldSheet = new ArrayList();

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			try
			{
				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogFieldSheet.Add("FieldSheet not attempted");
					return false;
				}

				//create the FieldSheetData table
				cmd.CommandText = @"CREATE TABLE FieldSheetData (FieldSheetData MEMO)";
				cmd.ExecuteNonQuery();

				cmd = null;
				dataAccess = null;
			}
			catch
			{
				resultLogFieldSheet.Add("FieldSheet not completed");
			}
			finally
			{
				resultLogFieldSheet.Add("FieldSheet stop");
			}

			return true;
		}

		#endregion /***** UpdateFieldSheet *****/

		#region /***** UpdateCurrentValue *****/

		public bool UpdateCurrentValue()
		{
			ArrayList resultLogCurrentValue = new ArrayList();

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			OleDbCommand cmd = null;

			try
			{
				cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogCurrentValue.Add("UpdateCurrentValue not attempted");
					return false;
				}
			}
			catch
			{
				resultLogCurrentValue.Add("Current Value failed on create OleDbCommand");
			}

			try
			{
				cmd.CommandText = @"ALTER TABLE DisciplineLand ADD COLUMN CurrentValue CURRENCY";
				cmd.ExecuteNonQuery();
			}
			catch
			{
				resultLogCurrentValue.Add("Current Value field not created in DisciplineLand table");
			}
			try
			{
				cmd.CommandText = @"ALTER TABLE DisciplineMech ADD COLUMN CurrentValue CURRENCY";
				cmd.ExecuteNonQuery();
			}
			catch
			{
				resultLogCurrentValue.Add("Current Value field not created in DisciplineMech table");
			}
			try
			{
				cmd.CommandText = @"ALTER TABLE DisciplineStruct ADD COLUMN CurrentValue CURRENCY";
				cmd.ExecuteNonQuery();
			}
			catch
			{
				resultLogCurrentValue.Add("Current Value field not created in DisciplineStruct table");
			}

			cmd = null;
			dataAccess = null;
			resultLogCurrentValue.Add("Current Value stop");
			return true;
		}

		#endregion /***** UpdateCurrentValue *****/

		#region /***** UpdateInfoSet *****/

		public bool UpdateInfoSet()
		{
			ArrayList resultLogInfoSet = new ArrayList();

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			OleDbCommand cmd = null;

			try
			{
				cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogInfoSet.Add("InfoSet not attempted");
					return false;
				}
			}
			catch
			{
				resultLogInfoSet.Add("InfoSet failed on create OleDbCommand");
			}

			try
			{
				cmd.CommandText = @"ALTER TABLE InfoSets ADD COLUMN FixedInfoSet BYTE";
				cmd.ExecuteNonQuery();
				cmd.CommandText = @"ALTER TABLE InfoSets ALTER COLUMN FixedInfoSet SET DEFAULT 0";
				cmd.ExecuteNonQuery();
				cmd.CommandText = @"UPDATE InfoSets SET FixedInfoSet = 0 WHERE IsNull(FixedInfoSet)";
				cmd.ExecuteNonQuery();
			}
			catch
			{
				//System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
				resultLogInfoSet.Add("FixedInfoSet field not created/altered in InfoSets table");
			}

			cmd = null;
			dataAccess = null;
			resultLogInfoSet.Add("InfoSets stop");
			return true;
		}

		#endregion /***** UpdateInfoSet *****/

		#region /***** UpdateDatabaseInfo *****/

		//mam 102309 - no longer using DatabaseInfo table after switch to SQL Server
//		public bool UpdateDatabaseInfo()
//		{
//			ArrayList resultLogDatabaseInfo = new ArrayList();
//
//			//mam 102309
//			//DataAccess dataAccess = new DataAccess();
//			UpdateDataAccess dataAccess = new UpdateDataAccess();
//
//			OleDbCommand cmd = null;
//
//			try
//			{
//				cmd = dataAccess.GetCommandObject(useConnectionString);
//				if (cmd == null)
//				{
//					resultLogDatabaseInfo.Add("DatabaseInfo not attempted");
//					return false;
//				}
//			}
//			catch
//			{
//				resultLogDatabaseInfo.Add("DatabaseInfo failed on create OleDbCommand");
//			}
//
//			try
//			{
//				cmd.CommandText = @"CREATE TABLE DatabaseInfo (DatabaseImageFolder VARCHAR (255) WITH COMPRESSION)";
//				cmd.ExecuteNonQuery();
//				cmd.CommandText = "INSERT INTO DatabaseInfo (DatabaseImageFolder) VALUES('')";
//				cmd.ExecuteNonQuery();
//			}
//			catch
//			{
//				//System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//				//System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
//				resultLogDatabaseInfo.Add("DatabaseInfo table not created");
//			}
//
//			cmd = null;
//			dataAccess = null;
//			resultLogDatabaseInfo.Add("DatabaseInfo stop");
//			return true;
//		}

		#endregion /***** UpdateDatabaseInfo *****/

		#region /***** UpdateReportTemplateDecimal *****/

		public bool UpdateReportTemplateDecimal()
		{
			ArrayList resultLogReportTemplateDecimal = new ArrayList();

			//mam 102309
			//DataAccess dataAccess = new DataAccess();
			UpdateDataAccess dataAccess = new UpdateDataAccess();

			OleDbCommand cmd = null;

			try
			{
				cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogReportTemplateDecimal.Add("ReportTemplateDecimal not attempted");
					return false;
				}
			}
			catch
			{
				resultLogReportTemplateDecimal.Add("ReportTemplateDecimal failed on create OleDbCommand");
			}

			try
			{
				//cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare1 DECIMAL (18, 4)";
				cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare1 DOUBLE";
				cmd.ExecuteNonQuery();
				//cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare2 DECIMAL (18, 4)";
				cmd.CommandText = @"ALTER TABLE ReportTemplateFilter ALTER COLUMN FilterTextCompare2 DOUBLE";
				cmd.ExecuteNonQuery();
			}
			catch
			{
				//System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//System.Windows.Forms.MessageBox.Show(ex.Message.ToString());
				resultLogReportTemplateDecimal.Add("ReportTemplateDecimal table not created");
			}

			cmd = null;
			dataAccess = null;
			resultLogReportTemplateDecimal.Add("ReportTemplateDecimal stop");
			return true;
		}

		#endregion /***** UpdateReportTemplateDecimal *****/

		#region /***** UpdatePreferenceTable *****/

		//let's not use the Preference table, as it will cause problems if we ever have multiple users
//		public bool UpdatePreference()
//		{
//			UpdateDataAccess dataAccess = new UpdateDataAccess();
//			DataTable dataTable = dataAccess.GetTables("Preference", useConnectionString);
//			ArrayList resultLogPreference = new ArrayList();
//			bool result = false;
//
//			resultLogPreference.Add("Preference update not attempted");
//
//			if (dataTable == null)
//			{
//				//the table doesn't exist, so attempt to create the Preference table
//
//				resultLogPreference.Clear();
//
//				OleDbCommand cmd = dataAccess.GetCommandObject(useConnectionString);
//				if (cmd == null)
//					return false;
//
//				StringBuilder builder = new StringBuilder(200);
//
//				// create Preference table
//				try
//				{
//					resultLogPreference.Add("Table Preference start");
//
//					builder.Append(@"CREATE TABLE Preference (ID IDENTITY(1,1) CONSTRAINT Key"); 
//					builder.Append(NextKey());
//					builder.Append(" PRIMARY KEY, PreferenceType VARCHAR (50) WITH COMPRESSION,");
//					builder.Append(" PreferenceText VARCHAR (50) WITH COMPRESSION,");
//					builder.Append(" PreferenceDisplayText VARCHAR (100) WITH COMPRESSION, PreferenceValue INTEGER,");
//					builder.Append(" ToolTipText VARCHAR (255) WITH COMPRESSION, SortBy INTEGER, NewlyInstalled INTEGER,");
//					builder.Append(" UserName VARCHAR (50) WITH COMPRESSION, UserPassword VARCHAR (50) WITH COMPRESSION)");
//
//					cmd.CommandText = @builder.ToString();
//					cmd.ExecuteNonQuery();
//						
//					cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON Preference (SortBy)";
//					cmd.ExecuteNonQuery();
//
//					cmd.CommandText = @"ALTER TABLE Preference ALTER COLUMN PreferenceValue SET DEFAULT 0";
//					cmd.ExecuteNonQuery();
//					cmd.CommandText = @"ALTER TABLE Preference ALTER COLUMN SortBy SET DEFAULT 0";
//					cmd.ExecuteNonQuery();
//					cmd.CommandText = @"ALTER TABLE Preference ALTER COLUMN NewlyInstalled SET DEFAULT 0";
//					cmd.ExecuteNonQuery();
//				}
//				catch
//				{
//					resultLogPreference.Add("Table Preference not completed");
//				}
//				finally
//				{
//					resultLogPreference.Add("Table Preference stop");
//				}
//
//				cmd = null;
//
//				//*******************************************************
//				//DATA POPULATION
//
//				//populate the Preference table
//
//				DataSet dataSet = new DataSet();
//				string queryString = @"SELECT * FROM Preference";
//				dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
//				if (dataSet == null)
//				{
//					throw new Exception("Database Error.  Update1.UpdatePreference.");
//				}
//
//				DataRow dataRow;
//
//				try
//				{
//					resultLogPreference.Add("Data Population Table Preference start");
//
//					dataRow = dataSet.Tables[0].NewRow();
//					dataRow["PreferenceType"] = "ReportTemplate";
//					dataRow["PreferenceText"] = "AutomaticSave";
//					dataRow["PreferenceValue"] = 1;
//					dataRow["SortBy"] = 0;
//					dataSet.Tables[0].Rows.Add(dataRow);
//
//					dataRow = dataSet.Tables[0].NewRow();
//					dataRow["PreferenceType"] = "ReportTemplate";
//					dataRow["PreferenceText"] = "UserView";
//					dataRow["PreferenceValue"] = 0;
//					dataRow["SortBy"] = 1;
//					dataSet.Tables[0].Rows.Add(dataRow);
//
//					result = dataAccess.UpdateDatabase(dataSet, queryString, useConnectionString);
//					if (!result)
//						resultLogPreference.Add("Data Population Table Preference not completed");
//				}
//				catch
//				{
//					resultLogPreference.Add("Data Population Table Preference not completed");
//				}
//				finally
//				{
//					resultLogPreference.Add("Data Population Table Preference stop");
//				}
//
//				//*******************************************************
//
//			}
//
//			return true;
//		}

	#endregion /***** UpdatePreferenceTable *****/

		#region /***** UpdateENRValue2004 *****/

		//mam 102309 - using Update1 only for importing Access database data - don't update enr data

//		public bool UpdateENRValue2004()
//		{
//			OleDbCommand	sqlCommand = null;
//			OleDbDataReader	dataReader = null;
//			int curENRValue2004 = 0;
//			bool hasENRValue = false;
//			bool returnValue = true;
//			string connectionStringENR = WAM.Data.WAMSource.ENRSource.ConnectionString;
//
//			string querySqlString = "SELECT enr_value FROM ENR20Cities WHERE enr_year = 2004";
//			string insertSqlString = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2004, 6957)";
//
//			//check whether the year 2004 already exists in ENR20Cities table
//
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionStringENR);
//			OleDbCommand	dataCommand = null;
//
//			try
//			{
//				sqlConnection.Open();
//
//				dataCommand = new OleDbCommand(querySqlString, sqlConnection);
//				dataReader = dataCommand.ExecuteReader();
//
//				if (dataReader == null)
//					System.Windows.Forms.MessageBox.Show("dataReader is null");
//
//				while (dataReader.Read())
//				{
//					curENRValue2004 = (int)dataReader.GetValue(0);
//					hasENRValue	 = true;
//					break;
//				}
//				if (dataReader != null && !dataReader.IsClosed)
//					dataReader.Close();
//
//				if (!hasENRValue)
//				{
//					sqlCommand = new OleDbCommand(insertSqlString, sqlConnection);
//					sqlCommand.ExecuteNonQuery();
//				}
//			}
//			catch (OleDbException ex)
//			{
//				returnValue = false;
//				System.Diagnostics.Trace.WriteLine(
//					String.Format("Update1 UpdateENRValue2004 Error: {0}\n", ex.Message));
//			}
//			finally
//			{
//				if (dataReader != null && !dataReader.IsClosed)
//					dataReader.Close();
//
//				sqlConnection.Dispose();
//			}
//
//			return returnValue;
//		}

		#endregion /***** UpdateENRValue2004 *****/

	}
}
