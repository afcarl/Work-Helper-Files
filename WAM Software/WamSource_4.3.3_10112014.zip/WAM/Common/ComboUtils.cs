using System;
using System.Windows.Forms;
using System.Collections;
using System.Text;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for ComboUtils.
	/// </summary>
	public class ComboUtils
	{
		private string _data;
		private string _display;

		public ComboUtils(string in_data, string in_display)
		{
			Data = in_data;
			Display = in_display;
		}

		public string Data
		{
			set{ _data = value; }
			get{ return _data;}
		}
	
		public string Display
		{
			set{ _display = value; }
			get{ return _display;}
		}
	
		public override string ToString()
		{
			return Display;
		}
	}


	public class ComboBoxMethods
	{
		private int forInfoSetID = 0;
		private string queryValueCustomENR = "";

		public ComboBoxMethods()
		{
			AssignQueryStringValues();
		}

		public ComboBoxMethods(int forInfoSetID)
		{
			this.forInfoSetID = forInfoSetID;
			AssignQueryStringValues();
		}

		private void AssignQueryStringValues()
		{
			StringBuilder builder = new StringBuilder(200);

			builder.Append("SELECT C.CustomENRListID AS ID, C.CustomENRListID AS EnumValue,");
			builder.Append(" C.CustomENRListName AS Description, C.CustomENRListName AS ItemTag");
			builder.Append(" FROM (CustomENRList C INNER JOIN Facilities F ON C.CustomENRListID = F.CustomENRListID)");
			builder.Append(" INNER JOIN InfoSets I ON F.infoset_id = I.infoset_id");

			if (forInfoSetID > 0)
			{
				builder.AppendFormat(" WHERE I.infoset_id = {0}", forInfoSetID.ToString());
				builder.Append(" ORDER BY I.infoset_name, C.CustomerENRListName");
			}
			else
			{
				builder.Append(" ORDER BY C.CustomENRListName");
			}

			queryValueCustomENR = builder.ToString();
			System.Diagnostics.Debug.WriteLine(QueryValueCustomENR);
		}

		public string QueryValueCustomENR
		{
			get { return queryValueCustomENR; }
		}

		public bool PopulateComboBox(ComboBox comboBox, string queryValue)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			ArrayList comboBoxItems = new ArrayList();

			//clear the combo box whether or not there are any new items to put into it
			comboBox.DataSource = null;
			comboBox.Items.Clear();

			dataSet = dataAccess.GetDisconnectedDataset(@queryValue);
			if (dataSet == null)
			{
				return false;
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];
			if (dataTable == null)
			{
				return false;
			}
			
			comboBox.BeginUpdate();
			comboBox.Items.Clear();
			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				WAM.Common.ComboBoxItem comboBoxItem =  new WAM.Common.ComboBoxItem((int)dataRow["ID"], 
					(string)dataRow["Description"], (int)dataRow["EnumValue"], (string)dataRow["ItemTag"]);
				comboBox.Items.Add(comboBoxItem);
			}
			comboBox.EndUpdate();

			if (comboBox.Items.Count > 0)
				comboBox.SelectedIndex = 0;
			
			comboBox.DisplayMember = "ItemDescription";
			comboBox.ValueMember = "ItemID";

			return true;
		}

		//mam 050806 - use this method to get list of custom enr list names
		public System.Collections.Specialized.ListDictionary GetEnrListItems(bool includeNoneChoice)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			System.Collections.Specialized.ListDictionary listDictionary = new System.Collections.Specialized.ListDictionary();

			StringBuilder builder = new StringBuilder(100);
			builder.Append("SELECT C.CustomENRListID AS ID, C.CustomENRListID AS EnumValue, C.CustomENRListName AS Description,");
			builder.Append(" C.CustomENRListName AS ItemTag");
			builder.Append(" FROM CustomENRList C ORDER BY C.CustomENRListName");

			System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTable(@builder.ToString());
			if (dataTable == null)
			{
				return null;
			}
			
			if (includeNoneChoice)
			{
				listDictionary.Add(0, "[none]");
			}

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				listDictionary.Add((int)dataRow["ID"], (string)dataRow["Description"]);
			}

			return listDictionary;
		}

		//mam - set which item is displayed in the combo box based on its ID
		public void SetComboIndex(ComboBox comboBox, int comboBoxID)
		{
			if (comboBox == null)
				return;

			for (int i = 0; i < comboBox.Items.Count; i++)
			{
				if (((WAM.Common.ComboBoxItem)comboBox.Items[i]).ItemID == comboBoxID)
				{
					comboBox.SelectedIndex = i;
					break;
				}
			}
		}
		//</mam>

		//mam - set which item is displayed in the combo box based on the combo index
		public void SetComboIndexBasedOnIndex(ComboBox comboBox, int comboBoxIndex)
		{
			if (comboBox == null)
				return;

			for (int i = 0; i < comboBox.Items.Count; i++)
			{
				if (i == comboBoxIndex)
				{
					comboBox.SelectedIndex = i;
					break;
				}
			}
		}
		//</mam>
	}


	public class GridMethods
	{
		private int forInfoSetID = 0;
		private string queryValueCustomENR = "";

		public GridMethods()
		{
			AssignQueryStringValues();
		}

		public GridMethods(int forInfoSetID)
		{
			this.forInfoSetID = forInfoSetID;
			AssignQueryStringValues();
		}

		private void AssignQueryStringValues()
		{
			StringBuilder builder = new StringBuilder(200);
			string sortDir = " ASC";

			builder.Append("SELECT C.CustomENRListID AS ID, C.CustomENRListID AS EnumValue, C.CustomENRListName AS Description,");

			//mam 102309 - replace IIF with CASE
			//builder.Append(" C.CustomENRListName AS ItemTag, I.infoset_name AS ItemExtra1, IIF(I.FixedInfoset = 1, 'true', 'false') AS ItemExtra2");
			builder.Append(" C.CustomENRListName AS ItemTag, I.infoset_name AS ItemExtra1,");
			builder.Append(" CASE I.FixedInfoset WHEN 1 THEN 'true' ELSE 'false' END AS ItemExtra2");

			builder.Append(" FROM CustomENRList C LEFT JOIN InfoSets I ON C.InfosetID = I.infoset_id");

			if (forInfoSetID > 0)
			{
				builder.AppendFormat(" WHERE I.infoset_id = {0}", forInfoSetID.ToString());
			}
			builder.AppendFormat(" ORDER BY I.infoset_name {0}, I.infoset_id {0}, C.CustomENRListName {0}", sortDir);

			queryValueCustomENR = builder.ToString();
			//System.Diagnostics.Debug.WriteLine("queryValueCustomENR = " + queryValueCustomENR.ToString());
		}

		public string QueryValueCustomENR
		{
			get { return queryValueCustomENR; }
		}

		public int PopulateGrid(ref C1.Win.C1FlexGrid.C1FlexGrid grid, int selectedID, string queryValue)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			WAM.Common.ComboBoxItem comboBoxItem;
			int selRow = -1;
			int row = -1;

			//clear the grid whether or not there are any new items to put into it
			//update: don't use grid.Clear() because it removes formatting - use 'grid.Rows.Count = 1' instead
			//grid.Clear();

			dataSet = dataAccess.GetDisconnectedDataset(@queryValue);
			if (dataSet == null)
			{
				return selRow;
			}

			System.Data.DataTable dataTable = dataSet.Tables[0];
			if (dataTable == null)
			{
				return selRow;
			}
			
			row = 1;
			grid.Redraw = false;
			grid.Rows.Count = 1;

			try
			{
				foreach (System.Data.DataRow dataRow in dataTable.Rows)
				{
					if (dataRow["ItemExtra1"].ToString().Length == 0)
					{
						dataRow["ItemExtra1"] = "[none]";
					}
					comboBoxItem =  new WAM.Common.ComboBoxItem((int)dataRow["ID"], (string)dataRow["Description"], 
						(int)dataRow["EnumValue"], (string)dataRow["ItemTag"], (string)dataRow["ItemExtra1"], (string)dataRow["ItemExtra2"]);

					grid.Rows.Add().UserData = comboBoxItem;
					grid.SetData(row, 0, comboBoxItem.ItemID.ToString());
					grid.SetData(row, 1, comboBoxItem.ItemExtra1.ToString());
					grid.SetData(row, 2, comboBoxItem.ItemDescription.ToString());

					if (selectedID.ToString() == comboBoxItem.ItemID.ToString())
					{
						selRow = row;
					}
					row++;
				}
				grid.Row = selRow;
				
				if (selRow == -1 && grid.Rows.Count > 1)
				{
					selRow = 1;
					grid.Row = selRow;
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			finally
			{
				grid.Redraw = true;
			}

			return selRow;
		}
	}
}
