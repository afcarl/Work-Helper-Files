using System;
using System.Data;

//mam 102309
//using System.Data.OleDb;

using System.Windows.Forms;

//mam 102309
using System.Data.SqlClient;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for DataAccess.
	/// </summary>

	//mam 03202012 - added IDisposable to use DataAccess in a using block
	public class DataAccess : IDisposable
	{
		#region /***** Member Variables *****/

		//mam 102309
		//private string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		private string connectionString = WAM.Common.Globals.WamSqlConnectionString;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public DataAccess()
		{
		}

		#endregion /***** Construction *****/

		#region /***** Database Access *****/

		//mam 07072011 - don't use this - when is the connection closed?
		//mam 102309
		//public OleDbCommand GetCommandObject()
//		public SqlCommand GetCommandObject()
//		{
//			//mam 102309
//			//OleDbConnection conn = new OleDbConnection(@connectionString);
//			SqlConnection  conn = new  SqlConnection(@connectionString);
//
//			try
//			{
//				conn.Open();
//
//				//mam 102309
//				//OleDbCommand cmd = conn.CreateCommand();
//				SqlCommand cmd = conn.CreateCommand();
//
//				return cmd;
//			}
//			catch
//			{
//				return null;
//			}
//		}

		//mam 07072011 - don't use this - when is the connection closed?
		//mam 102309
		//public OleDbCommand GetCommandObject(string useConnectionString)
//		public SqlCommand GetCommandObject(string useConnectionString)
//		{
//			//mam 102309
//			//OleDbConnection conn = new OleDbConnection(useConnectionString);
//			SqlConnection  conn = new  SqlConnection(useConnectionString);
//
//			try
//			{
//				conn.Open();
//
//				//mam 102309
//				//OleDbCommand cmd = conn.CreateCommand();
//				SqlCommand cmd = conn.CreateCommand();
//
//				return cmd;
//			}
//				//mam 102309
//				//catch (OleDbException ex)
//			catch (SqlException ex)
//			{
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//				//return null;
//				throw ex;
//			}
//		}

		public bool ExecuteCommand(string ExecuteStatement)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(@connectionString);
			SqlConnection  conn = new  SqlConnection(@connectionString);

			try
			{
				conn.Open();

				//mam 102309
				//OleDbCommand cmd = conn.CreateCommand();
				SqlCommand cmd = conn.CreateCommand();

				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, "DataAccess.ExecuteCommand", "Embedded SQL Text", @ExecuteStatement, ex.Message);

				//let's not thrown the error; let's add it to the error text 
				//Globals.ErrorText += Environment.NewLine + "Error in ExecuteCommand:  " + ex.Message;
				return false;
				//throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 07072011 - new method that uses stored procedure
		public bool ExecuteCommandSP(string StoredProcedureName, string ParameterName, int ItemId)
		{
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();

			SqlConnection conn = new SqlConnection();
			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;

				System.Data.SqlClient.SqlParameter param = new SqlParameter(ParameterName, System.Data.SqlDbType.Int);
				param.Value = ItemId;
				command.Parameters.Add(param);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//LogError(conn, StoredProcedureName, "Stored Procedure", "", ex.Message);
				LogError(conn, StoredProcedureName, "Stored Procedure", ParameterName + "=" + ItemId.ToString(), ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 07072011 - new method that uses stored procedure and two parameters
		public bool ExecuteCommandSP(string StoredProcedureName, string ParameterName1, string ParameterName2, int ItemId1, int ItemId2)
		{
			//System.Data.DataTable dataTable = new System.Data.DataTable();
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;

				//System.Data.SqlClient.SqlParameter param = new SqlParameter("@componentId", System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param1 = new SqlParameter(ParameterName1, System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param2 = new SqlParameter(ParameterName2, System.Data.SqlDbType.Int);
				param1.Value = ItemId1;
				param2.Value = ItemId2;
				command.Parameters.Add(param1);
				command.Parameters.Add(param2);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, StoredProcedureName, "Stored Procedure", ParameterName1 + "=" + ItemId1.ToString() + ", " + ParameterName2 + "=" + ItemId2.ToString(), ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 03032011 - new method that uses stored procedure
		public bool ExecuteCommandSP(string StoredProcedureName, string ParameterName1, string ParameterName2, string ParameterName3
			, string ItemData1, int ItemData2, bool ItemData3)
		{
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;

				System.Data.SqlClient.SqlParameter param1 = new SqlParameter(ParameterName1, System.Data.SqlDbType.Text);
				System.Data.SqlClient.SqlParameter param2 = new SqlParameter(ParameterName2, System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param3 = new SqlParameter(ParameterName3, System.Data.SqlDbType.Bit);
				param1.Value = ItemData1;
				param2.Value = ItemData2;
				param3.Value = ItemData3;
				command.Parameters.Add(param1);
				command.Parameters.Add(param2);
				command.Parameters.Add(param3);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				string args = ParameterName1 + "=" + ItemData1.ToString() + ", " + ParameterName2 + "=" + ItemData2.ToString()
					+ ParameterName3 + "=" + ItemData3.ToString();
				LogError(conn, StoredProcedureName, "Stored Procedure", args, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 03032011 - new method that uses stored procedure
		public bool ExecuteCommandSP(string StoredProcedureName, string ParameterName1, string ParameterName2, string ParameterName3, string ParameterName4
			, string ItemData1, int ItemData2, bool ItemData3, bool ItemData4)
		{
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;

				System.Data.SqlClient.SqlParameter param1 = new SqlParameter(ParameterName1, System.Data.SqlDbType.Text);
				System.Data.SqlClient.SqlParameter param2 = new SqlParameter(ParameterName2, System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param3 = new SqlParameter(ParameterName3, System.Data.SqlDbType.Bit);
				System.Data.SqlClient.SqlParameter param4 = new SqlParameter(ParameterName4, System.Data.SqlDbType.Bit);
				param1.Value = ItemData1;
				param2.Value = ItemData2;
				param3.Value = ItemData3;
				param4.Value = ItemData4;
				command.Parameters.Add(param1);
				command.Parameters.Add(param2);
				command.Parameters.Add(param3);
				command.Parameters.Add(param4);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				string args = ParameterName1 + "=" + ItemData1.ToString() + ", " + ParameterName2 + "=" + ItemData2.ToString()
					+ ParameterName3 + "=" + ItemData3.ToString() + ", " + ParameterName4 + "=" + ItemData4.ToString();
				LogError(conn, StoredProcedureName, "Stored Procedure", args, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 07072011 - new method to call specific stored procedure
		//save criticality values to database for major component
		public bool ExecuteCommandInsertCriticalityValuesComponent(int ComponentId, string CritValues, bool byScore)
		{
			//the byScore parameter is true if the values in CritValues are score values rather than CriticalityScoreIds

			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();

			System.Diagnostics.Debug.WriteLine(CritValues);

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = byScore ? "InsertCriticalityValuesByScore" : "InsertCriticalityValues";
				command.CommandType = System.Data.CommandType.StoredProcedure;

				//**********************************
				//**********************************

				//System.Data.SqlClient.SqlParameter param = new SqlParameter("@componentId", System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param = new SqlParameter("@componentId", System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param2 = new SqlParameter("@critValues", System.Data.SqlDbType.VarChar);
				param.Value = ComponentId;
				param2.Value = CritValues;
				command.Parameters.Add(param);
				command.Parameters.Add(param2);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, "DataAccess.ExecuteCommandInsertCriticalityValuesComponent", "Stored Procedure", "Component Id = " + ComponentId.ToString() +"; CritValues = " + CritValues, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 07072011 - new method to call specific stored procedure
		//save criticality values to database for pipes and nodes
		public bool ExecuteCommandInsertCriticalityValuesPipeNode(int ItemId, string CritValues, bool isPipe)
		{
			//System.Data.DataTable dataTable = new System.Data.DataTable();
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();
			string itemType = isPipe ? "Pipe" : "Node";
			string parameterName = isPipe ? "@pipeId" : "@nodeId";

			System.Diagnostics.Debug.WriteLine(CritValues);

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = "InsertCriticalityValues" + itemType;
				command.CommandType = System.Data.CommandType.StoredProcedure;

				System.Data.SqlClient.SqlParameter param = new SqlParameter(parameterName, System.Data.SqlDbType.Int);
				System.Data.SqlClient.SqlParameter param2 = new SqlParameter("@critValues", System.Data.SqlDbType.VarChar);
				param.Value = ItemId;
				param2.Value = CritValues;
				command.Parameters.Add(param);
				command.Parameters.Add(param2);

				command.ExecuteNonQuery();
				return true;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, "DataAccess.ExecuteCommandInsertCriticalityValuesPipeNode", "Stored Procedure", "Pipe or Node Id = " + ItemId.ToString() +"; CritValues = " + CritValues, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public bool ExecuteCommand(string ExecuteStatement, string useConnectionString)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(@useConnectionString);
			SqlConnection conn = new SqlConnection(@useConnectionString);

			try
			{
				conn.Open();

				//mam 102309
				//OleDbCommand cmd = conn.CreateCommand();
				SqlCommand cmd = conn.CreateCommand();

				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, "DataAccess.ExecuteCommand", "Embedded SQL Text", @ExecuteStatement, ex.Message);
				throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public int ExecuteCommandReturnAutoID(string ExecuteStatement)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(@connectionString);
			SqlConnection conn = new SqlConnection(@connectionString);

			try
			{
				int returnID = 0;

				conn.Open();

				//mam 102309
				//OleDbCommand cmd = conn.CreateCommand();
				SqlCommand cmd = conn.CreateCommand();
				
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();

				//mam 102309 - use SCOPE_IDENTITY instead of @@Identity
				//cmd.CommandText = "SELECT @@Identity";
				cmd.CommandText = "SELECT SCOPE_IDENTITY()";

				//mam 102309 - SCOPE_IDENTITY returns a decimal - use Convert.ToInt32 instead of (int)
				//returnID = (int)cmd.ExecuteScalar();
				returnID = Convert.ToInt32(cmd.ExecuteScalar());

				return returnID;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine("An error occurred while saving data." + Environment.NewLine + Environment.NewLine + ex.Message.ToString());
				LogError(conn, "DataAccess.ExecuteCommandReturnAutoID", "Embedded SQL Text", @ExecuteStatement, ex.Message);

				//let's not thrown the error; let's add it to the error text 
				//Globals.ErrorText += Environment.NewLine + "Error in ExecuteCommandReturnAutoID:  " + ex.Message;
				//throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return 0;
		}

		//mam 03202012
		public int ExecuteScalar(string StoredProcedureName, string paramName1, string paramName2, int ItemId1, string ItemId2)
		{
			int returnValue = -1;

			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.Int);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.VarChar);
					param1.Value = ItemId1;
					param2.Value = ItemId2;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);

					returnValue = Convert.ToInt32(command.ExecuteScalar());
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", paramName1 + "=" + ItemId1.ToString() + ", " + paramName2 + "=" + ItemId2.ToString(), ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return returnValue;
		}

		private bool LogError(SqlConnection conn, string errorSource, string errorSoureType, string queryOrStatement, string errorMessage)
		{
			try
			{
				queryOrStatement = queryOrStatement.Replace("'", "");
				errorMessage = errorMessage.Replace("'", "");
				System.Diagnostics.Debug.WriteLine("queryOrStatement = " + @queryOrStatement);
				System.Diagnostics.Debug.WriteLine("errorMessage = " + @errorMessage);

				DateTime dateTime = DateTime.Now;
				string errMsg = errorMessage + ":  " + queryOrStatement;
				//string ExecuteStatement = "EXECUTE [UtilityLogError2] '0', '" + @errorSource + "', '" + @errorSoureType + "', 0, '" + @errMsg + "', 0, 0";
				string ExecuteStatement = "EXECUTE [ErrorLogInsert] '0', '" + @errorSource + "', '" + @errorSoureType + "', 0, '" + @errMsg + "', 0, 0, NULL";

				System.Diagnostics.Debug.WriteLine(@ExecuteStatement);

				SqlCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();

					//@errorCode VARCHAR(50)
					//@errorSource VARCHAR(50)
					//@errorSourceType VARCHAR(50)
					//@errorSeverity INT
					//@errorText VARCHAR(MAX)
					//@errorState INT
					//@errorLine INT
					//@errorDateTime DATETIME

					//@ErrNumber INT
					//@ErrProcedure NVARCHAR(126)
					//@ErrSeverity INT
					//@ErrMsg NVARCHAR(2048)
					//@ErrState INT
					//@ErrLine INT
					//@ErrDateTime DATETIME

				//error source (procedure) = DataAccess.[method name]
				//error source type = inserted by SP
				//error text (msg) = error message + query/statement
			}
			catch
			{
				return false;
			}

			return true;
		}

		//mam 01222012
		public bool LogError(string errorSource, string errorSoureType, string queryOrStatement, string errorMessage)
		{
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();

				queryOrStatement = queryOrStatement.Replace("'", "");
				errorMessage = errorMessage.Replace("'", "");
				System.Diagnostics.Debug.WriteLine("queryOrStatement = " + @queryOrStatement);
				System.Diagnostics.Debug.WriteLine("errorMessage = " + @errorMessage);

				DateTime dateTime = DateTime.Now;
				string errMsg = errorMessage + ":  " + queryOrStatement;
				//string ExecuteStatement = "EXECUTE [UtilityLogError2] '0', '" + @errorSource + "', '" + @errorSoureType + "', 0, '" + @errMsg + "', 0, 0";
				string ExecuteStatement = "EXECUTE [ErrorLogInsert] '0', '" + @errorSource + "', '" + @errorSoureType + "', 0, '" + @errMsg + "', 0, 0, NULL";

				System.Diagnostics.Debug.WriteLine(@ExecuteStatement);

				SqlCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
			}
			catch
			{
				return false;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}

			return true;
		}

		public int ExecuteCommandReturnAutoID(string ExecuteStatement, string useConnectionString)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(useConnectionString);
			SqlConnection conn = new SqlConnection(useConnectionString);

			try
			{
				int returnID = 0;

				conn.Open();

				//mam 102309
				//OleDbCommand cmd = conn.CreateCommand();
				SqlCommand cmd = conn.CreateCommand();

				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();

				//mam 102309 - use SCOPE_IDENTITY instead of @@Identity
				//cmd.CommandText = "SELECT @@Identity";
				cmd.CommandText = "SELECT SCOPE_IDENTITY()";

				//mam 102309 - SCOPE_IDENTITY returns a decimal - use Convert.ToInt32 instead of (int)
				//returnID = (int)cmd.ExecuteScalar();
				returnID = Convert.ToInt32(cmd.ExecuteScalar());

				return returnID;
			}
			catch(Exception ex)
			{
				LogError(conn, "DataAccess.ExecuteCommandReturnAutoID", "Embedded SQL Text", @ExecuteStatement, ex.Message);
				throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataTable GetDisconnectedDataTable(string QueryString)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//mam 102309
			//OleDbConnection conn = null;
			SqlConnection conn = null;

			try
			{
				//mam 102309
				//conn = new OleDbConnection(@connectionString);
				//OleDbDataAdapter adapter = new OleDbDataAdapter();
				//adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				conn = new SqlConnection(@connectionString);
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.SelectCommand = new SqlCommand(@QueryString, conn);

				adapter.Fill(dataTable);

				return dataTable;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				LogError(conn, "DataAccess.GetDisconnectedDataTable", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataTable GetDisconnectedDataTable(string QueryString, string useConnectionString)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//mam 102309
			//OleDbConnection conn = null;
			SqlConnection conn = null;

			try
			{
				//mam 102309
				//conn = new OleDbConnection(@useConnectionString);
				//OleDbDataAdapter adapter = new OleDbDataAdapter();
				//adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				conn = new SqlConnection(@useConnectionString);
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.SelectCommand = new SqlCommand(@QueryString, conn);

				adapter.Fill(dataTable);
				
				return dataTable;
			}

			catch(Exception ex)
			{
				//return null;
				LogError(conn, "DataAccess.GetDisconnectedDataTable", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		//mam 07072011 - new method that uses a stored procedure
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.SelectCommand = command;
				adapter.Fill(dataTable);

				return dataTable;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//return null;
				LogError(conn, StoredProcedureName, "Stored Procedure", "", ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}
		//</mam>

		//mam 07072011 - new method that uses a stored procedure
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string ParameterName, int ItemId)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;
				
				System.Data.SqlClient.SqlParameter param = new SqlParameter(ParameterName, System.Data.SqlDbType.Int);
				param.Value = ItemId;
				command.Parameters.Add(param);

				SqlDataAdapter adapter = new SqlDataAdapter();
				//adapter.SelectCommand = new SqlCommand(@QueryString, conn);
				//adapter.SelectCommand = new SqlCommand(command.CommandText, conn);
				adapter.SelectCommand = command;
				adapter.Fill(dataTable);

				//System.Data.DataTable dataTable = new System.Data.DataTable();
				//command.CommandText = "GetListCriticality";
				//command.CommandType = System.Data.CommandType.StoredProcedure;

				//System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter();
				//adapter.SelectCommand = command;
				//adapter.Fill(dataTable);

				return dataTable;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//return null;
				LogError(conn, StoredProcedureName, "Stored Procedure", "ParameterName=" + ParameterName.ToString() + "; ItemId=" + ItemId.ToString(), ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}
		//</mam>

		//mam 07072011 - new method that uses a stored procedure
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName, bool boolValue)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			//System.Data.SqlClient.SqlCommand command = GetCommandObject();
			SqlConnection conn = new SqlConnection();

			try
			{
				conn = new  SqlConnection(@connectionString);
				conn.Open();
				SqlCommand command = conn.CreateCommand();

				command.CommandText = StoredProcedureName;
				command.CommandType = System.Data.CommandType.StoredProcedure;
				
				System.Data.SqlClient.SqlParameter param = new SqlParameter(paramName, System.Data.SqlDbType.Bit);
				param.Value = boolValue;
				command.Parameters.Add(param);

				SqlDataAdapter adapter = new SqlDataAdapter();
				//adapter.SelectCommand = new SqlCommand(@QueryString, conn);
				//adapter.SelectCommand = new SqlCommand(command.CommandText, conn);
				adapter.SelectCommand = command;
				adapter.Fill(dataTable);

				//System.Data.DataTable dataTable = new System.Data.DataTable();
				//command.CommandText = "GetListCriticality";
				//command.CommandType = System.Data.CommandType.StoredProcedure;

				//System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter();
				//adapter.SelectCommand = command;
				//adapter.Fill(dataTable);

				return dataTable;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//return null;
				LogError(conn, StoredProcedureName, "Stored Procedure", "ParameterName=" + paramName.ToString() + "; boolValue=" + boolValue.ToString(), ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}
		//</mam>

		//mam 01222012 - new method that uses a stored procedure (with two params)
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName1, string paramName2, int ItemId1, int ItemId2)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.Int);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.Int);
					param1.Value = ItemId1;
					param2.Value = ItemId2;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);

					return dataTable;
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", paramName1 + "=" + ItemId1.ToString() + ", " + paramName2 + "=" + ItemId2.ToString(), ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName1, string paramName2, string ItemId1, bool ItemId2)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.Bit);
					param1.Value = ItemId1;
					param2.Value = ItemId2;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);

					return dataTable;
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", paramName1 + "=" + ItemId1.ToString() + ", " + paramName2 + "=" + ItemId2.ToString(), ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName, string paramData)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//*****************************************
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param = new SqlParameter(paramName, System.Data.SqlDbType.VarChar);
					param.Value = paramData;
					command.Parameters.Add(param);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", "ParameterName=" + paramName.ToString() + "; parameterData=" + paramData.ToString(), ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return dataTable;
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName, string paramData, ref DataTable dataTable)
		{
			//System.Data.DataTable dataTable = new System.Data.DataTable();

			//*****************************************
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param = new SqlParameter(paramName, System.Data.SqlDbType.VarChar);
					param.Value = paramData;
					command.Parameters.Add(param);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", "ParameterName=" + paramName.ToString() + "; parameterData=" + paramData.ToString(), ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return dataTable;
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName, string paramName1, string paramData1
			, string paramName2, bool paramData2, ref DataTable dataTable)
		{
			//System.Data.DataTable dataTable = new System.Data.DataTable();

			//*****************************************
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.Bit);
					param1.Value = paramData1;
					param2.Value = paramData2;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", "This stored procedure has multiple parameters", ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return dataTable;
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName
			, string paramName1, string paramData1
			, string paramName2, string paramData2
			, string paramName3, string paramData3
			, string paramName4, string paramData4
			, string paramName5, string paramData5
			, string paramName6, string paramData6)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//*****************************************
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param3 = new SqlParameter(paramName3, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param4 = new SqlParameter(paramName4, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param5 = new SqlParameter(paramName5, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param6 = new SqlParameter(paramName6, System.Data.SqlDbType.VarChar);
					param1.Value = paramData1;
					param2.Value = paramData2;
					param3.Value = paramData3;
					param4.Value = paramData4;
					param5.Value = paramData5;
					param6.Value = paramData6;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);
					command.Parameters.Add(param3);
					command.Parameters.Add(param4);
					command.Parameters.Add(param5);
					command.Parameters.Add(param6);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", "This stored procedure has multiple parameters", ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return dataTable;
		}

		//mam 03202012 - new method
		public System.Data.DataTable GetDisconnectedDataTableSP(string StoredProcedureName
			, string paramName1, int paramData1
			, string paramName2, int paramData2
			, string paramName3, string paramData3
			, string paramName4, string paramData4)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();

			//*****************************************
			using (SqlConnection conn = new SqlConnection(@connectionString))
			{
				conn.Open();

				try
				{
					SqlCommand command = conn.CreateCommand();

					command.CommandText = StoredProcedureName;
					command.CommandType = System.Data.CommandType.StoredProcedure;
				
					System.Data.SqlClient.SqlParameter param1 = new SqlParameter(paramName1, System.Data.SqlDbType.Int);
					System.Data.SqlClient.SqlParameter param2 = new SqlParameter(paramName2, System.Data.SqlDbType.Int);
					System.Data.SqlClient.SqlParameter param3 = new SqlParameter(paramName3, System.Data.SqlDbType.VarChar);
					System.Data.SqlClient.SqlParameter param4 = new SqlParameter(paramName4, System.Data.SqlDbType.VarChar);
					param1.Value = paramData1;
					param2.Value = paramData2;
					param3.Value = paramData3;
					param4.Value = paramData4;
					command.Parameters.Add(param1);
					command.Parameters.Add(param2);
					command.Parameters.Add(param3);
					command.Parameters.Add(param4);

					SqlDataAdapter adapter = new SqlDataAdapter();
					adapter.SelectCommand = command;
					adapter.Fill(dataTable);
				}

				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					LogError(conn, StoredProcedureName, "Stored Procedure", "This stored procedure has multiple parameters", ex.Message);
					throw ex;
				}

				finally
				{
					if (conn!= null)
					{
						if (conn.State == ConnectionState.Open)
							conn.Close();
					}
				}
			}

			return dataTable;
		}

		public System.Data.DataSet GetDisconnectedDataset(string QueryString)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();

			//mam 102309
			//OleDbConnection conn = null;
			SqlConnection conn = null;

			try
			{
				//mam 102309
				//conn = new OleDbConnection(@connectionString);
				//OleDbDataAdapter adapter = new OleDbDataAdapter();
				//adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				conn = new SqlConnection(@connectionString);
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.SelectCommand = new SqlCommand(@QueryString, conn);

				adapter.Fill(dataSet);
				
				return dataSet;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//return null;
				LogError(conn, "DataAccess.GetDisconnectedDataset", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataSet GetDisconnectedDataset(string QueryString, string useConnectionString)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();

			//mam 102309
			//OleDbConnection conn = null;
			SqlConnection conn = null;

			try
			{
				//mam 102309
				//conn = new OleDbConnection(useConnectionString);
				//OleDbDataAdapter adapter = new OleDbDataAdapter();
				//adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				conn = new SqlConnection(useConnectionString);
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.SelectCommand = new SqlCommand(@QueryString, conn);

				adapter.Fill(dataSet);
				
				return dataSet;
			}

			catch(Exception ex)
			{
				//return null;
				LogError(conn, "DataAccess.GetDisconnectedDataset", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(@connectionString);
			//OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
			//dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
			//OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);
			SqlConnection conn = new SqlConnection(@connectionString);
			SqlDataAdapter dataAdapter = new SqlDataAdapter();
			dataAdapter.SelectCommand = new SqlCommand(@QueryString, conn);
			SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

			try
			{
				conn.Open();
				dataAdapter.Update(dataSet);
				return true;
			}
			catch(Exception ex)
			{
				LogError(conn, "DataAccess.UpdateDatabase", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString, string useConnectionString)
		{
			//mam 102309
			//OleDbConnection conn = new OleDbConnection(useConnectionString);
			//OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
			//dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
			//OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);
			SqlConnection conn = new SqlConnection(useConnectionString);
			SqlDataAdapter dataAdapter = new SqlDataAdapter();
			dataAdapter.SelectCommand = new SqlCommand(@QueryString, conn);
			SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

			try
			{
				conn.Open();
				dataAdapter.Update(dataSet);
				return true;
			}
			catch(Exception ex)
			{
				LogError(conn, "DataAccess.UpdateDatabase", "Embedded SQL Text", @QueryString, ex.Message);
				throw ex;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		#endregion /***** Database Access *****/

		#region /***** Get Database Schema Info *****/

		//mam 102309 - method now in DataAccessOleDb
		//		public DataTable GetFields(string specificTableName)
		//		{
		//			string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
		//						new object[] {null, null, null, null});
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
		//						new object[] {null, null, specificTableName, null});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//					return null;
		//				else
		//					return schemaTable;
		//			}
		//			catch (OleDbException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		//mam 102309 - method now in DataAccessOleDb
		//		public DataTable GetFields(string specificTableName, string databaseName)
		//		{
		//			string connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseName);
		//			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
		//						new object[] {null, null, null, null});
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
		//						new object[] {null, null, specificTableName, null});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//					return null;
		//				else
		//					return schemaTable;
		//			}
		//
		//			catch (OleDbException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		//mam 102309 - method now in DataAccessOleDb
		//		public DataTable GetTables(string specificTableName)
		//		{
		//			string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
		//						new object[] {null, null, null, "TABLE"});
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
		//						new object[] {null, null, specificTableName, "TABLE"});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//					return null;
		//				else
		//					return schemaTable;
		//			}
		//
		//			catch (OleDbException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		//mam 102309 - method now in DataAccessOleDb
		//		public DataTable GetTables(string specificTableName, string databaseName)
		//		{
		//			string connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseName);
		//			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
		//						new object[] {null, null, null, "TABLE"});
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
		//						new object[] {null, null, specificTableName, "TABLE"});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//					return null;
		//				else
		//					return schemaTable;
		//			}
		//
		//			catch (OleDbException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		//mam 102309 - not used
		//		public DataTable GetPrimaryKeys(string specificTableName)
		//		{
		//			//mam 102309
		//			//string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		//			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
		//			SqlConnection sqlConnection = new SqlConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					return null;
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, 
		//						new object[] {null, null, specificTableName});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//				{
		//					return null;
		//				}
		//				else
		//				{
		//					return schemaTable;
		//				}
		//			}
		//			//mam 102309
		//			//catch (OleDbException ex)
		//			catch (SqlException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(
		//					String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		#endregion /***** Get Database Schema Info *****/

		#region IDisposable Members

		public void Dispose()
		{
			// TODO:  Add DataAccess.Dispose implementation
		}

		#endregion
	}
}
