//mam 102309

using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for DataAccessOleDb.
	/// </summary>
	public class DataAccessOleDb
	{
		#region /***** Member Variables *****/

		private string connectionString = WAM.Data.WamSourceOleDb.CurrentSource.ConnectionString;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public DataAccessOleDb()
		{
		}

		#endregion /***** Construction *****/

		#region /***** Database Access *****/


		public OleDbCommand GetCommandObject()
		{
			OleDbConnection conn = new OleDbConnection(@connectionString);

			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				return cmd;
			}
			catch
			{
				return null;
			}
		}

		public OleDbCommand GetCommandObject(string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);

			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				return cmd;
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return null;
			}
		}

		public bool ExecuteCommand(string ExecuteStatement)
		{
			OleDbConnection conn = new OleDbConnection(@connectionString);

			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return false;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public bool ExecuteCommand(string ExecuteStatement, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(@useConnectionString);

			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return false;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public int ExecuteCommandReturnAutoID(string ExecuteStatement)
		{
			OleDbConnection conn = new OleDbConnection(@connectionString);

			try
			{
				int returnID = 0;
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				cmd.CommandText = "SELECT @@Identity";
				returnID = (int)cmd.ExecuteScalar();

				return returnID;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return 0;
		}

		public int ExecuteCommandReturnAutoID(string ExecuteStatement, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);

			try
			{
				int returnID = 0;
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				cmd.CommandText = "SELECT @@Identity";
				returnID = (int)cmd.ExecuteScalar();

				return returnID;
			}
			catch
			{
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return 0;
		}

		public System.Data.DataTable GetDisconnectedDataTable(string QueryString)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(@connectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);

				adapter.Fill(dataTable);

				return dataTable;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataTable GetDisconnectedDataTable(string QueryString, string useConnectionString)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(@useConnectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);

				adapter.Fill(dataTable);
				
				return dataTable;
			}

			catch
			{
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataSet GetDisconnectedDataset(string QueryString)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(@connectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);

				adapter.Fill(dataSet);
				
				return dataSet;
			}

			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public System.Data.DataSet GetDisconnectedDataset(string QueryString, string useConnectionString)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(useConnectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);

				adapter.Fill(dataSet);
				
				return dataSet;
			}

			catch
			{
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString)
		{
			OleDbConnection conn = new OleDbConnection(@connectionString);
			OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
			dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
			OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);

			try
			{
				conn.Open();
				dataAdapter.Update(dataSet);
				return true;
			}
			catch
			{
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return false;
		}

		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);
			OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
			dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
			OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);

			try
			{
				conn.Open();
				dataAdapter.Update(dataSet);
				return true;
			}
			catch
			{
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return false;
		}

		#endregion /***** Database Access *****/

		#region /***** Get Database Schema Info *****/

//		public DataTable GetFields(string specificTableName)
//		{
//			string connectionString = WAM.Data.WamSourceOleDb.CurrentSource.ConnectionString;
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
//
//			DataTable schemaTable;
//
//			try
//			{
//				sqlConnection.Open();
//
//				if (specificTableName == "")
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
//						new object[] {null, null, null, null});
//				}
//				else
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
//						new object[] {null, null, specificTableName, null});
//				}
//
//				if (schemaTable.Rows.Count == 0)
//					return null;
//				else
//					return schemaTable;
//			}
//			catch (OleDbException ex)
//			{
//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
//				return null;
//			}
//			finally
//			{
//				if (sqlConnection!= null)
//				{
//					if (sqlConnection.State == ConnectionState.Open)
//						sqlConnection.Close();
//				}
//
//				sqlConnection.Dispose();
//			}
//		}

		public DataTable GetFields(string specificTableName, string databaseName)
		{
			string connectionString = WAM.Data.WamSourceOleDb.SelectedDBConnectionString(databaseName);
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);

			DataTable schemaTable;

			try
			{
				sqlConnection.Open();

				if (specificTableName == "")
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
						new object[] {null, null, null, null});
				}
				else
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
						new object[] {null, null, specificTableName, null});
				}

				if (schemaTable.Rows.Count == 0)
					return null;
				else
					return schemaTable;
			}

			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
				return null;
			}
			finally
			{
				if (sqlConnection!= null)
				{
					if (sqlConnection.State == ConnectionState.Open)
						sqlConnection.Close();
				}

				sqlConnection.Dispose();
			}
		}

		public DataTable GetTables(string specificTableName)
		{
			string connectionString = WAM.Data.WamSourceOleDb.CurrentSource.ConnectionString;
			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);

			DataTable schemaTable;

			try
			{
				sqlConnection.Open();

				if (specificTableName == "")
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, null, "TABLE"});
				}
				else
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, specificTableName, "TABLE"});
				}

				if (schemaTable.Rows.Count == 0)
					return null;
				else
					return schemaTable;
			}

			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
				return null;
			}
			finally
			{
				if (sqlConnection!= null)
				{
					if (sqlConnection.State == ConnectionState.Open)
						sqlConnection.Close();
				}

				sqlConnection.Dispose();
			}
		}

		public DataTable GetTables(string specificTableName, string databaseName)
		{
			string connectionString = WAM.Data.WamSourceOleDb.SelectedDBConnectionString(databaseName);
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);

			DataTable schemaTable;

			try
			{
				sqlConnection.Open();

				if (specificTableName == "")
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, null, "TABLE"});
				}
				else
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, specificTableName, "TABLE"});
				}

				if (schemaTable.Rows.Count == 0)
					return null;
				else
					return schemaTable;
			}

			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
				return null;
			}
			finally
			{
				if (sqlConnection!= null)
				{
					if (sqlConnection.State == ConnectionState.Open)
						sqlConnection.Close();
				}

				sqlConnection.Dispose();
			}
		}

		//mam 102309 - not used
		//		public DataTable GetPrimaryKeys(string specificTableName)
		//		{
		//			//mam 102309
		//			//string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		//			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
		//			SqlConnection sqlConnection = new SqlConnection(connectionString);
		//
		//			DataTable schemaTable;
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//
		//				if (specificTableName == "")
		//				{
		//					return null;
		//				}
		//				else
		//				{
		//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, 
		//						new object[] {null, null, specificTableName});
		//				}
		//
		//				if (schemaTable.Rows.Count == 0)
		//				{
		//					return null;
		//				}
		//				else
		//				{
		//					return schemaTable;
		//				}
		//			}
		//			//mam 102309
		//			//catch (OleDbException ex)
		//			catch (SqlException ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(
		//					String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
		//				return null;
		//			}
		//			finally
		//			{
		//				if (sqlConnection!= null)
		//				{
		//					if (sqlConnection.State == ConnectionState.Open)
		//						sqlConnection.Close();
		//				}
		//
		//				sqlConnection.Dispose();
		//			}
		//		}

		#endregion /***** Get Database Schema Info *****/
	}
}
