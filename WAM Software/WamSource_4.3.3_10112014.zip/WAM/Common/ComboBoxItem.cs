using System;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for ComboBoxItem.
	/// </summary>
	public class ComboBoxItem
	{
		private int itemID;
		private int enumValue;
		private string itemDescription;
		private string itemTag = "";
		private string itemExtra1 = "";
		private string itemExtra2 = "";

		public ComboBoxItem(int itemID, string itemDescription, int enumValue, string itemTag)
		{
			this.itemID = itemID;
			this.itemDescription = itemDescription;
			this.enumValue = enumValue;
			this.itemTag = itemTag;
		}

		public ComboBoxItem(int itemID, string itemDescription, int enumValue, string itemTag, string itemExtra1, string itemExtra2)
		{
			this.itemID = itemID;
			this.itemDescription = itemDescription;
			this.enumValue = enumValue;
			this.itemTag = itemTag;
			this.itemExtra1 = itemExtra1;
			this.itemExtra2 = itemExtra2;
		}

		public int ItemID
		{
    		get
			{
				return itemID ;
			}
		}

		public string ItemDescription
		{
			get
			{
				return itemDescription;
			}
		}

		public int EnumValue
		{
			get
			{
				return enumValue;
			}
		}


		public string ItemTag
		{
			get
			{
				return itemTag;
			}
		}

		public string ItemExtra1
		{
			get
			{
				return itemExtra1;
			}
		}

		public string ItemExtra2
		{
			get
			{
				return itemExtra2;
			}
			set
			{
				itemExtra2 = value;
			}
		}

		public override string ToString()
		{
			return this.ItemID + " - " + this.ItemDescription;
			//return this.ItemTag;
		}
	}
}
