using System;
using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using C1.Win.C1FlexGrid;
using System.Text;


namespace WAM.Common
{
	/// <summary>
	/// GridEvents class handles grid events from the Projected Flows historical grids (Domestic, Industrial, and Other Pollutants)
	/// </summary>
	public class GridEventsCopyPaste
	{
		#region /***** Variables *****/

		private Form parentForm = null;
		private Form mainMDIForm = null;
		private bool restrictCopyingToSelectedCells = true;

		#endregion /***** Variables *****/

		#region /***** Construction and Disposal *****/

		public GridEventsCopyPaste()
		{
		}

		public GridEventsCopyPaste(Form parentForm)
		{
			this.parentForm = parentForm;
			this.mainMDIForm = parentForm.ParentForm;
		}

		public GridEventsCopyPaste(Form parentForm, bool copyFromGridErrorForm)
		{
			this.parentForm = parentForm;
			this.mainMDIForm = parentForm.ParentForm;
		}

		#endregion /***** Construction and Disposal *****/

		#region /***** Grid Copy/Paste Event Handler *****/

		public string CopySelector(Control controlFocus, bool sysSep, bool includeHiddenColumnData, 
			bool includeHeader, bool setToClipboard, bool copyAllVisibleGridCells, bool appendQuotes, bool forCSV)
		{
			if (controlFocus is TextBox)
			{
				return CopyDataFromTextBox((TextBox)controlFocus);
			}
			else if (controlFocus is C1FlexGrid)
			{
				return CopyDataFromGrid((C1FlexGrid)controlFocus, sysSep, includeHiddenColumnData, includeHeader, 
					setToClipboard, copyAllVisibleGridCells, appendQuotes, forCSV);
			}
			return string.Empty;
		}

		public bool PasteSelector(object controlFocus)
		{
			try
			{
				if (controlFocus is TextBox)
				{
					return PasteToTextBox((TextBox)controlFocus);
				}
				else if (controlFocus is C1FlexGrid)
				{
					return PerformPasteActions((C1FlexGrid)controlFocus);
				}
				return true;
			}
			catch
			{
				return false;
			}
		}

		public bool PasteToTextBox(TextBox controlFocus)
		{
			try
			{
				//don't ask whether to overwrite existing text
				//if(((TextBox)controlFocus).SelectionLength > 0)
				//{
				//	//verify pasting over currently selected text
				//	string msgText = "The selected text in the box will be overwritten.  Do you want to continue pasting?";
				//
				//	if (MessageBox.Show(msgText, "Paste Text", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
				//	{
				//		return true;
				//	}
				//}

				//paste text from the clipboard into the text box
				((TextBox)controlFocus).Paste();

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error occurred: " + ex.Message.ToString());
				return false;
			}
		}

		public void gridKeyUpCopyPasteHandler(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			bool copyFromGrid = false;
			bool pasteToGrid = false;

			switch (e.KeyCode)
			{
				case Keys.Delete:
					if (e.Modifiers == Keys.Shift)
					{
						copyFromGrid = true;
					}
					break;
				case Keys.Insert:
					if (e.Modifiers == Keys.Control)
					{
						copyFromGrid = true;
					}
					else if (e.Modifiers == Keys.Shift)
					{
						pasteToGrid = true;
					}
					break;
				case Keys.C: //copy
					if (e.Modifiers == Keys.Control)
					{
						copyFromGrid = true;
					}
					break;
				case Keys.V: //paste
					if (e.Modifiers == Keys.Control)
					{
						pasteToGrid = true;
					}
					break;
				default:
					break;
			}

			if (copyFromGrid)
			{
				CopyDataFromGrid((C1FlexGrid)sender, true, false, false, true, false, false, false);
			}
			else if (pasteToGrid)
			{
				PerformPasteActions(sender);
			}
		}

		private bool PerformPasteActions(object sender)
		{
			try
			{
				//if (MPM.Common.Globals.ScenarioIsLocked)
				//{
				//	return true;
				//}

				//paste data into grid
				C1FlexGrid gridClip = new C1FlexGrid();
				gridClip.Size = new System.Drawing.Size(312, 112);
				gridClip.Visible = false;

				string clip = string.Empty;

				if (GetDataFromClipboard(ref gridClip, ref clip))
				{
					//allow all data to be pasted, whether it is valid or not
					//bool okToPaste = true;

					bool okToPaste = ValidateDataToBeCopiedIntoGrid((C1FlexGrid)sender, gridClip, false);
					if (!okToPaste)
					{
						WAM.UI.GridPasteErrors gridPasteErrors = new WAM.UI.GridPasteErrors(
							parentForm, gridClip, clip, gridClip.Rows.Count, gridClip.Cols.Count);
						gridPasteErrors.ShowDialog(parentForm.ParentForm);
					}

					if (okToPaste)
					{
						PasteDataIntoGrid((C1FlexGrid)sender, gridClip, false);
					}
				}
				return true;
			}
			catch
			{
				return false;
			}
		}

		public void gridKeyUpCopyPasteHandlerCopyOnly(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			bool copyFromGrid = false;

			switch (e.KeyCode)
			{
				case Keys.Delete:
					if (e.Modifiers == Keys.Shift)
					{
						copyFromGrid = true;
					}
					break;
				case Keys.Insert:
					if (e.Modifiers == Keys.Control)
					{
						copyFromGrid = true;
					}
					break;
				case Keys.C: //copy
					if (e.Modifiers == Keys.Control)
					{
						copyFromGrid = true;
					}
					break;
				default:
					break;
			}

			if (copyFromGrid)
			{
				CopyDataFromGrid((C1FlexGrid)sender, true, false, false, true, false, false, false);
			}
		}

		private string CopyDataFromTextBox(TextBox textBox)
		{
			try
			{
				//if any text is selected in the textbox, copy it to the clipboard
				if(textBox.SelectionLength > 0)
				{
					textBox.Copy();
					if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
					{
						return (string)Clipboard.GetDataObject().GetData(typeof(string));
					}
					else
					{
						return string.Empty;
					}
				}
				else
				{
					return string.Empty;
				}
			}
			catch
			{
				return string.Empty;
			}
		}

		private string CopyDataFromGrid(C1FlexGrid grid, bool sysSep, bool includeHiddenColumnData, 
			bool includeHeader, bool setToClipboard, bool copyAllVisibleGridCells, bool appendQuotes, bool forCSV)
		{
			try
			{
				//copy selected data from the grid

				//get user-selected range of cells
				CellRange cellRangeSelection = grid.Selection;
				string rowSep = Environment.NewLine;
				char colSep = (char)Keys.Tab;

				if (forCSV)
				{
					colSep = Convert.ToChar(",");
				}

				if (copyAllVisibleGridCells)
				{
					//get all visible cells, regardless of grid.Selection
					cellRangeSelection = grid.GetCellRange(grid.Rows.Fixed, grid.Cols.Fixed, grid.Rows.Count - 1, grid.Cols.Count - 1);
				}

				cellRangeSelection.Normalize();
				int colStop = cellRangeSelection.c2;
				string curValue = string.Empty;

				StringBuilder stringBuilder = new StringBuilder();

				// add header row cell data, if necessary
				if (includeHeader && grid.Rows.Fixed > 0)
				{
					CellRange cellRangeHeader = grid.GetCellRange(0, 0, grid.Rows.Fixed - 1, grid.Cols.Count-1);
					cellRangeHeader.Normalize();

					for (int row = cellRangeHeader.r1; row <= cellRangeHeader.r2; row++)
					{
						if (row > cellRangeHeader.r1) 
						{
							stringBuilder.Append(rowSep);
						}
						for (int col = cellRangeHeader.c1; col <= colStop; col++)
						{
							if ((includeHiddenColumnData || (!includeHiddenColumnData && grid.Cols[col].Visible))
								&& grid[row, col] != null && grid[row, col].ToString().Trim().Length > 0)
							{
								curValue = grid.GetDataDisplay(row, col).ToString();
								curValue = curValue.Replace("\r\n", " ");
								if (appendQuotes)
								{
									stringBuilder.Append("\"" + curValue + "\"");
								}
								else
								{
									stringBuilder.Append(curValue);
								}
								if (col < colStop)
								{
									stringBuilder.Append(colSep);
								}
							}
						}
					}
				}

				//remove trailing column separator character
				if (stringBuilder.Length > 0 && stringBuilder.ToString().EndsWith(colSep.ToString()))
				{
					stringBuilder.Remove(stringBuilder.Length - 1, 1);
				}

				//if the headers have been added, append a line return character to separate the header row(s) from the data
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(rowSep);
				}

				//add each cell's data
				for (int row = cellRangeSelection.r1; row <= cellRangeSelection.r2; row++)
				{
					//don't include rows with height < 10 because they are not text rows
					if (grid.Rows[row].HeightDisplay < 10)
					{
						continue;
					}

					//add a row separator charactor if necessary
					if (row > cellRangeSelection.r1) 
					{
						stringBuilder.Append(rowSep);
					}

					for (int col = cellRangeSelection.c1; col <= cellRangeSelection.c2; col++)
					{
						if (includeHiddenColumnData || (!includeHiddenColumnData && grid.Cols[col].Visible))
						{
//							if (grid.Cols[col].DataType == typeof(Boolean))
//							{
//								MessageBox.Show(grid.GetDataDisplay(row, col).ToString());
//								if (Convert.ToInt32(grid.GetDataDisplay(row, col)) == 0)
//								{
//									stringBuilder.Append(0);
//								}
//								else
//								{
//									stringBuilder.Append(1);
//								}
//							}
//							else
							{
								if (grid.Cols[col].Name == "DiscComponentInfo")
								{
									//the Discipline Component Info column is being copied
								}
								else if (appendQuotes)
								{
									stringBuilder.Append("\"" + grid.GetDataDisplay(row, col).ToString() + "\"");
								}
								else
								{
									stringBuilder.Append(grid.GetDataDisplay(row, col));
								}
							}
							if (col < cellRangeSelection.c2)
							{
								stringBuilder.Append(colSep);
							}
							else
							{
								stringBuilder.Append(colSep);
								
								//grid name is empty string if copying from GridPasteErrors grid
								if (grid.Name.Length > 0)
								{
									//add TempID to string so that when copying DisciplineType or DiscComponentInfo columns
									//	the discipline object can be created using TempID value
									stringBuilder.Append(grid.GetDataDisplay(row, grid.Cols["TempID"].Name));
								}
							}
						}
					}
				}

				//remove trailing column separator character
				if (stringBuilder.Length > 0 && stringBuilder.ToString().EndsWith(colSep.ToString()))
				{
					stringBuilder.Remove(stringBuilder.Length - 1, 1);
				}

				//put data on the clipboard
				if (setToClipboard)
				{
					Clipboard.SetDataObject(stringBuilder.ToString(), true);
				}

				return stringBuilder.ToString();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message.ToString());
				//MPM.Common.CommonTasks.ShowMessageBoxError(parentForm, "GridEventsCopyPaste.CopyDataFromGrid", ex.Message, "Error");
				return string.Empty;
			}
		}

		private bool GetDataFromClipboard(ref C1FlexGrid gridClip, ref string clip)
		{
			try
			{
				//get data from the clipboard
				IDataObject data = Clipboard.GetDataObject();
				if (data.GetDataPresent(typeof(string)))
				{
					clip = (string)data.GetData(typeof(string));

					//Remove the line return character at the end, if it exists
					//	(Excel appends a line return character)
					if (clip.EndsWith(Environment.NewLine))
					{
						clip = clip.Substring(0, clip.Length-2);
					}

					//read the clipboard contents with a StringReader
					System.IO.StringReader stringReader = new System.IO.StringReader(clip);
				
					gridClip.Rows.Count = 0;
					gridClip.Cols.Count = 0;
					int counter = 0;
					string rowData = string.Empty;

					//read the clipboard contents one line at a time
					while (stringReader.Peek() > 0)
					{
						rowData = stringReader.ReadLine();

						//when copying multiple rows, the end of each row may contain a column separator char
						char colSep = (char)Keys.Tab;
						if (rowData.Length > 0 && rowData.ToString().EndsWith(colSep.ToString()))
						{
							rowData = rowData.Remove(rowData.Length - 1, 1);
						}

						if (counter == 0)
						{
							//determine number of columns in the clipboard data
							string[] columnNumber = rowData.Split((char)Keys.Tab);
							gridClip.Cols.Count = columnNumber.Length;
							gridClip.Cols.Fixed = 0;
						}

						gridClip.Rows.Count++;
						counter++;
					}
					gridClip.Rows.Fixed = 0;
				
					//the gridClip grid now has the same number of rows and columns as the clipboard contents

					//select all cells in the gridClip grid
					gridClip.Select(gridClip.Row, gridClip.Col, gridClip.Rows.Count-1, gridClip.Cols.Count-1, false);

					//copy the clipboard contents into the gridClip grid
					gridClip.Clip = clip;

					//select the first cell in the grid (not for any real reason, just so the whole grid isn't selected)
					gridClip.Select(gridClip.Row, gridClip.Col, false);
				}

				return true;
			}
			catch
			{
				return false;
			}
		}

		private bool PasteDataIntoGrid(C1FlexGrid grid, C1FlexGrid gridClip, bool includeHiddenColumnData)
		{
			//copy data into the grid
			try
			{
				CellRange cellRangeSelection = grid.Selection;
				cellRangeSelection.Normalize();

				int gridRowIndexStart = cellRangeSelection.r1;
				int gridRowIndexStop = cellRangeSelection.r2;
				int gridColIndexStart = cellRangeSelection.c1;
				int gridColIndexStop = cellRangeSelection.c2;
				int gridCurRow = 0;
				int gridCurCol = 0;

				int rowCountGrid = gridRowIndexStop - gridRowIndexStart + 1;
				int colCountGrid = gridColIndexStop - gridColIndexStart + 1;
				int rowCountClip = gridClip.Rows.Count;
				int colCountClip = gridClip.Cols.Count;
				bool oneCellSelected = gridRowIndexStart == gridRowIndexStop && gridColIndexStart == gridColIndexStop;

				//if only one grid cell is selected, go ahead and paste the clip, no matter how many rows or cols it has

				//(subtract 1 from colCountClip because we are passing in the TempID column value along with the data to be pasted)
				//	(TempID value col is the last col in the clip)
				colCountClip--;

				//if multiple grid cells are selected and the row and col count does not match the clip row and col count, 
				//	alert the user to the mismatch, and ask whether to continue
				if (!oneCellSelected && (rowCountGrid < rowCountClip || colCountGrid < colCountClip))
				{
					StringBuilder builder = new StringBuilder(100);

					builder.Append("The data to be pasted has a different number of rows or columns than the selected area.");
					builder.Append("\r\n\r\nIf you select Yes, data will be pasted only into the selected area.");
					builder.Append("\r\n\r\nDo you want to paste the data?");

					DialogResult dialogResult = DialogResult.No;
					dialogResult = MessageBox.Show(builder.ToString(), "Paste Data into Grid", 
						MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

					if (dialogResult != DialogResult.Yes)
					{
						return true;
					}
				}

				//don't do this - it's causing problems with pasting one value to multiple cells
				if (!restrictCopyingToSelectedCells || oneCellSelected)
				{
					gridRowIndexStop = gridRowIndexStart + rowCountClip - 1;
					gridColIndexStop = gridColIndexStart + colCountClip - 1;

					//add 1 to gridColIndexStop for each hidden column in the grid
					for (int i = gridColIndexStart; i <= gridColIndexStart + colCountClip; i++)
					{
						if (!grid.Cols[i].Visible)
						{
							gridColIndexStop++;
						}
					}

					if (gridRowIndexStop > grid.Rows.Count - 1)
					{
						gridRowIndexStop = grid.Rows.Count - 1;
					}
					if (gridColIndexStop > grid.Cols.Count - 1)
					{
						gridColIndexStop = grid.Cols.Count - 1;
					}
				}

				for (int gridRow = gridRowIndexStart; gridRow <= gridRowIndexStop; gridRow++)
				{
					//gridCurRow tracks the current row number (starting with zero)
					//if the current row number exceeds the number of rows in the clip, 
					//	or the row is invisible, break
					if ((gridCurRow > gridClip.Rows.Count - 1 || !grid.Rows[gridRow].Visible)
						&& (gridClip.Rows.Count > 1 || colCountClip > 1))	//changed from gridClip.Cols.Count to colCountClip
					{
						if (gridClip.Rows.Count == 1)
						{
							gridCurRow = 0;
						}
						else
						{
							break;
						}
					}

					//if the row is not editable, but is visible, move on to the next row
					if (!grid.Rows[gridRow].AllowEditing && grid.Rows[gridRow].Visible)
					{
						gridCurRow++;
						break;
					}

					for (int gridCol = gridColIndexStart; gridCol <= gridColIndexStop; gridCol++)
					{
						//break if the current col index exceeds the number of columns in the clip
						//	(unless there is only one cell in the clip - if this is the case, copy that
						//	cell's value into all of the selected cells)
						if (gridCurCol > colCountClip - 1	//changed from gridClip.Cols.Count to colCountClip
							&& (gridClip.Rows.Count > 1 || colCountClip > 1))	//changed from gridClip.Cols.Count to colCountClip
						{
							break;
						}

						//MessageBox.Show(grid.Cols[gridCol].Name);

						if (grid.Cols[gridCol].Name == "DisciplineType" || grid.Cols[gridCol].Name == "DiscComponentInfo")
						{
							WAM.UI.Import.ImportFromTextFileDiscipline importDisciplineFrom = 
								((WAM.UI.Import.ImportFromTextFile)parentForm).GetDisciplineObject
								(Convert.ToInt32(gridClip[gridCurRow, gridClip.Cols.Count - 1]));
							WAM.UI.Import.ImportFromTextFileDiscipline importDisciplineTo = 
								((WAM.UI.Import.ImportFromTextFile)parentForm).GetDisciplineObject
								(Convert.ToInt32(grid[gridRow, grid.Cols["TempID"].Name]));

							if (grid.Cols[gridCol].Name == "DisciplineType")
							{
								grid[gridRow, gridCol] = gridClip[gridCurRow, gridCurCol];
								importDisciplineTo.DisciplineType = importDisciplineFrom.DisciplineType;
							}
							else
							{
								if (importDisciplineFrom.DisciplineType == WAM.UI.NodeType.DisciplineMech
									&& importDisciplineTo.DisciplineType == WAM.UI.NodeType.DisciplineMech)
								{
									importDisciplineFrom.CopyDisciplineMech(importDisciplineTo);
								}
								else if (importDisciplineFrom.DisciplineType == WAM.UI.NodeType.DisciplineStruct
									&& importDisciplineTo.DisciplineType == WAM.UI.NodeType.DisciplineStruct)
								{
									importDisciplineFrom.CopyDisciplineStruct(importDisciplineTo);
								}
								else if (importDisciplineFrom.DisciplineType == WAM.UI.NodeType.DisciplineLand
									&& importDisciplineTo.DisciplineType == WAM.UI.NodeType.DisciplineLand)
								{
									importDisciplineFrom.CopyDisciplineLand(importDisciplineTo);
								}
							}
						}
						else if (grid.Cols[gridCol].Visible && grid.Cols[gridCol].AllowEditing)
						//else if (grid.Cols[gridCol].Visible)
						{
							if (gridClip.Rows.Count == 1 && colCountClip == 1)	//changed from gridClip.Cols.Count to colCountClip
							{
								grid[gridRow, gridCol] = gridClip[0, 0];
							}
							else
							{
								//MessageBox.Show(grid[gridRow, gridCol].ToString());
								//MessageBox.Show(gridClip[gridCurRow, gridCurCol].ToString());
								//MessageBox.Show(grid.Cols[gridCol].Name);
								grid[gridRow, gridCol] = gridClip[gridCurRow, gridCurCol];
							}
						}

						if (grid.Cols[gridCol].Visible)
						{
							gridCurCol++;
						}
					}
					gridCurRow++;
					gridCurCol = 0;
				}

				//perform "after paste" tasks
				//MessageBox.Show("call SetGridRowImportCellStyleAfterPaste");
				((WAM.UI.Import.ImportFromTextFile)parentForm).SetGridRowImportCellStyleAfterPaste();

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error in CommonTasks.PasteDataIntoGrid:  " + ex.Message.ToString());
				return false;
			}
		}

		private bool ValidateDataToBeCopiedIntoGrid(C1FlexGrid grid, C1FlexGrid gridClip, bool includeHiddenColumnData)
		{
			//check to see whether any of the data to be copied into the grid is of the wrong data type
			try
			{
				CellRange cellRangeSelection = grid.Selection;
				cellRangeSelection.Normalize();

				int gridRowIndexStart = cellRangeSelection.r1;
				int gridRowIndexStop = cellRangeSelection.r2;
				int gridColIndexStart = cellRangeSelection.c1;
				int gridColIndexStop = cellRangeSelection.c2;
				int gridCurRow = gridClip.Rows.Fixed;
				int gridCurCol = 0;
				bool validData = true;

				//if copying is not restricted to the cells selected in the grid
				if (!restrictCopyingToSelectedCells)
				{
					gridRowIndexStop = grid.Rows.Count - 1;
					gridColIndexStop = grid.Cols.Count - 1;
				}

				for (int gridRow = gridRowIndexStart; gridRow < grid.Rows.Count; gridRow++)
				{
					//gridCurRow tracks the current row number (starting with the row below the last fixed row)
					//if the current row number exceeds the number of rows in the clip, 
					//	or the row is invisible, break
					if (gridCurRow > gridClip.Rows.Count - 1 || !grid.Rows[gridRow].Visible)
					{
						break;
					}

					//if the row is not editable, but is visible, move on to the next row
					if (!grid.Rows[gridRow].AllowEditing && grid.Rows[gridRow].Visible)
					{
						gridCurRow++;
						break;
					}

					for (int gridCol = gridColIndexStart; gridCol < grid.Cols.Count; gridCol++)
					{
						//break if the current col index exceeds the number of columns in the clip
						//subtract 2 rather than 1 to account for TempID col
						if (gridCurCol > gridClip.Cols.Count - 2)
						{
							break;
						}

						if (grid.Cols[gridCol].Visible && grid.Cols[gridCol].AllowEditing)
						{
							try
							{
								try
								{
									gridClip.Cols[gridCurCol].Name = grid[grid.Rows.Fixed - 1, gridCol].ToString();
								}
								catch
								{
								}

								if (grid.Cols[gridCol].DataMap != null)
								{
									//MessageBox.Show(grid.Cols[gridCol].Name.ToString());
									gridClip.Cols[gridCurCol].DataMap = grid.Cols[gridCol].DataMap;
									bool itemFound = false;
									string comboBoxText = gridClip[gridCurRow, gridCurCol].ToString();

									IDictionaryEnumerator idEnumerator = grid.Cols[gridCol].DataMap.GetEnumerator();
									while (idEnumerator.MoveNext())
									{
										if (idEnumerator.Value.ToString().ToUpper().Equals(comboBoxText.ToUpper()))
										{
											itemFound = true;
											break;
										}
									}
									if (itemFound)
									{
										if (grid.Cols[gridCol].Name == "FacilityName"
											|| grid.Cols[gridCol].Name == "ProcessName"
											|| grid.Cols[gridCol].Name == "ComponentName")
										{
											gridClip[gridCurRow, gridCurCol] = idEnumerator.Value;
										}
										else
										{
											gridClip[gridCurRow, gridCurCol] = idEnumerator.Key;
										}
									}
									else
									{
										validData = false;
										CellRange cellRangeNotValid = gridClip.GetCellRange(gridCurRow, gridCurCol);
										cellRangeNotValid.UserData = "-1";
									}
								}
								else
								{
									//MessageBox.Show(grid.Cols[gridCol].Name.ToString());
//									MessageBox.Show(grid.Cols[gridCol].DataType.ToString());
//									switch(grid.Cols[gridCol].DataType.ToString())
//									{
//										case "System.Double":
//											double curValueDouble = double.Parse(gridClip[gridCurRow, gridCurCol].ToString(), System.Globalization.NumberStyles.Any);
//											break;
//										case "System.Int32":
//											int curValueInt = Int32.Parse(gridClip[gridCurRow, gridCurCol].ToString(), System.Globalization.NumberStyles.Any);
//											break;
//										case "System.Int16":
//											int curValueInt16 = Int16.Parse(gridClip[gridCurRow, gridCurCol].ToString(), System.Globalization.NumberStyles.Any);
//											break;
//										case "System.Decimal":
//											decimal curValueDecimal = decimal.Parse(gridClip[gridCurRow, gridCurCol].ToString(), System.Globalization.NumberStyles.Any);
//											break;
//										case "System.DateTime":
//											DateTime curValueDateTime = DateTime.Parse(gridClip[gridCurRow, gridCurCol].ToString());
//											break;
//										case "System.String":
//											break;
//										case "System.Boolean":
//											if (gridClip[gridCurRow, gridCurCol].ToString().Trim().ToUpper() == "TRUE"
//												|| gridClip[gridCurRow, gridCurCol].ToString().Trim().ToUpper() == "FALSE")
//											{
//												bool curValueBoolean = Boolean.Parse(gridClip[gridCurRow, gridCurCol].ToString().Trim());
//												if (curValueBoolean)
//												{
//													gridClip[gridCurRow, gridCurCol] = 1;
//												}
//												else
//												{
//													gridClip[gridCurRow, gridCurCol] = 0;
//												}
//											}
//											else
//											{
//												bool curValueBoolean = Convert.ToBoolean(Convert.ToInt32(gridClip[gridCurRow, gridCurCol]));
//											}
//											break;
//										default:
//											MessageBox.Show("Grid data type not found");
//											break;
//									}
								}
							}
							catch
							{
								validData = false;
								CellRange cellRangeNotValid = gridClip.GetCellRange(gridCurRow, gridCurCol);
								cellRangeNotValid.UserData = "-1";
							}
						}

						if (grid.Cols[gridCol].Visible)
						{
							gridCurCol++;
						}
					}
					gridCurRow++;
					gridCurCol = 0;
				}

				if (!validData)
				{
					return false;
				}

				return true;
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error in CommonTasks.ValidDataToBePastedIntoGrid:  " + ex.Message.ToString());
				return false;
			}
		}

		#endregion /***** Grid Copy/Paste Event Handler *****/
	}
}
