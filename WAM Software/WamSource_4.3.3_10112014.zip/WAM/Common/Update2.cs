using System;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Update2.
	/// </summary>
	/// 

	public class Update2
	{
		#region /***** Member Variables *****/

		UpdateDataAccess dataAccess = new UpdateDataAccess();
		OleDbCommand cmd = null;
		DataSet dataSet = new DataSet();
		DataTable dataTable = new DataTable();
		ArrayList resultLogUpdate2 = new ArrayList();

		private int keyCount = 0;
		private int indexCount = 0;
		private string useConnectionString;

		#endregion /***** Member Variables *****/

		#region /***** Methods *****/

		bool update2PreviouslyApplied = false;

		public Update2(string connectionString)
		{
			useConnectionString = connectionString;
		}

		private int NextKey()
		{
			keyCount += 1;
			return keyCount;
		}

		private int NextIndex()
		{
			indexCount += 1;
			return indexCount;
		}

		public bool PerformUpdate()
		{
			// perform database updates
			try
			{
				//if a connection can't be opened, exit
				//	(return true regardless of error)
				if (OpenConnectionForUpdating())
				{
					CreateCustomENRList();
					//ReplaceCustomENRTable();
					UpdateNodeType();
					UpdateCustomENRTable();
					CreateComboReportLevel();
					ConsolidationHandler();
					CreateDefaultCustomENRTable();
					UpdateReportTemplateTable();
				}
				Cleanup();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Methods *****/

		#region /***** Update2 Methods *****/

		private bool OpenConnectionForUpdating()
		{
			StringBuilder builder = new StringBuilder(200);

			// open a connection
			try
			{
				resultLogUpdate2.Add("OpenConnectionForUpdating start");
				cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogUpdate2.Add("OpenConnectionForUpdating not attempted");
					return false;
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("OpenConnectionForUpdating failed on create OleDbCommand");
			}
			return true;
		}

		private bool CreateCustomENRList()
		{
			// create the CustomENRList table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				dataTable = dataAccess.GetTables("CustomENRList", useConnectionString);
				if (dataTable == null)
				{
					//the table does not exist, so go ahead and add it

					resultLogUpdate2.Add("Table CustomENRList start");

					builder.Append(@"CREATE TABLE CustomENRList (CustomENRListID IDENTITY(1,1) CONSTRAINT U2Key"); 
					builder.Append(NextKey());
					
					builder.Append(" PRIMARY KEY, InfosetID INTEGER,");

					builder.Append(" CustomENRListName VARCHAR (255) WITH COMPRESSION NOT NULL)");
				
					cmd.CommandText = @builder.ToString();
					cmd.ExecuteNonQuery();

					cmd.CommandText = @"CREATE INDEX U2Index" + NextIndex() + " ON CustomENRList (InfosetID)";
					cmd.ExecuteNonQuery();
				}
				else
				{
					update2PreviouslyApplied = true;
					resultLogUpdate2.Add("Table CustomENRList not attempted");
					return true;
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("CustomENRList table not created");
				return false;
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR Create CustomENRList table stop");
			}

			ReplaceCustomENRTable();

			//add the CustomENRListID field to the Facilities table
			UpdateFacilitiesTable();

			//add the CustomENRListID field to the CustomENR table
			AddCustomENRListID();

			//populate the CustomENRList table
			DataPopulationCustomENRList();

			return true;
		}
		
		private bool UpdateFacilitiesTable()
		{
			// add the CustomENRListID field to the Facilities table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("UpdateCustomENR Add CustomENRListID to Facilities table start");

				//builder.Append("ALTER TABLE Facilities ADD COLUMN CustomENRListID LONG NOT NULL CONSTRAINT U2Key");
				builder.Append("ALTER TABLE Facilities ADD COLUMN CustomENRListID LONG CONSTRAINT U2Key");
				builder.Append(NextKey());
				//builder.Append(" REFERENCES CustomENRList (CustomENRListID) ON UPDATE CASCADE ON DELETE CASCADE");
				builder.Append(" REFERENCES CustomENRList (CustomENRListID)");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("CustomENRListID field not created in Facilities table");
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR Add CustomENRListID to Facilities table stop");
			}
			return true;
		}
		
		private bool ReplaceCustomENRTable()
		{
			// replace the CustomENR table with one that doesn't have primary keys
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("UpdateCustomENR replace CustomENR table start");

				// create a new table to hold the CustomENR data
				builder.Append("SELECT C.facility_id, C.enr_year, C.enr_value INTO CustomENR2 FROM CustomENR C");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				// delete table CustomENR
				builder.Remove(0, builder.Length);
				builder.Append("DROP TABLE CustomENR");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				// copy info from CustomENR2 to CustomENR
				builder.Remove(0, builder.Length);
				builder.Append("SELECT C.facility_id, C.enr_year, C.enr_value INTO CustomENR FROM CustomENR2 C");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				// delete table CustomENR2
				builder.Remove(0, builder.Length);
				builder.Append("DROP TABLE CustomENR2");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("CustomENR table not replaced");
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR replace CustomENR table stop");
			}
			return true;
		}

		private bool AddCustomENRListID()
		{
			// add the CustomENRListID field to the CustomENR table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("UpdateCustomENR Add CustomENRListID to CustomENR table start");

				builder.Append("ALTER TABLE CustomENR ADD COLUMN CustomENRListID LONG NOT NULL CONSTRAINT U2Key");
				builder.Append(NextKey());
				builder.Append(" REFERENCES CustomENRList (CustomENRListID) ON UPDATE CASCADE ON DELETE CASCADE");
				
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("CustomENRListID field not created in CustomENR table");
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR Add CustomENRListID to CustomENR table stop");
			}
			return true;
		}

		private bool DataPopulationCustomENRList()
		{
			// populate the CustomENRList table

			//DataSet dataSet = new DataSet();
			int customENRID = 0;
			int curFacID = 0;
			string customENRListName = "";
			string executeString = "";
			StringBuilder builder = new StringBuilder(200);

			//**********

			// get a list of Facility IDs that are currently using custom ENR tables
			string queryString = "";
			builder.Append(@"SELECT DISTINCT C.facility_id, I.infoset_id, F.facility_name, I.infoset_name");
			builder.Append(" FROM (CustomENR AS C LEFT JOIN Facilities AS F ON C.facility_id=F.facility_id)");
			builder.Append(" LEFT JOIN InfoSets AS I ON F.infoset_id=I.infoset_ID");
			builder.Append(" ORDER BY C.facility_id;");
			queryString = builder.ToString();
			System.Diagnostics.Debug.WriteLine("queryString = {0}", queryString);

			DataSet dataSetFac = new DataSet();
			dataSetFac = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
			if (dataSetFac == null)
			{
				//no dataset returned
				System.Diagnostics.Debug.WriteLine("dataSetFac is null");
				return false;
			}

			//**********
			
			// get the blank CustomENRList table			
			queryString = @"SELECT * FROM CustomENRList";
			dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
			if (dataSet == null)
			{
				//no dataset returned
				System.Diagnostics.Debug.WriteLine("CustomENRList table not found");
				return false;
			}

			dataTable = dataAccess.GetTables("CustomENRList", useConnectionString);
			if (dataTable != null)
			{
				queryString = @"SELECT * FROM CustomENRList";
				dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
				if (dataSet == null)
				{
					System.Diagnostics.Debug.WriteLine("CustomENRList table not found");
					return false;
				}
				if (dataSet.Tables[0].Rows.Count > 0)
				{
					resultLogUpdate2.Add("Data Population Table CustomENRList not completed - table already has data");
					return false;
				}

				resultLogUpdate2.Add("Data Population Table CustomENRList start");
				foreach (DataRow dataRowFac in dataSetFac.Tables[0].Rows)
				{
					//customENRListName = dataRowFac["infoset_name"].ToString() + " - " + dataRowFac["facility_name"].ToString();
					customENRListName = dataRowFac["facility_name"].ToString();
					if (customENRListName.Length > 255)
						customENRListName = customENRListName.Substring(255);
					curFacID = Convert.ToInt32(dataRowFac["facility_id"].ToString());

					customENRID = 0;

					builder.Remove(0, builder.Length);
					builder.Append(@"INSERT INTO CustomENRList (InfosetID, CustomENRListName)");
					builder.AppendFormat(@" VALUES ({0}, '{1}')", dataRowFac["infoset_id"], Drive.SQL.PadString(customENRListName));
					executeString = builder.ToString();
					customENRID = dataAccess.ExecuteCommandReturnAutoID(executeString, useConnectionString);
					if (customENRID != 0)
					{
						try
						{
							// add the new ID to the CustomENR and Facilities tables
							builder.Remove(0, builder.Length);
							builder.AppendFormat(@"UPDATE Facilities SET CustomENRListID = {0}", customENRID);
							builder.AppendFormat(@" WHERE facility_id = {0}", curFacID);
							dataAccess.ExecuteCommand(builder.ToString(), useConnectionString);
					
							builder.Remove(0, builder.Length);
							builder.AppendFormat(@"UPDATE CustomENR SET CustomENRListID = {0}", customENRID);
							builder.AppendFormat(@" WHERE facility_id = {0}", curFacID);
							dataAccess.ExecuteCommand(builder.ToString(), useConnectionString);
						}
						catch(Exception ex)
						{
							System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
						}
					}
				}
			}
			return true;
		}

		private bool UpdateNodeType()
		{
			// create the NodeType table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("Table NodeType start");

				builder.Append(@"CREATE TABLE NodeType (NodeTypeID LONG NOT NULL PRIMARY KEY,");
				builder.Append(" NodeType VARCHAR (50) WITH COMPRESSION NOT NULL,");
				builder.Append(" NodeTypeText VARCHAR (100) WITH COMPRESSION NOT NULL,");
				builder.Append(" SortBy INTEGER NOT NULL)");
				
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON NodeType (NodeTypeID)";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("NodeType table not created");
				// if there is an error, then either the table already exists, or there was an error while attempting
				//	to create it, so there is no point in continuing
				//return false;
				return false;
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR create NodeType table stop");
			}

			//populate the NodeType table
			DataPopulationNodeType();

			return true;
		}

		private bool DataPopulationNodeType()
		{
			//populate the NodeType table
			// note: should get these values from the enum

			dataTable = dataAccess.GetTables("NodeType", useConnectionString);
			if (dataTable != null)
			{
				dataSet = new DataSet();
				string queryString = @"SELECT * FROM NodeType";
				dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
				if (dataSet == null)
				{
					throw new Exception("Database Error.  Update2.DataPopulationNodeType");
				}

				if (dataSet.Tables[0].Rows.Count > 0)
				{
					resultLogUpdate2.Add("Data Population Table NodeType not completed - table already has data");
					//return true;
				}
				else
				{
					DataRow dataRow;

					try
					{
						resultLogUpdate2.Add("Data Population Table NodeType start");

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 0;
						dataRow["NodeType"] = "InfoSet";
						dataRow["NodeTypeText"] = "InfoSet";
						dataRow["SortBy"] = 0;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 1;
						dataRow["NodeType"] = "Facility";
						dataRow["NodeTypeText"] = "Facility / System";
						dataRow["SortBy"] = 1;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 2;
						dataRow["NodeType"] = "TreatmentProcess";
						dataRow["NodeTypeText"] = "Process / Basin / Zone";
						dataRow["SortBy"] = 2;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 3;
						dataRow["NodeType"] = "MajorComponent";
						dataRow["NodeTypeText"] = "Component / Subbasin / Subzone";
						dataRow["SortBy"] = 3;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 255;
						dataRow["NodeType"] = "Discipline";
						dataRow["NodeTypeText"] = "Discipline: All";
						dataRow["SortBy"] = 4;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 4;
						dataRow["NodeType"] = "DisciplineMech";
						dataRow["NodeTypeText"] = "Discipline: Mech / Elec / Instr / Piping";
						dataRow["SortBy"] = 5;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 5;
						dataRow["NodeType"] = "DisciplineStruct";
						dataRow["NodeTypeText"] = "Discipline: Struct / Arch";
						dataRow["SortBy"] = 6;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 6;
						dataRow["NodeType"] = "DisciplineLand";
						dataRow["NodeTypeText"] = "Discipline: Site / Land / Other";
						dataRow["SortBy"] = 7;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 7;
						dataRow["NodeType"] = "DisciplinePipe";
						dataRow["NodeTypeText"] = "Discipline: Pipes";
						dataRow["SortBy"] = 8;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 8;
						dataRow["NodeType"] = "DisciplineNode";
						dataRow["NodeTypeText"] = "Discipline: Nodes / Appurtenances";
						dataRow["SortBy"] = 9;
						dataSet.Tables[0].Rows.Add(dataRow);

						dataRow = dataSet.Tables[0].NewRow();
						dataRow["NodeTypeID"] = 9;
						dataRow["NodeType"] = "AssetList";
						dataRow["NodeTypeText"] = "Asset List";
						dataRow["SortBy"] = 10;
						dataSet.Tables[0].Rows.Add(dataRow);

						bool result = dataAccess.UpdateDatabase(dataSet, queryString, useConnectionString);
						if (!result)
							resultLogUpdate2.Add("Data Population Table NodeType not completed");
					}
					catch(Exception ex)
					{
						System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
						resultLogUpdate2.Add("Data Population Table NodeType not completed");
					}
					finally
					{
						resultLogUpdate2.Add("Data Population Table NodeType stop");
					}
				}
			}
			return true;
		}

		private bool UpdateCustomENRTable()
		{
			//remove facility_id field from CustomENR table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("UpdateCustomENR Remove facility_id field from CustomENR table start");

				builder.Append("ALTER TABLE CustomENR DROP COLUMN facility_id");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("facility_id field not removed from CustomENR table");
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR Remove facility_id field from CustomENR table stop");
			}

			// add the CustomENRID field to the CustomENR table
			try
			{
				builder.Remove(0, builder.Length);
				resultLogUpdate2.Add("UpdateCustomENR add CustomENRID field to CustomENR table start");

				builder.Append(@"ALTER TABLE CustomENR ADD COLUMN CustomENRID IDENTITY(1,1) CONSTRAINT U2Key"); 
				builder.Append(NextKey());
				builder.Append(" PRIMARY KEY");
				
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("CustomENRID field not added to CustomENR table");
			}
			finally
			{
				resultLogUpdate2.Add("UpdateCustomENR add CustomENRID field to CustomENR table stop");
			}
			return true;
		}

		private bool CreateComboReportLevel()
		{
			// create the ComboReportLevel table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("Table ComboReportLevel start");

				builder.Append(@"CREATE TABLE ComboReportLevel (ComboReportLevelID LONG NOT NULL PRIMARY KEY,");
				builder.Append(" NodeTypeID INTEGER NOT NULL CONSTRAINT U2Key");
				builder.Append(NextKey());
				builder.Append(" REFERENCES NodeType (NodeTypeID) ON UPDATE CASCADE ON DELETE CASCADE,");
				builder.Append(" ReportLevel VARCHAR (50) WITH COMPRESSION NOT NULL,");
				builder.Append(" ReportLevelText VARCHAR (100) WITH COMPRESSION NOT NULL,");
				builder.Append(" SortBy INTEGER NOT NULL,");
				builder.Append(" ApplyToGraph INTEGER)");
				
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				cmd.CommandText = @"CREATE INDEX Index" + NextIndex() + " ON ComboReportLevel (ComboReportLevelID)";
				cmd.ExecuteNonQuery();

				cmd.CommandText = @"CREATE INDEX U2Index" + NextIndex() + " ON ComboReportLevel (SortBy)";
				cmd.ExecuteNonQuery();
			}
			catch(Exception	ex)
			{
				System.Diagnostics.Debug.WriteLine(builder.ToString());
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("ComboReportLevel table not created");
				// if there is an error, then either the table already exists, or there was an error while attempting
				//	to create it, so there is no point in continuing
				return false;
			}
			finally
			{
				resultLogUpdate2.Add("Table ComboReportLevel stop");
			}

			//populate the ComboReportLevel table
			DataPopulationComboReportLevel();

			return true;
		}

		private bool DataPopulationComboReportLevel()
		{
			//populate the ComboReportLevel table
			// note: should get these values from the enum

			dataTable = dataAccess.GetTables("ComboReportLevel", useConnectionString);
			if (dataTable != null)
			{
				dataSet = new DataSet();
				string queryString = @"SELECT * FROM ComboReportLevel";
				dataSet = dataAccess.GetDisconnectedDataset(queryString, useConnectionString);
				if (dataSet == null)
				{
					throw new Exception("Database Error.  Update2.DataPopulationComboReportLevel");
				}

				if (dataSet.Tables[0].Rows.Count > 0)
				{
					resultLogUpdate2.Add("Data Population Table ComboReportLevel not completed - table already has data");
					return true;
				}

				DataRow dataRow;

				try
				{
					resultLogUpdate2.Add("Data Population Table ComboReportLevel start");

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 0;
					dataRow["NodeTypeID"] = 1;
					dataRow["ReportLevel"] = "Facility";
					dataRow["ReportLevelText"] = "Facility / System";
					dataRow["SortBy"] = 0;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 1;
					dataRow["NodeTypeID"] = 2;
					dataRow["ReportLevel"] = "TreatmentProcess";
					dataRow["ReportLevelText"] = "Process / Basin / Zone";
					dataRow["SortBy"] = 1;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 2;
					dataRow["NodeTypeID"] = 3;
					dataRow["ReportLevel"] = "MajorComponent";
					dataRow["ReportLevelText"] = "Component / Subbasin / Subzone";
					dataRow["SortBy"] = 2;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 3;
					dataRow["NodeTypeID"] = 255;
					dataRow["ReportLevel"] = "Discipline";
					dataRow["ReportLevelText"] = "Discipline: All";
					dataRow["SortBy"] = 3;
					dataRow["ApplyToGraph"] = 0;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 4;
					dataRow["NodeTypeID"] = 4;
					dataRow["ReportLevel"] = "DisciplineMech";
					dataRow["ReportLevelText"] = "Discipline: Mech / Elec / Instr / Piping";
					dataRow["SortBy"] = 4;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 5;
					dataRow["NodeTypeID"] = 5;
					dataRow["ReportLevel"] = "DisciplineStruct";
					dataRow["ReportLevelText"] = "Discipline: Struct / Arch";
					dataRow["SortBy"] = 5;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 6;
					dataRow["NodeTypeID"] = 6;
					dataRow["ReportLevel"] = "DisciplineLand";
					dataRow["ReportLevelText"] = "Discipline: Site / Land / Other";
					dataRow["SortBy"] = 6;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 7;
					dataRow["NodeTypeID"] = 7;
					dataRow["ReportLevel"] = "DisciplinePipe";
					dataRow["ReportLevelText"] = "Discipline: Pipes";
					dataRow["SortBy"] = 7;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 8;
					dataRow["NodeTypeID"] = 8;
					dataRow["ReportLevel"] = "DisciplineNode";
					dataRow["ReportLevelText"] = "Discipline: Nodes / Appurtenances";
					dataRow["SortBy"] = 8;
					dataRow["ApplyToGraph"] = 1;
					dataSet.Tables[0].Rows.Add(dataRow);

					dataRow = dataSet.Tables[0].NewRow();
					dataRow["ComboReportLevelID"] = 9;
					dataRow["NodeTypeID"] = 9;
					dataRow["ReportLevel"] = "ComponentAsset";
					dataRow["ReportLevelText"] = "Asset List";
					dataRow["SortBy"] = 9;
					dataRow["ApplyToGraph"] = 0;
					dataSet.Tables[0].Rows.Add(dataRow);

					bool result = dataAccess.UpdateDatabase(dataSet, queryString, useConnectionString);
					if (!result)
						resultLogUpdate2.Add("Data Population Table ComboReportLevel not completed");
				}
				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
					resultLogUpdate2.Add("Data Population Table ComboReportLevel not completed");
					return false;
				}
				finally
				{
					resultLogUpdate2.Add("Data Population Table ComboReportLevel stop");
				}
			}
			return true;
		}

		private void ConsolidationHandler()
		{
			if (update2PreviouslyApplied)
				return;
			ConsolidateFixedInfosetENRTables(true);
			ConsolidateFixedInfosetENRTables(false);
		}

		private void ConsolidateFixedInfosetENRTables(bool forFixedInfoset)
		{
			//check whether multiple facilities are using the same ENR values - if they are, remove the 
			//	duplicate ENR tables, and reassign each facility's CustomerENRListID
			DataTable dataTableListOfCustomENRListIDs = new DataTable();
			DataTable dataTableTemp = new DataTable();
			DataSet dataSetENRTableValues = new DataSet();
			int curENRID = 0;
			bool resultSame = false;
			bool resultDifferent = false;
			bool okToContinue = false;
			StringBuilder builder = new StringBuilder(200);

			//get a list of the CustomENRListIDs used in the database
			builder.Append("SELECT C.CustomENRListID, C.CustomENRListName, C.InfosetID, I.infoset_id, I.FixedInfoset");
			builder.Append(" FROM CustomENRList C LEFT JOIN InfoSets I ON C.InfosetID = I.infoset_id");
			builder.Append(" ORDER BY C.InfosetID, C.CustomENRListID");

			dataTableListOfCustomENRListIDs = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
			foreach (DataRow dataRow in dataTableListOfCustomENRListIDs.Rows)
			{
				okToContinue = false;
				if ((forFixedInfoset && dataRow["FixedInfoset"].ToString() == "1")
					|| (!forFixedInfoset && dataRow["FixedInfoset"].ToString() != "1"))
				{
					okToContinue = true;
				}

				if (okToContinue)
				{
					//get the ENR values for the CustomENRListID in dataTableListOfCustomENRListIDs
					builder.Remove(0, builder.Length);
					builder.AppendFormat("SELECT CustomENRListID, enr_year, enr_value FROM CustomENR WHERE CustomENRListID = {0}", (int)dataRow["CustomENRListID"]);
					builder.Append(" ORDER BY enr_year, enr_value");

					dataTableTemp = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
					if (dataTableTemp == null)
						continue;
					//if (dataTableTemp.Rows.Count == 0)
					//	continue;

					if (dataSetENRTableValues.Tables.Count == 0)
					{
						//if this is the first CustomENRListID, store the ENR values in the dataSetENRTableValues DataSet
						dataSetENRTableValues.Tables.Add(dataTableTemp);

						//rename the Custom ENR table from the facility name to a facility-independent name
						if (dataTableTemp.Rows.Count > 0)
						{
							RenameENRTable(forFixedInfoset, dataSetENRTableValues.Tables.Count, (int)dataTableTemp.Rows[0]["CustomENRListID"]);
						}
					}
					else
					{
						//for subsequent CustomENRListIDs, check the ENR values against the values stored in the dataSetENRTableValues DataSet
						//resultDifferent = false;
						resultSame = false;
						foreach (DataTable dataTable in dataSetENRTableValues.Tables)
						{
							//compare the two tables to determine whether they have the exact same years and ENR values
							//if (dataTableTemp.Equals(dataTable))
							resultDifferent = false;
							for (int i = 0; i < dataTableTemp.Rows.Count; i++)
							{
								if (dataTableTemp.Rows[i]["enr_year"].ToString() != dataTable.Rows[i]["enr_year"].ToString()
									|| dataTableTemp.Rows[i]["enr_value"].ToString() != dataTable.Rows[i]["enr_value"].ToString())
								{
									//result = false;
									resultDifferent = true;
									break;
								}
							}

							if (!resultDifferent)
								resultSame = true;

							//if result = true, then then two ENR tables are the same
							if (resultSame)
							{
								curENRID = (int)dataTable.Rows[0]["CustomENRListID"];
								break;
							}
						}
						if (resultSame)
						{
							//the two tables are the same, which means that the ENR values for the CustomENRListID in
							//	dataTableTemp can be removed, and any Facilities using those values can instead use the
							//  CustomENRListID in dataSetENRTableValues

							//update the Facilities table
							builder.Remove(0, builder.Length);
							builder.AppendFormat(@"UPDATE Facilities SET CustomENRListID = {0}", curENRID);
							builder.AppendFormat(@" WHERE CustomENRListID = {0}", dataTableTemp.Rows[0]["CustomENRListID"]);
							dataAccess.ExecuteCommand(builder.ToString(), useConnectionString);

							//remove the dataTableTemp CustomENRListID
							builder.Remove(0, builder.Length);
							builder.AppendFormat(@"DELETE FROM CustomENRList WHERE CustomENRListID = {0}", dataTableTemp.Rows[0]["CustomENRListID"]);
							dataAccess.ExecuteCommand(builder.ToString(), useConnectionString);
						}
						else
						{
							//the two tables are different, so add dataTableTemp to the dataSetENRTableValues DataSet
							dataSetENRTableValues.Tables.Add(dataTableTemp);
							if (dataTableTemp.Rows.Count > 0)
							{
								RenameENRTable(forFixedInfoset, dataSetENRTableValues.Tables.Count, (int)dataTableTemp.Rows[0]["CustomENRListID"]);
							}
						}
					}
				}
			}
		}

		private void RenameENRTable(bool forFixedInfoset, int tableCounter, int enrID)
		{
			string newName = "";
			StringBuilder builder = new StringBuilder(200);

			if (forFixedInfoset)
			{
				newName = string.Format("Locked Infoset ENR Table {0}", tableCounter.ToString());
			}
			else
			{
				newName = string.Format("ENR Table {0}", tableCounter.ToString());
			}

			builder.AppendFormat("UPDATE CustomENRList SET CustomENRListName = '{0}'", newName);
			//builder.AppendFormat(" WHERE CustomENRListID = {0}", (int)dataTableTemp.Rows[0]["CustomENRListID"]);
			builder.AppendFormat(" WHERE CustomENRListID = {0}", enrID);
			dataAccess.ExecuteCommand(builder.ToString(), useConnectionString);
		}

		private int CreateDefaultCustomENRTable()
		{
			if (update2PreviouslyApplied)
				return 0;

			//mam 112806
			//return WAM.Common.CommonTasks.CreateCustomENRTable(0, 0, true, false, "Default Custom ENR Table");
			return WAM.Common.CommonTasks.CreateCustomENRTable(0, 0, true, false, "Custom ENR Table");
		}

		private bool UpdateReportTemplateTable()
		{
			//GraphTemplate	GraphYAxis1	GraphYAxis2
			// add the GraphTemplate, GraphYAxis1, and GraphYAxis2 fields to the ReportTemplate table
			StringBuilder builder = new StringBuilder(200);
			try
			{
				resultLogUpdate2.Add("UpdateReportTemplateTable Add Graph fields to ReportTemplate table start");

				// add the GraphTemplate, GraphYAxis1, and GraphYAxis2 fields to the ReportTemplate table
				builder.Append("ALTER TABLE ReportTemplate ADD COLUMN GraphTemplate LONG");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				builder.Remove(0, builder.Length);
				builder.Append("ALTER TABLE ReportTemplate ADD COLUMN GraphYAxis1 VARCHAR (100) WITH COMPRESSION");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				builder.Remove(0, builder.Length);
				builder.Append("ALTER TABLE ReportTemplate ADD COLUMN GraphYAxis2 VARCHAR (100) WITH COMPRESSION");
				cmd.CommandText = @builder.ToString();
				cmd.ExecuteNonQuery();

				cmd.CommandText = @"ALTER TABLE ReportTemplate ALTER COLUMN GraphTemplate SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "UPDATE ReportTemplate SET GraphTemplate = 0";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate2.Add("Graph fields not created in ReportTemplate table");
				return false;
			}
			finally
			{
				resultLogUpdate2.Add("UpdateReportTemplateTable Add Graph fields to ReportTemplate table stop");
			}
			return true;
		}

		private bool Cleanup()
		{
			try
			{
				cmd = null;
				dataTable = null;
				dataAccess = null;
				dataSet = null;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Update2 Methods *****/

	}
}
