using System;
using C1.Win.C1FlexGrid;
using System.Collections;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Rounding
	{
		public Rounding()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public string RoundNumber(int NumberRaw)
		{
			System.Windows.Forms.MessageBox.Show(NumberRaw.ToString());
			System.Windows.Forms.MessageBox.Show(Convert.ToString(NumberRaw));
			return Convert.ToString(NumberRaw);
		}

		//062407 - add roundingColExceptions
		public void PerformRounding(int rowStart, int colStart, C1.Win.C1FlexGrid.C1FlexGrid grid, ArrayList roundingColExceptions)
		{
			if (!WAM.Common.Globals.AllowRounding || WAM.Common.Globals.AllowRoundingDigit < 1)
				return;

			if (grid.Rows.Count <= (rowStart + 1))
				return;

			int roundingDigit = WAM.Common.Globals.AllowRoundingDigit;
			grid.Redraw = false;

			for (int row = rowStart; row < grid.Rows.Count; row++)
			{
				for (int col = colStart; col <= grid.Cols.Count - 1; col++)
				{
					if (roundingColExceptions.Contains(col))
					{
						continue;
					}

					try
					{
						grid.SetData(row, col, RoundNumber(double.Parse(grid.GetData(row, col).ToString(), System.Globalization.NumberStyles.Currency), roundingDigit).ToString("$#,##0"));
					}
					catch
					{
						//System.Diagnostics.Debug.Assert(false, ex.Message);
					}
				}
			}
			grid.Redraw = true;
		}

		public double RoundNumber(double numberRaw, double position)
		{
			if (position > 0)
				numberRaw = (System.Math.Round(numberRaw / System.Math.Pow(10, position), 0)) * System.Math.Pow(10, position);
			
			return numberRaw;
		}

		public decimal RoundNumber(decimal numberRaw, double position)
		{
			//mam 050806 - why take the chance of converting the decimal to a double - just work with the decimal value
			//double numberRaw2;
			//numberRaw2 = Convert.ToDouble(numberRaw);
			//numberRaw2 = (System.Math.Round(numberRaw2 / System.Math.Pow(10, position), 0)) * System.Math.Pow(10, position);
			//return Convert.ToDecimal(numberRaw2);

			numberRaw = (System.Math.Round(numberRaw / (decimal)System.Math.Pow(10, position), 0)) * (decimal)System.Math.Pow(10, position);
			return numberRaw;
		}
	}
}
