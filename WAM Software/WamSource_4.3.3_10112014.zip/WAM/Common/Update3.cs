using System;
using System.Collections;
using System.Data.OleDb;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Update3.
	/// </summary>
	/// 

	public class Update3
	{
		#region /***** Member Variables *****/

		//mam 102309
		//DataAccess dataAccess = new DataAccess();
		UpdateDataAccess dataAccess = new UpdateDataAccess();
		DataAccess dataAccessSql = new DataAccess();

		OleDbCommand cmd = null;
		//DataSet dataSet = new DataSet();
		//DataTable dataTable = new DataTable();
		ArrayList resultLogUpdate3 = new ArrayList();

		private int keyCount = 0;
		private int indexCount = 0;
		private string useConnectionString;

		#endregion /***** Member Variables *****/

		#region /***** Methods *****/

		//bool update3PreviouslyApplied = false;

		public Update3(string connectionString)
		{
			useConnectionString = connectionString;
		}

		private int NextKey()
		{
			keyCount += 1;
			return keyCount;
		}

		private int NextIndex()
		{
			indexCount += 1;
			return indexCount;
		}

		public bool PerformUpdate()
		{
			// perform database updates
			try
			{
				//if a connection can't be opened, exit
				//	(return true regardless of error)
				if (OpenConnectionForUpdating())
				{
					UpdateDisciplineLandTable();
					ChangeDisciplineName();
					UpdateComboReportTableForGraphDisciplineAll();
					UpdateReportTemplateTableForGraphSettings();

					AddReplacementValueYearField();
					AddRepairCostField();
					AddRehabCostField();
					AddPipeNodeFields();
					AddRedundancyField();
				}
				Cleanup();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Methods *****/

		#region /***** Update3 Methods *****/

		private bool OpenConnectionForUpdating()
		{
			// open a connection
			try
			{
				resultLogUpdate3.Add("OpenConnectionForUpdating start");
				cmd = dataAccess.GetCommandObject(useConnectionString);
				if (cmd == null)
				{
					resultLogUpdate3.Add("OpenConnectionForUpdating not attempted");
					return false;
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("OpenConnectionForUpdating failed on create OleDbCommand");
			}
			return true;
		}

		private bool UpdateDisciplineLandTable()
		{
			StringBuilder builder = new StringBuilder(200);
			// add new Component Information fields to the DisciplineLand table
			try
			{
				resultLogUpdate3.Add("UpdateDisciplineLandTable start");

				//create the fields
				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppClayLiner BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBermErosionInterior BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBermErosionBermExterior BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBermVegetation BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBermSettlement BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBermSeepage BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppBurrowHoles BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppErosionProtectionPresent BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppErosionProtectionAdequate BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppAlgalBlooms BYTE";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ADD COLUMN disc3_LandAppDrainageAdequate BYTE";
				cmd.ExecuteNonQuery();

				//set default values
				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppClayLiner SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBermErosionInterior SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBermErosionBermExterior SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBermVegetation SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBermSettlement SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBermSeepage SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppBurrowHoles SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppErosionProtectionPresent SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppErosionProtectionAdequate SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppAlgalBlooms SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "ALTER TABLE DisciplineLand ALTER COLUMN disc3_LandAppDrainageAdequate SET DEFAULT 0";
				cmd.ExecuteNonQuery();

				//populate the new fields with the N/A value
				builder.Append("UPDATE DisciplineLand SET disc3_LandAppClayLiner = 2,");
				builder.Append(" disc3_LandAppBermErosionInterior = 2,");
				builder.Append(" disc3_LandAppBermErosionBermExterior = 2,");
				builder.Append(" disc3_LandAppBermVegetation = 2,");
				builder.Append(" disc3_LandAppBermSettlement = 2,");
				builder.Append(" disc3_LandAppBermSeepage = 2,");
				builder.Append(" disc3_LandAppBurrowHoles = 2,");
				builder.Append(" disc3_LandAppErosionProtectionPresent = 2,");
				builder.Append(" disc3_LandAppErosionProtectionAdequate = 2,");
				builder.Append(" disc3_LandAppAlgalBlooms = 2,");
				builder.Append(" disc3_LandAppDrainageAdequate = 2;");
				cmd.CommandText = builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("ComponentInformation fields not added to DisciplineLand table");
			}
			finally
			{
				resultLogUpdate3.Add("UpdateDisciplineLandTable stop");
			}
			return true;
		}

		private bool ChangeDisciplineName()
		{
			// change Land discipline name to Civil / Sitework
			try
			{
				resultLogUpdate3.Add("ChangeDisciplineName start");

				//create the fields
				cmd.CommandText = "UPDATE ComboReportLevel SET ReportLevelText = 'Discipline: Civil / Sitework' WHERE ReportLevel = 'DisciplineLand';";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "UPDATE FilterReportLevel SET FilterReportLevelText = 'Discipline: Civil / Sitework' WHERE FilterReportLevel = 'DisciplineLand';";
				cmd.ExecuteNonQuery();

				cmd.CommandText = "UPDATE NodeType SET NodeTypeText = 'Discipline: Civil / Sitework' WHERE NodeType = 'DisciplineLand';";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("ChangeDisciplineName error");
			}
			finally
			{
				resultLogUpdate3.Add("ChangeDisciplineName stop");
			}
			return true;
		}

		private bool UpdateComboReportTableForGraphDisciplineAll()
		{
			// update table to allow graph to have DisciplineAll selection
			try
			{
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll start");

				cmd.CommandText = "UPDATE ComboReportLevel SET ApplyToGraph = 1 WHERE NodeTypeID = 255;";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll error");
			}
			finally
			{
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll stop");
			}
			return true;
		}

		private bool UpdateReportTemplateTableForGraphSettings()
		{
			// update table to store graph properties
			try
			{
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll start");

				cmd.CommandText = "ALTER TABLE ReportTemplate ADD COLUMN ChartProperties MEMO";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll error");
			}
			finally
			{
				resultLogUpdate3.Add("Update3.UpdateComboReportTableForGraphDisciplineAll stop");
			}
			return true;
		}

		//mam 050806
		private bool AddReplacementValueYearField()
		{
			//add ReplacementValueYear field to discipline tables
			if (AddField("DisciplineLand", "ReplacementValueYear", "INTEGER", 0))
			{
				PopulateField("DisciplineLand", "ReplacementValueYear", 0);
			}
			//else
			//{
			//	return false;
			//}

			if (AddField("DisciplineMech", "ReplacementValueYear", "INTEGER", 0))
			{
				PopulateField("DisciplineMech", "ReplacementValueYear", 0);
			}

			if (AddField("DisciplineStruct", "ReplacementValueYear", "INTEGER", 0))
			{
				PopulateField("DisciplineStruct", "ReplacementValueYear", 0);
			}

			if (AddField("PipingComponents", "ReplacementValueYear", "INTEGER", 0))
			{
				PopulateField("PipingComponents", "ReplacementValueYear", 0);
			}
					
			if (AddField("NodeAppurtComponents", "ReplacementValueYear", "INTEGER", 0))
			{
				PopulateField("NodeAppurtComponents", "ReplacementValueYear", 0);
			}

			return true;
		}

		//mam 050806
		private bool AddRepairCostField()
		{
			AddField("DisciplineLand", "RepairCost", "CURRENCY", 0);
			//if (!AddField("DisciplineLand", "RepairCost", "CURRENCY", 0))
			//{
			//	return false;
			//}

			AddField("DisciplineMech", "RepairCost", "CURRENCY", 0);
			AddField("DisciplineStruct", "RepairCost", "CURRENCY", 0);
			AddField("PipingComponents", "RepairCost", "CURRENCY", 0);
			AddField("NodeAppurtComponents", "RepairCost", "CURRENCY", 0);

			return true;
		}

		//mam 050806
		private bool AddRehabCostField()
		{
			if (AddField("DisciplineLand", "RehabCost", "CURRENCY", 0))
			{
				PopulateField("DisciplineLand", "RehabCost", 0);
			}

			if (AddField("DisciplineMech", "RehabCost", "CURRENCY", 0))
			{
				PopulateField("DisciplineMech", "RehabCost", 0);
			}

			if (AddField("DisciplineStruct", "RehabCost", "CURRENCY", 0))
			{
				PopulateField("DisciplineStruct", "RehabCost", 0);
			}

			if (AddField("PipingComponents", "RehabCost", "CURRENCY", 0))
			{
				PopulateField("PipingComponents", "RehabCost", 0);
			}

			if (AddField("NodeAppurtComponents", "RehabCost", "CURRENCY", 0))
			{
				PopulateField("NodeAppurtComponents", "RehabCost", 0);
			}

			return true;
		}

		//mam 050806
		private bool AddPipeNodeFields()
		{
			AddField("NodeAppurtComponents", "node_currentValue", "CURRENCY", 0);

			try
			{
				cmd.CommandText = "ALTER TABLE NodeAppurtComponents ALTER COLUMN node_currentValue SET DEFAULT";
				cmd.ExecuteNonQuery();
			}
			catch
			{
			}

			if (AddField("PipingComponents", "pipe_acquisitionCost", "CURRENCY", 0))
			{
				AddField("PipingComponents", "pipe_currentValue", "CURRENCY", 0);

				try
				{
					cmd.CommandText = "ALTER TABLE PipingComponents ALTER COLUMN pipe_acquisitionCost SET DEFAULT";
					cmd.ExecuteNonQuery();

					cmd.CommandText = "ALTER TABLE PipingComponents ALTER COLUMN pipe_currentValue SET DEFAULT";
					cmd.ExecuteNonQuery();
				}
				catch
				{
				}

				try
				{
					StringBuilder builder = new StringBuilder(100);
					//DataAccess dataAccess = new DataAccess();
					DataRow[] dataRowFind;
					string findRowWhereClause = string.Empty;

					//****************

					//get pipeIDs for facilities that use custom ENR data (includes facility ENR value)
					builder.Append("SELECT PC.pipe_id, F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, PC.pipe_installYear, CE.enr_value AS FacENR, 1 AS PipeENR, ");
					builder.Append(" PC.pipe_length, PC.pipe_unitCost, PC.pipe_replacementValue, PC.pipe_conditionRank, PC.pipe_levelOfService");
					builder.Append(" FROM (((((PipingComponents PC INNER JOIN DisciplinePipes DP ON PC.discpipe_id = DP.discpipe_id)");
					builder.Append(" INNER JOIN MajorComponents MC ON DP.component_id = MC.component_id)");
					builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
					builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id)");
					builder.Append(" LEFT JOIN CustomENR CE ON F.CustomENRListID = CE.CustomENRListID AND F.facility_currentYear = CE.enr_year)");
					builder.Append(" WHERE F.facility_usesCustomENR = true");

					DataTable dataTablePipeIDsCustom = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
					//MessageBox.Show(dataTablePipeIDsCustom.Rows.Count.ToString());
				
					//****************

					//get pipeIDs for facility that use 20CitiesENR data (no facility or pipe enr values)
					builder.Remove(0, builder.Length);
					builder.Append("SELECT DISTINCT PC.pipe_id, F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, PC.pipe_installYear, 1 AS FacENR, 1 AS PipeENR, ");
					builder.Append(" PC.pipe_length, PC.pipe_unitCost, PC.pipe_replacementValue, PC.pipe_conditionRank, PC.pipe_levelOfService");
					builder.Append(" FROM ((((PipingComponents PC INNER JOIN DisciplinePipes DP ON PC.discpipe_id = DP.discpipe_id)");
					builder.Append(" INNER JOIN MajorComponents MC ON DP.component_id = MC.component_id)");
					builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
					builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id)");
					builder.Append(" WHERE F.facility_usesCustomENR = false");

					DataTable dataTablePipeIDs20Cities = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
					//MessageBox.Show(dataTablePipeIDs20Cities.Rows.Count.ToString());

					//****************

					//get custom ENR values
					DataTable dataTableEnrValuesCustom = dataAccess.GetDisconnectedDataTable("SELECT * FROM CustomENR ORDER BY CustomENRListID, enr_year", useConnectionString);

					//get 20CitiesENR values
					DataTable dataTableEnrValues20Cities = dataAccess.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Common.Globals.WamSqlConnectionString);

					if (dataTablePipeIDsCustom == null || dataTablePipeIDs20Cities == null
						|| dataTableEnrValuesCustom == null || dataTableEnrValues20Cities == null)
					{
						throw new Exception();
					}

					//****************

					//go through the dataTablePipeIDsCustom table and set the PipeENR value
					foreach (DataRow dataRow in dataTablePipeIDsCustom.Rows)
					{
						//find the matching CustomENRListID and pipe_installYear in the dataTableEnrValuesCustom table
						findRowWhereClause = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["pipe_installYear"];
						dataRowFind = dataTableEnrValuesCustom.Select(findRowWhereClause);
						if (dataRowFind != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["PipeENR"] = dataRowFind[0]["enr_value"];
								dataRow.EndEdit();
								//MessageBox.Show(dataRow["PipeENR"].ToString());
							}
							catch
							{
							}
						}
					}
					dataTablePipeIDsCustom.AcceptChanges();

					//****************

					//go through the dataTablePipeIDs20Cities table and set the FacENR value
					foreach (DataRow dataRow in dataTablePipeIDs20Cities.Rows)
					{
						//find the matching pipe_installYear in the dataTablePipeIDs20Cities table
						findRowWhereClause = "enr_year = " + dataRow["facility_currentYear"];
						dataRowFind = dataTableEnrValues20Cities.Select(findRowWhereClause);
						if (dataRowFind != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["FacENR"] = dataRowFind[0]["enr_value"];
								dataRow.EndEdit();
								//MessageBox.Show(dataRow["FacENR"].ToString());
							}
							catch
							{
							}
						}
					}
					dataTablePipeIDs20Cities.AcceptChanges();

					//go through the dataTablePipeIDs20Cities table and set the PipeENR value
					foreach (DataRow dataRow in dataTablePipeIDs20Cities.Rows)
					{
						//find the matching pipe_installYear in the dataTablePipeIDs20Cities table
						findRowWhereClause = "enr_year = " + dataRow["pipe_installYear"];
						dataRowFind = dataTableEnrValues20Cities.Select(findRowWhereClause);
						if (dataRowFind != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["PipeENR"] = dataRowFind[0]["enr_value"];
								dataRow.EndEdit();
								//MessageBox.Show(dataRow["PipeENR"].ToString());
							}
							catch
							{
							}
						}
					}
					dataTablePipeIDs20Cities.AcceptChanges();

					//****************

					//UPDATE DATABASE VALUES

					//go through the dataTablePipeIDsCustom table and update the PipingComponents table in the database
					decimal repairCost = -1.0m;
					decimal currentValue = 0.0m;
					int curPipeID = 0;
					foreach (DataRow dataRow in dataTablePipeIDsCustom.Rows)
					{
						//set AC = Length * Unit Cost * PipeENR / FacENR
						//if either PipeENR or FacENR value = 1, set AC = 0, CV = Length * Unit Cost

						//string cmdText = string.Empty;
						builder.Remove(0, builder.Length);
						curPipeID = Convert.ToInt32(dataRow["pipe_id"]);

						//MessageBox.Show(dataRow["PipeENR"].ToString());
						//MessageBox.Show(dataRow["FacENR"].ToString());

						//********************
						//repair cost

						repairCost = -1.0m;
						currentValue = Convert.ToDecimal(dataRow["pipe_length"]) * Convert.ToDecimal(dataRow["pipe_unitCost"]);

						if (dataRow["pipe_conditionRank"] != DBNull.Value && dataRow["pipe_levelOfService"] != DBNull.Value)
						{
							repairCost = GetRepairCost(Convert.ToByte(dataRow["pipe_conditionRank"]), Convert.ToByte(dataRow["pipe_levelOfService"]), 
								currentValue, Convert.ToDecimal(dataRow["pipe_replacementValue"]));
						}

						//********************

						if (Convert.ToInt32(dataRow["PipeENR"]) == 1 || Convert.ToInt32(dataRow["FacENR"]) == 1)
						{
							builder.Append("UPDATE PipingComponents SET pipe_acquisitionCost = 0, pipe_currentValue = pipe_length * pipe_unitCost");
							builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						}
						else
						{
							builder.Append("UPDATE PipingComponents SET pipe_acquisitionCost = pipe_length * pipe_unitCost");
							builder.AppendFormat(" * {0} / {1}", dataRow["PipeENR"], dataRow["FacENR"]);
							builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						}
						System.Diagnostics.Debug.WriteLine("20Cities: " + builder.ToString());
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();

						//mam 112806 - repair cost
						builder.Remove(0, builder.Length);
						builder.AppendFormat("UPDATE PipingComponents SET RepairCost = {0}", repairCost < 0? "NULL": repairCost.ToString());
						builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();
					}

					//go through the dataTablePipeIDs20Cities table and update the PipingComponents table in the database
					foreach (DataRow dataRow in dataTablePipeIDs20Cities.Rows)
					{
						//set AC = Length * Unit Cost * PipeENR / FacENR
						//if either PipeENR or FacENR value = 1, set AC = 0, CV = Length * Unit Cost

						//string cmdText = string.Empty;
						builder.Remove(0, builder.Length);
						curPipeID = Convert.ToInt32(dataRow["pipe_id"]);

						//MessageBox.Show(dataRow["PipeENR"].ToString());
						//MessageBox.Show(dataRow["FacENR"].ToString());

						//********************
						//repair cost

						repairCost = -1.0m;
						currentValue = Convert.ToDecimal(dataRow["pipe_length"]) * Convert.ToDecimal(dataRow["pipe_unitCost"]);

						if (dataRow["pipe_conditionRank"] != DBNull.Value && dataRow["pipe_levelOfService"] != DBNull.Value)
						{
							repairCost = GetRepairCost(Convert.ToByte(dataRow["pipe_conditionRank"]), Convert.ToByte(dataRow["pipe_levelOfService"]), 
								currentValue, Convert.ToDecimal(dataRow["pipe_replacementValue"]));
						}

						//********************

						if (Convert.ToInt32(dataRow["PipeENR"]) == 1 || Convert.ToInt32(dataRow["FacENR"]) == 1)
						{
							builder.Append("UPDATE PipingComponents SET pipe_acquisitionCost = 0, pipe_currentValue = pipe_length * pipe_unitCost");
							builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						}
						else
						{
							builder.Append("UPDATE PipingComponents SET pipe_acquisitionCost = pipe_length * pipe_unitCost");
							builder.AppendFormat(" * {0} / {1}", dataRow["PipeENR"], dataRow["FacENR"]);
							builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						}
						//System.Diagnostics.Debug.WriteLine("20Cities: " + builder.ToString());
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();

						//mam 112806 - repair cost
						builder.Remove(0, builder.Length);
						builder.AppendFormat("UPDATE PipingComponents SET RepairCost = {0}", repairCost < 0? "NULL": repairCost.ToString());
						builder.AppendFormat(" WHERE pipe_ID = {0}", curPipeID);
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();
					}
				}
				catch
				{
					MessageBox.Show("An error has occurred in Update3.AddPipeNodeFields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return false;
				}

				//mam 112806
				CalculateNodeRepairCost();

				//mam 012307
				UpdateDisciplineMSCRepairCost();

				UpdateDisciplineMSCAcquisitionCost();

				//mam 112806
				ChangeDefaultENRCustomTableName();
			}

			return true;
		}

		private bool CalculateNodeRepairCost()
		{
			try
			{
				StringBuilder builder = new StringBuilder(100);
				//DataAccess dataAccess = new DataAccess();
				DataRow[] dataRowFind;
				string findRowWhereClause = string.Empty;

				//****************

				//get nodeIDs for facilities that use custom ENR data (includes facility ENR value)

				//mam 012307 - added N.node_installYear
				builder.Append("SELECT N.node_id, F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, N.node_installYear, N.node_acquisitionCost, CE.enr_value AS FacENR, 1 AS NodeENR, ");
				builder.Append(" N.node_acquisitionCost, N.node_replacementValue, N.node_conditionRank, N.node_levelOfService");
				builder.Append(" FROM (((((NodeAppurtComponents N INNER JOIN DisciplineNodes DN ON N.discnode_id = DN.discnode_id)");
				builder.Append(" INNER JOIN MajorComponents MC ON DN.component_id = MC.component_id)");
				builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
				builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id)");
				builder.Append(" LEFT JOIN CustomENR CE ON F.CustomENRListID = CE.CustomENRListID AND F.facility_currentYear = CE.enr_year)");
				builder.Append(" WHERE F.facility_usesCustomENR = true");

				System.Diagnostics.Debug.WriteLine(builder.ToString());
				DataTable dataTableNodeIDsCustom = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
				//MessageBox.Show(dataTableNodeIDsCustom.Rows.Count.ToString());
			
				//****************

				//get nodeIDs for facility that use 20CitiesENR data (no facility or node enr values)
				builder.Remove(0, builder.Length);
				builder.Append("SELECT DISTINCT N.node_id, F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, N.node_installYear, 1 AS FacENR, 1 AS NodeENR, ");
				builder.Append(" N.node_acquisitionCost, N.node_replacementValue, N.node_conditionRank, N.node_levelOfService");
				builder.Append(" FROM ((((NodeAppurtComponents N INNER JOIN DisciplineNodes DN ON N.discnode_id = DN.discnode_id)");
				builder.Append(" INNER JOIN MajorComponents MC ON DN.component_id = MC.component_id)");
				builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
				builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id)");
				builder.Append(" WHERE F.facility_usesCustomENR = false");

				System.Diagnostics.Debug.WriteLine(builder.ToString());
				DataTable dataTableNodeIDs20Cities = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);
				//MessageBox.Show(dataTableNodeIDs20Cities.Rows.Count.ToString());

				//****************

				//get custom ENR values
				DataTable dataTableEnrValuesCustom = dataAccess.GetDisconnectedDataTable("SELECT * FROM CustomENR ORDER BY CustomENRListID, enr_year", useConnectionString);

				//get 20CitiesENR values
				DataTable dataTableEnrValues20Cities = dataAccess.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Common.Globals.WamSqlConnectionString);

				if (dataTableNodeIDsCustom == null || dataTableNodeIDs20Cities == null
					|| dataTableEnrValuesCustom == null || dataTableEnrValues20Cities == null)
				{
					throw new Exception();
				}

				//****************

				//go through the dataTableNodeIDsCustom table and set the NodeENR value
				foreach (DataRow dataRow in dataTableNodeIDsCustom.Rows)
				{
					//find the matching CustomENRListID and node_installYear in the dataTableEnrValuesCustom table
					findRowWhereClause = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["node_installYear"];
					dataRowFind = dataTableEnrValuesCustom.Select(findRowWhereClause);
					if (dataRowFind != null)
					{
						try
						{
							dataRow.BeginEdit();
							dataRow["NodeENR"] = dataRowFind[0]["enr_value"];
							dataRow.EndEdit();
							//MessageBox.Show(dataRow["NodeENR"].ToString());
						}
						catch
						{
						}
					}
				}
				dataTableNodeIDsCustom.AcceptChanges();

				//****************

				//go through the dataTableNodeIDs20Cities table and set the FacENR value
				foreach (DataRow dataRow in dataTableNodeIDs20Cities.Rows)
				{
					//find the matching node_installYear in the dataTableNodeIDs20Cities table
					findRowWhereClause = "enr_year = " + dataRow["facility_currentYear"];
					dataRowFind = dataTableEnrValues20Cities.Select(findRowWhereClause);
					if (dataRowFind != null)
					{
						try
						{
							dataRow.BeginEdit();
							dataRow["FacENR"] = dataRowFind[0]["enr_value"];
							dataRow.EndEdit();
							//MessageBox.Show(dataRow["FacENR"].ToString());
						}
						catch
						{
						}
					}
				}
				dataTableNodeIDs20Cities.AcceptChanges();

				//go through the dataTableNodeIDs20Cities table and set the NodeENR value
				foreach (DataRow dataRow in dataTableNodeIDs20Cities.Rows)
				{
					//find the matching node_installYear in the dataTableNodeIDs20Cities table
					findRowWhereClause = "enr_year = " + dataRow["node_installYear"];
					dataRowFind = dataTableEnrValues20Cities.Select(findRowWhereClause);
					if (dataRowFind != null)
					{
						try
						{
							dataRow.BeginEdit();
							dataRow["NodeENR"] = dataRowFind[0]["enr_value"];
							dataRow.EndEdit();
							//MessageBox.Show(dataRow["NodeENR"].ToString());
						}
						catch
						{
						}
					}
				}
				dataTableNodeIDs20Cities.AcceptChanges();

				//****************

				//UPDATE DATABASE VALUES

				//go through the dataTableNodeIDsCustom table and update the NodeAppurtComponents table in the database
				decimal repairCost = -1.0m;
				decimal currentValue = 0.0m;
				int curNodeID = 0;
				foreach (DataRow dataRow in dataTableNodeIDsCustom.Rows)
				{
					//set RC = AC * NodeENR / FacENR
					//if either NodeENR or FacENR value = 1, set RC = 0
					//if cond = na, set RC = null

					//string cmdText = string.Empty;
					builder.Remove(0, builder.Length);
					curNodeID = Convert.ToInt32(dataRow["node_id"]);

					//MessageBox.Show(dataRow["NodeENR"].ToString());
					//MessageBox.Show(dataRow["FacENR"].ToString());

					//********************
					//repair cost

					repairCost = -1.0m;
					currentValue = Convert.ToDecimal(dataRow["node_acquisitionCost"]) * 
						Convert.ToInt32(dataRow["FacENR"]) / Convert.ToInt32(dataRow["NodeENR"]);

					if (dataRow["node_conditionRank"] != DBNull.Value && dataRow["node_levelOfService"] != DBNull.Value)
					{
						repairCost = GetRepairCost(Convert.ToByte(dataRow["node_conditionRank"]), Convert.ToByte(dataRow["node_levelOfService"]), 
							currentValue, Convert.ToDecimal(dataRow["node_replacementValue"]));
					}

					//********************

					//repair cost
					builder.Remove(0, builder.Length);
					builder.AppendFormat("UPDATE NodeAppurtComponents SET RepairCost = {0}", repairCost < 0? "NULL": repairCost.ToString());
					builder.AppendFormat(" WHERE node_ID = {0}", curNodeID);
					cmd.CommandText = builder.ToString();
					cmd.ExecuteNonQuery();
				}

				//go through the dataTableNodeIDs20Cities table and update the NodeAppurtComponents table in the database
				foreach (DataRow dataRow in dataTableNodeIDs20Cities.Rows)
				{
					//set RC = AC * NodeENR / FacENR
					//if either NodeENR or FacENR value = 1, set RC = 0
					//if cond = na, set RC = null

					//string cmdText = string.Empty;
					builder.Remove(0, builder.Length);
					curNodeID = Convert.ToInt32(dataRow["node_id"]);

					//MessageBox.Show(dataRow["NodeENR"].ToString());
					//MessageBox.Show(dataRow["FacENR"].ToString());

					//********************
					//repair cost

					repairCost = -1.0m;
					currentValue = Convert.ToDecimal(dataRow["node_acquisitionCost"]) * 
						Convert.ToInt32(dataRow["FacENR"]) / Convert.ToInt32(dataRow["NodeENR"]);

					if (dataRow["node_conditionRank"] != DBNull.Value && dataRow["node_levelOfService"] != DBNull.Value)
					{
						repairCost = GetRepairCost(Convert.ToByte(dataRow["node_conditionRank"]), Convert.ToByte(dataRow["node_levelOfService"]), 
							currentValue, Convert.ToDecimal(dataRow["node_replacementValue"]));
					}

					//********************

					//mam 112806 - repair cost
					builder.Remove(0, builder.Length);
					builder.AppendFormat("UPDATE NodeAppurtComponents SET RepairCost = {0}", repairCost < 0? "NULL": repairCost.ToString());
					builder.AppendFormat(" WHERE node_ID = {0}", curNodeID);
					cmd.CommandText = builder.ToString();
					cmd.ExecuteNonQuery();
				}
			}
			catch
			{
				MessageBox.Show("An error has occurred in Update3.CalculateNodeRepairCost", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}

			return true;
		}

		//mam 112806
		private decimal GetRepairCost(byte curCond, byte curLOS, decimal curCurrentValue, decimal curReplacementValue)	//, int cenr, int oenr)
		{
			//if cond = 0 or 5 and los = 1, repair cost = replacement value
			//if cond < los, repair cost = 0
			//if cond = na, repair cost = na

			if ((curCond == 0 || curCond == 5) && curLOS == 1)
				return curReplacementValue;

			if (curCond < curLOS)
				return 0.0M;

			if (curCond == 255)
				return -1.0m;

			decimal condFraction = GetFraction(curCond);
			decimal losFraction = GetFraction(curLOS);

			//return Math.Round(curCurrentValue * (condFraction - losFraction), 0);
			return curCurrentValue * (condFraction - losFraction);
		}

		//mam 051708 - note:  no need to add method such as GetFractionForUsefulLife because GetFraction
		//	is used only in GetRepairCost
		//mam 112806
		private decimal GetFraction(byte curValue)
		{
			switch (curValue)
			{
				case 0:
				case 1:
					return 0.0M;
				case 2:
					return 0.047M;
				case 3:
					return 0.153M;
				case 4:
					return 0.304M;
				case 5:
					return 0.496M;
				case 255:
					return -1;
			}
			return 0m;
		}

		//mam 012307
		private bool UpdateDisciplineMSCRepairCost()
		{
			try
			{
				StringBuilder builder = new StringBuilder(100);
				//DataAccess dataAccess = new DataAccess();
				DataRow[] dataRowFindFac;
				DataRow[] dataRowFindDisc;
				string findRowWhereClauseFac = string.Empty;
				string findRowWhereClauseDisc = string.Empty;
				string curDiscDataTableName = string.Empty;

				//****************

				//get custom ENR values
				DataTable dataTableEnrValuesCustom = dataAccess.GetDisconnectedDataTable("SELECT * FROM CustomENR ORDER BY CustomENRListID, enr_year", useConnectionString);

				//get 20CitiesENR values
				//mam 102309
				//DataTable dataTableEnrValues20Cities = dataAccess.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Data.WAMSource.ENRSource.ConnectionString);
				DataTable dataTableEnrValues20Cities = dataAccessSql.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Common.Globals.WamSqlConnectionString);

				//****************

				for (int i = 1; i <= 3; i++)
				{
					if (i == 1)
					{
						curDiscDataTableName = "DisciplineMech";
					}
					else if (i == 2)
					{
						curDiscDataTableName = "DisciplineStruct";
					}
					else if (i == 3)
					{
						curDiscDataTableName = "DisciplineLand";
					}

					if (i == 1)
					{
						//MECH - get discipline data for Mech disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc1_acquisitionCost AS AcquisitionCost, DM.disc1_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc1_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc1_installationYear AS disc_installationYear, DM.disc1_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc1_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc1_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineMech DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");

						//System.Diagnostics.Debug.WriteLine(builder.ToString());
					}
					else if (i == 2)
					{
						//STRUCT - get discipline data for Struct disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc2_acquisitionCost AS AcquisitionCost, DM.disc2_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc2_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc2_installationYear AS disc_installationYear, DM.disc2_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc2_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc2_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineStruct DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");
					}
					else if (i == 3)
					{
						//LAND - get discipline data for Land disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc3_acquisitionCost AS AcquisitionCost, DM.disc3_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc3_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc3_installationYear AS disc_installationYear, DM.disc3_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc3_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc3_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineLand DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");
					}

					DataTable dataTableDisc = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);

					if (dataTableDisc == null || dataTableEnrValuesCustom == null || dataTableEnrValues20Cities == null)
					{
						throw new Exception();
					}
					//****************

					//go through the dataTableDisc table and set the FacENR and DiscENR values
					foreach (DataRow dataRow in dataTableDisc.Rows)
					{
						//get the ENR values from the ENR tables
						if (Convert.ToBoolean(dataRow["facility_usesCustomENR"]))
						{
							findRowWhereClauseFac = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["facility_currentYear"];
							findRowWhereClauseDisc = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["disc_installationYear"];
							dataRowFindFac = dataTableEnrValuesCustom.Select(findRowWhereClauseFac);
							dataRowFindDisc = dataTableEnrValuesCustom.Select(findRowWhereClauseDisc);
						}
						else
						{
							findRowWhereClauseFac = "enr_year = " + dataRow["facility_currentYear"];
							findRowWhereClauseDisc = "enr_year = " + dataRow["disc_installationYear"];
							dataRowFindFac = dataTableEnrValues20Cities.Select(findRowWhereClauseFac);
							dataRowFindDisc = dataTableEnrValues20Cities.Select(findRowWhereClauseDisc);
						}

						//update the FacENR and DiscENR values in the discipline table
						if (dataRowFindFac != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["FacENR"] = dataRowFindFac[0]["enr_value"];
								dataRow.EndEdit();
							}
							catch
							{
							}
						}
						if (dataRowFindDisc != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["DiscENR"] = dataRowFindDisc[0]["enr_value"];
								dataRow.EndEdit();
							}
							catch
							{
							}
						}
					}
					dataTableDisc.AcceptChanges();

					//****************

					//UPDATE DATABASE VALUES

					//go through the dataTableDisc table and update the discipline table in the database
					decimal repairCost = -1.0m;
					decimal currentValue = 0.0m;
					int curDiscID = 0;
					foreach (DataRow dataRow in dataTableDisc.Rows)
					{
						curDiscID = Convert.ToInt32(dataRow["disc_id"]);

						//mam 112806 - repair cost

						repairCost = -1.0m;
						currentValue = 0.0m;
						if (dataRow["CurrentValue"] != DBNull.Value)
						{
							currentValue = Convert.ToDecimal(dataRow["CurrentValue"]);
						}
						else if (dataRow["AcquisitionCost"] != DBNull.Value)
						{
							currentValue = Convert.ToDecimal(dataRow["AcquisitionCost"]) * 
								Convert.ToInt32(dataRow["FacENR"]) / Convert.ToInt32(dataRow["DiscENR"]);
						}
						else
						{
							currentValue = Convert.ToDecimal(dataRow["process_orgCost"]) * 
								Convert.ToDecimal(dataRow["component_CWPValue"]) * 
								Convert.ToDecimal(dataRow["disc_CWPAssetValue"]);
						}

						if (dataRow["ConditionRank"] != DBNull.Value && dataRow["component_LevelOfService"] != DBNull.Value)
						{
							repairCost = GetRepairCost(Convert.ToByte(dataRow["ConditionRank"]), Convert.ToByte(dataRow["component_LevelOfService"]), 
								currentValue, Convert.ToDecimal(dataRow["ReplacementValue"]));
						}

//						if (currentValue != 0)
//						{
//							System.Diagnostics.Debug.WriteLine(currentValue.ToString());
//						}

						builder.Remove(0, builder.Length);
						builder.AppendFormat("UPDATE {0} SET RepairCost = {1}", curDiscDataTableName, repairCost < 0? "NULL": repairCost.ToString());
						builder.AppendFormat(" WHERE disc{0}_id = {1}", i, curDiscID);
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();

					}
				}

				return true;
			}
			catch
			{
				MessageBox.Show("An error has occurred in Update3.UpdateDisciplineMSCRepairCost", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		//mam 050806
		private bool UpdateDisciplineMSCAcquisitionCost()
		{
			try
			{
				StringBuilder builder = new StringBuilder(100);
				//DataAccess dataAccess = new DataAccess();
				DataRow[] dataRowFindFac;
				DataRow[] dataRowFindDisc;
				string findRowWhereClauseFac = string.Empty;
				string findRowWhereClauseDisc = string.Empty;
				string curDiscDataTableName = string.Empty;

				//****************

				//get custom ENR values
				DataTable dataTableEnrValuesCustom = dataAccess.GetDisconnectedDataTable("SELECT * FROM CustomENR ORDER BY CustomENRListID, enr_year", useConnectionString);

				//get 20CitiesENR values
				//mam 102309
				//DataTable dataTableEnrValues20Cities = dataAccess.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Data.WAMSource.ENRSource.ConnectionString);
				DataTable dataTableEnrValues20Cities = dataAccessSql.GetDisconnectedDataTable("SELECT * FROM ENR20Cities ORDER BY enr_year", WAM.Common.Globals.WamSqlConnectionString);

				//****************

				for (int i = 1; i <= 3; i++)
				{
					if (i == 1)
					{
						curDiscDataTableName = "DisciplineMech";
					}
					else if (i == 2)
					{
						curDiscDataTableName = "DisciplineStruct";
					}
					else if (i == 3)
					{
						curDiscDataTableName = "DisciplineLand";
					}

					//mam 112806 - moved this code down so that null values will be preserved when setting Repair Cost
					//	mam 012307 - removed repair cost code, and moved this code back up
					//set all acquisition cost values to zero where they are currently null
					try
					{
						builder.Remove(0, builder.Length);
						builder.AppendFormat("UPDATE {0} SET disc{1}_acquisitionCost = 0 WHERE IsNull(disc{2}_acquisitionCost)", curDiscDataTableName, i, i);
						//System.Diagnostics.Debug.WriteLine(builder.ToString());
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();
					}
					catch
					{
					}

					//****************

					if (i == 1)
					{
						//MECH - get discipline data for Mech disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc1_acquisitionCost AS AcquisitionCost, DM.disc1_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc1_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc1_installationYear AS disc_installationYear, DM.disc1_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc1_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc1_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineMech DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");

						//mam 012907 - commented following line because we want to get all values
						//builder.Append(" WHERE IsNull(DM.CurrentValue)");

						//System.Diagnostics.Debug.WriteLine(builder.ToString());
					}
					else if (i == 2)
					{
						//STRUCT - get discipline data for Struct disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc2_acquisitionCost AS AcquisitionCost, DM.disc2_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc2_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc2_installationYear AS disc_installationYear, DM.disc2_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc2_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc2_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineStruct DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");

						//mam 012907 - commented following line because we want to get all values
						//builder.Append(" WHERE IsNull(DM.CurrentValue)");
					}
					else if (i == 3)
					{
						//LAND - get discipline data for Land disc

						builder.Remove(0, builder.Length);
						builder.Append("SELECT F.facility_usesCustomENR, F.CustomENRListID, F.facility_currentYear, ");
						builder.Append(" DM.disc3_acquisitionCost AS AcquisitionCost, DM.disc3_replacementValue AS ReplacementValue, ");
						builder.Append(" DM.disc3_conditionRanking AS ConditionRank, MC.component_LevelOfService, ");
						builder.Append(" DM.disc3_installationYear AS disc_installationYear, DM.disc3_id as disc_id, TP.process_orgCost, ");
						builder.Append(" MC.component_CWPValue, DM.disc3_CWPAssetValue AS disc_CWPAssetValue, 1 AS FacENR, 1 AS DiscENR, DM.CurrentValue, ccur(0) AS AC,");
						builder.Append(" TP.process_orgCost * MC.component_CWPValue * DM.disc3_CWPAssetValue AS TempCurrentValue");
						builder.Append(" FROM ((DisciplineLand DM INNER JOIN MajorComponents MC ON DM.component_id = MC.component_id)");
						builder.Append(" INNER JOIN TreatmentProcesses TP ON MC.process_id = TP.process_id)");
						builder.Append(" INNER JOIN Facilities F ON TP.facility_id = F.facility_id");

						//mam 012907 - commented following line because we want to get all values
						//builder.Append(" WHERE IsNull(DM.CurrentValue)");
					}

					DataTable dataTableDisc = dataAccess.GetDisconnectedDataTable(builder.ToString(), useConnectionString);

					if (dataTableDisc == null || dataTableEnrValuesCustom == null || dataTableEnrValues20Cities == null)
					{
						throw new Exception();
					}
					//****************

					//go through the dataTableDisc table and set the FacENR and DiscENR values
					foreach (DataRow dataRow in dataTableDisc.Rows)
					{
						//get the ENR values from the ENR tables
						if (Convert.ToBoolean(dataRow["facility_usesCustomENR"]))
						{
							findRowWhereClauseFac = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["facility_currentYear"];
							findRowWhereClauseDisc = "CustomENRListID = " + dataRow["CustomENRListID"] + " AND enr_year = " + dataRow["disc_installationYear"];
							dataRowFindFac = dataTableEnrValuesCustom.Select(findRowWhereClauseFac);
							dataRowFindDisc = dataTableEnrValuesCustom.Select(findRowWhereClauseDisc);
						}
						else
						{
							findRowWhereClauseFac = "enr_year = " + dataRow["facility_currentYear"];
							findRowWhereClauseDisc = "enr_year = " + dataRow["disc_installationYear"];
							dataRowFindFac = dataTableEnrValues20Cities.Select(findRowWhereClauseFac);
							dataRowFindDisc = dataTableEnrValues20Cities.Select(findRowWhereClauseDisc);
						}

						//update the FacENR and DiscENR values in the discipline table
						if (dataRowFindFac != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["FacENR"] = dataRowFindFac[0]["enr_value"];
								dataRow.EndEdit();
							}
							catch
							{
							}
						}
						if (dataRowFindDisc != null)
						{
							try
							{
								dataRow.BeginEdit();
								dataRow["DiscENR"] = dataRowFindDisc[0]["enr_value"];
								dataRow.EndEdit();
							}
							catch
							{
							}
						}
					}
					dataTableDisc.AcceptChanges();

					//****************

					//UPDATE DATABASE VALUES

					//go through the dataTableDisc table and update the discipline table in the database
//					decimal repairCost = -1.0m;
//					decimal currentValue = 0.0m;
					int curDiscID = 0;
					foreach (DataRow dataRow in dataTableDisc.Rows)
					{
						//set AC = TP.process_orgCost * MC.component_CWPValue * DM.disc1_CWPAssetValue * DiscENR / FacENR
						//	or, if CV is overridden, set AC = CV * Original ENR / Curren ENR
						//if either DiscENR or FacENR value = 1, set AC = 0

						curDiscID = Convert.ToInt32(dataRow["disc_id"]);

						//********************
						
//						//mam 112806 - repair cost
//
//						repairCost = -1.0m;
//						currentValue = 0.0m;
//						if (dataRow["CurrentValue"] != DBNull.Value)
//						{
//							currentValue = Convert.ToDecimal(dataRow["CurrentValue"]);
//						}
//						else if (dataRow["AcquisitionCost"] != DBNull.Value)
//						{
//							currentValue = Convert.ToDecimal(dataRow["AcquisitionCost"]) * 
//								Convert.ToInt32(dataRow["FacENR"]) / Convert.ToInt32(dataRow["NodeENR"]);
//						}
//						else
//						{
//							currentValue = Convert.ToDecimal(dataRow["process_orgCost"]) * 
//								Convert.ToDecimal(dataRow["component_CWPValue"]) * 
//								Convert.ToDecimal(dataRow["disc_CWPAssetValue"]);
//						}
//
//						if (dataRow["ConditionRank"] != DBNull.Value && dataRow["component_LevelOfService"] != DBNull.Value)
//						{
//							repairCost = GetRepairCost(Convert.ToByte(dataRow["ConditionRank"]), Convert.ToByte(dataRow["component_LevelOfService"]), 
//								currentValue, Convert.ToDecimal(dataRow["ReplacementValue"]));
//						}
////
//						builder.Remove(0, builder.Length);
//						builder.AppendFormat("UPDATE {0} SET RepairCost = {1}", curDiscDataTableName, repairCost < 0? "NULL": repairCost.ToString());
//						builder.AppendFormat(" WHERE disc{0}_id = {1}", i, curDiscID);
//						cmd.CommandText = builder.ToString();
//						cmd.ExecuteNonQuery();

						//********************

						//string cmdText = string.Empty;
						builder.Remove(0, builder.Length);

						//curDiscID = Convert.ToInt32(dataRow["disc_id"]);
						decimal curAC = 0.0m;
						if (Convert.ToInt32(dataRow["DiscENR"]) == 1 || Convert.ToInt32(dataRow["FacENR"]) == 1)
						{
							builder.AppendFormat("UPDATE {0} SET disc{1}_acquisitionCost = 0", curDiscDataTableName, i);
							builder.AppendFormat(" WHERE disc{0}_id = {1}", i, curDiscID);
						}
						else
						{
							//mam 012907 - added check for null CV
							if (dataRow["CurrentValue"] != DBNull.Value)
							{
								//current value is overridden, so calculate AC based on CV
								curAC = Convert.ToDecimal(dataRow["CurrentValue"]) * 
									Convert.ToInt32(dataRow["DiscENR"]) / Convert.ToInt32(dataRow["FacENR"]);
								builder.AppendFormat("UPDATE {0} SET disc{1}_acquisitionCost = {2}", curDiscDataTableName, i, curAC);
								builder.AppendFormat(" WHERE disc{0}_id = {1}", i, curDiscID);
							}
							else
							{
								builder.AppendFormat("UPDATE {0} SET disc{1}_acquisitionCost = {2} * {3} * {4}", 
									curDiscDataTableName, i, dataRow["process_orgCost"], dataRow["component_CWPValue"], 
									dataRow["disc_CWPAssetValue"]);
								builder.AppendFormat(" * {0} / {1}", dataRow["DiscENR"], dataRow["FacENR"]);
								builder.AppendFormat(" WHERE disc{0}_id = {1}", i, curDiscID);
							}
						}
						System.Diagnostics.Debug.WriteLine(builder.ToString());
						cmd.CommandText = builder.ToString();
						cmd.ExecuteNonQuery();
					}
				}

				for (int i = 1; i <= 3; i++)
				{
					if (i == 1)
					{
						curDiscDataTableName = "DisciplineMech";
					}
					else if (i == 2)
					{
						curDiscDataTableName = "DisciplineStruct";
					}
					else if (i == 3)
					{
						curDiscDataTableName = "DisciplineLand";
					}

//					//mam 112806 - moved this code down so that null values will be preserved when setting Repair Cost
//					//set all acquisition cost values to zero where they are currently null
//					try
//					{
//						builder.Remove(0, builder.Length);
//						builder.AppendFormat("UPDATE {0} SET disc{1}_acquisitionCost = 0 WHERE IsNull(disc{2}_acquisitionCost)", curDiscDataTableName, i, i);
//						//System.Diagnostics.Debug.WriteLine(builder.ToString());
//						cmd.CommandText = builder.ToString();
//						cmd.ExecuteNonQuery();
//					}
//					catch
//					{
//					}
				}

				return true;
			}
			catch
			{
				MessageBox.Show("An error has occurred in Update3.UpdateDisciplineMSCAcquisitionCost", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		//mam 050806
		private bool AddRedundancyField()
		{
			try
			{
				if (AddField("MajorComponents", "RedundantAssetCount", "INTEGER", 1))
				{
					//MessageBox.Show("populate new redundant field");
					PopulateField("MajorComponents", "RedundantAssetCount", 1);
				}

				if (AddField("NodeAppurtComponents", "RedundantAssetCount", "INTEGER", 1))
				{
					PopulateField("NodeAppurtComponents", "RedundantAssetCount", 1);
				}

				if (AddField("PipingComponents", "RedundantAssetCount", "INTEGER", 1))
				{
					PopulateField("PipingComponents", "RedundantAssetCount", 1);
				}

				return true;
			}
			catch
			{
				return false;
			}
		}

		//mam 050806
		public bool AddField(string tableName, string columnName, string fieldType, int defaultValue)
		{
			try
			{
				resultLogUpdate3.Add(string.Format("Update3.AddField {0}.{1} start", tableName, columnName));

				cmd.CommandText = string.Format("ALTER TABLE {0} ADD COLUMN {1} {2}", tableName, columnName, fieldType);
				cmd.ExecuteNonQuery();

				cmd.CommandText = string.Format("ALTER TABLE {0} ALTER COLUMN {1} SET DEFAULT {2}", tableName, columnName, defaultValue);
				cmd.ExecuteNonQuery();
			}
			catch
			{
				resultLogUpdate3.Add(string.Format("AddField {0} field not created in {1} table", columnName, tableName));
				return false;
			}

			resultLogUpdate3.Add(string.Format("AddField {0}.{1} stop", tableName, columnName));
			return true;
		}

		//mam 050806
		public bool PopulateField(string tableName, string columnName, int setValue)
		{
			StringBuilder builder = new StringBuilder(50);
			// add new Component Information fields to the DisciplineLand table
			try
			{
				resultLogUpdate3.Add(string.Format("PopulateField {0}.{1} start", tableName, columnName));

				//populate the new fields with the N/A value
				builder.AppendFormat("UPDATE {0} SET {1} = {2}", tableName, columnName, setValue);
				cmd.CommandText = builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("ComponentInformation fields not added to DisciplineLand table");
			}
			finally
			{
				resultLogUpdate3.Add("UpdateDisciplineLandTable stop");
			}
			return true;
		}

		//mam 112806
		private bool ChangeDefaultENRCustomTableName()
		{
			//Default ENR Custom Table
			StringBuilder builder = new StringBuilder(50);

			//change name of existing, automatically-created default custom ENR table
			try
			{
				resultLogUpdate3.Add("ChangeDefaultENRCustomTableName CustomENRList.CustomENRListName start");

				builder.Append("UPDATE CustomENRList SET CustomENRListName = 'Custom ENR Table'");
				builder.Append(" WHERE CustomENRListName = 'Default ENR Custom Table'");
				builder.Append(" OR CustomENRListName = 'Default Custom ENR Table'");
				cmd.CommandText = builder.ToString();
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate3.Add("ChangeDefaultENRCustomTableName not completed");
			}
			finally
			{
				resultLogUpdate3.Add("ChangeDefaultENRCustomTableName stop");
			}
			return true;
		}

		private bool Cleanup()
		{
			try
			{
				cmd = null;
				//dataTable = null;
				//dataSet = null;
				dataAccess = null;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Update3 Methods *****/
	}
}
