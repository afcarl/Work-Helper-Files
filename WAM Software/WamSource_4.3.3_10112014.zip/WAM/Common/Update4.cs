using System;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Text;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Update4.
	/// </summary>
	public class Update4
	{

		#region /***** Member Variables *****/

		//mam 102309
		//DataAccess dataAccess = new DataAccess();
		UpdateDataAccess dataAccess = new UpdateDataAccess();

		OleDbCommand cmd = null;
		ArrayList resultLogUpdate4 = new ArrayList();

		private int keyCount = 0;
		private int indexCount = 0;
		private string useConnectionString;
		private string databaseName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public Update4(string DBName)
		{
			//useConnectionString = connectionString;
			databaseName = DBName;
		}

		#endregion /***** Construction *****/

		#region /***** Methods *****/

		private int NextKey()
		{
			keyCount += 1;
			return keyCount;
		}

		private int NextIndex()
		{
			indexCount += 1;
			return indexCount;
		}

		public bool PerformUpdate()
		{
			// perform database updates
			try
			{
				//if a connection can't be opened, exit
				//	(return true regardless of error)
				//if (OpenConnectionForUpdating())
				{
					SetDatabasePassword();

					//mam 102309 - don't do this - just import the data as is
					//103108 - update 20 Cities ENR database to include valeus for 2007 and 2008,
					//	if they are not already there (don't overwrite existing 2007 and 2008 ENR values)
					//UpdateEnrValues();
				}
				Cleanup();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Methods *****/

		#region /***** Update4 Methods *****/

		private bool OpenConnectionForUpdating()
		{
			// open a connection
			try
			{
				resultLogUpdate4.Add("OpenConnectionForUpdating start");

				cmd = dataAccess.GetCommandObject(useConnectionString);

				if (cmd == null)
				{
					resultLogUpdate4.Add("OpenConnectionForUpdating not attempted");
					return false;
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate4.Add("OpenConnectionForUpdating failed on create OleDbCommand");
			}
			return true;
		}
		
		private bool SetDatabasePassword()
		{
			//make sure all databases have a password
			try
			{
				resultLogUpdate4.Add("SetDatabasePassword start");

				if (databaseName.Length == 0)
				{
					//set password for all verified databases in the app folder
					System.IO.DirectoryInfo appDirectory;
					appDirectory = new System.IO.DirectoryInfo(@Drive.IO.Directory.GetApplicationPath());

					WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();

					foreach (System.IO.FileInfo f in appDirectory.GetFiles("*.mdb"))
					{
						if (verify.VerifyTables(f.Name))
						{
							databaseName = f.Name;
							useConnectionString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password={0};Data Source={1};Mode=12;", 
								WAM.Common.Globals.AccessPassword, @databaseName);
							OpenConnectionForUpdating();

							ResetDatabasePassword();
						}
					}
				}
				else
				{
					//set password only for the specified database
					useConnectionString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password={0};Data Source={1};Mode=12;", 
						WAM.Common.Globals.AccessPassword, @databaseName);
					OpenConnectionForUpdating();

					ResetDatabasePassword();
				}
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				resultLogUpdate4.Add("Update4 SetDatabasePassword Failed");
			}
			finally
			{
				resultLogUpdate4.Add("Update4 SetDatabasePassword stop");
			}
			return true;
		}

		private void ResetDatabasePassword()
		{
			try
			{
				cmd.CommandText = "ALTER DATABASE PASSWORD " + WAM.Common.Globals.AccessPassword + " NULL";
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}

			try
			{
				cmd.CommandText = "ALTER DATABASE PASSWORD " + WAM.Common.Globals.AccessPassword + " " + WAM.Common.Globals.AccessPassword;
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}

			try
			{
				cmd.Connection.Close();
			}
			catch
			{
			}
		}

		#region /***** UpdateENRValues *****/

		//mam 102309 - don't do this - just import the data as is

		//103108 - update 20 Cities ENR database to include valeus for 2005 through 2008,
		//	if they are not already there (don't overwrite existing 2005-2008 ENR values)
//		public bool UpdateEnrValues()
//		{
//			OleDbConnection sqlConnection = new OleDbConnection();
//			bool returnValue = true;
//
//			try
//			{
//				string connectionStringENR = WAM.Data.WAMSource.ENRSource.ConnectionString;
//				sqlConnection = new OleDbConnection(connectionStringENR);
//				OleDbCommand	sqlCommand = null;
//
//				string querySqlString = "SELECT * FROM ENR20Cities WHERE enr_year >= 2005 ORDER BY enr_year";
//				string insert2005 = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2005, 7446)";
//				string insert2006 = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2006, 7751)";
//				string insert2007 = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2007, 8045)";
//				string insert2008 = "INSERT INTO ENR20Cities (enr_year, enr_value) VALUES (2008, 8362)";
//
//				//check whether the years 2005-2008 exist in ENR20Cities table
//
//				//get 20CitiesENR values
//				DataTable dataTableEnrValues20Cities = dataAccess.GetDisconnectedDataTable(
//					querySqlString, WAM.Data.WAMSource.ENRSource.ConnectionString);
//				if (dataTableEnrValues20Cities == null)
//				{
//					returnValue = false;
//					throw new Exception();
//				}
//
//				sqlConnection.Open();
//
//				//insert 2005-2008 ENR values if they don't already exist
//
//				//2005
//				string findRow = "enr_year = 2005";
//				DataRow[] dataRowFind = dataTableEnrValues20Cities.Select(findRow);
//				if (dataRowFind == null || dataRowFind.Length == 0)
//				{
//					try
//					{
//						sqlCommand = new OleDbCommand(insert2005, sqlConnection);
//						sqlCommand.ExecuteNonQuery();
//					}
//					catch
//					{
//						returnValue = false;
//					}
//				}
//
//				//2006
//				findRow = "enr_year = 2006";
//				dataRowFind = null;
//				dataRowFind = dataTableEnrValues20Cities.Select(findRow);
//				if (dataRowFind == null || dataRowFind.Length == 0)
//				{
//					try
//					{
//						sqlCommand = new OleDbCommand(insert2006, sqlConnection);
//						sqlCommand.ExecuteNonQuery();
//					}
//					catch
//					{
//						returnValue = false;
//					}
//				}
//
//				//2007
//				findRow = "enr_year = 2007";
//				dataRowFind = null;
//				dataRowFind = dataTableEnrValues20Cities.Select(findRow);
//				if (dataRowFind == null || dataRowFind.Length == 0)
//				{
//					try
//					{
//						sqlCommand = new OleDbCommand(insert2007, sqlConnection);
//						sqlCommand.ExecuteNonQuery();
//					}
//					catch
//					{
//						returnValue = false;
//					}
//				}
//
//				//2008
//				findRow = "enr_year = 2008";
//				dataRowFind = null;
//				dataRowFind = dataTableEnrValues20Cities.Select(findRow);
//				if (dataRowFind == null || dataRowFind.Length == 0)
//				{
//					try
//					{
//						sqlCommand = new OleDbCommand(insert2008, sqlConnection);
//						sqlCommand.ExecuteNonQuery();
//					}
//					catch
//					{
//						returnValue = false;
//					}
//				}
//
//			}
//			catch (OleDbException ex)
//			{
//				returnValue = false;
//				System.Diagnostics.Trace.WriteLine(
//					String.Format("Update4 UpdateEnrValues Error: {0}\n", ex.Message));
//			}
//			catch (Exception ex)
//			{
//				returnValue = false;
//				System.Diagnostics.Trace.WriteLine(
//					String.Format("Update4 UpdateEnrValues Error: {0}\n", ex.Message));
//			}
//			finally
//			{
//				if (sqlConnection != null && sqlConnection.State != System.Data.ConnectionState.Closed)
//				{
//					sqlConnection.Close();
//				}
//
//				sqlConnection.Dispose();
//			}
//
//			return returnValue;
//		}
		#endregion /***** UpdateENRValues *****/

		private bool Cleanup()
		{
			try
			{
				cmd = null;
				dataAccess = null;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}
			return true;
		}

		#endregion /***** Update4 Methods *****/
	}
}
