 using System;
using System.Data;
using System.Text;
using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using WAM.Data;
using Drive.Collections;


namespace WAM.Common
{
	/// <summary>
	/// Summary description for CommonTasks.
	/// </summary>
	/// 

	public class CommonTasks
	{
		public ArrayList nodesExpanded = new ArrayList();

		//mam 07072011
		public static void GenerateDivideByZeroError()
		{
			int testInt = 0;
			int testInt2 = 1 / testInt;
		}

		//mam 07072011
		private static int defaultCipPlanningId = 0;
		private static int zeroRehabCostCipPlanningId = 0;
		private static int nonZeroRehabCostCipPlanningId = 0;
		public static ArrayList ArrayListCipObjects = new ArrayList();

		//mam 07072011
		public struct Cip
		{
			private int cipPlanningId;
			private int defaultCipPlanningId;
			private bool zeroRehabCost;
			private bool useAsDefault;
			private string cipPlanningText;

			public int CipPlanningId
			{
				get { return cipPlanningId; }
				set { cipPlanningId = value; }
			}

			public int DefaultCipPlanningId
			{
				get { return defaultCipPlanningId; }
				set { defaultCipPlanningId = value; }
			}

			public bool ZeroRehabCost
			{
				get { return zeroRehabCost; }
				set { zeroRehabCost = value; }
			}

			public bool UseAsDefault
			{
				get { return useAsDefault; }
				set { useAsDefault = value; }
			}

			public string CipPlanningText
			{
				get { return cipPlanningText; }
				set { cipPlanningText = value; }
			}
		}

		//mam 11142011
		public struct CritMapper
		{
			private int criticalityId;
			//private CriticalityFactor factor;
			private Hashtable hashTableAccessToFactorId;

			public int CriticalityId
			{
				get { return criticalityId; }
				set { criticalityId = value; }
			}

			//public CriticalityFactor Factor
			//{
			//	get { return factor; }
			//	set { factor = value; }
			//}

			public Hashtable HashTableAccessToFactorId
			{
				get { return hashTableAccessToFactorId; }
				set { hashTableAccessToFactorId = value; }
			}
		}

		//example of regex to determine number in format ###.##
		//private string regExExample = @"(^-?\d{1,3}\.$)|(^-?\d{1,3}$)|(^-?\d{0,3}\.\d{1,2}$)";
		private static string regExInteger = @"^\d+$";

		public CommonTasks()
		{
		}

		public ArrayList RecordTreeExpandedState(TreeView treeView)
		{
			nodesExpanded.Clear();

			foreach (TreeNode node in treeView.Nodes)
			{
				RecordTreeExpandedNodes(node);
			}
			return nodesExpanded;
		}

		private void RecordTreeExpandedNodes(TreeNode node)
		{
			if (node.IsExpanded)
			{
				nodesExpanded.Add(node.Tag);
			}
			foreach (TreeNode childNode in node.Nodes)
			{
				RecordTreeExpandedNodes(childNode);
			}
		}

		public static bool IsNumericInteger(string checkValue)
		{
			if (checkValue == "")
				return false;

			if (!Regex.IsMatch(checkValue, regExInteger))
				return false;

			return true;
		}

		public static bool WriteFile(string fileName, string fileContents, bool appendToFile)
		{
			if (fileName == "")
				return false;

			try
			{
				using (System.IO.StreamWriter streamWriter = new System.IO.StreamWriter(fileName, appendToFile)) 
				{
					streamWriter.Write(fileContents);
					return true;
				}
			}
			catch
			{
				return false;
			}
		}

		public static bool WriteXMLFile(string XML, string fileName, FileMode fileMode)
		{
			FileStream file = null;
			StreamWriter writer = null;
			string			filePath = string.Format("{0}\\{1}", 
				Drive.IO.Directory.GetApplicationPath(), 
				fileName);

			try
			{
				file = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);

				writer = new StreamWriter(file);
				writer.Write(XML);
				writer.Close();
				file = null;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message.ToString());
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}

			return true;
		}

		public static void DoStackTrace()
		{
			StackTrace callStack = new StackTrace(true);
			StackFrame stackFrame = new StackFrame();
			string traceInfo = callStack.ToString();
			
			for(int i = 0; i < callStack.FrameCount; i++)
			{
				stackFrame = callStack.GetFrame(i);
				
				try
				{
					Debug.WriteLine(stackFrame.GetFileName().ToString());
				}
				catch
				{
				}
				finally
				{
					Debug.WriteLine(stackFrame.GetFileLineNumber().ToString() + " : ");
					Debug.WriteLine(stackFrame.GetMethod().ToString());
				}
			}
		}

		public static decimal[] AdjustCWPValues(int infoSetID, int itemID, decimal totalValue, WAM.UI.NodeType itemType)
		{
			decimal[] cwpArrayTruncValue = null;

			try
			{
				if (totalValue == 0)
					return null;

				WAM.Data.Facility[] facilities = null;
				WAM.Data.TreatmentProcess[] processes = null;
				WAM.Data.MajorComponent[] components = null;
				WAM.Data.Discipline[] disciplines = null;

				decimal trueValue = 0;
				decimal tempItem = 0;
				long totalTruncValue = 0;
				bool bubbleSorted = false;
				long totalAdjustmentsRequired = 0;
				int ArrayLength = 0;

				switch (itemType)
				{
					case WAM.UI.NodeType.InfoSet:
						facilities = WAM.Data.CacheManager.GetFacilities(infoSetID);
						ArrayLength = facilities.Length;
						break;

					case WAM.UI.NodeType.Facility:
						processes = WAM.Data.CacheManager.GetProcesses(infoSetID, itemID);
						ArrayLength = processes.Length;
						break;
				
					case WAM.UI.NodeType.TreatmentProcess:
						components = WAM.Data.CacheManager.GetComponents(infoSetID, itemID);
						ArrayLength = components.Length;
						break;

					case WAM.UI.NodeType.MajorComponent:
						disciplines = WAM.Data.CacheManager.GetDisciplines(infoSetID, itemID);
						ArrayLength = disciplines.Length;
						break;
				}

				cwpArrayTruncValue = new decimal[ArrayLength];
				decimal[] cwpArrayErrorValue = new decimal[ArrayLength];
				decimal[,] bubbleList = new decimal[ArrayLength, 2];

				switch (itemType)
				{
					case WAM.UI.NodeType.InfoSet:
						for (int i = 0; i < ArrayLength; i++)
						{
							//mam 112806 - use AcquisitionCost instead of CurrentValue
							//divide CurrentValue for this row by the total of the Current Value column
							//trueValue = facilities[i].GetCurrentValue() / totalValue * 100m;
							trueValue = facilities[i].GetAcquisitionCostRoundIndividualValues() / totalValue * 100m;

							//truncate trueValue after the first decimal place
							cwpArrayTruncValue[i] = (Decimal.Truncate(trueValue * 10m)) / 10m;

							//calculate error value
							cwpArrayErrorValue[i] = trueValue - cwpArrayTruncValue[i];

							//multiply truncated value by 10 to work in whole numbers
							totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[i] * 10m);
						}
						break;

					case WAM.UI.NodeType.Facility:
						for (int i = 0; i < ArrayLength; i++)
						{
							//mam 112806 - use AcquisitionCost instead of CurrentValue
							//trueValue = processes[i].GetCurrentValue() / totalValue * 100m;
							trueValue = processes[i].GetAcquisitionCostRoundIndividualValues() / totalValue * 100m;

							cwpArrayTruncValue[i] = (Decimal.Truncate(trueValue * 10m)) / 10m;
							cwpArrayErrorValue[i] = trueValue - cwpArrayTruncValue[i];
							totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[i] * 10m);
						}
						break;
				
					case WAM.UI.NodeType.TreatmentProcess:
						for (int i = 0; i < ArrayLength; i++)
						{
							if (components[i].Retired)
								continue;

							//mam 112806 - use AcquisitionCost instead of CurrentValue
							//trueValue = components[i].GetCurrentValue() / totalValue * 100m;
							trueValue = components[i].GetAcquisitionCostRoundIndividualValues() / totalValue * 100m;

							cwpArrayTruncValue[i] = (Decimal.Truncate(trueValue * 10m)) / 10m;
							cwpArrayErrorValue[i] = trueValue - cwpArrayTruncValue[i];
							totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[i] * 10m);
						}
						break;

					case WAM.UI.NodeType.MajorComponent:
						for (int i = 0; i < ArrayLength; i++)
						{
							//mam 112806 - use AcquisitionCost instead of CurrentValue
							//trueValue = disciplines[i].GetCurrentValue() / totalValue * 100m;
							trueValue = disciplines[i].AcquisitionCostRoundIndividualValues / totalValue * 100m;

							cwpArrayTruncValue[i] = (Decimal.Truncate(trueValue * 10m)) / 10m;
							cwpArrayErrorValue[i] = trueValue - cwpArrayTruncValue[i];
							totalTruncValue += Convert.ToInt64(cwpArrayTruncValue[i] * 10m);
						}
						break;
				}

				//populate bubbleList array
				bubbleSorted = false;
				for (int i = 0; i < ArrayLength; i++)
				{
					//assign the counter
					bubbleList[i, 0] = i;
					//assign the error value
					bubbleList[i, 1] = cwpArrayErrorValue[i];
				}

				//sort the bubbleList from highest to lowest Error Value
				bubbleSorted = false;
				do
				{
					bubbleSorted=true;
					for (int i = 0; i < ArrayLength-1; i++)
					{
						if (bubbleList[i,1] < bubbleList[i+1,1])
						{
							bubbleSorted = false;

							//switch the order of the two items
							tempItem = bubbleList[i,1];
							bubbleList[i,1] = bubbleList[i+1,1];
							bubbleList[i+1,1] = tempItem;

							tempItem = bubbleList[i,0];
							bubbleList[i,0] = bubbleList[i+1,0];
							bubbleList[i+1,0] = tempItem;
						}
					}
				}
				while (!bubbleSorted);

				//adjust the truncated values, as necessary
				totalAdjustmentsRequired = 1000 - totalTruncValue;
				for (int i = 0; i < totalAdjustmentsRequired; i++)
				{
					cwpArrayTruncValue[Convert.ToInt32(bubbleList[i, 0])] += 0.1m;
				}

				return cwpArrayTruncValue;
			}
			catch
			{
				return cwpArrayTruncValue;
			}
		}

		public static string SplitVulnerability(string toSplit)
		{
			string delimStr = ".";
			char [] delimiter = delimStr.ToCharArray();
			char charPad = '0';
			string [] split = null;
			string tempString = "";

			split = toSplit.Split(delimiter);
			tempString = split[split.Length-1].ToString();
			tempString = tempString.PadRight(4, charPad);
			
			return tempString;
		}

		public static bool GetAllERULZero(int infoSetID, int componentID)
		{
			//mam - check whether all Disciplines for this Component have ERUL = zero

			bool AllNA = true;

			WAM.Data.Discipline[] disciplines = WAM.Data.CacheManager.GetDisciplines(infoSetID, componentID);
			WAM.Data.Discipline discipline;

			WAM.Data.DisciplinePipe	pipe;
			WAM.Data.DisciplineNode	node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == WAM.Data.DisciplineType.Pipes)
				{
					//MessageBox.Show(m_root.Name.ToString());
					pipe = discipline as WAM.Data.DisciplinePipe;
					if (!pipe.GetAllERULZero())
					{
						AllNA = false;
						break;
					}
				}
				if (discipline.Type == WAM.Data.DisciplineType.Nodes)
				{
					//MessageBox.Show(m_root.Name.ToString());
					node = discipline as WAM.Data.DisciplineNode;
					if (!node.GetAllERULZero())
					{
						AllNA = false;
						break;
					}
				}
				if (discipline.Type == WAM.Data.DisciplineType.Mechanical 
					|| discipline.Type == WAM.Data.DisciplineType.Structural
					|| discipline.Type == WAM.Data.DisciplineType.Land)
				{
					if (discipline.GetEvaluatedRemainingUsefulLife() != 0)
					{
						AllNA = false;
						break;
					}
				}
			}

			return AllNA;
		}
		//</mam>

		//mam
		public static bool GetAnyVulnerabilityOverridden(int infoSetID, int componentID)
		{
			//mam - check whether any Discipline for this Component has overridden vulnerability
			//	or, for the case of MSL Disciplines, check whether the component has overridden vulnerability

			WAM.Data.MajorComponent component = WAM.Data.CacheManager.GetMajorComponent(infoSetID, componentID);

			bool AllNA = false;

			WAM.Data.Discipline[] disciplines = WAM.Data.CacheManager.GetDisciplines(infoSetID, componentID);
			WAM.Data.Discipline discipline;

			WAM.Data.DisciplinePipe	pipe;
			WAM.Data.DisciplineNode	node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == WAM.Data.DisciplineType.Pipes)
				{
					pipe = discipline as WAM.Data.DisciplinePipe;
					if (pipe.GetAnyVulnerabilityOverridden())
					{
						AllNA = true;
						break;
					}
				}
				if (discipline.Type == WAM.Data.DisciplineType.Nodes)
				{
					node = discipline as WAM.Data.DisciplineNode;
					if (node.GetAnyVulnerabilityOverridden())
					{
						AllNA = true;
						break;
					}
				}
				if (discipline.Type == WAM.Data.DisciplineType.Mechanical 
					|| discipline.Type == WAM.Data.DisciplineType.Structural
					|| discipline.Type == WAM.Data.DisciplineType.Land)
				{
					//if (discipline.GetVulnerabilityOverridden())
					if (component.OverrideVulnerability)
					{
						AllNA = true;
						break;
					}
				}
			}

			return AllNA;
		}

		//determine if all pipes or nodes in a discipline have condition = n/a
		public bool GetAllConditionNA(WAM.Data.Discipline discipline)
		{
			if (discipline is WAM.Data.DisciplinePipe)
			{
				// Retrieve the pipe data for the current discipline
				WAM.Data.PipeData[] pipes = WAM.Data.CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = true;

				// Retrieve the Condition from the pipe data
				for (int pos = 0; pos < pipes.Length; pos++)
					if (pipes[pos].ConditionRank != WAM.Data.CondRank.No)
					{
						AllNA = false;
						break;
					}

				return AllNA;
			}
			else if (discipline is WAM.Data.DisciplineNode)
			{
				// Retrieve the node data for the current discipline
				WAM.Data.NodeData[] nodes = WAM.Data.CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = true;

				// Retrieve the Condition from the node data
				for (int pos = 0; pos < nodes.Length; pos++)
					if (nodes[pos].ConditionRank != WAM.Data.CondRank.No)
					{
						AllNA = false;
						break;
					}

				return AllNA;
			}

			return false;
		}

		//mam 102309 - no longer using this
		//		public static string RemoveConnectionDataFromStringToGetFileName(string stringToCheck)
		//		{
		//			try
		//			{
		//				//apparently Drive dll returns the entire connectionString instead of the just file name,
		//				//	thus revealing the database password; remove the password from the string
		//				stringToCheck = stringToCheck.Replace("Password=" + WAM.Common.Globals.AccessPassword, "");
		//				
		//				//if the currentDB string contains "DataSource" then that means that it contains the
		//				//	connection string data rather than just the file name, so delete the connection string data
		//				int pos = stringToCheck.LastIndexOf("Data Source=");
		//				if (pos > -1)
		//				{
		//					stringToCheck = stringToCheck.Remove(0, pos + "Data Source=".Length);
		//				}
		//
		//				return stringToCheck;
		//			}
		//			catch
		//			{
		//				return string.Empty;
		//			}
		//		}

		//mam 102309 - don't display database name
		//		public string GetCurrentDatabaseName(bool includeExtension)
		//		{
		//			string connectionString = "";
		//			string currentDB = "";
		//			try
		//			{
		//				//mam 102309
		//				//connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString.Trim();
		//				connectionString = Globals.WamSqlConnectionString.Trim();
		//				
		//				currentDB = Drive.IO.Directory.GetFileNameFromPath(connectionString, includeExtension);
		//
		//				currentDB = RemoveConnectionDataFromStringToGetFileName(currentDB);
		//				//				//apparently Drive dll returns the entire connectionString instead of the just file name,
		//				//				//	thus revealing the database password; remove the password from the string
		//				//				currentDB = currentDB.Replace("Password=" + WAM.Common.Globals.AccessPassword, "");
		//				//				
		//				//				//if the currentDB string contains "DataSource" then that means that it contains the
		//				//				//	connection string data rather than just the file name, so delete the connection string data
		//				//				int pos = currentDB.LastIndexOf("Data Source=");
		//				//				if (pos > -1)
		//				//				{
		//				//					currentDB = currentDB.Remove(0, pos + "Data Source=".Length);
		//				//				}
		//
		//				if (currentDB.EndsWith(";"))
		//				{
		//					currentDB = currentDB.Remove(currentDB.Length - 1, 1);
		//				}
		//			}
		//			catch (Exception ex)
		//			{
		//				System.Diagnostics.Trace.WriteLine(
		//					String.Format("MainForm.OnLoad Error: {0}\n", ex.Message));
		//				System.Diagnostics.Debug.Assert(false, ex.Message);
		//			}
		//
		//			if (currentDB == null || currentDB.Length == 0)
		//			{
		//				return "";
		//			}
		//			else
		//			{
		//				return currentDB;
		//			}
		//		}

		//mam 102309 - no longer necessary
		//		public string CreateDatabaseImageFolderName()
		//		{
		//			int counter = 1;
		//			string imageFolder = "";
		//			string testFolder = "";
		//			string databaseName = GetCurrentDatabaseName(false);
		//			string appPath = Drive.IO.Directory.GetApplicationPath() + @"\Images\";
		//
		//			if (!System.IO.Directory.Exists(appPath + databaseName))
		//			{
		//				imageFolder = @appPath + databaseName;
		//			}
		//			else
		//			{
		//				while (imageFolder == "")
		//				{
		//					testFolder = appPath + databaseName + counter.ToString();
		//					if (System.IO.Directory.Exists(testFolder))
		//					{
		//						counter++;
		//					}
		//					else
		//					{
		//						imageFolder = testFolder;
		//					}
		//				}
		//			}
		//
		//			if (imageFolder != "")
		//			{
		//				try
		//				{
		//					System.IO.Directory.CreateDirectory(imageFolder);
		//				}
		//				catch
		//				{
		//					imageFolder = "";
		//				}
		//			}
		//
		//			return imageFolder;
		//		}

		//mam 102309 - no longer necessary
		//		public string CreateDatabaseImageFolderName(string databaseName)
		//		{
		//			int counter = 1;
		//			string imageFolder = "";
		//			string testFolder = "";
		//			string appPath = Drive.IO.Directory.GetApplicationPath() + @"\Images\";
		//
		//			if (!System.IO.Directory.Exists(appPath + databaseName))
		//			{
		//				imageFolder = @appPath + databaseName;
		//			}
		//			else
		//			{
		//				while (imageFolder == "")
		//				{
		//					testFolder = appPath + databaseName + counter.ToString();
		//					if (System.IO.Directory.Exists(testFolder))
		//					{
		//						counter++;
		//					}
		//					else
		//					{
		//						imageFolder = testFolder;
		//					}
		//				}
		//			}
		//
		//			if (imageFolder != "")
		//			{
		//				try
		//				{
		//					System.IO.Directory.CreateDirectory(imageFolder);
		//				}
		//				catch
		//				{
		//					imageFolder = "";
		//				}
		//			}
		//
		//			return imageFolder;
		//		}

		//mam 102309 - no longer necessary
		//		public bool CreateDatabaseInfosetFolderName(string folderNameWithPath)
		//		{
		//			if (folderNameWithPath != "")
		//			{
		//				if (!System.IO.Directory.Exists(folderNameWithPath))
		//				{
		//					try
		//					{
		//						System.IO.Directory.CreateDirectory(folderNameWithPath);
		//					}
		//					catch
		//					{
		//						return false;
		//					}
		//				}
		//			}
		//
		//			return true;
		//		}

		public void SetBitmap(PictureBox pictureBox)
		{
			System.Drawing.Bitmap b = (System.Drawing.Bitmap)pictureBox.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBox.Image = b;
		}

		public void LoadImage(PictureBox pictureBox, string imageName)
		{
			System.Reflection.Assembly thisExe;
			thisExe = System.Reflection.Assembly.GetExecutingAssembly();

			System.IO.Stream file = thisExe.GetManifestResourceStream(imageName);

			System.Drawing.Image image = (System.Drawing.Bitmap)System.Drawing.Bitmap.FromStream(file);
			pictureBox.Image = image;
		}

		public void LoadHelpImage(PictureBox pictureBox)
		{
			System.Reflection.Assembly thisExe;
			thisExe = System.Reflection.Assembly.GetExecutingAssembly();

			System.IO.Stream file = thisExe.GetManifestResourceStream("WAM.Graphics.HelpImage.bmp");

			System.Drawing.Image image = (System.Drawing.Bitmap)System.Drawing.Bitmap.FromStream(file);
			pictureBox.Image = image;
			pictureBox.Refresh();

			//set transparent color
			System.Drawing.Bitmap b = (System.Drawing.Bitmap)pictureBox.Image;
			b.MakeTransparent(System.Drawing.Color.Fuchsia);
			pictureBox.Image = b;
		}

		//mam 102309
		public static string GetInfosetImagePath(int infosetId)
		{
			string photoPath = "";
			try
			{
				photoPath = WAM.Common.Globals.WamPhotoPath;
				string infosetName = CacheManager.GetInfosetNameForInfoSetID(infosetId);
				photoPath += "\\" + infosetName;
			}
			catch
			{
			}
			
			return photoPath;
		}

		//mam 102309
		public static void SetInfosetImagePath(string setPath)
		{
			try
			{
				//Drive.Configuration.AppSettings.Settings.SetSetting("PhotoPaths", "Infoset" + infosetId, setPath);

				Drive.Configuration.AppSettings.Settings.SetSetting("PhotoPaths", "BaseImagePath", setPath);
				Drive.Configuration.AppSettings.Settings.Save();
				WAM.Common.Globals.WamPhotoPath = setPath;
			}
			catch
			{
			}
		}

		//mam 07072011
		public static bool DoesImagesFolderExist(string folderPath)
		{
			if (!System.IO.Directory.Exists(folderPath))
			{
				string msg = "WAM cannot find the images folder:" + Environment.NewLine + Environment.NewLine + folderPath;

				//mam 03202012
				//ShowErrorMessage("DoesImagesFolderExist", msg);
				ShowPhotoPathNotFoundMessage(msg);

				return false;
			}

			return true;
		}

		#region /***** Tree Populate *****/

		public void		LoadSpecificUnitsTree(TreeView treeViewSpecificUnits, int InfoSetID)
		{
			WAM.Data.Facility[]		facilities = null;
			WAM.Data.Facility		facility = null;

			//mam - comment lines no longer used
			//			if (radioPrintAllFacilities.Checked)
			//			{
			//				// Load a list of all items from all facilities into a tree
			facilities = WAM.Data.CacheManager.GetFacilities(InfoSetID);
			//			}
			//			else
			//			{
			//				facility = comboBoxFacility.SelectedItem as Facility;
			//				if (facility != null && facility.ID != 0)
			//					facilities = new Facility[1] { facility };
			//				else
			//					facilities = new Facility[0];
			//			}

			TreeNode		node;

			// Walk the facilities array and add the items to the tree
			treeViewSpecificUnits.BeginUpdate();
			treeViewSpecificUnits.Nodes.Clear();
			
			// Populate the facilities
			for (int pos = 0; pos < facilities.Length; pos++)
			{
				facility = facilities[pos];
				node = new TreeNode(facility.Name);
				node.Tag = facility;

				//mam
				node.ImageIndex = 0;
				node.SelectedImageIndex = 0;
				//</mam>

				treeViewSpecificUnits.Nodes.Add(node);

				if (facility.HasChildren)
					PopulateTreeProcesses(node, InfoSetID);
			}

			treeViewSpecificUnits.EndUpdate();
		}

		public void PopulateTreeProcesses(TreeNode facilityNode, int InfoSetID)
		{
			// Get the root nodes (facilities)
			WAM.Data.TreatmentProcess[] processes = 
				WAM.Data.CacheManager.GetProcesses(InfoSetID, 
				((WAM.Data.Facility)facilityNode.Tag).ID);
			WAM.Data.TreatmentProcess process;
			TreeNode		node;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				node = new TreeNode(process.Name);
				node.Tag = process;

				//mam
				node.ImageIndex = 3;
				node.SelectedImageIndex = 3;
				//</mam>

				facilityNode.Nodes.Add(node);

				if (process.HasChildren)
					PopulateTreeComponents(node, InfoSetID);
			}
		}

		public void		PopulateTreeComponents(TreeNode processNode, int InfoSetID)
		{
			// Get the root nodes (facilities)
			WAM.Data.MajorComponent[] components = 
				WAM.Data.CacheManager.GetComponents(InfoSetID, 
				((WAM.Data.TreatmentProcess)processNode.Tag).ID);
			WAM.Data.MajorComponent	component;
			TreeNode		node;

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				node = new TreeNode(component.Name);
				node.Tag = component;
				
				//mam
				node.ImageIndex = 5;
				node.SelectedImageIndex = 5;
				//</mam>
				
				processNode.Nodes.Add(node);

				// Add disciplines
				PopulateTreeDisciplines(node, InfoSetID);
			}
		}

		public void		PopulateTreeDisciplines(TreeNode componentNode, int InfoSetID)
		{
			// Get the root nodes (facilities)
			WAM.Data.Discipline[]	disciplines = 
				WAM.Data.CacheManager.GetDisciplines(InfoSetID, 
				((WAM.Data.MajorComponent)componentNode.Tag).ID);
			WAM.Data.Discipline		discipline;
			TreeNode		node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (discipline.ConditionRanking == WAM.Data.CondRank.No)
					continue;

				node = new TreeNode(discipline.Name);
				node.Tag = discipline;

				//mam
				node.ImageIndex = 7;
				node.SelectedImageIndex = 7;
				//</mam>

				componentNode.Nodes.Add(node);

				if (discipline.Type == WAM.Data.DisciplineType.Mechanical)
				{
					// Check to see if there are any assets for this item, and if
					// so, add an "asset list" node
					WAM.Data.ComponentAsset[] assets = 
						WAM.Data.CacheManager.GetAssets(InfoSetID, discipline.ComponentID);

					if (assets.Length > 0)
					{
						TreeNode assetNode;

						assetNode = new TreeNode("Asset List");
						assetNode.Tag = assets[0];

						//mam
						node.ImageIndex = 7;
						node.SelectedImageIndex = 7;
						//</mam>

						node.Nodes.Add(assetNode);
					}
				}
			}
		}

		#endregion /***** Tree Populate *****/

		public static void FileCopy(string srcdir, string destdir, bool recursive)
		{
			DirectoryInfo   dir;
			FileInfo[]      files;
			DirectoryInfo[] dirs;
			string          tmppath;

			//determine if the destination directory exists; if it doesn't, create it
			if (!Directory.Exists(destdir))
			{
				Directory.CreateDirectory(destdir);
			}

			dir = new DirectoryInfo(srcdir);
            
			//if the source dir doesn't exist, throw an exception
			if (!dir.Exists)
			{
				try
				{
					System.Diagnostics.Debug.WriteLine(string.Format("Directory '{0}' doesn't exist"), dir.ToString());
				}
				catch
				{
				}
			}

			//get all files in the current dir
			files = dir.GetFiles();

			//loop through each file
			foreach(FileInfo file in files)
			{
				//create the path to where this file should be in destdir
				tmppath=Path.Combine(destdir, file.Name);                

				//copy file to dest dir
				file.CopyTo(tmppath, false);
			}

			//clean up
			files = null;
            
			//if not recursive, we're finished
			if (!recursive)
			{
				return;
			}

			//otherwise, get dirs
			dirs = dir.GetDirectories();

			//loop through each sub directory in the current dir
			foreach(DirectoryInfo subdir in dirs)
			{
				//create the path to the directory in destdir
				tmppath = Path.Combine(destdir, subdir.Name);

				//call this function over and over again with each new dir.
				FileCopy(subdir.FullName, tmppath, recursive);
			}
            
			//clean up
			dirs = null;
			dir = null;
		}

		public static bool CopyImageFile(string imageSource, string imageDestination)
		{
			try
			{
				if (File.Exists(imageDestination))
				{
					//make sure existing file at the destination is not read only (so it can be overwritten)
					FileInfo fileInfo = new FileInfo(imageDestination);
					fileInfo.Attributes -= FileAttributes.ReadOnly;
				}

				if ((File.GetAttributes(imageSource) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
				{
					//the source file is read only
					FileInfo fileInfo = new FileInfo(imageSource);

					//remove read-only attribute from source file
					fileInfo.Attributes -= FileAttributes.ReadOnly;

					//copy source file to destination
					File.Copy(fileInfo.ToString(), imageDestination, true);

					//restore read-only attribute to source file
					//fileInfo.Attributes += FileAttributes.ReadOnly;
					File.SetAttributes(imageSource, File.GetAttributes(imageSource) | FileAttributes.ReadOnly);
				}
				else
				{
					//the source file is not read only
					System.IO.File.Copy(imageSource, imageDestination, true);
				}
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
				return false;
			}

			return true;
		}

		//mam 03202012
		public static OpenFileDialog GetPhotoOpenDialog()
		{
			OpenFileDialog fileDialog = new OpenFileDialog();
			fileDialog.Filter = "JPG Images (*.jpg)|*.jpg|Portable Network Graphics png (*.png)|*.png";
			fileDialog.CheckFileExists = true;
			fileDialog.Multiselect = false;
			//fileDialog.RestoreDirectory = true;
			//fileDialog.InitialDirectory = infoSetPhotoPath;

			return fileDialog;
		}

		//mam 03202012
		public static int GetPhotoCount(int infoSetId, string photoFileName)
		{
			//return -1 if an error occurs

			//need to check infoset id because each infoset has its own image folder, and it doesn't matter what photos exist
			//	in other infosets - there could be photos with the same name in other infoset folders, but they should not be counted

			int photoCount = -1;

			try
			{
				WAM.Common.DataAccess dataAccess = new DataAccess();
				photoCount = dataAccess.ExecuteScalar("GetPhotoCountSingle", "@infosetId", "@photoFileName", infoSetId, photoFileName);
			}
			catch(Exception ex)
			{
				ShowErrorMessage("GetPhotoCount", ex.Message);
				return -1;
			}

			return photoCount;
		}

		//mam 03202012
		public static SortedList GetPhotosToDelete(int assetId, WAM.UI.NodeType nodeType)
		{
			SortedList sortedList = new SortedList();

			try
			{
				using (DataAccess dataAccess = new DataAccess())
				{
					System.Data.DataTable dataTable = new DataTable();

					if (nodeType == WAM.UI.NodeType.InfoSet)
					{
						dataTable = dataAccess.GetDisconnectedDataTableSP("GetPhotosToDeleteInfoset", "@infosetId", assetId);
					}
					if (nodeType == WAM.UI.NodeType.Facility)
					{
						dataTable = dataAccess.GetDisconnectedDataTableSP("GetPhotosToDeleteFacility", "@facilityId", assetId);
					}
					if (nodeType == WAM.UI.NodeType.TreatmentProcess)
					{
						dataTable = dataAccess.GetDisconnectedDataTableSP("GetPhotosToDeleteProcess", "@processId", assetId);
					}
					if (nodeType == WAM.UI.NodeType.MajorComponent)
					{
						dataTable = dataAccess.GetDisconnectedDataTableSP("GetPhotosToDeleteComponent", "@componentId", assetId);
					}

					int counter = 0;
					foreach (System.Data.DataRow dataRow in dataTable.Rows)
					{
						sortedList.Add(counter, dataRow["PhotoFileName"].ToString());
						counter++;
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}

			return sortedList;
		}

//		//mam 03202012
//		public static int IsImageFileUsedByOtherAssets(string photoFileName)
//		{
//			//return -1 if an error occurs or if the data table is null
//
//			StringBuilder builder = new StringBuilder();
//
//			//need to also check infoset id because each infoset has its own image folder, and it doesn't matter what photos exist
//			//	in other infosets - there could be photos with the same name in other infoset folders, but they should not be counted
//			builder.AppendFormat("SELECT PhotoFileNameNorth AS PhotoFileName FROM Facilities WHERE PhotoFileNameNorth = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileNameSouth FROM Facilities WHERE PhotoFileNameSouth = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM TreatmentProcesses WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM MajorComponents WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM DisciplineMech WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM DisciplineStruct WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM DisciplineLand WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM DisciplinePipes WHERE PhotoFileName = '{0}'", photoFileName);
//			builder.AppendFormat("UNION ALL SELECT PhotoFileName FROM DisciplineNodes WHERE PhotoFileName = '{0}'", photoFileName);
//
//			System.Data.DataTable dataTable = new DataTable();
//			try
//			{
//				WAM.Common.DataAccess dataAccess = new DataAccess();
//				dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
//				if (dataTable == null)
//				{
//					return -1;
//				}
//			}
//			catch
//			{
//				return -1;
//			}
//
//			return dataTable.Rows.Count;
//		}

		public static int CreateCustomENRTable(int useInfosetID, int setENRValue, bool use20CitiesValues, bool showMessage, string customENRName)
		{
			try
			{
				WAM.Common.DataAccess dataAccess = new DataAccess();
				System.Data.DataSet dataSet = new System.Data.DataSet();
				string queryString = @"SELECT * FROM CustomENR WHERE CustomENRListID = 0";
				string executeStatement = "";

				if (useInfosetID == 0)
					executeStatement = string.Format("INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", "null", customENRName);
				else
					executeStatement = string.Format("INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", useInfosetID, customENRName);
				dataSet = dataAccess.GetDisconnectedDataset(queryString);
				if (dataSet == null)
					return 0;

				int newCustomENRID = dataAccess.ExecuteCommandReturnAutoID(executeStatement);
				if (newCustomENRID == 0)
					return 0;

				if (setENRValue < 0)
					setENRValue = 0;

				//check whether the 20 cities ENR database can be found and has values
				WAM.Data.ENR20Cities[] enrRecordsTest = WAM.Data.ENR20CitiesCache.GetAllENRValues();
				if (use20CitiesValues && enrRecordsTest.Length == 0 && showMessage)
				{
					MessageBox.Show("The ENR database has no values, or the database file (20CitiesENR.mdb) cannot be found.\n\nThe values for the new ENR table will be set to zero.", 
						"20 Cities ENR Database", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
				}

				if (use20CitiesValues && enrRecordsTest.Length > 0)
				{
					WAM.Data.ENR20Cities[] enrRecords = WAM.Data.ENR20CitiesCache.GetAllENRValues();
					WAM.Data.ENR20Cities enrRecord;


					for (int i = 0; i < enrRecords.Length; i++)
					{
						enrRecord = enrRecords[i];

						System.Data.DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["enr_year"] = enrRecord.Year;
						dataRow["enr_value"] = enrRecord.ENRValue;
						dataRow["CustomENRListID"] = newCustomENRID;
						dataSet.Tables[0].Rows.Add(dataRow);
					}
				}
				else
				{
					for (int i = 1900; i <= DateTime.Now.Year; i++)
					{
						System.Data.DataRow dataRow;
						dataRow = dataSet.Tables[0].NewRow();
						dataRow["enr_year"] = i;
						dataRow["enr_value"] = setENRValue;
						dataRow["CustomENRListID"] = newCustomENRID;
						dataSet.Tables[0].Rows.Add(dataRow);
					}
				}

				if (dataAccess.UpdateDatabase(dataSet, queryString))
					return newCustomENRID;

				return 0;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return 0;
			}
		}

		//mam 050806
		public static void ShowErrorMessage(string methodName, string msgText)
		{
			try
			{
				string msgDisplay = string.Format("Error in {0}: {1}", methodName, msgText);
				MessageBox.Show(msgDisplay, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//mam 03202012
		public static void ShowPhotoPathNotFoundMessage(string msgText)
		{
			try
			{
				MessageBox.Show(msgText, "Images Folder Cannot be Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		public static void ShowErrorMessage(Form messageBoxOwner, string methodName, string msgText)
		{
			try
			{
				string msgDisplay = string.Format("Error in {0}: {1}", methodName, msgText);
				MessageBox.Show(messageBoxOwner, msgDisplay, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch(Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		//mam 050806 - moved from MajorComponentControl
		public static void LoadLOS(ref ComboBox comboBoxToLoad)
		{
			int pos;
			LevelOfService[] losValues = (LevelOfService[])Enum.GetValues(typeof(LevelOfService));

			comboBoxToLoad.BeginUpdate();
			comboBoxToLoad.DisplayMember = "DisplayMember";
			comboBoxToLoad.Items.Clear();
			for (pos = 0; pos < losValues.Length; pos++)
			{
				//mam - include description with LOS number
				//original code:
				//comboBoxToLoad.Items.Add(new ListItem(
				//	EnumHandlers.GetLOSShort(losValues[pos]),
				//	losValues[pos]));
				comboBoxToLoad.Items.Add(new ListItem(
					EnumHandlers.GetLOSString(losValues[pos]),
					losValues[pos]));
				//</mam>
			}
			comboBoxToLoad.EndUpdate();
		}

		//mam 07072011
		public static CriticalityCollection Criticalities = new CriticalityCollection();

		//mam 07072011
		public static bool LoadCriticalities()
		{
			//get all of the criticalities from the database and populate the Criticalites collection
			//	(this is the entire, distinct set of Criticalities, and is not per Major Component or Pipe or Node)

			//MessageBox.Show("you are here 1");

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{

				//System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticality");
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticality", "@activeOnly", true);
				//MessageBox.Show(dataTable.Rows.Count.ToString());

				Criticalities.Clear();

				int counter = 0;
				int curId = 0;
				int critWeight = 0;
				string critName = "";
				Criticality curCrit = new Criticality();
				CriticalityFactor curCritFactor = new CriticalityFactor();
				//for (pos = 0; pos < dataTable.Rows.Count; pos++)
				foreach (System.Data.DataRow dataRow in dataTable.Rows)
				{
					if ((int)dataRow["CriticalityId"] != curId)
					{
						//next criticality

						curId = Convert.ToInt32(dataRow["CriticalityId"]);
						counter++;

						critWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
						critName = dataRow["Criticality"].ToString();
						curCrit = new Criticality(curId, counter, critWeight, critName);
						Criticalities.Add(curCrit);
					}

					//curCritFactor = new WAM.Data.Criticality.CriticalityFactor();
					curCritFactor = new CriticalityFactor();
					curCritFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
					curCritFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
					curCritFactor.FactorName = dataRow["CriticalityFactor"].ToString();
					curCritFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);
					curCritFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
					curCritFactor.UseAsDefaultScore = Convert.ToBoolean(dataRow["UseAsDefaultScore"]);
					//curCrit.AddCriticalityFactor(curCritFactor.FactorId, curCritFactor);
					curCrit.AddCriticalityFactor(curCritFactor);
				}
			}			
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message.ToString());
				return false;
			}
			finally
			{
				dataAccess = null;
			}			

			return true;
		}
		//</mam>

		//mam 07072011
		public static bool LoadCriticalityComboBoxes(ComboBox comboBoxToLoad1, ComboBox comboBoxToLoad2, ComboBox comboBoxToLoad3
			, ComboBox comboBoxToLoad4, ComboBox comboBoxToLoad5, ComboBox comboBoxToLoad6
			, Label labelToLoad1, Label labelToLoad2, Label labelToLoad3
			, Label labelToLoad4, Label labelToLoad5, Label labelToLoad6
			, Label labelCritWeight1, Label labelCritWeight2, Label labelCritWeight3
			, Label labelCritWeight4, Label labelCritWeight5, Label labelCritWeight6)
		{

			//comboBoxToLoad1.BeginUpdate();
			//comboBoxToLoad1.ValueMember = "ValueMember";
			comboBoxToLoad1.DisplayMember = "DisplayMember";
			comboBoxToLoad1.Items.Clear();

			comboBoxToLoad2.DisplayMember = "DisplayMember";
			comboBoxToLoad2.Items.Clear();

			comboBoxToLoad3.DisplayMember = "DisplayMember";
			comboBoxToLoad3.Items.Clear();

			comboBoxToLoad4.DisplayMember = "DisplayMember";
			comboBoxToLoad4.Items.Clear();

			comboBoxToLoad5.DisplayMember = "DisplayMember";
			comboBoxToLoad5.Items.Clear();

			comboBoxToLoad6.DisplayMember = "DisplayMember";
			comboBoxToLoad6.Items.Clear();

			int counter = 0;
			foreach (Criticality crit in Criticalities)
			{
				counter++;

				if (counter == 1)
				{
					labelToLoad1.Text = crit.CriticalityName;
					labelCritWeight1.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad1.Visible = true;
					labelCritWeight1.Visible = true;
					comboBoxToLoad1.Visible = true;
					//comboBoxToLoad1.Tag = crit.CriticalityId;
					comboBoxToLoad1.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						comboBoxToLoad1.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}

				if (counter == 2)
				{
					labelToLoad2.Text = crit.CriticalityName;
					labelCritWeight2.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad2.Visible = true;
					labelCritWeight2.Visible = true;
					comboBoxToLoad2.Visible = true;
					//comboBoxToLoad2.Tag = crit.CriticalityId;
					comboBoxToLoad2.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						//comboBoxToLoad2.Items.Add(new ListItem(factor.FactorName, factor));
						comboBoxToLoad2.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}

				if (counter == 3)
				{
					labelToLoad3.Text = crit.CriticalityName;
					labelCritWeight3.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad3.Visible = true;
					labelCritWeight3.Visible = true;
					comboBoxToLoad3.Visible = true;
					//comboBoxToLoad3.Tag = crit.CriticalityId;
					comboBoxToLoad3.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						//comboBoxToLoad3.Items.Add(new ListItem(factor.FactorName, factor));
						comboBoxToLoad3.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}

				if (counter == 4)
				{
					labelToLoad4.Text = crit.CriticalityName;
					labelCritWeight4.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad4.Visible = true;
					labelCritWeight4.Visible = true;
					comboBoxToLoad4.Visible = true;
					//comboBoxToLoad4.Tag = crit.CriticalityId;
					comboBoxToLoad4.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						//comboBoxToLoad4.Items.Add(new ListItem(factor.FactorName, factor));
						comboBoxToLoad4.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}

				if (counter == 5)
				{
					labelToLoad5.Text = crit.CriticalityName;
					labelCritWeight5.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad5.Visible = true;
					labelCritWeight5.Visible = true;
					comboBoxToLoad5.Visible = true;
					//comboBoxToLoad5.Tag = crit.CriticalityId;
					comboBoxToLoad5.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						//comboBoxToLoad5.Items.Add(new ListItem(factor.FactorName, factor));
						comboBoxToLoad5.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}

				if (counter == 6)
				{
					labelToLoad6.Text = crit.CriticalityName;
					labelCritWeight6.Text = crit.CriticalityWeight.ToString() + "%";
					labelToLoad6.Visible = true;
					labelCritWeight6.Visible = true;
					comboBoxToLoad6.Visible = true;
					//comboBoxToLoad6.Tag = crit.CriticalityId;
					comboBoxToLoad6.Tag = crit;

					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						//comboBoxToLoad6.Items.Add(new ListItem(factor.FactorName, factor));
						comboBoxToLoad6.Items.Add(new ListItem(factor.FactorName + "  (" + factor.Score.ToString() + ")", factor));
					}
				}
			}

			return true;
		}
		//</mam>

		//mam 07072011
		public static int DefaultCipPlanningId
		{
			get 
			{ 
				if (defaultCipPlanningId == 0)
				{
					defaultCipPlanningId = GetCipDefaultId();
				}

				return defaultCipPlanningId;
			}
			set { defaultCipPlanningId = value; }
		}

		//mam 07072011
		public static int ZeroRehabCostCipPlanningId
		{
			get 
			{ 
				if (zeroRehabCostCipPlanningId == 0)
				{
					GetCipDefaultId();
				}

				return zeroRehabCostCipPlanningId;
			}
			set { zeroRehabCostCipPlanningId = value; }
		}

		//mam 07072011
		public static int NonZeroRehabCostCipPlanningId
		{
			get 
			{ 
				if (nonZeroRehabCostCipPlanningId == 0)
				{
					GetCipNonZeroRehabCostId();
				}

				return nonZeroRehabCostCipPlanningId;
			}
			set { nonZeroRehabCostCipPlanningId = value; }
		}

		//mam 07072011
		public static int GetCipDefaultId()
		{
			ArrayList arrayListCip = GetCipObjects();
			int defaultId = 0;
			for (int i = 0; i < arrayListCip.Count; i++)
			{
				if (((Cip)arrayListCip[i]).UseAsDefault)
				{
					defaultId = ((Cip)arrayListCip[i]).CipPlanningId;
				}

				if (((Cip)arrayListCip[i]).ZeroRehabCost)
				{
					zeroRehabCostCipPlanningId = ((Cip)arrayListCip[i]).CipPlanningId;
				}
			}

			if (defaultId == 0)
			{
				defaultId = ((Cip)arrayListCip[0]).CipPlanningId;
			}

			return defaultId;
		}

		//mam 07072011
		public static string GetCipText(int cipId)
		{
			ArrayList arrayListCip = GetCipObjects();
			for (int i = 0; i < arrayListCip.Count; i++)
			{
				if (((Cip)arrayListCip[i]).CipPlanningId == cipId)
				{
					return ((Cip)arrayListCip[i]).CipPlanningText;
				}
			}

			return "";
		}

		//mam 07072011
		public static int GetCipZeroRehabCostId()
		{
			ArrayList arrayListCip = GetCipObjects();
			int defaultId = 0;
			for (int i = 0; i < arrayListCip.Count; i++)
			{
				if (((Cip)arrayListCip[i]).UseAsDefault)
				{
					defaultId = ((Cip)arrayListCip[i]).CipPlanningId;
				}

				if (((Cip)arrayListCip[i]).ZeroRehabCost)
				{
					zeroRehabCostCipPlanningId = ((Cip)arrayListCip[i]).CipPlanningId;
				}
			}

			if (defaultId == 0)
			{
				defaultId = ((Cip)arrayListCip[0]).CipPlanningId;
			}

			return defaultId;
		}

		//mam 07072011
		public static int GetCipNonZeroRehabCostId()
		{
			ArrayList arrayListCip = GetCipObjects();
			for (int i = 0; i < arrayListCip.Count; i++)
			{
				if (!((Cip)arrayListCip[i]).ZeroRehabCost)
				{
					nonZeroRehabCostCipPlanningId = ((Cip)arrayListCip[i]).CipPlanningId;
					break;
				}
			}

			return nonZeroRehabCostCipPlanningId;
		}

		//mam 07072011
		public static ArrayList GetCipObjects()
		{
			if (ArrayListCipObjects.Count > 0)
			{
				return ArrayListCipObjects;
			}

			ArrayListCipObjects.Clear();
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCipPlanning");

				foreach (System.Data.DataRow dataRow in dataTable.Rows)
				{
					Cip cip = new Cip();

					cip.CipPlanningId = Convert.ToInt32(dataRow["CipPlanningId"]);
					cip.CipPlanningText = dataRow["CipPlanning"].ToString();
					cip.UseAsDefault = Convert.ToBoolean(dataRow["UseAsDefault"]);
					cip.ZeroRehabCost = Convert.ToBoolean(dataRow["ZeroRehabCost"]);

					ArrayListCipObjects.Add(cip);
				}
			}			
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}

			return ArrayListCipObjects;
		}

		//mam 07072011
		public static bool LoadCipPlanningComboBox(ComboBox comboBoxCipPlanning)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCipPlanning");

				comboBoxCipPlanning.DisplayMember = "DisplayMember";
				comboBoxCipPlanning.Items.Clear();
				comboBoxCipPlanning.BeginUpdate();

				foreach (System.Data.DataRow dataRow in dataTable.Rows)
				{
					Cip cip = new Cip();

					cip.CipPlanningId = Convert.ToInt32(dataRow["CipPlanningId"]);
					cip.CipPlanningText = dataRow["CipPlanning"].ToString();

					comboBoxCipPlanning.Items.Add(new ListItem(cip.CipPlanningText, cip));
				}

				comboBoxCipPlanning.EndUpdate();
			}			
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}			

			return true;
		}
		//</mam>

		//mam 07072011
		public static System.Data.DataTable GetAssetClassValues(int excludeComponentId)
		{
			DataAccess dataAccess = new DataAccess();
			System.Data.DataTable dataTable = new System.Data.DataTable();

			try
			{
				dataTable = dataAccess.GetDisconnectedDataTableSP("GetAssetClassValues", "@excludeComponentId", excludeComponentId);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}

			return dataTable;
		}

		//mam 07072011
		//public static DataTable GetRehabValuesForResurrection(int componentId)
		//{
		//}

		//mam 07072011
		//public static SortedList GetRehabCostByComponent(int componentId)
		public static DataTable GetRehabCostByComponent(int componentId)
		{
			DataAccess dataAccess = new DataAccess();
			System.Data.DataTable dataTable = new System.Data.DataTable();
			SortedList sortedList = new SortedList();

			try
			{
				dataTable = dataAccess.GetDisconnectedDataTableSP("GetRehabCostByComponent", "@componentId", componentId);
				//foreach (System.Data.DataRow dataRow in dataTable.Rows)
				//{
				//	sortedList.Add(Convert.ToInt32(dataRow["disc_id"]), Convert.ToDecimal(dataRow["RehabCost"]));
				//}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}

			return dataTable;
			//return sortedList;
		}

		//mam 07072011
		public static Common.MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesIntoCollection(System.Data.DataTable dataTable)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			//componentSelectedCritFactorCollection.Clear();

			//int counter = 0;
			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				//counter++;

				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				//curCrit.CriticalityNumber = counter;
				curCrit.CriticalityNumber = ((Criticality)Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				//critColl.Add(curCrit);
				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}
		//</mam>

		//mam 03202012 - this new method is used during the startup process
		//	it is the same as the method above with the same name, but takes rows instead of a table
		//@@@@
		public static Common.MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesIntoCollection(System.Data.DataRow[] rows)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			//componentSelectedCritFactorCollection.Clear();

			//int counter = 0;
			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in rows)
			{
				//counter++;

				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				//curCrit.CriticalityNumber = counter;
				curCrit.CriticalityNumber = ((Criticality)Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				//critColl.Add(curCrit);
				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}

		//mam 07072011
		//load the default criticalities into the collection
		public static Common.MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesDefaultIntoCollection()
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			//componentSelectedCritFactorCollection.Clear();

			//int counter = 0;
			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCritsSource = new ArrayList();
			ArrayList arrayListCrits = new ArrayList();

			//get the default criticality factors from the Criticalities collection
			foreach (Criticality crit in Criticalities)
			{
				arrayListCritsSource.Add(crit);
			}
			arrayListCritsSource.Sort();

			for (int i = 0; i < arrayListCritsSource.Count; i++)
			{
				Criticality crit = (Criticality)arrayListCritsSource[i];

				//counter++;

				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = crit.CriticalityId;

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				//curCrit.CriticalityNumber = counter;
				//curCrit.CriticalityNumber = ((Criticality)Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;
				curCrit.CriticalityNumber = crit.CriticalityNumber;

				curCrit.CriticalityWeight = crit.CriticalityWeight;
				curCrit.CriticalityName = crit.CriticalityName;
				//curCrit.CriticalityOrderBy = crit.CriticalityOrderBy;
				
				//mam 11142011 - check this! - OK
				foreach (CriticalityFactor factor in crit.CriticalityFactors)
				{
					if (factor.UseAsDefaultScore == true)
					{
						critFactor = new CriticalityFactor();
						critFactor.FactorId = factor.FactorId;
						critFactor.ScoreId = factor.ScoreId;
						critFactor.FactorName = factor.FactorName;
						critFactor.Score = factor.Score;
						critFactor.FactorOrderBy = factor.FactorOrderBy;
						critFactor.UseAsDefaultScore = factor.UseAsDefaultScore;

						break;
					}
				}

				//critFactor = crit.CriticalityFactors.GetDefaultFactor();
				curCrit.CritFactor = critFactor;

				critColl.Add(curCrit);
				//arrayListCrits.Add(curCrit);
			}

//			arrayListCrits.Sort();
//
//			for (int i = 0; i < arrayListCrits.Count; i++)
//			{
//				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
//			}

			return critColl;
		}
		//</mam>

		//mam 07072011
		//load the default criticalities into an array list
		public static ArrayList LoadCriticalitiesIntoArrayList()
		{
			Criticality curCrit = new Criticality();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCritsSource = new ArrayList();
			ArrayList arrayListCrits = new ArrayList();

			//get the criticality factors from the Criticalities collection
			foreach (Criticality crit in Criticalities)
			{
				arrayListCritsSource.Add(crit);
			}
			arrayListCritsSource.Sort();

			for (int i = 0; i < arrayListCritsSource.Count; i++)
			{
				Criticality crit = (Criticality)arrayListCritsSource[i];

				curCrit = new Criticality();
				curCrit.CriticalityId = crit.CriticalityId;
				curCrit.CriticalityNumber = crit.CriticalityNumber;
				curCrit.CriticalityWeight = crit.CriticalityWeight;
				curCrit.CriticalityName = crit.CriticalityName;
				//curCrit.CriticalityOrderBy = crit.CriticalityOrderBy;
				
				foreach (CriticalityFactor factor in crit.CriticalityFactors)
				{
					critFactor = new CriticalityFactor();

					critFactor.FactorId = factor.FactorId;
					critFactor.ScoreId = factor.ScoreId;
					critFactor.FactorName = factor.FactorName;
					critFactor.Score = factor.Score;
					critFactor.FactorOrderBy = factor.FactorOrderBy;
					critFactor.UseAsDefaultScore = factor.UseAsDefaultScore;

					curCrit.CriticalityFactors.Add(critFactor);
				}

				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();
			return arrayListCrits;
		}
		//</mam>

		public static string CreateCriticalityXmlString(MajorComponentSelectedCriticalityFactorsCollection componentSelectedCritFactorCollection)
		{
			System.Text.StringBuilder xmlString = new System.Text.StringBuilder();
			xmlString.Append("<Criticalities>");
			foreach (MajorComponentSelectedCriticalityFactors critFactor in componentSelectedCritFactorCollection)
			{
				xmlString.AppendFormat("<Criticality CriticalityId=\"{0}\" CriticalityScoreId=\"{1}\" />", critFactor.CriticalityId, critFactor.CritFactor.ScoreId);
			}
			xmlString.Append("</Criticalities>");

			return xmlString.ToString();
		}

		//mam 07072011
		public static ArrayList LoadImportCritArray()
		{
			ArrayList arrayListCriticalities = new ArrayList();
			ArrayList arrayListCriticalitiesImport = new ArrayList();
			CriticalityForImport critForImport = new CriticalityForImport();

			ListDictionary listDictionaryCriticality1 = new ListDictionary();
			ListDictionary listDictionaryCriticality2 = new ListDictionary();
			ListDictionary listDictionaryCriticality3 = new ListDictionary();
			ListDictionary listDictionaryCriticality4 = new ListDictionary();
			ListDictionary listDictionaryCriticality5 = new ListDictionary();
			ListDictionary listDictionaryCriticality6 = new ListDictionary();

			foreach (Criticality crit in Criticalities)
			{
				arrayListCriticalities.Add(crit.Copy());
			}

			//sort by CriticalityNumber, which is a counter, not an ID)
			arrayListCriticalities.Sort();

			int critNum = 0;
			for (int i = 0; i < arrayListCriticalities.Count; i++)
			{
				critNum = i + 1;
				Criticality crit = (Criticality)arrayListCriticalities[i];
				int defaultCritScore = 0;

				if (i == 0)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality1.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality1);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality1.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}
					
					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit1"] = crit.CriticalityName;
				}
				else if (i == 1)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality2.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality2);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality2.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}

					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit2"] = crit.CriticalityName;
				}
				else if (i == 2)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality3.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality3);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality3.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}

					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit3"] = crit.CriticalityName;
				}
				else if (i == 3)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality4.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality4);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality4.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}

					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit4"] = crit.CriticalityName;
				}
				else if (i == 4)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality5.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality5);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality5.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}

					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit5"] = crit.CriticalityName;
				}
				else if (i == 5)
				{
					defaultCritScore = -1;
					foreach (CriticalityFactor factor in crit.CriticalityFactors)
					{
						listDictionaryCriticality6.Add(factor.Score, factor.FactorName);
						if (factor.UseAsDefaultScore)
						{
							defaultCritScore = factor.Score;
						}
					}
					critForImport = new CriticalityForImport(crit.CriticalityId, critNum, crit.CriticalityName, listDictionaryCriticality6);

					if (defaultCritScore == -1)
					{
						IDictionaryEnumerator idEnumerator = listDictionaryCriticality6.GetEnumerator();
						idEnumerator.MoveNext();
						defaultCritScore = Convert.ToInt32(idEnumerator.Key);
					}

					critForImport.DefaultCriticalityScore = defaultCritScore;
					arrayListCriticalitiesImport.Add(critForImport);
					//c1FlexGridComponent[1, "Crit6"] = crit.CriticalityName;
				}
			}

			return arrayListCriticalitiesImport;
		}

		//mam 07072011 - no longer using four fixed crits
		//mam 050806 - moved from MajorComponentControl
//		public static void LoadCriticalityBoxPublicHealth(ref ComboBox comboBoxToLoad)
//		{
//			int pos;
//
//			// Public Health and Safety
//			CriticalityPublicHealth[] critHealthValues = 
//				(CriticalityPublicHealth[])Enum.GetValues(
//				typeof(CriticalityPublicHealth));
//			comboBoxToLoad.BeginUpdate();
//			comboBoxToLoad.DisplayMember = "DisplayMember";
//			comboBoxToLoad.Items.Clear();
//			for (pos = 0; pos < critHealthValues.Length; pos++)
//			{
//				//mam - include description with LOS number
//				//original code:
//				//comboBoxCritHealth.Items.Add(new ListItem(
//				//	EnumHandlers.GetCritPublicHealthString(
//				//	critHealthValues[pos]),
//				//	critHealthValues[pos]));
//				//new code:
//				comboBoxToLoad.Items.Add(new ListItem(
//					EnumHandlers.GetCritPublicHealthStringAssocValue(
//					critHealthValues[pos]),
//					critHealthValues[pos]));
//				//</mam>
//			}
//			comboBoxToLoad.EndUpdate();
//		}

		//mam 07072011 - no longer using four fixed crits
		//mam 050806 - moved from MajorComponentControl
//		public static void LoadCriticalityBoxEnvironmental(ref ComboBox comboBoxToLoad)
//		{
//			int pos;
//
//			//Environmental
//			CriticalityEnvironmental[] critEnvValues = 
//				(CriticalityEnvironmental[])Enum.GetValues(
//				typeof(CriticalityEnvironmental));
//			comboBoxToLoad.BeginUpdate();
//			comboBoxToLoad.DisplayMember = "DisplayMember";
//			comboBoxToLoad.Items.Clear();
//			for (pos = 0; pos < critEnvValues.Length; pos++)
//			{
//				comboBoxToLoad.Items.Add(new ListItem(
//					EnumHandlers.GetCritEnvironmentalStringAssocValue(
//					critEnvValues[pos]),
//					critEnvValues[pos]));
//			}
//			comboBoxToLoad.EndUpdate();
//		}

		//mam 07072011 - no longer using four fixed crits
		//mam 050806 - moved from MajorComponentControl
//		public static void LoadCriticalityBoxRepair(ref ComboBox comboBoxToLoad)
//		{
//			int pos;
//
//			// Cost of Repair
//			CriticalityRepairCost[] critRepairValues = 
//				(CriticalityRepairCost[])Enum.GetValues(
//				typeof(CriticalityRepairCost));
//			comboBoxToLoad.BeginUpdate();
//			comboBoxToLoad.DisplayMember = "DisplayMember";
//			comboBoxToLoad.Items.Clear();
//			for (pos = 0; pos < critRepairValues.Length; pos++)
//			{
//				comboBoxToLoad.Items.Add(new ListItem(
//					EnumHandlers.GetCritRepairCostStringAssocValue(
//					critRepairValues[pos]),
//					critRepairValues[pos]));
//			}
//			comboBoxToLoad.EndUpdate();
//		}

		//mam 07072011 - no longer using four fixed crits
		//mam 050806 - moved from MajorComponentControl
//		public static void LoadCriticalityBoxCustomerEffect(ref ComboBox comboBoxToLoad)
//		{
//			int pos;
//
//			// Customer Effect
//			CriticalityCustomerEffect[] critCustEffectValues = 
//				(CriticalityCustomerEffect[])Enum.GetValues(
//				typeof(CriticalityCustomerEffect));
//			comboBoxToLoad.BeginUpdate();
//			comboBoxToLoad.DisplayMember = "DisplayMember";
//			comboBoxToLoad.Items.Clear();
//			for (pos = 0; pos < critCustEffectValues.Length; pos++)
//			{
//				comboBoxToLoad.Items.Add(new ListItem(
//					EnumHandlers.GetCritCustomerEffectStringAssocValue(
//					critCustEffectValues[pos]),
//					critCustEffectValues[pos]));
//			}
//			comboBoxToLoad.EndUpdate();
//		}

		//mam 112806
		public static decimal GetRedundantPercentage(int curRedundantAssetCount)
		{
			decimal redundantPercent = 1.0m;

			if (curRedundantAssetCount > 1)
			{
				if (curRedundantAssetCount == 2)
				{
					redundantPercent = 0.95m;
				}
				else if (curRedundantAssetCount == 3)
				{
					redundantPercent = 0.92m;
				}
				else if (curRedundantAssetCount == 4)
				{
					redundantPercent = 0.88m;
				}
				else if (curRedundantAssetCount == 5)
				{
					redundantPercent = 0.85m;
				}
				else if (curRedundantAssetCount < 11)
				{
					redundantPercent = 0.80m;
				}
				else if (curRedundantAssetCount < 16)
				{
					redundantPercent = 0.70m;
				}
				else if (curRedundantAssetCount < 21)
				{
					redundantPercent = 0.60m;
				}
				else if (curRedundantAssetCount > 20)
				{
					redundantPercent = 0.50m;
				}
			}

			return redundantPercent;
		}

		public static C1.Win.C1FlexGrid.C1FlexGrid GetErrorGrid()
		{
			//C1.Win.C1FlexGrid.C1FlexGrid grid
			C1.Win.C1FlexGrid.C1FlexGrid gridErrors = new C1.Win.C1FlexGrid.C1FlexGrid();
			gridErrors.Cols.Count = 2;
			gridErrors.Cols.Fixed = 1;
			gridErrors.Rows.Count = 1;
			gridErrors.Rows.Fixed = 1;
			//gridReasons.Cols[1].Name = "LineNumber";
			gridErrors.Cols[1].Name = "Error";
			//gridReasons.Cols[3].Name = "IDNumber";

			return gridErrors;

		}

		public static bool PopulateErrorGridRow(ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors, string errorText)
		{
			C1.Win.C1FlexGrid.Row newRow = gridErrors.Rows.Add();
			//gridReasons.SetData(newRow.Index, "LineNumber", lineNumber.ToString());
			gridErrors.SetData(newRow.Index, "Error", errorText);
			//gridReasons.SetData(newRow.Index, "IDNumber", idNumber.ToString());

			return true;
		}

		//mam 01042012
		public static string ColorConvertToRgb(System.Drawing.Color color)
		{
			System.ComponentModel.TypeConverter converter = System.ComponentModel.TypeDescriptor.GetConverter(color);
			//string colorString = converter.ConvertToString(colorDialog.Color);
			//string colorHex = colorDialog.Color.R.ToString("X2") + colorDialog.Color.G.ToString("X2") + colorDialog.Color.B.ToString("X2");
			return color.R.ToString() + "," + color.G.ToString() + "," + color.B.ToString();
		}

		//mam 01042012
		public static string ColorConvertToHex(System.Drawing.Color color)
		{
			//Color red = ColorTranslator.FromHtml("#FF0000");
			//Color red = System.Drawing.Color.Red;
			//string redHex = ColorTranslator.ToHtml(red);

			System.ComponentModel.TypeConverter converter = System.ComponentModel.TypeDescriptor.GetConverter(color);
			return color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
		}

		//mam 03202012 - check whether user has write permission
		public static bool GetUserWritePermission()
		{
			DataAccess dataAccess = new WAM.Common.DataAccess();
			int hasPerm = 0;

			try
			{
				DataTable dataTable = dataAccess.GetDisconnectedDataTable("SELECT isnull(has_perms_by_name('Facilities', 'OBJECT', 'INSERT'), 0)");
				if (dataTable != null && dataTable.Rows.Count > 0)
				{
					if (dataTable.Rows[0][0] != DBNull.Value)
					{
						hasPerm = Convert.ToInt32(dataTable.Rows[0][0]);
					}
				}
				//MessageBox.Show("row count = " + dataTableTest.Rows.Count.ToString() + "; data value = " + dataTableTest.Rows[0][0].ToString());
			}
			catch
			{
				//it doesn't matter why there was an error
			}
			finally
			{
				if (dataAccess != null)
				{
					dataAccess.Dispose();
					dataAccess = null;
				}
			}

			return hasPerm == 1;
		}
	}
}
