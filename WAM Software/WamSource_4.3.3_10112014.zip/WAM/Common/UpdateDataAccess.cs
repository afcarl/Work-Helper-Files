//mam 102309 - new class

using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
//using Drive.Configuration;
using Drive.Data.OleDb;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for UpdateDataAccess.
	/// </summary>
	public class UpdateDataAccess
	{
		#region /***** Member Variables *****/

		//private string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
		//private string connectionString = CurrentSource.ConnectionString;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		public UpdateDataAccess()
		{
		}

		#endregion /***** Construction *****/

		#region /***** Database Access *****/

//		private static Jet40DataSource CurrentSource
//		{
//			get 
//			{
//				Jet40DataSource m_dataSource = null;
//
//				if (m_dataSource == null)
//				{
//					//mam - add error handling because an error occurs if WAM.xml exists, but is empty
//					//	(although this shouldn't happen)
//					string lastSource = "";
//					try
//					{
//						lastSource = Drive.Configuration.AppSettings.
//							Settings.GetSetting("DBConnection", "LastSource");
//					}
//					catch
//					{
//						System.Diagnostics.Trace.WriteLine(String.Format("WAMSource.Jet40DatSource error"));
//						System.Diagnostics.Debug.Assert(false, "WAMSource.Jet40DatSource error");
//					}
//
//					//mam 050806 - the source string must contain the entire folder path or an error occurs when 
//					//	saving raw graphing data to the hard drive in a folder different from the WAM folder
//					//mam 112806 - modified by adding lastSource.Length > 0 to allow WAM to attempt to create the WAM.mdb file when
//					//	the app first opens and there is no WAM.xml file and no WAM.mdb file
//					if (lastSource.Length > 0 && lastSource.IndexOf(@"\") < 0 && lastSource.IndexOf(@"/") < 0)
//					{
//						//get the application folder
//						string appPath = Application.StartupPath;
//
//						if (!appPath.EndsWith(@"\") && !appPath.EndsWith(@"/"))
//						{
//							if (appPath.IndexOf(@"\") > -1)
//							{
//								appPath += @"\";
//							}
//							else
//							{
//								appPath += @"/";
//							}
//						}
//
//						lastSource = appPath + lastSource;
//					}
//
//					if (!System.IO.File.Exists(lastSource) || lastSource == null || lastSource.Length == 0)
//					{
//						//mam - show the user a warning message when the database cannot be found
//						if (lastSource.Length > 0)
//						{
//							System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
//							builder.Append("WAM cannot find the database\r\n\r\n");
//							builder.AppendFormat(@"'{0}'", lastSource.ToString());
//							builder.Append("\r\n\r\nWAM will attempt to open a default database.");
//
//							//mam 050806 - the message text was set, but no message was shown to the user
//							MessageBox.Show(builder.ToString(), "WAM Cannot Locate Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//						}
//						//</mam>
//
//						// Default last source to be the current folder, 
//						// WAM.MDB
//						System.Reflection.Assembly assembly = System.Reflection.Assembly.GetEntryAssembly();
//
//						lastSource = string.Format(@"{0}\WAM.mdb", Drive.IO.Directory.GetFilePath(assembly.Location));
//
//						//mam - save lastSource
//						try
//						{
//							Drive.Configuration.AppSettings.
//								Settings.SetSetting("DBConnection", "LastSource", lastSource);
//						}
//						catch
//						{
//							System.Diagnostics.Trace.WriteLine(String.Format("WAMSource.Jet40DatSource error"));
//							System.Diagnostics.Debug.Assert(false, "WAMSource.Jet40DatSource error");
//						}
//						//</mam>
//
//						//mam - make sure WAM.mdb exists - create it, if necessary
//						MainForm.CreateWAMDatabaseFile();
//						//</mam>
//					}
//
//					m_dataSource = new Jet40DataSource(lastSource);
//
//					//mam - Jet40DataSource apparently does not allow for a password, so add one here, if necessary
//					string connectionString = m_dataSource.ConnectionString;
//					connectionString = CheckConnectionString("", connectionString);
//					//if (connectionString.ToUpper().IndexOf("PASSWORD") > -1)
//					if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
//					{
//						//the database is password protected
//						m_dataSource.Provider = m_dataSource.Provider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
//					}
//					//</mam>
//				}
//				return m_dataSource;
//			}
//			set
//			{
//				Drive.Configuration.AppSettings.Settings.SetSetting("DBConnection", "LastSource", value.DataPath);
//
//				m_dataSource = value;
//
//				//mam - Jet40DataSource apparently does not allow for a password, so add one here, if necessary
//				string connectionString = m_dataSource.ConnectionString;
//				connectionString = CheckConnectionString("", connectionString);
//				if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
//				{
//					//the database is password protected
//					m_dataSource.Provider = m_dataSource.Provider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
//				}
//				//</mam>
//			}
//		}


//		private static string CheckConnectionString(string connStringPwd, string connString)
//		{
//			//The databases (20CitiesENR.mdb, OriginalData.mdb, FreshWam.mdb) are now password protected.
//			//	However, existing users at Carollo have databases that are not password protected.
//			//	Therefore, test the connection to see if it works with the password or without it, and
//			//	pass back the correct connection string.
//
//			string connectionString = connString;
//
//			if (connStringPwd == "" && connString == "")
//				return "";
//
//			if (connStringPwd == "")
//			{
//				if (connString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
//				{
//					//there is already a password in the connection string
//				}
//				else
//				{
//					//insert a password into the connection string
//					int pos = -1;
//					pos = connString.ToUpper().IndexOf("DATA SOURCE");
//					if (pos > -1)
//					{
//						connStringPwd = connString;
//						connStringPwd = connStringPwd.Insert(pos, "Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword + ";");
//					}
//				}
//			}
//
//			try
//			{
//				using (System.Data.OleDb.OleDbConnection sqlConnection = new System.Data.OleDb.OleDbConnection(connStringPwd))
//				{
//					sqlConnection.Open();
//					connectionString = connStringPwd;
//					if (sqlConnection.State == System.Data.ConnectionState.Open)
//						sqlConnection.Close();
//				}
//			}
//			catch(Exception ex)
//			{
//				//the database won't open with the password, so pass back the connection string without the password
//				connectionString = connString;
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//			}
//
//			return connectionString;
//		}

//		public OleDbCommand GetCommandObject()
//		{
//			OleDbConnection conn = new OleDbConnection(@connectionString);
//
//			try
//			{
//				conn.Open();
//				OleDbCommand cmd = conn.CreateCommand();
//
//				return cmd;
//			}
//			catch
//			{
//				return null;
//			}
//		}

		public OleDbCommand GetCommandObject(string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);
			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				return cmd;
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return null;
			}
		}

//		public bool ExecuteCommand(string ExecuteStatement)
//		{
//			OleDbConnection conn = new OleDbConnection(@connectionString);
//
//			try
//			{
//				conn.Open();
//				OleDbCommand cmd = conn.CreateCommand();
//				cmd.CommandText = @ExecuteStatement;
//				cmd.ExecuteNonQuery();
//
//				return true;
//			}
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//				return false;
//			}
//			finally
//			{
//				if (conn!= null)
//				{
//					if (conn.State == ConnectionState.Open)
//						conn.Close();
//				}
//			}
//		}

		public bool ExecuteCommand(string ExecuteStatement, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(@useConnectionString);

			try
			{
				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();

				return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				return false;
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

//		public int ExecuteCommandReturnAutoID(string ExecuteStatement)
//		{
//			OleDbConnection conn = new OleDbConnection(@connectionString);
//
//			try
//			{
//				int returnID = 0;
//
//				conn.Open();
//				OleDbCommand cmd = conn.CreateCommand();
//				cmd.CommandText = @ExecuteStatement;
//				cmd.ExecuteNonQuery();
//				cmd.CommandText = "SELECT @@Identity";
//				returnID = (int)cmd.ExecuteScalar();
//
//				return returnID;
//			}
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//			}
//			finally
//			{
//				if (conn!= null)
//				{
//					if (conn.State == ConnectionState.Open)
//						conn.Close();
//				}
//			}
//			return 0;
//		}

		public int ExecuteCommandReturnAutoID(string ExecuteStatement, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);

			try
			{
				int returnID = 0;

				conn.Open();
				OleDbCommand cmd = conn.CreateCommand();
				cmd.CommandText = @ExecuteStatement;
				cmd.ExecuteNonQuery();
				cmd.CommandText = "SELECT @@Identity";
				returnID = (int)cmd.ExecuteScalar();

				return returnID;
			}
			catch
			{
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return 0;
		}

//		public System.Data.DataTable GetDisconnectedDataTable(string QueryString)
//		{
//			System.Data.DataTable dataTable = new System.Data.DataTable();
//			OleDbConnection conn = null;
//
//			try
//			{
//				conn = new OleDbConnection(@connectionString);
//				OleDbDataAdapter adapter = new OleDbDataAdapter();
//				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
//				adapter.Fill(dataTable);
//
//				return dataTable;
//			}
//
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//				return null;
//			}
//
//			finally
//			{
//				if (conn!= null)
//				{
//					if (conn.State == ConnectionState.Open)
//						conn.Close();
//				}
//			}
//		}

		public System.Data.DataTable GetDisconnectedDataTable(string QueryString, string useConnectionString)
		{
			System.Data.DataTable dataTable = new System.Data.DataTable();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(@useConnectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				adapter.Fill(dataTable);
				
				return dataTable;
			}

			catch
			{
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

//		public System.Data.DataSet GetDisconnectedDataset(string QueryString)
//		{
//			System.Data.DataSet dataSet = new System.Data.DataSet();
//			OleDbConnection conn = null;
//
//			try
//			{
//				conn = new OleDbConnection(@connectionString);
//				OleDbDataAdapter adapter = new OleDbDataAdapter();
//				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
//				adapter.Fill(dataSet);
//				
//				return dataSet;
//			}
//
//			catch(Exception ex)
//			{
//				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
//				return null;
//			}
//
//			finally
//			{
//				if (conn!= null)
//				{
//					if (conn.State == ConnectionState.Open)
//						conn.Close();
//				}
//			}
//		}

		public System.Data.DataSet GetDisconnectedDataset(string QueryString, string useConnectionString)
		{
			System.Data.DataSet dataSet = new System.Data.DataSet();
			OleDbConnection conn = null;

			try
			{
				conn = new OleDbConnection(useConnectionString);
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.SelectCommand = new OleDbCommand(@QueryString, conn);
				adapter.Fill(dataSet);
				
				return dataSet;
			}

			catch
			{
				return null;
			}

			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
		}

//		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString)
//		{
//			OleDbConnection conn = new OleDbConnection(@connectionString);
//			OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
//			dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
//			OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);
//
//			try
//			{
//				conn.Open();
//				dataAdapter.Update(dataSet);
//				return true;
//			}
//			catch
//			{
//			}
//			finally
//			{
//				if (conn!= null)
//				{
//					if (conn.State == ConnectionState.Open)
//						conn.Close();
//				}
//			}
//			return false;
//		}

		public bool UpdateDatabase(System.Data.DataSet dataSet, string QueryString, string useConnectionString)
		{
			OleDbConnection conn = new OleDbConnection(useConnectionString);
			OleDbDataAdapter dataAdapter = new OleDbDataAdapter();
			dataAdapter.SelectCommand = new OleDbCommand(@QueryString, conn);
			OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder(dataAdapter);

			try
			{
				conn.Open();
				dataAdapter.Update(dataSet);
				return true;
			}
			catch
			{
			}
			finally
			{
				if (conn!= null)
				{
					if (conn.State == ConnectionState.Open)
						conn.Close();
				}
			}
			return false;
		}

		#endregion /***** Database Access *****/

		#region /***** Get Database Schema Info *****/

//		public DataTable GetFields(string specificTableName)
//		{
//			//string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
//			string connectionString = CurrentSource.ConnectionString;
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
//			DataTable schemaTable;
//
//			try
//			{
//				sqlConnection.Open();
//
//				if (specificTableName == "")
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
//						new object[] {null, null, null, null});
//				}
//				else
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
//						new object[] {null, null, specificTableName, null});
//				}
//
//				if (schemaTable.Rows.Count == 0)
//					return null;
//				else
//					return schemaTable;
//			}
//			catch (OleDbException ex)
//			{
//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
//				return null;
//			}
//			finally
//			{
//				if (sqlConnection!= null)
//				{
//					if (sqlConnection.State == ConnectionState.Open)
//						sqlConnection.Close();
//				}
//
//				sqlConnection.Dispose();
//			}
//		}

		public DataTable GetFields(string specificTableName, string databaseName)
		{
			//mam 102309
			//string connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseName);
			string connectionString = WAM.Data.WamSourceOleDb.SelectedDBConnectionString(databaseName);

			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			DataTable schemaTable;

			try
			{
				sqlConnection.Open();

				if (specificTableName == "")
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
						new object[] {null, null, null, null});
				}
				else
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns,
						new object[] {null, null, specificTableName, null});
				}

				if (schemaTable.Rows.Count == 0)
					return null;
				else
					return schemaTable;
			}

			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
				return null;
			}
			finally
			{
				if (sqlConnection!= null)
				{
					if (sqlConnection.State == ConnectionState.Open)
						sqlConnection.Close();
				}

				sqlConnection.Dispose();
			}
		}

//		public DataTable GetTables(string specificTableName)
//		{
//			//string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
//			string connectionString = CurrentSource.ConnectionString;
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
//			DataTable schemaTable;
//
//			try
//			{
//				sqlConnection.Open();
//
//				if (specificTableName == "")
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
//						new object[] {null, null, null, "TABLE"});
//				}
//				else
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
//						new object[] {null, null, specificTableName, "TABLE"});
//				}
//
//				if (schemaTable.Rows.Count == 0)
//					return null;
//				else
//					return schemaTable;
//			}
//
//			catch (OleDbException ex)
//			{
//				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
//				return null;
//			}
//			finally
//			{
//				if (sqlConnection!= null)
//				{
//					if (sqlConnection.State == ConnectionState.Open)
//						sqlConnection.Close();
//				}
//
//				sqlConnection.Dispose();
//			}
//		}

		public DataTable GetTables(string specificTableName, string databaseName)
		{
			//mam 102309
			//string connectionString = WAM.Data.WAMSource.SelectedDBConnectionString(databaseName);
			string connectionString = WAM.Data.WamSourceOleDb.SelectedDBConnectionString(databaseName);

			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			DataTable schemaTable;

			try
			{
				sqlConnection.Open();

				if (specificTableName == "")
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, null, "TABLE"});
				}
				else
				{
					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
						new object[] {null, null, specificTableName, "TABLE"});
				}

				if (schemaTable.Rows.Count == 0)
					return null;
				else
					return schemaTable;
			}

			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DataAccess.GetTables Error: {0}\n", ex.Message));
				return null;
			}
			finally
			{
				if (sqlConnection!= null)
				{
					if (sqlConnection.State == ConnectionState.Open)
						sqlConnection.Close();
				}

				sqlConnection.Dispose();
			}
		}

//		public DataTable GetPrimaryKeys(string specificTableName)
//		{
//			//string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
//			string connectionString = CurrentSource.ConnectionString;
//			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
//			DataTable schemaTable;
//
//			try
//			{
//				sqlConnection.Open();
//
//				if (specificTableName == "")
//				{
//					return null;
//				}
//				else
//				{
//					schemaTable = sqlConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, 
//						new object[] {null, null, specificTableName});
//				}
//
//				if (schemaTable.Rows.Count == 0)
//				{
//					return null;
//				}
//				else
//				{
//					return schemaTable;
//				}
//			}
//			catch (OleDbException ex)
//			{
//				System.Diagnostics.Trace.WriteLine(
//					String.Format("DataAccess.GetFields Error: {0}\n", ex.Message));
//				return null;
//			}
//			finally
//			{
//				if (sqlConnection!= null)
//				{
//					if (sqlConnection.State == ConnectionState.Open)
//						sqlConnection.Close();
//				}
//
//				sqlConnection.Dispose();
//			}
//		}

		#endregion /***** Get Database Schema Info *****/

	}
}
