using System;
using System.Collections;
using System.Collections.Specialized;

//mam 07072011
namespace WAM.Common
{
	public class Criticality : IComparable
	{
		private int criticalityId;
		private int criticalityNumber;
		private int criticalityWeight;
		private string criticalityName;
		private CriticalityFactorCollection criticalityFactors = new CriticalityFactorCollection();

		public Criticality()
		{
		}

		public Criticality(int critId, int critNumber, int critWeight, string critName)
		{
			criticalityId = critId;
			criticalityNumber = critNumber;
			criticalityWeight = critWeight;
			criticalityName = critName;
		}

		public Criticality(int critId, int critNumber, int critWeight, string critName, CriticalityFactorCollection critFactors)
		{
			criticalityId = critId;
			criticalityNumber = critNumber;
			criticalityWeight = critWeight;
			criticalityName = critName;
			criticalityFactors = critFactors;
		}

		public int CompareTo(object obj) 
		{
			if (obj == null)
			{
				return 1;
			}

			Criticality crit = obj as Criticality;
			if (crit != null) 
			{
				return this.CriticalityNumber.CompareTo(crit.CriticalityNumber);
			}
			else
			{
				throw new ArgumentException("Object is not a Criticality");
			}
		}

		public Criticality Copy()
		{
			Criticality newCrit = new Criticality();

			newCrit.CriticalityId = this.CriticalityId;
			newCrit.CriticalityName = this.CriticalityName;
			newCrit.CriticalityNumber = this.CriticalityNumber;
			newCrit.CriticalityWeight = this.CriticalityWeight;
			newCrit.CriticalityFactors = this.CriticalityFactors;

			return newCrit;
		}

		public int CriticalityId
		{
			get { return criticalityId; }
			set { criticalityId = value; }
		}

		public int CriticalityNumber
		{
			get { return criticalityNumber; }
			set { criticalityNumber = value; }
		}

		public int CriticalityWeight
		{
			get { return criticalityWeight; }
			set { criticalityWeight = value; }
		}

		public string CriticalityName
		{
			get { return criticalityName; }
			set { criticalityName = value; }
		}

		public CriticalityFactorCollection CriticalityFactors
		{
			get { return criticalityFactors; }
			set { criticalityFactors = value; }
		}

		public void SetCriticalityFactorList(CriticalityFactorCollection critFactors)
		{
			criticalityFactors = critFactors;
		}

		public void AddCriticalityFactor(CriticalityFactor critFactor)
		{
			criticalityFactors.Add(critFactor);
		}
		#region IList Members

		public bool IsReadOnly
		{
			get
			{
				// TODO:  Add Criticality.IsReadOnly getter implementation
				return false;
			}
		}

		public object this[int index]
		{
			get
			{
				// TODO:  Add Criticality.this getter implementation
				return null;
			}
			set
			{
				// TODO:  Add Criticality.this setter implementation
			}
		}

		public void RemoveAt(int index)
		{
			// TODO:  Add Criticality.RemoveAt implementation
		}

		public void Insert(int index, object value)
		{
			// TODO:  Add Criticality.Insert implementation
		}

		public void Remove(object value)
		{
			// TODO:  Add Criticality.Remove implementation
		}

		public bool Contains(object value)
		{
			// TODO:  Add Criticality.Contains implementation
			return false;
		}

		public void Clear()
		{
			// TODO:  Add Criticality.Clear implementation
		}

		public int IndexOf(object value)
		{
			// TODO:  Add Criticality.IndexOf implementation
			return 0;
		}

		public int Add(object value)
		{
			// TODO:  Add Criticality.Add implementation
			return 0;
		}

		public bool IsFixedSize
		{
			get
			{
				// TODO:  Add Criticality.IsFixedSize getter implementation
				return false;
			}
		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				// TODO:  Add Criticality.IsSynchronized getter implementation
				return false;
			}
		}

		public int Count
		{
			get
			{
				// TODO:  Add Criticality.Count getter implementation
				return 0;
			}
		}

		public void CopyTo(Array array, int index)
		{
			// TODO:  Add Criticality.CopyTo implementation
		}

		public object SyncRoot
		{
			get
			{
				// TODO:  Add Criticality.SyncRoot getter implementation
				return null;
			}
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			// TODO:  Add Criticality.GetEnumerator implementation
			return null;
		}

		#endregion
	}

	public class CriticalityFactor
	{
		private int factorId;
		private int factorOrderBy;
		private int scoreId;
		private int score;
		private string factorName;
		private bool useAsDefaultScore;
		
		public CriticalityFactor()
		{
		}

		public CriticalityFactor Copy()
		{
			CriticalityFactor newFactor = new CriticalityFactor();

			newFactor.FactorId = this.FactorId;
			newFactor.FactorName = this.FactorName;
			newFactor.FactorOrderBy = this.FactorOrderBy;
			newFactor.Score = this.Score;
			newFactor.ScoreId = this.ScoreId;
			newFactor.UseAsDefaultScore = this.UseAsDefaultScore;

			return newFactor;
		}

		public int FactorId
		{
			get { return factorId; }
			set { factorId = value; }
		}

		public int FactorOrderBy
		{
			get { return factorOrderBy; }
			set { factorOrderBy = value; }
		}

		public int ScoreId
		{
			get { return scoreId; }
			set { scoreId = value; }
		}

		public int Score
		{
			get { return score; }
			set { score = value; }
		}

		public string FactorName
		{
			get { return factorName; }
			set { factorName = value; }
		}

		public bool UseAsDefaultScore
		{
			get { return useAsDefaultScore; }
			set { useAsDefaultScore = value; }
		}
	}

	public class CriticalityCollection : System.Collections.CollectionBase
	{
		public void Add(Criticality crit)
		{
			List.Add(crit);
		}

		public void Remove(int index)
		{
			if (index > Count - 1 || index < 0)
			{
				//System.Windows.Forms.MessageBox.Show("Index not valid");
			}
			else
			{
				List.RemoveAt(index); 
			}
		}

		public Criticality ItemById(int CriticalityId)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((Criticality)List[i]).CriticalityId == CriticalityId)
				{
					//return (Criticality)List[i];
					return ((Criticality)List[i]).Copy();
				}
			}

			return null;
		}

		public Criticality GetCriticalityByNumber(int criticalityNumber)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((Criticality)List[i]).CriticalityNumber == criticalityNumber)
				{
					//return (Criticality)List[i];
					return ((Criticality)List[i]).Copy();
				}
			}

			return null;
		}

		public Criticality GetCriticalityByName(string criticalityName)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (string.Compare(criticalityName, ((Criticality)List[i]).CriticalityName, true) == 0)
				{
					//return (Criticality)List[i];
					return ((Criticality)List[i]).Copy();
				}
			}

			return null;
		}

		public System.Collections.ArrayList GetCriticalityNames()
		{
			System.Collections.ArrayList arrayListCritNames = new System.Collections.ArrayList();
			
			for (int i = 0; i < List.Count; i++)
			{
				arrayListCritNames.Add(((Criticality)List[i]).CriticalityName);
			}

			return arrayListCritNames;
		}

		public System.Collections.ArrayList GetCriticalityNamesToUpper()
		{
			System.Collections.ArrayList arrayListCritNames = new System.Collections.ArrayList();
			
			for (int i = 0; i < List.Count; i++)
			{
				arrayListCritNames.Add(((Criticality)List[i]).CriticalityName.ToUpper());
			}

			return arrayListCritNames;
		}

		public System.Collections.Specialized.ListDictionary GetCriticalityNamesWithId()
		{
			//System.Collections.ArrayList arrayListCritNames = new System.Collections.ArrayList();
			System.Collections.Specialized.ListDictionary listDictionaryCritNames = new System.Collections.Specialized.ListDictionary();

			for (int i = 0; i < List.Count; i++)
			{
				listDictionaryCritNames.Add(((Criticality)List[i]).CriticalityId, ((Criticality)List[i]).CriticalityName);
			}

			return listDictionaryCritNames;
		}
	}

	public class CriticalityFactorCollection : System.Collections.CollectionBase
	{
		public void Add(CriticalityFactor critFactor)
		{
			List.Add(critFactor);
		}

		//			public void Remove(int index)
		//			{
		//				if (index > Count - 1 || index < 0)
		//				{
		//					//System.Windows.Forms.MessageBox.Show("Index not valid");
		//				}
		//				else
		//				{
		//					List.RemoveAt(index); 
		//				}
		//			}

		public CriticalityFactor Item(int Index)
		{
			//return (CriticalityFactor)List[Index];
			return ((CriticalityFactor)List[Index]).Copy();
		}

		public CriticalityFactor ItemByScoreNotCopy(int factorScore)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).Score == factorScore)
				{
					return (CriticalityFactor)List[i];
				}
			}

			return null;
		}

		public CriticalityFactor ItemByNameNotCopy(string factorName)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).FactorName == factorName)
				{
					return (CriticalityFactor)List[i];
				}
			}

			return null;
		}

		//public CriticalityFactor DefaultFactor()
		public int GetDefaultFactorId()
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).UseAsDefaultScore == true)
				{
					return ((CriticalityFactor)List[i]).FactorId;
				}
			}

			return 0;
		}

		public CriticalityFactor GetDefaultFactor()
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).UseAsDefaultScore == true)
				{
					//return (CriticalityFactor)List[i];
					return ((CriticalityFactor)List[i]).Copy();
				}
			}

			return null;
		}

		//mam 03202012 - for use when creating sample pipe and node import files
		public string GetDefaultFactorName()
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).UseAsDefaultScore == true)
				{
					//return (CriticalityFactor)List[i];
					return ((CriticalityFactor)List[i]).FactorName;
				}
			}

			return "";
		}

		public int GetDefaultScore()
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).UseAsDefaultScore == true)
				{
					return ((CriticalityFactor)List[i]).Score;
				}
			}

			return -1;
		}

		public int GetScoreIdBasedOnScore(int score)
		{
			for (int i = 0; i < List.Count; i++)
			{
				if (((CriticalityFactor)List[i]).Score == score)
				{
					return ((CriticalityFactor)List[i]).ScoreId;
				}
			}

			return 0;
		}

		public ArrayList GetListScores()
		{
			ArrayList arrayListScores = new ArrayList();
			for (int i = 0; i < List.Count; i++)
			{
				arrayListScores.Add(((CriticalityFactor)List[i]).Score);
			}

			return arrayListScores;
		}

		public ArrayList GetListFactorNames()
		{
			ArrayList arrayListFactorNames = new ArrayList();
			for (int i = 0; i < List.Count; i++)
			{
				arrayListFactorNames.Add(((CriticalityFactor)List[i]).FactorName);
			}

			return arrayListFactorNames;
		}
	}

	//mam 07072011
	#region /***** Major Component Criticality Classes *****/

	//the MajorComponentSelectedCriticalityFactors class does not contain a Factor collection as only the user-selected factors (one per criticality) 
	//	will be stored in this class (rather than all of the factors for each criticality)
	public class MajorComponentSelectedCriticalityFactors : IComparable
	{
		private int criticalityId;
		private int criticalityNumber;
		private int criticalityWeight;
		private string criticalityName;

		private CriticalityFactor critFactor;

		private int criticalityOrderBy;
		//private int factorOrderBy;

		public MajorComponentSelectedCriticalityFactors()
		{
		}

		public MajorComponentSelectedCriticalityFactors(int critId, int critNumber, int critWeight, string critName)
		{
			criticalityId = critId;
			criticalityNumber = critNumber;
			criticalityWeight = critWeight;
			criticalityName = critName;
		}

		public int CompareTo(object obj) 
		{
			if (obj == null)
			{
				return 1;
			}

			MajorComponentSelectedCriticalityFactors crit = obj as MajorComponentSelectedCriticalityFactors;
			if (crit != null) 
			{
				return this.CriticalityNumber.CompareTo(crit.CriticalityNumber);
			}
			else
			{
				throw new ArgumentException("Object is not a Criticality");
			}
		}

		public MajorComponentSelectedCriticalityFactors Copy()
		{
			MajorComponentSelectedCriticalityFactors newFactor = new MajorComponentSelectedCriticalityFactors();

			newFactor.CriticalityId = this.CriticalityId;
			newFactor.CriticalityName = this.CriticalityName;
			newFactor.CriticalityNumber = this.CriticalityNumber;
			newFactor.CriticalityOrderBy = this.CriticalityOrderBy;
			newFactor.CriticalityWeight = this.CriticalityWeight;
			newFactor.CritFactor = this.CritFactor;

			return newFactor;
		}

		public int CriticalityId
		{
			get { return criticalityId; }
			set { criticalityId = value; }
		}

		public int CriticalityNumber
		{
			get { return criticalityNumber; }
			set { criticalityNumber = value; }
		}

		public int CriticalityWeight
		{
			get { return criticalityWeight; }
			set { criticalityWeight = value; }
		}

		public string CriticalityName
		{
			get { return criticalityName; }
			set { criticalityName = value; }
		}

		public CriticalityFactor CritFactor
		{
			get { return critFactor; }
			set { critFactor = value; }
		}

		public int CriticalityOrderBy
		{
			get { return criticalityOrderBy; }
			set { criticalityOrderBy = value; }
		}

		//		public int FactorOrderBy
		//		{
		//			get { return factorOrderBy; }
		//			set { factorOrderBy = value; }
		//		}
	}


	//mam 07072011
	//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
	//	rather than all of the factors for each criticality
	public class MajorComponentSelectedCriticalityFactorsCollection : System.Collections.CollectionBase
	{
		public void Add(MajorComponentSelectedCriticalityFactors crit)
		{
			List.Add(crit);
		}

		public void Remove(int index)
		{
			if (index > Count - 1 || index < 0)
			{
				//System.Windows.Forms.MessageBox.Show("Index not valid");
			}
			else
			{
				List.RemoveAt(index); 
			}
		}

		public MajorComponentSelectedCriticalityFactors Item(int Index)
		{
			return (MajorComponentSelectedCriticalityFactors)List[Index];
			//return ((MajorComponentSelectedCriticalityFactors)List[Index]).Copy();
		}

		public MajorComponentSelectedCriticalityFactors ItemById(int CriticalityId)
		{
			//foreach (MajorComponentSelectedCriticalityFactors item in (MajorComponentSelectedCriticalityFactors)List)
			for (int i = 0; i < List.Count; i++)
			{
				//if (item.CriticalityId == CriticalityId)
				if (((MajorComponentSelectedCriticalityFactors)List[i]).CriticalityId == CriticalityId)
				{
					//return (MajorComponentSelectedCriticalityFactors)List[i];
					return ((MajorComponentSelectedCriticalityFactors)List[i]).Copy();
				}
			}

			return null;
		}
	}


	public class CriticalityForImport : IComparable
	{
		private int criticalityId;
		private int criticalityNumber;
		private int criticalityWeight;
		private int columnIndex;
		private int selectedCriticalityScore;
		private int defaultCriticalityScore;
		private string criticalityName;
		private ListDictionary criticalityFactors = new ListDictionary();

		public CriticalityForImport()
		{
		}

		public CriticalityForImport(int critId, int critNumber, string critName)
		{
			criticalityId = critId;
			criticalityNumber = critNumber;
			criticalityName = critName;
		}

		public CriticalityForImport(int critId, int critNumber, string critName, ListDictionary critFactors)
		{
			criticalityId = critId;
			criticalityNumber = critNumber;
			criticalityName = critName;
			criticalityFactors = critFactors;
		}

		public int CompareTo(object obj) 
		{
			if (obj == null)
			{
				return 1;
			}

			CriticalityForImport crit = obj as CriticalityForImport;
			if (crit != null) 
			{
				return this.CriticalityNumber.CompareTo(crit.CriticalityNumber);
			}
			else
			{
				throw new ArgumentException("Object is not a CriticalityForImport");
			}
		}

		public int CriticalityId
		{
			get { return criticalityId; }
			set { criticalityId = value; }
		}

		public int CriticalityNumber
		{
			get { return criticalityNumber; }
			set { criticalityNumber = value; }
		}

		public int CriticalityWeight
		{
			get { return criticalityWeight; }
			set { criticalityWeight = value; }
		}

		public int ColumnIndex
		{
			get { return columnIndex; }
			set { columnIndex = value; }
		}

		public int SelectedCriticalityScore
		{
			get { return selectedCriticalityScore; }
			set { selectedCriticalityScore = value; }
		}

		public int DefaultCriticalityScore
		{
			get { return defaultCriticalityScore; }
			set { defaultCriticalityScore = value; }
		}

		public string CriticalityName
		{
			get { return criticalityName; }
			set { criticalityName = value; }
		}

		public ListDictionary CriticalityFactors
		{
			get { return criticalityFactors; }
			set { criticalityFactors = value; }
		}

		//			public void SetCriticalityFactorList(CriticalityFactorCollection critFactors)
		//			{
		//				criticalityFactors = critFactors;
		//			}
		//
		//			public void AddCriticalityFactor(CriticalityFactor critFactor)
		//			{
		//				criticalityFactors.Add(critFactor);
		//			}
	}

	#endregion /***** Major Component Criticality Classes *****/

}
