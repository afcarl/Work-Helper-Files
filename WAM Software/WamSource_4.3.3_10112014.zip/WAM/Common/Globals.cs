using System;
using System.Configuration;

//mam 11142011
using System.Collections;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for Globals.
	/// </summary>
	public class Globals
	{
		public Globals()
		{
		}

		//for testing only!!!
		//public static int DatabaseHitCount = 0;

		private static bool allowRounding = false;
		private static int allowRoundingDigit = 0;

		private static bool allowGraphNameMatching = false;
		private static bool showCostTab = false;
		private static bool showFacilityValuationTab = false;

		//mam 12192011
		private static System.Drawing.Color readOnlyBackgroundColorNumeric = System.Drawing.Color.FromKnownColor(System.Drawing.KnownColor.Control);
		private static System.Drawing.Color readOnlyBackgroundColorAssetNames = System.Drawing.Color.FromKnownColor(System.Drawing.KnownColor.Control);
		private static System.Drawing.Color readOnlyBackgroundColorScreen = System.Drawing.Color.FromKnownColor(System.Drawing.KnownColor.Control);
		private static bool applyReadOnlyBackgroundColorNumeric = false;
		private static bool applyReadOnlyBackgroundColorAssetNames = false;
		private static bool applyReadOnlyBackgroundColorScreen = false;

		//mam 01042012
		//the default is true
		private static bool showCostsAsZeroInReportForRetiredAssets = true;

		//mam 01222012
		//the default is true
		private static bool applyFacilityCriticalityFactor = true;

		//mam 03202012
		private static bool allowWamToCreatePhotoFileNames = true;

		//mam 03202012 - these values are not saved to the WAM.xml file
		private static bool exportImportSingleTab = true;
		private static bool exportImportNumericCrit = true;

		//mam 03202012
		private static string allDataTabName = "Import Format";
		private static string sampleDataTabName = "Sample Data";

		//mam 03202012 
		public static SortedList SortedListExportImportTabNames = new SortedList();

		//mam 102309
		public static string AccessPassword = "carollo3";
		private static string wamSqlServerConnectionString = string.Empty;
		private static string wamPhotoPath = string.Empty;

		//mam 07072011
		private static string errorText = string.Empty;

		//mam 11142011
		private static Common.CommonTasks.CritMapper critMapperPublicHealth = new WAM.Common.CommonTasks.CritMapper();
		private static Common.CommonTasks.CritMapper critMapperFinancial = new WAM.Common.CommonTasks.CritMapper();
		private static Common.CommonTasks.CritMapper critMapperEnvironmental = new WAM.Common.CommonTasks.CritMapper();
		private static Common.CommonTasks.CritMapper critMapperCustomerEffect = new WAM.Common.CommonTasks.CritMapper();

		//mam 03202012
		private static bool userHasWritePermission = false;

		//mam 11142011
		public static Common.CommonTasks.CritMapper CritMapperPublicHealth
		{
			get { return critMapperPublicHealth; }
			set { critMapperPublicHealth = value; }
		}
		public static Common.CommonTasks.CritMapper CritMapperFinancial
		{
			get { return critMapperFinancial; }
			set { critMapperFinancial = value; }
		}
		public static Common.CommonTasks.CritMapper CritMapperEnvironmental
		{
			get { return critMapperEnvironmental; }
			set { critMapperEnvironmental = value; }
		}
		public static Common.CommonTasks.CritMapper CritMapperCustomerEffect
		{
			get { return critMapperCustomerEffect; }
			set { critMapperCustomerEffect = value; }
		}

		//mam 102309
		public static string WamSqlConnectionString
		{
			get 
			{
				if (wamSqlServerConnectionString == null || wamSqlServerConnectionString == "")
				{
					wamSqlServerConnectionString = GetConnectionString();
				}
				return wamSqlServerConnectionString;
			}
		}

		//mam 102309
		public static string WamPhotoPath
		{
			get 
			{
				//mam 07072011 - added check for existence of image folder
				if (wamPhotoPath == null || wamPhotoPath == "" || !System.IO.Directory.Exists(wamPhotoPath))
				{
					wamPhotoPath = GetBasePhotoPath();
				}
				return wamPhotoPath;
			}
			set
			{
				wamPhotoPath = value;
			}
		}

		//mam 102309
		private static string GetConnectionString()
		{
			string connString = string.Empty;
			try
			{
				//System.Configuration.AppSettingsReader asr = new System.Configuration.AppSettingsReader();
				//connString = asr.GetValue("SqlServerConnectionString", typeof(string));
				connString = ConfigurationSettings.AppSettings["SqlServerConnectionString"];
			}
			catch
			{
			}

			return connString;
		}

		//mam 102309
		private static string GetBasePhotoPath()
		{
			string photoPath = string.Empty;
			try
			{
				//photoPath = ConfigurationSettings.AppSettings["BaseImagePath"];
				photoPath = Drive.Configuration.AppSettings.Settings.GetSetting("PhotoPaths", "BaseImagePath");

				//mam 07072011 - added check for existence of image folder
				if (photoPath == null || photoPath == "" || !System.IO.Directory.Exists(photoPath))
				{
					//if there is no images folder in the WAM.xml file, create a default images folder in the app startup path
					photoPath = System.Windows.Forms.Application.StartupPath + "\\Images";
					try
					{
						if (System.IO.Directory.Exists(photoPath))
						{
							WAM.Common.CommonTasks.SetInfosetImagePath(photoPath);
						}
						else
						{
							System.IO.Directory.CreateDirectory(photoPath);
							WAM.Common.CommonTasks.SetInfosetImagePath(photoPath);
						}
					}
					catch
					{
					}
				}

				//photoPath = photoPath.EndsWith("\\") ? photoPath.Substring(0, photoPath.Length - 1) : photoPath;
			}
			catch
			{
			}

			return photoPath;
		}

		public static bool AllowRounding
		{
			get { return allowRounding; }
			set { allowRounding = value; }
		}

		public static int AllowRoundingDigit
		{
			get { return allowRoundingDigit; }
			set { allowRoundingDigit = value; }
		}

		public static bool AllowGraphNameMatching
		{
			get { return allowGraphNameMatching; }
			set { allowGraphNameMatching = value; }
		}

		public static bool ShowCostTab
		{
			get { return showCostTab; }
			set { showCostTab = value; }
		}

		public static bool ShowFacilityValuationTab
		{
			get { return showFacilityValuationTab; }
			set { showFacilityValuationTab = value; }
		}

		//mam 12192011
		public static System.Drawing.Color ReadOnlyBackgroundColorNumeric
		{
			get { return readOnlyBackgroundColorNumeric; }
			set { readOnlyBackgroundColorNumeric = value; }
		}
		public static bool ApplyReadOnlyBackgroundColorNumeric
		{
			get { return applyReadOnlyBackgroundColorNumeric; }
			set { applyReadOnlyBackgroundColorNumeric = value; }
		}

		//mam 12192011
		public static System.Drawing.Color ReadOnlyBackgroundColorAssetNames
		{
			get { return readOnlyBackgroundColorAssetNames; }
			set { readOnlyBackgroundColorAssetNames = value; }
		}
		public static bool ApplyReadOnlyBackgroundColorAssetNames
		{
			get { return applyReadOnlyBackgroundColorAssetNames; }
			set { applyReadOnlyBackgroundColorAssetNames = value; }
		}

		//mam 12192011
		public static System.Drawing.Color ReadOnlyBackgroundColorScreen
		{
			get { return readOnlyBackgroundColorScreen; }
			set { readOnlyBackgroundColorScreen = value; }
		}
		public static bool ApplyReadOnlyBackgroundColorScreen
		{
			get { return applyReadOnlyBackgroundColorScreen; }
			set { applyReadOnlyBackgroundColorScreen = value; }
		}

		//mam 01042012
		public static bool ShowCostsAsZeroInReportForRetiredAssets
		{
			get { return showCostsAsZeroInReportForRetiredAssets; }
			set { showCostsAsZeroInReportForRetiredAssets = value; }
		}

		//mam 01222012
		public static bool ApplyFacilityCriticalityFactor
		{
			get { return applyFacilityCriticalityFactor; }
			set { applyFacilityCriticalityFactor = value; }
		}

		//mam 03202012
		public static bool AllowWamToCreatePhotoFileNames
		{
			get { return allowWamToCreatePhotoFileNames; }
			set { allowWamToCreatePhotoFileNames = value; }
		}

		//mam 07072011
		public static string ErrorText
		{
			get { return errorText; }
			set { errorText = value; }
		}

		//mam 03202012
		public static string AllDataTabName
		{
			get { return allDataTabName; }
			set { allDataTabName = value; }
		}

		//mam 03202012
		public static string SampleDataTabName
		{
			get { return sampleDataTabName; }
			set { sampleDataTabName = value; }
		}

		//mam  - let's not do it this way
		////mam 03202012 - this is not saved to the WAM.xml file
		//public static bool ExportImportSingleTab
		//{
		//	get { return exportImportSingleTab; }
		//	set { exportImportSingleTab = value; }
		//}

		//mam  - let's not do it this way
		////mam 03202012 - this is not saved to the WAM.xml file
		//public static bool ExportImportNumericCrit
		//{
		//	get { return exportImportNumericCrit; }
		//	set { exportImportNumericCrit = value; }
		//}

		//mam 03202012
		public static bool UserHasWritePermission
		{
			get { return userHasWritePermission; }
			set { userHasWritePermission = value; }
		}
	}
}
