using System;

namespace WAM.Common
{
	/// <summary>
	/// Summary description for StartUpChores.
	/// </summary>
	public class StartUpChores
	{
		public StartUpChores()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		//mam 102309 - no longer necessary
//		public string SetDatabaseImageFolderName(string infosetImageFolderWithPath)
//		{
//			//retrieve image folder for the current database
//			//create the image folder name, if necessary
//
//			WAM.Common.DataAccess dataAccess = new DataAccess();
//			System.Data.DataSet dataSet = new System.Data.DataSet();
//			int pos = 0;
//			int rowCount = 0;
//			string databaseImageFolder = "";
//			string infosetImageFolder = infosetImageFolderWithPath;
//			string appPath = Drive.IO.Directory.GetApplicationPath() + @"\Images\";
//
//			//get the infoset folder name (without the path)
//			pos = infosetImageFolder.LastIndexOf(@"\");
//			infosetImageFolder = infosetImageFolder.Remove(0, pos + 1);
//
//			try
//			{
//				//check the database to see if it contains the image folder name
//				dataAccess = new WAM.Common.DataAccess();
//				dataSet = dataAccess.GetDisconnectedDataset("SELECT DatabaseImageFolder FROM DatabaseInfo");
//
//				if (dataSet == null)
//					return "";
//				else
//				{
//					rowCount = dataSet.Tables[0].Rows.Count;
//					foreach (System.Data.DataRow dataRow in dataSet.Tables[0].Rows)
//					{
//						if (dataRow["DatabaseImageFolder"].ToString() != "")
//						{
//							databaseImageFolder = dataRow["DatabaseImageFolder"].ToString();
//							break;
//						}
//					}
//				}
//
//				if (databaseImageFolder == "")
//				{
//					//the database does not contain the folder name
//					//this means that the database is an existing database that uses only the infoset name for the folder name
//					//check to see that the infoset folder name exists
//					//if it does, use "" as the databaseImageFolder name
//					//if it does not, create a new image folder using the database and infoset names and save the folder name to the database
//
//					if (System.IO.Directory.Exists(infosetImageFolderWithPath))
//					{
//						//the image folder (without database name) already exists
//					}
//					else
//					{
//						//the infoset folder name does not exist; create the folder using both the database and infoset names
//						WAM.Common.CommonTasks commonTasks = new CommonTasks();
//						databaseImageFolder = commonTasks.CreateDatabaseImageFolderName();
//						commonTasks.CreateDatabaseInfosetFolderName(databaseImageFolder + @"\" + infosetImageFolder);
//
//						//get the database folder name (without the path)
//						pos = databaseImageFolder.LastIndexOf(@"\");
//						databaseImageFolder = databaseImageFolder.Remove(0, pos + 1);
//
//						//update database with folder name
//						if (rowCount == 0)
//							dataAccess.ExecuteCommand("INSERT INTO DatabaseInfo (DatabaseImageFolder) VALUES('" + databaseImageFolder + "')");
//						else
//							dataAccess.ExecuteCommand("UPDATE DatabaseInfo SET DatabaseImageFolder = '" + databaseImageFolder + "'");
//					}
//				}
//				else
//				{
//					//the database contains the name of the image folder
//					//the image folder uses the both the database name and the infoset name
//					//if the database name folder doesn't exist, create it (don't bother trying to create the infoset folder here)
//					if (!System.IO.Directory.Exists(appPath + databaseImageFolder))
//					{
//						try
//						{
//							System.IO.Directory.CreateDirectory(appPath + databaseImageFolder);
//						}
//						catch
//						{
//							return "";
//						}
//					}
//				}
//				databaseImageFolder = appPath + databaseImageFolder;
//				return databaseImageFolder;
//			}
//			catch
//			{
//				return "";
//			}
//			finally
//			{
//				dataSet = null;
//				dataAccess = null;
//			}
//		}

		public bool CreateFieldSheetFileFromDatabase()
		{
			string filenameWrite = string.Format(@"{0}\" + "FieldSheet.xml", Drive.IO.Directory.GetApplicationPath());
			System.IO.StreamWriter streamWriter = null;

			//delete the existing file
			try
			{
				if (System.IO.File.Exists(filenameWrite))
					System.IO.File.Delete(filenameWrite);
			}
			catch
			{
				System.Diagnostics.Debug.WriteLine("FieldSheet file not deleted");
			}

			//create a new file based on data in the FieldSheetData table
			try
			{
				WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
				System.Data.DataSet dataSet = 
					dataAccess.GetDisconnectedDataset("SELECT FieldSheetData FROM FieldSheetData");

				if (dataSet == null)
					//throw new Exception("Database Error.");
					return false;
				else
				{
					if (dataSet.Tables[0].Rows[0].ToString() != "")
					{
						//write the data to an xml file
						streamWriter = new System.IO.StreamWriter(filenameWrite);
						streamWriter.Write(dataSet.Tables[0].Rows[0]["FieldSheetData"].ToString());
						streamWriter.Close();

						//mam 112806 - don't set file to hidden, as it seems to be causing an error when trying to open the file in code
						//if (System.IO.File.Exists(filenameWrite))
						//{
						//	System.IO.File.SetAttributes(filenameWrite, System.IO.FileAttributes.Hidden);
						//}
					}
				}

				return true;
			}
			catch
			{
				streamWriter.Close();
				return false;
			}
		}
	}
}
