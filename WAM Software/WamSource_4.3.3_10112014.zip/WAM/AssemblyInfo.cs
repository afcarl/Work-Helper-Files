using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("Water and Wastewater Asset Manager")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("10/11/2014")]	//mam 10112014 - changed for version 4.3.3
[assembly: AssemblyCompany("Carollo Engineers")]
[assembly: AssemblyProduct("WAM")]
[assembly: AssemblyCopyright("Carollo Engineers")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

//[assembly: AssemblyVersion("2.0.*")]
//[assembly: AssemblyVersion("2.1.0.0")]
//[assembly: AssemblyVersion("2.1.0.1")]
//[assembly: AssemblyVersion("2.1.1.0")]

//112806
//[assembly: AssemblyVersion("3.0")]

//062407
//[assembly: AssemblyVersion("3.0.0.1")]

//091607 - fixed problem with CWP (see WAM.UI.Grids.ComponentGrid.AdjustCWPValues())
//[assembly: AssemblyVersion("3.0.0.2")]

//101107 - addedReplaceDoubleQuoteWithTwoDoubleQuotes to replace double quote with two 
//	double quotes for CSV export file
//the quotes at the end of the Comments field of an asset was causing the asset following it to be appended
//	to the end of the Comments field in the exported CSV report
//also applied the fix to the name, idnumber, assessedby, etc. fields for the CSV reports
//[assembly: AssemblyVersion("3.0.0.3")]

//mam 051708 - changed fractions for Evaluated Remaining Useful Life and 
//	Economic Remaining Useful Life
//[assembly: AssemblyVersion("3.1.0.0")]

//mam 102309 - moved from Access database to SQL Server 2005
//[assembly: AssemblyVersion("4.0.0.3")]

//mam 07072011 - changed crits, added rehab fields, added cip and asset class
//[assembly: AssemblyVersion("4.1.0.0")]

//mam 11142011 - allow user to map Access crits to SQL Server crits for components imported from an Access database, 
//	changed logo to new Carollo logo, changed version display from major.minor to major.minor.build on splash screen
//	version 4.1.1.0 was not released to Carollo's clients because it was immediately superseded by version 4.1.2.0
//[assembly: AssemblyVersion("4.1.1.0")]

//mam 11142011 - correct problem that didn't allow discipline photos to be displayed in Photo tab - discipline photo
//	files were being written to disk with 0000 as the process id rather than a valid process id
//[assembly: AssemblyVersion("4.1.2.0")]

//mam 11142011 - version 4.1.2.0 corrects the discipline photo problem only for Mech and Struct disciplines
//	version 4.1.3.0 corrects the problem for Civil disciplines
//[assembly: AssemblyVersion("4.1.3.0")]

//mam 12192011 - left version as 4.1.3.0 - added the ability to set the background color of read-only text boxes
//this version was sent to Carollo, but never installed on a client computer
//[assembly: AssemblyVersion("4.1.3.0")]

//mam 01042012 - version 4.1.4.0 
//the change made on 12192011 to set the color of read-only text boxes was a quick fix; the user would have to go 
//	into the WAM.xml file to set the rgb values for the text boxes; version 4.1.4.0 allows the user to set the 
//	color via the Edit > Preferences screen
//additional changes:  allow user to show retired asset costs as zeros in reports (for MSC components/disciplines only)
//this version was never sent to Carollo
//[assembly: AssemblyVersion("4.1.4.0")]

//mam 01222012 - version 4.2.0.0
// - add RehabCostDesc, ReplacementValueDesc, RehabYearNext to DisciplineMech, Discipline Struct, DisciplineLand tables
// - add RehabCostDesc, ReplacementValueDesc, RehabYearNext, Time to Next Replacement to DisciplineMech, Discipline Struct, DisciplineLand forms
// - add FacilityCriticality to Facilities table
// - add FacilityCriticality to Facility form
// - add Constraint Viewer
// - don't read Time to Next Rehab (RehabNext) from database (it is no longer allowed to be overridden, and so is always calculated and never stored in the database)
// - add override to Next Rehab Year
// - remove override from Time to Next Rehab
// - show retired assets costs as zero in reports (display and csv) - allow user to determine this in preferences form
// - modify calcs: Next Rehab Year, Time to Next Rehab, Next Replacement Year
// - new field calc: Time to Next Replacement
// - add Next Rehab Year, Time to Next Replacement, Next Replacement Year to planning mode warning message
// - add timing constraints: Installation Year <= Last Rehab Year <= Inspection Year <= Current Year <= Next Rehab Year or Next Replacement Year
//[assembly: AssemblyVersion("4.2.0.0")]

//mam 03202012
//modified cache loading procedure so that all data is loaded with a few queries, rather than one query for each Fac, Proc, Comp, and Disc in the database
//[assembly: AssemblyVersion("4.3.0.0")]

//mam 06212012
//[assembly: AssemblyVersion("4.3.1.0")]
//modified report screen to not check database when the report window loads (it is unnecessary, as all data has already been
//	loaded into WAM when WAM was opened, and it significantly slows down the report window opening if there is a lot of data)

//mam 12312012
//[assembly: AssemblyVersion("4.3.2.0")]
//modified UI\Import\ImportFromTextFile.cs (marked as "12272012" in code) so that unreadable cells in Excel do not cause 
//	data problems in the import grid - this problem existed in versions 4.3.0.0 and 4.3.1.0

//mam 10112014
[assembly: AssemblyVersion("4.3.3.0")]
//modified UI\Import\ImportFromTextFile.cs to allow run time hours to exceed 32767 when importing (new limit is 2,147,483,647)
//	data problems in the import grid - this problem existed in versions 4.3.0.0 and 4.3.1.0



// In order to sign your assembly you must specify a key to use. Refer to the 
// Microsoft .NET Framework documentation for more information on assembly signing.
//
// Use the attributes below to control which key is used for signing. 
//
// Notes: 
//   (*) If no key is specified, the assembly is not signed.
//   (*) KeyName refers to a key that has been installed in the Crypto Service
//       Provider (CSP) on your machine. KeyFile refers to a file which contains
//       a key.
//   (*) If the KeyFile and the KeyName values are both specified, the 
//       following processing occurs:
//       (1) If the KeyName can be found in the CSP, that key is used.
//       (2) If the KeyName does not exist and the KeyFile does exist, the key 
//           in the KeyFile is installed into the CSP and used.
//   (*) In order to create a KeyFile, you can use the sn.exe (Strong Name) utility.
//       When specifying the KeyFile, the location of the KeyFile should be
//       relative to the project output directory which is
//       %Project Directory%\obj\<configuration>. For example, if your KeyFile is
//       located in the project directory, you would specify the AssemblyKeyFile 
//       attribute as [assembly: AssemblyKeyFile("..\\..\\mykey.snk")]
//   (*) Delay Signing is an advanced option - see the Microsoft .NET Framework
//       documentation for more information on this.
//
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
