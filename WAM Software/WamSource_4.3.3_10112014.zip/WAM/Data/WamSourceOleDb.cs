//mam 102309

using System;
using System.Windows.Forms;
using Drive.Configuration;
using Drive.Data.OleDb;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for WamSourceOleDb.
	/// </summary>
	public class WamSourceOleDb
	{
		public WamSourceOleDb()
		{
		}

		#region /****** Static Methods / Properties ******/

		private static Jet40DataSource m_dataSource = null;
		private static Jet40DataSource m_ENRSource = null;

		public static Jet40DataSource CurrentSource
		{
			get 
			{
				if (m_dataSource == null)
				{
					//mam - add error handling because an error occurs if WAM.xml exists, but is empty
					//	(although this shouldn't happen)
					string lastSource = "";
					try
					{
						lastSource = Drive.Configuration.AppSettings.
							Settings.GetSetting("DBConnection", "LastSource");
					}
					catch
					{
						System.Diagnostics.Trace.WriteLine(String.Format("WAMSource.Jet40DatSource error"));
						System.Diagnostics.Debug.Assert(false, "WAMSource.Jet40DatSource error");
					}

					//mam 050806 - the source string must contain the entire folder path or an error occurs when 
					//	saving raw graphing data to the hard drive in a folder different from the WAM folder
					//mam 112806 - modified by adding lastSource.Length > 0 to allow WAM to attempt to create the WAM.mdb file when
					//	the app first opens and there is no WAM.xml file and no WAM.mdb file
					if (lastSource.Length > 0 && lastSource.IndexOf(@"\") < 0 && lastSource.IndexOf(@"/") < 0)
					{
						//get the application folder
						string appPath = Application.StartupPath;

						if (!appPath.EndsWith(@"\") && !appPath.EndsWith(@"/"))
						{
							if (appPath.IndexOf(@"\") > -1)
							{
								appPath += @"\";
							}
							else
							{
								appPath += @"/";
							}
						}

						lastSource = appPath + lastSource;
					}

					if (!System.IO.File.Exists(lastSource) || lastSource == null || lastSource.Length == 0)
					{
						//mam - show the user a warning message when the database cannot be found
						if (lastSource.Length > 0)
						{
							System.Text.StringBuilder builder = new System.Text.StringBuilder(200);
							builder.Append("WAM cannot find the database\r\n\r\n");
							builder.AppendFormat(@"'{0}'", lastSource.ToString());
							builder.Append("\r\n\r\nWAM will attempt to open a default database.");

							//mam 050806 - the message text was set, but no message was shown to the user
							MessageBox.Show(builder.ToString(), "WAM Cannot Locate Database", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						//</mam>

						// Default last source to be the current folder, 
						// WAM.MDB
						System.Reflection.Assembly assembly = System.Reflection.Assembly.GetEntryAssembly();

						lastSource = string.Format(@"{0}\WAM.mdb", Drive.IO.Directory.GetFilePath(assembly.Location));

						//mam - save lastSource
						try
						{
							Drive.Configuration.AppSettings.
								Settings.SetSetting("DBConnection", "LastSource", lastSource);
						}
						catch
						{
							System.Diagnostics.Trace.WriteLine(String.Format("WAMSource.Jet40DatSource error"));
							System.Diagnostics.Debug.Assert(false, "WAMSource.Jet40DatSource error");
						}
						//</mam>

						//mam - make sure WAM.mdb exists - create it, if necessary
						MainForm.CreateWAMDatabaseFile();
						//</mam>
					}

					m_dataSource = new Jet40DataSource(lastSource);

					//mam - Jet40DataSource apparently does not allow for a password, so add one here, if necessary
					string connectionString = m_dataSource.ConnectionString;
					connectionString = CheckConnectionString("", connectionString);
					//if (connectionString.ToUpper().IndexOf("PASSWORD") > -1)
					if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
					{
						//the database is password protected
						m_dataSource.Provider = m_dataSource.Provider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
					}
					//</mam>
				}
				return m_dataSource;
			}
			set
			{
				Drive.Configuration.AppSettings.Settings.SetSetting("DBConnection", "LastSource", value.DataPath);

				m_dataSource = value;

				//mam - Jet40DataSource apparently does not allow for a password, so add one here, if necessary
				string connectionString = m_dataSource.ConnectionString;
				connectionString = CheckConnectionString("", connectionString);
				if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
				{
					//the database is password protected
					m_dataSource.Provider = m_dataSource.Provider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
				}
				//</mam>
			}
		}


		//mam - check source (used when importing infosets from version 2.0+ databases)
		public static string CheckSourceConnection(string sourceConnection, string sourceProvider)
		{
			//Jet40DataSource apparently does not allow for a password, so add one here, if necessary
			string connectionString = sourceConnection;
			connectionString = CheckConnectionString("", connectionString);
			if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
			{
				//the database is password protected
				if (sourceProvider.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) < 0)
					sourceProvider = sourceProvider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
			}
			return sourceProvider;
		}
		//</mam>

		public static Jet40DataSource ENRSource
		{
			get 
			{
				if (m_ENRSource == null)
				{
					string	sourcePath = string.Format(@"{0}\20CitiesENR.mdb", 
						Drive.IO.Directory.GetApplicationPath());

					m_ENRSource = new Jet40DataSource(sourcePath);

					//mam - Jet40DataSource apparently does not allow for a password, so add one here, if necessary
					string connectionString = m_ENRSource.ConnectionString;
					connectionString = CheckConnectionString("", connectionString);
					if (connectionString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
					{
						//the database is password protected
						m_ENRSource.Provider = m_ENRSource.Provider + ";Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword;
					}
					//</mam>
				}

				return m_ENRSource;
			}
		}

		//mam
		private static string CheckConnectionString(string connStringPwd, string connString)
		{
			//The databases (20CitiesENR.mdb, OriginalData.mdb, FreshWam.mdb) are now password protected.
			//	However, existing users at Carollo have databases that are not password protected.
			//	Therefore, test the connection to see if it works with the password or without it, and
			//	pass back the correct connection string.

			string connectionString = connString;

			if (connStringPwd == "" && connString == "")
				return "";

			if (connStringPwd == "")
			{
				if (connString.ToUpper().IndexOf("PASSWORD=" + WAM.Common.Globals.AccessPassword.ToUpper()) > -1)
				{
					//there is already a password in the connection string
				}
				else
				{
					//insert a password into the connection string
					int pos = -1;
					pos = connString.ToUpper().IndexOf("DATA SOURCE");
					if (pos > -1)
					{
						connStringPwd = connString;
						connStringPwd = connStringPwd.Insert(pos, "Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword + ";");
					}
				}
			}

			try
			{
				using (System.Data.OleDb.OleDbConnection sqlConnection = new System.Data.OleDb.OleDbConnection(connStringPwd))
				{
					sqlConnection.Open();
					connectionString = connStringPwd;
					if (sqlConnection.State == System.Data.ConnectionState.Open)
						sqlConnection.Close();
				}
			}
			catch(Exception ex)
			{
				//the database won't open with the password, so pass back the connection string without the password
				connectionString = connString;
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
			}

			return connectionString;
		}
		//</mam>

		//mam
		public static string SelectedDBConnectionString(string databaseNameWithPath)
		{
			string connectionString = "";
			string connectionStringPwd = "";

			if (databaseNameWithPath.IndexOf(@"\") > -1)
			{
				connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + databaseNameWithPath;
				connectionStringPwd = @"Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword + ";Data Source=" + databaseNameWithPath;
			}
			else
			{
				//if databaseNameWithPath is a file name without the path
				connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
					Drive.IO.Directory.GetApplicationPath() + @"\" + databaseNameWithPath;
				connectionStringPwd = @"Provider=Microsoft.Jet.OLEDB.4.0;Jet OLEDB:Database Password=" + WAM.Common.Globals.AccessPassword + ";Data Source=" +
					Drive.IO.Directory.GetApplicationPath() + @"\" + databaseNameWithPath;
			}

			connectionString = CheckConnectionString(connectionStringPwd, connectionString);
			return connectionString;
		}
		//</mam>


		#endregion /****** Static Methods / Properties ******/
	}
}
