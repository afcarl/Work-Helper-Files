using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Discipline3.
	/// </summary>
	public class Discipline3 : Discipline
	{
		#region /***** Member Variables *****/
		private ItemStatus	m_severalPotholes = ItemStatus.No;
		private ItemStatus	m_excessiveErosion = ItemStatus.No;
		private ItemStatus	m_roadDegradation = ItemStatus.No;
		private ItemStatus	m_expansionSpace = ItemStatus.No;
		private ItemStatus	m_functionCover = ItemStatus.No;
		private ItemStatus	m_fencingAdequate = ItemStatus.No;
		private ItemStatus	m_facilitiesSecure = ItemStatus.No;
		private DateTime	m_dateInspected = DateTime.Now.Date;
		private string		m_assessedBy = "";
		private string		m_equipmentNumber = "";
		private string		m_manufacturer = "";
		private string		m_runHours = "";
		private string		m_photoCaption1 = "";
		private string		m_photoCaption2 = "";
		private string		m_photoCaption3 = "";
		private string		m_comments = "";
		private bool		m_runningAtInspect = false;
		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		public				Discipline3(int id)
			: base(WAMSource.CurrentSource.ConnectionString, id)
		{
		}

		public				Discipline3(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		protected			Discipline3(System.Data.OleDb.OleDbDataReader reader)
			: base(reader)
		{
		}

		protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_severalPotholes = (ItemStatus)reader.GetByte(col++);
			m_excessiveErosion = (ItemStatus)reader.GetByte(col++);
			m_roadDegradation = (ItemStatus)reader.GetByte(col++);
			m_expansionSpace = (ItemStatus)reader.GetByte(col++);
			m_functionCover = (ItemStatus)reader.GetByte(col++);
			m_fencingAdequate = (ItemStatus)reader.GetByte(col++);
			m_facilitiesSecure = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);
			m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			m_photoCaption1 = Drive.SQL.ReadNullableString(reader, col++);
			m_photoCaption2 = Drive.SQL.ReadNullableString(reader, col++);
			m_photoCaption3 = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_runningAtInspect = reader.GetBoolean(col++);
		}
		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc3_id, component_id, disc3_conditionRanking, disc3_CWPAssetValue, ");
			builder.Append("disc3_originalUsefulLife, ");
			builder.Append("disc3_severalPotholes, ");
			builder.Append("disc3_excessiveErosion, disc3_roadDegradation, ");
			builder.Append("disc3_expansionSpace, disc3_functionCover, ");
			builder.Append("disc3_fencingAdequate, disc3_facilitiesSecure, ");
			builder.Append("disc3_dateInspected, disc3_assessedBy, disc3_equipmentNumber, ");
			builder.Append("disc3_manufacturer, disc3_runHours, disc3_installationYear, ");
			builder.Append("disc3_photoCaption1, disc3_photoCaption2, disc3_photoCaption3, ");
			builder.Append("disc3_comments, disc3_runningAtInspect ");
			builder.Append("FROM Discipline3 ");
			builder.AppendFormat("WHERE component_id={0}", id);

			return builder.ToString();
		}

		protected override string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO Discipline3 (");

			builder.Append("component_id, disc3_conditionRanking, disc3_CWPAssetValue, ");
			builder.Append("disc3_originalUsefulLife, ");
			builder.Append("disc3_severalPotholes, ");
			builder.Append("disc3_excessiveErosion, disc3_roadDegradation, ");
			builder.Append("disc3_expansionSpace, disc3_functionCover, ");
			builder.Append("disc3_fencingAdequate, disc3_facilitiesSecure, ");
			builder.Append("disc3_dateInspected, disc3_assessedBy, disc3_equipmentNumber, ");
			builder.Append("disc3_manufacturer, disc3_runHours, disc3_installationYear, ");
			builder.Append("disc3_photoCaption1, disc3_photoCaption2, disc3_photoCaption3, ");
			builder.Append("disc3_comments, disc3_runningAtInspect ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("{0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("{0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("{0}, ", m_orgUsefulLife);
			builder.AppendFormat("{0}, ", ((byte)m_severalPotholes));
			builder.AppendFormat("{0}, ", ((byte)m_excessiveErosion));
			builder.AppendFormat("{0}, ", ((byte)m_roadDegradation));
			builder.AppendFormat("{0}, ", ((byte)m_expansionSpace));
			builder.AppendFormat("{0}, ", ((byte)m_functionCover));
			builder.AppendFormat("{0}, ", ((byte)m_fencingAdequate));
			builder.AppendFormat("{0}, ", ((byte)m_facilitiesSecure));
			builder.AppendFormat("'{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_runHours));
			builder.AppendFormat("{0}, ", m_installationYear);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption1));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption2));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption3));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0} ", Drive.SQL.JetBoolToBit(m_runningAtInspect));
			builder.Append(")");

			return builder.ToString();
		}

		protected override string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE Discipline3 SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("disc3_conditionRanking={0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("disc3_CWPAssetValue={0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("disc3_originalUsefulLife={0}, ", m_orgUsefulLife);
			builder.AppendFormat("disc3_severalPotholes={0}, ", ((byte)m_severalPotholes));
			builder.AppendFormat("disc3_excessiveErosion={0}, ", ((byte)m_excessiveErosion));
			builder.AppendFormat("disc3_roadDegradation={0}, ", ((byte)m_roadDegradation));
			builder.AppendFormat("disc3_expansionSpace={0}, ", ((byte)m_expansionSpace));
			builder.AppendFormat("disc3_functionCover={0}, ", ((byte)m_functionCover));
			builder.AppendFormat("disc3_fencingAdequate={0}, ", ((byte)m_fencingAdequate));
			builder.AppendFormat("disc3_facilitiesSecure={0}, ", ((byte)m_facilitiesSecure));
			builder.AppendFormat("disc3_dateInspected='{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("disc3_assessedBy='{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("disc3_equipmentNumber='{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("disc3_manufacturer='{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("disc3_runHours={0}, ", m_runHours);
			builder.AppendFormat("disc3_installationYear={0}, ", m_installationYear);
			builder.AppendFormat("disc3_photoCaption1={0}, ", Drive.SQL.StringToDBString(m_photoCaption1));
			builder.AppendFormat("disc3_photoCaption2={0}, ", Drive.SQL.StringToDBString(m_photoCaption2));
			builder.AppendFormat("disc3_photoCaption3={0}, ", Drive.SQL.StringToDBString(m_photoCaption3));
			builder.AppendFormat("disc3_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("disc3_runningAtInspect={0} ", Drive.SQL.JetBoolToBit(m_runningAtInspect));

			builder.AppendFormat("WHERE (component_id={0}) ", ID);
			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From Discipline3 WHERE component_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public override string Name
		{
			get { return "Site Improvements / Landscaping / Other"; }
		}

		public ItemStatus	SeveralPotholes
		{
			get { return m_severalPotholes; }
			set { m_severalPotholes = value; }
		}

		public ItemStatus	ExcessiveErosion
		{
			get { return m_excessiveErosion; }
			set { m_excessiveErosion = value; }
		}

		public ItemStatus	RoadDegradation
		{
			get { return m_roadDegradation; }
			set { m_roadDegradation = value; }
		}

		public ItemStatus	ExpansionSpace
		{
			get { return m_expansionSpace; }
			set { m_expansionSpace = value; }
		}

		public ItemStatus	FunctionCover
		{
			get { return m_functionCover; }
			set { m_functionCover = value; }
		}

		public ItemStatus	FencingAdequate
		{
			get { return m_fencingAdequate; }
			set { m_fencingAdequate = value; }
		}

		public ItemStatus	FacilitiesSecure
		{
			get { return m_facilitiesSecure; }
			set { m_facilitiesSecure = value; }
		}

		public DateTime		DateInspected
		{
			get { return m_dateInspected; }
			set { m_dateInspected = value; }
		}

		public string		EquipmentNumber
		{
			get { return m_equipmentNumber; }
			set
			{
				if (value.Length > 255)
					m_equipmentNumber = value.Substring(255);
				else
					m_equipmentNumber = value;
			}
		}

		public string		AssessedBy
		{
			get { return m_assessedBy; }
			set
			{
				if (value.Length > 255)
					m_assessedBy = value.Substring(255);
				else
					m_assessedBy = value;
			}
		}

		public string		Manufacturer
		{
			get { return m_manufacturer; }
			set
			{
				if (value.Length > 255)
					m_manufacturer = value.Substring(255);
				else
					m_manufacturer = value;
			}
		}

		public string		RunHours
		{
			get { return m_runHours; }
			set
			{
				if (value.Length > 255)
					m_runHours = value.Substring(255);
				else
					m_runHours = value;
			}
		}

		public string		CaptionPhoto1
		{
			get { return m_photoCaption1; }
			set
			{
				if (value.Length > 255)
					m_photoCaption1 = value.Substring(255);
				else
					m_photoCaption1 = value;
			}
		}

		public string		CaptionPhoto2
		{
			get { return m_photoCaption2; }
			set
			{
				if (value.Length > 255)
					m_photoCaption2 = value.Substring(255);
				else
					m_photoCaption2 = value;
			}
		}

		public string		CaptionPhoto3
		{
			get { return m_photoCaption3; }
			set
			{
				if (value.Length > 255)
					m_photoCaption3 = value.Substring(255);
				else
					m_photoCaption3 = value;
			}
		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public bool			RunningAtInspect
		{
			get { return m_runningAtInspect; }
			set { m_runningAtInspect = value; }
		}
		#endregion /***** Properties *****/

		#region /***** Static Methods *****/
		public static Discipline3 LoadForComponent(int componentID)
		{
			return LoadForComponent(WAMSource.CurrentSource.ConnectionString, componentID);
		}

		public static Discipline3 LoadForComponent(string connectionString, int componentID)
		{
			OleDbConnection	sqlConnection = 
				new OleDbConnection(connectionString);
			Discipline3 retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponent(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		public static Discipline3 LoadForComponent(OleDbConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info
			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			Discipline3		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc3_id, component_id, disc3_conditionRanking, disc3_CWPAssetValue, ");
			builder.Append("disc3_originalUsefulLife, ");
			builder.Append("disc3_severalPotholes, ");
			builder.Append("disc3_excessiveErosion, disc3_roadDegradation, ");
			builder.Append("disc3_expansionSpace, disc3_functionCover, ");
			builder.Append("disc3_fencingAdequate, disc3_facilitiesSecure, ");
			builder.Append("disc3_dateInspected, disc3_assessedBy, disc3_equipmentNumber, ");
			builder.Append("disc3_manufacturer, disc3_runHours, disc3_installationYear, ");
			builder.Append("disc3_photoCaption1, disc3_photoCaption2, disc3_photoCaption3, ");
			builder.Append("disc3_comments, disc3_runningAtInspect ");
			builder.Append("FROM Discipline3 ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), 
					sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
					newObject = new Discipline3(dataReader);
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Discipline3.LoadForComponent Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				newObject = new Discipline3(0);
				newObject.ComponentID = componentID;
			}
			
			return newObject;
		}
		#endregion /***** Static Methods *****/
	}
}
