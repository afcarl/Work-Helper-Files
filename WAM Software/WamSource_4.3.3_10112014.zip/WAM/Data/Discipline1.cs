using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Discipline1.
	/// </summary>
	public class Discipline1 : Discipline
	{
		#region /***** Member Variables *****/
		private ItemStatus	m_mechExcessiveVibration = ItemStatus.No;
		private ItemStatus	m_mechExcessiveNoise = ItemStatus.No;
		private ItemStatus	m_mechExcessiveCorrosion = ItemStatus.No;
		private ItemStatus	m_mechExcessiveLeaks = ItemStatus.No;
		private ItemStatus	m_mechRunningHot = ItemStatus.No;
		private ItemStatus	m_mechCanRunWhenInspected = ItemStatus.No;
		private ItemStatus	m_mechSupportIsFunctional = ItemStatus.No;
		private ItemStatus	m_mechPartsMissing = ItemStatus.No;
		private ItemStatus	m_mechPartsAvailable = ItemStatus.No;
		private ItemStatus	m_mechAdequate = ItemStatus.No;
		private ItemStatus	m_mechMotorAmps = ItemStatus.No;
		private ItemStatus	m_instrIndicationFunctional = ItemStatus.No;
		private ItemStatus	m_instrAlarmFunctional = ItemStatus.No;
		private ItemStatus	m_instrPartsMissing = ItemStatus.No;
		private ItemStatus	m_instrPartsAvailable = ItemStatus.No;
		private ItemStatus	m_instrSpareCapacity = ItemStatus.No;
		private ItemStatus	m_elecExcessiveCorrosion = ItemStatus.No;
		private ItemStatus	m_elecCleanContacts = ItemStatus.No;
		private ItemStatus	m_elecPartsAvailable = ItemStatus.No;
		private ItemStatus	m_elecSpareCapacity = ItemStatus.No;
		private ItemStatus	m_pipeExcessiveCorrosion = ItemStatus.No;
		private ItemStatus	m_pipeExcessiveLeaks = ItemStatus.No;
		private ItemStatus	m_pipePaintGood = ItemStatus.No;
		private DateTime	m_dateInspected = DateTime.Now.Date;
		private string		m_equipmentNumber = "";
		private string		m_assessedBy = "";
		private string		m_manufacturer = "";
		private string		m_runHours = "";
		private string		m_photoCaption = "";
		private string		m_comments = "";
		private bool		m_runningAtInspect = false;
		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		public				Discipline1(int id)
			: base(WAMSource.CurrentSource.ConnectionString, id)
		{
		}

		public				Discipline1(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		protected			Discipline1(System.Data.OleDb.OleDbDataReader reader)
			: base(reader)
		{
		}

		protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_mechExcessiveVibration = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveNoise = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_mechRunningHot = (ItemStatus)reader.GetByte(col++);
			m_mechCanRunWhenInspected = (ItemStatus)reader.GetByte(col++);
			m_mechSupportIsFunctional = (ItemStatus)reader.GetByte(col++);
			m_mechPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_mechPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_mechAdequate = (ItemStatus)reader.GetByte(col++);
			m_mechMotorAmps = (ItemStatus)reader.GetByte(col++);
			m_instrIndicationFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrAlarmFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_instrPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_instrSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_elecExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_elecCleanContacts = (ItemStatus)reader.GetByte(col++);
			m_elecPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_elecSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_pipePaintGood = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);
			m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_runningAtInspect = reader.GetBoolean(col++);
		}
		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc1_id, component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");
			builder.Append("disc1_photoCaption, disc1_comments, disc1_runningAtInspect ");
			builder.Append("FROM Discipline1 ");
			builder.AppendFormat("WHERE component_id={0}", id);

			return builder.ToString();
		}

		protected override string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO Discipline1 (");

			builder.Append("component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");
			builder.Append("disc1_photoCaption, disc1_comments, disc1_runningAtInspect ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("{0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("{0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("{0}, ", m_orgUsefulLife);
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveVibration));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveNoise));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveLeaks));
			builder.AppendFormat("{0}, ", ((byte)m_mechRunningHot));
			builder.AppendFormat("{0}, ", ((byte)m_mechCanRunWhenInspected));
			builder.AppendFormat("{0}, ", ((byte)m_mechSupportIsFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_mechPartsMissing));
			builder.AppendFormat("{0}, ", ((byte)m_mechPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_mechAdequate));
			builder.AppendFormat("{0}, ", ((byte)m_mechMotorAmps));
			builder.AppendFormat("{0}, ", ((byte)m_instrIndicationFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_instrAlarmFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_instrPartsMissing));
			builder.AppendFormat("{0}, ", ((byte)m_instrPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_instrSpareCapacity));
			builder.AppendFormat("{0}, ", ((byte)m_elecExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_elecCleanContacts));
			builder.AppendFormat("{0}, ", ((byte)m_elecPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_elecSpareCapacity));
			builder.AppendFormat("{0}, ", ((byte)m_pipeExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_pipeExcessiveLeaks));
			builder.AppendFormat("{0}, ", ((byte)m_pipePaintGood));
			builder.AppendFormat("'{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_runHours));
			builder.AppendFormat("{0}, ", m_installationYear);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0} ", Drive.SQL.JetBoolToBit(m_runningAtInspect));
			builder.Append(")");

			return builder.ToString();
		}

		protected override string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE Discipline1 SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("disc1_conditionRanking={0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("disc1_CWPAssetValue={0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("disc1_originalUsefulLife={0}, ", m_orgUsefulLife);
			builder.AppendFormat("disc1_mechExcessiveVibration={0}, ", ((byte)m_mechExcessiveVibration));
			builder.AppendFormat("disc1_mechExcessiveNoise={0}, ", ((byte)m_mechExcessiveNoise));
			builder.AppendFormat("disc1_mechExcessiveCorrosion={0}, ", ((byte)m_mechExcessiveCorrosion));
			builder.AppendFormat("disc1_mechExcessiveLeaks={0}, ", ((byte)m_mechExcessiveLeaks));
			builder.AppendFormat("disc1_mechRunningHot={0}, ", ((byte)m_mechRunningHot));
			builder.AppendFormat("disc1_mechCanRunWhenInspected={0}, ", ((byte)m_mechCanRunWhenInspected));
			builder.AppendFormat("disc1_mechSupportIsFunctional={0}, ", ((byte)m_mechSupportIsFunctional));
			builder.AppendFormat("disc1_mechPartsMissing={0}, ", ((byte)m_mechPartsMissing));
			builder.AppendFormat("disc1_mechPartsAvailable={0}, ", ((byte)m_mechPartsAvailable));
			builder.AppendFormat("disc1_mechAdequate={0}, ", ((byte)m_mechAdequate));
			builder.AppendFormat("disc1_mechMotorAmps={0}, ", ((byte)m_mechMotorAmps));
			builder.AppendFormat("disc1_instrIndicationFunctional={0}, ", ((byte)m_instrIndicationFunctional));
			builder.AppendFormat("disc1_instrAlarmFunctional={0}, ", ((byte)m_instrAlarmFunctional));
			builder.AppendFormat("disc1_instrPartsMissing={0}, ", ((byte)m_instrPartsMissing));
			builder.AppendFormat("disc1_instrPartsAvailable={0}, ", ((byte)m_instrPartsAvailable));
			builder.AppendFormat("disc1_instrSpareCapacity={0}, ", ((byte)m_instrSpareCapacity));
			builder.AppendFormat("disc1_elecExcessiveCorrosion={0}, ", ((byte)m_elecExcessiveCorrosion));
			builder.AppendFormat("disc1_elecCleanContacts={0}, ", ((byte)m_elecCleanContacts));
			builder.AppendFormat("disc1_elecPartsAvailable={0}, ", ((byte)m_elecPartsAvailable));
			builder.AppendFormat("disc1_elecSpareCapacity={0}, ", ((byte)m_elecSpareCapacity));
			builder.AppendFormat("disc1_pipeExcessiveCorrosion={0}, ", ((byte)m_pipeExcessiveCorrosion));
			builder.AppendFormat("disc1_pipeExcessiveLeaks={0}, ", ((byte)m_pipeExcessiveLeaks));
			builder.AppendFormat("disc1_pipePaintGood={0}, ", ((byte)m_pipePaintGood));
			builder.AppendFormat("disc1_dateInspected='{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("disc1_assessedBy='{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("disc1_equipmentNumber='{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("disc1_manufacturer='{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("disc1_runHours={0}, ", m_runHours);
			builder.AppendFormat("disc1_installationYear={0}, ", m_installationYear);
			builder.AppendFormat("disc1_photoCaption={0}, ", Drive.SQL.StringToDBString(m_photoCaption));
			builder.AppendFormat("disc1_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("disc1_runningAtInspect={0} ", Drive.SQL.JetBoolToBit(m_runningAtInspect));

			builder.AppendFormat("WHERE (component_id={0}) ", ID);
			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From Discipline1 WHERE component_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public override string Name
		{
			get { return "Mechanical / Electrical / Instrumentation / Piping"; }
		}

		public ItemStatus	MechExcessiveVibration
		{
			get { return m_mechExcessiveVibration; }
			set { m_mechExcessiveVibration = value; }
		}

		public ItemStatus	MechExcessiveNoise
		{
			get { return m_mechExcessiveNoise; }
			set { m_mechExcessiveNoise = value; }
		}

		public ItemStatus	MechExcessiveCorrosion
		{
			get { return m_mechExcessiveCorrosion; }
			set { m_mechExcessiveCorrosion = value; }
		}

		public ItemStatus	MechExcessiveLeaks
		{
			get { return m_mechExcessiveLeaks; }
			set { m_mechExcessiveLeaks = value; }
		}

		public ItemStatus	MechRunningHot
		{
			get { return m_mechRunningHot; }
			set { m_mechRunningHot = value; }
		}

		public ItemStatus	MechCanRunWhenInspected
		{
			get { return m_mechCanRunWhenInspected; }
			set { m_mechCanRunWhenInspected = value; }
		}

		public ItemStatus	MechSupportIsFunctional
		{
			get { return m_mechSupportIsFunctional; }
			set { m_mechSupportIsFunctional = value; }
		}

		public ItemStatus	MechPartsMissing
		{
			get { return m_mechPartsMissing; }
			set { m_mechPartsMissing = value; }
		}

		public ItemStatus	MechPartsAvailable
		{
			get { return m_mechPartsAvailable; }
			set { m_mechPartsAvailable = value; }
		}

		public ItemStatus	MechAdequate
		{
			get { return m_mechAdequate; }
			set { m_mechAdequate = value; }
		}

		public ItemStatus	MechMotorAmps
		{
			get { return m_mechMotorAmps; }
			set { m_mechMotorAmps = value; }
		}

		public ItemStatus	InstrIndicationFunctional
		{
			get { return m_instrIndicationFunctional; }
			set { m_instrIndicationFunctional = value; }
		}

		public ItemStatus	InstrAlarmFunctional
		{
			get { return m_instrAlarmFunctional; }
			set { m_instrAlarmFunctional = value; }
		}

		public ItemStatus	InstrPartsMissing
		{
			get { return m_instrPartsMissing; }
			set { m_instrPartsMissing = value; }
		}

		public ItemStatus	InstrPartsAvailable
		{
			get { return m_instrPartsAvailable; }
			set { m_instrPartsAvailable = value; }
		}

		public ItemStatus	InstrSpareCapacity
		{
			get { return m_instrSpareCapacity; }
			set { m_instrSpareCapacity = value; }
		}

		public ItemStatus	ElecExcessiveCorrosion
		{
			get { return m_elecExcessiveCorrosion; }
			set { m_elecExcessiveCorrosion = value; }
		}

		public ItemStatus	ElecCleanContacts
		{
			get { return m_elecCleanContacts; }
			set { m_elecCleanContacts = value; }
		}

		public ItemStatus	ElecPartsAvailable
		{
			get { return m_elecPartsAvailable; }
			set { m_elecPartsAvailable = value; }
		}

		public ItemStatus	ElecSpareCapacity
		{
			get { return m_elecSpareCapacity; }
			set { m_elecSpareCapacity = value; }
		}

		public ItemStatus	PipeExcessiveCorrosion
		{
			get { return m_pipeExcessiveCorrosion; }
			set { m_pipeExcessiveCorrosion = value; }
		}

		public ItemStatus	PipeExcessiveLeaks
		{
			get { return m_pipeExcessiveLeaks; }
			set { m_pipeExcessiveLeaks = value; }
		}

		public ItemStatus	PipePaintGood
		{
			get { return m_pipePaintGood; }
			set { m_pipePaintGood = value; }
		}

		public DateTime		DateInspected
		{
			get { return m_dateInspected; }
			set { m_dateInspected = value; }
		}

		public string		EquipmentNumber
		{
			get { return m_equipmentNumber; }
			set
			{
				if (value.Length > 255)
					m_equipmentNumber = value.Substring(255);
				else
					m_equipmentNumber = value;
			}
		}

		public string		AssessedBy
		{
			get { return m_assessedBy; }
			set
			{
				if (value.Length > 255)
					m_assessedBy = value.Substring(255);
				else
					m_assessedBy = value;
			}
		}

		public string		Manufacturer
		{
			get { return m_manufacturer; }
			set
			{
				if (value.Length > 255)
					m_manufacturer = value.Substring(255);
				else
					m_manufacturer = value;
			}
		}

		public string		RunHours
		{
			get { return m_runHours; }
			set
			{
				if (value.Length > 255)
					m_runHours = value.Substring(255);
				else
					m_runHours = value;
			}
		}

		public string		CaptionPhoto
		{
			get { return m_photoCaption; }
			set
			{
				if (value.Length > 255)
					m_photoCaption = value.Substring(255);
				else
					m_photoCaption = value;
			}
		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public bool			RunningAtInspect
		{
			get { return m_runningAtInspect; }
			set { m_runningAtInspect = value; }
		}
		#endregion /***** Properties *****/

		#region /***** Static Methods *****/
		public static Discipline1 LoadForComponent(int componentID)
		{
			return LoadForComponent(WAMSource.CurrentSource.ConnectionString, componentID);
		}

		public static Discipline1 LoadForComponent(string connectionString, int componentID)
		{
			OleDbConnection	sqlConnection = 
				new OleDbConnection(connectionString);
			Discipline1 retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponent(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		public static Discipline1 LoadForComponent(OleDbConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info
			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			Discipline1		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc1_id, component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");
			builder.Append("disc1_photoCaption, disc1_comments, disc1_runningAtInspect ");
			builder.Append("FROM Discipline1 ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), 
					sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
					newObject = new Discipline1(dataReader);
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Discipline1.LoadForComponent Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				newObject = new Discipline1(0);
				newObject.ComponentID = componentID;
			}
			
			return newObject;
		}
		#endregion /***** Static Methods *****/
	}
}
