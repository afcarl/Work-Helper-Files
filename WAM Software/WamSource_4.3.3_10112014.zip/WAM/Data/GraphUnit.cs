using System;
using System.Collections;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for IGraphableUnit.
	/// </summary>
	/// 

	public interface		IGraphableUnit
	{
		string				GetFullName();
		string				GetShortName();
		decimal				GetYAxisValue(GraphYAxis yAxis);
		int					GetYearValue();

		//mam - need a way to compare units (currently the comparison is performed using the unit name,
		//	but this is unreliable when units have the same name, as when selected units come from different
		//	infosets
		int GetItemID();
		//</mam>

		//mam - need a way to get only the pipes, or only the nodes, because the graph is showing
		//	both pipes and nodes when the user has selected either pipes only or nodes only
		decimal GetYAxisValue(GraphYAxis yAxis, bool pipesOnly, bool nodesOnly);
		//</mam>

		//mam
		string GetFullNameWithInfoset();
		//</mam>

		//mam 090105
		int GetFacilityID();
		string GetParentName();
		//</mam>

		//mam 050806
		int GetInspectionYear();
		int GetInfosetID();
		int GetParentID();
		int GetGrandparentID();
		object GetUnitType();
	}

	public class GraphableUnitComparer : IComparer
	{
		public GraphableUnitComparer()
		{
		}

		#region IComparer Members

		public int Compare(object x, object y)
		{
			IGraphableUnit	lhs = x as IGraphableUnit;
			IGraphableUnit	rhs = y as IGraphableUnit;

			if (lhs == null || rhs == null)
				throw new ArgumentException("Not an IGraphableUnit object!");

			return string.Compare(lhs.GetFullName(), rhs.GetFullName(), true);
		}

		#endregion

		public static IComparer GetComparer()
		{
			return (IComparer)new GraphableUnitComparer();
		}
	}

	public class GraphableUnitComparerByID : IComparer
	{
		public GraphableUnitComparerByID()
		{
		}

		#region IComparer Members

		public int Compare(object x, object y)
		{
//			IGraphableUnit	lhs = x as IGraphableUnit;
//			IGraphableUnit	rhs = y as IGraphableUnit;
//
//			if (lhs == null || rhs == null)
//				throw new ArgumentException("Not an IGraphableUnit object!");
//
//			//return string.Compare(lhs.GetItemID(), rhs.GetItemID());
//			return lhs.GetItemID().CompareTo(rhs.GetItemID());

			GraphUnit lhs = x as GraphUnit;
			GraphUnit rhs = y as GraphUnit;

			if (lhs == null || rhs == null)
				throw new ArgumentException("Not a GraphUnit object!");

			//return string.Compare(lhs.GetItemID(), rhs.GetItemID());
			return lhs.UnitID.CompareTo(rhs.UnitID);
		}
		//</mam>

		#endregion

		public static IComparer GetComparer()
		{
			return (IComparer)new GraphableUnitComparerByID();
		}
	}

	public class GraphableUnitComparerByYear : IComparer
	{
		//SortByYearType sortBy = SortByYearType.FacilityYear;

		//public GraphableUnitComparerByYear(SortByYearType sortBy)
		public GraphableUnitComparerByYear()
		{
			//this.sortBy = sortBy;
		}

		#region IComparer Members

		//public int CompareGraphItemByYear(object x, object y, SortByYearType sortBy)
		//{
		//	return Compare(x, y);
		//}

		public int Compare(object x, object y)
		{
			GraphUnit lhs = x as GraphUnit;
			GraphUnit rhs = y as GraphUnit;

			if (lhs == null || rhs == null)
				throw new ArgumentException("Not a GraphUnit object!");

			if (lhs.UnitType.Equals(WAM.UI.NodeType.Facility))
			{
				if (lhs.InfosetID == rhs.InfosetID || lhs.FacilityID == rhs.FacilityID)
				{
					return 0;
				}
				return lhs.FacilityYear.CompareTo(rhs.FacilityYear);
			}
			else if (lhs.UnitType.Equals(WAM.UI.NodeType.TreatmentProcess))
			{
				if (lhs.InfosetID == rhs.InfosetID || lhs.FacilityID == rhs.FacilityID)
				{
					return 0;
				}
				return lhs.FacilityYear.CompareTo(rhs.FacilityYear);
			}
			else if (lhs.UnitType.Equals(WAM.UI.NodeType.MajorComponent))
			{
				if (lhs.InfosetID == rhs.InfosetID || lhs.FacilityID == rhs.FacilityID || lhs.ParentID == rhs.ParentID)
				{
					return 0;
				}
				return lhs.InspectionYear.CompareTo(rhs.InspectionYear);
			}
			else
			{
				if (lhs.InfosetID == rhs.InfosetID || lhs.FacilityID == rhs.FacilityID 
					|| lhs.ParentID == rhs.ParentID || lhs.GrandParentID == rhs.GrandParentID)
				{
					return 0;
				}
				return lhs.InspectionYear.CompareTo(rhs.InspectionYear);
			}

//			//if (sortBy.Equals(SortByYearType.FacilityYear))
//			if (lhs == typeof(Facility) || lhs == typeof(TreatmentProcess))
//			{
//				return lhs.FacilityYear.CompareTo(rhs.FacilityYear);
//			}
//			//else if (sortBy.Equals(SortByYearType.InspectionYear))
//			else
//			{
//				return lhs.InspectionYear.CompareTo(rhs.InspectionYear);
//			}
//
//			return 0;

			//int test = lhs.FacilityYear.CompareTo(rhs.FacilityYear);
			//System.Windows.Forms.MessageBox.Show(lhs.FacilityYear.ToString() + ", " + rhs.FacilityYear.ToString()
			//	+ "; " + test.ToString());
			//return test;
			
		}
		//</mam>

		#endregion

		public static IComparer GetComparer()
		{
			return (IComparer)new GraphableUnitComparerByYear();
		}
	}

	public class GraphUnit : IComparable
	{
		private string		m_name;
		private string		m_shortName = "";
		private ArrayList	m_units = null;

		//mam
		private int m_unitID;
		private string m_nameWithInfoset;
		//</mam>

		//mam 090105
		private int m_facilityID;
		private int m_facilityYear;
		private string m_parentName;
		private string m_graphID;
		//</mam>

		//mam 050806
		private int inspectionYear;
		private int infosetID = 0;
		private int parentID = 0;
		private int grandparentID = 0;
		private object unitType = WAM.UI.NodeType.Facility;

		public				GraphUnit(string name, string nameWithInfoset)
		{
			m_name = name;

			//mam 090105
			m_nameWithInfoset = nameWithInfoset;
			//</mam>
		}

		//mam
//		public GraphUnit(int id, string name, string nameWithInfoset)
//		{
//			m_unitID = id;
//			m_name = name;
//			m_nameWithInfoset = nameWithInfoset;
//		}
		//</mam>

		//mam 090105
		//public GraphUnit(int id, string name, string nameWithInfoset, int facilityID, int facilityYear, string parentName)
		//mam 050806 - add inspection year
		public GraphUnit(int id, string name, string nameWithInfoset, int facilityID, int facilityYear, 
			string parentName, int inspectionYear, int infosetID, int parentID, int grandparentID, object unitType)
		{
			m_unitID = id;
			m_name = name;
			m_nameWithInfoset = nameWithInfoset;
			m_facilityID = facilityID;
			m_facilityYear = facilityYear;
			m_parentName = parentName;

			//mam 050806
			this.inspectionYear = inspectionYear;
			this.infosetID = parentID;
			this.parentID = parentID;
			this.grandparentID = grandparentID;
			this.unitType = unitType;
		}
		//</mam>

		public string		Name
		{
			get { return m_name; }
		}

		public string		ShortName
		{
			get { return m_shortName; }
		}

		//mam
		public string		NameWithInfoset
		{
			get { return m_nameWithInfoset; }
		}
		//</mam>

		//mam
		public int UnitID
		{
			get { return m_unitID; }
		}
		//</mam>

		//mam 090105
		public int FacilityID
		{
			get { return m_facilityID; }
		}
		public int FacilityYear
		{
			get { return m_facilityYear; }
		}

		//mam 050806
		public int InspectionYear
		{
			get { return inspectionYear; }
		}

		public string ParentName
		{
			get { return m_parentName; }
		}
		public string GraphID
		{
			get { return m_graphID; }
			set { m_graphID = value; }
		}
		//</mam>

		//mam 050806
		public int ParentID
		{
			get { return parentID; }
		}

		//mam 050806
		public int GrandParentID
		{
			get { return grandparentID; }
		}

		//mam 050806
		public int InfosetID
		{
			get { return infosetID; }
		}

		//mam 050806
		public object UnitType
		{
			get { return unitType; }
		}

		public bool			UnitMatches(string compName)
		{
			return string.Compare(m_name, compName) == 0;
		}

		public void			AddUnit(IGraphableUnit unit)
		{
			if (m_units == null)
				m_units = new ArrayList();

			m_units.Add(unit);
			if (m_shortName.Length == 0)
				m_shortName = unit.GetShortName();
		}

		public int			Count
		{
			get
			{
				if (m_units == null)
					return 0;

				return m_units.Count;
			}
		}

		public IGraphableUnit this[int unitPos]
		{
			get
			{
				if (m_units == null)
					return null;

				return (IGraphableUnit)m_units[unitPos];
			}
		}

		#region IComparable Members
		public int CompareTo(object obj)
		{
			GraphUnit unit = obj as GraphUnit;
			if (unit != null)
				return string.Compare(m_name, unit.m_name);

			return 0;
		}

		#endregion

		#region IList Members

//		public bool IsReadOnly
//		{
//			get
//			{
//				// TODO:  Add GraphUnit.IsReadOnly getter implementation
//				return false;
//			}
//		}
//
//		object System.Collections.IList.this[int index]
//		{
//			get
//			{
//				// TODO:  Add GraphUnit.System.Collections.IList.this getter implementation
//				return null;
//			}
//			set
//			{
//				// TODO:  Add GraphUnit.System.Collections.IList.this setter implementation
//			}
//		}
//
//		public void RemoveAt(int index)
//		{
//			// TODO:  Add GraphUnit.RemoveAt implementation
//		}
//
//		public void Insert(int index, object value)
//		{
//			// TODO:  Add GraphUnit.Insert implementation
//		}
//
//		public void Remove(object value)
//		{
//			// TODO:  Add GraphUnit.Remove implementation
//		}
//
//		public bool Contains(object value)
//		{
//			// TODO:  Add GraphUnit.Contains implementation
//			return false;
//		}
//
//		public void Clear()
//		{
//			// TODO:  Add GraphUnit.Clear implementation
//		}
//
//		public int IndexOf(object value)
//		{
//			// TODO:  Add GraphUnit.IndexOf implementation
//			return 0;
//		}
//
//		public int Add(object value)
//		{
//			// TODO:  Add GraphUnit.Add implementation
//			return 0;
//		}
//
//		public bool IsFixedSize
//		{
//			get
//			{
//				// TODO:  Add GraphUnit.IsFixedSize getter implementation
//				return false;
//			}
//		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				// TODO:  Add GraphUnit.IsSynchronized getter implementation
				return false;
			}
		}

		public void CopyTo(Array array, int index)
		{
			// TODO:  Add GraphUnit.CopyTo implementation
		}

		public object SyncRoot
		{
			get
			{
				// TODO:  Add GraphUnit.SyncRoot getter implementation
				return null;
			}
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			// TODO:  Add GraphUnit.GetEnumerator implementation
			return null;
		}

		#endregion
	}

	public class GraphUnitManager
	{
		private ArrayList	m_graphUnits = new ArrayList();
		private IComparer	m_comparer = GraphableUnitComparer.GetComparer();

		public GraphUnitManager()
		{
		}

		public void			AddUnit(IGraphableUnit unit)
		{
			// sanity check
			if (unit == null)
				return;
			
			//System.Windows.Forms.MessageBox.Show(unit.GetType().ToString());
	
			//mam - compare using IDs rather than names, because there could be two units with the same name
			//GraphUnit	selectUnit = new GraphUnit(unit.GetFullName());
			//GraphUnit selectUnit = new GraphUnit(unit.GetItemID(), unit.GetFullName(), unit.GetFullNameWithInfoset());

			//mam 090105
			GraphUnit selectUnit = new GraphUnit(unit.GetItemID(), unit.GetFullName(), unit.GetFullNameWithInfoset(),
				unit.GetFacilityID(), unit.GetYearValue(), unit.GetParentName(), unit.GetInspectionYear(), 
				unit.GetInfosetID(), unit.GetParentID(), unit.GetGrandparentID(), unit.GetUnitType());
			//</mam>

			GraphableUnitComparerByID unitComparerByID = new GraphableUnitComparerByID();

			// Perform a binary search to determine if it already exists
			//int findPos = m_graphUnits.BinarySearch(selectUnit);
			int findPos = m_graphUnits.BinarySearch(selectUnit, unitComparerByID);
			//</mam>

			if (findPos < 0)
			{
				// Perform a binary insert
				selectUnit.AddUnit(unit);

				//mam 050806
				//the call to BinaryInsertArrayList causes items to be added out of tree order - just
				//	add the items to the array in the order they come in (which is tree order)
				//Drive.Collections.Util.BinaryInsertArrayList(m_graphUnits, selectUnit);
				m_graphUnits.Add(selectUnit);
			}
			else
			{
				selectUnit = (GraphUnit)m_graphUnits[findPos];
				selectUnit.AddUnit(unit);
			}

			//mam 050806 - put graph items in order by Facility Year or Inspection Year
			//SortByYearType sortBy = SortByYearType.InspectionYear;
			//if (unit.GetType() == typeof(WAM.Data.Facility) || unit.GetType() == typeof(WAM.Data.TreatmentProcess))
			//{
			//	sortBy = SortByYearType.FacilityYear;
			//}

			GraphableUnitComparerByYear unitComparerByYear = new GraphableUnitComparerByYear();
			m_graphUnits.Sort(unitComparerByYear);
		}

		//mam - new method to force the addition of the graphable unit to the array
		public void			AddUnitForceAddition(IGraphableUnit unit)
		{
			//mam - Now that we have the DisciplineAll selection for graphs, checking the ID isn't sufficient, as different
			//	discipline types are stored in different tables, which means that two disciplines (of different types)
			//	could have the same ID.
			//There is no way that an item could be added to the list of graphable items twice, because the source is the
			//	treeview, which has a checkbox for each item.  Since there can be no duplication, don't check whether the
			//	item has been added, just go ahead and add it.
			//</mam>

			// sanity check
			if (unit == null)
				return;

			//mam - compare using IDs rather than names, because there could be two units with the same name
			//GraphUnit	selectUnit = new GraphUnit(unit.GetFullName());
			//GraphUnit selectUnit = new GraphUnit(unit.GetItemID(), unit.GetFullName(), unit.GetFullNameWithInfoset());

			//mam 090105
			GraphUnit selectUnit = new GraphUnit(unit.GetItemID(), unit.GetFullName(), unit.GetFullNameWithInfoset(),
				unit.GetFacilityID(), unit.GetYearValue(), unit.GetParentName(), unit.GetInspectionYear(), 
				unit.GetInfosetID(), unit.GetParentID(), unit.GetGrandparentID(), unit.GetUnitType());
			//</mam>

			GraphableUnitComparerByID unitComparerByID = new GraphableUnitComparerByID();

			//mam - don't bother with the search, as discussed above
//			// Perform a binary search to determine if it already exists
//			//int findPos = m_graphUnits.BinarySearch(selectUnit);
//			int findPos = m_graphUnits.BinarySearch(selectUnit, unitComparerByID);
//			//</mam>
//
//			if (findPos < 0)
//			{
				// Perform a binary insert
				selectUnit.AddUnit(unit);

				//mam 050806
				//the call to BinaryInsertArrayList causes items to be added out of tree order - just
				//	add the items to the array in the order they come in (which is tree order)
				//Drive.Collections.Util.BinaryInsertArrayList(m_graphUnits, selectUnit);
				m_graphUnits.Add(selectUnit);
//			}
//			else
//			{
//				selectUnit = (GraphUnit)m_graphUnits[findPos];
//				selectUnit.AddUnit(unit);
//			}
			//</mam>
		}
		//</mam>

		public GraphUnit this[int pos]
		{
			get { return m_graphUnits[pos] as GraphUnit; }
		}

		public void			Clear()
		{
			m_graphUnits.Clear();
		}

		public int			Count
		{
			get { return m_graphUnits.Count; }
		}

		public GraphUnit[]	Units
		{
			get
			{
				GraphUnit[] units = new GraphUnit[m_graphUnits.Count];
				m_graphUnits.CopyTo(units);
				return units;
			}
		}
		#region IList Members

//		public bool IsReadOnly
//		{
//			get
//			{
//				// TODO:  Add GraphUnitManager.IsReadOnly getter implementation
//				return false;
//			}
//		}
//
//		object System.Collections.IList.this[int index]
//		{
//			get
//			{
//				// TODO:  Add GraphUnitManager.System.Collections.IList.this getter implementation
//				return null;
//			}
//			set
//			{
//				// TODO:  Add GraphUnitManager.System.Collections.IList.this setter implementation
//			}
//		}
//
//		public void RemoveAt(int index)
//		{
//			// TODO:  Add GraphUnitManager.RemoveAt implementation
//		}
//
//		public void Insert(int index, object value)
//		{
//			// TODO:  Add GraphUnitManager.Insert implementation
//		}
//
//		public void Remove(object value)
//		{
//			// TODO:  Add GraphUnitManager.Remove implementation
//		}
//
//		public bool Contains(object value)
//		{
//			// TODO:  Add GraphUnitManager.Contains implementation
//			return false;
//		}
//
//		public int IndexOf(object value)
//		{
//			// TODO:  Add GraphUnitManager.IndexOf implementation
//			return 0;
//		}
//
//		public int Add(object value)
//		{
//			// TODO:  Add GraphUnitManager.Add implementation
//			return 0;
//		}
//
//		public bool IsFixedSize
//		{
//			get
//			{
//				// TODO:  Add GraphUnitManager.IsFixedSize getter implementation
//				return false;
//			}
//		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized
		{
			get
			{
				// TODO:  Add GraphUnitManager.IsSynchronized getter implementation
				return false;
			}
		}

		public void CopyTo(Array array, int index)
		{
			// TODO:  Add GraphUnitManager.CopyTo implementation
		}

		public object SyncRoot
		{
			get
			{
				// TODO:  Add GraphUnitManager.SyncRoot getter implementation
				return null;
			}
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			// TODO:  Add GraphUnitManager.GetEnumerator implementation
			return null;
		}

		#endregion
	}
}