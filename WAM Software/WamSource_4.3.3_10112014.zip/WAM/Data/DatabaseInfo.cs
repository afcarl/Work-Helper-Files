using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;

namespace WAM.Data
{
	//mam - store database info here

	/// <summary>
	/// Summary description for InfoSet.
	/// </summary>
	public class DatabaseInfo : Drive.Data.OleDb.Jet40DALInt32Key
	{
		private string m_databaseImageFolder = "";

		#region /***** Construction *****/

		public DatabaseInfo(string imageFolder)
		{
			m_databaseImageFolder = imageFolder;
		}

		#endregion /***** Construction *****/

		#region /***** Methods *****/


		#endregion /***** Methods *****/

		#region /***** Properties *****/

		public string DatabaseImageFolder
		{
			get { return m_databaseImageFolder; }
			set { m_databaseImageFolder = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Static Methods *****/

		private static string databaseImageFolder = "";

		public static string DatabaseImageFolderName
		{
			get
			{
				return databaseImageFolder;
			}
			set
			{
				databaseImageFolder = value;
			}
		}

		#endregion /***** Static Methods *****/
	}
}
