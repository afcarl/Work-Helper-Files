using System;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for IFilterable.
	/// </summary>
	public interface IFilterable
	{
		decimal				GetLHValue(WAM.Logic.UnitFilter.FilterSource source);
		decimal				GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo);

		bool				IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source);
		bool				IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo);

		//mam 07072011
		string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source);
		//string GetRHValueString(WAM.Logic.UnitFilter.FilterCompareTo compareTo);
		bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source);
		//bool IsRHValueStringValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo);

	}
}
