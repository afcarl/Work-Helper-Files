using System;

//mam 07072011
using System.Collections;

namespace WAM.Data
{
	#region /***** Enumerations *****/

	public enum	ItemStatus : byte
	{
		Yes,
		No,
		NotApplicable
	}

	public enum CondRank : byte
	{
		C0 = 0,
		C1,
		C2,
		C3,
		C4,
		C5,
		No = 0xFF
	}

	public enum LevelOfService : byte
	{
		LOS0 = 0,
		LOS1,
		LOS2,
		LOS3,
		LOS4,
		LOS5,
	}

	public enum Vulnerability : byte
	{
		FailureLikely1,
		FailureLikely2,
		FailureLikely3,
		FailureLikely5,
		FailureLikely10,
		FailureLikely20,
		FailureLikely50,
		FailureLikely100,
		FailureLikely150,
	}

	//mam 07072011 - no longer using four fixed crits
//	public enum CriticalityPublicHealth : byte
//	{
//		MultipleIllness,
//		Seasonal,
//		SingleIllness,
//		NoEffect
//	}

	//mam 07072011 - no longer using four fixed crits
//	public enum CriticalityEnvironmental : byte
//	{
//		Major,
//		Minor,
//		NoEffect,
//	}

	//mam 07072011 - no longer using four fixed crits
//	public enum CriticalityRepairCost : byte
//	{
//		MoreThan100k,
//		Between30kAnd100k,
//		Between5kAnd30k,
//		LessThan5k,
//	}

	//mam 07072011 - no longer using four fixed crits
//	public enum CriticalityCustomerEffect : byte
//	{
//		Major,
//		Minor,
//		NoEffect,
//	}

	public enum				GraphYAxis
	{
		AcquisitionCost,
		CurrentValue,
		ReplacementValue,
		BookValue,
		SalvageValue,
		AnnualDepreciation,
		CumulativeDepreciation,
		EvaluatedValue,
		RepairCost,
		AnnualMaintenanceCost,

		//mam 050806
		AcquisitionCostEscalated,
		RehabCost,

		//mam 07072011 - allowed only for msc disciplines, and discipline all
		RehabInterval,
		RehabNext,
		//RehabYearLast,
		//RehabYearNext,

		//mam 090105
		OriginalUsefulLife,
		RemainingUsefulLife,
		EvaluatedRemainingUsefulLife,
		EconomicRemainingUsefulLife,

		// Only allow these options on components
		Vulnerability = 100,
		Criticality,
		Risk,
		LOS,
		Condition,

		ConditionAndLOS = 200,
	}

	//mam
	public enum GlobalUpdate
	{
		//mam 050806
		AcquisitionCost,

		//mam 112806
		CurrentValue,

		//mam 090105 - add new global update option for inspection date
		DateOfInspection,

		LevelOfService,

		//mam 112806
		RepairCost,

		//mam 112806 - remove ReplacementValue global update
		//ReplacementValue,

		//mam 050806
		ReplacementValueYear,
	}
	//</mam>

	//mam
	public enum			ReportFormat
	{
		Standard = 0,
		Matrix = 1
	}
	//</mam>

	//mam 01222012
	public enum PlanningMode
	{
		Rehabilitation,
		Replacement,
	}

	#endregion /***** Enumerations *****/

	public class			EnumHandlers
	{
		//mam
		#region /***** Global Update *****/

		public static string GetGlobalUpdateString(GlobalUpdate rank)
		{
			switch (rank)
			{
				case GlobalUpdate.LevelOfService:
					return "Level of Service";

					//mam 112806 - remove ReplacementValue global update
					//case GlobalUpdate.ReplacementValue:
					//	return "Replacement Value";

					//mam 090105 - add new global update option
				case GlobalUpdate.DateOfInspection:
					return "Date of Inspection";

					//mam 050806
				case GlobalUpdate.ReplacementValueYear:
					return "Replacement Value Year";

					//mam 050806
				case GlobalUpdate.AcquisitionCost:
					return "Acquisition Cost";

					//mam 112806
				case GlobalUpdate.CurrentValue:
					return "Current Value";

					//mam 112806
				case GlobalUpdate.RepairCost:
					return "Repair Cost";
			}

			return "";
		}

		#endregion /***** Global Update *****/
		//</mam>

		//mam
		#region /***** Report Format *****/

		public static string GetReportFormatString(ReportFormat rank)
		{
			switch (rank)
			{
				case ReportFormat.Standard:
					return "Detail";
				case ReportFormat.Matrix:
					return "Summary";
			}

			return "N/A";
		}

		#endregion /***** Report Format *****/
		//</mam>

		#region /***** Condition Ranking *****/

		public static decimal GetConditionRankValue(CondRank rank)
		{
			switch (rank)
			{
				case CondRank.C0:
				case CondRank.C1:
				case CondRank.No:
					return 0m;
				case CondRank.C2:
					return 0.047M;
				case CondRank.C3:
					return 0.153M;
				case CondRank.C4:
					return 0.304M;
				case CondRank.C5:
					return 0.496M;
			}

			return 0m;
		}

		//mam 051708 - new method to be used when calculating non-dollar values that involve condition
		//	(such as Remaining Useful Life)
		public static decimal GetConditionRankValueForUsefulLife(CondRank rank)
		{
			switch (rank)
			{
				case CondRank.C0:
				case CondRank.C1:
				case CondRank.No:
					return 0m;
				case CondRank.C2:
					return 0.10M;
				case CondRank.C3:
					return 0.20M;
				case CondRank.C4:
					return 0.40M;
				case CondRank.C5:
					return 0.90M;
			}

			return 0m;
		}

		public static string GetConditionRankString(CondRank rank)
		{
			//mam 050806 - added percentages to the text
			switch (rank)
			{
				case CondRank.C0:
					return "0 - Non-Existent";
				case CondRank.C1:
					return "1 - Very Good (0%)";
				case CondRank.C2:
					return "2 - Minor Defects (>0% to 10%)";
				case CondRank.C3:
					return "3 - Requires Significant Maintenance (11% to 20%)";
				case CondRank.C4:
					return "4 - Requires Rehabilitation (21% to 40%)";
				case CondRank.C5:
					return "5 - Requires Replacement (>=50%)";
			}

			//mam
			//original code:
			//return "N/A";
			//new code:
			return "N/A - Not Applicable";
			//</mam>
		}

		public static string GetConditionRankShort(CondRank rank)
		{
			switch (rank)
			{
				case CondRank.C0:
					return "0";
				case CondRank.C1:
					return "1";
				case CondRank.C2:
					return "2";
				case CondRank.C3:
					return "3";
				case CondRank.C4:
					return "4";
				case CondRank.C5:
					return "5";
			}

			return "N/A";
		}

		//mam 050806
		public static int GetConditionIndexFromSingleWord(string val)
		{
			switch (val.Trim().ToUpper())
			{
				case "0":
					return 0;
				case "1":
					return 1;
				case "2":
					return 2;
				case "3":
					return 3;
				case "4":
					return 4;
				case "5":
					return 5;
			}

			return -1;
		}

		//mam 050806
		public static CondRank GetConditionRankFromSingleWord(string val)
		{
			switch (val.Trim().ToUpper())
			{
				case "0":
					return CondRank.C0;
				case "1":
					return CondRank.C1;
				case "2":
					return CondRank.C2;
				case "3":
					return CondRank.C3;
				case "4":
					return CondRank.C4;
				case "5":
					return CondRank.C5;
			}

			return CondRank.No;
		}

		//mam 050806
		public static string GetConditionTextFromSingleWord(string val)
		{
			switch (val.Trim().ToUpper())
			{
				case "0":
					return GetConditionRankString(CondRank.C0);
				case "1":
					return GetConditionRankString(CondRank.C1);
				case "2":
					return GetConditionRankString(CondRank.C2);
				case "3":
					return GetConditionRankString(CondRank.C3);
				case "4":
					return GetConditionRankString(CondRank.C4);
				case "5":
					return GetConditionRankString(CondRank.C5);
			}

			return GetConditionRankString(CondRank.No);
		}

		#endregion /***** Condition Ranking *****/

		#region /***** Level of Service *****/
		public static double GetLOSValue(LevelOfService rank)
		{
			switch (rank)
			{
				case LevelOfService.LOS0:
				case LevelOfService.LOS1:
					return 0.0;
				case LevelOfService.LOS2:
					return 0.047;
				case LevelOfService.LOS3:
					return 0.153;
				case LevelOfService.LOS4:
					return 0.304;
				case LevelOfService.LOS5:
					return 0.496;
			}

			return 0.0;
		}

		public static string GetLOSString(LevelOfService rank)
		{
			switch (rank)
			{
				case LevelOfService.LOS0:
					return "0 - Non-Existent";
				case LevelOfService.LOS1:
					return "1 - Very Good";
				case LevelOfService.LOS2:
					return "2 - Minor Defects";
				case LevelOfService.LOS3:
					return "3 - Requires Significant Maintenance";
				case LevelOfService.LOS4:
					return "4 - Requires Rehabilitation";
				case LevelOfService.LOS5:
					return "5 - Requires Replacement";
					//mam 112806
					//return "5 - Requires Replacement (in excess of 50%)";
			}

			return "";
		}

		public static string GetLOSShort(LevelOfService rank)
		{
			switch (rank)
			{
				case LevelOfService.LOS0:
					return "0";
				case LevelOfService.LOS1:
					return "1";
				case LevelOfService.LOS2:
					return "2";
				case LevelOfService.LOS3:
					return "3";
				case LevelOfService.LOS4:
					return "4";
				case LevelOfService.LOS5:
					return "5";
			}

			return "";
		}

		//mam 050806
		public static int GetLOSIndexFromString(string val)
		{
			switch (val)
			{
				case "0 - Non-Existent":
					return 0;
				case "1 - Very Good":
					return 1;
				case "2 - Minor Defects":
					return 2;
				case "3 - Requires Significant Maintenance":
					return 3;
				case "4 - Requires Rehabilitation":
					return 4;
					//mam 112806
					//case "5 - Requires Replacement (in excess of 50%)":
				case "5 - Requires Replacement":
					return 5;
			}

			return 0;
		}

		//mam 050806
		public static LevelOfService GetLOSRank(int val)
		{
			switch (val)
			{
				case 0:
					return LevelOfService.LOS0;
				case 1:
					return LevelOfService.LOS1;
				case 2:
					return LevelOfService.LOS2;
				case 3:
					return LevelOfService.LOS3;
				case 4:
					return LevelOfService.LOS4;
				case 5:
					return LevelOfService.LOS5;
			}

			return LevelOfService.LOS0;
		}

		//mam 050806
		public static int GetLOSIndexFromSingleWord(string val)
		{
			switch (val.Trim().ToUpper())
			{
				case "0":
					return 0;
				case "1":
					return 1;
				case "2":
					return 2;
				case "3":
					return 3;
				case "4":
					return 4;
				case "5":
					return 5;
			}

			return -1;
		}

		//mam 050806
		public static string GetLOSTextFromSingleWord(string val)
		{
			switch (val.Trim().ToUpper())
			{
				case "0":
					return GetLOSString(LevelOfService.LOS0);
				case "1":
					return GetLOSString(LevelOfService.LOS1);
				case "2":
					return GetLOSString(LevelOfService.LOS2);
				case "3":
					return GetLOSString(LevelOfService.LOS3);
				case "4":
					return GetLOSString(LevelOfService.LOS4);
				case "5":
					return GetLOSString(LevelOfService.LOS5);
			}

			return string.Empty;
		}

		//mam 050806
		public static bool LOSIsValidValue(string val)
		{
			if (string.Compare(val, 
				GetLOSString(LevelOfService.LOS0), false) == 0)
				return true;
			else if (string.Compare(val,
				GetLOSString(LevelOfService.LOS1), false) == 0)
				return true;
			else if (string.Compare(val, 
				GetLOSString(LevelOfService.LOS2), false) == 0)
				return true;
			else if (string.Compare(val, 
				GetLOSString(LevelOfService.LOS3), false) == 0)
				return true;
			else if (string.Compare(val, 
				GetLOSString(LevelOfService.LOS4), false) == 0)
				return true;
			else if (string.Compare(val, 
				GetLOSString(LevelOfService.LOS5), false) == 0)
				return true;

			return false;
		}

		#endregion /***** Level of Service *****/

		#region /***** Vulnerability *****/
		public static double GetVulnerabilityValue(Vulnerability rank)
		{
			switch (rank)
			{
				case Vulnerability.FailureLikely1:
					return 0.9;
				case Vulnerability.FailureLikely2:
					return 0.7;
				case Vulnerability.FailureLikely3:
					return 0.4;
				case Vulnerability.FailureLikely5:
					return 0.2;
				case Vulnerability.FailureLikely10:
					return 0.1;
				case Vulnerability.FailureLikely20:
					return 0.05;
				case Vulnerability.FailureLikely50:
					return 0.02;
				case Vulnerability.FailureLikely100:
					return 0.01;
				case Vulnerability.FailureLikely150:
					return 0.0067;
			}

			return 0.0;
		}

		public static double GetVulnerabilityYear(Vulnerability rank)
		{
			switch (rank)
			{
				case Vulnerability.FailureLikely1:
					return 1.0;
				case Vulnerability.FailureLikely2:
					return 2.0;
				case Vulnerability.FailureLikely3:
					return 3.0;
				case Vulnerability.FailureLikely5:
					return 5.0;
				case Vulnerability.FailureLikely10:
					return 10.0;
				case Vulnerability.FailureLikely20:
					return 20.0;
				case Vulnerability.FailureLikely50:
					return 50.0;
				case Vulnerability.FailureLikely100:
					return 100.0;
				case Vulnerability.FailureLikely150:
					return 150.0;
			}

			return 0.0;
		}

		public static string GetVulnerabilityString(Vulnerability rank)
		{
			switch (rank)
			{
				case Vulnerability.FailureLikely1:
					return "Failure likely within 1 year";
				case Vulnerability.FailureLikely2:
					return "Failure likely within 2 years";
				case Vulnerability.FailureLikely3:
					return "Failure likely within 3 years";
				case Vulnerability.FailureLikely5:
					return "Failure likely within 5 years";
				case Vulnerability.FailureLikely10:
					return "Failure likely within 10 years";
				case Vulnerability.FailureLikely20:
					return "Failure likely within 20 years";
				case Vulnerability.FailureLikely50:
					return "Failure likely within 50 years";
				case Vulnerability.FailureLikely100:
					return "Failure likely within 100 years";
				case Vulnerability.FailureLikely150:
					return "Failure likely within 150 years";
			}

			return "";
		}

		public static string GetVulnerabilityShort(Vulnerability rank)
		{
			switch (rank)
			{
				case Vulnerability.FailureLikely1:
					return "1";
				case Vulnerability.FailureLikely2:
					return "2";
				case Vulnerability.FailureLikely3:
					return "3";
				case Vulnerability.FailureLikely5:
					return "5";
				case Vulnerability.FailureLikely10:
					return "10";
				case Vulnerability.FailureLikely20:
					return "20";
				case Vulnerability.FailureLikely50:
					return "50";
				case Vulnerability.FailureLikely100:
					return "100";
				case Vulnerability.FailureLikely150:
					return "150";
			}

			return "";
		}

		public static Vulnerability VulnerabilityFromShort(short val)
		{
			if (val < 2)
				return Vulnerability.FailureLikely1;
			if (val < 3)
				return Vulnerability.FailureLikely2;
			if (val < 5)
				return Vulnerability.FailureLikely3;
			if (val < 10)
				return Vulnerability.FailureLikely5;
			if (val < 20)
				return Vulnerability.FailureLikely10;
			if (val < 50)
				return Vulnerability.FailureLikely20;
			if (val < 100)
				return Vulnerability.FailureLikely50;
			if (val < 150)
				return Vulnerability.FailureLikely100;

			return Vulnerability.FailureLikely150;
		}

		//mam - add associated value to text description
		public static string GetVulnerabilityStringAssocValue(Vulnerability rank)
		{
			switch (rank)
			{
				case Vulnerability.FailureLikely1:
					return "0.9  (Failure likely within 1 year)";
				case Vulnerability.FailureLikely2:
					return "0.7  (Failure likely within 2 years)";
				case Vulnerability.FailureLikely3:
					return "0.4  (Failure likely within 3 years)";
				case Vulnerability.FailureLikely5:
					return "0.2  (Failure likely within 5 years)";
				case Vulnerability.FailureLikely10:
					return "0.1  (Failure likely within 10 years)";
				case Vulnerability.FailureLikely20:
					return "0.05  (Failure likely within 20 years)";
				case Vulnerability.FailureLikely50:
					return "0.02  (Failure likely within 50 years)";
				case Vulnerability.FailureLikely100:
					return "0.01  (Failure likely within 100 years)";
				case Vulnerability.FailureLikely150:
					return "0.0067  (Failure likely within 150 years)";
			}

			return "";
		}
		//</mam>

		#endregion /***** Vulnerability *****/

		#region /***** Criticality: Public Health *****/

		//mam 07072011 - no longer using four fixed crits
//		public static int GetCritPublicHealthValue(CriticalityPublicHealth rank)
//		{
//			switch (rank)
//			{
//				case CriticalityPublicHealth.MultipleIllness:
//					return 15;
//				case CriticalityPublicHealth.Seasonal:
//					return 10;
//				case CriticalityPublicHealth.SingleIllness:
//					return 5;
//				case CriticalityPublicHealth.NoEffect:
//					return 0;
//			}
//
//			return 0;
//		}

		//mam 07072011 - no longer using four fixed crits
//		public static string GetCritPublicHealthString(CriticalityPublicHealth rank)
//		{
//			switch (rank)
//			{
//				case CriticalityPublicHealth.MultipleIllness:
//					return "Multiple illness or injury";
//				case CriticalityPublicHealth.Seasonal:
//					return "Illness or injury due to seasonal effects";
//				case CriticalityPublicHealth.SingleIllness:
//					return "Single illness or injury";
//				case CriticalityPublicHealth.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}

		//mam 07072011 - no longer using four fixed crits
//		public static string GetCritPublicHealthShort(CriticalityPublicHealth rank)
//		{
//			switch (rank)
//			{
//				case CriticalityPublicHealth.MultipleIllness:
//					return "Multiple";
//				case CriticalityPublicHealth.Seasonal:
//					return "Seasonal";
//				case CriticalityPublicHealth.SingleIllness:
//					return "Single";
//				case CriticalityPublicHealth.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam - add associated value to text description
//		public static string GetCritPublicHealthStringAssocValue(CriticalityPublicHealth rank)
//		{
//			switch (rank)
//			{
//				case CriticalityPublicHealth.MultipleIllness:
//					return "Multiple illness or injury  (15)";
//				case CriticalityPublicHealth.Seasonal:
//					return "Illness or injury due to seasonal effects  (10)";
//				case CriticalityPublicHealth.SingleIllness:
//					return "Single illness or injury  (5)";
//				case CriticalityPublicHealth.NoEffect:
//					return "No effect  (0)";
//			}
//
//			return "";
//		}
		//mam

		//mam 07072011 - no longer using four fixed crits
//		public static CriticalityPublicHealth CritHealthFromString(string val)
//		{
//			//mam - use GetCritPublicHealthString instead of GetCritPublicHealthShort
//			//original code:
//			//			if (string.Compare(val, 
//			//				GetCritPublicHealthShort(
//			//				CriticalityPublicHealth.MultipleIllness), false) == 0)
//			//				return CriticalityPublicHealth.MultipleIllness;
//			//			else if (string.Compare(val,
//			//				GetCritPublicHealthShort(
//			//				CriticalityPublicHealth.Seasonal), false) == 0)
//			//				return CriticalityPublicHealth.Seasonal;
//			//			else if (string.Compare(val, 
//			//				GetCritPublicHealthShort(
//			//				CriticalityPublicHealth.SingleIllness), false) == 0)
//			//				return CriticalityPublicHealth.SingleIllness;
//
//			//new code:
//			if (string.Compare(val, 
//				GetCritPublicHealthString(
//				CriticalityPublicHealth.MultipleIllness), false) == 0)
//				return CriticalityPublicHealth.MultipleIllness;
//			else if (string.Compare(val,
//				GetCritPublicHealthString(
//				CriticalityPublicHealth.Seasonal), false) == 0)
//				return CriticalityPublicHealth.Seasonal;
//			else if (string.Compare(val, 
//				GetCritPublicHealthString(
//				CriticalityPublicHealth.SingleIllness), false) == 0)
//				return CriticalityPublicHealth.SingleIllness;
//			//</mam>
//
//			return CriticalityPublicHealth.NoEffect;
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam 050806
//		public static CriticalityPublicHealth CritHealthFromStringAssocValue(string val)
//		{
//			if (string.Compare(val, 
//				GetCritPublicHealthStringAssocValue(
//				CriticalityPublicHealth.MultipleIllness), false) == 0)
//				return CriticalityPublicHealth.MultipleIllness;
//			else if (string.Compare(val,
//				GetCritPublicHealthStringAssocValue(
//				CriticalityPublicHealth.Seasonal), false) == 0)
//				return CriticalityPublicHealth.Seasonal;
//			else if (string.Compare(val, 
//				GetCritPublicHealthStringAssocValue(
//				CriticalityPublicHealth.SingleIllness), false) == 0)
//				return CriticalityPublicHealth.SingleIllness;
//
//			return CriticalityPublicHealth.NoEffect;
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam 050806
//		public static CriticalityPublicHealth CritHealthFromIndex(int val)
//		{
//			switch (val)
//			{
//				case 0:
//					return CriticalityPublicHealth.MultipleIllness;
//				case 1:
//					return CriticalityPublicHealth.Seasonal;
//				case 2:
//					return CriticalityPublicHealth.SingleIllness;
//				case 3:
//					return CriticalityPublicHealth.NoEffect;
//			}
//
//			return CriticalityPublicHealth.NoEffect;
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam 050806
//		public static int GetCritPublicHealthIndexFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MULTIPLE":
//					return 0;
//				case "SEASONAL":
//					return 1;
//				case "SINGLE":
//					return 2;
//				case "NO EFFECT":
//					return 3;
//			}
//
//			return -1;
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam 050806
//		public static string GetCritPublicHealthTextFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MULTIPLE":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.MultipleIllness);
//				case "SEASONAL":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.Seasonal);
//				case "SINGLE":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.SingleIllness);
//				case "NO EFFECT":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.NoEffect);
//				case "15":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.MultipleIllness);
//				case "10":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.Seasonal);
//				case "5":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.SingleIllness);
//				case "0":
//					return GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.NoEffect);
//			}
//
//			return string.Empty;
//		}

		//mam 07072011 - no longer using four fixed crits
//		//mam 050806
//		public static bool CritHealthIsValidValue(string val)
//		{
//			if (string.Compare(val, 
//				GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.MultipleIllness), false) == 0)
//				return true;
//			else if (string.Compare(val,
//				GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.Seasonal), false) == 0)
//				return true;
//			else if (string.Compare(val, 
//				GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.SingleIllness), false) == 0)
//				return true;
//			else if (string.Compare(val, 
//				GetCritPublicHealthStringAssocValue(CriticalityPublicHealth.NoEffect), false) == 0)
//				return true;
//
//			return false;
//		}

		#endregion /***** Criticality: Public Health *****/

		#region /***** Criticality: Environmental *****/

		//mam 07072011 - no longer using four fixed crits - comment all

//		public static int GetCritEnvironmentalValue(CriticalityEnvironmental rank)
//		{
//			switch (rank)
//			{
//				case CriticalityEnvironmental.Major:
//					return 8;
//				case CriticalityEnvironmental.Minor:
//					return 4;
//				case CriticalityEnvironmental.NoEffect:
//					return 0;
//			}
//
//			return 0;
//		}
//
//		public static string GetCritEnvironmentalString(CriticalityEnvironmental rank)
//		{
//			switch (rank)
//			{
//				case CriticalityEnvironmental.Major:
//					return "Major";
//				case CriticalityEnvironmental.Minor:
//					return "Minor";
//				case CriticalityEnvironmental.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}
//
//		public static string GetCritEnvironmentalShort(CriticalityEnvironmental rank)
//		{
//			switch (rank)
//			{
//				case CriticalityEnvironmental.Major:
//					return "Major";
//				case CriticalityEnvironmental.Minor:
//					return "Minor";
//				case CriticalityEnvironmental.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}
//
//		public static CriticalityEnvironmental CritEnvFromString(string val)
//		{
//			if (string.Compare(val, 
//				GetCritEnvironmentalShort(
//				CriticalityEnvironmental.Major), false) == 0)
//				return CriticalityEnvironmental.Major;
//			else if (string.Compare(val, 
//				GetCritEnvironmentalShort(
//				CriticalityEnvironmental.Minor), false) == 0)
//				return CriticalityEnvironmental.Minor;
//
//			return CriticalityEnvironmental.NoEffect;
//		}
//
//		//mam - add associated value to text description
//		public static string GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental rank)
//		{
//			switch (rank)
//			{
//				case CriticalityEnvironmental.Major:
//					return "Major  (8)";
//				case CriticalityEnvironmental.Minor:
//					return "Minor  (4)";
//				case CriticalityEnvironmental.NoEffect:
//					return "No effect  (0)";
//			}
//
//			return "";
//		}
//		//</mam>
//
//		//mam 050806
//		public static CriticalityEnvironmental CritEnvironmentFromIndex(int val)
//		{
//			switch (val)
//			{
//				case 0:
//					return CriticalityEnvironmental.Major;
//				case 1:
//					return CriticalityEnvironmental.Minor;
//				case 2:
//					return CriticalityEnvironmental.NoEffect;
//			}
//
//			return CriticalityEnvironmental.NoEffect;
//		}
//
//		//mam 050806
//		public static int GetCritEnvironmentalIndexFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MAJOR":
//					return 0;
//				case "MINOR":
//					return 1;
//				case "NO EFFECT":
//					return 2;
//			}
//
//			return -1;
//		}
//
//		//mam 050806
//		public static string GetCritEnvironmentTextFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MAJOR":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Major);
//				case "MINOR":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Minor);
//				case "NO EFFECT":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.NoEffect);
//				case "8":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Major);
//				case "4":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Minor);
//				case "0":
//					return GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.NoEffect);
//			}
//
//			return string.Empty;
//		}
//
//		//mam 050806
//		public static bool CritEnvironmentIsValidValue(string val)
//		{
//			if (string.Compare(val, 
//				GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Major), false) == 0)
//				return true;
//			else if (string.Compare(val,
//				GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.Minor), false) == 0)
//				return true;
//			else if (string.Compare(val, 
//				GetCritEnvironmentalStringAssocValue(CriticalityEnvironmental.NoEffect), false) == 0)
//				return true;
//
//			return false;
//		}

		#endregion /***** Criticality: Environmental *****/

		//mam 03202012 - some criticality values were changed in the second WAM version 3.1
		//	this was done for a particular client, but the values remained in WAM, even though they should have 
		//	been reset to their previous values

		#region /***** Criticality: Cost of Repairs *****/

		//mam 07072011 - no longer using four fixed crits - comment all

//		public static int GetCritRepairCostValue(CriticalityRepairCost rank)
//		{
//			switch (rank)
//			{
//				case CriticalityRepairCost.MoreThan100k:
//					return 6;
//				case CriticalityRepairCost.Between30kAnd100k:
//					return 4;
//				case CriticalityRepairCost.Between5kAnd30k:
//					return 2;
//				case CriticalityRepairCost.LessThan5k:
//					return 0;
//			}
//
//			return 0;
//		}
//
//		public static string GetCritRepairCostString(CriticalityRepairCost rank)
//		{
//			switch (rank)
//			{
//				case CriticalityRepairCost.MoreThan100k:
//					return "More than $100,000";
//				case CriticalityRepairCost.Between30kAnd100k:
//					return "Between $30,000 and $100,000";
//				case CriticalityRepairCost.Between5kAnd30k:
//					return "Between $5,000 and $30,000";
//				case CriticalityRepairCost.LessThan5k:
//					return "Less than $5,000";
//			}
//
//			return "";
//		}
//
//		public static string GetCritRepairCostShort(CriticalityRepairCost rank)
//		{
//			switch (rank)
//			{
//				case CriticalityRepairCost.MoreThan100k:
//					return "$100,000";
//				case CriticalityRepairCost.Between30kAnd100k:
//					return "$30,000 and $100,000";
//				case CriticalityRepairCost.Between5kAnd30k:
//					return "$5,000 and $30,000";
//				case CriticalityRepairCost.LessThan5k:
//					return "$5,000";
//			}
//
//			return "";
//		}
//
//		public static CriticalityRepairCost CritRepairCostFromString(string val)
//		{
//			//mam - use GetCritRepairCostString rather than GetCritRepairCostShort
//			//original code:
//			//			if (string.Compare(val, 
//			//				GetCritRepairCostShort(
//			//				CriticalityRepairCost.MoreThan20k), false) == 0)
//			//				return CriticalityRepairCost.MoreThan20k;
//			//			else if (string.Compare(val, 
//			//				GetCritRepairCostShort(
//			//				CriticalityRepairCost.Between5kAnd20k), false) == 0)
//			//				return CriticalityRepairCost.Between5kAnd20k;
//			
//			//new code:
//			if (string.Compare(val, 
//				GetCritRepairCostString(
//				CriticalityRepairCost.MoreThan100k), false) == 0)
//				return CriticalityRepairCost.MoreThan100k;
//			else if (string.Compare(val, 
//				GetCritRepairCostString(
//				CriticalityRepairCost.Between30kAnd100k), false) == 0)
//				return CriticalityRepairCost.Between30kAnd100k;
//			else if (string.Compare(val,
//				GetCritRepairCostString(
//				CriticalityRepairCost.Between5kAnd30k), false) == 0)
//				return CriticalityRepairCost.Between5kAnd30k;
//			return CriticalityRepairCost.LessThan5k;
//		}
//
//		//mam - add associated value to text description
//		public static string GetCritRepairCostStringAssocValue(CriticalityRepairCost rank)
//		{
//			switch (rank)
//			{
//				case CriticalityRepairCost.MoreThan100k:
//					return "More than $100,000  (6)";
//				case CriticalityRepairCost.Between30kAnd100k:
//					return "Between $30,000 and $100,000  (4)";
//				case CriticalityRepairCost.Between5kAnd30k:
//					return "Between $5,000 and $30,000  (2)";
//				case CriticalityRepairCost.LessThan5k:
//					return "Less than $5,000  (0)";
//			}
//
//			return "";
//		}
//		
//		//mam 050806
//		public static CriticalityRepairCost CritRepairFromIndex(int val)
//		{
//			switch (val)
//			{
//				case 0:
//					return CriticalityRepairCost.MoreThan100k;
//				case 1:
//					return CriticalityRepairCost.Between30kAnd100k;
//				case 2:
//					return CriticalityRepairCost.Between5kAnd30k;
//				case 3:
//					return CriticalityRepairCost.LessThan5k;
//			}
//
//			return CriticalityRepairCost.LessThan5k;
//		}
//		
//		//mam 050806
//		public static int GetCritRepairIndexFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case ">100000":
//					return 0;
//				case "30000 TO 100000":
//					return 1;
//				case "5000 TO 30000":
//					return 2;
//				case "<5000":
//					return 3;
//			}
//
//			return -1;
//		}
//
//		//mam 050806
//		public static string GetCritRepairTextFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case ">100000":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.MoreThan100k);
//				case "30000 TO 100000":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between30kAnd100k);
//				case "5000 TO 30000":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between5kAnd30k);
//				case "<5000":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.LessThan5k);
//				case "6":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.MoreThan100k);
//				case "4":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between30kAnd100k);
//				case "2":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between5kAnd30k);
//				case "0":
//					return GetCritRepairCostStringAssocValue(CriticalityRepairCost.LessThan5k);
//			}
//
//			return string.Empty;
//		}
//
//		//mam 050806
//		public static bool CritRepairIsValidValue(string val)
//		{
//			if (string.Compare(val, 
//				GetCritRepairCostStringAssocValue(CriticalityRepairCost.MoreThan100k), false) == 0)
//				return true;
//			else if (string.Compare(val,
//				GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between30kAnd100k), false) == 0)
//				return true;
//			else if (string.Compare(val,
//				GetCritRepairCostStringAssocValue(CriticalityRepairCost.Between5kAnd30k), false) == 0)
//				return true;
//			else if (string.Compare(val, 
//				GetCritRepairCostStringAssocValue(CriticalityRepairCost.LessThan5k), false) == 0)
//				return true;
//
//			return false;
//		}

		#endregion /***** Criticality: Cost of Repairs *****/

		#region /***** Criticality: Effect on Customers *****/

		//mam 07072011 - no longer using four fixed crits - comment all

//		public static int GetCritCustomerEffectValue(CriticalityCustomerEffect rank)
//		{
//			switch (rank)
//			{
//				case CriticalityCustomerEffect.Major:
//					return 10;
//				case CriticalityCustomerEffect.Minor:
//					return 5;
//				case CriticalityCustomerEffect.NoEffect:
//					return 0;
//			}
//
//			return 0;
//		}
//
//		public static string GetCritCustomerEffectString(CriticalityCustomerEffect rank)
//		{
//			switch (rank)
//			{
//				case CriticalityCustomerEffect.Major:
//					return "Major or repeat occurrence";
//				case CriticalityCustomerEffect.Minor:
//					return "Minor";
//				case CriticalityCustomerEffect.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}
//
//		public static string GetCritCustomerEffectShort(CriticalityCustomerEffect rank)
//		{
//			switch (rank)
//			{
//				case CriticalityCustomerEffect.Major:
//					return "Major";
//				case CriticalityCustomerEffect.Minor:
//					return "Minor";
//				case CriticalityCustomerEffect.NoEffect:
//					return "No effect";
//			}
//
//			return "";
//		}
//
//		public static CriticalityCustomerEffect CritCustEffectFromString(string val)
//		{
//			if (string.Compare(val, 
//				GetCritCustomerEffectShort(
//				CriticalityCustomerEffect.Major), false) == 0)
//				return CriticalityCustomerEffect.Major;
//			else if (string.Compare(val, 
//				GetCritCustomerEffectShort(
//				CriticalityCustomerEffect.Minor), false) == 0)
//				return CriticalityCustomerEffect.Minor;
//
//			return CriticalityCustomerEffect.NoEffect;
//		}
//
//		//mam - add associated value to text description
//		public static string GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect rank)
//		{
//			switch (rank)
//			{
//				case CriticalityCustomerEffect.Major:
//					return "Major or repeat occurrence  (10)";
//				case CriticalityCustomerEffect.Minor:
//					return "Minor  (5)";
//				case CriticalityCustomerEffect.NoEffect:
//					return "No effect  (0)";
//			}
//
//			return "";
//		}
//		//</mam>
//
//		//mam 050806
//		public static CriticalityCustomerEffect CritEffectFromIndex(int val)
//		{
//			switch (val)
//			{
//				case 0:
//					return CriticalityCustomerEffect.Major;
//				case 1:
//					return CriticalityCustomerEffect.Minor;
//				case 2:
//					return CriticalityCustomerEffect.NoEffect;
//			}
//
//			return CriticalityCustomerEffect.NoEffect;
//		}
//
//		//mam 050806
//		public static int GetCritEffectIndexFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MAJOR":
//					return 0;
//				case "MINOR":
//					return 1;
//				case "NO EFFECT":
//					return 2;
//			}
//
//			return -1;
//		}
//
//		//mam 050806
//		public static string GetCritEffectTextFromSingleWord(string val)
//		{
//			switch (val.Trim().ToUpper())
//			{
//				case "MAJOR":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Major);
//				case "MINOR":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Minor);
//				case "NO EFFECT":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.NoEffect);
//				case "10":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Major);
//				case "5":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Minor);
//				case "0":
//					return GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.NoEffect);
//			}
//
//			return string.Empty;
//		}
//
//		//mam 050806
//		public static bool CritEffectIsValidValue(string val)
//		{
//			if (string.Compare(val, 
//				GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Major), false) == 0)
//				return true;
//			else if (string.Compare(val,
//				GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.Minor), false) == 0)
//				return true;
//			else if (string.Compare(val, 
//				GetCritCustomerEffectStringAssocValue(CriticalityCustomerEffect.NoEffect), false) == 0)
//				return true;
//
//			return false;
//		}

		#endregion /***** Criticality: Effect on Customers *****/

		#region /***** Item Status *****/
		public static string GetItemStatusShort(ItemStatus status)
		{
			switch (status)
			{
				case ItemStatus.Yes:
					return "Yes";
				case ItemStatus.No:
					return "No";
				case ItemStatus.NotApplicable:
					return "N/A";
			}

			return "";
		}
		#endregion /***** Item Status *****/

		#region /***** Graphing *****/

		public static string GetGraphYAxisString(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return "Acquisition Cost ($)";
				case GraphYAxis.CurrentValue:
					return "Current Value ($)";
				case GraphYAxis.ReplacementValue:
					return "Replacement Value ($)";
				case GraphYAxis.BookValue:
					return "Book Value ($)";
				case GraphYAxis.SalvageValue:
					return "Salvage Value ($)";
				case GraphYAxis.AnnualDepreciation:
					return "Annual Depreciation ($)";
				case GraphYAxis.CumulativeDepreciation:
					return "Cumulative Depreciation ($)";
				case GraphYAxis.EvaluatedValue:
					return "Evaluated Value ($)";
				case GraphYAxis.RepairCost:
					return "Repair Cost ($)";
				case GraphYAxis.AnnualMaintenanceCost:
					return "Annual Maintenance Cost ($)";

				case GraphYAxis.Vulnerability:
					return "Vulnerability";
				case GraphYAxis.Criticality:
					return "Criticality";
				case GraphYAxis.Risk:
					return "Risk";
				case GraphYAxis.Condition:
					return "Condition Rank";
				case GraphYAxis.LOS:
					return "Level of Service Goal";
				case GraphYAxis.ConditionAndLOS:
					return "LOS and Condition";

				//mam 050806
				case GraphYAxis.AcquisitionCostEscalated:
					return "Escalated Acquisition Cost ($)";

				case GraphYAxis.RehabCost:
				{
					return "Rehabilitation Cost ($)";
				}

				//mam 090105
				//original, remaining, evaluated, and economic
				case GraphYAxis.OriginalUsefulLife:
					return "Original Useful Life";
				case GraphYAxis.RemainingUsefulLife:
					return "Remaining Useful Life";
				case GraphYAxis.EvaluatedRemainingUsefulLife:
					return "Evaluated Remaining Useful Life";
				case GraphYAxis.EconomicRemainingUsefulLife:
					return "Economic Remaining Useful Life";
			}

			return "";
		}

		public static string GetGraphYAxisFormatString(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
				case GraphYAxis.CurrentValue:
				case GraphYAxis.ReplacementValue:
				case GraphYAxis.BookValue:
				case GraphYAxis.SalvageValue:
				case GraphYAxis.AnnualDepreciation:
				case GraphYAxis.CumulativeDepreciation:
				case GraphYAxis.EvaluatedValue:
				case GraphYAxis.RepairCost:
				case GraphYAxis.AnnualMaintenanceCost:
				
					//mam050806
				case GraphYAxis.AcquisitionCostEscalated:
				case GraphYAxis.RehabCost:
					return "#,##0";

				//mam 07072011
				case GraphYAxis.RehabInterval:
				case GraphYAxis.RehabNext:
					return "##0.0";

				case GraphYAxis.Vulnerability:
				case GraphYAxis.Condition:
				case GraphYAxis.LOS:
				case GraphYAxis.ConditionAndLOS:
					return "D1";
				case GraphYAxis.Criticality:
					return "F2";
				case GraphYAxis.Risk:
					return "F2";


					//mam 090105
					//original, remaining, evaluated, and economic
				case GraphYAxis.OriginalUsefulLife:
				case GraphYAxis.RemainingUsefulLife:
				case GraphYAxis.EvaluatedRemainingUsefulLife:
				case GraphYAxis.EconomicRemainingUsefulLife:
					return "F2";
			}

			return "";
		}

		#endregion /***** Graphing *****/
	}
}