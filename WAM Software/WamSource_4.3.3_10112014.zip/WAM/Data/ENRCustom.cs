using System;
using System.Configuration;
using System.Data;

//mam 102309
//using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for ENRCustom.
	/// </summary>

	//mam 102309
	//public class ENRCustom : Drive.Data.OleDb.Jet40DALInt32Key, IComparable
	public class ENRCustom : Drive.Data.SqlClient.SqlDALInt32Key, IComparable
	{
		#region /***** Member Variables *****/
		//mam - no longer tying ENR tables only to one facility
		//private int			m_facilityID = 0;
		//</mam>

		private	int			m_year = 0;
		private int			m_enrValue = 0;
		private bool		m_isNew = true;

		//mam
		private int m_customENRListID = 0;
		private bool m_allowDriveSynchronization = true;
		private static int useCustomENRListID;
		//</mam>
		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public ENRCustom(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public ENRCustom(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public				ENRCustom(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		//mam 102309
		//protected ENRCustom(System.Data.OleDb.OleDbDataReader reader) : base(WAMSource.CurrentSource.ConnectionString, reader)
		protected ENRCustom(System.Data.SqlClient.SqlDataReader reader) : base(Globals.WamSqlConnectionString, reader)
		{
		}
		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			//mam - ENR tables are no longer associated with only one specific Facility
			//m_facilityID = reader.GetInt32(col++);
			//</mam>

			m_year = reader.GetInt32(col++);
			m_enrValue = reader.GetInt32(col++);
			m_customENRListID = reader.GetInt32(col++);
			m_isNew = false;
		}

		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			//mam - no longer tying ENR tables only to one facility
			//builder.Append("SELECT facility_id, enr_year, enr_value ");
			//builder.Append("FROM CustomENR ");
			//builder.AppendFormat("WHERE enr_year={0}", m_year);

			builder.AppendFormat(@"SELECT enr_year, enr_value, CustomENRListID FROM CustomENR WHERE enr_year = {0} AND CustomENRListID = {1}", m_year, m_customENRListID);
			//</mam>

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			//mam - no longer tying ENR tables only to one facility
			//builder.Append("INSERT INTO CustomENR ");
			//builder.Append("( facility_id, enr_year, enr_value, CustomENRListID ) ");
			//builder.Append(" VALUES (");
			//builder.AppendFormat("{0}, ", m_facilityID);
			//builder.AppendFormat("{0}, ", m_year);
			//builder.AppendFormat("{0}, ", m_enrValue);
			//builder.Append("); ");

			builder.AppendFormat(@"INSERT INTO CustomENR (enr_year, enr_value, CustomENRListID) VALUES ({0}, {1}, {2})", m_year, m_enrValue, m_customENRListID);
			//</mam>

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(150);

			//mam - no longer tying ENR tables only to one facility
			//builder.Append("UPDATE CustomENR SET ");
			//builder.AppendFormat("enr_value={0} ", m_enrValue );
			//builder.AppendFormat("WHERE (facility_id={0} AND enr_year={1}); ", m_facilityID, m_year);
			//</mam>

			//mam
			builder.AppendFormat(@"UPDATE CustomENR SET enr_value = {0} WHERE enr_year = {1} AND CustomENRListID = {2}", m_enrValue, m_year, m_customENRListID);
			//</mam>

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			//mam - no longer tying ENR tables only to one facility
			//return string.Format("DELETE FROM CustomENR WHERE facility_id={0} AND enr_year={1}", m_facilityID, m_year);
			return string.Format("DELETE FROM CustomENR WHERE CustomENRListID = {0} AND enr_year = {1}", m_customENRListID, m_year);
			//</mam>
		}

		public override bool Valid
		{
			get
			{
				return !m_isNew;
			}
		}

		//mam
		public void UpdateDatabaseCustomENR(bool isNew)
		{
			//set the value of useCustomENRListID;
			//call Save to update the database (year, value, and ID have been set previously in ManageCustomENRForm.buttonEditValue_Click;
			m_isNew = isNew;
			this.Save();
		}
		//</mam>

		//mam 102309
		//public override bool Save(System.Data.OleDb.OleDbConnection oleDbConnection)
		public override bool Save(SqlConnection sqlConnection)
		{
			//mam 102309
			//OleDbCommand	sqlCommand = null;
			//OleDbDataReader	dataReader = null;
			SqlCommand		sqlCommand = null;
			SqlDataReader	dataReader = null;

			string			saveSqlString;
			bool			isNew = m_isNew;

			if (isNew)
				saveSqlString = GetInsertSql();
			else
				saveSqlString = GetUpdateSql();

			if (saveSqlString.Length == 0)
				return false;

			try
			{
				//mam 102309
				//sqlCommand = new OleDbCommand(saveSqlString, oleDbConnection);
				sqlCommand = new SqlCommand(saveSqlString, sqlConnection);

				sqlCommand.ExecuteNonQuery();
				m_id = 1;
				m_isNew = false;
			}

			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("{0}.Save Error: {1}\n", 
					this.ToString(), ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				//return false;
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			//mam - don't call Drive.Synchronization.SyncAction when the ManageCustomENRForm is open, unless
			//	the changes affect the current facility
			if (!m_allowDriveSynchronization)
				return true;

			if (Valid)
			{
				Drive.Synchronization.SyncAction action;

				if (isNew)
					action = Drive.Synchronization.SyncAction.Add;
				else
					action = Drive.Synchronization.SyncAction.Edit;

				InvokeChangeEvent(this, new DataChangeEventArgs(this, action));
			}
			return Valid;
		}

		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/

		public int			Year
		{
			get { return m_year; }
			set { m_year = value; }
		}

		public int			ENRValue
		{
			get { return m_enrValue; }
			set { m_enrValue = value; }
		}

		//mam
		public int CustomENRListID
		{
			get { return m_customENRListID; }
			set { m_customENRListID = value; }
		}

		public bool AllowDriveSynchronization
		{
			get { return m_allowDriveSynchronization; }
			set { m_allowDriveSynchronization = value; }
		}
		//</mam>

		#endregion /***** Properties *****/

		#region /***** Static Methods *****/

		//mam - no longer tying ENR tables only to one facility
		public static ENRCustom[] LoadForFacility(int facilityID)
		//public static ENRCustom[] LoadForFacility()
		{
			//return LoadForFacility(facilityID, WAMSource.CurrentSource.ConnectionString);

			if (facilityID != 0)
			{
				Facility facility = CacheManager.GetFacility(InfoSet.CurrentID, facilityID);
				if (facility != null)
				{
					useCustomENRListID = facility.CustomENRListID;

					//mam 102309
					//return LoadForFacility(WAMSource.CurrentSource.ConnectionString);
					return LoadForFacility(Globals.WamSqlConnectionString);
				}
			}

			return null;
		}

		//mam - no longer tying ENR tables only to one facility
		public static ENRCustom[] LoadForENR(int customENRListID)
		//public static ENRCustom[] LoadForFacility()
		{
			useCustomENRListID = customENRListID;
			//return LoadForFacility(facilityID, WAMSource.CurrentSource.ConnectionString);

			//mam 102309
			//return LoadForFacility(WAMSource.CurrentSource.ConnectionString);
			return LoadForFacility(Globals.WamSqlConnectionString);
		}

		//mam - new method to be used when getting ENR data based on CustomENRListID
		public static ENRCustom[] LoadForFacility(int facilityID, int customENRListID)
		//public static ENRCustom[] LoadForFacility(int customENRListID)
		{
			ENRCustom[] typedArray;

			useCustomENRListID = customENRListID;

			//mam - no longer tying ENR tables only to one facility
			//typedArray = LoadForFacility(facilityID, WAMSource.CurrentSource.ConnectionString);

			//mam 102309
			//typedArray = LoadForFacility(WAMSource.CurrentSource.ConnectionString);
			typedArray = LoadForFacility(Globals.WamSqlConnectionString);

			//</mam>

			return typedArray;
		}
		//</mam>

		//mam - no longer tying ENR tables only to one facility
		//public static ENRCustom[] LoadForFacility(int facilityID, string connectionString)
		public static ENRCustom[] LoadForFacility(string connectionString)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			ENRCustom		newObject;
			ENRCustom[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			//mam - change the query to use the CustomENR table
			//builder.Append("SELECT facility_id, enr_year, enr_value FROM CustomENR ");
			//builder.AppendFormat("WHERE facility_id={0} ", facilityID);
			//builder.Append("ORDER BY enr_year ASC ");

			builder.Append("SELECT C.enr_year, C.enr_value, C.CustomENRListID");
			builder.Append(" FROM CustomENRList C2 INNER JOIN CustomENR C ON C2.CustomENRListID = C.CustomENRListID");
			builder.AppendFormat(" WHERE C2.CustomENRListID={0}", useCustomENRListID);
			builder.Append(" ORDER BY C.enr_year ASC");
			//</mam>

			//System.Diagnostics.Debug.WriteLine(builder.ToString());
			try
			{
				sqlConnection.Open();

				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new ENRCustom(dataReader);
					arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("ENRCustom.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				sqlConnection.Dispose();
			}
			typedArray = new ENRCustom[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods *****/

		#region IComparable Members
		public int CompareTo(object obj)
		{
			if (obj is ENRCustom)
			{
				ENRCustom comp = (ENRCustom)obj;

				return Drive.Math.Compare(m_year, comp.m_year);
			}

			throw new ArgumentException("Not an ENRCustom object!");
		}
		#endregion
	}
}