using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for NodeData.
	/// </summary>

	//mam 102309
	//public class NodeData : Drive.Data.OleDb.Jet40DALInt32Key, ICloneable, IComparable
	public class NodeData : Drive.Data.SqlClient.SqlDALInt32Key, ICloneable, IComparable
	{
		#region /***** Member Variables *****/
		private int			m_discNodeID = 0;
		private string		m_idNumber = "";
		private string		m_description = "";
		private string		m_type = "";
		private string		m_size = "";
		private short		m_installYear = (short)DateTime.Now.Year;
		private int			m_originalENR = 0;
		private decimal		m_acquisitionCost = 0;
		private decimal		m_replacementValue = 0;
		private decimal		m_salvageValue = 0;
		private decimal		m_annualMaintCost = 0;

		//mam
		private double		m_vulnerability2 = 0;
		private bool		m_overrideVulnerability = false;
		//private int m_replacementENR = 0;
		private int m_currentENR = 0;
		//</mam>

		//mam 050806
		private int m_replacementValueYear = 0;
		private decimal m_repairCost = 0;
		private bool m_overrideRepairCost = false;
		private decimal m_currentValue = 0;
		private decimal m_rehabCost = 0;
		private bool m_overrideAcquisitionCost = false;
		private bool m_overrideCurrentValue = false;
		private int m_redundantAssetCount = 1;

		//mam - set default CondRank.C0 to CodeRank.No
		//private CondRank	m_conditionRank = CondRank.C0;
		private CondRank	m_conditionRank = CondRank.No;
		//</mam>

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using the four fixed crits
		//private CriticalityPublicHealth m_critPublic = CriticalityPublicHealth.NoEffect;
		//private CriticalityEnvironmental m_critEnvironmental = CriticalityEnvironmental.NoEffect;
		//private CriticalityRepairCost m_critRepair = CriticalityRepairCost.LessThan5k;
		//private CriticalityCustomerEffect m_critCustEffect = CriticalityCustomerEffect.NoEffect;
		private byte m_critPublic = 0;
		private byte m_critEnvironmental = 0;
		private byte m_critRepair = 0;
		private byte m_critCustEffect = 0;

		//mam - change to LOS2
		//private LevelOfService m_LOS = LevelOfService.LOS2;
		private LevelOfService m_LOS = LevelOfService.LOS1;
		//</mam>

		private Vulnerability m_vulnerability = Vulnerability.FailureLikely50;
		private short		m_orgUsefulLife = 50;

		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		//mam 07072011
		//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
		private MajorComponentSelectedCriticalityFactorsCollection nodeSelectedCritFactorCollection = new MajorComponentSelectedCriticalityFactorsCollection();

		#endregion /***** Member Variables *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			NodeData comp = obj as NodeData;

			if (comp != null)
			{
				return Drive.Math.Compare((int)this.ID, (int)comp.ID);
			}
			else
				throw new InvalidCastException("NodeData");
		}
		#endregion /***** IComparable Members *****/

		#region /***** Construction *****/
		//mam 102309
		//public NodeData(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public NodeData(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public NodeData(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//protected NodeData(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected NodeData(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
		{
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(System.Data.SqlClient.SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_discNodeID = reader.GetInt32(col++);

			//mam 102309
			//m_idNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			//m_type = Drive.SQL.ReadNullableString(reader, col++);
			//m_size = Drive.SQL.ReadNullableString(reader, col++);
			m_idNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_type = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_size = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_installYear = reader.GetInt16(col++);

			//mam 102309
			//m_originalENR = Drive.SQL.ReadNullableInt32(reader, col++);
			m_originalENR = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 050806
			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 050806 - change to nullable
			//m_acquisitionCost = reader.GetDecimal(col++);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_conditionRank = (CondRank)reader.GetByte(col++);

			//mam 07072011 - no longer using the four fixed criticalities
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);

			m_LOS = (LevelOfService)reader.GetByte(col++);
			m_vulnerability = (Vulnerability)reader.GetByte(col++);
			m_orgUsefulLife = reader.GetInt16(col++);

			//mam
			//m_vulnerability2 = reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			//mam 102309
			//m_vulnerability2 = Drive.SQL.ReadNullableDouble(reader, col++);
			m_vulnerability2 = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabCost = reader.GetDecimal(col++);
			m_redundantAssetCount = reader.GetInt32(col++);
		}

		//mam 11142011 - new method - need this when importing from Access
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_discNodeID = reader.GetInt32(col++);

			//mam 102309
			//m_idNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			//m_type = Drive.SQL.ReadNullableString(reader, col++);
			//m_size = Drive.SQL.ReadNullableString(reader, col++);
			m_idNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_type = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_size = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_installYear = reader.GetInt16(col++);

			//mam 102309
			//m_originalENR = Drive.SQL.ReadNullableInt32(reader, col++);
			m_originalENR = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 050806
			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 050806 - change to nullable
			//m_acquisitionCost = reader.GetDecimal(col++);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_conditionRank = (CondRank)reader.GetByte(col++);

			//mam 11142011 - need these when importing from Access
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);
			m_critPublic = reader.GetByte(col++);
			m_critEnvironmental = reader.GetByte(col++);
			m_critRepair = reader.GetByte(col++);
			m_critCustEffect = reader.GetByte(col++);

			m_LOS = (LevelOfService)reader.GetByte(col++);
			m_vulnerability = (Vulnerability)reader.GetByte(col++);
			m_orgUsefulLife = reader.GetInt16(col++);

			//mam
			//m_vulnerability2 = reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			//mam 102309
			//m_vulnerability2 = Drive.SQL.ReadNullableDouble(reader, col++);
			m_vulnerability2 = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabCost = reader.GetDecimal(col++);
			m_redundantAssetCount = reader.GetInt32(col++);
		}

		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("SELECT ");
			builder.Append("node_id, ");
			builder.Append("discnode_id, ");
			builder.Append("node_IDNumber, ");
			builder.Append("node_description, ");
			builder.Append("node_type, ");
			builder.Append("node_size, ");
			builder.Append("node_installYear, ");
			builder.Append("node_originalENR, ");
			builder.Append("node_acquisitionCost, ");
			builder.Append("node_replacementValue, ");
			builder.Append("node_salvageValue, ");
			builder.Append("node_annualMaintCost, ");
			builder.Append("node_conditionRank, ");

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.Append("node_critPublicHealth, ");
			//builder.Append("node_critEnvironmental, ");
			//builder.Append("node_critRepairCost, ");
			//builder.Append("node_critCustomerEffect, ");

			builder.Append("node_levelOfService, ");
			builder.Append("node_vulnerability, ");
			builder.Append("node_originalUsefulLife ");

			//mam
			builder.Append(", node_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost ");
			builder.Append(", node_currentValue ");
			builder.Append(", RehabCost");
			//</mam>

			//mam 050806
			builder.Append(", RedundantAssetCount ");

			builder.Append("FROM NodeAppurtComponents ");
			builder.AppendFormat("WHERE node_id={0}", id);
			return builder.ToString();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - add bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}

					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for saving all criticality values
		public bool SaveCriticalityValuesAll()
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				string xmlString = Common.CommonTasks.CreateCriticalityXmlString(nodeSelectedCritFactorCollection);
				dataAccess.ExecuteCommandInsertCriticalityValuesPipeNode(this.ID, xmlString, false);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				//mam 07072011 - throw error
				//System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				//return false;
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting criticality values from one major component to another
		public bool InsertCriticalityValuesAllCopy(int sourceNodeId, int destinationNodeId)
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityCopyNode", "@sourceNodeId", "@destinationNodeId", sourceNodeId, destinationNodeId);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting all criticality default values
		public bool InsertCriticalityValuesAllDefault()
		{
			//this is used when creating a new Major Component

			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityDefaultNode", "@nodeId", this.ID);

				//populate the crit collection for this major component
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityNode", "@nodeId", this.ID);
				ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(dataTable);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO NodeAppurtComponents (");
			builder.Append("discnode_id, ");
			builder.Append("node_IDNumber, ");
			builder.Append("node_description, ");
			builder.Append("node_type, ");
			builder.Append("node_size, ");
			builder.Append("node_installYear, ");
			builder.Append("node_originalENR, ");
			builder.Append("node_acquisitionCost, ");
			builder.Append("node_replacementValue, ");
			builder.Append("node_salvageValue, ");
			builder.Append("node_annualMaintCost, ");
			builder.Append("node_conditionRank, ");

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.Append("node_critPublicHealth, ");
			//builder.Append("node_critEnvironmental, ");
			//builder.Append("node_critRepairCost, ");
			//builder.Append("node_critCustomerEffect, ");

			builder.Append("node_levelOfService, ");
			builder.Append("node_vulnerability, ");
			builder.Append("node_originalUsefulLife ");

			//mam
			builder.Append(", node_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost ");
			builder.Append(", node_currentValue ");
			builder.Append(", RehabCost");
			//</mam>

			//mam 050806
			builder.Append(", RedundantAssetCount ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_discNodeID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_idNumber));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_type));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_size));
			builder.AppendFormat("{0}, ", m_installYear);
			builder.AppendFormat("{0}, ", m_originalENR);

			//mam 050806 - check overridden value
			if (m_overrideAcquisitionCost)
				//builder.AppendFormat(", {0} ", m_acquisitionCost);
				builder.AppendFormat("{0:F2}, ", m_acquisitionCost);
			else
				builder.Append(" NULL, ");
			
			builder.AppendFormat("{0:F2}, ", m_replacementValue);
			builder.AppendFormat("{0:F2}, ", m_salvageValue);
			builder.AppendFormat("{0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("{0}, ", (byte)m_conditionRank);

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.AppendFormat("{0}, ", (byte)m_critPublic);
			//builder.AppendFormat("{0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("{0}, ", (byte)m_critRepair);
			//builder.AppendFormat("{0}, ", (byte)m_critCustEffect);

			builder.AppendFormat("{0}, ", (byte)m_LOS);
			builder.AppendFormat("{0}, ", (byte)m_vulnerability);
			builder.AppendFormat("{0} ", m_orgUsefulLife);

			//mam
			if (m_overrideVulnerability)
				builder.AppendFormat(", {0} ", m_vulnerability2);
			else
				builder.Append(", NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", {0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", {0} ", m_repairCost);
			else
				builder.Append(", NULL ");
			if (m_overrideCurrentValue)
				builder.AppendFormat(", {0} ", m_currentValue);
			else
				builder.Append(", NULL ");

			//mam 050806
			builder.AppendFormat(", {0:F2} ", m_rehabCost);
			builder.AppendFormat(", {0} ", m_redundantAssetCount);

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			//System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE NodeAppurtComponents SET ");
			builder.AppendFormat("discnode_id={0}, ", m_discNodeID);
			builder.AppendFormat("node_IDNumber='{0}', ", Drive.SQL.PadString(m_idNumber));
			builder.AppendFormat("node_description={0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("node_type={0}, ", Drive.SQL.StringToDBString(m_type));
			builder.AppendFormat("node_size={0}, ", Drive.SQL.StringToDBString(m_size));
			builder.AppendFormat("node_installYear={0}, ", m_installYear);
			builder.AppendFormat("node_originalENR={0} ", m_originalENR);

			//mam 050806 - check overridden value
			if (m_overrideAcquisitionCost)
				//builder.AppendFormat(", node_acquisitionCost={0} ", m_acquisitionCost);
				builder.AppendFormat(", node_acquisitionCost={0:F2}, ", m_acquisitionCost);
			else
				builder.Append(", node_acquisitionCost=NULL, ");

			builder.AppendFormat("node_replacementValue={0:F2}, ", m_replacementValue);
			builder.AppendFormat("node_salvageValue={0:F2}, ", m_salvageValue);
			builder.AppendFormat("node_annualMaintCost={0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("node_conditionRank={0}, ", (byte)m_conditionRank);

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.AppendFormat("node_critPublicHealth={0}, ", (byte)m_critPublic);
			//builder.AppendFormat("node_critEnvironmental={0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("node_critRepairCost={0}, ", (byte)m_critRepair);
			//builder.AppendFormat("node_critCustomerEffect={0}, ", (byte)m_critCustEffect);

			builder.AppendFormat("node_levelOfService={0}, ", (byte)m_LOS);
			builder.AppendFormat("node_vulnerability={0}, ", (byte)m_vulnerability);
			builder.AppendFormat("node_originalUsefulLife={0} ", m_orgUsefulLife);

			//mam
			if (m_overrideVulnerability)
				builder.AppendFormat(", node_vulnerability2={0} ", m_vulnerability2);
			else
				builder.Append(", node_vulnerability2=NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", ReplacementValueYear={0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", RepairCost={0} ", m_repairCost);
			else
				builder.Append(", RepairCost=NULL ");
			if (m_overrideCurrentValue)
				builder.AppendFormat(", node_currentValue={0} ", m_currentValue);
			else
				builder.Append(", node_currentValue=NULL ");

			//mam 050806
			builder.AppendFormat(", RehabCost={0:F2} ", m_rehabCost);
			builder.AppendFormat(", RedundantAssetCount={0} ", m_redundantAssetCount);

			builder.AppendFormat("WHERE (node_id={0}) ", ID);

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From NodeAppurtComponents WHERE node_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/

		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public int			DiscNodeID
		{
			get { return m_discNodeID; }
			set { m_discNodeID = value; }
		}

		public string		IDNumber
		{
			get { return m_idNumber; }
			set
			{
				if (value.Length > 50)
					m_idNumber = value.Substring(0, 50);
				else
					m_idNumber = value;
			}
		}

		public string		Description
		{
			get { return m_description; }
			set 
			{
				if (value.Length > 255)
					m_description = value.Substring(0, 255);
				else
					m_description = value;
			}
		}

		public string		Type
		{
			get { return m_type; }
			set 
			{
				if (value.Length > 255)
					m_type = value.Substring(0, 255);
				else
					m_type = value;
			}
		}

		public string		Size
		{
			get { return m_size; }
			set 
			{
				if (value.Length > 50)
					m_size = value.Substring(0, 50);
				else
					m_size = value;
			}
		}

		public short		InstallYear
		{
			get { return m_installYear; }
			set { m_installYear = value; }
		}

//		//mam 050806
//		public int ReplacementENR
//		{
//			get
//			{
//				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
//				Facility	facility = discipline.GetFacility();
//
//				if (facility != null)
//					return facility.GetENRValueForYear(m_replacementValueYear);
//
//				return 0;
//			}
//			set { m_replacementENR = value; }
//		}

		//mam 050806
		public int CurrentENR
		{
			get
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.CurrentENR;

				return 0;
			}
			set { m_currentENR = value; }
		}

		public int			OriginalENR
		{
			get
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(m_installYear);

				return 0;
			}
			set { m_originalENR = value; }
		}

		//mam 050806
		public decimal AcquisitionCostEscalated
		{
			get
			{
				if (OriginalENR == 0)
				{
					return 0;
				}

				return AcquisitionCost * (decimal)CurrentENR / (decimal)OriginalENR;
			}
		}

		public decimal		AcquisitionCost
		{
			//mam 050806 - new calculation

			//get { return m_acquisitionCost; }
			//set { m_acquisitionCost = value; }

			get
			{
				if (m_overrideAcquisitionCost)
				{
					return m_acquisitionCost;
				}
				else
				{
					//AC = Replacement Value * ENR Install Year / ENR Replacement Year

					int replacementYearENR = GetENRValueForYear((short)ReplacementValueYear);

					if (replacementYearENR == 0)
					{
						return 0;
					}

					return ReplacementValue * (decimal)OriginalENR / (decimal)replacementYearENR;
				}
			}
			set
			{
				m_acquisitionCost = value;
			}
		}

		//mam 050806
		public decimal RehabCost
		{
			get { return m_rehabCost; }
			set { m_rehabCost = value; }
		}

		//mam 050806
		public decimal CurrentValue
		{
			get 
			{ 
				//mam 112806 - take override into account
				//return m_currentValue; 
				if (m_overrideCurrentValue)
					return m_currentValue;
				else
					return GetCurrentValue();
			}
			set { m_currentValue = value; }
		}

		public decimal		ReplacementValue
		{
			get { return m_replacementValue; }
			set { m_replacementValue = value; }
		}

		public int		ReplacementValueYear
		{
			get { return m_replacementValueYear; }
			set { m_replacementValueYear = value; }
		}

		public decimal		SalvageValue
		{
			get { return m_salvageValue; }
			set { m_salvageValue = value; }
		}

		public decimal		AnnualMaintCost
		{
			get { return m_annualMaintCost; }
			set { m_annualMaintCost = value; }
		}

		public CondRank		ConditionRank
		{
			get { return m_conditionRank; }
			set { m_conditionRank = value; }
		}

		//mam 07072011 - provide a way for other objects to get the collection
		public MajorComponentSelectedCriticalityFactorsCollection ComponentSelectedCriticalityFactorsCollection
		{
			//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
			get { return nodeSelectedCritFactorCollection; }
			set { nodeSelectedCritFactorCollection = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityPublicHealth CritPublicHealth
//		{
//			get { return m_critPublic; }
//			set { m_critPublic = value; }
//		}
		public byte CritPublicHealth
		{
			get { return m_critPublic; }
			set { m_critPublic = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityEnvironmental CritEnvironmental
//		{
//			get { return m_critEnvironmental; }
//			set { m_critEnvironmental = value; }
//		}
		public byte CritEnvironmental
		{
			get { return m_critEnvironmental; }
			set { m_critEnvironmental = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityRepairCost CritRepair
//		{
//			get { return m_critRepair; }
//			set { m_critRepair = value; }
//		}
		public byte CritRepair
		{
			get { return m_critRepair; }
			set { m_critRepair = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityCustomerEffect CritCustEffect
//		{
//			get { return m_critCustEffect; }
//			set { m_critCustEffect = value; }
//		}
		public byte CritCustEffect
		{
			get { return m_critCustEffect; }
			set { m_critCustEffect = value; }
		}

		public LevelOfService LevelOfService
		{
			get { return m_LOS; }
			set { m_LOS = value; }
		}

		public Vulnerability Vulnerability
		{
			get { return m_vulnerability; }
			set { m_vulnerability = value; }
		}

		//mam
		public double Vulnerability2
		{
			get { return m_vulnerability2; }
			set { m_vulnerability2 = value; }
		}
		//</mam>

		//mam 050806
		public decimal RepairCost
		{
			get { return m_repairCost; }
			set { m_repairCost = value; }
		}
		//</mam>

		public short		OrgUsefulLife
		{
			get { return m_orgUsefulLife; }
			set { m_orgUsefulLife = value; }
		}

		//mam 050806
		public int RedundantAssetCount
		{
			get { return m_redundantAssetCount; }
			set { m_redundantAssetCount = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete()
		{
			this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
			using (SqlConnection connection = new SqlConnection(this.m_sqlConnectionString))
			{
				connection.Open();
				return this.Delete(connection);
			}
		}
		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete(SqlConnection sqlConnection)
		{
			//return base.Delete (sqlConnection);

			string deleteSql = this.GetDeleteSql();
			if (deleteSql.Length == 0)
			{
				return false;
			}
			try
			{
				new SqlCommand(deleteSql, sqlConnection).ExecuteNonQuery();
			}
			catch (SqlException exception)
			{
				throw exception;
			}
			InvokeChangeEvent(this, new DataChangeEventArgs(this, Drive.Synchronization.SyncAction.Delete));
			return true;
		}

		//mam 07072011 - new method to calculate overall criticality
		private double CalculateCritTotal()
		{
			double total = 0.0;

			foreach (MajorComponentSelectedCriticalityFactors critFactor in nodeSelectedCritFactorCollection)
			{
				total += ((double)critFactor.CriticalityWeight * critFactor.CritFactor.Score / 100);
			}

			return total;
		}

		//mam 050806 - change from int to double
		//public int GetOverallCriticality()
		public double GetOverallCriticality()
		{
			//mam 050806 - change from int to double
			//int				total = 0;
			double total = 0.0;

			//mam 07072011 - no longer using the four fixed crits
			//total += EnumHandlers.GetCritPublicHealthValue(m_critPublic);
			//total += EnumHandlers.GetCritEnvironmentalValue(m_critEnvironmental);
			//total += EnumHandlers.GetCritRepairCostValue(m_critRepair);
			//total += EnumHandlers.GetCritCustomerEffectValue(m_critCustEffect);

			//mam 07072011 - new way to calculate total
			total = CalculateCritTotal();

			//mam 050806
			//total /= RedundantAssetCount;
			//total = Math.Round(total, 1);

			//mam 112806
			total *= Convert.ToDouble(WAM.Common.CommonTasks.GetRedundantPercentage(RedundantAssetCount));

			//mam 01222012
			if (WAM.Common.Globals.ApplyFacilityCriticalityFactor)
			{
				//mam 03202012
				//Discipline discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
				Discipline discipline = CacheManager.GetDiscipline(InfoSet.CurrentID, m_discNodeID, DisciplineType.Nodes);

				total *= (double)(discipline.GetFacility().FacilityCriticality);
			}

			total = Math.Round(total, 1);

			return total;
		}

		public double		GetRisk()
		{
			//mam
			//return Math.Round(GetOverallCriticality() * 
			//	EnumHandlers.GetVulnerabilityValue(m_vulnerability), 2);

			return Math.Round(GetOverallCriticality() * m_vulnerability2, 2);

			//</mam>
		}

		//mam
		public double GetVulnerability()
		{
			if (m_overrideVulnerability)
				return m_vulnerability2;
			else
			{
				double evalRUL = GetEvaluatedRemainingUsefulLife();

				if (evalRUL == 0 && !OverrideVulnerability)
					return 0;

				m_vulnerability2 = (double)Math.Round(1 / (decimal)evalRUL, 4);
				return m_vulnerability2;
			}
		}
		//</mam>

		public double		GetCWP()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discNodeID, DisciplineType.Nodes);

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalCurrentValue = discipline.GetCurrentValue();
			decimal			totalCurrentValue = discipline.AcquisitionCost;

			if (totalCurrentValue == 0)
				return 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
            // Current Value / discipline Total Current Value 
			//return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
			return Math.Round((double)(AcquisitionCost / totalCurrentValue), 2);
		}

		//mam - add a routine that returns the unrounded CWP
		public double		GetCWP(bool roundValue)
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discNodeID, DisciplineType.Nodes);

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalCurrentValue = discipline.GetCurrentValue();
			decimal			totalCurrentValue = discipline.AcquisitionCost;

			if (totalCurrentValue == 0)
				return 0.0;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			// Current Value / discipline Total Current Value 
			if (roundValue)
			{
				//return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
				return Math.Round((double)(AcquisitionCost / totalCurrentValue), 2);
			}
			else
			{
				//return (double)(GetCurrentValue(false) / totalCurrentValue);
				return (double)(AcquisitionCost / totalCurrentValue);
			}
		}
		//</mam>

		//mam 112806 - added new CWP routine because the original CWP is now using AC, and the Pipes/Nodes Averages need CWP based on CV
		public double GetCWPCurrentValue()
		{
			Discipline		discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
			decimal			totalCurrentValue = discipline.GetCurrentValue();

			if (totalCurrentValue == 0)
				return 0.0;

			// Current Value / discipline Total Current Value 
			return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
		}

		//mam 112806 - added new CWP routine because the original CWP is now using AC, and the Pipes/Nodes Averages need CWP based on CV
		public double GetCWPCurrentValue(bool roundValue)
		{
			Discipline		discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
			decimal			totalCurrentValue = discipline.GetCurrentValue();

			if (totalCurrentValue == 0)
				return 0.0;

			// Current Value / discipline Total Current Value 
			if (roundValue)
			{
				return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
			}
			else
			{
				return (double)(GetCurrentValue(false) / totalCurrentValue);
			}
		}
		//</mam>

//		//mam 050806
//		public decimal GetAcquisitionCost()
//		{
//			return m_acquisitionCost;
//		}

		//mam 050806 - get ENR for Replacement Year
		public int GetENRValueForYear(short yearENR)
		{
			try
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(yearENR);

				return 0;
			}
			catch
			{
				return 0;
			}
		}
		//</mam>

		public decimal		GetCurrentValue()
		{
			if (m_overrideCurrentValue)
				return m_currentValue;

			//mam 112806 - comment
			//Discipline		discipline = CacheManager.GetDiscipline(m_infoSetID, m_discNodeID, DisciplineType.Nodes);

			//mam 050806
			//return Math.Round((AcquisitionCost * ((decimal)discipline.CurrentENR / (decimal)OriginalENR)), 0);

			//***********************

			//mam 050806 - new calculation for Current Value

			//if (OriginalENR == 0)
			//	return 0;

			//decimal tempCV = AcquisitionCost + RehabCost;
			//decimal tempACE = AcquisitionCostEscalated;
			//tempCV = tempCV > tempACE? tempACE: tempCV;
			//return Math.Round(tempCV, 0);

			//***********************

			//mam 050806 - update - new calculation for CV
			//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

			//mam 112806 - update - new calculation for CV
			//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

			//if there is no condition, the current value cannot be calculated
			if (ConditionRank == CondRank.No)
				return 0;

			decimal tempACE = AcquisitionCostEscalated;
			decimal condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
				
			//return Math.Round(tempACE + RehabCost - (tempACE * condPct), 0);

			//mam 112806
			return Math.Round((tempACE * condPct) + RehabCost, 0);
		}

		//mam - add a routine that returns the unrounded CurrentValue
		public decimal		GetCurrentValue(bool roundValue)
		{
			//mam 112806 - added check for overridden CV
			if (m_overrideCurrentValue)
			{
				if (roundValue)
				{
					return Math.Round(m_currentValue, 2);
				}
				else
				{
					return m_currentValue;
				}
			}
			if (roundValue)
			{
				//mam 050806
				//return Math.Round((AcquisitionCost * 
				//	((decimal)discipline.CurrentENR / (decimal)OriginalENR)), 0);
				return this.GetCurrentValue();
			}
			else
			{
				//mam 112806 - comment
				//Discipline		discipline = 
				//	CacheManager.GetDiscipline(m_infoSetID, 
				//	m_discNodeID, DisciplineType.Nodes);

				//mam 050806
				//if (OriginalENR == 0)
				//	return 0m;

				//mam 050806
				//return (AcquisitionCost * ((decimal)discipline.CurrentENR / (decimal)OriginalENR));

				//***********************

				//mam 050806 - new calculation for Current Value

				//if (OriginalENR == 0)
				//	return 0;

				//decimal tempCV = AcquisitionCost + RehabCost;
				//decimal tempACE = AcquisitionCostEscalated;
				//tempCV = tempCV > tempACE? tempACE: tempCV;
				//return tempCV;

				//***********************

				//mam 050806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

				//mam 112806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

				//if there is no condition, the current value cannot be calculated
				if (ConditionRank == CondRank.No)
					return 0;

				decimal tempACE = AcquisitionCostEscalated;
				decimal condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
				
				//return tempACE + RehabCost - (tempACE * condPct);

				//mam 112806
				return (tempACE * condPct) + RehabCost;
			}
		}
		//</mam>

		public decimal		GetBookValue()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discNodeID, DisciplineType.Nodes);

			// Acquisition Cost - (Annual Depreciation * 
			//   (Current Year - Installation Year))
			return Math.Round((AcquisitionCost - 
				(GetAnnualDepreciation() * 
				(discipline.CurrentYear - InstallYear))), 0);
		}

		public decimal		GetAnnualDepreciation()
		{
			// (Acquisition Cost - Salvage Value) / Original Useful Life
			if (OrgUsefulLife == 0)
				return 0m;

			return Math.Round(((AcquisitionCost - SalvageValue) / (decimal)OrgUsefulLife), 0);
		}

		public decimal		GetCumulativeDepreciation()
		{
			return AcquisitionCost - GetBookValue();
		}

		public decimal		GetEvaluatedValue()
		{
			//mam 050806 - new calculation for EV
			//EV = EAC * (1 - Condition Fraction)

			//return Math.Round(GetCurrentValue() * 
			//	(1m - (decimal)EnumHandlers.GetConditionRankValue(m_conditionRank)), 0);
			
			return Math.Round(AcquisitionCostEscalated * (1m - (decimal)EnumHandlers.GetConditionRankValue(m_conditionRank)), 0);
		}

		public decimal		GetRepairCost()
		{
			// Repair Cost = Current Value * ( Fraction associated with Condition - 
			//   Fraction associated with Level of Service ). 
			// 

			// If Condition is 0 or 5, and LOS is 1, Repair Cost = Replacement Cost. 
			// When Condition <= LOS, Repair Cost is 0.  Min of 0.

			//mam 050806
			if (m_overrideRepairCost)
				return m_repairCost;

			if ((m_conditionRank == CondRank.C0 ||
				m_conditionRank == CondRank.C5 || 
				m_conditionRank == CondRank.No) &&
				m_LOS == LevelOfService.LOS1)
			{
				return ReplacementValue;
			}

			// When condition <= LOS, repair cost = 0
			if (m_conditionRank != CondRank.No &&
				(byte)m_conditionRank <= (byte)m_LOS)
			{
				return 0;
			}

			// Get the condition percent modifier
			decimal			condPct = 
				(decimal)EnumHandlers.GetConditionRankValue(m_conditionRank);

			//new equation: Repair Cost = Current Value * (Condition Fraction � LOS Fraction)
			//original code:
			//decimal			repairCost = GetCurrentValue() * (1m - condPct);
			//new code:
			decimal losPct = (decimal)EnumHandlers.GetLOSValue(m_LOS );

			//mam 020607 - new equation for Repair Cost = EAC * (Cond - LOS)
			//decimal repairCost = GetCurrentValue() * (condPct - losPct);
			decimal repairCost = AcquisitionCostEscalated * (condPct - losPct);
			//</mam>

			// Min of 0
			if (repairCost < 0)
				return 0;
			
			return Math.Round(repairCost, 0);
		}

		public double		GetRemainingUsefulLife()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discNodeID, DisciplineType.Nodes);

			// Original Useful Life - (Current Year - Installation Year)
			return Math.Round((double)
				(OrgUsefulLife - (discipline.CurrentYear - InstallYear)), 1);
		}

		public double		GetEvaluatedRemainingUsefulLife()
		{
			// Evaluated Remaining Useful Life = (1 - (Fraction associated with Condition)) * 
			//	 Original Useful Life

			// This used to be Evaluated Remaining Useful Life
			if (ConditionRank == CondRank.No)
				return 0;

			//mam 051708 - get cond value for use in calculating useful life values
			// Get the condition percent modifier
			//decimal			condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
			decimal			condPct = 1m - EnumHandlers.GetConditionRankValueForUsefulLife(ConditionRank);

			return (double)Math.Round(((decimal)OrgUsefulLife * condPct), 1);
		}

		//mam
		public double GetEconomicUsefulLife()
		{
			//Economic Remaining Useful Life = (Original UL/2) - (Original UL * Condition Fraction)

			if (ConditionRank == CondRank.No)
				return 0;

			//mam 051708 - get cond value for use in calculating useful life values
			// Get the condition percent modifier
			//decimal condPct = EnumHandlers.GetConditionRankValue(ConditionRank);
			decimal condPct = EnumHandlers.GetConditionRankValueForUsefulLife(ConditionRank);

			return (double)(Math.Round((decimal)OrgUsefulLife / 2m - (decimal)OrgUsefulLife * condPct, 1));
		}
		//</mam>

		//mam
		public virtual bool	OverrideVulnerability
		{
			get { return m_overrideVulnerability; }
			set
			{
				if (m_overrideVulnerability == value)
					return;

				// Set to the default vulnerability when turning 
				// override on, and set back to zero when turning it off
				if (!m_overrideVulnerability)
					m_vulnerability2 = Math.Round(Vulnerability2, 4);
				//else
				//	m_vulnerability2 = 0;

				m_overrideVulnerability = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideRepairCost
		{
			get { return m_overrideRepairCost; }
			set
			{
				if (m_overrideRepairCost == value)
					return;

				//set Repair Cost to zero when turning override on
				//if (!m_overrideRepairCost)
					//m_repairCost = 0.0;

				m_overrideRepairCost = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideAcquisitionCost
		{
			get { return m_overrideAcquisitionCost; }
			set
			{
				if (m_overrideAcquisitionCost == value)
					return;

				m_overrideAcquisitionCost = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideCurrentValue
		{
			get { return m_overrideCurrentValue; }
			set
			{
				if (m_overrideCurrentValue == value)
					return;

				m_overrideCurrentValue = value;
			}
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Static Methods *****/

		private static string GetBaseSelect()
		{
			StringBuilder builder = new StringBuilder(150);

			builder.Append("SELECT ");
			builder.Append("node_id, ");
			builder.Append("discnode_id, ");
			builder.Append("node_IDNumber, ");
			builder.Append("node_description, ");
			builder.Append("node_type, ");
			builder.Append("node_size, ");
			builder.Append("node_installYear, ");
			builder.Append("node_originalENR, ");
			builder.Append("node_acquisitionCost, ");
			builder.Append("node_replacementValue, ");
			builder.Append("node_salvageValue, ");
			builder.Append("node_annualMaintCost, ");
			builder.Append("node_conditionRank, ");

			//mam 07072011 - no longer using the four fixed crits
			//builder.Append("node_critPublicHealth, ");
			//builder.Append("node_critEnvironmental, ");
			//builder.Append("node_critRepairCost, ");
			//builder.Append("node_critCustomerEffect, ");

			builder.Append("node_levelOfService, ");
			builder.Append("node_vulnerability, ");
			builder.Append("node_originalUsefulLife ");

			//mam
			builder.Append(", node_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", node_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");
			builder.Append("FROM NodeAppurtComponents ");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		#region /***** OleDb *****/

		//mam 102309
		private static NodeData[] LoadBulkOleDb(OleDbConnection sqlConnection, string query)
		//private static NodeData[] LoadBulk(SqlConnection sqlConnection, string query)
		{
			// open the database to retrieve info

			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			NodeData 		newObject = null;
			NodeData[]		typedArray;
			ArrayList		arrayList = new ArrayList();

			try
			{
				dataCommand = new OleDbCommand(query, sqlConnection);
				//dataCommand = new SqlCommand(query, sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					//mam 102309
					//newObject = new NodeData(dataReader);
					newObject = new NodeData(dataReader.GetInt32(0));

					//mam 11142011 - get the data for the node
					newObject.LoadRecordData(dataReader);

					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("NodeData.LoadForDiscipline Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			typedArray = new NodeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		public static NodeData[] LoadForDisciplineOleDb(int disciplineID)
		{
			return LoadForDisciplineOleDb(WamSourceOleDb.CurrentSource.ConnectionString, disciplineID);
			//return LoadForDiscipline(Globals.WamSqlConnectionString, disciplineID);
		}

		//mam 102309
		public static NodeData[] LoadForDisciplineOleDb(string connectionString, int disciplineID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			try
			{
				sqlConnection.Open();
				return LoadForDisciplineOleDb(sqlConnection, disciplineID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}
		}

		//mam 102309
		public static NodeData[] LoadForDisciplineOleDb(OleDbConnection sqlConnection, int disciplineID)
		//public static NodeData[] LoadForDiscipline(SqlConnection sqlConnection, int disciplineID)
		{
			//mam 11142011
			//StringBuilder	builder = new StringBuilder(GetBaseSelect());
			StringBuilder	builder = new StringBuilder(GetBaseSelectOleDb());

			builder.AppendFormat("WHERE (discnode_id={0}) ", disciplineID);
			return LoadBulkOleDb(sqlConnection, builder.ToString());
		}

//		public static NodeData[] LoadForDisciplineAndNodeID(int disciplineID, string nodeID)
//		{
//			StringBuilder	builder = new StringBuilder(GetBaseSelect());
//
//			//mam 102309
//			//OleDbConnection sqlConnection = new OleDbConnection(WAMSource.CurrentSource.ConnectionString);
//			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);
//
//			NodeData[]		nodeData = null;
//
//			builder.AppendFormat("WHERE (discnode_id={0} AND node_IDNumber='{1}') ", 
//				disciplineID, Drive.SQL.PadString(nodeID));
//
//			try
//			{
//				sqlConnection.Open();
//				nodeData = LoadBulk(sqlConnection, builder.ToString());
//			}
//			catch
//			{
//				nodeData = new NodeData[0];
//			}
//			finally
//			{
//				if (sqlConnection != null)
//					sqlConnection.Dispose();
//			}
//
//			return nodeData;
//		}

		//mam 11142011 - new method need this when importing from Access
		private static string GetBaseSelectOleDb()
		{
			StringBuilder builder = new StringBuilder(150);

			builder.Append("SELECT ");
			builder.Append("node_id, ");
			builder.Append("discnode_id, ");
			builder.Append("node_IDNumber, ");
			builder.Append("node_description, ");
			builder.Append("node_type, ");
			builder.Append("node_size, ");
			builder.Append("node_installYear, ");
			builder.Append("node_originalENR, ");
			builder.Append("node_acquisitionCost, ");
			builder.Append("node_replacementValue, ");
			builder.Append("node_salvageValue, ");
			builder.Append("node_annualMaintCost, ");
			builder.Append("node_conditionRank, ");

			builder.Append("node_critPublicHealth, ");
			builder.Append("node_critEnvironmental, ");
			builder.Append("node_critRepairCost, ");
			builder.Append("node_critCustomerEffect, ");

			builder.Append("node_levelOfService, ");
			builder.Append("node_vulnerability, ");
			builder.Append("node_originalUsefulLife ");

			//mam
			builder.Append(", node_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", node_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");
			builder.Append("FROM NodeAppurtComponents ");

			return builder.ToString();
		}

		#endregion /***** OleDb *****/

		//mam 102309
		//private static NodeData[] LoadBulk(OleDbConnection sqlConnection, string query)
		private static NodeData[] LoadBulk(SqlConnection sqlConnection, string query)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			NodeData 		newObject = null;
			NodeData[]		typedArray;
			ArrayList		arrayList = new ArrayList();

			//mam 07072011
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(query, sqlConnection);
				dataCommand = new SqlCommand(query, sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new NodeData(dataReader);
					if (newObject.ID != 0)
					{
						//mam 07072011 - load crit values into new object
						System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityNode", "@nodeId", newObject.ID);
						newObject.ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(dataTable);

						arrayList.Add(newObject);
					}
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("NodeData.LoadForDiscipline Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				//mam 07072011
				dataAccess = null;
			}

			typedArray = new NodeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		public static NodeData[] LoadForDiscipline(int disciplineID)
		{
			//mam 102309
			//return LoadForDiscipline(WAMSource.CurrentSource.ConnectionString, disciplineID);
			return LoadForDiscipline(Globals.WamSqlConnectionString, disciplineID);
		}

		public static NodeData[] LoadForDiscipline(string connectionString, int disciplineID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			try
			{
				sqlConnection.Open();
				return LoadForDiscipline(sqlConnection, disciplineID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}
		}

		//mam 102309
		//public static NodeData[] LoadForDiscipline(OleDbConnection sqlConnection, int disciplineID)
		public static NodeData[] LoadForDiscipline(SqlConnection sqlConnection, int disciplineID)
		{
			StringBuilder	builder = new StringBuilder(GetBaseSelect());

			builder.AppendFormat("WHERE (discnode_id={0}) ", disciplineID);
			return LoadBulk(sqlConnection, builder.ToString());
		}

		//mam 03202012
		//@@@@
		public static NodeData[] LoadForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			NodeData newObject = null;
			NodeData[] typedArray;
			ArrayList arrayList = new ArrayList();

			StringBuilder builder = new StringBuilder();

			builder.Append("SELECT NC.node_id, NC.discnode_id, NC.node_IDNumber, NC.node_description, NC.node_type");
			builder.Append(", NC.node_size, NC.node_installYear, NC.node_originalENR, NC.node_acquisitionCost");
			builder.Append(", NC.node_replacementValue, NC.node_salvageValue, NC.node_annualMaintCost, NC.node_conditionRank");
			builder.Append(", NC.node_levelOfService, NC.node_vulnerability, NC.node_originalUsefulLife , NC.node_vulnerability2");
			builder.Append(", NC.ReplacementValueYear, NC.RepairCost, NC.node_currentValue, NC.RehabCost, NC.RedundantAssetCount ");
			builder.Append(" FROM NodeAppurtComponents NC LEFT JOIN DisciplineNodes D ON NC.discnode_id = D.discnode_id");
			builder.Append(" LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);


			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			//get the active crits for all components
			//System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityNode", "@componentId", 0);
			StringBuilder builderCrits = new StringBuilder();
			builderCrits.Append("SELECT M.node_id, M.CriticalityId, C.Criticality, C.CriticalityWeight, C.Active");
			builderCrits.Append(", S.CriticalityScore");
			builderCrits.Append(", CS.CriticalityToScoreId, M.CriticalityScoreId, CS.CriticalityFactor");
			builderCrits.Append(", C.OrderBy AS CriticalityOrderBy, S.OrderBy AS FactorOrderBy");
			builderCrits.Append(" FROM NodeToCriticality M");
			builderCrits.Append(" INNER JOIN NodeAppurtComponents MC ON M.node_id = MC.node_id");
			builderCrits.Append(" INNER JOIN CriticalityScore S ON M.CriticalityScoreId = S.CriticalityScoreId");
			builderCrits.Append(" INNER JOIN Criticality C ON M.CriticalityId = C.CriticalityId");
			builderCrits.Append(" INNER JOIN CriticalityToScore CS ON M.CriticalityScoreId = CS.CriticalityScoreId AND M.CriticalityId = CS.CriticalityId");
			builderCrits.Append(" LEFT JOIN DisciplineNodes D ON MC.discnode_id = D.discnode_id");
			builderCrits.Append(" LEFT JOIN MajorComponents M2 ON D.component_id = M2.component_id");
			builderCrits.Append(" LEFT JOIN TreatmentProcesses P ON M2.process_id = P.process_id");
			builderCrits.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builderCrits.AppendFormat(" WHERE C.Active = 'true' AND F.infoset_id = {0}", infosetId);
			builderCrits.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id");
			builderCrits.Append(", M2.component_sortOrder, M2.component_id, C.OrderBy, S.OrderBy");

			try
			{
				System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTable(builderCrits.ToString());

				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new NodeData(dataReader);
					if (newObject.ID != 0)
					{
						//System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityNode", "@nodeId", newObject.ID);
						DataRow[] rows = dataTableCritsAll.Select("node_id = " + newObject.ID);
						newObject.ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(rows);

						arrayList.Add(newObject);
					}
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("NodeData.LoadBulk Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				dataAccess = null;
			}

			typedArray = new NodeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		public static NodeData[] LoadForDisciplineAndNodeID(int disciplineID, string nodeID)
		{
			StringBuilder	builder = new StringBuilder(GetBaseSelect());

			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(WAMSource.CurrentSource.ConnectionString);
			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);

			NodeData[]		nodeData = null;

			builder.AppendFormat("WHERE (discnode_id={0} AND node_IDNumber='{1}') ", 
				disciplineID, Drive.SQL.PadString(nodeID));

			try
			{
				sqlConnection.Open();
				nodeData = LoadBulk(sqlConnection, builder.ToString());
			}
			catch
			{
				nodeData = new NodeData[0];
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return nodeData;
		}

		//mam 07072011
		private static MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesForComponent(System.Data.DataTable dataTable)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			//int counter = 0;
			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				//counter++;

				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				//curCrit.CriticalityNumber = counter;
				curCrit.CriticalityNumber = ((Criticality)Common.CommonTasks.Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				//critColl.Add(curCrit);
				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}
		//</mam>

		//mam 03202012
		//@@@@
		private static MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesForComponent(System.Data.DataRow[] dataRows)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in dataRows)
			{
				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				curCrit.CriticalityNumber = ((Criticality)Common.CommonTasks.Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}

		#endregion /***** Static Methods *****/

		#region /***** ICloneable Members *****/
		public object		Clone()
		{
			NodeData		node = new NodeData(0);

			node.m_id = m_id;
			node.CopyFrom(this);
			return node;
		}

		public void			CopyFrom(NodeData rhs)
		{
			m_discNodeID = rhs.m_discNodeID;
			m_idNumber = rhs.m_idNumber;
			m_description = rhs.m_description;
			m_type = rhs.m_type;
			m_size = rhs.m_size;
			m_installYear = rhs.m_installYear;
			m_originalENR = rhs.m_originalENR;
			m_acquisitionCost = rhs.m_acquisitionCost;
			m_replacementValue = rhs.m_replacementValue;
			m_salvageValue = rhs.m_salvageValue;
			m_annualMaintCost = rhs.m_annualMaintCost;
			m_conditionRank = rhs.m_conditionRank;

			//mam 07072011 - no longer using the four fixed crits
			//m_critPublic = rhs.m_critPublic;
			//m_critEnvironmental = rhs.m_critEnvironmental;
			//m_critRepair = rhs.m_critRepair;
			//m_critCustEffect = rhs.m_critCustEffect;

			//mam 07072011
			ComponentSelectedCriticalityFactorsCollection = rhs.ComponentSelectedCriticalityFactorsCollection;

			m_LOS = rhs.m_LOS;
			m_vulnerability = rhs.m_vulnerability;
			m_orgUsefulLife = rhs.m_orgUsefulLife;

			//mam
			m_vulnerability2 = rhs.m_vulnerability2;
			m_overrideVulnerability = rhs.m_overrideVulnerability;
			//</mam>

			//mam 050806
			m_replacementValueYear = rhs.m_replacementValueYear;
			m_repairCost = rhs.m_repairCost;
			m_overrideRepairCost = rhs.m_overrideRepairCost;
			m_currentValue = rhs.m_currentValue;
			m_overrideCurrentValue = rhs.m_overrideCurrentValue;
			m_rehabCost = rhs.m_rehabCost;
			m_redundantAssetCount = rhs.m_redundantAssetCount;
			m_overrideAcquisitionCost = rhs.m_overrideAcquisitionCost;
		}
		
		public void			CopyTo(NodeData copy)
		{
			copy.m_discNodeID = 0;
			copy.m_idNumber = m_idNumber;
			copy.m_description = m_description;
			copy.m_type = m_type;
			copy.m_size = m_size;
			copy.m_installYear = m_installYear;
			copy.m_originalENR = m_originalENR;
			copy.m_acquisitionCost = m_acquisitionCost;
			copy.m_replacementValue = m_replacementValue;
			copy.m_salvageValue = m_salvageValue;
			copy.m_annualMaintCost = m_annualMaintCost;
			copy.m_conditionRank = m_conditionRank;

			//mam 07072011 - no longer using four fixed criticalities
			//copy.m_critPublic = m_critPublic;
			//copy.m_critEnvironmental = m_critEnvironmental;
			//copy.m_critRepair = m_critRepair;
			//copy.m_critCustEffect = m_critCustEffect;

			//mam 07072011
			copy.ComponentSelectedCriticalityFactorsCollection = ComponentSelectedCriticalityFactorsCollection;

			copy.m_LOS = m_LOS;
			copy.m_vulnerability = m_vulnerability;
			copy.m_orgUsefulLife = m_orgUsefulLife;

			//mam
			copy.m_vulnerability2 = m_vulnerability2;
			copy.m_overrideVulnerability = m_overrideVulnerability;
			//</mam>

			//mam 050806
			copy.m_replacementValueYear = m_replacementValueYear;
			copy.m_repairCost = m_repairCost;
			copy.m_overrideRepairCost = m_overrideRepairCost;
			copy.m_currentValue = m_currentValue;
			copy.m_overrideCurrentValue = m_overrideCurrentValue;
			copy.m_rehabCost = m_rehabCost;
			copy.m_redundantAssetCount = m_redundantAssetCount;
			copy.m_overrideAcquisitionCost = m_overrideAcquisitionCost;
		}
		#endregion /***** ICloneable Members *****/
	}

	#region /***** Cache Class *****/
	public class			NodeDataCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable();

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.NodeData));
		private int			m_infoSetID = 0;

		public				NodeDataCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged));
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged));
		}

		#region IDisposable Members
		~NodeDataCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SuppressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		//mam 102309
		//private void DataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			NodeData obj = e.ChangedObject as NodeData;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.DiscNodeID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.DiscNodeID, obj);
			}
		}

		public NodeData[] GetForDiscipline(int id)
		{
			NodeData[] children = (NodeData[])m_treeHash.GetChildren(id);

			if (children == null)
			{
				children = NodeData.LoadForDiscipline(id);
				m_treeHash.SetChildren(id, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					// Set info set for cache matching purposes
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}

			return children;
		}

		//mam 102309
		//public NodeData[] BuildCacheForDiscipline(OleDbConnection connection, int id)
		public NodeData[] BuildCacheForDiscipline(SqlConnection connection, int id)
		{
			NodeData[] children = NodeData.LoadForDiscipline(connection, id);

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				// Set info set for cache matching purposes
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		//mam 03202012
		//@@@@
		public NodeData[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			NodeData[] children = NodeData.LoadForInfoset(connection, infosetId);

			foreach (NodeData nodeData in children)
			{
				m_treeHash.AddChild(nodeData.DiscNodeID, nodeData);

				nodeData.InfoSetID = m_infoSetID;
				m_hash[nodeData.GetHashCode()] = nodeData;
			}

			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		public NodeData GetNodeData(int id)
		{
			// Look up the components in the hash table
			NodeData node = m_hash[id.GetHashCode()] as NodeData;

			// If the component is not present, load it from the default database
			if (node == null)
			{
				node = new NodeData(id);
				node.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (node.ID != 0)
					m_hash[node.GetHashCode()] = node;
				else
					node = null;
			}

			return node;
		}
	}
	#endregion /***** Cache Class *****/
}