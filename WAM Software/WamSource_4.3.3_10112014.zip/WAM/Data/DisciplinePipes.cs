using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for DisciplinePipe.
	/// </summary>
	public class DisciplinePipe : Discipline
	{
		#region /***** Member Variables *****/
		private DateTime	m_dateInspected = DateTime.Now.Date;
		private string		m_assessedBy = "";
		private string		m_photoCaption = "";
		private string		m_comments = "";

		//mam
		bool isNA = false;
		bool allERULzero = false;
		bool anyORVuln = false;
		decimal totalCurrentValueSort = 0;
		//</mam>

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public DisciplinePipe(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public DisciplinePipe(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public DisciplinePipe(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//public DisciplinePipe(System.Data.OleDb.OleDbConnection sqlConnection, int id)
		//	: base(sqlConnection.ConnectionString, id)
		public DisciplinePipe(SqlConnection sqlConnection, int id)
			: base(sqlConnection.ConnectionString, id)
		{
		}

		//mam 102309
		//protected DisciplinePipe(System.Data.OleDb.OleDbConnection sqlConnection, System.Data.OleDb.OleDbDataReader reader)
		//	: base(sqlConnection, reader)
		protected DisciplinePipe(SqlConnection sqlConnection, SqlDataReader reader)
			: base(sqlConnection, reader)
			{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			//mam 102309
			//m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			//m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_assessedBy = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_photoCaption = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
		}

		//mam 03202012
		//@@@@
		protected void LoadRecordData(DataRow dataRow)
		{
			m_id = dataRow["discpipe_id"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["discpipe_id"]);

			if (m_id == 0)
			{
				m_componentID = Convert.ToInt32(dataRow["ComponentId"]);
				m_currentENR = 0;
				short facilityYear = Convert.ToInt16(dataRow["facility_currentYear"]);
				m_dateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
				m_inspectionYear = m_dateInspected;
				m_assessedBy = "";
				m_photoCaption = "";
				m_comments = "";

				return;
			}

			m_componentID = Convert.ToInt32(dataRow["component_id"]);
			m_currentENR = dataRow["discpipe_currentENR"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["discpipe_currentENR"]);
			m_dateInspected = Convert.ToDateTime(dataRow["discpipe_dateInspected"]);
			m_inspectionYear = m_dateInspected;
			m_assessedBy = dataRow["discpipe_assessedBy"] == DBNull.Value ? "" : dataRow["discpipe_assessedBy"].ToString();
			m_photoCaption = dataRow["discpipe_photoCaption"] == DBNull.Value ? "" : dataRow["discpipe_photoCaption"].ToString();
			m_comments = dataRow["discpipe_comments"] == DBNull.Value ? "" : dataRow["discpipe_comments"].ToString();
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/

		//mam - compare Disciplines by their various values
		public new int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)		
		{
			DisciplinePipe rhs = obj as DisciplinePipe;
			int result = 0;

			this.totalCurrentValueSort = this.GetCurrentValue();
			rhs.totalCurrentValueSort = rhs.GetCurrentValue();

			this.isNA = GetAllConditionNA(this);
			this.allERULzero = GetAllERULZero(this);
			this.anyORVuln = GetAnyVulnerabilityOverridden(this);

			rhs.isNA = GetAllConditionNA(rhs);
			rhs.allERULzero = GetAllERULZero(rhs);
			rhs.anyORVuln = GetAnyVulnerabilityOverridden(rhs);

			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a discipline");

			return result;
		}
		//</mam>

		//mam - compare Disciplines by their various values
		private int CompareToEach(DisciplinePipe rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;
			
			switch (which)
			{
				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
				//mam

				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.AcquisitionCost.CompareTo(rhs.AcquisitionCost);
					else
						result = rhs.AcquisitionCost.CompareTo(this.AcquisitionCost);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.AcquisitionCostEscalated.CompareTo(rhs.AcquisitionCostEscalated);
					else
						result = rhs.AcquisitionCostEscalated.CompareTo(this.AcquisitionCostEscalated);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.RehabCost.CompareTo(rhs.RehabCost);
					else
						result = rhs.RehabCost.CompareTo(this.RehabCost);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.ReplacementValue.CompareTo(rhs.ReplacementValue);
					else
						result = rhs.ReplacementValue.CompareTo(this.ReplacementValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.SalvageValue.CompareTo(rhs.SalvageValue);
					else
						result = rhs.SalvageValue.CompareTo(this.SalvageValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetEvaluatedValueLocal().CompareTo(rhs.SortGetEvaluatedValueLocal());
					else
						result = rhs.SortGetEvaluatedValueLocal().CompareTo(this.SortGetEvaluatedValueLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRepairCostLocal().CompareTo(rhs.SortGetRepairCostLocal());
					else
						result = rhs.SortGetRepairCostLocal().CompareTo(this.SortGetRepairCostLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.AnnualMaintCost.CompareTo(rhs.AnnualMaintCost);
					else
						result = rhs.AnnualMaintCost.CompareTo(this.AnnualMaintCost);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InstallYear:
					if (lowToHigh)
						result = this.InstallationYear.CompareTo(rhs.InstallationYear);
					else
						result = rhs.InstallationYear.CompareTo(this.InstallationYear);
					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValueYear:
					if (lowToHigh)
						result = this.ReplacementValueYear.CompareTo(rhs.ReplacementValueYear);
					else
						result = rhs.ReplacementValueYear.CompareTo(this.ReplacementValueYear);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InspectionYear:
					if (lowToHigh)
						result = this.DateInspected.CompareTo(rhs.DateInspected);
					else
						result = rhs.DateInspected.CompareTo(this.DateInspected);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortOrgUsefulLifeLocal().CompareTo(rhs.SortOrgUsefulLifeLocal());
					else
						result = rhs.SortOrgUsefulLifeLocal().CompareTo(this.SortOrgUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRemainingUsefulLifeLocal().CompareTo(rhs.SortGetRemainingUsefulLifeLocal());
					else
						result = rhs.SortGetRemainingUsefulLifeLocal().CompareTo(this.SortGetRemainingUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetEvaluatedRemainingUsefulLifeLocal().CompareTo(rhs.SortGetEvaluatedRemainingUsefulLifeLocal());
					else
						result = rhs.SortGetEvaluatedRemainingUsefulLifeLocal().CompareTo(this.SortGetEvaluatedRemainingUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
					if (lowToHigh)
						result = this.SortGetEconomicUsefulLifeLocal().CompareTo(rhs.SortGetEconomicUsefulLifeLocal());
					else
						result = rhs.SortGetEconomicUsefulLifeLocal().CompareTo(this.SortGetEconomicUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortConditionRankingLocal.CompareTo(rhs.SortConditionRankingLocal);
					else
						result = rhs.SortConditionRankingLocal.CompareTo(this.SortConditionRankingLocal);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetLevelOfServiceLocal().CompareTo(rhs.SortGetLevelOfServiceLocal());
					else
						result = rhs.SortGetLevelOfServiceLocal().CompareTo(this.SortGetLevelOfServiceLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetOverallCriticalityLocal().CompareTo(rhs.SortGetOverallCriticalityLocal());
					else
						result = rhs.SortGetOverallCriticalityLocal().CompareTo(this.SortGetOverallCriticalityLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetVulnerabilityLocal().CompareTo(rhs.SortGetVulnerabilityLocal());
					else
						result = rhs.SortGetVulnerabilityLocal().CompareTo(this.SortGetVulnerabilityLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRiskLocal().CompareTo(rhs.SortGetRiskLocal());
					else
						result = rhs.SortGetRiskLocal().CompareTo(this.SortGetRiskLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;

			}
			return result;
		}
		//</mam>
		#endregion /***** IComparable Members *****/

		#region /***** Nested Class DisciplineComparer *****/
		//mam
		public class DisciplineComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				DisciplinePipe l = (DisciplinePipe) lhs;
				DisciplinePipe r = (DisciplinePipe) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}
			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class DisciplineComparer *****/

		#region /****** SQL Statements ******/

		//mam 102309
		//protected override string GetLoadSql(object id)
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("discpipe_id, ");
			builder.Append("component_id, ");
			builder.Append("discpipe_currentENR, ");
			builder.Append("discpipe_dateInspected, ");
			builder.Append("discpipe_assessedBy, ");
			builder.Append("discpipe_photoCaption, ");
			builder.Append("discpipe_comments ");
			builder.Append("FROM DisciplinePipes ");
			builder.AppendFormat("WHERE discpipe_id={0}", id);

			return builder.ToString();
		}

		//mam 102309
//		public override string GetInsertSqlForCopy()
//		{
//			return GetInsertSql();
//		}

		//mam 102309
		//public override string GetUpdateSqlForImport()
		//{
		//	return GetUpdateSql();
		//}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			//mam 03202012 - if the user doesn't have write permission, don't show the save error
			if (!WAM.Common.Globals.UserHasWritePermission)
			{
				return true;
			}

			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - added bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
						//InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
					}

					//mam - add discipline to cache manually, below;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));

//					//the discipline is not getting added to the cache by calling InvokeChangeEvent - add it manually
//					if (add == Drive.Synchronization.SyncAction.Add)
//					{
//						DisciplineCache disciplineCache = CacheManager.GetDisciplineCache(this.InfoSetID);
//						disciplineCache.AddDisciplineToCache(this.ComponentID, this);
//					}
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO DisciplinePipes (");
			builder.Append("component_id, ");
			builder.Append("discpipe_currentENR, ");
			builder.Append("discpipe_dateInspected, ");
			builder.Append("discpipe_assessedBy, ");
			builder.Append("discpipe_photoCaption, ");
			builder.Append("discpipe_comments ");
			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("{0}, ", m_currentENR);
			builder.AppendFormat("'{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption));
			builder.AppendFormat("{0} ", Drive.SQL.StringToDBString(m_comments));
			builder.Append(")");

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE DisciplinePipes SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("discpipe_currentENR={0}, ", m_currentENR);
			builder.AppendFormat("discpipe_dateInspected='{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("discpipe_assessedBy='{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("discpipe_photoCaption={0}, ", Drive.SQL.StringToDBString(m_photoCaption));
			builder.AppendFormat("discpipe_comments={0} ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("WHERE (discpipe_id={0}) ", ID);
			return builder.ToString();
		}

		//mam 102309
		//protected override string GetDeleteSql()
		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From DisciplinePipes WHERE discpipe_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public override string Name
		{
			get { return "Pipes"; }
		}

		public override DisciplineType Type
		{
			get { return DisciplineType.Pipes; }
		}

		public DateTime		DateInspected
		{
			get { return m_dateInspected; }
			set 
			{ 
				m_dateInspected = value; 

				//mam
				//m_inspectionYear = m_dateInspected.Year;
				m_inspectionYear = m_dateInspected;
				//</mam>
			}
		}

		public string		AssessedBy
		{
			get { return m_assessedBy; }
			set
			{
				if (value.Length > 255)
					m_assessedBy = value.Substring(255);
				else
					m_assessedBy = value;
			}
		}

		public string		CaptionPhoto
		{
			get { return m_photoCaption; }
			set
			{
				if (value.Length > 255)
					m_photoCaption = value.Substring(255);
				else
					m_photoCaption = value;
			}
		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}
		#endregion /***** Properties *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static DisciplinePipe LoadForComponentOleDb(int componentID)
		{
			return LoadForComponent(WamSourceOleDb.CurrentSource.ConnectionString, componentID);
			//return LoadForComponent(Globals.WamSqlConnectionString, componentID);
		}

		//mam 102309
		public static DisciplinePipe LoadForComponentOleDb(string connectionString, int componentID)
		{
			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			DisciplinePipe retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponentOleDb(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static DisciplinePipe LoadForComponentOleDb(OleDbConnection sqlConnection, int componentID)
		//public static DisciplinePipe LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			DisciplinePipe		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("discpipe_id, ");
			builder.Append("component_id, ");
			builder.Append("discpipe_currentENR, ");
			builder.Append("discpipe_dateInspected, ");
			builder.Append("discpipe_assessedBy, ");
			builder.Append("discpipe_photoCaption, ");
			builder.Append("discpipe_comments ");
			builder.Append("FROM DisciplinePipes ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
				{
					//newObject = new DisciplinePipe(sqlConnection, dataReader);
					newObject = new DisciplinePipe(0);
					newObject.LoadRecordData(dataReader);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplinePipe.LoadForComponent Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				//mam 102309
				//newObject = new DisciplinePipe(sqlConnection, 0);
				newObject = new DisciplinePipe(0);

				newObject.ComponentID = componentID;
			}
			
			return newObject;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static DisciplinePipe LoadForComponent(int componentID)
		{
			//mam 102309
			//return LoadForComponent(WAMSource.CurrentSource.ConnectionString, componentID);
			return LoadForComponent(Globals.WamSqlConnectionString, componentID);
		}

		public static DisciplinePipe LoadForComponent(string connectionString, int componentID)
		{
			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			DisciplinePipe retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponent(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static DisciplinePipe LoadForComponent(OleDbConnection sqlConnection, int componentID)
		public static DisciplinePipe LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			DisciplinePipe		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("discpipe_id, ");
			builder.Append("component_id, ");
			builder.Append("discpipe_currentENR, ");
			builder.Append("discpipe_dateInspected, ");
			builder.Append("discpipe_assessedBy, ");
			builder.Append("discpipe_photoCaption, ");
			builder.Append("discpipe_comments ");
			builder.Append("FROM DisciplinePipes ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
					newObject = new DisciplinePipe(sqlConnection, dataReader);
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplinePipe.LoadForComponent Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				newObject = new DisciplinePipe(sqlConnection, 0);
				newObject.ComponentID = componentID;

				//mam 03202012 - set default date inspected to the facility year (so it won't violate timing constraints)
				short facilityYear = newObject.GetFacility().CurrentYear;
				newObject.DateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
				newObject.InspectionYear = Convert.ToDateTime("1/1/" + facilityYear.ToString());
			}
			
			return newObject;
		}

		//mam 03202012
		//@@@@
		public static DisciplinePipe[] LoadForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			DisciplinePipe newObject = null;
			StringBuilder builder = new StringBuilder(400);

			DisciplinePipe[] typedArray;
			ArrayList arrayList = new ArrayList();

			//builder.Append("SELECT ");
			//builder.Append("discpipe_id, ");
			//builder.Append("component_id, ");
			//builder.Append("discpipe_currentENR, ");
			//builder.Append("discpipe_dateInspected, ");
			//builder.Append("discpipe_assessedBy, ");
			//builder.Append("discpipe_photoCaption, ");
			//builder.Append("discpipe_comments ");
			//builder.Append("FROM DisciplinePipes ");
			//builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			builder.Append("SELECT D.discpipe_id, D.component_id, D.discpipe_currentENR, D.discpipe_dateInspected");
			builder.Append(" , D.discpipe_assessedBy, D.discpipe_photoCaption, D.discpipe_comments, C.component_id AS ComponentId, F.facility_currentYear");
			builder.Append(" FROM DisciplinePipes D LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.Append(" UNION ALL");
			builder.Append(" SELECT D.discpipe_id, D.component_id, D.discpipe_currentENR, D.discpipe_dateInspected");
			builder.Append(" , D.discpipe_assessedBy, D.discpipe_photoCaption, D.discpipe_comments, C.component_id, F.facility_currentYear");
			builder.Append(" FROM MajorComponents C LEFT JOIN DisciplinePipes D ON C.component_id = D.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0} AND C.component_id NOT IN (SELECT component_id FROM DisciplinePipes)", infosetId);
			builder.Append(" AND C.component_MechStructDisc != 1");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				SqlDataAdapter adapter = new SqlDataAdapter();
				System.Data.DataTable dataTable = new System.Data.DataTable();
				adapter.SelectCommand = new SqlCommand(builder.ToString(), sqlConnection);
				adapter.Fill(dataTable);

				foreach (DataRow dataRow in dataTable.Rows)
				{
					//newObject = new DisciplinePipe(sqlConnection, 0);
					//newObject.ComponentID = componentID;

					newObject = new DisciplinePipe(0);
					newObject.LoadRecordData(dataRow);
					arrayList.Add(newObject);
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DisciplinePipe.LoadForInfoset Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
			}

			typedArray = new DisciplinePipe[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods *****/

		#region / ***** Local Calculation Properties and Methods for Sorting *****/

		public short SortOrgUsefulLifeLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else
				return (short)Math.Round((double)OrgUsefulLife, 1);
		}

		public double SortGetRemainingUsefulLifeLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else
			{
				return Math.Round(GetRemainingUsefulLife(), 1);
			}
		}

		public double SortGetEvaluatedRemainingUsefulLifeLocal()
		{
			if (totalCurrentValueSort == 0 || isNA)
				return -1;
			else
				return Math.Round(GetEvaluatedRemainingUsefulLife(), 1);
		}

		//mam
		public double SortGetEconomicUsefulLifeLocal()
		{
			if (totalCurrentValueSort == 0 || isNA)
				return -1;
			else
				return Math.Round(GetEconomicUsefulLife(), 1);
		}
		//</mam>

		public decimal SortGetRepairCostLocal()
		{
			if (isNA)
				return -1;
			else
				return Math.Round(GetRepairCost(), 0);
		}

		public decimal SortGetEvaluatedValueLocal()
		{
			if (isNA)
				return -1;
			else
				return Math.Round(GetEvaluatedValue(), 0);
		}

		//mam - new method to return value based on Discipline type
		public decimal SortConditionRankingLocal
		{
			get 
			{ 
				if (totalCurrentValueSort == 0 || isNA)
					return -1;
				else
					return (decimal)Math.Round(GetAverageCondition(), 1);
			}
			set {}
		}

		//mam
		public decimal SortGetLevelOfServiceLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else
				return Math.Round(GetAverageLOS(), 1);
		}
		//</mam>

		//mam
		public double SortGetOverallCriticalityLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else
				return Math.Round(GetAverageCriticality(), 1);
		}
		//</mam>

		//mam
		public decimal SortGetVulnerabilityLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else if (isNA && allERULzero && !anyORVuln)
				return -1;
			else
				return Math.Round(GetAverageVulnerability(), 4);
		}
		//</mam>

		//mam
		public double SortGetRiskLocal()
		{
			if (totalCurrentValueSort == 0)
				return -1;
			else if (isNA && allERULzero && !anyORVuln)
				return -1;
			else
				return Math.Round(GetAverageRisk(), 2);
		}
		//</mam>

		#endregion / ***** Local Calculation Properties and Methods for Sorting *****/

		#region / ***** Overrides for Calculation Properties and Methods for Sorting *****/

		public override short SortOrgUsefulLife()
		{
			return (short)Math.Round((double)OrgUsefulLife, 1);
		}

		public override double SortGetRemainingUsefulLife()
		{
			return (double)Math.Round(GetRemainingUsefulLife(), 1);
		}

		public override double SortGetEvaluatedRemainingUsefulLife()
		{
			return Math.Round(GetEvaluatedRemainingUsefulLife(), 1);
		}

		public override double SortGetEconomicUsefulLife()
		{
			return Math.Round(GetEconomicUsefulLife(), 1);
		}

		public override decimal SortGetRepairCost()
		{
			return Math.Round(GetRepairCost(), 0);
		}

		public override decimal SortGetEvaluatedValue()
		{
			return Math.Round(GetEvaluatedValue(), 0);
		}

		//mam - new method to return value based on Discipline type
		public override decimal SortConditionRanking
		{
			get 
			{ 
				return (decimal)Math.Round(GetAverageCondition(), 1);
			}
			set {}
		}

		//mam
		public override decimal SortGetLevelOfService()
		{
			return Math.Round(GetAverageLOS(), 1);
		}
		//</mam>

		//mam
		public override double SortGetOverallCriticality()
		{
			return Math.Round(GetAverageCriticality(), 1);
		}
		//</mam>

		//mam
		public override decimal SortGetVulnerability()
		{
			return Math.Round(GetAverageVulnerability(), 4);
		}
		//</mam>

		//mam
		public override double SortGetRisk()
		{
			return Math.Round(GetAverageRisk(), 2);
		}
		//</mam>

		#endregion / ***** Overrides for Calculation Properties and Methods for Sorting *****/

		#region /***** Methods *****/

		//mam
		public static DisciplineComparer GetComparer()
		{
			return new DisciplineComparer();
		}
		//</mam>

		//mam - added parameter
		public override string GetXML(bool includePhotos, string selectedFilters)
		{
			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();
			MajorComponent component = GetMajorComponent();
			TreatmentProcess process = CacheManager.GetTreatmentProcess(InfoSetID, component.ProcessID);
			Facility		facility = CacheManager.GetFacility(InfoSetID, process.FacilityID);

			//mam
			decimal totalCurrentValue = GetCurrentValue();
			bool useNA = GetAllConditionNA();
			//</mam>

			//mam 112806
			bool overrideCV = GetAnyCurrentValueOverridden();
			bool overrideRC = GetAnyRepairCostOverridden();

			builder.Append("<DisciplinePipesData>\r\n");

			// Populate the basic data
			builder.Append("\t<DisciplinePipes>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
			builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", process.Name);
			builder.AppendFormat("\t\t<ComponentName><![CDATA[{0}]]></ComponentName>\r\n", component.Name);
			builder.AppendFormat("\t\t<Discipline><![CDATA[{0}]]></Discipline>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", facility.CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", facility.CurrentENR);

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			//mam 112806
			builder.AppendFormat("\t\t<Retired><![CDATA[{0}]]></Retired>\r\n", component.Retired);

			//mam
			if (includePhotos)
			{
			//</mam>
				builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePathWithPhotoFileName());
				builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto);
			}

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);
			builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", AcquisitionCost);
			builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", ReplacementValue);

			//mam 050806
			builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", AcquisitionCostEscalated);
			builder.AppendFormat("\t\t<ReplacementValueYear><![CDATA[{0:F0}]]></ReplacementValueYear>\r\n", ReplacementValueYear);
			builder.AppendFormat("\t\t<ReplacementValueYearENR><![CDATA[{0:F0}]]></ReplacementValueYearENR>\r\n", ReplacementENR);
			builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", RehabCost);

			builder.AppendFormat("\t\t<SalvageValue><![CDATA[{0:F0}]]></SalvageValue>\r\n", SalvageValue);
			builder.AppendFormat("\t\t<AnnualMaintenanceCost><![CDATA[{0:F0}]]></AnnualMaintenanceCost>\r\n", AnnualMaintCost);
			builder.AppendFormat("\t\t<InstallYear><![CDATA[{0:F0}]]></InstallYear>\r\n", InstallationYear);

			//mam - if Total Current Value = zero, then OUL, LOS, Crit, Vuln, RUL, and Risk = N/A
			if (totalCurrentValue == 0)
			{
				builder.AppendFormat("\t\t<OrgUsefulLife><![CDATA[{0:F1}]]></OrgUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", "N/A");
				builder.AppendFormat("\t\t<AvgCriticality><![CDATA[{0:F1}]]></AvgCriticality>\r\n", "N/A");
				builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", "N/A");
				builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<AvgVulnerability><![CDATA[{0}]]></AvgVulnerability>\r\n", "N/A");
				builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F1}]]></RemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<AvgRisk><![CDATA[{0:F2}]]></AvgRisk>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t<OrgUsefulLife><![CDATA[{0:F1}]]></OrgUsefulLife>\r\n", OrgUsefulLife);
				builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", GetAverageLOS());
				builder.AppendFormat("\t\t<AvgCriticality><![CDATA[{0:F1}]]></AvgCriticality>\r\n", GetAverageCriticality());

				if (useNA)
				{
					builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", "N/A");
					builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", string.Format("{0:F1}", GetAverageCondition()));
					builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", GetEconomicUsefulLife());
				}

				if (GetAllERULZero() && !GetAnyVulnerabilityOverridden())
				{
					builder.AppendFormat("\t\t<AvgVulnerability><![CDATA[{0}]]></AvgVulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t<AvgRisk><![CDATA[{0}]]></AvgRisk>\r\n", "N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat("\t\t<AvgVulnerability><![CDATA[{0:F2}]]></AvgVulnerability>\r\n", GetAverageVulnerability());
					builder.AppendFormat("\t\t<AvgVulnerability><![CDATA[{0:F4}]]></AvgVulnerability>\r\n", GetAverageVulnerability());
					builder.AppendFormat("\t\t<AvgRisk><![CDATA[{0:F2}]]></AvgRisk>\r\n", GetAverageRisk());
				}

				builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F1}]]></RemainingUsefulLife>\r\n", GetRemainingUsefulLife());
			}

			//mam 112806 - moved down
			//builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", GetCurrentValue()));

			builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", GetBookValue());
			builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", GetAnnualDepreciation());
			builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", GetCumulativeDepreciation());

			if (useNA)
			{
				//mam 112806
				if (overrideCV)
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", GetCurrentValue()));
				}
				else
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0}]]></CurrentValue>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0}]]></EvaluatedValue>\r\n", "N/A");

				//mam 112806 - check override
				if (overrideRC)
				{
					//mam 01042012 - repair cost can't be N/A if it's overridden - this line should be in the else block, directly below
					//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0}]]></RepairCost>\r\n", "N/A");
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", string.Format("{0:$#,##0}", GetRepairCost()));
				}
				else
				{
					//mam 01042012 - UseNa = true, and repair cost is not overridden, so display it as N/A - this line should be in the if block, directly above
					//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", string.Format("{0:$#,##0}", GetRepairCost()));
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0}]]></RepairCost>\r\n", "N/A");
				}
			}
			else
			{
				//mam 112806
				builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", GetCurrentValue()));

				//mam 07072011
				//builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", string.Format("{0:$#,##0}", GetEvaluatedValue()));
				//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", string.Format("{0:$#,##0}", GetRepairCost()));
				builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", GetEvaluatedValue());
				builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost());
			}

			builder.AppendFormat("\t\t<DateOfInspection><![CDATA[{0}]]></DateOfInspection>\r\n", DateInspected.ToString("MM/dd/yyyy"));
			builder.AppendFormat("\t\t<AssessedBy><![CDATA[{0}]]></AssessedBy>\r\n", AssessedBy);
			builder.Append("\t</DisciplinePipes>\r\n");

			PipeData[]		pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			PipeData		pipe;

			builder.Append("\t<PipeRecords>\r\n");

			//mam
			//may not do this:
//			//since we're now showing disciplines that have no pipes, must account for that case
//			if (pipes.Length == 0)
//			{
//				builder.Append("\t<PipeRecord>\r\n");
//
//				builder.AppendFormat("\t\t<IDNumber><![CDATA[{0}]]></IDNumber>\r\n", "N/A");
//				builder.AppendFormat("\t\t<Description><![CDATA[{0}]]></Description>\r\n", "N/A");
//				builder.AppendFormat("\t\t<Type><![CDATA[{0}]]></Type>\r\n", "N/A");
//				builder.AppendFormat("\t\t<SizeFt><![CDATA[{0}]]></SizeFt>\r\n", "N/A");
//				builder.AppendFormat("\t\t<LengthFt><![CDATA[{0}]]></LengthFt>\r\n", "N/A");
//				builder.AppendFormat("\t\t<UnitCost><![CDATA[{0:F2}]]></UnitCost>\r\n", "N/A");
//				builder.AppendFormat("\t\t<InstallYear><![CDATA[{0}]]></InstallYear>\r\n", "N/A");
//				builder.AppendFormat("\t\t<OriginalENR><![CDATA[{0}]]></OriginalENR>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CWPAssetVal><![CDATA[{0:F1}]]></CWPAssetVal>\r\n", "N/A");
//				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", "0");
//				builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", "0");
//				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", "0");
//				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", "N/A");
//				builder.AppendFormat("\t\t<SalvageValue><![CDATA[{0:F0}]]></SalvageValue>\r\n", "N/A");
//				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", "N/A");
//				builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0}]]></EvaluatedValue>\r\n", "N/A");
//				builder.AppendFormat("\t\t<RepairCost><![CDATA[{0}]]></RepairCost>\r\n", "N/A");
//				builder.AppendFormat("\t\t<AnnualMaintCost><![CDATA[{0:F0}]]></AnnualMaintCost>\r\n", "N/A");
//				builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CritPublicHealth><![CDATA[{0}]]></CritPublicHealth>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CritEnvironmental><![CDATA[{0}]]></CritEnvironmental>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CritCostOfRepairs><![CDATA[{0}]]></CritCostOfRepairs>\r\n", "N/A");
//				builder.AppendFormat("\t\t<CritCustomerEffect><![CDATA[{0}]]></CritCustomerEffect>\r\n", "N/A");
//				builder.AppendFormat("\t\t<OverallCriticality><![CDATA[{0}]]></OverallCriticality>\r\n", "N/A");
//				builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0}]]></Vulnerability>\r\n", "N/A");
//				builder.AppendFormat("\t\t<OverrideVulnerability><![CDATA[{0}]]></OverrideVulnerability>\r\n", 0);
//				builder.AppendFormat("\t\t<Risk><![CDATA[{0}]]></Risk>\r\n", "N/A");
//				builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", "N/A");
//				builder.AppendFormat("\t\t<OriginalUsefulLife><![CDATA[{0}]]></OriginalUsefulLife>\r\n", "N/A");
//				builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F2}]]></RemainingUsefulLife>\r\n", "N/A");
//				builder.AppendFormat("\t\t<EvalRemainingUsefulLife><![CDATA[{0}]]></EvalRemainingUsefulLife>\r\n", "N/A");
//				builder.Append("\t</PipeRecord>\r\n");
//			}

			// Append the pipe data, if there is any
			for (int pos = 0; pos < pipes.Length; pos++)
			{
				pipe = pipes[pos];
				CondRank currentCondition = pipe.ConditionRank;

				//mam
				useNA = (pipe.ConditionRank == CondRank.No);
				//</mam>

				builder.Append("\t<PipeRecord>\r\n");
				builder.AppendFormat("\t\t<IDNumber><![CDATA[{0}]]></IDNumber>\r\n", pipe.IDNumber);
				builder.AppendFormat("\t\t<Description><![CDATA[{0}]]></Description>\r\n", pipe.Description);
				builder.AppendFormat("\t\t<Type><![CDATA[{0}]]></Type>\r\n", pipe.Type);
				builder.AppendFormat("\t\t<SizeFt><![CDATA[{0}]]></SizeFt>\r\n", pipe.Size);
				builder.AppendFormat("\t\t<LengthFt><![CDATA[{0}]]></LengthFt>\r\n", pipe.Length);
				builder.AppendFormat("\t\t<UnitCost><![CDATA[{0:F2}]]></UnitCost>\r\n", pipe.UnitCost);
				builder.AppendFormat("\t\t<InstallYear><![CDATA[{0}]]></InstallYear>\r\n", pipe.InstallYear);
				builder.AppendFormat("\t\t<OriginalENR><![CDATA[{0}]]></OriginalENR>\r\n", pipe.OriginalENR);

				//mam - use unrounded value
				//builder.AppendFormat("\t\t<CWPAssetVal><![CDATA[{0:F2}]]></CWPAssetVal>\r\n", pipe.GetCWP() * 100.0);
				builder.AppendFormat("\t\t<CWPAssetVal><![CDATA[{0:F1}]]></CWPAssetVal>\r\n", pipe.GetCWP(false) * 100.0);
				//</mam>

				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", pipe.AcquisitionCost);

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", pipe.GetCurrentValue()));

				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", pipe.ReplacementValue);
				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", pipe.GetBookValue());
				builder.AppendFormat("\t\t<SalvageValue><![CDATA[{0:F0}]]></SalvageValue>\r\n", pipe.SalvageValue);
				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", pipe.GetAnnualDepreciation());
				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", pipe.GetCumulativeDepreciation());

				//mam 050806
				builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", pipe.AcquisitionCostEscalated);
				builder.AppendFormat("\t\t<ReplacementValueYear><![CDATA[{0:F0}]]></ReplacementValueYear>\r\n", pipe.ReplacementValueYear);
				builder.AppendFormat("\t\t<ReplacementValueYearENR><![CDATA[{0:F0}]]></ReplacementValueYearENR>\r\n", pipe.GetENRValueForYear(Convert.ToInt16(pipe.ReplacementValueYear)));
				builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", pipe.RehabCost);
				builder.AppendFormat("\t\t<RedundantAssets><![CDATA[{0:F0}]]></RedundantAssets>\r\n", pipe.RedundantAssetCount);

				//mam - added "if" condition
				if (useNA == true)
				{
					//mam 112806 - moved down from above; check override
					if (pipe.OverrideCurrentValue)
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", pipe.GetCurrentValue()));
					}
					else
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0}]]></CurrentValue>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0}]]></EvaluatedValue>\r\n", "N/A");

					//mam 112806 - check override
					if (pipe.OverrideRepairCost)
					{
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", string.Format("{0:$#,##0}", pipe.GetRepairCost()));
					}
					else
					{
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0}]]></RepairCost>\r\n", "N/A");
					}
				}
				else
				{
					//mam 112806
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", string.Format("{0:$#,##0}", pipe.GetCurrentValue()));

					//mam 07072011
					//builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", string.Format("{0:$#,##0}", pipe.GetEvaluatedValue()));
					//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", string.Format("{0:$#,##0}", pipe.GetRepairCost()));
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", pipe.GetEvaluatedValue());
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", pipe.GetRepairCost());
				}
				//</mam>

				//mam 050806
				builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", Convert.ToInt32(pipe.OverrideAcquisitionCost));
				builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", Convert.ToInt32(pipe.OverrideCurrentValue));
				builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", Convert.ToInt32(pipe.OverrideRepairCost));

				builder.AppendFormat("\t\t<AnnualMaintCost><![CDATA[{0:F0}]]></AnnualMaintCost>\r\n", pipe.AnnualMaintCost);
				builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", EnumHandlers.GetConditionRankShort(pipe.ConditionRank));

				//mam 07072011 - no longer using four fixed crits
				//builder.AppendFormat("\t\t<CritPublicHealth><![CDATA[{0}]]></CritPublicHealth>\r\n", EnumHandlers.GetCritPublicHealthString(pipe.CritPublicHealth));
				//builder.AppendFormat("\t\t<CritEnvironmental><![CDATA[{0}]]></CritEnvironmental>\r\n", EnumHandlers.GetCritEnvironmentalString(pipe.CritEnvironmental));
				//builder.AppendFormat("\t\t<CritCostOfRepairs><![CDATA[{0}]]></CritCostOfRepairs>\r\n", EnumHandlers.GetCritRepairCostString(pipe.CritRepair));
				//builder.AppendFormat("\t\t<CritCustomerEffect><![CDATA[{0}]]></CritCustomerEffect>\r\n", EnumHandlers.GetCritCustomerEffectString(pipe.CritCustEffect));

				//mam 07072011 - new crits
				foreach (MajorComponentSelectedCriticalityFactors critFactor in pipe.ComponentSelectedCriticalityFactorsCollection)
				{
					string critNumberText = "Crit" + critFactor.CriticalityNumber.ToString();
					builder.AppendFormat("\t\t<" + critNumberText + "><![CDATA[{0}]]></" + critNumberText + ">\r\n", critFactor.CritFactor.FactorName);
				}

				builder.AppendFormat("\t\t<OverallCriticality><![CDATA[{0}]]></OverallCriticality>\r\n", pipe.GetOverallCriticality());

				//mam - use probability
				if ((currentCondition == CondRank.No || pipe.GetEvaluatedRemainingUsefulLife() == 0) 
					&& !pipe.OverrideVulnerability)
				{
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0}]]></Vulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t<OverrideVulnerability><![CDATA[{0}]]></OverrideVulnerability>\r\n", 0);
					builder.AppendFormat("\t\t<Risk><![CDATA[{0}]]></Risk>\r\n", "N/A");
				}
				else
				{
					//builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0}]]></Vulnerability>\r\n", EnumHandlers.GetVulnerabilityShort(pipe.Vulnerability));
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F4}]]></Vulnerability>\r\n", pipe.GetVulnerability());
					builder.AppendFormat("\t\t<OverrideVulnerability><![CDATA[{0}]]></OverrideVulnerability>\r\n", Convert.ToInt32(pipe.OverrideVulnerability));
					builder.AppendFormat("\t\t<Risk><![CDATA[{0:F2}]]></Risk>\r\n", pipe.GetRisk());
				}
				//</mam>
				
				builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", EnumHandlers.GetLOSShort(pipe.LevelOfService));
				builder.AppendFormat("\t\t<OriginalUsefulLife><![CDATA[{0}]]></OriginalUsefulLife>\r\n", pipe.OrgUsefulLife);
				builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F2}]]></RemainingUsefulLife>\r\n", pipe.GetRemainingUsefulLife());

				//mam - added "if" condition
				if (useNA == true || currentCondition == CondRank.No)
				{
					builder.AppendFormat("\t\t<EvalRemainingUsefulLife><![CDATA[{0}]]></EvalRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0}]]></EconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t<EvalRemainingUsefulLife><![CDATA[{0:F2}]]></EvalRemainingUsefulLife>\r\n", pipe.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F2}]]></EconomicUsefulLife>\r\n", pipe.GetEconomicUsefulLife());
				}

				builder.Append("\t</PipeRecord>\r\n");
			}
			builder.Append("\t</PipeRecords>\r\n");

			builder.Append("</DisciplinePipesData>\r\n");
			return builder.ToString();
		}

		public override void CopyTo(Discipline copyBase)
		{
			base.CopyTo(copyBase);

			DisciplinePipe copy = (DisciplinePipe)copyBase;

			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;
			copy.m_photoCaption = m_photoCaption;
			copy.m_comments = m_comments;
		}

		//mam - allow or disallow copying of photo
		public override void CopyTo(Discipline copyBase, bool copyPhoto, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			base.CopyTo(copyBase);

			DisciplinePipe copy = (DisciplinePipe)copyBase;

			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;

			if (copyPhoto)
			{
				copy.m_photoCaption = m_photoCaption;
			}

			copy.m_comments = m_comments;
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Overrides *****/

		public override decimal AcquisitionCost
		{
			get
			{
				// Acquisition cost = sum of pipe data acquisition cost
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		acqCost = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					acqCost += pipes[pos].AcquisitionCost;

				return acqCost;
			}
			set
			{
			}
		}

		//mam 07072011 - this is needed because pipe AC is calculated differently than mech/struct/civil discipline AC
		public override decimal AcquisitionCostRoundIndividualValues
		{
			get
			{
				return AcquisitionCost;
			}
		}

		//mam 050806
		public override decimal AcquisitionCostEscalated
		{
			get
			{
				// Acquisition Cost = sum of pipe data acquisition cost
				// Escalated Acquisition Cost = Acquisition Cost * Current ENR / Original ENR
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		acqCost = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					acqCost += pipes[pos].AcquisitionCostEscalated;

				return acqCost;
			}
		}

		public override decimal ReplacementValue
		{
			get
			{
				// Replacement Value = sum of pipe data Replacement Value
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		replaceVal = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					replaceVal += pipes[pos].ReplacementValue;

				return replaceVal;
			}
			set
			{
			}
		}

		//mam 050806
		public override decimal RehabCost
		{
			get
			{
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		rehabCost = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					rehabCost += pipes[pos].RehabCost;

				return rehabCost;
			}
			set
			{
			}
		}

		public override decimal SalvageValue
		{
			get
			{
				// Salvage Value = sum of pipe data Salvage Value
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		salvageVal = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					salvageVal += pipes[pos].SalvageValue;

				return salvageVal;
			}
			set
			{
			}
		}

		public override decimal AnnualMaintCost
		{
			get
			{
				// Annual Maint Cost = sum of pipe data Annual Maint Cost
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		annualMaintCost = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
					annualMaintCost += pipes[pos].AnnualMaintCost;

				return annualMaintCost;
			}
			set
			{
			}
		}

		public override short InstallationYear
		{
			get
			{
				// Average Installation Year = (sum of install year / count)
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				long		installYearSum = 0;

				if (pipes.Length == 0)
					return 0;

				for (int pos = 0; pos < pipes.Length; pos++)
					installYearSum += pipes[pos].InstallYear;

				return (short)(installYearSum / pipes.Length);
			}
			set
			{
			}
		}

		//mam 050806
		public override int ReplacementValueYear
		{
			get
			{
				// Average Replacement Year = (sum of replacement year / count)
				// Retrieve the pipe data for the current discipline
				PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				long replacementYearSum = 0;

				//mam 112806
				int discCount = 0;

				if (pipes.Length == 0)
					return 0;

				for (int pos = 0; pos < pipes.Length; pos++)
				{
					//mam 112806 - check for ReplacementValueYear > zero
					if (pipes[pos].ReplacementValueYear > 0)
					{
						discCount++;
						replacementYearSum += pipes[pos].ReplacementValueYear;
					}
				}

				//mam 112806 - use discCount rather than pipes.Length
				//return (int)(replacementYearSum / pipes.Length);
				return discCount == 0 ? 0 : (int)Math.Round((decimal)replacementYearSum / discCount, 0);
			}
			set
			{
			}
		}

		public override short OrgUsefulLife
		{
			get
			{
				// Avg Original Useful Life = sum (row CWP * row org UL)
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
				decimal		totalUsefulLife = 0m;

				for (int pos = 0; pos < pipes.Length; pos++)
				{
					//mam - get unrounded CWP
					//original code:
					//totalUsefulLife += (decimal)
					//	(pipes[pos].GetCWP() * (double)pipes[pos].OrgUsefulLife);
					//new code:
					totalUsefulLife += (decimal)
						(pipes[pos].GetCWPCurrentValue(false) * (double)pipes[pos].OrgUsefulLife);	//mam 112806 - changed to GetCWPCurrentValue
					//</mam>
				}

				return (short)(Math.Round(totalUsefulLife, 0));
			}
			set
			{
			}
		}

		//mam - check whether any pipes exist
		public override int GetItemCount()
		{
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			return pipes.Length;
		}
		//</mam>

		public override double CWPAssetValue
		{
			get
			{
				// For pipes / Appurtenances, CWP Asset Value is calculated
				MajorComponent component = 
					CacheManager.GetMajorComponent(InfoSetID, m_componentID);
				decimal totalValue = component.GetCurrentValue();

				if (totalValue == 0m)
					return 0.0;

				// = Discipline's Current Value / Component's Total Current Value
				return (double)(GetCurrentValue() / totalValue);
			}
			set
			{
			}
		}

		public override CondRank ConditionRanking
		{
			get
			{
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);

				if (pipes.Length == 0)
					return CondRank.No;

				return (CondRank)((int)GetAverageCondition());
			}
			set
			{
			}
		}

		public override int OriginalENR
		{
			get
			{
				// Should never get original ENR from this object
				return base.OriginalENR;
			}
			set
			{
			}
		}

		public override decimal GetCurrentValue()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalCurVal = 0m;
			// Retrieve the total current value from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				totalCurVal += pipes[pos].GetCurrentValue();
			return totalCurVal;
		}

		public override decimal GetBookValue()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalBookVal = 0m;

			// Retrieve the total book value from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				totalBookVal += pipes[pos].GetBookValue();

			if (totalBookVal < 0m)
				totalBookVal = 0m;

			return totalBookVal;
		}

		public override decimal GetAnnualDepreciation()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalAnnualDepr = 0m;

			// Retrieve the total annual depreciation from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				totalAnnualDepr += pipes[pos].GetAnnualDepreciation();

			return totalAnnualDepr;
		}

		public override decimal GetCumulativeDepreciation()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalCumulativeDepr = 0m;

			// Retrieve the total cumulative depreciation from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				totalCumulativeDepr += pipes[pos].GetCumulativeDepreciation();

			return totalCumulativeDepr;
		}

		public override decimal GetEvaluatedValue()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalEvalVal = 0m;

			// Retrieve the total Evaluated Value from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				//mam - if Condition = N/A, don't include that pipe's EvalValue in the total
				if (pipes[pos].ConditionRank != CondRank.No)
				//</mam>
					totalEvalVal += pipes[pos].GetEvaluatedValue();

			return totalEvalVal;
		}

		public override decimal GetRepairCost()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		totalRepairCost = 0m;

			// Retrieve the total Repair Cost from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				//mam - if Condition = N/A, don't include that pipe's RepairCost in the total,
				//	unless the Repair Cost has been overridden by the user
				//mam 050806
				if (pipes[pos].ConditionRank != CondRank.No
					|| (pipes[pos].ConditionRank == CondRank.No && pipes[pos].OverrideRepairCost))
					//</mam>
				{
					totalRepairCost += pipes[pos].GetRepairCost();
				}

			return totalRepairCost;
		}

		//mam - add routine to check whether Condition for all pipes is N/A
		public bool GetAllConditionNA()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam 050806 - add routine to check whether any Repair Cost value is overridden
		public bool GetAnyRepairCostOverridden()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			bool AnyOR = false;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideRepairCost)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		//mam 112806 - add routine to check whether any Current Value is overridden
		public bool GetAnyCurrentValueOverridden()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			bool AnyOR = false;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideCurrentValue)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>


		//mam - add routine to check whether ERUL for all pipes is zero
		public bool GetAllERULZero()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			bool AllNA = true;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].GetEvaluatedRemainingUsefulLife() != 0)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether any Vulnerability value is overridden
		public bool GetAnyVulnerabilityOverridden()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			bool AnyOR = false;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideVulnerability)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		public override double GetRemainingUsefulLife()
		{
			// = SUM( (Row CWP ) * (Row Remaining Useful Life))
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			double		avgRemainingUL = 0.0;

			// Retrieve the total Repair Cost from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//mam - get unrounded CWP
				//original code:
				//avgRemainingUL += 
				//	(pipes[pos].GetCWP() * pipes[pos].GetRemainingUsefulLife());
				//new code:
				avgRemainingUL += 
					(pipes[pos].GetCWPCurrentValue(false) * pipes[pos].GetRemainingUsefulLife());	//mam 112806 - changed to GetCWPCurrentValue
				//</mam>
			}

			return avgRemainingUL;
		}

		public override double GetEvaluatedRemainingUsefulLife()
		{
			// = SUM( (Row CWP ) * (Row Eval Useful Life))
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			double		avgEvalUL = 0.0;

			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//mam - get unrounded CWP
				//original code:
				//avgEvalUL += 
				//	(pipes[pos].GetCWP() * pipes[pos].GetEvaluatedRemainingUsefulLife());
				//new code:
				//if Condition = N/A, don't include that pipe's ERUL in the total
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					avgEvalUL += 
						(pipes[pos].GetCWPCurrentValue(false) * pipes[pos].GetEvaluatedRemainingUsefulLife());	//mam 112806 - changed to GetCWPCurrentValue
				}
				//</mam>
			}

			return Math.Round(avgEvalUL, 1);
		}

		//mam
		public override double GetEconomicUsefulLife()
		{
			// Retrieve the pipe data for the current discipline
			PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			double avgEconomicUL = 0.0;

			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//if Condition = N/A, don't include that pipe's EconomicUL in the total
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					avgEconomicUL += 
						(pipes[pos].GetCWPCurrentValue(false) * pipes[pos].GetEconomicUsefulLife());	//mam 112806 - changed to GetCWPCurrentValue
				}
			}

			return Math.Round(avgEconomicUL, 1);
		}
		//</mam>

		public override decimal GetDisciplineCost()
		{
			return base.GetDisciplineCost();
		}
		#endregion /***** Overrides *****/

		#region /***** Calculations *****/

//		//mam - change from int to decimal
//		//original code:
//		//public int			GetAverageLOS()
//		//new code:
//		public decimal			GetAverageLOS()
//		{
//		//</mam>
//			// = SUM( (Row CWP ) * (Row LOS))
//			// Retrieve the pipe data for the current discipline
//			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
//			decimal		avgLOS = 0m;
//
//			// Retrieve the total Repair Cost from the pipe data
//			for (int pos = 0; pos < pipes.Length; pos++)
//			{
//				//mam - get unrounded CWP
//				//original code:
//				//avgLOS += ((decimal)pipes[pos].GetCWP() * 
//				//	(decimal)(pipes[pos].LevelOfService));
//				//new code:
//				avgLOS += ((decimal)pipes[pos].GetCWP(false) * 
//					(decimal)(pipes[pos].LevelOfService));
//				//</mam>
//			}
//
//			//mam - round LOS to 1 decimal place
//			//original code:
//			//return (int)Math.Round(avgLOS, 0);
//			//new code:
//			return Math.Round(avgLOS, 1);
//			//</mam>
//		}

		//mam - new GetAverageLOS to calculate based on same equation as Condition
		//This routine replaces GetAverageLOS, above
		public decimal GetAverageLOS()
		{
			decimal			totalCurrentValue = GetCurrentValue();
			decimal			rankPercent = 0m;
			decimal			sumRankValues = 0m;

			// = (0.4021 * (((sum of (LOS Fraction * current value) / totalCurrentValue) * 100) ^ .5885)) + 1

			// Retrieve the pipe data for the current discipline
			PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);

			// Retrieve the sum of the LOS Percentage x Current Value
			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//sumRankValues += (decimal)EnumHandlers.GetConditionRankValue(pipes[pos].ConditionRank) * 
				//	(decimal)pipes[pos].GetCurrentValue();
				sumRankValues += (decimal)EnumHandlers.GetLOSValue(pipes[pos].LevelOfService) * 
					(decimal)pipes[pos].GetCurrentValue();
			}		

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				rankPercent += 1m;
				if (rankPercent > 5m)
					rankPercent = 5m;
			}

				//if totalCurrentValue = 0, there is not enough data to calculate the avg LOS
			else
			{
				return 0.0m;
			}

			if (rankPercent < 1.0m)
				rankPercent = 1.0m;

			return (decimal)Math.Round(rankPercent, 2);
		}
		//</mam>

		//mam - replaced GetAverageCondition with a new equation
//		public double		GetAverageCondition()
//		{
//			decimal			totalCurrentValue = GetCurrentValue();
//			double			rankPercent = 0.0;
//
//			// = 0.4113 * (((Total Repair Cost)/(Total  Current Value)) * 100) ^ .583
//			if (totalCurrentValue != 0)
//			{
//				rankPercent = 0.4113;
//				rankPercent *= Math.Pow((double)((double)
//					((GetRepairCost() / totalCurrentValue) * 100m)), 0.583);
//				if (rankPercent > 5.0)
//					rankPercent = 5.0;
//			}
//
//			//mam - added the following code, because if totalCurrentValue = 0, 
//			//	there is not enough data to calculate the avg condition
//			else
//			{
//				return 0.0;
//			}
//			//</mam>	
//
//			if (rankPercent < 1.0)
//				rankPercent = 1.0;
//
//			return Math.Round(rankPercent, 2);
//		}
		//</mam>

		//mam - replacement for GetAverageCondition
		public double		GetAverageCondition()
		{
			decimal			totalCurrentValue = GetCurrentValue();
			decimal			rankPercent = 0m;
			decimal			sumRankValues = 0m;

			// = (0.4021 * (((sum of (Condition Fraction * current value) / totalCurrentValue) * 100) ^ .5885)) + 1

			// Retrieve the pipe data for the current discipline
			PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);

			// Retrieve the sum of the Condition Percentage x Current Value
			for (int pos = 0; pos < pipes.Length; pos++)
			{
				sumRankValues += (decimal)EnumHandlers.GetConditionRankValue(pipes[pos].ConditionRank) * 
					(decimal)pipes[pos].GetCurrentValue();
			}		

			if (totalCurrentValue != 0)
			{
				rankPercent = 0.4021M;
				rankPercent *= (decimal)Math.Pow((double)((sumRankValues / totalCurrentValue) * 100m), 0.5885);

				rankPercent += 1m;
				if (rankPercent > 5m)
					rankPercent = 5m;
			}

			//if totalCurrentValue = 0, there is not enough data to calculate the avg condition
			else
			{
				return 0.0;
			}

			if (rankPercent < 1.0m)
				rankPercent = 1.0m;

			return (double)Math.Round(rankPercent, 2);
		}
		//</mam>

		//mam - new method
		public override double GetAverageConditionForInterpolatedRank()
		{
			return GetAverageCondition();
		}
		//</mam>

		public double GetAverageCriticality()
		{
			// = SUM( (Row CWP ) * (Row Criticality))
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			double		avgCrit = 0.0;

			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//mam - get unrounded CWP
				//original code:
				//avgCrit += 
				//	(pipes[pos].GetCWP() * (double)pipes[pos].GetOverallCriticality());
				//new code:
				avgCrit += 
					(pipes[pos].GetCWPCurrentValue(false) * pipes[pos].GetOverallCriticality());	//mam 112806 - changed to GetCWPCurrentValue
				//</mam>
			}

			return avgCrit;
		}

		//mam - change from int to decimal to return probability rather than year
		//public int			GetAverageVulnerability()
		public decimal			GetAverageVulnerability()
		{
			// = SUM( (Row CWP ) * (Row Vulnerability))
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			decimal		avgVuln = 0m;

			// Retrieve the total Repair Cost from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
			{
//				//mam - get unrounded CWP
//				//original code:
//				//avgVuln += 
//				//	(decimal)(pipes[pos].GetCWP() * 
//				//	EnumHandlers.GetVulnerabilityYear(pipes[pos].Vulnerability));
//				//new code:
//				avgVuln += 
//					(decimal)(pipes[pos].GetCWP(false) * 
//					EnumHandlers.GetVulnerabilityYear(pipes[pos].Vulnerability));
//				//</mam>

				//mam - use the probability, rather than the enumerated value
				avgVuln += (decimal)(pipes[pos].GetCWPCurrentValue(false) * 
					pipes[pos].GetVulnerability());	//mam 112806 - changed to GetCWPCurrentValue
				//</mam>
			}

			//mam - return actual vulnerability probability rather than the equivalent year
			//return Math.Round(avgVuln, 2);

			//mam 090105 - round vuln to 4 decimals rather than 2
			return Math.Round(avgVuln, 4);

//			avgVuln = Math.Round(avgVuln, 0);
//
//			// Round down to 5, 10, 20, 50, 100, 150
//			if (avgVuln < 10m)
//				return 5;
//			else if (avgVuln < 20m)
//				return 10;
//			else if (avgVuln < 50m)
//				return 20;
//			else if (avgVuln < 100m)
//				return 50;
//			else if (avgVuln < 150m)
//				return 100;
//
//			return 150;
		}

		public double GetAverageRisk()
		{
			// = SUM( (Row CWP ) * (Row Risk))
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, ID);
			double		avgRisk = 0.0;

			// Retrieve the total Repair Cost from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
			{
				//mam - get unrounded CWP
				//original code:
				//avgRisk += 
				//	(pipes[pos].GetCWP() * pipes[pos].GetRisk());
				//new code:
				avgRisk += 
					(pipes[pos].GetCWPCurrentValue(false) * pipes[pos].GetRisk());
				//</mam>
			}

			return Math.Round(avgRisk, 2);
		}
		#endregion /***** Calculations *****/
	}
}