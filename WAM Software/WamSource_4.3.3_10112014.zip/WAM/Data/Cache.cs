using System;
using System.Collections;

//mam 102309
//using System.Data.OleDb;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Cache.
	/// </summary>
	public class Cache
	{
		private InfoSet				m_infoSet = null;
		private FacilityCache		m_facilityCache = null;
		private TreatmentProcessCache m_processCache = null;
		private MajorComponentCache	m_componentCache = null;
		private DisciplineCache		m_disciplineCache = null;
		private ComponentAssetCache m_assetCache = null;
		private NodeDataCache		m_nodeCache = null;
		private PipeDataCache		m_pipeCache = null;

		//mam 03202012 - instead of loading the cache by making separate calls to the database for each facility, process, component, crit, discipline, and asset list, 
		//	get the data in larger chunks (one call per type) and populate the cache
		//@@@@
		public Cache(int infoSetID)
		{
			m_infoSet = new InfoSet(infoSetID);

			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);
			UI.CacheBuildStatusControl.CacheUpdateEventArgs eventArgs = new WAM.UI.CacheBuildStatusControl.CacheUpdateEventArgs();
			Drive.Profile.Profiler profiler = new Drive.Profile.Profiler();

			m_facilityCache = new FacilityCache(infoSetID);
			m_processCache = new TreatmentProcessCache(infoSetID);
			m_componentCache = new MajorComponentCache(infoSetID);
			m_disciplineCache = new DisciplineCache(infoSetID);
			m_assetCache = new ComponentAssetCache(infoSetID);
			m_nodeCache = new NodeDataCache(infoSetID);
			m_pipeCache = new PipeDataCache(infoSetID);

			profiler.Start();
			try
			{
				sqlConnection.Open();

				//update the message on the splash screen
				eventArgs.Status = "Loading Facilities";
				UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs); 

				//get all facilities in the infoset
				m_facilityCache.BuildCache(sqlConnection);

				//update the message on the splash screen
				eventArgs.Status = "Loading Treatment Processes";
				UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs);

				//get all processes in the infoset
				m_processCache.BuildCacheForInfoset(sqlConnection, infoSetID);

				//update the message on the splash screen
				eventArgs.Status = "Loading Major Components";
				UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs);

				//get all components in the infoset
				m_componentCache.BuildCacheForInfoset(sqlConnection, infoSetID);

				//update the message on the splash screen
				eventArgs.Status = "Loading Disciplines";
				UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs);

				//get all disciplines in the infoset
				m_disciplineCache.BuildCacheForInfoset(sqlConnection, infoSetID);

				//get all pipe data for infoset
				m_pipeCache.BuildCacheForInfoset(sqlConnection, infoSetID);

				//get all node data for infoset
				m_nodeCache.BuildCacheForInfoset(sqlConnection, infoSetID);

				//get all component assets in the infoset
				m_assetCache.BuildCacheForInfoset(sqlConnection, infoSetID);
			}
			finally
			{
				eventArgs.Status = "";
				if (sqlConnection != null)
				{
					sqlConnection.Dispose();
				}
			}
			profiler.End();

			System.Diagnostics.Trace.WriteLine(
				string.Format("{0:F2} seconds to build cache", 
				profiler.DurationMilli / 1000.0));
		}

		//mam 03202012 - no longer using this method - it has been superseded
//		public Cache(int infoSetID)
//		{
//			m_infoSet = new InfoSet(infoSetID);
//
//			Facility[]		facilities;
//			TreatmentProcess[] processes;
//			MajorComponent[] components;
//			int				facPos;
//			int				treatPos;
//			int				compPos;
//
//			//mam 102309
//			//OleDbConnection sqlConnection = new System.Data.OleDb.OleDbConnection(
//			//	WAMSource.CurrentSource.ConnectionString);
//			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);
//
//			UI.CacheBuildStatusControl.CacheUpdateEventArgs
//							eventArgs = new WAM.UI.CacheBuildStatusControl.CacheUpdateEventArgs();
//
//			Drive.Profile.Profiler profiler = new Drive.Profile.Profiler();
//
//			m_facilityCache = new FacilityCache(infoSetID);
//			m_processCache = new TreatmentProcessCache(infoSetID);
//			m_componentCache = new MajorComponentCache(infoSetID);
//			m_disciplineCache = new DisciplineCache(infoSetID);
//			m_assetCache = new ComponentAssetCache(infoSetID);
//			m_nodeCache = new NodeDataCache(infoSetID);
//			m_pipeCache = new PipeDataCache(infoSetID);
//
//			profiler.Start();
//			try
//			{
//				sqlConnection.Open();
//
//				eventArgs.Status = "Loading Facilities";
//				UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs); 
//
//				facilities = m_facilityCache.BuildCache(sqlConnection);
//				for (facPos = 0; facPos < facilities.Length; facPos++)
//				{
//					processes = m_processCache.BuildCacheForFacility(
//						sqlConnection, facilities[facPos].ID);
//
//					//mam - allow user to cancel caching operation under certain circumstances
//					//	(such as preparing a graph)
//					if (eventArgs.Status == "Cancelling...")
//						return;
//					//</mam>
//
//					for (treatPos = 0; treatPos < processes.Length; treatPos++)
//					{
//						eventArgs.Status = string.Format("Caching treatment process '{0}'",
//							processes[treatPos].Name);
//						UI.CacheBuildStatusControl.InvokeUpdateEvent(null, eventArgs);
//
//						components = m_componentCache.BuildCacheForProcess(
//							sqlConnection, processes[treatPos].ID);
//
//						//mam - allow user to cancel caching operation under certain circumstances
//						//	(such as preparing a graph)
//						if (eventArgs.Status == "Cancelling...")
//							return;
//						//</mam>
//
//						for (compPos = 0; compPos < components.Length; compPos++)
//						{
//							m_disciplineCache.BuildCacheForComponent(
//								sqlConnection, components[compPos].ID);
//
//							m_assetCache.BuildCacheForComponent(sqlConnection, components[compPos].ID);
//
//							//mam - allow user to cancel caching operation under certain circumstances
//							//	(such as preparing a graph)
//							if (eventArgs.Status == "Cancelling...")
//								return;
//							//</mam>
//						}
//					}
//				}
//
//				//mam - moved to the finally block
//				//eventArgs.Status = "";
//				//</mam>
//			}
//			finally
//			{
//				//mam
//				eventArgs.Status = "";
//				//</mam>
//
//				if (sqlConnection != null)
//					sqlConnection.Dispose();
//			}
//			profiler.End();
//
//			System.Diagnostics.Trace.WriteLine(
//				string.Format("{0:F2} seconds to build cache", 
//				profiler.DurationMilli / 1000.0));
//		}

		public int			InfoSetID
		{
			get { return m_infoSet.ID; }
		}

		public FacilityCache FacilityCache
		{
			get { return m_facilityCache; }
		}

		public TreatmentProcessCache TreatmentProcessCache
		{
			get { return m_processCache; }
		}

		public MajorComponentCache MajorComponentCache
		{
			get { return m_componentCache; }
		}

		public DisciplineCache DisciplineCache
		{
			get { return m_disciplineCache; }
		}

		public ComponentAssetCache ComponentAssetCache
		{
			get { return m_assetCache; }
		}

		public NodeDataCache NodeDataCache
		{
			get { return m_nodeCache; }
		}

		public PipeDataCache PipeDataCache
		{
			get { return m_pipeCache; }
		}

		public override int GetHashCode()
		{
			return m_infoSet.ID.GetHashCode();
		}

		//mam
		public string GetInfosetName()
		{
			return m_infoSet.Name;
		}
		//</mam>

		//mam 050806
		public void SetInfosetName(string newName)
		{
			if (newName.Length > 255)
				m_infoSet.Name = newName.Substring(255);
			else
				m_infoSet.Name = newName;
		}
		//</mam>
	}

	public class			CacheManager
	{
		private static Hashtable m_cacheHash = new Hashtable();

		static				CacheManager()
		{
		}

		//mam
		public static string GetInfosetNameForInfoSetID(int infoSetID)
		{
			Cache			cache = null;

			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
			if (cache == null)
				return "";

			return cache.GetInfosetName();
		}
		//</mam>

		//mam
		public static void SetInfosetNameForInfoSetID(int infoSetID, string newName)
		{
			Cache			cache = null;

			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
			if (cache == null)
				return;

			cache.SetInfosetName(newName);

			//return cache.GetInfosetName();
		}
		//</mam>

		public static Cache	GetCacheForInfoSetID(int infoSetID)
		{
			Cache			cache = null;

			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
			if (cache == null)
			{
				cache = new Cache(infoSetID);
				m_cacheHash[infoSetID.GetHashCode()] = cache;
			}

			return cache;
		}

		//mam - added this routine because of problems allowing user to load various databases
		public static Cache	GetCacheForInfoSetID(int infoSetID, bool forceLoadCache)
		{
			Cache			cache = null;

			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
			if (cache == null || forceLoadCache)
			{
				cache = new Cache(infoSetID);
				m_cacheHash[infoSetID.GetHashCode()] = cache;
			}

			return cache;
		}
		//</mam>

		//mam - don't load an infoset into the cache - just determine whether it has been previously loaded
		public static bool IsLoadedCacheForInfoSetID(int infoSetID)
		{
			Cache			cache = null;

			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
			if (cache != null)
				return true;

			return false;
		}
		//</mam>

		#region /***** Facility Cache *****/

		//mam
		public static Int32 GetFacilityCount(int infoSetID)
		{
			Facility[] facilities = CacheManager.GetFacilities(infoSetID);
			return facilities.Length;
		}
		//</mam>

		public static FacilityCache GetFacilityCache(int infoSetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.FacilityCache;
		}

		public static Facility[] GetFacilities(int infoSetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.FacilityCache.GetAll();
		}

		public static Facility	GetFacility(int infoSetID, int facilityID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.FacilityCache.GetFacility(facilityID);
		}
		#endregion /***** Facility Cache *****/

		#region /***** Process Cache *****/
		public static TreatmentProcessCache GetProcessCache(int infoSetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.TreatmentProcessCache;
		}

		public static TreatmentProcess[] GetProcesses(int infoSetID, int facilityID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			TreatmentProcessCache processCache = cache.TreatmentProcessCache;

			return processCache.GetForFacility(facilityID);
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public static TreatmentProcess[] GetProcessesForReport(int infoSetID, int facilityID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			TreatmentProcessCache processCache = cache.TreatmentProcessCache;

			return processCache.GetForFacilityForReport(facilityID);
		}

		public static TreatmentProcess GetTreatmentProcess(int infoSetID, int processID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			TreatmentProcessCache processCache = cache.TreatmentProcessCache;

			return processCache.GetTreatmentProcess(processID);
		}
		#endregion /***** Process Cache *****/

		#region /***** Component Cache *****/

		public static MajorComponentCache GetComponentCache(int infoSetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.MajorComponentCache;
		}

		public static MajorComponent[] GetComponents(int infoSetID, int processID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			MajorComponentCache componentCache = cache.MajorComponentCache;

			return componentCache.GetForProcess(processID);
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public static MajorComponent[] GetComponentsForReport(int infoSetID, int processID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			MajorComponentCache componentCache = cache.MajorComponentCache;

			return componentCache.GetForProcessForReport(processID);
		}

		public static MajorComponent GetMajorComponent(int infoSetID, int componentID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			MajorComponentCache componentCache = cache.MajorComponentCache;

			return componentCache.GetMajorComponent(componentID);
		}

		#endregion /***** Component Cache *****/

		#region /***** Discipline Cache *****/
		public static DisciplineCache GetDisciplineCache(int infoSetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);

			return cache.DisciplineCache;
		}

		public static Discipline[] GetDisciplines(int infoSetID, int componentID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			DisciplineCache disciplineCache = cache.DisciplineCache;

			return disciplineCache.GetForComponent(componentID);
		}

		public static Discipline GetDiscipline(int infoSetID, int disciplineID, DisciplineType type)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			DisciplineCache disciplineCache = cache.DisciplineCache;

			return disciplineCache.GetDiscipline(disciplineID, type);
		}
		#endregion /***** Discipline Cache *****/

		public static NodeData[] GetNodeDataForDiscipline(int infoSetID, int disciplineID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			NodeDataCache	nodeDataCache = cache.NodeDataCache;

			return nodeDataCache.GetForDiscipline(disciplineID);
		}
		
		public static PipeData[] GetPipeDataForDiscipline(int infoSetID, int disciplineID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			PipeDataCache	pipeDataCache = cache.PipeDataCache;

			return pipeDataCache.GetForDiscipline(disciplineID);
		}

		public static ComponentAsset[] GetAssets(int infoSetID, int componentID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			ComponentAssetCache	assetCache = cache.ComponentAssetCache;

			return assetCache.GetForComponent(componentID);
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public static ComponentAsset[] GetAssetsForReport(int infoSetID, int componentID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			ComponentAssetCache	assetCache = cache.ComponentAssetCache;

			return assetCache.GetForComponentForComponent(componentID);
		}

		//mam - added this code to get individual assets for the report tree
		public static ComponentAsset	GetAsset(int infoSetID, int assetID)
		{
			Cache			cache = GetCacheForInfoSetID(infoSetID);
			ComponentAssetCache	assetCache = cache.ComponentAssetCache;

			return assetCache.GetComponentAsset(assetID);
		}
		//</mam>

	}
}