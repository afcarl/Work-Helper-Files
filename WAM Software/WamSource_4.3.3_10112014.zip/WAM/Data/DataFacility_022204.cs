using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Collections;
using System.Drawing;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Facility.
	/// </summary>
	public class Facility : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable, IGraphableUnit
	{
		#region /***** Member Variables *****/
		private int			m_infoSetID = 0;
		private string		m_name = "";
		private short		m_currentYear = (short)DateTime.Now.Year;
		private int			m_currentENR = 0;
		private string		m_captionNorth = "";
		private string		m_captionSouth = "";
		private string		m_captionEast = "";
		private string		m_captionWest = "";
		private string		m_comments = "";
		private decimal		m_replacementVal = 0;
		private decimal		m_oldOrgCost = 0;
		private decimal		m_newFacilityCost = 0;
		private int			m_sortOrder = 65000;
		private decimal		m_fundedFacilityCost = 0;
		private decimal		m_fundedReplaceValue = 0;
		private bool		m_usesCustomENR = false;

		private Hashtable	m_customENRValues = null;
		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		public				Facility(int id)
			: base(WAMSource.CurrentSource.ConnectionString, id)
		{
		}

		public				Facility(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		protected			Facility(System.Data.OleDb.OleDbDataReader reader)
			: base(WAMSource.CurrentSource.ConnectionString, reader)
		{
		}

		protected Facility(System.Data.OleDb.OleDbConnection sqlConnection, 
			System.Data.OleDb.OleDbDataReader reader)
			: base(sqlConnection, reader)
		{
		}

		protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_infoSetID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_currentYear = reader.GetInt16(col++);
			m_currentENR = reader.GetInt32(col++);
			m_captionNorth = Drive.SQL.ReadNullableString(reader, col++);
			m_captionSouth = Drive.SQL.ReadNullableString(reader, col++);
			m_captionEast = Drive.SQL.ReadNullableString(reader, col++);
			m_captionWest = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_replacementVal = reader.GetDecimal(col++);
			m_oldOrgCost = reader.GetDecimal(col++);
			m_newFacilityCost = reader.GetDecimal(col++);
			m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_fundedFacilityCost = reader.GetDecimal(col++);
			m_fundedReplaceValue = reader.GetDecimal(col++);
			m_usesCustomENR = reader.GetBoolean(col++);
		}
		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			Facility comp = obj as Facility;

			if (comp != null)
			{
				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);

				if (compare == 0)
					compare = Drive.Math.Compare(this.ID, comp.ID);

				return compare;
			}
			else
				throw new InvalidCastException("Not a facility");
		}
		#endregion /***** IComparable Members *****/

		#region /***** IFilterable Members *****/
		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterSource.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterSource.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterSource.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterSource.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterSource.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterSource.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterSource.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:
					break;
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:
					return false;
			}

			return true;
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					break;
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					return false;
				default:
					break;
			}

			return true;
		}
		#endregion /***** IFilterable Members *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR ");
			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE facility_id={0}", id);

			return builder.ToString();
		}

		protected override string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO Facilities (");

			builder.Append("infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_infoSetID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0}, ", m_currentYear);
			builder.AppendFormat("{0}, ", m_currentENR);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionNorth));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionSouth));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionEast));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionWest));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0:F2}, ", m_replacementVal);
			builder.AppendFormat("{0:F2}, ", m_oldOrgCost);
			builder.AppendFormat("{0:F2}, ", m_newFacilityCost);
			builder.AppendFormat("{0}, ", m_sortOrder);
			builder.AppendFormat("{0:F2}, ", m_fundedFacilityCost);
			builder.AppendFormat("{0:F2}, ", m_fundedReplaceValue);
			builder.AppendFormat("{0} ", Drive.SQL.JetBoolToBit(m_usesCustomENR));
			builder.Append(")");

			return builder.ToString();
		}

		protected override string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE Facilities SET ");
			builder.AppendFormat("infoset_id={0}, ", m_infoSetID);
			builder.AppendFormat("facility_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("facility_currentYear={0}, ", m_currentYear);
			builder.AppendFormat("facility_currentENR={0}, ", m_currentENR);
			builder.AppendFormat("facility_captionNorth={0}, ", Drive.SQL.StringToDBString(m_captionNorth));
			builder.AppendFormat("facility_captionSouth={0}, ", Drive.SQL.StringToDBString(m_captionSouth));
			builder.AppendFormat("facility_captionEast={0}, ", Drive.SQL.StringToDBString(m_captionEast));
			builder.AppendFormat("facility_captionWest={0}, ", Drive.SQL.StringToDBString(m_captionWest));
			builder.AppendFormat("facility_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("facility_replacementValue={0:F2}, ", m_replacementVal);
			builder.AppendFormat("facility_oldOrgCost={0:F2}, ", m_oldOrgCost);
			builder.AppendFormat("facility_newFacilityCost={0:F2}, ", m_newFacilityCost);
			builder.AppendFormat("facility_sortOrder={0}, ", m_sortOrder);
			builder.AppendFormat("facility_fundedFacilityCost={0:F2}, ", m_fundedFacilityCost);
			builder.AppendFormat("facility_fundedReplaceValue={0:F2}, ", m_fundedReplaceValue);
			builder.AppendFormat("facility_usesCustomENR={0} ", Drive.SQL.JetBoolToBit(m_usesCustomENR));

			builder.AppendFormat("WHERE (facility_id={0}) ", ID);
			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From Facilities WHERE facility_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Methods *****/
		public bool			SaveAsXML(string filePath)
		{
			System.IO.FileStream file = null;
			System.IO.StreamWriter writer = null;

			try
			{
				file = new System.IO.FileStream(filePath, 
					System.IO.FileMode.Create, System.IO.FileAccess.Write);

				writer = new System.IO.StreamWriter(file);
				writer.Write(GetXML());
				writer.Flush();
				writer.Close();
				writer = null;
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}
			return true;
		}

		public string		GetXML()
		{
			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();

			builder.Append("<FacilityData>\r\n");

			// Populate the basic facility data
			builder.Append("\t<Facility>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", CurrentENR);

			//mam - comment for testing
			//builder.AppendFormat("\t\t<Photo1Path><![CDATA[{0}]]></Photo1Path>\r\n", GetImage1Path());
			//builder.AppendFormat("\t\t<Photo1Caption><![CDATA[{0}]]></Photo1Caption>\r\n", CaptionNorth);
			//builder.AppendFormat("\t\t<Photo2Path><![CDATA[{0}]]></Photo2Path>\r\n", GetImage2Path());
			//builder.AppendFormat("\t\t<Photo2Caption><![CDATA[{0}]]></Photo2Caption>\r\n", CaptionSouth);
			//builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);
			//</mam>

			decimal			acquisitionCost = GetAcquisitionCost();
			decimal			currentValue = GetCurrentValue();

			//mam - added for testing

			builder.Append("\t</Facility>\r\n");

			builder.Append("\t<Processes>\r\n");
			builder.Append("\t\t<Process>\r\n");

			decimal			replacementValue = GetReplacementValue();
			decimal			bookValue = GetBookValue();
			decimal			salvageValue = GetSalvageValue();
			decimal			annualDepreciation = GetAnnualDepreciation();
			decimal			cumulativeDepreciation = GetCumulativeDepreciation();
			decimal			evaluatedValue = GetEvaluatedValue();
			decimal			repairCost = GetRepairCost();
			decimal			annualMaint = GetAnnualMaintenanceCost();
			decimal			cwp = 100.00m;

			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", Name);
			builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwp);
			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", acquisitionCost);
			builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", currentValue);
			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", replacementValue);
			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", bookValue);
			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", salvageValue);
			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", annualDepreciation);
			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", cumulativeDepreciation);
			builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", evaluatedValue);
			builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", repairCost);
			builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", annualMaint);

			builder.Append("\t\t</Process>\r\n");
			builder.Append("\t</Processes>\r\n");

			//</mam>

			//mam - comment for testing
			//decimal			fundedAcquisitionCost = GetFundedAcquisitionCost();
			//decimal			fundedCurrentValue = GetFundedCurrentValue();
			//</mam>

			//mam - comment for testing
			//builder.AppendFormat("\t\t<TotalAcquisition><![CDATA[{0:F0}]]></TotalAcquisition>\r\n", acquisitionCost);
			//builder.AppendFormat("\t\t<TotalCurrentValue><![CDATA[{0:F0}]]></TotalCurrentValue>\r\n", currentValue);
			//builder.AppendFormat("\t\t<AcqCostLessCumDepr><![CDATA[{0:F0}]]></AcqCostLessCumDepr>\r\n", acquisitionCost - GetCumulativeDepreciation());
			//builder.AppendFormat("\t\t<CurValLessRepairCost><![CDATA[{0:F0}]]></CurValLessRepairCost>\r\n", currentValue - GetRepairCost());
			//builder.AppendFormat("\t\t<ReplaceVal><![CDATA[{0:F0}]]></ReplaceVal>\r\n", GetReplacementValue());
			//builder.AppendFormat("\t\t<FundedTotalAcquisition><![CDATA[{0:F0}]]></FundedTotalAcquisition>\r\n", fundedAcquisitionCost);
			//builder.AppendFormat("\t\t<FundedTotalCurrentValue><![CDATA[{0:F0}]]></FundedTotalCurrentValue>\r\n", fundedCurrentValue);
			//builder.AppendFormat("\t\t<FundedAcqCostLessCumDepr><![CDATA[{0:F0}]]></FundedAcqCostLessCumDepr>\r\n", fundedAcquisitionCost - GetFundedCumulativeDepreciation());
			//builder.AppendFormat("\t\t<FundedCurValLessRepairCost><![CDATA[{0:F0}]]></FundedCurValLessRepairCost>\r\n", fundedCurrentValue - GetFundedRepairCost());
			//builder.AppendFormat("\t\t<FundedReplaceVal><![CDATA[{0:F0}]]></FundedReplaceVal>\r\n", GetFundedReplacementValue());
			//</mam>

			//mam - comment for testing
//			builder.Append("\t</Facility>\r\n");
//			
//			// Populate the treatment process data
//			WAM.Logic.TreatmentProcessTotals processTotals = GetProcessTotals();
//			TreatmentProcess[] processes = 
//				CacheManager.GetProcesses(m_infoSetID, ID);
//			int				pos;
//			decimal			totalValue = processTotals.GetTotalCurrentValue();
//			TreatmentProcess process;
//			double			cwpVal = 0.0;
//			decimal			orgCost = GetOrgCost();
//
//			builder.Append("\t<Processes>\r\n");
//			for (pos = 0; pos < processes.Length; pos++)
//			{
//				process = processes[pos];
//				builder.Append("\t\t<Process>\r\n");
//				builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);
//				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", process.Name);
//
//				if (totalValue != 0)
//					cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
//				else
//					cwpVal = 0.0;
//
//				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);
//				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", process.GetAcquisitionCost());
//				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", process.GetCurrentValue());
//				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", process.GetReplacementValue());
//				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", process.GetBookValue());
//				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", process.GetSalvageValue());
//				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", process.GetAnnualDepreciation());
//				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", process.GetCumulativeDepreciation());
//				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", process.GetEvaluatedValue());
//				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", process.GetRepairCost());
//				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", process.GetAnnualMaintenanceCost());
//				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", process.GetRankPercent());
//				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", process.GetOrgUsefulLife());
//				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", process.GetRemainingUsefulLife());
//				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", process.GetEvaluatedRemainingUsefulLife());
//
//				if (orgCost != 0m)
//					cwpVal = Math.Round((double)(process.OrgCost / orgCost) * 100.0, 1);
//				else
//					cwpVal = 0.0;
//
//				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", cwpVal);
//				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", process.OrgCost);
//				builder.Append("\t\t</Process>\r\n");
//			}
//			builder.Append("\t\t<Process>\r\n");
//			builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", false);
//			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", "Total");
//			builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", processTotals.GetCalcTotalCWP());
//			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", processTotals.GetTotalAcquisitionCost());
//			builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", processTotals.GetTotalCurrentValue());
//			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", processTotals.GetTotalReplacementValue());
//			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", processTotals.GetTotalBookValue());
//			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", processTotals.GetTotalSalvageValue());
//			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", processTotals.GetTotalAnnualDepreciation());
//			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", processTotals.GetTotalCumulativeDepreciation());
//			builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", processTotals.GetTotalEvaluatedValue());
//			builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", processTotals.GetTotalRepairCost());
//			builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", processTotals.GetTotalAnnualMaintenanceCost());
//			builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", processTotals.GetRankPercent());
//			builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", processTotals.GetTotalOrgUsefulLife());
//			builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", processTotals.GetTotalRemainingUsefulLife());
//			builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", processTotals.GetTotalEvaluatedRemainingUsefulLife());
//			builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", processTotals.GetTotalCWPValue() * 100.0);
//			builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", processTotals.GetTotalOrgCost());
//			builder.Append("\t\t</Process>\r\n");
//			builder.Append("\t</Processes>\r\n");
//
//			// Append Funded Processes
//			totalValue = processTotals.GetFundedTotalCurrentValue();
//			builder.Append("\t<FundedProcesses>\r\n");
//			for (pos = 0; pos < processes.Length; pos++)
//			{
//				process = processes[pos];
//				if (!process.IsFunded) // skip non-funded processes
//					continue;
//
//				builder.Append("\t\t<FundedProcess>\r\n");
//				builder.AppendFormat("\t\t\t<FundGridName><![CDATA[{0}]]></FundGridName>\r\n", process.Name);
//				builder.AppendFormat("\t\t\t<FundGridPctFunded><![CDATA[{0:F1}]]></FundGridPctFunded>\r\n", process.PctFunded * 100.0);
//
//				if (totalValue != 0)
//					cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
//				else
//					cwpVal = 0.0;
//
//				builder.AppendFormat("\t\t\t<FundGridCWP><![CDATA[{0:F1}]]></FundGridCWP>\r\n", cwpVal);
//				builder.AppendFormat("\t\t\t<FundGridAcquisitionCost><![CDATA[{0:F0}]]></FundGridAcquisitionCost>\r\n", process.GetAcquisitionCost());
//				builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", process.GetCurrentValue());
//				builder.AppendFormat("\t\t\t<FundGridReplacementValue><![CDATA[{0:F0}]]></FundGridReplacementValue>\r\n", process.GetReplacementValue());
//				builder.AppendFormat("\t\t\t<FundGridBookValue><![CDATA[{0:F0}]]></FundGridBookValue>\r\n", process.GetBookValue());
//				builder.AppendFormat("\t\t\t<FundGridSalvageValue><![CDATA[{0:F0}]]></FundGridSalvageValue>\r\n", process.GetSalvageValue());
//				builder.AppendFormat("\t\t\t<FundGridAnnualDepreciation><![CDATA[{0:F0}]]></FundGridAnnualDepreciation>\r\n", process.GetAnnualDepreciation());
//				builder.AppendFormat("\t\t\t<FundGridCumulativeDepreciation><![CDATA[{0:F0}]]></FundGridCumulativeDepreciation>\r\n", process.GetCumulativeDepreciation());
//				builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", process.GetEvaluatedValue());
//				builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", process.GetRepairCost());
//				builder.AppendFormat("\t\t\t<FundGridAnnualMaintenanceCost><![CDATA[{0:F0}]]></FundGridAnnualMaintenanceCost>\r\n", process.GetAnnualMaintenanceCost());
//				builder.AppendFormat("\t\t\t<FundGridRankPercent><![CDATA[{0:F1}]]></FundGridRankPercent>\r\n", process.GetRankPercent());
//				builder.AppendFormat("\t\t\t<FundGridOrgUsefulLife><![CDATA[{0:F1}]]></FundGridOrgUsefulLife>\r\n", process.GetOrgUsefulLife());
//				builder.AppendFormat("\t\t\t<FundGridRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridRemainingUsefulLife>\r\n", process.GetRemainingUsefulLife());
//				builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", process.GetEvaluatedRemainingUsefulLife());
//				builder.Append("\t\t</FundedProcess>\r\n");
//			}
//			builder.Append("\t\t<FundedProcess>\r\n");
//			builder.AppendFormat("\t\t\t<FundGridName><![CDATA[{0}]]></FundGridName>\r\n", "Total");
//			builder.Append("\t\t\t<FundGridPctFunded></FundGridPctFunded>\r\n");
//			builder.AppendFormat("\t\t\t<FundGridCWP><![CDATA[{0:F1}]]></FundGridCWP>\r\n", processTotals.GetFundedCalcTotalCWP());
//			builder.AppendFormat("\t\t\t<FundGridAcquisitionCost><![CDATA[{0:F0}]]></FundGridAcquisitionCost>\r\n", processTotals.GetFundedTotalAcquisitionCost());
//			builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", processTotals.GetFundedTotalCurrentValue());
//			builder.AppendFormat("\t\t\t<FundGridReplacementValue><![CDATA[{0:F0}]]></FundGridReplacementValue>\r\n", processTotals.GetFundedTotalReplacementValue());
//			builder.AppendFormat("\t\t\t<FundGridBookValue><![CDATA[{0:F0}]]></FundGridBookValue>\r\n", processTotals.GetFundedTotalBookValue());
//			builder.AppendFormat("\t\t\t<FundGridSalvageValue><![CDATA[{0:F0}]]></FundGridSalvageValue>\r\n", processTotals.GetFundedTotalSalvageValue());
//			builder.AppendFormat("\t\t\t<FundGridAnnualDepreciation><![CDATA[{0:F0}]]></FundGridAnnualDepreciation>\r\n", processTotals.GetFundedTotalAnnualDepreciation());
//			builder.AppendFormat("\t\t\t<FundGridCumulativeDepreciation><![CDATA[{0:F0}]]></FundGridCumulativeDepreciation>\r\n", processTotals.GetFundedTotalCumulativeDepreciation());
//			builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", processTotals.GetFundedTotalEvaluatedValue());
//			builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", processTotals.GetFundedTotalRepairCost());
//			builder.AppendFormat("\t\t\t<FundGridAnnualMaintenanceCost><![CDATA[{0:F0}]]></FundGridAnnualMaintenanceCost>\r\n", processTotals.GetFundedTotalAnnualMaintenanceCost());
//			builder.AppendFormat("\t\t\t<FundGridRankPercent><![CDATA[{0:F1}]]></FundGridRankPercent>\r\n", processTotals.GetRankPercent());
//			builder.AppendFormat("\t\t\t<FundGridOrgUsefulLife><![CDATA[{0:F1}]]></FundGridOrgUsefulLife>\r\n", processTotals.GetFundedTotalOrgUsefulLife());
//			builder.AppendFormat("\t\t\t<FundGridRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridRemainingUsefulLife>\r\n", processTotals.GetFundedTotalRemainingUsefulLife());
//			builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", processTotals.GetFundedTotalEvaluatedRemainingUsefulLife());
//			builder.Append("\t\t</FundedProcess>\r\n");
//			builder.Append("\t</FundedProcesses>\r\n");
			//</mam>

			builder.Append("</FacilityData>\r\n");
			

			return builder.ToString();
		}

		public void			CopyTo(Facility copy)
		{
			//copy.m_infoSetID = 0; // Don't copy InfoSet
			copy.m_name = m_name;
			copy.m_currentYear = m_currentYear;
			copy.m_currentENR = m_currentENR;
			copy.m_captionNorth = m_captionNorth;
			copy.m_captionSouth = m_captionSouth;
			copy.m_captionEast = m_captionEast;
			copy.m_captionWest = m_captionWest;
			copy.m_comments = m_comments;
			copy.m_replacementVal = m_replacementVal;
			copy.m_oldOrgCost = m_oldOrgCost;
			copy.m_newFacilityCost = m_newFacilityCost;
			copy.m_sortOrder = m_sortOrder;
			copy.m_fundedFacilityCost = m_fundedFacilityCost;
			copy.m_fundedReplaceValue = m_fundedReplaceValue;
			copy.m_usesCustomENR = m_usesCustomENR;
		}

		public void			CopyENRTable(Facility copy)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ENRCustom[] values = GetAllENRValues();

				for (int pos = 0; pos < values.Length; pos++)
					copy.SetENRValueForYear(values[pos].Year, values[pos].ENRValue);
			}
		}

		private void		LoadCustomENRValues()
		{
			if (m_usesCustomENR && m_customENRValues == null)
			{
				ENRCustom[]	enrData = ENRCustom.LoadForFacility(ID);

				m_customENRValues = new Hashtable(Drive.Math.FindHighestPrime(enrData.Length * 2), 1.0f);
				for (int pos = 0; pos < enrData.Length; pos++)
					m_customENRValues[enrData[pos].Year.GetHashCode()] = enrData[pos];
			}
		}

		public int			GetENRValueForYear(int year)
		{
			if (m_usesCustomENR)
			{
				// Make sure that the custom cache is loaded
				LoadCustomENRValues();
				ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				if (enr != null)
					return enr.ENRValue;

				return 0;
			}
			else
			{
				return ENR20CitiesCache.GetENRValueForYear(year);
			}
		}

		public void			SetENRValueForYear(int year, int enrValue)
		{
			if (m_usesCustomENR)
			{
				// Make sure that the custom cache is loaded
				LoadCustomENRValues();

				ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				if (enr != null)
				{
					enr.ENRValue = enrValue;
					enr.Save();
				}
				else
				{
					enr = new ENRCustom(0);
					enr.FacilityID = ID;
					enr.Year = year;
					enr.ENRValue = enrValue;
					enr.Save();

					m_customENRValues[year.GetHashCode()] = enr;
				}
			}
		}

		public bool			HasENRValueForYear(int year)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ENR20Cities		enr = (ENR20Cities)m_customENRValues[year.GetHashCode()];

				return (enr != null);
			}

			return false;
		}

		public void			DeleteENRValueForYear(int year)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ENRCustom	enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				if (enr != null)
				{
					m_customENRValues.Remove(year.GetHashCode());
					enr.Delete();
				}
			}
		}

		public ENRCustom	GetENRRecordForYear(int year)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ENRCustom		enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				return enr;
			}

			return null;
		}

		public ENRCustom[] GetAllENRValues()
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ICollection	items = m_customENRValues.Values;
				ENRCustom[]	enrItems = new ENRCustom[items.Count];

				items.CopyTo(enrItems, 0);
				Array.Sort(enrItems);

				return enrItems;
			}

			return new ENRCustom[0];
		}

		public string		GetFullName()
		{
			return Name;
		}

		public string		GetShortName()
		{
			return Name;
		}

		public decimal		GetYAxisValue(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return GetAcquisitionCost();
				case GraphYAxis.CurrentValue:
					return GetCurrentValue();
				case GraphYAxis.ReplacementValue:
					return GetReplacementValue();
				case GraphYAxis.BookValue:
					return GetBookValue();
				case GraphYAxis.SalvageValue:
					return GetSalvageValue();
				case GraphYAxis.AnnualDepreciation:
					return GetAnnualDepreciation();
				case GraphYAxis.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case GraphYAxis.EvaluatedValue:
					return GetEvaluatedValue();
				case GraphYAxis.RepairCost:
					return GetRepairCost();
				case GraphYAxis.AnnualMaintenanceCost:
					return GetAnnualMaintenanceCost();
			}

			return 0m;
		}

		public int			GetYearValue()
		{
			// Return the year
			return CurrentYear;
		}
		#endregion /***** Methods *****/

		#region /***** Properties *****/
		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public short		CurrentYear
		{
			get { return m_currentYear; }
			set 
			{ 
				m_currentYear = value;

				// For now, let's go ahead and keep m_currentENR in sync with the 
				// ENR table
				m_currentENR = GetENRValueForYear(m_currentYear);
			}
		}

		public int			CurrentENR
		{
			get { return GetENRValueForYear(m_currentYear); }
			set { m_currentENR = value; }
		}

		public string		CaptionNorth
		{
			get { return m_captionNorth; }
			set
			{
				if (value.Length > 255)
					m_captionNorth = value.Substring(255);
				else
					m_captionNorth = value;
			}
		}

		public string		CaptionSouth
		{
			get { return m_captionSouth; }
			set
			{
				if (value.Length > 255)
					m_captionSouth = value.Substring(255);
				else
					m_captionSouth = value;
			}
		}

		public string		CaptionEast
		{
			get { return m_captionEast; }
			set
			{
				if (value.Length > 255)
					m_captionEast = value.Substring(255);
				else
					m_captionEast = value;
			}
		}

		public string		CaptionWest
		{
			get { return m_captionWest; }
			set
			{
				if (value.Length > 255)
					m_captionWest = value.Substring(255);
				else
					m_captionWest = value;
			}
		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public decimal		ReplacementValue
		{
			get { return m_replacementVal; }
			set { m_replacementVal = value; }
		}

		public decimal		OldOrgCost
		{
			get { return m_oldOrgCost; }
			set { m_oldOrgCost = value; }
		}

		public decimal		NewFacilityCost
		{
			get { return m_newFacilityCost; }
			set { m_newFacilityCost = value; }
		}

		public decimal		FundedFacilityCost
		{
			get { return m_fundedFacilityCost; }
			set { m_fundedFacilityCost = value; }
		}

		public decimal		FundedReplaceValue
		{
			get { return m_fundedReplaceValue; }
			set { m_fundedReplaceValue = value; }
		}

		public int			SortOrder
		{
			get { return m_sortOrder; }
			set { m_sortOrder = value; }
		}

		public bool			UsesCustomENRTable
		{
			get { return m_usesCustomENR; }
			set { m_usesCustomENR = value; }
		}
		#endregion /***** Properties *****/

		#region /***** Photo Methods *****/
		public string		GetImage1Path()
		{
			InfoSet			infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);
			string			path = string.Format(
				@"{0}\{1:D4}-N.jpg", infoSet.GetImagePath(), ID);

			return path;
		}

		public string		GetImage2Path()
		{
			InfoSet			infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);
			string			path = string.Format(
				@"{0}\{1:D4}-S.jpg", infoSet.GetImagePath(), ID);

			return path;
		}

		public Image		GetPhoto1()
		{
			string			path = GetImage1Path();
			Image			image = null;

			if (System.IO.File.Exists(path))
				image = Image.FromFile(path);

			return image;
		}

		public Image		GetPhoto2()
		{
			string			path = GetImage2Path();
			Image			image = null;

			if (System.IO.File.Exists(path))
				image = Image.FromFile(path);

			return image;
		}
		#endregion /***** Photo Methods *****/

		#region		/***** Calculation Methods *****/
		private Logic.TreatmentProcessTotals
							m_processTotals = null;

		public void			RefreshTotals()
		{
			m_processTotals = new Logic.TreatmentProcessTotals(this);
		}

		public TreatmentProcess[] GetChildProcesses()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTreatmentProcesses();
		}

		public Logic.TreatmentProcessTotals GetProcessTotals()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals;
		}

		public bool			HasChildren
		{
			get
			{
				if (m_processTotals == null)
					RefreshTotals();

				return m_processTotals.GetTreatmentProcesses().Length > 0;
			}
		}

		public decimal		GetOldOrgCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCostOrgVal();
		}

		public decimal		GetOrgCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCost();
		}

		public decimal		GetAcquisitionCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAcquisitionCost();
		}

		public decimal		GetCurrentValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalCurrentValue();
		}

		public decimal		GetReplacementValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalReplacementValue();
		}

		public decimal		GetBookValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalBookValue();
		}

		public decimal		GetSalvageValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalSalvageValue();
		}

		public decimal		GetAnnualDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAnnualDepreciation();
		}

		public decimal		GetCumulativeDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalCumulativeDepreciation();
		}

		public decimal		GetEvaluatedValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalEvaluatedValue();
		}

		public decimal		GetRepairCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalRepairCost();
		}

		public decimal		GetAnnualMaintenanceCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAnnualMaintenanceCost();
		}

		public double		GetOrgUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgUsefulLife();
		}

		public double		GetRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalRemainingUsefulLife();
		}

		public double		GetEvaluatedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalEvaluatedRemainingUsefulLife();
		}

		public double		GetRankPercent()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetRankPercent();
		}

		public decimal		GetFacilityStraightLineA()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCostLessStrtLineDep();
		}

		public decimal		GetFacilityValue()
		{
			return GetOrgCost() - GetRepairCost();
		}

		public decimal		GetFundedCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalOrgCost();
		}

		public decimal		GetFundedAcquisitionCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAcquisitionCost();
		}

		public decimal		GetFundedCurrentValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCurrentValue();
		}

		public decimal		GetFundedReplacementValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalReplacementValue();
		}

		public decimal		GetFundedBookValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalBookValue();
		}

		public decimal		GetFundedSalvageValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalSalvageValue();
		}

		public decimal		GetFundedAnnualDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAnnualDepreciation();
		}

		public decimal		GetFundedCumulativeDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCumulativeDepreciation();
		}

		public decimal		GetFundedEvaluatedValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalEvaluatedValue();
		}

		public decimal		GetFundedRepairCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalRepairCost();
		}

		public decimal		GetFundedAnnualMaintenanceCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAnnualMaintenanceCost();
		}

		public double		GetFundedOrgUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalOrgUsefulLife();
		}

		public double		GetFundedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalRemainingUsefulLife();
		}

		public double		GetFundedEvaluatedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalEvaluatedRemainingUsefulLife();
		}

		public decimal		GetFundedOrgCostLessStrtLineDep()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCostLessStrtLineDep();
		}

		public decimal		GetFundedValue()
		{
			return GetFundedCost() - GetFundedRepairCost();
		}
		#endregion		/***** Calculation Methods *****/

		#region /***** Static Methods *****/
		public static Facility[] LoadAll(int infoSetID)
		{
			Facility[]		facilities = 
				LoadAll(WAMSource.CurrentSource.ConnectionString, infoSetID);

			return facilities;
		}

		public static Facility[] LoadAll(string connectionString, int infoSetID)
		{
			OleDbConnection	sqlConnection = 
				new OleDbConnection(connectionString);
			Facility[]		retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAll(sqlConnection, infoSetID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		public static Facility[] LoadAll(OleDbConnection sqlConnection, int infoSetID)
		{
			// open the database to retrieve info
			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			Facility		newObject;
			Facility[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR ");
			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE (infoset_id={0}) ", infoSetID);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			System.Diagnostics.Debug.Write(builder);
			System.Diagnostics.Debug.WriteLine("");

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), 
					sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new Facility(sqlConnection, dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new Facility[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		public static Facility[] LoadForFacilityName(string facilityName, int infoSetID, OleDbConnection sqlConnection)
		{
			// open the database to retrieve info
			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			Facility		newObject;
			Facility[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR ");
			builder.Append("FROM Facilities ");
			builder.Append("WHERE (");
			builder.AppendFormat("facility_name='{0}' AND ", Drive.SQL.PadString(facilityName));
			builder.AppendFormat("infoset_id={0}) ", infoSetID);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new Facility(sqlConnection, dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadForFacilityName Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new Facility[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}
		#endregion /***** Static Methods *****/
	}

	#region /***** Cache Class *****/
	public class			FacilityCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable(17);
		private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
							m_changeDelegate = null;
		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.Facility));
		private int			m_infoSetID = 0;

		public				FacilityCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			m_changeDelegate = 
				new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged);

			// Handle the global event
			Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(m_changeDelegate);
		}

		public int			InfoSetID
		{
			get { return m_infoSetID; }
		}

		#region IDisposable Members
		~FacilityCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event
					Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
						m_changeDelegate);
					m_changeDelegate = null;
				}
            }
        }
		#endregion

		private void DataChanged(object sender, 
			Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		{
			Facility		obj = e.ChangedObject as Facility;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.InfoSetID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.InfoSetID, obj);
			}
		}

		public Facility[]	GetAll()
		{
			Facility[] children = (Facility[])m_treeHash.GetChildren(m_infoSetID);

			if (children == null)
			{
				System.Diagnostics.Trace.WriteLine("Generating Facility cache");
				children = Facility.LoadAll(m_infoSetID);
				m_treeHash.SetChildren(m_infoSetID, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}

			return children;
		}

		public void			Sort()
		{
			m_treeHash.Sort(m_infoSetID);
		}

		public Facility[]   BuildCache(OleDbConnection connection)
		{
			Facility[]		children = Facility.LoadAll(connection, m_infoSetID);

			m_treeHash.SetChildren(m_infoSetID, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		public Facility		GetFacility(int id)
		{
			// Look up the facility in the hash table
			Facility		facility = m_hash[id.GetHashCode()] as Facility;

			// If the facility is not present, load it from the default database
			if (facility == null)
			{
				facility = new Facility(id);

				// If it doesn't exist in the database, then reset it
				if (facility.ID != 0)
					m_hash[facility.GetHashCode()] = facility;
				else
					facility = null;
			}

			return facility;
		}
	}
	#endregion /***** Cache Class *****/
}
