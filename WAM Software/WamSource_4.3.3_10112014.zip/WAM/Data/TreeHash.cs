using System;
using System.Collections;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for TreeHash.
	/// </summary>
	public class TreeHash
	{
		private Hashtable	m_hashTable = new Hashtable(Drive.Math.FindHighestPrime(97));
		private System.Type m_nodeType;

		public				TreeHash(System.Type nodeType)
		{
			m_nodeType = nodeType;
		}

		public void			Clear()
		{
			m_hashTable.Clear();
		}

		public void			Sort(int parentID)
		{
			ChildNode		node = m_hashTable[parentID.GetHashCode()] as ChildNode;

			if (node != null)
				node.m_childObjects.Sort();
		}

		public Array 		GetChildren(int parentID)
		{
			ChildNode		node = m_hashTable[parentID.GetHashCode()] as ChildNode;

			if (node == null)
				return null;

			Array			fillArray;
			
			fillArray = Array.CreateInstance(m_nodeType, node.m_childObjects.Count);

			if (node.m_childObjects.Count > 0)
				node.m_childObjects.CopyTo(fillArray);
			return fillArray;
		}

		public void			SetChildren(int parentID, Array children)
		{
			ChildNode		node = m_hashTable[parentID.GetHashCode()] as ChildNode;

			if (node == null)
			{
				node = new ChildNode(parentID);
				m_hashTable.Add(node.GetHashCode(), node);
			}
			else
				node.m_childObjects.Clear();

			node.m_childObjects.AddRange(children);
		}

		public void			AddChild(int parentID, object child)
		{
			ChildNode		node = m_hashTable[parentID.GetHashCode()] as ChildNode;

			if (node == null)
			{
				node = new ChildNode(parentID);
				m_hashTable.Add(node.GetHashCode(), node);
			}

			node.m_childObjects.Add(child);
			node.m_childObjects.Sort();
		}

		public void			RemoveChild(int parentID, object child)
		{
			ChildNode		node = m_hashTable[parentID.GetHashCode()] as ChildNode;

			if (node == null)
				return;

			node.m_childObjects.Remove(child);
		}
	}

	internal class ChildNode
	{
		internal int		m_parentID = 0;
		internal ArrayList	m_childObjects = new ArrayList();

		internal			ChildNode(int parentID)
		{
			m_parentID = parentID;
		}

		public override int GetHashCode()
		{
			return m_parentID.GetHashCode();
		}
	}
}
