using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Diagnostics;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

//mam 07072011
using System.Xml;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for MajorComponent.
	/// </summary>
	
	//mam 102309
	//public class MajorComponent : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable, IGraphableUnit
	public class MajorComponent : Drive.Data.SqlClient.SqlDALInt32Key, IComparable, IFilterable, IGraphableUnit
	{
		#region /***** Member Variables *****/
		private int			m_processID = 0;
		private string		m_name = "";
		private double		m_CWPValue = 0.0;
		private string		m_captionPhoto = "";
		private string		m_comments = "";
		private int			m_sortOrder = 65000;

		//mam 102309
		//private string m_photo = "";

		private LevelOfService m_LOS = LevelOfService.LOS1;

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using the four fixed crits
		//private CriticalityPublicHealth m_critPublic = CriticalityPublicHealth.NoEffect;
		//private CriticalityEnvironmental m_critEnvironmental = CriticalityEnvironmental.NoEffect;
		//private CriticalityRepairCost m_critRepair = CriticalityRepairCost.LessThan5k;
		//private CriticalityCustomerEffect m_critCustEffect = CriticalityCustomerEffect.NoEffect;
		private byte m_critPublic = 0;
		private byte m_critEnvironmental = 0;
		private byte m_critRepair = 0;
		private byte m_critCustEffect = 0;

		//mam 112806
		private bool mscOverrideAnyCurrentValue = false;
		private bool mscOverrideAnyRepairCost = false;
		private bool pipeOverrideAnyCurrentValue = false;
		private bool pipeOverrideAnyRepairCost = false;
		private bool nodeOverrideAnyCurrentValue = false;
		private bool nodeOverrideAnyRepairCost = false;

		//mam - use probability instead of year
		//private Vulnerability m_vulnerability = Vulnerability.FailureLikely50;
		private double m_vulnerability = 0.0;
		private bool		m_overrideVulnerability = false;
		private bool useNA = false;
		bool isNA = false;
		WAM.Logic.DisciplineTotals disciplineTotalsSort = null;
		bool nodesERULVulnNASort = false;
		bool pipesERULVulnNASort = false;
		//</mam>

		private bool		m_mechStructDisc = true;
		private bool		m_retired = false;

		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		//mam 090105
		private string processName = string.Empty;
		private int facilityID = 0;
		//</mam>

		//mam 050806
		private int m_redundantAssetCount = 1;
		private int treeNodeIndex = 0;

		//mam 07072011
		private string m_assetClass = "";
		private int m_cipPlanningId = Common.CommonTasks.DefaultCipPlanningId;

		//mam 07072011
		//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
		private MajorComponentSelectedCriticalityFactorsCollection componentSelectedCritFactorCollection = new MajorComponentSelectedCriticalityFactorsCollection();

		//mam 03202012
		private string m_photoFileName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		//mam 102309
		//public MajorComponent(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public MajorComponent(int id) 
			: base(Globals.WamSqlConnectionString, id)
		{
		}

		////mam 11142011
		//public MajorComponent(int id, bool forImport) : base(WAMSource.CurrentSource.ConnectionString, id)
		//{
		//}

		public MajorComponent(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		//mam 102309
		//protected MajorComponent(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected MajorComponent(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
		{
		}

		//mam 07072011 - new method
		protected MajorComponent(System.Data.SqlClient.SqlDataReader reader, DataAccess dataAccess)
			: base(Globals.WamSqlConnectionString, reader)
		{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_processID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_CWPValue = reader.GetDouble(col++);
			m_LOS = (LevelOfService)reader.GetByte(col++);

			//mam 11142011 - we need these when importing data from an Access database
			//mam 07072011 - using different method to store selected criticality values
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);
			m_critPublic = reader.GetByte(col++);
			m_critEnvironmental = reader.GetByte(col++);
			m_critRepair = reader.GetByte(col++);
			m_critCustEffect = reader.GetByte(col++);

			//mam - use probability instead of year
			//m_vulnerability = (Vulnerability)reader.GetByte(col++);
			//m_vulnerability = (double)reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			m_vulnerability = Drive.SQL.ReadNullableDouble(reader, col++);

			//</mam

			m_mechStructDisc = reader.GetBoolean(col++);

			//mam - if not MechStructDisc, set overrideVulnerability to false 
			//	because it does not apply at this level for pipes and nodes
			if (!m_mechStructDisc)
				m_overrideVulnerability = false;
			//</mam>
			m_retired = reader.GetBoolean(col++);

			m_captionPhoto = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);

			//mam 050806
			m_redundantAssetCount = reader.GetInt32(col++);

			//mam 07072011 - put these here only to be consistent - since the Access database has not been updated
			//	to include these fields (AssetClass and CipPlanningId), don't try to get these values from an Access database
			//m_assetClass = Drive.SQL.ReadNullableString(reader, col++);
			//m_assetClass = Drive.SQL.ReadNullableInt32(reader, col++);
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(System.Data.SqlClient.SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_processID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_CWPValue = reader.GetDouble(col++);
			m_LOS = (LevelOfService)reader.GetByte(col++);

			//mam 07072011 - using different method to store selected criticality values
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);

			//mam - use probability instead of year
			//m_vulnerability = (Vulnerability)reader.GetByte(col++);
			//m_vulnerability = (double)reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			//mam 102309
			//m_vulnerability = Drive.SQL.ReadNullableDouble(reader, col++);
			m_vulnerability = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			//</mam

			m_mechStructDisc = reader.GetBoolean(col++);

			//mam - if not MechStructDisc, set overrideVulnerability to false 
			//	because it does not apply at this level for pipes and nodes
			if (!m_mechStructDisc)
				m_overrideVulnerability = false;
			//</mam>
			m_retired = reader.GetBoolean(col++);

			//mma 102309
			//m_captionPhoto = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			//m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_captionPhoto = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 03202012
			m_photoFileName = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 102309
			//m_photo = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_sortOrder = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 050806
			m_redundantAssetCount = reader.GetInt32(col++);

			//mam 07072011
			m_assetClass = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_cipPlanningId = reader.IsDBNull(col) ? 0 : reader.GetInt32(col);
			//m_cipPlanningId = reader.GetInt32(col++);
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			MajorComponent comp = obj as MajorComponent;

			if (comp != null)
			{
				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);

				if (compare == 0)
					compare = Drive.Math.Compare(this.ID, comp.ID);

				return compare;
			}
			else
				throw new InvalidCastException("Not a major component");
		}

		//mam - compare Components by their various values
		public int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)
		{
			MajorComponent rhs = obj as MajorComponent;
			int result = 0;

			disciplineTotalsSort = this.GetDisciplineTotals();
			this.isNA = disciplineTotalsSort.CheckIfAllNADiscipline(this.InfoSetID, this.ID);
			
			disciplineTotalsSort = rhs.GetDisciplineTotals();
			rhs.isNA = disciplineTotalsSort.CheckIfAllNADiscipline(rhs.InfoSetID, rhs.ID);

			//if pipe or node, determine ERUL and Vuln override
			//**************************************************
			Discipline[] disciplines;
			Discipline discipline;

			disciplines = CacheManager.GetDisciplines(this.InfoSetID, this.ID);
			//decimal totalValue = disciplineTotals.GetTotalCurrentValue();
			DisciplinePipe	pipe;
			DisciplineNode	node;
			int pos = 0;

			for (pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (!this.MechStructDisciplines)
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
							this.pipesERULVulnNASort = true;
						else
							this.pipesERULVulnNASort = false;
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
							this.nodesERULVulnNASort = true;
						else
							this.nodesERULVulnNASort = false;
					}
				}
			}

			disciplines = CacheManager.GetDisciplines(rhs.InfoSetID, rhs.ID);
			for (pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (!rhs.MechStructDisciplines)
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
							rhs.pipesERULVulnNASort = true;
						else
							rhs.pipesERULVulnNASort = false;
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
							rhs.nodesERULVulnNASort = true;
						else
							rhs.nodesERULVulnNASort = false;
					}
				}
			}
			//**************************************************

			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a component");

			return result;
		}
		//</mam>

		//mam - compare each Component as necessary
		private int CompareToEach(MajorComponent rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;

			try
			{
				switch (which)
				{
						//mam 050806
					case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
						result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
						break;
						//mam

					case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
						if (lowToHigh)
							result = this.GetAcquisitionCost().CompareTo(rhs.GetAcquisitionCost());
						else
							result = rhs.GetAcquisitionCost().CompareTo(this.GetAcquisitionCost());

						break;

						//mam 050806
					case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
						if (lowToHigh)
							result = this.GetAcquisitionCostEscalated().CompareTo(rhs.GetAcquisitionCostEscalated());
						else
							result = rhs.GetAcquisitionCostEscalated().CompareTo(this.GetAcquisitionCostEscalated());

						break;

						//mam 050806
					case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
						if (lowToHigh)
							result = this.GetRehabCost().CompareTo(rhs.GetRehabCost());
						else
							result = rhs.GetRehabCost().CompareTo(this.GetRehabCost());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
						if (lowToHigh)
							result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
						else
							result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
						if (lowToHigh)
							result = this.GetReplacementValue().CompareTo(rhs.GetReplacementValue());
						else
							result = rhs.GetReplacementValue().CompareTo(this.GetReplacementValue());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
						if (lowToHigh)
							result = this.GetBookValue().CompareTo(rhs.GetBookValue());
						else
							result = rhs.GetBookValue().CompareTo(this.GetBookValue());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
						if (lowToHigh)
							result = this.GetSalvageValue().CompareTo(rhs.GetSalvageValue());
						else
							result = rhs.GetSalvageValue().CompareTo(this.GetSalvageValue());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
						if (lowToHigh)
							result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
						else
							result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
						if (lowToHigh)
							result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
						else
							result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetEvaluatedValue().CompareTo(rhs.GetEvaluatedValue());
						//						else
						//							result = rhs.GetEvaluatedValue().CompareTo(this.GetEvaluatedValue());
						if (lowToHigh)
							result = this.SortGetEvaluatedValue().CompareTo(rhs.SortGetEvaluatedValue());
						else
							result = rhs.SortGetEvaluatedValue().CompareTo(this.SortGetEvaluatedValue());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetRepairCost().CompareTo(rhs.GetRepairCost());
						//						else
						//							result = rhs.GetRepairCost().CompareTo(this.GetRepairCost());
						if (lowToHigh)
							result = this.SortGetRepairCost().CompareTo(rhs.SortGetRepairCost());
						else
							result = rhs.SortGetRepairCost().CompareTo(this.SortGetRepairCost());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
						if (lowToHigh)
							result = this.GetAnnualMaintenanceCost().CompareTo(rhs.GetAnnualMaintenanceCost());
						else
							result = rhs.GetAnnualMaintenanceCost().CompareTo(this.GetAnnualMaintenanceCost());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetOrgUsefulLife().CompareTo(rhs.GetOrgUsefulLife());
						//						else
						//							result = rhs.GetOrgUsefulLife().CompareTo(this.GetOrgUsefulLife());
						if (lowToHigh)
							result = this.SortGetOrgUsefulLife().CompareTo(rhs.SortGetOrgUsefulLife());
						else
							result = rhs.SortGetOrgUsefulLife().CompareTo(this.SortGetOrgUsefulLife());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetRemainingUsefulLife().CompareTo(rhs.GetRemainingUsefulLife());
						//						else
						//							result = rhs.GetRemainingUsefulLife().CompareTo(this.GetRemainingUsefulLife());
						if (lowToHigh)
							result = this.SortGetRemainingUsefulLife().CompareTo(rhs.SortGetRemainingUsefulLife());
						else
							result = rhs.SortGetRemainingUsefulLife().CompareTo(this.SortGetRemainingUsefulLife());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetEvaluatedRemainingUsefulLife().CompareTo(rhs.GetEvaluatedRemainingUsefulLife());
						//						else
						//							result = rhs.GetEvaluatedRemainingUsefulLife().CompareTo(this.GetEvaluatedRemainingUsefulLife());
						if (lowToHigh)
							result = this.SortGetEvaluatedRemainingUsefulLife().CompareTo(rhs.SortGetEvaluatedRemainingUsefulLife());
						else
							result = rhs.SortGetEvaluatedRemainingUsefulLife().CompareTo(this.SortGetEvaluatedRemainingUsefulLife());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
						if (lowToHigh)
							result = this.SortGetEconomicUsefulLife().CompareTo(rhs.SortGetEconomicUsefulLife());
						else
							result = rhs.SortGetEconomicUsefulLife().CompareTo(this.SortGetEconomicUsefulLife());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetRankPercentInterpolated().CompareTo(rhs.GetRankPercentInterpolated());
						//						else
						//							result = rhs.GetRankPercentInterpolated().CompareTo(this.GetRankPercentInterpolated());
						if (lowToHigh)
							result = this.SortGetRankPercentInterpolated().CompareTo(rhs.SortGetRankPercentInterpolated());
						else
							result = rhs.SortGetRankPercentInterpolated().CompareTo(this.SortGetRankPercentInterpolated());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetLOS().CompareTo(rhs.GetLOS());
						//						else
						//							result = rhs.GetLOS().CompareTo(this.GetLOS());
						if (lowToHigh)
							result = this.SortGetLOS().CompareTo(rhs.SortGetLOS());
						else
							result = rhs.SortGetLOS().CompareTo(this.SortGetLOS());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
						//mam - use new method that will return -1 for N/A value
						//	overall crit can only be N/A for pipes and nodes
						//						if (lowToHigh)
						//							result = this.GetOverallCriticality().CompareTo(rhs.GetOverallCriticality());
						//						else
						//							result = rhs.GetOverallCriticality().CompareTo(this.GetOverallCriticality());
						if (lowToHigh)
							result = this.SortGetOverallCriticality().CompareTo(rhs.SortGetOverallCriticality());
						else
							result = rhs.SortGetOverallCriticality().CompareTo(this.SortGetOverallCriticality());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
						//mam - use new method that will return -1 for N/A value
						//						if (lowToHigh)
						//							result = this.GetVulnerability().CompareTo(rhs.GetVulnerability());
						//						else
						//							result = rhs.GetVulnerability().CompareTo(this.GetVulnerability());
						if (lowToHigh)
							result = this.SortGetVulnerability().CompareTo(rhs.SortGetVulnerability());
						else
							result = rhs.SortGetVulnerability().CompareTo(this.SortGetVulnerability());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
						//mam - use new method that will return -1 for N/A value
						//	overall crit can only be N/A for pipes and nodes
						//						if (lowToHigh)
						//							result = this.GetRisk().CompareTo(rhs.GetRisk());
						//						else
						//							result = rhs.GetRisk().CompareTo(this.GetRisk());
						if (lowToHigh)
							result = this.SortGetRisk().CompareTo(rhs.SortGetRisk());
						else
							result = rhs.SortGetRisk().CompareTo(this.SortGetRisk());

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.AssetClass:
						if (lowToHigh)
							result = this.AssetClass.CompareTo(rhs.AssetClass);
						else
							result = rhs.AssetClass.CompareTo(this.AssetClass);

						break;

					case WAM.Logic.UnitFilter.FilterSourceSort.CipMode:
						if (lowToHigh)
							result = this.SortGetCip().CompareTo(rhs.SortGetCip());
						else
							result = rhs.SortGetCip().CompareTo(this.SortGetCip());

						break;


					case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
						break;

					default:
						System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
							System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

						break;
				}
				return result;
			}
			catch(Exception ex)
			{
				System.Windows.Forms.MessageBox.Show("TError.  " + ex.ToString(), "Error",
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
				return 0;
			}
		}
		//</mam>

		private string GetStringNA()
		{
			return "N/A";
		}

		private double GetDoubleNA()
		{
			return -1.0;
		}

		#endregion /***** IComparable Members *****/

		#region /***** Nested Class MajorComponentComparer *****/
		//mam
		public class MajorComponentComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				MajorComponent l = (MajorComponent) lhs;
				MajorComponent r = (MajorComponent) rhs;

				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}

			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class MajorComponentComparer *****/

		#region /***** IFilterable Members *****/

		//mam 07072011
		public string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AssetClass:
				{
					return AssetClass;
				}
				case WAM.Logic.UnitFilter.FilterSource.CipMode:
				{
					return GetCipModeTextFromId(Common.CommonTasks.GetCipObjects(), m_cipPlanningId);
				}
			}

			return "";
		}

		//mam 07072011
		public bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			return true;
		}

		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterSource.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterSource.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterSource.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterSource.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterSource.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterSource.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterSource.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterSource.RehabCost:
					return GetRehabCost();

					//mam
				case WAM.Logic.UnitFilter.FilterSource.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
					//</mam>

					//mam - use interpolated value (not really interpolated, but that's what it's called)
					//case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					//	return Math.Round(((decimal)GetRankPercent()), 1);
				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)GetRankPercentInterpolated()), 1);
					//</mam>

				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
					return Math.Round(((decimal)LOS), 1);
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
					return Math.Round(((decimal)GetOverallCriticality()), 1);

					//mam - use probability
					//case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
					//	return decimal.Parse(EnumHandlers.GetVulnerabilityShort(Vulnerability));
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
					//mam 090105 - round vuln to 4 decimals rather than 2
					//return Math.Round(((decimal)Vulnerability), 2);
					return Math.Round(((decimal)Vulnerability), 4);
					//</mam>

				case WAM.Logic.UnitFilter.FilterSource.Risk:
					return Math.Round(((decimal)GetRisk()), 2);

				case WAM.Logic.UnitFilter.FilterSource.InstallYear:

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					break;
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.InstallYear:

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					//mam 01222012
					//return false;

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSource.CipMode:
				case WAM.Logic.UnitFilter.FilterSource.AssetClass:
				{
					if (m_mechStructDisc)
					{
						return true;
					}

					return false;
				}
			}

			return true;
		}

		//mam 07072011
		public string GetRHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AssetClass:
				{
					return AssetClass;
				}
			}

			return "";
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

					//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabCost:
					return GetRehabCost();

					//mam
				case WAM.Logic.UnitFilter.FilterCompareTo.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
					//</mam>

					//mam - use interpolated
					//case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					//	return Math.Round(((decimal)GetRankPercent()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)GetRankPercentInterpolated()), 1);
					//</mam>

				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					return Math.Round(((decimal)LOS), 1);

					//mam - added the following cases (why were they not here already?)
				case WAM.Logic.UnitFilter.FilterCompareTo.OverallCriticality:
					return Math.Round(((decimal)GetOverallCriticality()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.Vulnerability:
					//mam 090105 - round vuln to 4 decimals rather than 2
					//return Math.Round(((decimal)Vulnerability), 2);
					return Math.Round(((decimal)Vulnerability), 4);
				case WAM.Logic.UnitFilter.FilterCompareTo.Risk:
					return Math.Round(((decimal)GetRisk()), 2);

				case WAM.Logic.UnitFilter.FilterCompareTo.InstallYear:

					//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValueYear:

					break;
					//</mam>
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			return true;
		}
		#endregion /***** IFilterable Members *****/

		#region /****** SQL Statements ******/

		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT ");
			builder.Append("component_id, process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService, ");

			//mam 07072011 - using different method to store selected criticality values
			//builder.Append("component_critPublicHealth, component_critEnvironmental, ");
			//builder.Append("component_critRepairCost, component_critCustomerEffect, ");

			//mam - use probability
			builder.Append("component_vulnerability, component_MechStructDisc, ");
			//</mam>

			builder.Append("component_retired, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("component_captionPhoto, PhotoFileName, component_comments, ");

			builder.Append("component_sortOrder");

			//mam 050806
			builder.Append(", RedundantAssetCount");

			//mam 07072011
			builder.Append(", AssetClass");
			builder.Append(", CipPlanningId ");

			builder.Append("FROM MajorComponents ");
			builder.AppendFormat("WHERE component_id={0}", id);

			System.Diagnostics.Debug.WriteLine(builder.ToString());
			return builder.ToString();
		}

		//mam 102309
		public string GetInsertSqlForCopy()
		{
			return GetInsertSql();
		}

		//mam 102309
		//public string GetUpdateSqlForImport()
		//{
		//	return GetUpdateSql();
		//}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - added bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				System.Diagnostics.Debug.WriteLine(ex.Message.ToString());
				//string msg = "An error occurred while saving data." + Environment.NewLine + Environment.NewLine;
				//WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.Save", "An error has occurred: " + msg + ex.Message);
				string msg = "Error in " + this.Name + ".Save:" + Environment.NewLine + Environment.NewLine + ex.Message;
				throw new Exception(msg);
				//return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for saving a single criticality value to the database
		public bool SaveCriticalityValue(int criticalityId, int scoreId)
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				//bool flag = !this.Valid;
				//if (flag)
				//{
				//	this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				//}
				//else
				//{
				dataAccess.ExecuteCommand(this.GetUpdateSqlCriticalityValue(criticalityId, scoreId));
				//}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					//if (flag)
					//{
					//	add = Drive.Synchronization.SyncAction.Add;
					//}
					//else
					//{
					add = Drive.Synchronization.SyncAction.Edit;
					//}
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				string msg = "An error occurred while saving Criticality values." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.SaveCriticalityValue", "An error has occurred: " + msg + ex.Message);
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for saving all criticality values
		public bool SaveCriticalityValuesAll()
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				string xmlString = Common.CommonTasks.CreateCriticalityXmlString(componentSelectedCritFactorCollection);
				dataAccess.ExecuteCommandInsertCriticalityValuesComponent(this.ID, xmlString, false);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				string msg = "An error occurred while saving Criticality values." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.SaveCriticalityValuesAll", "An error has occurred: " + msg + ex.Message);
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting criticality values from one major component to another
		public bool InsertCriticalityValuesAllCopy(int sourceComponentId, int destinationComponentId)
		{
			if (!this.MechStructDisciplines)
			{
				return true;
			}

			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityCopy", "@sourceComponentId", "@destinationComponentId", sourceComponentId, destinationComponentId);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				string msg = "An error occurred while saving Criticality values." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.InsertCriticalityValuesAll", "An error has occurred: " + msg + ex.Message);
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting all criticality default values
		public bool InsertCriticalityValuesAllDefault()
		{
			if (!this.MechStructDisciplines)
			{
				return true;
			}

			//this is used when creating a new Major Component

			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityDefault", "@componentId", this.ID);

				//populate the crit collection for this major component
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityByComponent", "@componentId", this.ID);
				ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesIntoCollection(dataTable);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				string msg = "An error occurred while saving Criticality values." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.InsertCriticalityValuesAllDefault", "An error has occurred: " + msg + ex.Message);
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO MajorComponents (");

			builder.Append("process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService,");

			//mam 07072011 - using different method to store selected criticality values
			//builder.Append("component_critPublicHealth, component_critEnvironmental,");
			//builder.Append("component_critRepairCost, component_critCustomerEffect,");

			builder.Append("component_vulnerability, component_MechStructDisc, ");
			builder.Append("component_retired, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("component_captionPhoto, PhotoFileName, component_comments, ");

			builder.Append("component_sortOrder ");

			//mam 050806
			builder.Append(", RedundantAssetCount");

			//mam 07072011
			builder.Append(", AssetClass");
			builder.Append(", CipPlanningId ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_processID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0:F6}, ", m_CWPValue);
			builder.AppendFormat("{0}, ", (byte)m_LOS);

			//mam 07072011 - using different method to store selected criticality values
			//builder.AppendFormat("{0}, ", (byte)m_critPublic);
			//builder.AppendFormat("{0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("{0}, ", (byte)m_critRepair);
			//builder.AppendFormat("{0}, ", (byte)m_critCustEffect);

			//mam - use probability
			//builder.AppendFormat("{0}, ", (byte)m_vulnerability);
			if (m_overrideVulnerability)
				builder.AppendFormat("{0:F4}, ", m_vulnerability);
			else
				builder.Append("NULL, ");
			//</mam>

			builder.AppendFormat("{0}, ", Drive.SQL.BoolToBit(m_mechStructDisc));
			builder.AppendFormat("{0}, ", Drive.SQL.BoolToBit(m_retired));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionPhoto));

			//mam 03202012
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			//mam 102309
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photo));

			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0} ", m_sortOrder);

			//mam 050806
			builder.AppendFormat(", {0}", m_redundantAssetCount);

			//mam 07072011
			////builder.AppendFormat(", {0}", m_assetClass);
			builder.AppendFormat(", {0}", Drive.SQL.StringToDBString(m_assetClass));
			if (m_cipPlanningId == 0)
			{
				builder.AppendFormat(", NULL");
			}
			else
			{
				builder.AppendFormat(", {0}", m_cipPlanningId);
			}

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());
			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE MajorComponents SET ");
			builder.AppendFormat("process_id={0}, ", m_processID);
			builder.AppendFormat("component_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("component_CWPValue={0:F6}, ", m_CWPValue);
			builder.AppendFormat("component_LevelOfService={0}, ", (byte)m_LOS);

			//mam 07072011 - using different method to store selected criticality values
			//builder.AppendFormat("component_critPublicHealth={0}, ", (byte)m_critPublic);
			//builder.AppendFormat("component_critEnvironmental={0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("component_critRepairCost={0}, ", (byte)m_critRepair);
			//builder.AppendFormat("component_critCustomerEffect={0}, ", (byte)m_critCustEffect);

			//mam - use probability
			//builder.AppendFormat("component_vulnerability={0}, ", (byte)m_vulnerability);
			if (m_overrideVulnerability)
				builder.AppendFormat("component_vulnerability={0:F4}, ", m_vulnerability);
			else
				builder.Append("component_vulnerability=NULL, ");
			//</mam>

			builder.AppendFormat("component_MechStructDisc={0}, ", Drive.SQL.BoolToBit(m_mechStructDisc));
			builder.AppendFormat("component_retired={0}, ", Drive.SQL.BoolToBit(m_retired));
			builder.AppendFormat("component_captionPhoto={0}, ", Drive.SQL.StringToDBString(m_captionPhoto));

			//mam 03202012
			builder.AppendFormat("PhotoFileName={0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			builder.AppendFormat("component_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("component_sortOrder={0} ", m_sortOrder);

			//mam 050806
			builder.AppendFormat(", RedundantAssetCount={0}", m_redundantAssetCount);

			//mam 07072011
			builder.AppendFormat(", AssetClass={0} ", Drive.SQL.StringToDBString(m_assetClass));
			if (m_cipPlanningId == 0)
			{
				builder.AppendFormat(", CipPlanningId=NULL ");
			}
			else
			{
				builder.AppendFormat(", CipPlanningId={0} ", m_cipPlanningId);
			}
			//builder.AppendFormat(", CipPlanningId={0} ", m_cipPlanningId);

			builder.AppendFormat("WHERE (component_id={0}) ", ID);

			//System.Diagnostics.Debug.WriteLine(builder.ToString());
			return builder.ToString();
		}

		//mam 07072011 - new method
		protected string GetUpdateSqlCriticalityValue(int criticalityId, int scoreId)
		{
			// save a single criticality value to the database

			StringBuilder builder = new StringBuilder();

			builder.Append("UPDATE MajorComponentToCriticality");
			builder.AppendFormat(" SET CriticalityScoreId = {0}", scoreId);
			builder.AppendFormat(" WHERE component_id = {0} AND CriticalityId = {1}", this.ID, criticalityId);			

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From MajorComponents WHERE component_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/

		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public int			ProcessID
		{
			get { return m_processID; }
			set { m_processID = value; }
		}

		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		//mam 050806
		public int RedundantAssetCount
		{
			get 
			{ return m_redundantAssetCount; }
			set 
			{ 
				m_redundantAssetCount = value; 
			}
		}

		//mam 07072011
		public string AssetClass
		{
			get { return m_assetClass; }
			set { m_assetClass= value; }
		}

		//mam 07072011
		public int CipPlanningId
		{
			get { return m_cipPlanningId; }
			set { m_cipPlanningId = value; }
		}

		//mam 050806
		public int TreeNodeIndex
		{
			get { return treeNodeIndex; }
			set { treeNodeIndex = value; }
		}

		public double		CWPValue
		{
			get { return m_CWPValue; }
			set { m_CWPValue = value; }
		}

		public string		CaptionPhoto
		{
			get { return m_captionPhoto; }
			set
			{
				if (value.Length > 255)
					m_captionPhoto = value.Substring(255);
				else
					m_captionPhoto = value;
			}
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return m_photoFileName; }
			set { m_photoFileName = value; }
		}

		//mam 102309
		//		public string Photo
		//		{
		//			get { return m_photo; }
		//			set
		//			{
		//				if (value.Length > 255)
		//					m_photo = value.Substring(255);
		//				else
		//					m_photo = value;
		//			}
		//		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public int			SortOrder
		{
			get { return m_sortOrder; }
			set { m_sortOrder = value; }
		}

		public LevelOfService LOS
		{
			get
			{ 
				if (m_discTotals == null)
					RefreshTotals();

				if (MechStructDisciplines)
				{
					return m_LOS;
				}
				else
				{
					Discipline[]	disciplines = 
						CacheManager.GetDisciplines(m_infoSetID, ID);
					DisciplinePipe	pipe;
					DisciplineNode	node;
					decimal			levelOfService = 0m;
					decimal			totalVal = m_discTotals.GetTotalCurrentValue();

					if (totalVal == 0m)
						return LevelOfService.LOS0;

					for (int pos = 0; pos < disciplines.Length; pos++)
					{
						pipe = disciplines[pos] as DisciplinePipe;
						node = disciplines[pos] as DisciplineNode;

						if (pipe != null)
						{
							levelOfService += (pipe.GetCurrentValue() / totalVal) * 
								pipe.GetAverageLOS();
						}
						else if (node != null)
						{
							levelOfService += (node.GetCurrentValue() / totalVal) * 
								node.GetAverageLOS();
						}
					}

					int curLOS = (int)Math.Round(levelOfService, 0);

					if (curLOS < (int)LevelOfService.LOS0)
						curLOS = (int)LevelOfService.LOS0;
					else if (curLOS > (int)LevelOfService.LOS5)
						curLOS = (int)LevelOfService.LOS5;

					return (LevelOfService)curLOS;
				}
			}
			set
			{
				if (MechStructDisciplines)
					m_LOS = value;
			}
		}

		//mam 07072011 - provide a way for other objects to get the collection
		public MajorComponentSelectedCriticalityFactorsCollection ComponentSelectedCriticalityFactorsCollection
		{
			//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
			get { return componentSelectedCritFactorCollection; }
			set { componentSelectedCritFactorCollection = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - using different method to store selected criticality values
		//public CriticalityPublicHealth CritPublicHealth
		//{
		//	get { return m_critPublic; }
		//	set { m_critPublic = value; }
		//}
		public byte CritPublicHealth
		{
			get { return m_critPublic; }
			set { m_critPublic = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - using different method to store selected criticality values
		//public CriticalityEnvironmental CritEnvironmental
		//{
		//	get { return m_critEnvironmental; }
		//	set { m_critEnvironmental = value; }
		//}
		public byte CritEnvironmental
		{
			get { return m_critEnvironmental; }
			set { m_critEnvironmental = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - using different method to store selected criticality values
		//public CriticalityRepairCost CritRepair
		//{
		//	get { return m_critRepair; }
		//	set { m_critRepair = value; }
		//}
		public byte CritRepair
		{
			get { return m_critRepair; }
			set { m_critRepair = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - using different method to store selected criticality values
		//public CriticalityCustomerEffect CritCustEffect
		//{
		//	get { return m_critCustEffect; }
		//	set { m_critCustEffect = value; }
		//}
		public byte CritCustEffect
		{
			get { return m_critCustEffect; }
			set { m_critCustEffect = value; }
		}

		//mam - change to double
		//public Vulnerability Vulnerability
		public double Vulnerability
		{
			get
			{
				if (m_discTotals == null)
					RefreshTotals();

				if (MechStructDisciplines)
				{
					//mam - modified 010305 - for some reason, m_vulnerability may not have been assigned a value yet, so call GetVulnerability()
					m_vulnerability = GetVulnerability();
					//</mam>

					return m_vulnerability;
				}
				else
				{
					Discipline[]	disciplines = 
						CacheManager.GetDisciplines(m_infoSetID, ID);
					DisciplinePipe	pipe;
					DisciplineNode	node;
					decimal			vuln = 0m;
					decimal			totalVal = m_discTotals.GetTotalCurrentValue();
					decimal			currentValue;

					//mam - change from int to decimal
					//int				avgVuln;
					decimal				avgVuln;
					//</mam>

					if (totalVal == 0m)
						return 0;

					for (int pos = 0; pos < disciplines.Length; pos++)
					{
						pipe = disciplines[pos] as DisciplinePipe;
						node = disciplines[pos] as DisciplineNode;

						currentValue = 0;
						avgVuln = 0;

						if (pipe != null)
						{
							currentValue = pipe.GetCurrentValue();
							avgVuln = pipe.GetAverageVulnerability();

						}
						else if (node != null)
						{
							currentValue = node.GetCurrentValue();
							avgVuln = node.GetAverageVulnerability();
						}

						//vuln += (currentValue / totalVal) * (decimal)avgVuln;
						vuln += (currentValue / totalVal) * avgVuln;
					}

					//mam - round vuln to 2 decimal places, as it is the probability instead of the year
					//vuln = Math.Round(vuln, 0);
					//vuln = Math.Round(vuln, 2);

					//mam 090105 - round vuln to 4 decimals rather than 2
					vuln = Math.Round(vuln, 4);

					//</mam>

					//mam - don't return year
					//					// Round down to 5, 10, 20, 50, 100, 150
					//					if (vuln < 10m)
					//						return Vulnerability.FailureLikely5;
					//					else if (vuln < 20)
					//						return Vulnerability.FailureLikely10;
					//					else if (vuln < 50)
					//						return Vulnerability.FailureLikely20;
					//					else if (vuln < 100)
					//						return Vulnerability.FailureLikely50;
					//					else if (vuln < 150)
					//						return Vulnerability.FailureLikely100;
					//
					//					return Vulnerability.FailureLikely150;
					return (double)vuln;
					//</mam
				}
			}
			set
			{
				if (MechStructDisciplines)
					m_vulnerability = value;
			}
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public double VulnerabilityGraph(bool pipesOnly, bool nodesOnly)
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				//mam - modified 010305 - for some reason, m_vulnerability may not have been assigned a value yet, so call GetVulnerability()
				m_vulnerability = GetVulnerability();
				//</mam>

				return m_vulnerability;
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				decimal			vuln = 0m;
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();
				decimal			currentValue;
				decimal				avgVuln;

				if (totalVal == 0m)
					return 0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					currentValue = 0;
					avgVuln = 0;

					if (pipe != null && pipesOnly)
					{
						currentValue = pipe.GetCurrentValue();
						avgVuln = pipe.GetAverageVulnerability();

					}
					else if (node != null && nodesOnly)
					{
						currentValue = node.GetCurrentValue();
						avgVuln = node.GetAverageVulnerability();
					}

					vuln += (currentValue / totalVal) * avgVuln;
				}

				//mam 090105 - round vuln to 4 decimals rather than 2
				//vuln = Math.Round(vuln, 2);
				vuln = Math.Round(vuln, 4);

				return (double)vuln;
			}
		}
		//</mam>

		public bool			MechStructDisciplines
		{
			get { return m_mechStructDisc; }
			set { m_mechStructDisc = value; }
		}

		public bool			Retired
		{
			get { return m_retired; }
			set { m_retired = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Photo Methods *****/

		//mam 03202012 - renamed to indicate the photo file name is included
		//public string		GetImagePath()
		public string		GetImagePathWithPhotoFileName()
		{
			//mam 03202012
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			photoPath += "\\" + m_photoFileName;
			return photoPath;

			////mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value
			////mam 102309 - no, just use the original method
			//
			////TreatmentProcess process = new TreatmentProcess(m_sqlConnectionString, m_processID);
			////Facility		facility = new Facility(m_sqlConnectionString, process.FacilityID);
			////InfoSet			infoSet = new InfoSet(m_sqlConnectionString, facility.InfoSetID);
			////string			path = string.Format(
			////	@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", infoSet.GetImagePath(),
			////	facility.ID, process.ID, ID);
			////return path;
			//
			//string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			////string photoName = this.Photo;
			////string photoNamePlusPath = photoPath + "\\" + photoName;
			//
			////mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
			////mam 102309 - no - use original ID method for photo names
			////if (photoName == null || photoName == "")
			////{
			//string photoName = string.Format(@"{0:D4}-{1:D4}-{2:D4}.jpg", GetFacilityID(), m_processID, ID);
			//photoPath += "\\" + photoName;
			////}
			//
			//return photoPath;
		}

		//mam 03202012
		//public string GetImagePathIdStyle(int facilityID, int processID, int componentID, int infoSetID)
		public string GetImagePathIdStyle()
		{
			InfoSet infoSet = new InfoSet(m_sqlConnectionString, InfoSetID);
			string path = string.Format(@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", infoSet.GetImagePath(), GetFacilityID(), ProcessID, ID);

			return path;
		}

		//mam 03202012 - no longer used
		//mam 102309 - used only when deleting photos, and we are not deleting photos any more
		//mam 102309 - yes, we are deleting photos
		//mam - pass in IDs so the path can be returned faster when deleting photos
		//public string		GetImagePath(int facilityID, int processID, int componentID, int infoSetID)
		//{
		//	InfoSet			infoSet = new InfoSet(m_sqlConnectionString, infoSetID);
		//	string			path = string.Format(
		//		@"{0}\{1:D4}-{2:D4}-{3:D4}.jpg", infoSet.GetImagePath(),
		//		facilityID, processID, componentID);
		//	return path;
		//}
		//</mam>

		public Image		GetPhoto()
		{
			//mam 03202012 - changed GetImagePath to GetImagePathWithPhotoFileName
			//string			path = GetImagePath();
			string			path = GetImagePathWithPhotoFileName();

			Image			image = null;

			//mam - added try/catch
			try
			{
				if (System.IO.File.Exists(path))
				{
					//image = Image.FromFile(path);
					//return image;

					//mam - set the file to be not read only, just in case the user has pulled a fast one and
					//	has copied a read-only image into the images folder
					System.IO.File.SetAttributes(path, System.IO.FileAttributes.Normal);
					//</mam>

					//mam - get the image from a filestream to alleviate
					//	"access denied" issues when deleting nodes and image folders
					using (System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open))
					{
						image = Image.FromStream(fileStream);
						fileStream.Close();
					}
					//</mam>
				}
			}
			catch
			{
				return null;
			}
			//</mam>

			return image;
		}
		#endregion /***** Photo Methods *****/

		#region		/***** Calculation Methods *****/
		private Logic.DisciplineTotals
			m_discTotals = null;

		public Logic.DisciplineTotals GetDisciplineTotals()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals;
		}

		public void			RefreshTotals()
		{
			m_discTotals = new Logic.DisciplineTotals(this);
		}

		public decimal		GetComponentCost()
		{
			decimal			compCost = 0;

			// Retrieve the parent treatment process
			TreatmentProcess process = 
				CacheManager.GetTreatmentProcess(m_infoSetID, 
				this.ProcessID);

			compCost = process.OrgCost * ((decimal)CWPValue);
			return compCost;
		}

		public decimal		GetAcquisitionCost()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalAcquisitionCost();
		}

		//mam 091607 - new method
		public decimal		GetAcquisitionCostRoundIndividualValues()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalAcquisitionCostRoundIndividualValues();
		}

		//mam 050806
		public decimal GetAcquisitionCostEscalated()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalAcquisitionCostEscalated();
		}

		public decimal		GetCurrentValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalCurrentValue();
		}

		public decimal		GetReplacementValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalReplacementValue();
		}

		//mam 050806
		public int GetReplacementValueYear()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetAverageReplacementValueYear();
		}

		//mam 050806
		public decimal GetRehabCost()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalRehabCost();
		}

		public decimal		GetBookValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalBookValue();
		}

		public decimal		GetSalvageValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalSalvageValue();
		}

		public decimal		GetAnnualDepreciation()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalAnnualDepreciation();
		}

		public decimal		GetCumulativeDepreciation()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalCumulativeDepreciation();
		}

		public decimal		GetEvaluatedValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalEvaluatedValue();
		}

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetEvaluatedValue()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalEvaluatedValue(), 0);
		}
		//</mam>

		public decimal		GetRepairCost()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalRepairCost();
		}

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetRepairCost()
		{
			if (m_discTotals == null)
				RefreshTotals();
			
			if (isNA)
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalRepairCost(), 0);
		}
		//</mam>

		public decimal		GetAnnualMaintenanceCost()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalAnnualMaintCost();
		}

		//mam - use interpolated
		//		public double		GetRankPercent()
		//		{
		//			if (m_discTotals == null)
		//				RefreshTotals();
		//
		//			return m_discTotals.GetRankPercent();
		//		}

		//mam - new method
		public double		GetRankPercentInterpolated()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetRankPercentInterpolated();
		}
		//</mam>

		//mam - need a way to get only pipes or only nodes for graphing
		public double GetRankPercentInterpolated(bool pipesOnly, bool nodesOnly)
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetRankPercentInterpolated(pipesOnly, nodesOnly);
		}
		//</mam>

		//mam - new method that accounts for N/A when sorting
		public double SortGetRankPercentInterpolated()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return Math.Round(m_discTotals.GetRankPercentInterpolated(), 1);
		}
		//</mam>

		public double		GetOrgUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalOrgUsefulLife();
		}

		//mam
		public double SortGetOrgUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA && (m_discTotals.GetTotalCurrentValue() == 0))
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalOrgUsefulLife(), 1);
		}
		//</mam>

		public double		GetRemainingUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalRemainingUsefulLife();
		}

		//mam
		public double SortGetRemainingUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA && (m_discTotals.GetTotalCurrentValue() == 0))
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalRemainingUsefulLife(), 1);
		}
		//</mam>

		public double		GetEvaluatedRemainingUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalEvaluatedRemainingUsefulLife();
		}

		//mam
		public double SortGetEvaluatedRemainingUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalEvaluatedRemainingUsefulLife(), 1);
		}
		//</mam>

		//mam
		public double		GetEconomicUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalEconomicUsefulLife();
		}
		//</mam>

		//mam
		public double SortGetEconomicUsefulLife()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return Math.Round(m_discTotals.GetTotalEconomicUsefulLife(), 1);
		}
		//</mam>

		public double		GetCWP()
		{
			if (m_discTotals == null)
				RefreshTotals();

			return m_discTotals.GetTotalCWPValue();
		}

		//mam - change to decimal
		//original code:
		//public int			GetOverallCriticality()
		//new code:
		public decimal			GetOverallCriticality()
		{
			//mam - change from int to decimal
			//int				total = 0;
			decimal				total = 0.0m;
			//</mam>

			//mam - added this code
			if (m_discTotals == null)
				RefreshTotals();
			//</mam>

			if (MechStructDisciplines)
			{
				//mam 07072011 - no longer using four fixed crits
				//total += EnumHandlers.GetCritPublicHealthValue(m_critPublic);
				//total += EnumHandlers.GetCritEnvironmentalValue(m_critEnvironmental);
				//total += EnumHandlers.GetCritRepairCostValue(m_critRepair);
				//total += EnumHandlers.GetCritCustomerEffectValue(m_critCustEffect);

				//mam 07072011 - new way to calculate total
				total = CalculateCritTotal();

				//mam - added RedundantAssetCount
				//mam 112806
				total *= WAM.Common.CommonTasks.GetRedundantPercentage(RedundantAssetCount);

				//mam 01222012
				if (WAM.Common.Globals.ApplyFacilityCriticalityFactor)
				{
					total *= GetFacility().FacilityCriticality;
				}

				total = Math.Round(total, 1);
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				//mam - change to 0.0m
				//original code:
				//decimal			crit = 0m;
				//new code:
				decimal			crit = 0.0m;
				//</mam>
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if (pipe != null)
					{
						crit += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageCriticality();
					}
					else if (node != null)
					{
						crit += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageCriticality();
					}
				}

				//mam 03202012 - don't apply the facility criticality here - it has already been 
				//	applied above in GetAverageCriticality
				//mam 01222012
				//if (WAM.Common.Globals.ApplyFacilityCriticalityFactor)
				//{
				//	crit *= GetFacility().FacilityCriticality;
				//}

				//mam - round crit before returning the integer
				crit = Math.Round(crit, 1);
				//</mam>

				//mam - return decimal instead of integer
				//total = (int)crit;
				total = crit;
				//</mam>
			}

			return total;
		}

		//mam 07072011 - new method to calculate overall criticality
		private decimal CalculateCritTotal()
		{
			decimal total = 0.0m;

			foreach (MajorComponentSelectedCriticalityFactors critFactor in componentSelectedCritFactorCollection)
			{
				total += ((decimal)critFactor.CriticalityWeight * critFactor.CritFactor.Score / 100);
			}

			return total;
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public decimal GetOverallCriticality(bool pipesOnly, bool nodesOnly)
		{
			//mam - change from int to decimal
			//int				total = 0;
			decimal				total = 0;
			//</mam>

			//mam - added this code
			if (m_discTotals == null)
				RefreshTotals();
			//</mam>

			if (MechStructDisciplines)
			{
				//mam 07072011 - no longer using four fixed crits
				//total += EnumHandlers.GetCritPublicHealthValue(m_critPublic);
				//total += EnumHandlers.GetCritEnvironmentalValue(m_critEnvironmental);
				//total += EnumHandlers.GetCritRepairCostValue(m_critRepair);
				//total += EnumHandlers.GetCritCustomerEffectValue(m_critCustEffect);

				//mam 07072011 - new way to calculate total
				total = CalculateCritTotal();
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				//mam - change to 0.0m
				//original code:
				//decimal			crit = 0m;
				//new code:
				decimal			crit = 0.0m;
				//</mam>
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if (pipe != null && pipesOnly)
					{
						crit += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageCriticality();
					}
					else if (node != null && nodesOnly)
					{
						crit += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageCriticality();
					}
				}

				//mam - round crit before returning the integer
				crit = Math.Round(crit, 1);
				//</mam>

				//mam - return decimal instead of integer
				//total = (int)crit;
				total = crit;
				//</mam>
			}

			return total;
		}
		//</mam>

		//mam 07072011 - this method is not called by any code - comment it
//		//mam - need a way to get only pipes or only nodes for graphing
//		public decimal GetOverallCriticalityForPipeOrNode(bool pipesOnly, bool nodesOnly)
//		{
//			decimal				total = 0;
//
//			if (m_discTotals == null)
//				RefreshTotals();
//
//		{
//			Discipline[]	disciplines = 
//				CacheManager.GetDisciplines(m_infoSetID, ID);
//			DisciplinePipe	pipe;
//			DisciplineNode	node;
//			decimal			crit = 0.0m;
//			decimal			totalVal = m_discTotals.GetTotalCurrentValue();
//
//			if (totalVal == 0m)
//				return 0;
//
//			for (int pos = 0; pos < disciplines.Length; pos++)
//			{
//				pipe = disciplines[pos] as DisciplinePipe;
//				node = disciplines[pos] as DisciplineNode;
//
//				if (pipe != null && pipesOnly)
//				{
//					crit = (decimal)pipe.GetAverageCriticality();
//				}
//				else if (node != null && nodesOnly)
//				{
//					crit = (decimal)node.GetAverageCriticality();
//				}
//			}
//
//			crit = Math.Round(crit, 1);
//			total = crit;
//		}
//
//			return total;
//		}
		//</mam>

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetOverallCriticality()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				return Math.Round(GetOverallCriticality(), 1);
			}
			else
			{
				if (GetCurrentValue() == 0)
					return -1;
				else
				{
					return Math.Round(GetOverallCriticality(), 1);
				}
			}
		}
		//</mam>

		//mam
		public double GetVulnerability()
		{
			//if (MechStructDisciplines), go ahead and execute this code; otherwise, return Vulnerability

			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				if (m_overrideVulnerability)
					return m_vulnerability;
				else
				{
					double evalRUL = GetEvaluatedRemainingUsefulLife();

					if (evalRUL == 0 && !OverrideVulnerability)
						return 0;

					if (evalRUL <= 1)
						m_vulnerability = 0.9;
					else if (evalRUL <= 2)
						m_vulnerability = 0.7;
					else if (evalRUL <= 3)
						m_vulnerability = 0.4;
					else if (evalRUL <= 5)
						m_vulnerability = 0.2;
					else
						m_vulnerability = (double)Math.Round(1 / (decimal)evalRUL, 4);

					return m_vulnerability;
				}
			}
			else
			{
				return Math.Round(Vulnerability, 4);
			}

			//****************************

			//ORIGINAL CODE:
			//			if (m_overrideVulnerability)
			//				return m_vulnerability;
			//			else
			//			{
			//				double evalRUL = GetEvaluatedRemainingUsefulLife();
			//
			//				if (evalRUL == 0 && !OverrideVulnerability)
			//					return 0;
			//
			//				if (evalRUL <= 1)
			//					m_vulnerability = 0.9;
			//				else if (evalRUL <= 2)
			//					m_vulnerability = 0.7;
			//				else if (evalRUL <= 3)
			//					m_vulnerability = 0.4;
			//				else if (evalRUL <= 5)
			//					m_vulnerability = 0.2;
			//				else
			//					m_vulnerability = (double)Math.Round(1 / (decimal)evalRUL, 4);
			//
			//				return m_vulnerability;
			//			}
		}
		//</mam>

		//mam - new method that accounts for N/A when sorting
		public double SortGetVulnerability()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				if (GetEvaluatedRemainingUsefulLife() == 0 && !OverrideVulnerability)
					return -1;
				else
					return Math.Round(GetVulnerability(), 4);
			}
			else
			{
				if (GetCurrentValue() == 0 || (pipesERULVulnNASort && nodesERULVulnNASort))
					return -1;
				else
					return Math.Round(Vulnerability, 4);
			}
		}
		//</mam>

		//mam
		public bool	OverrideVulnerability
		{
			get { return m_overrideVulnerability; }
			set
			{
				if (m_overrideVulnerability == value)
					return;

				// Set to the default vulnerability when turning 
				// override on, and set back to zero when turning it off
				if (!m_overrideVulnerability)
					m_vulnerability = Math.Round(Vulnerability, 4);
				//else
				//mam - don't set back to zero
				//	m_vulnerability2 = 0;

				m_overrideVulnerability = value;
			}
		}
		//</mam>

		public double		GetRisk()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				//mam - use probability
				//return (double)GetOverallCriticality() * 
				//	EnumHandlers.GetVulnerabilityValue(m_vulnerability);

				//mam - modified 010305 - for some reason, m_vulnerability may not have been assigned a value yet, so call GetVulnerability()
				m_vulnerability = GetVulnerability();
				//</mam>

				return (double)GetOverallCriticality() * (double)m_vulnerability;
				//</mam>
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				decimal			risk = 0m;
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0.0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if (pipe != null)
					{
						risk += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageRisk();
					}
					else if (node != null)
					{
						risk += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageRisk();
					}
				}

				return (double)risk;
			}
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public double GetRisk(bool pipesOnly, bool nodesOnly)
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				//mam - modified 010305 - for some reason, m_vulnerability may not have been assigned a value yet, so call GetVulnerability()
				m_vulnerability = GetVulnerability();
				//</mam>

				return (double)GetOverallCriticality() * (double)m_vulnerability;
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				decimal			risk = 0m;
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0.0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if (pipe != null && pipesOnly)
					{
						risk += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageRisk();
					}
					else if (node != null && nodesOnly)
					{
						risk += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageRisk();
					}
				}

				return (double)risk;
			}
		}
		//mam

		//mam - new method that accounts for N/A when sorting
		public double SortGetRisk()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				if (GetEvaluatedRemainingUsefulLife() == 0 && !OverrideVulnerability)
					return -1;
				else
					return Math.Round(GetRisk(), 2);
			}
			else
			{
				if (GetCurrentValue() == 0 || (pipesERULVulnNASort && nodesERULVulnNASort))
					return -1;
				else
					return Math.Round(GetRisk(), 2);
			}
		}
		//</mam>

		//mam - new routine to calculate total LOS for pipes and nodes
		public double GetLOS()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				return (double)(int)m_LOS;
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				decimal			los = 0m;
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0.0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if (pipe != null)
					{
						los += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageLOS();
					}
					else if (node != null)
					{
						los += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageLOS();
					}
				}

				return Math.Round((double)los, 1);
			}
		}
		//</mam>

		//mam - need a way to get only pipes or only nodes for graphing
		public double GetLOS(bool pipesOnly, bool nodesOnly)
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
			{
				return (double)(int)m_LOS;
			}
			else
			{
				Discipline[]	disciplines = 
					CacheManager.GetDisciplines(m_infoSetID, ID);
				DisciplinePipe	pipe;
				DisciplineNode	node;
				decimal			los = 0m;
				decimal			totalVal = m_discTotals.GetTotalCurrentValue();

				if (totalVal == 0m)
					return 0.0;

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					pipe = disciplines[pos] as DisciplinePipe;
					node = disciplines[pos] as DisciplineNode;

					if ((pipe != null && pipesOnly) || (pipe != null && !pipesOnly && !nodesOnly))
					{
						los += (pipe.GetCurrentValue() / totalVal) * 
							(decimal)pipe.GetAverageLOS();
					}
					else if ((node != null && nodesOnly) || (node != null && !pipesOnly && !nodesOnly))
					{
						los += (node.GetCurrentValue() / totalVal) * 
							(decimal)node.GetAverageLOS();
					}
				}

				return Math.Round((double)los, 1);
			}
		}
		//</mam>

		//mam - new method that accounts for N/A when sorting
		public double SortGetLOS()
		{
			if (m_discTotals == null)
				RefreshTotals();

			if (MechStructDisciplines)
				return Math.Round(GetLOS(), 1);
			else
			{
				if (GetCurrentValue() == 0)
					return -1;
				else
					return Math.Round(GetLOS(), 1);
			}
		}
		//</mam>

		//mam 07072011
		public string SortGetCip()
		{
			if (MechStructDisciplines)
			{
				return GetCipModeTextFromId(Common.CommonTasks.GetCipObjects(), m_cipPlanningId);
			}

			return "";
		}

		#endregion	/***** Calculation Methods *****/

		#region /***** Methods *****/

		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete()
		{
			this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
			using (SqlConnection connection = new SqlConnection(this.m_sqlConnectionString))
			{
				connection.Open();
				return this.Delete(connection);
			}
		}
		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete(SqlConnection sqlConnection)
		{
			//return base.Delete (sqlConnection);

			string deleteSql = this.GetDeleteSql();
			if (deleteSql.Length == 0)
			{
				return false;
			}
			try
			{
				new SqlCommand(deleteSql, sqlConnection).ExecuteNonQuery();
			}
			catch (SqlException exception)
			{
				throw exception;
			}
			InvokeChangeEvent(this, new DataChangeEventArgs(this, Drive.Synchronization.SyncAction.Delete));
			return true;
		}

		//mam
		public static MajorComponentComparer GetComparer()
		{
			return new MajorComponent.MajorComponentComparer();
		}
		//</mam>

		public bool			SaveAsXML(string filePath)
		{
			System.IO.FileStream file = null;
			System.IO.StreamWriter writer = null;

			try
			{
				file = new System.IO.FileStream(filePath, 
					System.IO.FileMode.Create, System.IO.FileAccess.Write);

				writer = new System.IO.StreamWriter(file);

				//mam - added parameters - always get photos when displaying data in the application
				//	and pass in an empty string for the selectedFilters, which only apply to reports
				writer.Write(GetXML(true, ""));
				//</mam>

				writer.Flush();
				writer.Close();
				writer = null;
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}
			return true;
		}

		public Facility		GetFacility()
		{
			TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, m_processID);
			Facility		facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);

			return facility;
		}

		public TreatmentProcess	GetTreatmentProcess()
		{
			TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, m_processID);

			//mam 090105
			processName = process.Name;
			facilityID = process.FacilityID;
			//</mam>

			return process;
		}

		public string		GetFullName()
		{
			TreatmentProcess process = GetTreatmentProcess();

			return string.Format("{0} / {1}", process.GetFullName(), Name);
		}

		public string		GetShortName()
		{
			return Name;
		}

		//mam
		public string GetFullNameWithInfoset()
		{
			return string.Format("{0} / {1}", CacheManager.GetInfosetNameForInfoSetID(this.InfoSetID), GetFullName());
		}
		//</mam>

		//mam 090105
		public int GetFacilityID()
		{
			if (facilityID == 0)
			{
				TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, m_processID);

				//mam 102309 - added this line:
				return process.FacilityID;
			}

			return facilityID;
		}

		public string GetParentName()
		{
			//get the Process name

			//just go ahead and call GetTreatmentProcess to make sure that all of the data is refreshed
			//if (processName.Length == 0)
		{
			TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, m_processID);
		}

			return processName;
		}
		//</mam>

		//mam 050806
		public int GetParentID()
		{
			//parentID = ProcessID;
			//return parentID;
			return ProcessID;
		}

		//mam 050806
		public int GetGrandparentID()
		{
			return GetFacilityID();
		}

		//mam 050806
		public int GetInfosetID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public object GetUnitType()
		{
			return WAM.UI.NodeType.MajorComponent;
		}

		//mam - need a way to get pipes only or nodes only for graphing
		public decimal GetYAxisValue(GraphYAxis yAxis, bool pipesOnly, bool nodesOnly)
		{
			switch (yAxis)
			{
				case GraphYAxis.Criticality:
					return (decimal)GetOverallCriticality(pipesOnly, nodesOnly);
				case GraphYAxis.Vulnerability:
					return (decimal)VulnerabilityGraph(pipesOnly, nodesOnly);
				case GraphYAxis.Risk:
					return Math.Round(((decimal)GetRisk(pipesOnly, nodesOnly)), 2);
				case GraphYAxis.Condition:
					return (decimal)GetRankPercentInterpolated(pipesOnly, nodesOnly);
				case GraphYAxis.LOS:
					return (decimal)GetLOS(pipesOnly, nodesOnly);
			}

			return 0m;
		}
		//</mam>

		public decimal		GetYAxisValue(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return GetAcquisitionCost();
				case GraphYAxis.CurrentValue:
					return GetCurrentValue();
				case GraphYAxis.ReplacementValue:
					return GetReplacementValue();
				case GraphYAxis.BookValue:
					return GetBookValue();
				case GraphYAxis.SalvageValue:
					return GetSalvageValue();
				case GraphYAxis.AnnualDepreciation:
					return GetAnnualDepreciation();
				case GraphYAxis.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case GraphYAxis.EvaluatedValue:
					return GetEvaluatedValue();
				case GraphYAxis.RepairCost:
					return GetRepairCost();
				case GraphYAxis.AnnualMaintenanceCost:
					return GetAnnualMaintenanceCost();

					//mam 050806
				case GraphYAxis.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case GraphYAxis.RehabCost:
					return GetRehabCost();

				case GraphYAxis.Criticality:
				{
					return (decimal)GetOverallCriticality();
				}

					//mam - use probability
					//case GraphYAxis.Vulnerability:
					//	return decimal.Parse(EnumHandlers.GetVulnerabilityShort(this.Vulnerability));
				case GraphYAxis.Vulnerability:
					return (decimal)Vulnerability;
					//</mam>

				case GraphYAxis.Risk:
					return Math.Round(((decimal)GetRisk()), 2);

					//mam - use interpolated
					//case GraphYAxis.Condition:
					//	return (decimal)GetRankPercent();
				case GraphYAxis.Condition:
					return (decimal)GetRankPercentInterpolated(false, false);
					//</mam>

				case GraphYAxis.LOS:
					//mam - return value with one decimal place (rather than a whole number)
					//return (decimal)LOS;
					return (decimal)GetLOS(false, false);

					//mam 190105
				case GraphYAxis.OriginalUsefulLife:
					return (decimal)GetOrgUsefulLife();
				case GraphYAxis.RemainingUsefulLife:
					return (decimal)GetRemainingUsefulLife();
				case GraphYAxis.EvaluatedRemainingUsefulLife:
					return (decimal)GetEvaluatedRemainingUsefulLife();
				case GraphYAxis.EconomicRemainingUsefulLife:
					return (decimal)GetEconomicUsefulLife();
			}

			return 0m;
		}

		public int			GetYearValue()
		{
			// Return the year
			return GetFacility().CurrentYear;
		}

		//mam 050806
		public int GetInspectionYear()
		{
			//return GetFacility().CurrentYear;
			Discipline[] disciplines = CacheManager.GetDisciplines(m_infoSetID, ID);
			Discipline discipline;
			int curInspectionYear = 0;
			int lowInspectionYear = 0;

			for (int i = 0; i < disciplines.Length; i++)
			{
				discipline = disciplines[i];

				//mam 012307 - check condition
				if (discipline.ConditionRanking != CondRank.No)
				{
					curInspectionYear = discipline.GetInspectionYear();
					lowInspectionYear = curInspectionYear < lowInspectionYear || lowInspectionYear == 0? 
					curInspectionYear: lowInspectionYear;
				}
			}

			return lowInspectionYear;
		}

		//mam - new method
		public int GetItemID()
		{
			//return the ID
			return ID;
		}
		//</mam>

		//mam - added parameter
		public string		GetXML(bool includePhotos, string selectedFilters)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();
			TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, m_processID);
			Facility		facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);
			Discipline[] disciplines = CacheManager.GetDisciplines(m_infoSetID, ID);
			WAM.Logic.DisciplineTotals disciplineTotals = GetDisciplineTotals();
			Discipline		discipline;

			//mam
			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalValue = disciplineTotals.GetTotalCurrentValue();
			decimal			totalValue = disciplineTotals.GetTotalAcquisitionCost();
			decimal			totalValueRounded = disciplineTotals.GetTotalAcquisitionCostRoundIndividualValues();

			decimal adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(InfoSetID, ID, totalValueRounded, WAM.UI.NodeType.MajorComponent);

			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}
			//</mam>

			//mam 07072011
			ArrayList arrayListCip = Common.CommonTasks.GetCipObjects();

			//mam
			DisciplinePipe	pipe;
			DisciplineNode	node;
			bool pipesERULVulnNA = false;
			bool nodesERULVulnNA = false;
			//disciplineTotals.GetTotalCurrentValue()

			//mam 112806
			ResetOverrideVariables();

			//if pipe or node, determine ERUL and Vuln override
			//**************************************************
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (MechStructDisciplines)
				{
					if (discipline.OverrideCurrentValue)
					{
						mscOverrideAnyCurrentValue = true;
					}
					if (discipline.OverrideRepairCost)
					{
						mscOverrideAnyRepairCost = true;
					}
				}
				else
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
							pipesERULVulnNA = true;
						else
							pipesERULVulnNA = false;

						//mam 112806
						if (pipe.GetAnyCurrentValueOverridden())
						{
							pipeOverrideAnyCurrentValue = true;
						}
						if (pipe.GetAnyRepairCostOverridden())
						{
							pipeOverrideAnyRepairCost = true;
						}
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
							nodesERULVulnNA = true;
						else
							nodesERULVulnNA = false;

						//mam 112806
						if (node.GetAnyCurrentValueOverridden())
						{
							nodeOverrideAnyCurrentValue = true;
						}
						if (node.GetAnyRepairCostOverridden())
						{
							nodeOverrideAnyRepairCost = true;
						}
					}
				}
			}
			//</mam>

			//**************************************************

			builder.Append("<ComponentData>\r\n");

			// Populate the basic facility data
			builder.Append("\t<MajorComponent>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
			builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", process.Name);
			builder.AppendFormat("\t\t<ComponentName><![CDATA[{0}]]></ComponentName>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", facility.CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", facility.CurrentENR);
			builder.AppendFormat("\t\t<Retired>{0}</Retired>\r\n", this.Retired.ToString());
			//mam

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			if (includePhotos)
			{
			//</mam>
				//mam 03202012 - changed GetImagePath to PhotoFileName (don't include path in photo file name because it is a 
				//	mapped path on the user's machine that will be different for all users)
				//builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePath());
				builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", PhotoFileName);

				builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto);
			}

			//mam - make sure m_discTotals is not null
			if (m_discTotals == null)
				RefreshTotals();
			//</mam>

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);

			if (MechStructDisciplines)
			{
				//mam 050806
				builder.AppendFormat("\t\t<RedundantAssets><![CDATA[{0}]]></RedundantAssets>\r\n", RedundantAssetCount);

				builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", EnumHandlers.GetLOSShort(LOS));

				//mam 07072011 - no longer using four fixed crits
				//builder.AppendFormat("\t\t<CritPublicHealth><![CDATA[{0}]]></CritPublicHealth>\r\n", EnumHandlers.GetCritPublicHealthString(CritPublicHealth));
				//builder.AppendFormat("\t\t<CritEnvironmental><![CDATA[{0}]]></CritEnvironmental>\r\n", EnumHandlers.GetCritEnvironmentalString(CritEnvironmental));
				//builder.AppendFormat("\t\t<CritCostOfRepairs><![CDATA[{0}]]></CritCostOfRepairs>\r\n", EnumHandlers.GetCritRepairCostString(CritRepair));
				//builder.AppendFormat("\t\t<CritCustEffect><![CDATA[{0}]]></CritCustEffect>\r\n", EnumHandlers.GetCritCustomerEffectString(CritCustEffect));

				//mam 07072011 - new crits
				foreach (MajorComponentSelectedCriticalityFactors critFactor in componentSelectedCritFactorCollection)
				{
					string critNumberText = "Crit" + critFactor.CriticalityNumber.ToString();
					builder.AppendFormat("\t\t<" + critNumberText + "><![CDATA[{0}]]></" + critNumberText + ">\r\n", critFactor.CritFactor.FactorName);
				}

				builder.AppendFormat("\t\t<OverallCriticality><![CDATA[{0}]]></OverallCriticality>\r\n", GetOverallCriticality());
			}
			else
			{
				if (GetCurrentValue() == 0)
				{
					builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0:F1}]]></LevelOfService>\r\n", "N/A");
					builder.AppendFormat("\t\t<OverallCriticality><![CDATA[{0}]]></OverallCriticality>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0:F1}]]></LevelOfService>\r\n", GetLOS());
					builder.AppendFormat("\t\t<OverallCriticality><![CDATA[{0:F1}]]></OverallCriticality>\r\n", GetOverallCriticality());
				}
			}

			//mam - use probability
			//builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0}]]></Vulnerability>\r\n", EnumHandlers.GetVulnerabilityString(Vulnerability));
			//</mam>

			//mam
			if (MechStructDisciplines)
			{
				if (GetEvaluatedRemainingUsefulLife() == 0 && !OverrideVulnerability)
				{
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F4}]]></Vulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t<OverrideVulnerability><![CDATA[{0}]]></OverrideVulnerability>\r\n", 0);
					builder.AppendFormat("\t\t<Risk><![CDATA[{0}]]></Risk>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F4}]]></Vulnerability>\r\n", GetVulnerability());
					builder.AppendFormat("\t\t<OverrideVulnerability><![CDATA[{0}]]></OverrideVulnerability>\r\n", Convert.ToInt32(m_overrideVulnerability));
					builder.AppendFormat("\t\t<Risk><![CDATA[{0:F2}]]></Risk>\r\n", GetRisk());
				}

				//mam 07072011
				string cipPlanningMode = CipPlanningId == 0 ? "N/A" : GetCipModeTextFromId(arrayListCip, CipPlanningId);
				builder.AppendFormat("\t\t<CipPlanningMode><![CDATA[{0}]]></CipPlanningMode>\r\n", cipPlanningMode);
				builder.AppendFormat("\t\t<AssetClass><![CDATA[{0}]]></AssetClass>\r\n", AssetClass);
			}
			else
			{
				if (GetCurrentValue() == 0 || (pipesERULVulnNA && nodesERULVulnNA))
				{
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F4}]]></Vulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t<Risk><![CDATA[{0}]]></Risk>\r\n", "N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F2}]]></Vulnerability>\r\n", Vulnerability);
					builder.AppendFormat("\t\t<Vulnerability><![CDATA[{0:F4}]]></Vulnerability>\r\n", Vulnerability);

					builder.AppendFormat("\t\t<Risk><![CDATA[{0:F2}]]></Risk>\r\n", GetRisk());
				}
			}
			//</mam>


			builder.AppendFormat("\t\t<IsMechStructLand><![CDATA[{0}]]></IsMechStructLand>\r\n", MechStructDisciplines);
			builder.Append("\t</MajorComponent>\r\n");

			// Populate the major component data
			double			cwpVal = 0.0;

			builder.Append("\t<Disciplines>\r\n");
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				//decimal totalValue = processTotals.GetTotalCurrentValue();

				builder.Append("\t\t<Discipline>\r\n");
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", discipline.Name);

				//************************************
				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValueRounded != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}
				//</mam>
				//************************************

				//mam - moved up from below
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);

				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", "0");	//acquisition cost	//999999
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", "0");	//999999
					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", "0");	//999999

					//mam 01222012
					builder.AppendFormat("\t\t\t<GridReplacementValueDesc><![CDATA[{0}]]></GridReplacementValueDesc>\r\n", "");	//XXXX
					builder.AppendFormat("\t\t\t<GridRehabCostDesc><![CDATA[{0}]]></GridRehabCostDesc>\r\n", "");	//XXXX
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(discipline.AcquisitionCost, roundDigit));

					//mam 112806 - moved down
					//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(discipline.GetCurrentValue(), roundDigit));

					//mam 050806
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(discipline.AcquisitionCostEscalated, roundDigit));

					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(discipline.ReplacementValue, roundDigit));

					//mam 01222012
					builder.AppendFormat("\t\t\t<GridReplacementValueDesc><![CDATA[{0}]]></GridReplacementValueDesc>\r\n", discipline.ReplacementValueDesc);
					builder.AppendFormat("\t\t\t<GridRehabCostDesc><![CDATA[{0}]]></GridRehabCostDesc>\r\n", discipline.RehabCostDesc);
				}

				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", discipline.ReplacementValueYear);

				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(discipline.RehabCost, roundDigit));
				}

				//mam 07072011
				if (MechStructDisciplines)
				{
					builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0:F1}]]></GridRehabInterval>\r\n", discipline.RehabInterval);
					builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0:F0}]]></GridRehabYearLast>\r\n", discipline.RehabYearLast);
				}

				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(discipline.SalvageValue, roundDigit));
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(discipline.GetBookValue(), roundDigit));
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(discipline.SalvageValue, roundDigit));
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(discipline.GetAnnualDepreciation(), roundDigit));
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(discipline.GetCumulativeDepreciation(), roundDigit));
				}
				//</mam>

				//mam - added this code
				useNA = false;
				//if (discipline.Type == DisciplineType.Pipes || discipline.Type == DisciplineType.Nodes)
				if (!MechStructDisciplines)
				{
					switch(discipline.Type)
					{
						case DisciplineType.Pipes:
						{
							if (GetAllConditionNAPipes(discipline.InfoSetID, discipline.ID))
							{
								//if all pipes for the current discipline have condition = N/A, then Cond and ERUL = N/A
								useNA = true;
							}
							break;
						}
							
						case DisciplineType.Nodes:
						{
							if (GetAllConditionNANodes(discipline.InfoSetID, discipline.ID))
							{
								//if all nodes for the current discipline have condition = N/A, then Cond and ERUL = N/A
								useNA = true;
							}
							break;
						}
					}
				}
				//</mam>


				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 0);
					builder.AppendFormat("\t\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 0);
				}
				else
				{
					//mam 112806
					if (MechStructDisciplines && discipline.OverrideCurrentValue) 
					{
						//builder.AppendFormat("\t\t\t<FieldGridOverrideCurrentValue><![CDATA[{0}]]></FieldGridOverrideCurrentValue>\r\n", 1);
						builder.AppendFormat("\t\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 1);
					}
					else
					{
						//builder.AppendFormat("\t\t\t<FieldGridOverrideCurrentValue><![CDATA[{0}]]></FieldGridOverrideCurrentValue>\r\n", 0);
						builder.AppendFormat("\t\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 0);
					}

					//mam 112806
					if (MechStructDisciplines && discipline.OverrideRepairCost) 
					{
						builder.AppendFormat("\t\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 1);
					}
					else
					{
						builder.AppendFormat("\t\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 0);
					}
				}

				//mam 01222012
				PlanningMode planningMode = PlanningMode.Rehabilitation;
				if (CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					planningMode = PlanningMode.Replacement;
				}

				if (discipline.ConditionRanking == CondRank.No || useNA == true)
				{
					//mam 112806 - commented
					//builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");

					//**************************
					//mam 01222012
					if (MechStructDisciplines)
					{
						if (planningMode == PlanningMode.Replacement)
						{
							//rehab values are set to zero in the display
							builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", discipline.OverrideRehabYearNext == true ? 1 : 0);

							if (discipline.OverrideNextReplacementYear)
							{
								builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0:F1}]]></GridReplacementNext>\r\n", discipline.ReplacementNext);
								builder.AppendFormat("\t\t\t<GridReplacementYearNext><![CDATA[{0:F0}]]></GridReplacementYearNext>\r\n", discipline.NextReplacementYear);
								builder.AppendFormat("\t\t\t<OverrideReplacementYearNext><![CDATA[{0}]]></OverrideReplacementYearNext>\r\n", 1);
							}
							else
							{
								builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0}]]></GridReplacementNext>\r\n", "N/A");
								builder.AppendFormat("\t\t\t<GridReplacementYearNext><![CDATA[{0}]]></GridReplacementYearNext>\r\n", "N/A");
								builder.AppendFormat("\t\t\t<OverrideReplacementYearNext><![CDATA[{0}]]></OverrideReplacementYearNext>\r\n", 0);
							}
						}
						else
						{
							if (discipline.OverrideRehabYearNext)
							{
								builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", discipline.RehabNext);
								builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", discipline.RehabYearNext);
								builder.AppendFormat("\t\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", 1);
							}
							else
							{
								builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0}]]></GridRehabNext>\r\n", "N/A");
								builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0}]]></GridRehabYearNext>\r\n", "N/A");
								builder.AppendFormat("\t\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", 0);
							}

							//replacement values are set to zero in the display
							builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0:F1}]]></GridReplacementNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<GridReplacementYearNext><![CDATA[{0:F0}]]></GridReplacementYearNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<OverrideReplacementYearNext><![CDATA[{0}]]></OverrideReplacementYearNext>\r\n", discipline.OverrideNextReplacementYear == true ? 1 : 0);
						}
					}
					//**************************

					//mam 112806
					//current value
					if ((MechStructDisciplines && discipline.OverrideCurrentValue) 
						|| (discipline.Type == DisciplineType.Pipes && pipeOverrideAnyCurrentValue)
						|| (discipline.Type == DisciplineType.Nodes && nodeOverrideAnyCurrentValue))
					{
						//mam 01042012 - if component is retired, show zero on report
						if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", 0);	//999999
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(discipline.GetCurrentValue(), roundDigit).ToString("#,##0"));
						}
						//builder.AppendFormat("\t\t<FieldGridOverrideCurrentValue><![CDATA[{0}]]></FieldGridOverrideCurrentValue>\r\n", 1);
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
						//builder.AppendFormat("\t\t<FieldGridOverrideCurrentValue><![CDATA[{0}]]></FieldGridOverrideCurrentValue>\r\n", 0);
					}

					//mam 112806
					//repair cost
					if ((MechStructDisciplines && discipline.OverrideRepairCost) 
						|| (discipline.Type == DisciplineType.Pipes && pipeOverrideAnyRepairCost)
						|| (discipline.Type == DisciplineType.Nodes && nodeOverrideAnyRepairCost))
					{
						//mam 01042012 - if component is retired, show zero on report
						if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", 0);	//999999
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(discipline.GetRepairCost(), roundDigit).ToString("#,##0"));
						}
						//builder.AppendFormat("\t\t<GridOverrideRepairCost><![CDATA[{0}]]></GridOverrideRepairCost>\r\n", 1);
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
						//builder.AppendFormat("\t\t<GridOverrideRepairCost><![CDATA[{0}]]></GridOverrideRepairCost>\r\n", 0);
					}

					//mam 01042012 - if component is retired, show zero on report
					if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", discipline.AnnualMaintCost);
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", "N/A");

					//mam - added if condition
					//if (discipline.GetCurrentValue() == 0)
					if (!MechStructDisciplines)
					{
						if (discipline.GetCurrentValue() == 0)
						{
							builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
							builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
							builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
						}
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
					}
					//</mam>

					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					//**************************
					//mam 01222012
					if (MechStructDisciplines)
					{
						if (planningMode == PlanningMode.Replacement)
						{
							//rehab values are set to zero in the display
							builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", 0);

							builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0:F1}]]></GridReplacementNext>\r\n", discipline.ReplacementNext);
							builder.AppendFormat("\t\t\t<GridReplacementYearNext><![CDATA[{0:F0}]]></GridReplacementYearNext>\r\n", discipline.NextReplacementYear);
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", discipline.RehabNext);
							builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", discipline.RehabYearNext);

							//replacement values are set to zero in the display
							builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0:F1}]]></GridReplacementNext>\r\n", 0);
							builder.AppendFormat("\t\t\t<GridReplacementYearNext><![CDATA[{0:F0}]]></GridReplacementYearNext>\r\n", 0);
						}

						builder.AppendFormat("\t\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", discipline.OverrideRehabYearNext == true ? 1 : 0);
						builder.AppendFormat("\t\t\t<OverrideReplacementYearNext><![CDATA[{0}]]></OverrideReplacementYearNext>\r\n", discipline.OverrideNextReplacementYear == true ? 1 : 0);
					}
					//**************************

					//mam 01042012 - if component is retired, show zero on report
					if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", 0);	//999999
					}
					else
					{
						//mam 112806
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(discipline.GetCurrentValue(), roundDigit).ToString("#,##0"));

						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(discipline.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(discipline.GetRepairCost(), roundDigit).ToString("#,##0"));
					}

					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(discipline.AnnualMaintCost, roundDigit));

					//mam - added if condition
					//Condition
					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
						if (pipe.GetCurrentValue() == 0)
						{
							builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", "N/A");
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", string.Format("{0:F1}", pipe.GetAverageCondition()));
						}
						
						//grid.SetData(row, (int)Columns.ConditionRank, string.Format("{0:F1}", pipe.GetAverageCondition()));
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;
						if (node.GetCurrentValue() == 0)
						{
							builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", "N/A");
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", string.Format("{0:F1}", node.GetAverageCondition()));
						}
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
					}

					//mam - added if condition
					//Update: check Current Value only for pipes and nodes
					//if (discipline.GetCurrentValue() == 0)
					if (!MechStructDisciplines && discipline.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", discipline.GetEvaluatedRemainingUsefulLife());
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", discipline.GetEconomicUsefulLife());
					}
				}

				//*************************************************

				//mam - include LOS, Criticality, Vulnerability and Risk in the report for pipes and nodes
				//if (discipline.Type == DisciplineType.Pipes || discipline.Type == DisciplineType.Nodes)
				if (!MechStructDisciplines)
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetCurrentValue() == 0)
						{
							builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", "N/A");
							builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", "N/A");
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", pipe.GetAverageLOS());
							builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", pipe.GetAverageCriticality());
						}

						//if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
						if (pipe.GetCurrentValue() == 0 || pipesERULVulnNA)
						{
							//pipesERULVulnNA = true;
							builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", "N/A");
							builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
						}
						else
						{
							//pipesERULVulnNA = false;
							//mam 090105 - round vuln to 4 decimals rather than 2
							//builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", pipe.GetAverageVulnerability());
							builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", pipe.GetAverageVulnerability());
							builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", pipe.GetAverageRisk());
						}
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetCurrentValue() == 0)
						{
							builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", "N/A");
							builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", "N/A");
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", node.GetAverageLOS());
							builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", node.GetAverageCriticality());
						}


						//if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
						if (node.GetCurrentValue() == 0 || nodesERULVulnNA)
						{
							//nodesERULVulnNA = true;
							builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", "N/A");
							builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
						}
						else
						{
							//nodesERULVulnNA = false;
							//mam 090105 - round vuln to 4 decimals rather than 2
							//builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", node.GetAverageVulnerability());
							builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", node.GetAverageVulnerability());
							builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", node.GetAverageRisk());
						}
					}
				}
				//</mam>

				//*************************************************

				//mam - comment
				//}
				//</mam>

				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", discipline.CWPAssetValue * 100.0);
				if (discipline.ConditionRanking == CondRank.No)
					builder.Append("\t\t\t<AllocGridCurrentValue>0</AllocGridCurrentValue>\r\n");
				else
					builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", discipline.GetDisciplineCost());

				builder.Append("\t\t</Discipline>\r\n");
			}

			//***********************************

			//BEGIN TOTAL ROW HERE

			builder.Append("\t\t<Discipline>\r\n");
			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", "Total");

			//mam - use the adjusted total when possible
			if (adjustedValues == null)
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", disciplineTotals.GetCalcTotalCWP());
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", adjustedTotal);
			}
			//</mam>

			//mam 01042012 - if component is retired, show zero on report
			if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", 0);	//999999
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", 0);	//999999
				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", 0);	//999999
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCost(), roundDigit));

				//mam 112806 - commented
				//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalReplacementValue(), roundDigit));
			}

			//mam 01042012 - if component is retired, show zero on report
			if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", disciplineTotals.GetAverageReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", 0);	//999999
				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", 0);	//999999
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", 0);	//999999
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", 0);	//999999
			}
			else
			{
				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", disciplineTotals.GetAverageReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCumulativeDepreciation(), roundDigit));
			}

			//mam - if all disciplines have Condition = N/A, then various totals will be N/A
			if (disciplineTotals.CheckIfAllNADiscipline(m_infoSetID, ID))
			{
				//mam 112806
				//current value, repair cost
				if (MechStructDisciplines)
				{
					if (mscOverrideAnyCurrentValue)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
					}
					if (mscOverrideAnyRepairCost)
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}
				}
				else
				{
					if (pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}
				}

				//mam 112806 - commented
				//builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");

				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
				}

				if (disciplineTotals.GetTotalCurrentValue() == 0)
				{
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", disciplineTotals.GetTotalOrgUsefulLife());
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", disciplineTotals.GetTotalRemainingUsefulLife());
				}
				//</mam>

				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				//mam 01042012 - if component is retired, show zero on report
				if (this.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", 0);	//999999
				}
				else
				{
					//mam 112806
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
				}

				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));

				if (disciplineTotals.GetTotalCurrentValue() == 0)
				{
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					//mam - use interpolated value
					//builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", disciplineTotals.GetRankPercent());
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", disciplineTotals.GetRankPercentInterpolated());
					//</mam>

					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", disciplineTotals.GetTotalOrgUsefulLife());
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", disciplineTotals.GetTotalRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", disciplineTotals.GetTotalEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", disciplineTotals.GetTotalEconomicUsefulLife());
				}
				//builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", disciplineTotals.GetTotalEvaluatedRemainingUsefulLife());
				//builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", disciplineTotals.GetTotalEconomicUsefulLife());
			}
			//**************************************
			//mam - include LOS, Criticality, Vulnerability and Risk totals in the report for pipes and nodes
			if (!MechStructDisciplines)
			{
				//mam - 121504 - match UI\Grids\DisciplineAssessmentGrid.UpdateDisciplineGridTotals lines 637 and 660
				//	by using only GetCurrentValue() as a test for LOS and OCrit = N/A
				if (GetCurrentValue() == 0)
				{
					builder.AppendFormat("\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", "N/A");
					builder.AppendFormat("\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", GetLOS());
					builder.AppendFormat("\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", GetOverallCriticality());
				}
				//</mam>

				if (GetCurrentValue() == 0 || (pipesERULVulnNA && nodesERULVulnNA))
				{
					//builder.AppendFormat("\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", "N/A");
					//builder.AppendFormat("\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", "N/A");
					builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
				}
				else
				{
					//builder.AppendFormat("\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", GetLOS());
					//builder.AppendFormat("\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", GetOverallCriticality());

					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", Vulnerability);
					builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", Vulnerability);

					builder.AppendFormat("\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", GetRisk());
				}
			}
			//</mam>
			//**************************************

			builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", disciplineTotals.GetTotalCWPValue() * 100.0);
			builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalOrgCost(), roundDigit));
			builder.Append("\t\t</Discipline>\r\n");
			builder.Append("\t</Disciplines>\r\n");
			builder.Append("</ComponentData>\r\n");
			return builder.ToString();
		}

		//mam
		public string GetXMLMatrix(bool includePhotos, string selectedFilters, string selectedSortOrder, ArrayList filteredItems)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			//bool useNA = false;

			//remove (char)34
			if (selectedFilters != "" && selectedFilters.StartsWith(Convert.ToString((char)34)))
			{
				selectedFilters = selectedFilters.Remove(0, 1);
				int j = selectedFilters.IndexOf((char)34);
				if (j > -1)
					selectedFilters = selectedFilters.Remove(j, 1);
			}

			//mam 07072011
			ArrayList arrayListCip = Common.CommonTasks.GetCipObjects();

			StringBuilder builder = new StringBuilder();

			builder.Append("<ComponentData>\r\n");
			builder.Append("\t<Filters>\r\n");
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			builder.AppendFormat("\t\t<SelectedSortOrder><![CDATA[{0}]]></SelectedSortOrder>\r\n", selectedSortOrder);
			builder.Append("\t</Filters>\r\n");
			
			Facility facility = null;
			TreatmentProcess process = null;
			MajorComponent component;
			Discipline discipline;
			//Discipline[] disciplines = CacheManager.GetDisciplines(m_infoSetID, ID);
			WAM.Logic.DisciplineTotals disciplineTotals = null;
			WAM.Logic.MajorComponentTotals componentTotals = null;
			DisciplinePipe	pipe;
			DisciplineNode	node;
			decimal totalValue = 0;
			decimal adjustedTotal = 0;
			double cwpVal = 0.0;
			int curCompPos = 0;
			int curProcID = 0;
			//double cwpVal = 0.0;
			bool pipesERULVulnNA = false;
			bool nodesERULVulnNA = false;

			builder.Append("\t<Components>\r\n");

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				component = (MajorComponent)filteredItems[pos];

				process = component.GetTreatmentProcess();
				facility = process.GetFacility();
				Discipline[] disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);
				disciplineTotals = component.GetDisciplineTotals();
				//totalValue = disciplineTotals.GetTotalCurrentValue();
				componentTotals = process.GetComponentTotals();

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//totalValue = componentTotals.GetTotalCurrentValue();
				totalValue = componentTotals.GetTotalAcquisitionCost();
				decimal totalValueRounded = componentTotals.GetTotalAcquisitionCostRoundIndividualValues();

				pipesERULVulnNA = false;
				nodesERULVulnNA = false;

				//mam 112806
				ResetOverrideVariables();

				//if pipe or node, determine ERUL and Vuln override
				//**************************************************
				for (int i = 0; i < disciplines.Length; i++)
				{
					discipline = disciplines[i];

					if (component.MechStructDisciplines)
					{
						//mam 112806
						if (discipline.OverrideCurrentValue)
						{
							//mam 07072011 - should this be preceded with component? - no it is a private variable
							//	used only when creating reports
							mscOverrideAnyCurrentValue = true;
						}
						if (discipline.OverrideRepairCost)
						{
							mscOverrideAnyRepairCost = true;
						}
					}
					else
					{
						pipe = discipline as DisciplinePipe;
						node = discipline as DisciplineNode;

						if (discipline.Type == DisciplineType.Pipes)
						{
							pipe = disciplines[i] as DisciplinePipe;
					
							if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
								pipesERULVulnNA = true;
							else
								pipesERULVulnNA = false;

							//mam 112806
							if (pipe.GetAnyCurrentValueOverridden())
							{
								pipeOverrideAnyCurrentValue = true;
							}
							if (pipe.GetAnyRepairCostOverridden())
							{
								pipeOverrideAnyRepairCost = true;
							}
						}
						else if (discipline.Type == DisciplineType.Nodes)
						{
							node = disciplines[i] as DisciplineNode;

							if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
								nodesERULVulnNA = true;
							else
								nodesERULVulnNA = false;

							//mam 112806
							if (node.GetAnyCurrentValueOverridden())
							{
								nodeOverrideAnyCurrentValue = true;
							}
							if (node.GetAnyRepairCostOverridden())
							{
								nodeOverrideAnyRepairCost = true;
							}
						}
					}
				}

				//				//************************************

				decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(component.InfoSetID, component.ProcessID, totalValueRounded, WAM.UI.NodeType.TreatmentProcess);
				if (adjustedValues != null)
				{
					for (int i = 0; i < adjustedValues.Length; i++)
					{
						adjustedTotal += adjustedValues[i];
					}
				}

				//Variable 'pos' counts from 0 to the number of processes, which can include processes from multiple facilities.
				//	This is fine for the first facility, but because pos is never reset to zero, every subsequent facility 
				//	starts with a non-zero pos value.  This will result in an out-of-range error, so use curFacPos instead.
				if (curProcID == component.ProcessID)
				{
					curCompPos += 1;
				}
				else
				{
					curProcID = component.ProcessID;
					curCompPos = 0;
				}

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(component.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(component.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					//use curFacPos instead of pos
					//cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
					cwpVal = Convert.ToDouble(adjustedValues[curCompPos].ToString());
				}
				//</mam>
				//************************************

				builder.Append("\t\t<Component>\r\n");
				builder.AppendFormat("\t\t\t<GridNameFac><![CDATA[{0}]]></GridNameFac>\r\n", facility.Name);
				builder.AppendFormat("\t\t\t<GridNameProc><![CDATA[{0}]]></GridNameProc>\r\n", process.Name);
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", component.Name);
				builder.AppendFormat("\t\t\t<GridFacilityCurrentYear><![CDATA[{0}]]></GridFacilityCurrentYear>\r\n", facility.CurrentYear);
				builder.AppendFormat("\t\t\t<GridFacilityCurrentENR><![CDATA[{0}]]></GridFacilityCurrentENR>\r\n", facility.CurrentENR);

				if (component.Retired)
					builder.AppendFormat("\t\t\t<GridRetired>{0}</GridRetired>\r\n", "TRUE");
				else
					builder.AppendFormat("\t\t\t<GridRetired>{0}</GridRetired>\r\n", "");

				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCost(), roundDigit));

					//mam 112806
					//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit));

					//mam 050806
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCostEscalated(), roundDigit));

					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalReplacementValue(), roundDigit));
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", disciplineTotals.GetAverageReplacementValueYear());
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalSalvageValue(), roundDigit));
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", 0);	//999999
				}
				else
				{
					//mam 050806
					builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", disciplineTotals.GetAverageReplacementValueYear());
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRehabCost(), roundDigit));

					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalBookValue(), roundDigit));
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalSalvageValue(), roundDigit));
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualDepreciation(), roundDigit));
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCumulativeDepreciation(), roundDigit));
				}

				//if all disciplines have Condition = N/A, then various totals will be N/A
				if (disciplineTotals.CheckIfAllNADiscipline(m_infoSetID, ID))
				{
					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
					}
					else
					{
						//mam 112806
						//current value
						if ((component.MechStructDisciplines && mscOverrideAnyCurrentValue) 
							|| (!component.MechStructDisciplines && (pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)))
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
						}

						//mam 112806
						//repair cost
						if ((component.MechStructDisciplines && mscOverrideAnyRepairCost) 
							|| (!component.MechStructDisciplines && (pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)))
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
						}

						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
					}

					//mam 112806 - commented
					//builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");

					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");

					if (disciplineTotals.GetTotalCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", disciplineTotals.GetTotalOrgUsefulLife());
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", disciplineTotals.GetTotalRemainingUsefulLife());
					}
					//</mam>

					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", 0);	//999999
						builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					}
					else
					{
						//mam 112806
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));

						builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalEvaluatedValue(), roundDigit).ToString("#,##0"));

						//mam 112806
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
						builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					}

					if (disciplineTotals.GetTotalCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
					}
					else
					{
						//use interpolated value
						//builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", disciplineTotals.GetRankPercent());
						builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", disciplineTotals.GetRankPercentInterpolated());

						builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", disciplineTotals.GetTotalOrgUsefulLife());
						builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", disciplineTotals.GetTotalRemainingUsefulLife());
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", disciplineTotals.GetTotalEvaluatedRemainingUsefulLife());
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", disciplineTotals.GetTotalEconomicUsefulLife());
					}
					//builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", disciplineTotals.GetTotalEvaluatedRemainingUsefulLife());
					//builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", disciplineTotals.GetTotalEconomicUsefulLife());
				}

				//**************************************


				//builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0}]]></GridRankPercent>\r\n", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
				//builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", EnumHandlers.GetLOSShort(component.LOS));
			
				if (component.MechStructDisciplines)
				{
					//mam 050806
					builder.AppendFormat("\t\t\t<GridRedundantAssets><![CDATA[{0:F0}]]></GridRedundantAssets>\r\n", component.RedundantAssetCount);

					builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0:F1}]]></GridLevelOfService>\r\n", component.GetLOS());

					//mam 07072011 - no longer using four fixed crits
					//builder.AppendFormat("\t\t\t<GridCritPublicHealth><![CDATA[{0}]]></GridCritPublicHealth>\r\n", EnumHandlers.GetCritPublicHealthString(component.CritPublicHealth));
					//builder.AppendFormat("\t\t\t<GridCritEnvironmental><![CDATA[{0}]]></GridCritEnvironmental>\r\n", EnumHandlers.GetCritEnvironmentalString(component.CritEnvironmental));
					//builder.AppendFormat("\t\t\t<GridCritCostOfRepairs><![CDATA[{0}]]></GridCritCostOfRepairs>\r\n", EnumHandlers.GetCritRepairCostString(component.CritRepair));
					//builder.AppendFormat("\t\t\t<GridCritCustEffect><![CDATA[{0}]]></GridCritCustEffect>\r\n", EnumHandlers.GetCritCustomerEffectString(component.CritCustEffect));

					//mam 07072011 - new crits
					foreach (MajorComponentSelectedCriticalityFactors critFactor in component.ComponentSelectedCriticalityFactorsCollection)
					{
						string critNumberText = "Crit" + critFactor.CriticalityNumber.ToString();
						builder.AppendFormat("\t\t\t<" + critNumberText + "><![CDATA[{0}]]></" + critNumberText + ">\r\n", critFactor.CritFactor.FactorName);
					}

					builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", component.GetOverallCriticality());
				}
				else
				{
					//mam 050806
					builder.AppendFormat("\t\t\t<GridRedundantAssets><![CDATA[{0:F0}]]></GridRedundantAssets>\r\n", "N/A");

					//mam 07072011 - no longer using the four fixed crits
					//builder.AppendFormat("\t\t\t<GridCritPublicHealth><![CDATA[{0}]]></GridCritPublicHealth>\r\n", "N/A");
					//builder.AppendFormat("\t\t\t<GridCritEnvironmental><![CDATA[{0}]]></GridCritEnvironmental>\r\n", "N/A");
					//builder.AppendFormat("\t\t\t<GridCritCostOfRepairs><![CDATA[{0}]]></GridCritCostOfRepairs>\r\n", "N/A");
					//builder.AppendFormat("\t\t\t<GridCritCustEffect><![CDATA[{0}]]></GridCritCustEffect>\r\n", "N/A");

					//mam 07072011 - new crits
					for (int i = 1; i <= Common.CommonTasks.Criticalities.Count; i++)
					{
						builder.AppendFormat("\t\t\t<Crit" + i.ToString() + "><![CDATA[{0}]]></Crit" + i.ToString() + ">\r\n", "N/A");
					}

					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0:F1}]]></GridLevelOfService>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0:F1}]]></GridLevelOfService>\r\n", component.GetLOS());
						builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", component.GetOverallCriticality());
					}
				}

				if (component.MechStructDisciplines)
				{
					if (component.GetEvaluatedRemainingUsefulLife() == 0 && !component.OverrideVulnerability)
					{
						builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
						builder.AppendFormat("\t\t<GridOverrideVulnerability><![CDATA[{0}]]></GridOverrideVulnerability>\r\n", 0);
						builder.AppendFormat("\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", component.GetVulnerability());
						builder.AppendFormat("\t\t<GridOverrideVulnerability><![CDATA[{0}]]></GridOverrideVulnerability>\r\n", Convert.ToInt32(component.OverrideVulnerability));
						builder.AppendFormat("\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", component.GetRisk());
					}

					//mam 07072011
					//string cipPlanningMode = GetCipModeTextFromId(arrayListCip, CipPlanningId);
					string cipPlanningMode = component.CipPlanningId == 0 ? "N/A" : GetCipModeTextFromId(arrayListCip, component.CipPlanningId);
					builder.AppendFormat("\t\t<GridCipPlanningMode><![CDATA[{0}]]></GridCipPlanningMode>\r\n", cipPlanningMode);
					builder.AppendFormat("\t\t<GridAssetClass><![CDATA[{0}]]></GridAssetClass>\r\n", component.AssetClass);
				}
				else
				{
					if (component.GetCurrentValue() == 0 || (pipesERULVulnNA && nodesERULVulnNA))
					{
						builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", "N/A");
						builder.AppendFormat("\t\t<GridOverrideVulnerability><![CDATA[{0}]]></GridOverrideVulnerability>\r\n", 0);
						builder.AppendFormat("\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", component.Vulnerability);
						builder.AppendFormat("\t\t<GridOverrideVulnerability><![CDATA[{0}]]></GridOverrideVulnerability>\r\n", 0);
						builder.AppendFormat("\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", component.GetRisk());
					}

					builder.AppendFormat("\t\t<GridCipPlanningMode><![CDATA[{0}]]></GridCipPlanningMode>\r\n", "N/A");
					builder.AppendFormat("\t\t<GridAssetClass><![CDATA[{0}]]></GridAssetClass>\r\n", "N/A");
				}
				//</mam>
				
				//**************************************

				//builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", disciplineTotals.GetTotalCWPValue() * 100.0);
				//builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", disciplineTotals.GetTotalOrgCost());
				builder.Append("\t\t</Component>\r\n");
			}
			builder.Append("\t</Components>\r\n");

			builder.Append("</ComponentData>\r\n");

			return builder.ToString();
		}
		//</mam>

		//mam
		public string GetCSVData(string selectedFilters, string selectedSortOrder, ArrayList filteredItems, bool includeDisciplines)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			Facility facility;
			TreatmentProcess process;
			MajorComponent component;
			Discipline discipline;
			WAM.Logic.DisciplineTotals disciplineTotals = null;
			WAM.Logic.MajorComponentTotals componentTotals = null;
			DisciplinePipe	pipe;
			DisciplineNode	node;
			decimal totalValue = 0;
			decimal adjustedTotal = 0;
			double cwpVal = 0.0;
			int curCompPos = 0;
			int curProcID = 0;
			bool pipesERULVulnNA = false;
			bool nodesERULVulnNA = false;
			string disciplineXML = "";

			//mam 07072011
			ArrayList arrayListCip = Common.CommonTasks.GetCipObjects();

			StringBuilder builder = new StringBuilder();

			if (includeDisciplines)
				builder.Append("Major Component / Subbasin / Subzone Detail Report");
			else
				builder.Append("Major Component / Subbasin / Subzone Summary Report");

			builder.Append("\r\n");

			if (selectedFilters != "")
			{
				//modify selectedFilters language if report is a detail report
				if (includeDisciplines)
				{
					selectedFilters = selectedFilters.Replace("The totals for this", "Each");
					selectedFilters = selectedFilters.Replace("have", "in this report has");
				}

				builder.Append("\r\n");
				//builder.AppendFormat((char)34 + selectedFilters + (char)34);
				builder.AppendFormat(selectedFilters);
				builder.Append("\r\n\r\n");
			}

			//include sort order on both summary and detail CSV reports
			//if (selectedSortOrder != "" && !includeDisciplines)
			if (selectedSortOrder != "")
			{
				builder.AppendFormat((char)34 + selectedSortOrder + (char)34);
				builder.Append("\r\n\r\n");
			}

			builder.Append((char)34 + "Facility / System" + (char)34);
			builder.Append("," + (char)34 + "Treatment Process / Basin / Zone" + (char)34);
			builder.Append("," + (char)34 + "Major Component / Subbasin / Subzone" + (char)34);
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Discipline" + (char)34);
			}
			builder.Append("," + (char)34 + "Facility Current Year" + (char)34);
			builder.Append("," + (char)34 + "Facility Current ENR" + (char)34);
			builder.Append("," + (char)34 + "Major Component Cost Weighted Percentage of Asset Value (%)" + (char)34);
			builder.Append("," + (char)34 + "Retired" + (char)34);
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Discipline Cost Weighted Percentage of Asset Value (%)" + (char)34);
			}
			builder.Append("," + (char)34 + "Acquisition Cost" + (char)34);
			builder.Append("," + (char)34 + "Current Value" + (char)34);

			//mam 112806
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Current Value Overridden" + (char)34);
			}

			//mam 050806
			builder.Append("," + (char)34 + "Escalated Acquisition Cost" + (char)34);

			builder.Append("," + (char)34 + "Replacement Value" + (char)34);

			//mam 01222012
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Replacement Value Source/Description" + (char)34);
			}

			//mam 112806
			builder.Append("," + (char)34 + "Replacement Value Year" + (char)34);

			//mam 01222012 - added Time to Next Replacement and check for includeDisciplines
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Time to Next Replacement" + (char)34);

				//mam 07072011
				builder.Append("," + (char)34 + "Next Replacement Year" + (char)34);
				builder.Append("," + (char)34 + "Override Next Replacement Year" + (char)34);
			}

			//mam 050806
			builder.Append("," + (char)34 + "Rehabilitation Cost" + (char)34);

			//mam 07072011
			if (includeDisciplines)
			{
				//mam 01222012
				builder.Append("," + (char)34 + "Rehabilitation Cost Source/Description" + (char)34);

				builder.Append("," + (char)34 + "Rehabilitation Cost Year" + (char)34);
				builder.Append("," + (char)34 + "Rehabilitation Interval" + (char)34);
				builder.Append("," + (char)34 + "Last Rehabilitation Year" + (char)34);
				builder.Append("," + (char)34 + "Time to Next Rehabilitation" + (char)34);

				//mam 01222012 - no longer allowing overriding of Time to Next Rehab
				//builder.Append("," + (char)34 + "Override Time to Next Rehabilitation" + (char)34);

				builder.Append("," + (char)34 + "Next Rehabilitation Year" + (char)34);

				//mam 01222012
				builder.Append("," + (char)34 + "Override Next Rehabilitation Year" + (char)34);
			}

			builder.Append("," + (char)34 + "Book Value" + (char)34);
			builder.Append("," + (char)34 + "Salvage Value" + (char)34);
			builder.Append("," + (char)34 + "Annual Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Cumulative Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Value"+ (char)34);
			builder.Append("," + (char)34 + "Repair Cost" + (char)34);

			//mam 112806
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Repair Cost Overridden" + (char)34);
			}

			builder.Append("," + (char)34 + "Annual Maintenance Cost" + (char)34);

			//mam 112806
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Discipline Installation Year" + (char)34);
				builder.Append("," + (char)34 + "Discipline Original ENR" + (char)34);
			}

			builder.Append("," + (char)34 + "Condition" + (char)34);
			builder.Append("," + (char)34 + "Original Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Economic Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Level of Service" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Number of Assets with Similar Functionality" + (char)34);

			//mam 07072011 - no longer using four fixed crits
			//builder.Append("," + (char)34 + "Criticality - Public Health and Safety" + (char)34);
			//builder.Append("," + (char)34 + "Criticality - Environment" + (char)34);
			//builder.Append("," + (char)34 + "Criticality - Cost of Repairs" + (char)34);
			//builder.Append("," + (char)34 + "Criticality - Effect on Customers" + (char)34);

			//mam 07072011 - new crits
			//if the first component is a pipe/node component, it has no crits, so the crit names won't get written out to the report
			//instead of looking at the component's crits, get the crits from Criticalites
			//foreach (MajorComponentSelectedCriticalityFactors critFactor in componentSelectedCritFactorCollection)
			foreach (Criticality crit in Common.CommonTasks.Criticalities)
			{
				string critNumberText = "Crit" + crit.CriticalityNumber.ToString();
				builder.Append("," + (char)34 + "Criticality - " + crit.CriticalityName + (char)34);
			}

			builder.Append("," + (char)34 + "Overall Criticality" + (char)34);
			builder.Append("," + (char)34 + "Vulnerability" + (char)34);
			builder.Append("," + (char)34 + "Vulnerability Overridden" + (char)34);
			builder.Append("," + (char)34 + "Risk" + (char)34);

			//mam 07072011
			builder.Append("," + (char)34 + "Planning Mode" + (char)34);
			builder.Append("," + (char)34 + "Asset Class" + (char)34);

			//mam 011206
			builder.Append("," + (char)34 + "Comments" + (char)34);

			//mam 112806
			if (includeDisciplines)
			{
				builder.Append("," + (char)34 + "Date of Inspection" + (char)34);
				builder.Append("," + (char)34 + "Equipment/ID Number" + (char)34);
				builder.Append("," + (char)34 + "Manufacturer" + (char)34);
				builder.Append("," + (char)34 + "Assessed By" + (char)34);
				builder.Append("," + (char)34 + "Run Hours" + (char)34);
				builder.Append("," + (char)34 + "Running at Inspection" + (char)34);

				//discipline component info for MSC disciplines
				//mech
				builder.Append("," + (char)34 + "Mech Excessive Vibration" + (char)34);
				builder.Append("," + (char)34 + "Mech Excessive Noise" + (char)34);
				builder.Append("," + (char)34 + "Mech Excessive Corrosion" + (char)34);
				builder.Append("," + (char)34 + "Mech Excessive Leaks" + (char)34);
				builder.Append("," + (char)34 + "Mech Running Hot" + (char)34);
				builder.Append("," + (char)34 + "Mech Can Run When Inspected" + (char)34);
				builder.Append("," + (char)34 + "Mech Support Equipment Functional" + (char)34);
				builder.Append("," + (char)34 + "Mech Parts Missing" + (char)34);
				builder.Append("," + (char)34 + "Mech Parts Available" + (char)34);
				builder.Append("," + (char)34 + "Mech Adequate" + (char)34);
				builder.Append("," + (char)34 + "Mech Motor Amps" + (char)34);
				builder.Append("," + (char)34 + "Mech Instrument Indication Functional" + (char)34);
				builder.Append("," + (char)34 + "Mech Instrument Alarms Functional" + (char)34);
				builder.Append("," + (char)34 + "Mech Instrument Parts Missing" + (char)34);
				builder.Append("," + (char)34 + "Mech Instrument Parts Available" + (char)34);
				builder.Append("," + (char)34 + "Mech Electrical Excessive Corrosion" + (char)34);
				builder.Append("," + (char)34 + "Mech Electrical Clean Contacts" + (char)34);
				builder.Append("," + (char)34 + "Mech Electrical Parts Available" + (char)34);
				builder.Append("," + (char)34 + "Mech Piping Excessive Corrosion" + (char)34);
				builder.Append("," + (char)34 + "Mech Piping Excessive Leaks" + (char)34);
				builder.Append("," + (char)34 + "Mech Piping Paint Good" + (char)34);

				//struct
				builder.Append("," + (char)34 + "Struct Concrete Spalling" + (char)34);
				builder.Append("," + (char)34 + "Struct Excessive Corrosion" + (char)34);
				builder.Append("," + (char)34 + "Struct Member Excessive Corrosion" + (char)34);
				builder.Append("," + (char)34 + "Struct Corrosion Coating" + (char)34);
				builder.Append("," + (char)34 + "Struct Paint Good" + (char)34);
				builder.Append("," + (char)34 + "Struct Visible Deformities" + (char)34);
				builder.Append("," + (char)34 + "Struct Settling Evident" + (char)34);
				builder.Append("," + (char)34 + "Struct Major Cracks" + (char)34);
			
				//civil
				builder.Append("," + (char)34 + "Civil Several Potholes" + (char)34);
				builder.Append("," + (char)34 + "Civil Excessive Erosion" + (char)34);
				builder.Append("," + (char)34 + "Civil Road Degradation" + (char)34);
				builder.Append("," + (char)34 + "Civil Expansion Space" + (char)34);
				builder.Append("," + (char)34 + "Civil Functional Ground Cover" + (char)34);
				builder.Append("," + (char)34 + "Civil Fencing Adequate" + (char)34);
				builder.Append("," + (char)34 + "Civil Facilities Secure" + (char)34);
				builder.Append("," + (char)34 + "Civil Clay Liner" + (char)34);
				builder.Append("," + (char)34 + "Civil Berm Erosion Interior" + (char)34);
				builder.Append("," + (char)34 + "Civil Berm Erosion Exterior" + (char)34);
				builder.Append("," + (char)34 + "Civil Berm Vegetation" + (char)34);
				builder.Append("," + (char)34 + "Civil Berm Settlement" + (char)34);
				builder.Append("," + (char)34 + "Civil Berm Seepage" + (char)34);
				builder.Append("," + (char)34 + "Civil Burrow Holes" + (char)34);
				builder.Append("," + (char)34 + "Civil Erosion Protection Present" + (char)34);
				builder.Append("," + (char)34 + "Civil Erosion Protection Adequate" + (char)34);
				builder.Append("," + (char)34 + "Civil Algal Blooms" + (char)34);
				builder.Append("," + (char)34 + "Civil Drainage Adequate" + (char)34);
			}

			//mam 03202012
			builder.Append("," + (char)34 + "Photo File" + (char)34);
			builder.Append("," + (char)34 + "Photo Caption" + (char)34);

			//**************************************

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				component = (MajorComponent)filteredItems[pos];
				process = component.GetTreatmentProcess();
				facility = process.GetFacility();
				Discipline[] disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);
				disciplineTotals = component.GetDisciplineTotals();
				componentTotals = process.GetComponentTotals();
				//totalValue = disciplineTotals.GetTotalCurrentValue();
				

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//totalValue = componentTotals.GetTotalCurrentValue();
				totalValue = componentTotals.GetTotalAcquisitionCost();
				decimal totalValueRounded = componentTotals.GetTotalAcquisitionCostRoundIndividualValues();

				pipesERULVulnNA = false;
				nodesERULVulnNA = false;
				bool useNA = disciplineTotals.CheckIfAllNADiscipline(component.InfoSetID, component.ID);
				decimal componentCurrentValue = component.GetCurrentValue();

				//mam 112806
				ResetOverrideVariables();

				//if pipe or node, determine ERUL and Vuln override
				for (int i = 0; i < disciplines.Length; i++)
				{
					discipline = disciplines[i];

					if (component.MechStructDisciplines)
					{
						//mam 112806
						if (discipline.OverrideCurrentValue)
						{
							mscOverrideAnyCurrentValue = true;
						}
						if (discipline.OverrideRepairCost)
						{
							mscOverrideAnyRepairCost = true;
						}
					}
					else
					{
						pipe = discipline as DisciplinePipe;
						node = discipline as DisciplineNode;

						if (discipline.Type == DisciplineType.Pipes)
						{
							pipe = disciplines[i] as DisciplinePipe;
					
							if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
								pipesERULVulnNA = true;
							else
								pipesERULVulnNA = false;

							//mam 112806
							if (pipe.GetAnyCurrentValueOverridden())
							{
								pipeOverrideAnyCurrentValue = true;
							}
							if (pipe.GetAnyRepairCostOverridden())
							{
								pipeOverrideAnyRepairCost = true;
							}
						}
						else if (discipline.Type == DisciplineType.Nodes)
						{
							node = disciplines[i] as DisciplineNode;

							if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
								nodesERULVulnNA = true;
							else
								nodesERULVulnNA = false;

							
							//mam 112806
							if (node.GetAnyCurrentValueOverridden())
							{
								nodeOverrideAnyCurrentValue = true;
							}
							if (node.GetAnyRepairCostOverridden())
							{
								nodeOverrideAnyRepairCost = true;
							}
						}
					}
				}

				decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(component.InfoSetID, component.ProcessID, totalValueRounded, WAM.UI.NodeType.TreatmentProcess);
				if (adjustedValues != null)
				{
					for (int i = 0; i < adjustedValues.Length; i++)
					{
						adjustedTotal += adjustedValues[i];
					}
				}

				//Variable 'pos' counts from 0 to the number of processes, which can include processes from multiple facilities.
				//	This is fine for the first facility, but because pos is never reset to zero, every subsequent facility 
				//	starts with a non-zero pos value.  This will result in an out-of-range error, so use curFacPos instead.
				if (curProcID == component.ProcessID)
				{
					curCompPos += 1;
				}
				else
				{
					curProcID = component.ProcessID;
					curCompPos = 0;
				}

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(componentCurrentValue / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(component.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					//use curFacPos instead of pos
					//cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
					cwpVal = Convert.ToDouble(adjustedValues[curCompPos].ToString());
				}
				//</mam>

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);

				if (includeDisciplines)
				{
					builder.Append(",");	//placeholder for discipline type
				}
				builder.AppendFormat(",{0:F0}", facility.CurrentYear);
				builder.AppendFormat(",{0:F0}", facility.CurrentENR);
				builder.AppendFormat(",{0:F1}", cwpVal);

				if (component.Retired)
				{
					builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");
				}
				else
				{
					builder.Append(",");
				}

				if (includeDisciplines)
				{
					builder.Append(",");
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//acquisition cost	//XXXX
					builder.Append(",0");	//current value	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCost(), roundDigit));

					//mam 112806 - check useNA
					if (useNA)
					{
						//mam 112806 - commented
						//builder.Append(",N/A");

						//mam 112806
						if ((component.MechStructDisciplines && mscOverrideAnyCurrentValue)
							|| (!component.MechStructDisciplines && (pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)))
						{
							builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit));
						}
						else
						{
							builder.Append(",N/A");
						}
					}
					else
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalCurrentValue(), roundDigit));
					}
				}

				//mam 112806
				if (includeDisciplines)
				{
					builder.Append(",N/A");	//override current value
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//escalated acquisition cost	//XXXX
					builder.Append(",0");	//replacement value	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAcquisitionCostEscalated(), roundDigit));

					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalReplacementValue(), roundDigit));
				}

				//mam 01222012
				if (includeDisciplines)
				{
					builder.Append(",N/A");	//replacement value desc
				}

				//mam 112806
				builder.AppendFormat(",{0:F0}", disciplineTotals.GetAverageReplacementValueYear());

				//mam 01222012 - added Time to Next Replacement and check for includeDisciplines
				if (includeDisciplines)
				{
					builder.AppendFormat(",{0:F0}", "N/A");	//time to next replacement

					//mam 07072011 - rolled up values or N/A placeholders? -- N/A placeholders - these values are not being rolled up
					//mam 07072011
					builder.AppendFormat(",{0:F0}", "N/A");	//next replacement year
					builder.AppendFormat(",{0:F0}", "N/A");	//override next replacement year
					//builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);
					//builder.AppendFormat(",{0:F0}", discipline.OverrideNextReplacementYear);
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//rehabilitation cost	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalRehabCost(), roundDigit));
				}

				//mam 07072011
				if (includeDisciplines)
				{
					//mam 01222012
					builder.Append(",N/A");	//rehab cost desc

					builder.Append(",N/A");	//rehab cost year
					builder.Append(",N/A");	//rehab interval
					builder.Append(",N/A");	//rehab year last
					builder.Append(",N/A");	//rehab next

					//mam 01222012 - no longer allowing overriding of time to next rehab
					//builder.Append(",N/A");	//override rehab next

					builder.Append(",N/A");	//rehab year next

					//mam 01222012
					builder.Append(",N/A");	//override rehab year next
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//book value	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalBookValue(), roundDigit));
				}

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalSalvageValue(), roundDigit));

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//annual depreciation	//XXXX
					builder.Append(",0");	//cumulative depreciation	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualDepreciation(), roundDigit));
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalCumulativeDepreciation(), roundDigit));
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//evaluated value	//XXXX
					builder.Append(",0");	//repair cost	//XXXX
					if (includeDisciplines)
					{
						builder.Append(",N/A");	//override repair cost
					}
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
				}
				else
				{
					//EV, RC, AMC
					if (useNA)
					{
						builder.Append(",N/A");	//evaluated value

						//mam 112806 - commented
						//builder.Append(",N/A");

						//mam 112806
						if ((component.MechStructDisciplines && mscOverrideAnyRepairCost)
							|| (!component.MechStructDisciplines && (pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)))
						{
							builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit));
						}
						else
						{
							builder.Append(",N/A");
						}

						//mam 112806
						if (includeDisciplines)
						{
							builder.Append(",N/A");	//override repair cost
						}

						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					}
					else
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalEvaluatedValue(), roundDigit));
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalRepairCost(), roundDigit));

						//mam 112806
						if (includeDisciplines)
						{
							builder.Append(",N/A");	//override repair cost
						}

						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(disciplineTotals.GetTotalAnnualMaintCost(), roundDigit));
					}
				}

				//mam 112806
				if (includeDisciplines)
				{
					builder.Append(",N/A");	//discipline installation year
					builder.Append(",N/A");	//discipline installation year enr (original enr)
				}

				//Cond
				if (useNA)
					builder.Append(",N/A");
				else
				{
					if (componentCurrentValue == 0)
					{
						builder.Append(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F1}", disciplineTotals.GetRankPercentInterpolated());
					}
				}

				//OUL, RUL
				if (componentCurrentValue == 0)
				{
					builder.Append(",N/A");
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F1}", disciplineTotals.GetTotalOrgUsefulLife());
					builder.AppendFormat(",{0:F1}", disciplineTotals.GetTotalRemainingUsefulLife());
				}
				//</mam>

				//EvRUL, EcRUL
				if (useNA)
				{
					builder.Append(",N/A");
					builder.Append(",N/A");
				}
				else
				{
					if (componentCurrentValue == 0)
					{
						builder.Append(",N/A");
						builder.Append(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F1}", disciplineTotals.GetTotalEvaluatedRemainingUsefulLife());
						builder.AppendFormat(",{0:F1}", disciplineTotals.GetTotalEconomicUsefulLife());
					}
				}

				if (component.MechStructDisciplines)
				{
					//LOS, Redundant Asset Count, four Crit values, Overall Crit
					builder.AppendFormat(",{0:F1}", component.GetLOS());

					//mam 050806
					builder.AppendFormat(",{0:F1}", component.RedundantAssetCount);

					//mam 07072011 - no longer using four fixed crits
					//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritPublicHealthString(component.CritPublicHealth));
					//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritEnvironmentalString(component.CritEnvironmental));
					//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritRepairCostString(component.CritRepair));
					//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritCustomerEffectString(component.CritCustEffect));

					//mam 07072011 - new crits
					if (component.componentSelectedCritFactorCollection.Count == 0)
					{
						//pipe and node components
						for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
						{
							builder.AppendFormat(",N/A");
						}
					}
					else
					{
						foreach (MajorComponentSelectedCriticalityFactors critFactor in component.componentSelectedCritFactorCollection)
						{
							string critNumberText = "Crit" + critFactor.CriticalityNumber.ToString();
							builder.AppendFormat("," + (char)34 + "{0}" + (char)34, critFactor.CritFactor.FactorName);
						}
					}

					builder.AppendFormat(",{0:F1}", component.GetOverallCriticality());

					//Vuln, Override Vuln, Risk
					if (component.GetEvaluatedRemainingUsefulLife() == 0 && !component.OverrideVulnerability)
					{
						builder.AppendFormat(",N/A");	//vuln

						//mam 112806
						//builder.AppendFormat(",N/A");	//override vuln
						builder.AppendFormat(",{0}", Convert.ToBoolean(component.OverrideVulnerability));

						builder.AppendFormat(",N/A");	//risk
					}
					else
					{
						builder.AppendFormat(",{0:F4}", component.GetVulnerability());
						//builder.AppendFormat(",{0}", Convert.ToInt32(component.OverrideVulnerability));
						builder.AppendFormat(",{0}", Convert.ToBoolean(component.OverrideVulnerability));
						builder.AppendFormat(",{0:F2}", component.GetRisk());
					}

					//mam 07072011
					//string cipPlanningMode = GetCipModeTextFromId(arrayListCip, CipPlanningId);
					string cipPlanningMode = component.CipPlanningId == 0 ? "N/A" : GetCipModeTextFromId(arrayListCip, component.CipPlanningId);
					builder.AppendFormat(",{0}", cipPlanningMode);
					builder.AppendFormat(",{0}", component.AssetClass);
				}
				else
				{
					//LOS
					if (componentCurrentValue == 0)
						builder.Append(",N/A");
					else
						builder.AppendFormat(",{0:F1}", component.GetLOS());
					//</mam>

					//mam 050806
					//Redundant Asset Count
					builder.AppendFormat(",N/A");

					//four Crit values
					//mam 090105 - changed to N/A
					//builder.AppendFormat(",");
					//builder.AppendFormat(",");
					//builder.AppendFormat(",");
					//builder.AppendFormat(",");

					//mam 07072011 - no longer using four fixed crits
					//builder.AppendFormat(",N/A");
					//builder.AppendFormat(",N/A");
					//builder.AppendFormat(",N/A");
					//builder.AppendFormat(",N/A");

					//mam 07072011 - use the correct number of crits
					for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
					{
						builder.AppendFormat(",N/A");
					}

					//Overall Crit
					if (componentCurrentValue == 0)
						builder.Append(",N/A");
					else
						builder.AppendFormat(",{0:F1}", component.GetOverallCriticality());

					//</mam>

					//Vuln, Override Vuln, Risk
					if (componentCurrentValue == 0 || (pipesERULVulnNA && nodesERULVulnNA))
					{
						builder.AppendFormat(",N/A");

						//mam 090105 - changed to N/A for Override Vuln
						//builder.Append(",");
						builder.AppendFormat(",N/A");

						//risk
						builder.AppendFormat(",N/A");

						//mam 07072011 - cip mode, asset class
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F4}", component.Vulnerability);

						//mam 090105 - changed to N/A for Override Vuln
						//builder.Append(",");
						builder.AppendFormat(",N/A");

						//risk
						builder.AppendFormat(",{0:F2}", component.GetRisk());

						//mam 07072011 - cip mode, asset class
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
				}

				//mam 101107 - replace double quote in comments with two double quotes 
				//string commentsQuotes = @component.Comments;
				//commentsQuotes = commentsQuotes.Replace("\"", "\"\"");
				string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@component.Comments);
				////mam 011206
				//builder.Append("," + (char)34 + component.Comments + (char)34);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);

				//mam 03202012
				string caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@component.CaptionPhoto);
				string photo = component.PhotoFileName;

				//mam 112806 - add placeholders for discipline-only values
				if (includeDisciplines)
				{
					builder.Append(",N/A");	//Date of Inspection
					builder.Append(",N/A");	//Equipment/ID Number
					builder.Append(",N/A");	//Manufacturer
					builder.Append(",N/A");	//Assessed By
					builder.Append(",N/A");	//Run Hours
					builder.Append(",N/A");	//Running at Inspection

					//47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
					builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
					builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
					builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
					builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
					builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");

					//mam 03202012
					builder.AppendFormat(",{0}", photo);
					builder.AppendFormat(",{0}", caption);
				}
				//mam 03202012
				else
				{
					//mam 03202012
					builder.AppendFormat(",{0}", photo);
					builder.AppendFormat(",{0}", caption);
				}

				if (includeDisciplines)
				{
					disciplineXML = GetCSVDataDisciplines(component);
					builder.Append(disciplineXML);
				}
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		private string GetCSVDataDisciplines(MajorComponent component)
		{
			//this method is for the Component detail report
			//it's purpose is to list the Discipline totals
			//	(so there will be no crits or the new rehab values (rehab int, next, yearlast, yearnext)

			TreatmentProcess process = component.GetTreatmentProcess();
			Facility facility = process.GetFacility();
			Discipline[] disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);
			Discipline discipline;
			DisciplinePipe pipe;
			DisciplineNode node;
			WAM.Logic.DisciplineTotals disciplineTotals = component.GetDisciplineTotals();

			//mam 07072011
			ArrayList arrayListCip = Common.CommonTasks.GetCipObjects();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal totalValue = disciplineTotals.GetTotalCurrentValue();
			decimal totalValue = disciplineTotals.GetTotalAcquisitionCost();
			decimal totalValueRounded = disciplineTotals.GetTotalAcquisitionCostRoundIndividualValues();

			decimal adjustedTotal = 0;
			double cwpVal = 0.0;
			bool useNA = false;
			StringBuilder builder = new StringBuilder();

			bool pipesERULVulnNA = false;
			bool nodesERULVulnNA = false;

			//mam 112806
			ResetOverrideVariables();

			//if pipe or node, determine ERUL and Vuln override
			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (component.MechStructDisciplines)
				{
					if (discipline.OverrideCurrentValue)
					{
						mscOverrideAnyCurrentValue = true;
					}
					if (discipline.OverrideRepairCost)
					{
						mscOverrideAnyRepairCost = true;
					}
				}
				else
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetAllERULZero() && !pipe.GetAnyVulnerabilityOverridden())
							pipesERULVulnNA = true;
						else
							pipesERULVulnNA = false;

						//mam 112806
						if (pipe.GetAnyCurrentValueOverridden())
						{
							pipeOverrideAnyCurrentValue = true;
						}
						if (pipe.GetAnyRepairCostOverridden())
						{
							pipeOverrideAnyRepairCost = true;
						}
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetAllERULZero() && !node.GetAnyVulnerabilityOverridden())
							nodesERULVulnNA = true;
						else
							nodesERULVulnNA = false;

						//mam 112806
						if (node.GetAnyCurrentValueOverridden())
						{
							nodeOverrideAnyCurrentValue = true;
						}
						if (node.GetAnyRepairCostOverridden())
						{
							nodeOverrideAnyRepairCost = true;
						}
					}
				}
			}

			adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(component.InfoSetID, component.ID, totalValueRounded, WAM.UI.NodeType.MajorComponent);
			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + (char)34);

				builder.AppendFormat(",{0:F0}", facility.CurrentYear);
				builder.AppendFormat(",{0:F0}", facility.CurrentENR);
				builder.Append(",");	//component cost-weighted percentage
				
				//mam 112806 - show component retired value
				//builder.Append(",");	//retired
				builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				//use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}

				//mam 112806 - moved this code below calculation of useNA
				//				builder.AppendFormat(",{0:F1}", cwpVal);
				//				builder.AppendFormat(",{0:F0}", discipline.AcquisitionCost);
				//				builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
				//
				//				//mam 050806
				//				builder.AppendFormat(",{0:F0}", discipline.AcquisitionCostEscalated);
				//
				//				builder.AppendFormat(",{0:F0}", discipline.ReplacementValue);
				//
				//				//mam 050806
				//				builder.AppendFormat(",{0:F0}", discipline.RehabCost);
				//
				//				builder.AppendFormat(",{0:F0}", discipline.GetBookValue());
				//				builder.AppendFormat(",{0:F0}", discipline.SalvageValue);
				//				builder.AppendFormat(",{0:F0}", discipline.GetAnnualDepreciation());
				//				builder.AppendFormat(",{0:F0}", discipline.GetCumulativeDepreciation());

				useNA = false;
				if (!component.MechStructDisciplines)
				{
					switch(discipline.Type)
					{
						case DisciplineType.Pipes:
						{
							if (GetAllConditionNAPipes(discipline.InfoSetID, discipline.ID))
							{
								//if all pipes for the current discipline have condition = N/A, then Cond and ERUL = N/A
								useNA = true;
							}
							break;
						}
							
						case DisciplineType.Nodes:
						{
							if (GetAllConditionNANodes(discipline.InfoSetID, discipline.ID))
							{
								//if all nodes for the current discipline have condition = N/A, then Cond and ERUL = N/A
								useNA = true;
							}
							break;
						}
					}
				}

				builder.AppendFormat(",{0:F1}", cwpVal);

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//acquisition cost	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.AcquisitionCost);
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//current value	//XXXX
				}
				else
				{
					//mam 112806 - check NA
					if (discipline.ConditionRanking == CondRank.No || useNA == true)
					{
						//mam 112806 - commented
						//builder.AppendFormat(",N/A");

						//mam 112806
						if ((component.MechStructDisciplines && discipline.OverrideCurrentValue) 
							|| (discipline.Type == DisciplineType.Pipes && pipeOverrideAnyCurrentValue)
							|| (discipline.Type == DisciplineType.Nodes && nodeOverrideAnyCurrentValue))
						{
							builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
						}
						else
						{
							builder.AppendFormat(",N/A");
						}
					}
					else
					{
						builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
					}
				}

				//mam 112806
				if (component.MechStructDisciplines)
				{
					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//override current value OROR	//XXXX
					}
					else
					{
						builder.AppendFormat(",{0}", Convert.ToBoolean(discipline.OverrideCurrentValue));
					}
				}
				else
				{
					builder.AppendFormat(",N/A");
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//escalated acquisition cost	//XXXX
					builder.Append(",0");	//replacement value	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", discipline.AcquisitionCostEscalated);

					builder.AppendFormat(",{0:F0}", discipline.ReplacementValue);
				}

				//mam 01222012
				if (component.MechStructDisciplines)
				{
					//mam 01222012
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//replacement value source/description	//XXXX
					}
					else
					{
						builder.AppendFormat(",{0:F0}", discipline.ReplacementValueDesc);
					}
				}
				else
				{
					builder.Append(",N/A");	//replacement value desc
				}

				//mam 112806
				builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);

				//mam 01222012
				PlanningMode planningMode = PlanningMode.Rehabilitation;
				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					planningMode = PlanningMode.Replacement;
				}

				//mam 07072011
				if (component.MechStructDisciplines)
				{
					//**********************************************

					//mam 01222012 - if condition is N/A and next replacement year is not overridden, time to next replacement and next replacement year are N/A
					//unless planning mode is rehab, in which case values will be zero
					if (discipline.ConditionRanking == CondRank.No)
					{
						if (planningMode == PlanningMode.Replacement)
						{
							if (discipline.OverrideNextReplacementYear)
							{
								builder.AppendFormat(",{0:F1}", discipline.ReplacementNext);
								builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);
							}
							else
							{
								builder.AppendFormat(",{0}", "N/A");	//time to next replacement 
								builder.AppendFormat(",{0}", "N/A");	//next replacement year
							}
						}
						else
						{
							//replacement values are set to zero in the display
							builder.AppendFormat(",{0}", 0);	//time to next replacement 
							builder.AppendFormat(",{0}", 0);	//next replacement year
						}
					}
					else
					{
						if (planningMode == PlanningMode.Replacement)
						{
							builder.AppendFormat(",{0:F1}", discipline.ReplacementNext);
							builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);
						}
						else
						{
							//replacement values are set to zero in the display
							builder.AppendFormat(",{0}", 0);	//time to next replacement 
							builder.AppendFormat(",{0}", 0);	//next replacement year
						}
					}

					//**********************************************

					//mam 01222012 - format override
					//builder.AppendFormat(",{0:F0}", discipline.OverrideNextReplacementYear);
					builder.AppendFormat(",{0}", Convert.ToBoolean(discipline.OverrideNextReplacementYear));
				}
				else
				{
					//mam 01222012
					builder.Append(",N/A");	//time to next replacement

					builder.Append(",N/A");	//next replacement year
					builder.Append(",N/A");	//override next replacement year
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//rehabilitation cost	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", discipline.RehabCost);
				}

				//mam 07072011
				if (component.MechStructDisciplines)
				{
					//mam 01222012
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//rehab cost source/description	//XXXX
					}
					else
					{
						builder.AppendFormat(",{0:F)}", discipline.RehabCostDesc);
					}

					builder.AppendFormat(",{0:F0}", discipline.RehabCostYear);
					builder.AppendFormat(",{0:F1}", discipline.RehabInterval);
					builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);

					//************************************************

					//mam 01222012 - if condition is N/A and next replacement year is not overridden, 
					//	time to next rehab and next rehab year are N/A

					if (discipline.ConditionRanking == CondRank.No)
					{
						if (planningMode == PlanningMode.Replacement)
						{
							//rehab values are set to zero in the display
							builder.AppendFormat(",{0}", 0);	//time to next rehab year
							builder.AppendFormat(",{0}", 0);	//next rehab year
						}
						else
						{
							if (discipline.OverrideRehabYearNext)
							{
								builder.AppendFormat(",{0:F1}", discipline.RehabNext);
								builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);
							}
							else
							{
								builder.AppendFormat(",{0}", "N/A");	//time to next rehab year
								builder.AppendFormat(",{0}", "N/A");	//next rehab year
							}
						}
					}
					else
					{
						if (planningMode == PlanningMode.Replacement)
						{
							//rehab values are set to zero in the display
							builder.AppendFormat(",{0}", 0);	//time to next rehab year
							builder.AppendFormat(",{0}", 0);	//next rehab year
						}
						else
						{
							builder.AppendFormat(",{0:F1}", discipline.RehabNext);
							builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);
						}
					}

					//************************************************

					//mam 01222012
					builder.AppendFormat(",{0}", Convert.ToBoolean(discipline.OverrideRehabYearNext));
				}
				else
				{
					//mam 01222012
					builder.Append(",N/A");	//rehab cost desc

					builder.Append(",N/A");	//rehab cost year
					builder.Append(",N/A");	//rehab interval
					builder.Append(",N/A");	//rehab year last
					builder.Append(",N/A");	//rehab next

					//mam 01222012 - no longer allowing overriding of time to next rehab
					//builder.Append(",N/A");	//override rehab next

					builder.Append(",N/A");	//rehab year next

					//mam 01222012
					builder.Append(",N/A");	//override rehab year next
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//book value	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.GetBookValue());
				}

				builder.AppendFormat(",{0:F0}", discipline.SalvageValue);

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//annual depreciation	//XXXX
					builder.Append(",0");	//cumulative depreciation	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.GetAnnualDepreciation());
					builder.AppendFormat(",{0:F0}", discipline.GetCumulativeDepreciation());
				}

				if (discipline.ConditionRanking == CondRank.No || useNA == true)
				{
					//EV, RC, AMC, Condition

					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//evaluated value	//XXXX
						builder.Append(",0");	//repair cost	//XXXX
					}
					else
					{
						builder.AppendFormat(",N/A");	//evaluated value

						//mam 112806 - commented
						//builder.AppendFormat(",N/A");

						//mam 112806
						if ((MechStructDisciplines && discipline.OverrideRepairCost) 
							|| (discipline.Type == DisciplineType.Pipes && pipeOverrideAnyRepairCost)
							|| (discipline.Type == DisciplineType.Nodes && nodeOverrideAnyRepairCost))
						{
							builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
						}
						else
						{
							builder.AppendFormat(",N/A");
						}
					}

					//mam 112806
					if (component.MechStructDisciplines)
					{
						//mam 01042012 - if component is retired, show zero on report
						if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
						{
							builder.Append(",0");	//override repair cost OROR	//XXXX
						}
						else
						{
							builder.AppendFormat(",{0}", Convert.ToBoolean(discipline.OverrideRepairCost));
						}
					}
					else
					{
						builder.AppendFormat(",N/A");
					}

					builder.AppendFormat(",{0:F0}", discipline.AnnualMaintCost);

					//mam 112806
					if (component.MechStructDisciplines)
					{
						builder.AppendFormat(",{0:F0}", discipline.InstallationYear);	//discipline installation year
						builder.AppendFormat(",{0:F0}", discipline.GetOriginalENR(discipline.InstallationYear));	//discipline installation year enr (original enr)
					}
					else
					{
						if (discipline.Type == DisciplineType.Pipes)
						{
							pipe = disciplines[pos] as DisciplinePipe;
							builder.AppendFormat(",{0:F0}", pipe.InstallationYear);	//discipline installation year
							builder.AppendFormat(",{0:F0}", pipe.GetOriginalENR(pipe.InstallationYear));	//discipline installation year enr (original enr)
						}
						else
						{
							node = disciplines[pos] as DisciplineNode;
							builder.AppendFormat(",{0:F0}", node.InstallationYear);	//discipline installation year
							builder.AppendFormat(",{0:F0}", node.GetOriginalENR(node.InstallationYear));	//discipline installation year enr (original enr)
						}
					}

					builder.AppendFormat(",N/A");	//condition

					//OUL, RUL
					if (!component.MechStructDisciplines)
					{
						if (discipline.GetCurrentValue() == 0)
						{
							builder.AppendFormat(",N/A");
							builder.AppendFormat(",N/A");
						}
						else
						{
							builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
							builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
						}
					}
					else
					{
						builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
						builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
					}
					//</mam>

					//EvRUL, EcRUL
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else	//else if condition not na
				{
					//EV, RC, AMC

					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//evaluated value	//XXXX
						builder.Append(",0");	//repair cost	//XXXX
					}
					else
					{
						builder.AppendFormat(",{0:F0}", discipline.GetEvaluatedValue());
						builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
					}

					//mam 112806
					if (component.MechStructDisciplines)
					{
						//mam 01042012 - if component is retired, show zero on report
						if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
						{
							builder.Append(",0");	//override repair cost OROR	//XXXX
						}
						else
						{
							builder.AppendFormat(",{0}", Convert.ToBoolean(discipline.OverrideRepairCost));
						}
					}
					else
					{
						builder.AppendFormat(",N/A");
					}

					builder.AppendFormat(",{0:F0}", discipline.AnnualMaintCost);

					//Condition
					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;

						//mam 112806
						builder.AppendFormat(",{0:F0}", pipe.InstallationYear);	//discipline installation year
						builder.AppendFormat(",{0:F0}", pipe.GetOriginalENR(pipe.InstallationYear));	//discipline installation year enr (original enr)

						if (pipe.GetCurrentValue() == 0)
						{
							builder.AppendFormat(",N/A");
						}
						else
						{
							builder.AppendFormat(",{0:F1}", pipe.GetAverageCondition());
						}
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						//mam 112806
						builder.AppendFormat(",{0:F0}", node.InstallationYear);	//discipline installation year
						builder.AppendFormat(",{0:F0}", node.GetOriginalENR(node.InstallationYear));	//discipline installation year enr (original enr)

						if (node.GetCurrentValue() == 0)
						{
							builder.AppendFormat(",N/A");
						}
						else
						{
							builder.AppendFormat(",{0:F1}", node.GetAverageCondition());
						}
					}
					else
					{
						//mam 112806
						builder.AppendFormat(",{0:F0}", discipline.InstallationYear);	//discipline installation year
						builder.AppendFormat(",{0:F0}", discipline.GetOriginalENR(discipline.InstallationYear));	//discipline installation year enr (original enr)

						builder.AppendFormat(",{0}", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
					}

					//OUL, RUL
					//if (discipline.GetCurrentValue() == 0)
					if (!component.MechStructDisciplines && discipline.GetCurrentValue() == 0)
					{
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
						builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
						builder.AppendFormat(",{0:F1}", discipline.GetEvaluatedRemainingUsefulLife());
						builder.AppendFormat(",{0:F1}", discipline.GetEconomicUsefulLife());
					}
				}

				//*************************************************

				//include LOS, Redundant Asset Count, Criticality, Vulnerability and Risk in the report for pipes and nodes

				//mam 090105 - show N/A for MechStruct Components and Disciplines
				if (component.MechStructDisciplines)
				{
					//LOS
					//mam 07072011 - put component los here instead of N/A
					//builder.AppendFormat(",N/A");
					builder.AppendFormat(",{0:F1}", component.GetLOS());

					//mam 050806 - Redundant Asset Count
					builder.AppendFormat(",N/A");

					//mam 07072011 - use correct number of crit placeholders
					//mam 07072011 - use crit values instead of placeholders
					////builder.AppendFormat(",N/A");
					////builder.AppendFormat(",N/A");
					////builder.AppendFormat(",N/A");
					////builder.AppendFormat(",N/A");
					//for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
					//{
					//	builder.AppendFormat(",N/A");
					//}
					foreach (MajorComponentSelectedCriticalityFactors critFactor in component.componentSelectedCritFactorCollection)
					{
						string critNumberText = "Crit" + critFactor.CriticalityNumber.ToString();
						builder.AppendFormat("," + (char)34 + "{0}" + (char)34, critFactor.CritFactor.FactorName);
					}
					
					//overall crit
					//mam 07072011 - use overall crit value instead of placeholder
					//builder.AppendFormat(",N/A");

					builder.AppendFormat(",{0:F1}", component.GetOverallCriticality());

					//mam 07072011 - use values instead of placeholders for vuln and risk
					//vuln
					//builder.AppendFormat(",N/A");

					//vuln override
					//builder.AppendFormat(",N/A");

					//risk
					//builder.AppendFormat(",N/A");

					//Vuln, Override Vuln, Risk
					if (component.GetEvaluatedRemainingUsefulLife() == 0 && !component.OverrideVulnerability)
					{
						builder.AppendFormat(",N/A");	//vuln
						builder.AppendFormat(",N/A");	//vuln override
						builder.AppendFormat(",N/A");	//risk
					}
					else
					{
						builder.AppendFormat(",{0:F4}", component.GetVulnerability());
						builder.AppendFormat(",N/A");	//vuln override
						builder.AppendFormat(",{0:F2}", component.GetRisk());
					}

					//mam 07072011 - cip mode, asset class
					//mam 07072011 - use values for cip mode and asset class instead of placeholders
					//builder.AppendFormat(",N/A");
					//builder.AppendFormat(",N/A");
					string cipPlanningMode = component.CipPlanningId == 0 ? "N/A" : GetCipModeTextFromId(arrayListCip, component.CipPlanningId);
					builder.AppendFormat(",{0}", cipPlanningMode);
					builder.AppendFormat(",{0}", component.AssetClass);

					//mam 011206
					//builder.Append("," + (char)34 + "Discipline comments should be here" + (char)34);

					//mam 011206
					if (discipline.Type == DisciplineType.Land)
					{
						DisciplineLand disciplineTemp = discipline as DisciplineLand;

						//mam 101107 - replace double quote in comments with two double quotes 
						string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@disciplineTemp.Comments);
						//builder.Append("," + (char)34 + disciplineTemp.Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);

						//mam 112806
						builder.Append("," + (char)34 + disciplineTemp.DateInspected.ToString("MM/dd/yyyy") + (char)34);

						//mam 101107
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.EquipmentNumber) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.Manufacturer) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.AssessedBy) + (char)34);

						builder.AppendFormat(",N/A");	//RunHours
						builder.AppendFormat(",N/A");	//RunningAtInspect

						//mam 112806
						//mechanical
						builder.Append(",N/A");	//MechExcessiveVibration
						builder.Append(",N/A");	//MechExcessiveNoise
						builder.Append(",N/A");	//MechExcessiveCorrosion
						builder.Append(",N/A");	//MechExcessiveLeaks
						builder.Append(",N/A");	//MechRunningHot
						builder.Append(",N/A");	//MechCanRunWhenInspected
						builder.Append(",N/A");	//MechSupportIsFunctional
						builder.Append(",N/A");	//MechPartsMissing
						builder.Append(",N/A");	//MechPartsAvailable
						builder.Append(",N/A");	//MechAdequate
						builder.Append(",N/A");	//MechMotorAmps
						builder.Append(",N/A");	//InstrIndicationFunctional
						builder.Append(",N/A");	//InstrAlarmFunctional
						builder.Append(",N/A");	//InstrPartsMissing
						builder.Append(",N/A");	//InstrPartsAvailable
						builder.Append(",N/A");	//ElecExcessiveCorrosion
						builder.Append(",N/A");	//ElecCleanContacts
						builder.Append(",N/A");	//ElecPartsAvailable
						builder.Append(",N/A");	//PipeExcessiveCorrosion
						builder.Append(",N/A");	//PipeExcessiveLeaks
						builder.Append(",N/A");	//PipePaintGood

						//structural
						builder.Append(",N/A");	//ConcreteSpalling
						builder.Append(",N/A");	//StructExcessiveCorrosion
						builder.Append(",N/A");	//MembExcessiveCorrosion
						builder.Append(",N/A");	//CorrosionCoating
						builder.Append(",N/A");	//PaintGood
						builder.Append(",N/A");	//VisibleDeformities
						builder.Append(",N/A");	//SettingEvident
						builder.Append(",N/A");	//MajorCracks

						//civil
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).SeveralPotholes) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).ExcessiveErosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).RoadDegradation) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).ExpansionSpace) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FunctionCover) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FencingAdequate) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FacilitiesSecure) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppClayLiner) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermErosionInterior) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermErosionBermExterior) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermVegetation) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermSettlement) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermSeepage) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBurrowHoles) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppErosionProtectionPresent) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppErosionProtectionAdequate) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppAlgalBlooms) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppDrainageAdequate) + (char)34);

						//mam 03202012
						string caption = ((DisciplineLand)discipline).CaptionPhoto1;
						caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
						builder.AppendFormat(",{0}", ((DisciplineLand)discipline).PhotoFileName);
						builder.AppendFormat(",{0}", caption);
					}
					else if (discipline.Type == DisciplineType.Mechanical)
					{
						DisciplineMech disciplineTemp = discipline as DisciplineMech;

						//mam 101107 - replace double quote in comments with two double quotes 
						string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@disciplineTemp.Comments);
						//builder.Append("," + (char)34 + disciplineTemp.Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);

						//mam 112806
						builder.Append("," + (char)34 + disciplineTemp.DateInspected.ToString("MM/dd/yyyy") + (char)34);

						//mam 101107
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.EquipmentNumber) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.Manufacturer) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.AssessedBy) + (char)34);

						builder.Append("," + (char)34 + disciplineTemp.RunHours + (char)34);
						builder.Append("," + (char)34 + disciplineTemp.RunningAtInspect + (char)34);

						//mam 112806
						//mechanical
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveVibration) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveNoise) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveCorrosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveLeaks) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechRunningHot) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechCanRunWhenInspected) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechSupportIsFunctional) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechPartsMissing) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechPartsAvailable) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechAdequate) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechMotorAmps) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrIndicationFunctional) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrAlarmFunctional) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrPartsMissing) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrPartsAvailable) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecExcessiveCorrosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecCleanContacts) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecPartsAvailable) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipeExcessiveCorrosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipeExcessiveLeaks) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipePaintGood) + (char)34);

						//structural
						builder.Append(",N/A");	//ConcreteSpalling
						builder.Append(",N/A");	//StructExcessiveCorrosion
						builder.Append(",N/A");	//MembExcessiveCorrosion
						builder.Append(",N/A");	//CorrosionCoating
						builder.Append(",N/A");	//PaintGood
						builder.Append(",N/A");	//VisibleDeformities
						builder.Append(",N/A");	//SettingEvident
						builder.Append(",N/A");	//MajorCracks

						//civil
						builder.Append(",N/A");	//SeveralPotholes
						builder.Append(",N/A");	//ExcessiveErosion
						builder.Append(",N/A");	//RoadDegradation
						builder.Append(",N/A");	//ExpansionSpace
						builder.Append(",N/A");	//FunctionCover
						builder.Append(",N/A");	//FencingAdequate
						builder.Append(",N/A");	//FacilitiesSecure
						builder.Append(",N/A");	//LandAppClayLiner
						builder.Append(",N/A");	//LandAppBermErosionInterior
						builder.Append(",N/A");	//LandAppBermErosionBermExterior
						builder.Append(",N/A");	//LandAppBermVegetation
						builder.Append(",N/A");	//LandAppBermSettlement
						builder.Append(",N/A");	//LandAppBermSeepage
						builder.Append(",N/A");	//LandAppBurrowHoles
						builder.Append(",N/A");	//LandAppErosionProtectionPresent
						builder.Append(",N/A");	//LandAppErosionProtectionAdequate
						builder.Append(",N/A");	//LandAppAlgalBlooms
						builder.Append(",N/A");	//LandAppDrainageAdequate

						//mam 03202012
						string caption = ((DisciplineMech)discipline).CaptionPhoto;
						caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
						builder.AppendFormat(",{0}", ((DisciplineMech)discipline).PhotoFileName);
						builder.AppendFormat(",{0}", caption);
					}
					else if (discipline.Type == DisciplineType.Structural)
					{
						DisciplineStruct disciplineTemp = discipline as DisciplineStruct;

						//mam 101107 - replace double quote in comments with two double quotes 
						string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@disciplineTemp.Comments);
						//builder.Append("," + (char)34 + disciplineTemp.Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);

						//mam 112806
						builder.Append("," + (char)34 + disciplineTemp.DateInspected.ToString("MM/dd/yyyy") + (char)34);

						//mam 101107
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.EquipmentNumber) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.Manufacturer) + (char)34);
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(disciplineTemp.AssessedBy) + (char)34);

						builder.AppendFormat(",N/A");	//RunHours
						builder.AppendFormat(",N/A");	//RunningAtInspect

						//mam 112806
						//mechanical
						builder.Append(",N/A");	//MechExcessiveVibration
						builder.Append(",N/A");	//MechExcessiveNoise
						builder.Append(",N/A");	//MechExcessiveCorrosion
						builder.Append(",N/A");	//MechExcessiveLeaks
						builder.Append(",N/A");	//MechRunningHot
						builder.Append(",N/A");	//MechCanRunWhenInspected
						builder.Append(",N/A");	//MechSupportIsFunctional
						builder.Append(",N/A");	//MechPartsMissing
						builder.Append(",N/A");	//MechPartsAvailable
						builder.Append(",N/A");	//MechAdequate
						builder.Append(",N/A");	//MechMotorAmps
						builder.Append(",N/A");	//InstrIndicationFunctional
						builder.Append(",N/A");	//InstrAlarmFunctional
						builder.Append(",N/A");	//InstrPartsMissing
						builder.Append(",N/A");	//InstrPartsAvailable
						builder.Append(",N/A");	//ElecExcessiveCorrosion
						builder.Append(",N/A");	//ElecCleanContacts
						builder.Append(",N/A");	//ElecPartsAvailable
						builder.Append(",N/A");	//PipeExcessiveCorrosion
						builder.Append(",N/A");	//PipeExcessiveLeaks
						builder.Append(",N/A");	//PipePaintGood

						//structural
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).ConcreteSpalling) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).StructExcessiveCorrosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).MembExcessiveCorrosion) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).CorrosionCoating) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).PaintGood) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).VisibleDeformities) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).SettingEvident) + (char)34);
						builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).MajorCracks) + (char)34);

						//civil
						builder.Append(",N/A");	//SeveralPotholes
						builder.Append(",N/A");	//ExcessiveErosion
						builder.Append(",N/A");	//RoadDegradation
						builder.Append(",N/A");	//ExpansionSpace
						builder.Append(",N/A");	//FunctionCover
						builder.Append(",N/A");	//FencingAdequate
						builder.Append(",N/A");	//FacilitiesSecure
						builder.Append(",N/A");	//LandAppClayLiner
						builder.Append(",N/A");	//LandAppBermErosionInterior
						builder.Append(",N/A");	//LandAppBermErosionBermExterior
						builder.Append(",N/A");	//LandAppBermVegetation
						builder.Append(",N/A");	//LandAppBermSettlement
						builder.Append(",N/A");	//LandAppBermSeepage
						builder.Append(",N/A");	//LandAppBurrowHoles
						builder.Append(",N/A");	//LandAppErosionProtectionPresent
						builder.Append(",N/A");	//LandAppErosionProtectionAdequate
						builder.Append(",N/A");	//LandAppAlgalBlooms
						builder.Append(",N/A");	//LandAppDrainageAdequate

						//mam 03202012
						string caption = ((DisciplineStruct)discipline).CaptionPhoto;
						caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
						builder.AppendFormat(",{0}", ((DisciplineStruct)discipline).PhotoFileName);
						builder.AppendFormat(",{0}", caption);
					}
				}
				else
				{
					pipe = discipline as DisciplinePipe;
					node = discipline as DisciplineNode;

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = disciplines[pos] as DisciplinePipe;
					
						if (pipe.GetCurrentValue() == 0)
						{
							//LOS
							builder.AppendFormat(",N/A");

							//mam 050806 - Redundant Asset Count
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");

							//mam 07072011 - use correct number of crit placeholders
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
							{
								builder.AppendFormat(",N/A");
							}

							//overall crit
							builder.AppendFormat(",N/A");
						}
						else
						{
							//LOS, Redundant Asset Count, four Crit values, Crit
							builder.AppendFormat(",{0:F1}", pipe.GetAverageLOS());

							//mam 050806 - Redundant Asset Count
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");

							//mam 07072011 - use correct number of crit placeholders
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
							{
								builder.AppendFormat(",N/A");
							}

							builder.AppendFormat(",{0:F1}", pipe.GetAverageCriticality());
						}

						if (pipe.GetCurrentValue() == 0 || pipesERULVulnNA)
						{
							//Vuln, Override Vuln, Risk
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A for Override Vuln
							//builder.AppendFormat(",");
							builder.AppendFormat(",N/A");

							//risk
							builder.AppendFormat(",N/A");

							//mam 07072011 - cip mode, asset class
							builder.AppendFormat(",N/A");
							builder.AppendFormat(",N/A");
						}
						else
						{
							//Vuln, Override Vuln, Risk
							//mam 090105 - round vuln to 4 decimals rather than 2
							//builder.AppendFormat(",{0:F2}", pipe.GetAverageVulnerability());
							builder.AppendFormat(",{0:F4}", pipe.GetAverageVulnerability());
							
							//mam 090105 - changed to N/A for Override Vuln
							//builder.AppendFormat(",");
							builder.AppendFormat(",N/A");

							//risk
							builder.AppendFormat(",{0:F2}", pipe.GetAverageRisk());

							//mam 07072011 - cip mode, asset class
							builder.AppendFormat(",N/A");
							builder.AppendFormat(",N/A");
						}

						//mam 101107 - replace double quote in comments with two double quotes 
						string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@pipe.Comments);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);
						////mam 011206
						//builder.Append("," + (char)34 + pipe.Comments + (char)34);

						//mam 112806
						builder.Append("," + (char)34 + pipe.DateInspected.ToString("MM/dd/yyyy") + (char)34);	//Date of Inspection
						builder.Append(",N/A");	//Equipment/ID Number
						builder.Append(",N/A");	//Manufacturer

						//mam 101107
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.AssessedBy) + (char)34);	//Assessed By

						builder.Append(",N/A");	//Run Hours
						builder.Append(",N/A");	//Running at Inspection

						//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");

						//mam 03202012 - pipes don't have photos, so don't include photo and caption
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = disciplines[pos] as DisciplineNode;

						if (node.GetCurrentValue() == 0)
						{
							//LOS, Redundant Asset Count, four Crit values, Crit
							builder.AppendFormat(",N/A");

							//mam 050806 - Redundant Asset Count
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");

							//mam 07072011 - use correct number of crit placeholders
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
							{
								builder.AppendFormat(",N/A");
							}

							//overall crit
							builder.AppendFormat(",N/A");
						}
						else
						{
							//LOS, Redundant Asset Count, four Crit values, Crit
							builder.AppendFormat(",{0:F1}", node.GetAverageLOS());

							//mam 050806 - Redundant Asset Count
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");
							//builder.AppendFormat(",");

							//mam 07072011 - use correct number of crit placeholders
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							//builder.AppendFormat(",N/A");
							for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
							{
								builder.AppendFormat(",N/A");
							}

							builder.AppendFormat(",{0:F1}", node.GetAverageCriticality());
						}

						if (node.GetCurrentValue() == 0 || nodesERULVulnNA)
						{
							//Vuln, Override Vuln, Risk
							builder.AppendFormat(",N/A");

							//mam 090105 - changed to N/A for Override Vuln
							//builder.AppendFormat(",");
							builder.AppendFormat(",N/A");

							//risk
							builder.AppendFormat(",N/A");

							//mam 07072011 - cip mode, asset class
							builder.AppendFormat(",N/A");
							builder.AppendFormat(",N/A");
						}
						else
						{
							//Vuln, Override Vuln, Risk
							//mam 090105 - round vuln to 4 decimals rather than 2
							//builder.AppendFormat(",{0:F2}", node.GetAverageVulnerability());
							builder.AppendFormat(",{0:F4}", node.GetAverageVulnerability());

							//mam 090105 - changed to N/A for Override Vuln
							//builder.AppendFormat(",");
							builder.AppendFormat(",N/A");
							
							//risk
							builder.AppendFormat(",{0:F2}", node.GetAverageRisk());

							//mam 07072011 - cip mode, asset class
							builder.AppendFormat(",N/A");
							builder.AppendFormat(",N/A");
						}

						//mam 101107 - replace double quote in comments with two double quotes 
						string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@node.Comments);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);
						////mam 011206
						//builder.Append("," + (char)34 + node.Comments + (char)34);

						//mam 112806
						builder.Append("," + (char)34 + node.DateInspected.ToString("MM/dd/yyyy") + (char)34);	//Date of Inspection
						builder.Append(",N/A");	//Equipment/ID Number
						builder.Append(",N/A");	//Manufacturer

						//mam 101107
						builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.AssessedBy) + (char)34);	//Assessed By

						builder.Append(",N/A");	//Run Hours
						builder.Append(",N/A");	//Running at Inspection

						//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");

						//mam 03202012 - nodes don't have photos, so don't include photo and caption

					}	//is pipe or node
				}	//MSC vs. PN
			}	//loop through disciplines

			return builder.ToString();
		}
		//</mam>

		//mam 07072011
		public string GetCipModeTextFromId(ArrayList arrayListCip, int cipId)
		{
			if (cipId == 0)
			{
				return "";
			}

			for (int i = 0; i < arrayListCip.Count; i++)
			{
				Common.CommonTasks.Cip cip = (Common.CommonTasks.Cip)arrayListCip[i];
				if (cip.CipPlanningId == cipId)
				{
					return cip.CipPlanningText;
				}
			}

			return "";
		}

		//mam 112806
		private void ResetOverrideVariables()
		{
			mscOverrideAnyCurrentValue = false;
			mscOverrideAnyRepairCost = false;
			pipeOverrideAnyCurrentValue = false;
			pipeOverrideAnyRepairCost = false;
			nodeOverrideAnyCurrentValue = false;
			nodeOverrideAnyRepairCost = false;
		}

		//mam - add routine to check whether Condition for all pipes is N/A
		//mam 07072011 - changed to public
		//private bool GetAllConditionNAPipes(int curInfosetID, int curDisciplineID)
		public bool GetAllConditionNAPipes(int curInfosetID, int curDisciplineID)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(curInfosetID, curDisciplineID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether Condition for all nodes is N/A
		//mam 07072011 - changed to public
		//private bool GetAllConditionNANodes(int curInfosetID, int curDisciplineID)
		public bool GetAllConditionNANodes(int curInfosetID, int curDisciplineID)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(curInfosetID, curDisciplineID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		public void			CopyTo(MajorComponent copy)
		{
			//copy.m_processID = 0; // Don't copy ProcessID
			copy.m_name = m_name;
			copy.m_CWPValue = m_CWPValue;
			copy.m_captionPhoto = m_captionPhoto;

			//mam 03202012
			copy.m_photoFileName = m_photoFileName;

			//mam 102309
			//copy.m_photo = m_photo;

			copy.m_comments = m_comments;
			copy.m_sortOrder = m_sortOrder;
			copy.m_LOS = m_LOS;

			//mam 07072011 - using new storage method for criticality values
			//copy.m_critPublic = m_critPublic;
			//copy.m_critEnvironmental = m_critEnvironmental;
			//copy.m_critRepair = m_critRepair;
			//copy.m_critCustEffect = m_critCustEffect;
			copy.ComponentSelectedCriticalityFactorsCollection = ComponentSelectedCriticalityFactorsCollection;

			copy.m_vulnerability = m_vulnerability;

			//mam
			copy.m_overrideVulnerability = m_overrideVulnerability;
			//</mam>

			copy.m_mechStructDisc = m_mechStructDisc;
			copy.m_retired = m_retired;

			//mam 050806
			copy.m_redundantAssetCount = m_redundantAssetCount;

			//mam 07072011
			copy.m_assetClass = m_assetClass;
			copy.m_cipPlanningId = m_cipPlanningId;
		}

		//mam - allow or disallow copying of photo
		public void CopyTo(MajorComponent copy, bool copyPhoto)
		{
			//copy.m_processID = 0; // Don't copy ProcessID
			copy.m_name = m_name;
			copy.m_CWPValue = m_CWPValue;

			if (copyPhoto)
			{
				copy.m_captionPhoto = m_captionPhoto;

				//mam 03202012
				copy.m_photoFileName = m_photoFileName;

				//mam 102309
				//copy.m_photo = m_photo;
			}

			copy.m_comments = m_comments;
			copy.m_sortOrder = m_sortOrder;
			copy.m_LOS = m_LOS;

			//mam 07072011 - using new storage method for criticality values
			//copy.m_critPublic = m_critPublic;
			//copy.m_critEnvironmental = m_critEnvironmental;
			//copy.m_critRepair = m_critRepair;
			//copy.m_critCustEffect = m_critCustEffect;

			copy.ComponentSelectedCriticalityFactorsCollection = ComponentSelectedCriticalityFactorsCollection;

			copy.m_vulnerability = m_vulnerability;

			//mam
			copy.m_overrideVulnerability = m_overrideVulnerability;
			//</mam>

			copy.m_mechStructDisc = m_mechStructDisc;
			copy.m_retired = m_retired;

			//mam 050806
			copy.m_redundantAssetCount = m_redundantAssetCount;

			//mam 07072011
			copy.m_assetClass = m_assetClass;
			copy.m_cipPlanningId = m_cipPlanningId;
		}
		//</mam>

		//mam - allow new component name
		public void CopyTo(MajorComponent copy, string newComponentName, bool copyPhoto)
		{
			CopyTo(copy, copyPhoto);
			copy.m_name = newComponentName;
			//copy.m_CWPValue = 0;
			//mam 112806 - setting m_sortOrder here is overriding the value that was copied into it above
			//copy.m_sortOrder = 65000;

			//if (copy.m_sortOrder != 65000)
			//	copy.m_sortOrder = m_sortOrder + 1;
		}
		//</mam>

		//mam 101107 - replace double quote in comments with two double quotes 
		private string ReplaceDoubleQuoteWithTwoDoubleQuotes(string stringToChange)
		{
			stringToChange = stringToChange.Replace("\"", "\"\"");
			return stringToChange;
		}

		//mam 01222012
		public static void UpdateOverriddenYearsByComponent(int componentId)
		{
			//update all RehabYearNext or NextReplacementYear values that are overridden and less than currentYear
			//	for the specified component

			try
			{
				WAM.Common.DataAccess dataAccess = new DataAccess();
				dataAccess.ExecuteCommandSP("UpdateRehabReplacementYearsByComponent", "@componentId", componentId);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309 - leave as if for importing from Access databases
		public static MajorComponent[] LoadAllOleDb(int processID)
		{
			MajorComponent[]components = LoadAllOleDb(WamSourceOleDb.CurrentSource.ConnectionString, processID);
			//MajorComponent[]components = LoadAll(Globals.WamSqlConnectionString, processID);

			return components;
		}

		//mam 102309 - leave as if for importing from Access databases
		public static MajorComponent[] LoadAllOleDb(string connectionString, int processID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			MajorComponent[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAllOleDb(sqlConnection, processID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309 - leave as if for importing from Access databases
		public static MajorComponent[] LoadAllOleDb(OleDbConnection sqlConnection, int processID)
			//public static MajorComponent[] LoadAll(SqlConnection sqlConnection, int processID)
		{
			// open the database to retrieve info

			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			MajorComponent	newObject;
			MajorComponent[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("component_id, process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService,");

			//mam 11142011 - we need these when importing data from an Access database
			//mam 07072011 - using new storage method for criticality values
			builder.Append("component_critPublicHealth, component_critEnvironmental,");
			builder.Append("component_critRepairCost, component_critCustomerEffect,");

			//mam - use probability
			builder.Append("component_vulnerability, component_MechStructDisc, ");
			//</mam>

			builder.Append("component_retired, ");
			builder.Append("component_captionPhoto, component_comments, ");
			builder.Append("component_sortOrder ");

			//mam 050806
			builder.Append(", RedundantAssetCount ");

			//mam 07072011 - put these here only to be consistent - since the Access database has not been updated
			//	to include these fields, don't try to get these values from an Access database
			//builder.Append(", AssetClass");
			//builder.Append(", CipPlanningId ");

			builder.Append("FROM MajorComponents ");
			builder.AppendFormat("WHERE (process_id={0}) ", processID);
			builder.Append("ORDER BY component_sortOrder Asc, component_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				//				while (dataReader.Read())
				//				{
				//					for (int i = 0; i < dataReader.FieldCount; i++)
				//					{
				//						string test = dataReader[i].ToString();
				//						test = dataReader[i].ToString();
				//					}
				//				}

				while (dataReader.Read())
				{
					try
					{
						//mam 102309
						//newObject = new MajorComponent(dataReader);
						newObject = new MajorComponent(0);
						newObject.LoadRecordData(dataReader);

						if (newObject.ID != 0)
						{
							arrayList.Add(newObject);
						}
					}
					catch (Exception ex)
					{
						System.Diagnostics.Debug.Assert(false, ex.Message);
					}

				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("MajorComponent.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new MajorComponent[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static MajorComponent[] LoadAll(int processID)
		{
			//mam 102309
			//MajorComponent[]components = LoadAll(WAMSource.CurrentSource.ConnectionString, processID);
			MajorComponent[]components = LoadAll(Globals.WamSqlConnectionString, processID);

			return components;
		}

		public static MajorComponent[] LoadAll(string connectionString, int processID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			MajorComponent[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAll(sqlConnection, processID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static MajorComponent[] LoadAll(OleDbConnection sqlConnection, int processID)
		public static MajorComponent[] LoadAll(SqlConnection sqlConnection, int processID)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			MajorComponent	newObject;
			MajorComponent[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("component_id, process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService,");

			//mam 07072011 - using new storage method for criticality values
			//builder.Append("component_critPublicHealth, component_critEnvironmental,");
			//builder.Append("component_critRepairCost, component_critCustomerEffect,");

			//mam - use probability
			builder.Append("component_vulnerability, component_MechStructDisc, ");
			//</mam>

			builder.Append("component_retired, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("component_captionPhoto, PhotoFileName, component_comments, ");

			builder.Append("component_sortOrder ");

			//mam 050806
			builder.Append(", RedundantAssetCount");

			//mam 07072011
			builder.Append(", AssetClass");
			builder.Append(", CipPlanningId ");

			builder.Append("FROM MajorComponents ");
			builder.AppendFormat("WHERE (process_id={0}) ", processID);
			builder.Append("ORDER BY component_sortOrder Asc, component_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			//mam 07072011
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				//				while (dataReader.Read())
				//				{
				//					for (int i = 0; i < dataReader.FieldCount; i++)
				//					{
				//						string test = dataReader[i].ToString();
				//						test = dataReader[i].ToString();
				//					}
				//				}

				//mam 07072011 - get criticality values for all major components

				while (dataReader.Read())
				{
					try
					{
						//newObject = new MajorComponent(dataReader);
						newObject = new MajorComponent(dataReader, dataAccess);
						if (newObject.ID != 0)
						{
							//mam 07072011 - get criticalities for this major component
							System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityByComponent", "@componentId", newObject.ID);
							newObject.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesIntoCollection(dataTable);

							arrayList.Add(newObject);
						}
					}
					catch (Exception ex)
					{
						System.Diagnostics.Debug.Assert(false, ex.Message);
					}

				}
			}
				//mam 102309
				//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("MajorComponent.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				//string msg = "An error occurred while loading Major Component data." + Environment.NewLine + Environment.NewLine;
				//WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.LoadAll", "An error has occurred: " + msg + ex.Message);
				throw ex;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				string msg = "An error occurred while loading Major Component data." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.LoadAll", "An error has occurred: " + msg + ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				//mam 07072011
				dataAccess = null;
			}
			
			typedArray = new MajorComponent[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}
		
		//mam 03202012 - new method to get all components for an infoset
		//@@@@
		public static MajorComponent[] LoadAllForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			// open the database to retrieve info

			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			MajorComponent	newObject;
			MajorComponent[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("C.component_id, C.process_id, C.component_name, ");
			builder.Append("C.component_CWPValue, C.component_LevelOfService,");
			builder.Append("C.component_vulnerability, C.component_MechStructDisc, ");
			builder.Append("C.component_retired, ");
			builder.Append("C.component_captionPhoto, C.PhotoFileName, C.component_comments, ");
			builder.Append("C.component_sortOrder ");
			builder.Append(", C.RedundantAssetCount");
			builder.Append(", C.AssetClass");
			builder.Append(", C.CipPlanningId ");

			//builder.Append("FROM MajorComponents ");
			//builder.AppendFormat("WHERE (process_id={0}) ", processID);
			//builder.Append("ORDER BY component_sortOrder Asc, component_id Asc");

			builder.Append(" FROM MajorComponents C LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");

			//builder.Append("SELECT C.*");
			//builder.Append(" FROM MajorComponents C LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			//builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			//builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			//builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			//get the active crits for all components
			//don't use existing stored procedure because it will return crits for all infosets when passing in 0 for @componentId
			//System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityByComponent", "@componentId", 0);

			//let's just create the query here
			StringBuilder builderCrits = new StringBuilder();
			builderCrits.Append("SELECT M.component_id, MC.component_name, M.CriticalityId, C.Criticality, C.CriticalityWeight, C.Active");
			builderCrits.Append(", S.CriticalityScore, CS.CriticalityToScoreId, M.CriticalityScoreId, CS.CriticalityFactor");
			builderCrits.Append(", C.OrderBy AS CriticalityOrderBy, S.OrderBy AS FactorOrderBy");
			builderCrits.Append(" FROM MajorComponentToCriticality M");
			builderCrits.Append(" INNER JOIN MajorComponents MC ON M.component_id = MC.component_id");
			builderCrits.Append(" INNER JOIN CriticalityScore S ON M.CriticalityScoreId = S.CriticalityScoreId");
			builderCrits.Append(" INNER JOIN Criticality C ON M.CriticalityId = C.CriticalityId");
			builderCrits.Append(" INNER JOIN CriticalityToScore CS ON M.CriticalityScoreId = CS.CriticalityScoreId AND M.CriticalityId = CS.CriticalityId");
			builderCrits.Append(" LEFT JOIN TreatmentProcesses P ON MC.process_id = P.process_id");
			builderCrits.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builderCrits.AppendFormat(" WHERE C.Active = 'true' AND F.infoset_id = {0}", infosetId);
			builderCrits.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id");
			builderCrits.Append(", MC.component_sortOrder, MC.component_id, C.OrderBy, S.OrderBy");

			try
			{
				System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTable(builderCrits.ToString());

				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					try
					{
						newObject = new MajorComponent(dataReader, dataAccess);
						if (newObject.ID != 0)
						{
							//search a table of crits for all components rather than getting getting a table from the database for each component
							//using DataRowCollection.Find would be the fastest method, but we need multiple rows, so use DataTable.Select
							DataRow[] rows = dataTableCritsAll.Select("component_id = " + newObject.ID);
							newObject.ComponentSelectedCriticalityFactorsCollection = Common.CommonTasks.LoadCriticalitiesIntoCollection(rows);

							arrayList.Add(newObject);
						}
					}
					catch (Exception ex)
					{
						System.Diagnostics.Debug.Assert(false, ex.Message);
					}

				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("MajorComponent.LoadAll Error: {0}\n", ex.Message));
				throw ex;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
				string msg = "An error occurred while loading Major Component data." + Environment.NewLine + Environment.NewLine;
				WAM.Common.CommonTasks.ShowErrorMessage("MajorComponent.LoadAll", "An error has occurred: " + msg + ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				dataAccess = null;
			}
			
			typedArray = new MajorComponent[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		//public static MajorComponent[] LoadForComponentName(string componentName, int processID, OleDbConnection sqlConnection)
		public static MajorComponent[] LoadForComponentName(string componentName, int processID, SqlConnection sqlConnection)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			MajorComponent	newObject;
			MajorComponent[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("component_id, process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService,");

			//mam 07072011 - using new storage method for criticality values
			//builder.Append("component_critPublicHealth, component_critEnvironmental,");
			//builder.Append("component_critRepairCost, component_critCustomerEffect,");

			builder.Append("component_vulnerability, component_MechStructDisc, ");
			builder.Append("component_retired, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("component_captionPhoto, PhotoFileName, component_comments, ");

			builder.Append("component_sortOrder ");

			//mam 050806
			builder.Append(", RedundantAssetCount");

			//mam 07072011
			builder.Append(", AssetClass");
			builder.Append(", CipPlanningId ");

			builder.Append("FROM MajorComponents ");
			builder.Append("WHERE (");
			builder.AppendFormat("process_id={0} AND ", processID);
			builder.AppendFormat("component_name='{0}') ", Drive.SQL.PadString(componentName));
			builder.Append("ORDER BY component_sortOrder Asc, component_id Asc");

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new MajorComponent(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
				//mam 102309
				//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("MajorComponent.LoadForComponentName Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new MajorComponent[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		public static MajorComponent LoadOne(SqlConnection sqlConnection, int majorComponentId)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			MajorComponent	newObject = null;
			//MajorComponent[] typedArray;
			//ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("component_id, process_id, component_name, ");
			builder.Append("component_CWPValue, component_LevelOfService,");

			//mam 07072011 - using new storage method for criticality values
			//builder.Append("component_critPublicHealth, component_critEnvironmental,");
			//builder.Append("component_critRepairCost, component_critCustomerEffect,");

			//mam - use probability
			builder.Append("component_vulnerability, component_MechStructDisc, ");
			//</mam>

			builder.Append("component_retired, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("component_captionPhoto, PhotoFileName, component_comments, ");

			builder.Append("component_sortOrder ");

			//mam 050806
			builder.Append(", RedundantAssetCount");

			//mam 07072011
			builder.Append(", AssetClass");
			builder.Append(", CipPlanningId ");

			builder.Append("FROM MajorComponents ");
			builder.AppendFormat("WHERE (component_id={0}) ", majorComponentId);
			builder.Append("ORDER BY component_sortOrder Asc, component_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				//				while (dataReader.Read())
				//				{
				//					for (int i = 0; i < dataReader.FieldCount; i++)
				//					{
				//						string test = dataReader[i].ToString();
				//						test = dataReader[i].ToString();
				//					}
				//				}

				while (dataReader.Read())
				{
					try
					{
						newObject = new MajorComponent(dataReader);
						//if (newObject.ID != 0)
						//	arrayList.Add(newObject);
					}
					catch (Exception ex)
					{
						System.Diagnostics.Debug.Assert(false, ex.Message);
					}

				}
			}
				//mam 102309
				//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("MajorComponent.LoadOne Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(ex.Message);
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			//typedArray = new MajorComponent[arrayList.Count];
			//arrayList.CopyTo(typedArray);
			//return typedArray;

			return newObject;
		}

		public static string GetTypeString()
		{
			return "MajorComponent";
		}

		#endregion /***** Static Methods *****/
 
	}

	#region /***** Cache Class *****/
	public class			MajorComponentCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable();

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//	m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.MajorComponent));
		private int			m_infoSetID = 0;

		public				MajorComponentCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			//mam 102309
			//m_changeDelegate = 
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged);
			m_changeDelegate = 
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged);

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(m_changeDelegate);
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(m_changeDelegate);
		}

		#region IDisposable Members
		~MajorComponentCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
			Dispose(true);
			// This object will be cleaned up by the Dispose method.
			// Therefore, you should call GC.SupressFinalize to
			// take this object off the finalization queue 
			// and prevent finalization code for this object
			// from executing a second time.
			GC.SuppressFinalize(this);
		}

		private void Dispose(bool disposing)
		{
			// If disposing equals true, dispose all managed 
			// and unmanaged resources.
			if (disposing)
			{
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
			}
		}
		#endregion

		public int			InfoSetID
		{
			get { return m_infoSetID; }
		}

		//mam 102309
		//private void DataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			MajorComponent obj = e.ChangedObject as MajorComponent;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.ProcessID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.ProcessID, obj);
			}
		}

		public MajorComponent[] GetForProcess(int id)
		{
			MajorComponent[] children = (MajorComponent[])m_treeHash.GetChildren(id);

			if (children == null)
			{
				System.Diagnostics.Trace.WriteLine("Generating MajorComponent cache");
				children = MajorComponent.LoadAll(id);
				m_treeHash.SetChildren(id, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					// Set info set for cache matching purposes
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}

			return children;
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public MajorComponent[] GetForProcessForReport(int id)
		{
			MajorComponent[] children = (MajorComponent[])m_treeHash.GetChildren(id);

			//mam 06212012 - don't go to the database
			//if (children == null)
			//{
			//	System.Diagnostics.Trace.WriteLine("Generating MajorComponent cache");
			//	children = MajorComponent.LoadAll(id);
			//	m_treeHash.SetChildren(id, children);
			//	for (int pos = 0; pos < children.Length; pos++)
			//	{
			//		// Set info set for cache matching purposes
			//		children[pos].InfoSetID = m_infoSetID;
			//		m_hash[children[pos].GetHashCode()] = children[pos];
			//	}
			//}

			return children;
		}

		public void			SortForProcess(int id)
		{
			m_treeHash.Sort(id);
		}

		//mam 102309 - added this method, but commented it because it is not necessary
		//		public MajorComponent AddMajorComponentToCache(int processId, int majorComponentId)
		//		{
		//			SqlConnection sqlConnection = new SqlConnection(WAM.Common.Globals.WamSqlConnectionString);
		//
		//			try
		//			{
		//				sqlConnection.Open();
		//				MajorComponent child = MajorComponent.LoadOne(sqlConnection, majorComponentId);
		//				m_treeHash.AddChild(processId, child);
		//				child.InfoSetID = m_infoSetID;
		//				m_hash[child.GetHashCode()] = child;
		//				return child;
		//			}
		//			finally
		//			{
		//				if (sqlConnection != null)
		//					sqlConnection.Dispose();
		//			}
		//		}

		//mam 102309
		//public MajorComponent[] BuildCacheForProcess(OleDbConnection connection, int id)
		public MajorComponent[] BuildCacheForProcess(SqlConnection connection, int id)
		{
			MajorComponent[] children = MajorComponent.LoadAll(connection, id);

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				// Set info set for cache matching purposes
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		//mam 03202012 - new method to get all components for an infoset at once
		//@@@@
		public MajorComponent[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			MajorComponent[] children = MajorComponent.LoadAllForInfoset(connection, infosetId);

			foreach (MajorComponent component in children)
			{
				m_treeHash.AddChild(component.ProcessID, component);

				component.InfoSetID = m_infoSetID;
				m_hash[component.GetHashCode()] = component;
			}

			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		public MajorComponent GetMajorComponent(int id)
		{
			// Look up the components in the hash table
			MajorComponent component = m_hash[id.GetHashCode()] as MajorComponent;

			// If the component is not present, load it from the default database
			if (component == null)
			{
				component = new MajorComponent(id);
				component.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (component.ID != 0)
				{
					m_hash[component.GetHashCode()] = component;
				}
				else
				{
					component = null;
				}
			}

			return component;
		}
	}
	#endregion /***** Cache Class *****/
}