using System;
using System.Configuration;
using System.Data;

//mam 102309
//using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for ENR20Cities.
	/// </summary>

	//mam 102309
	//public class ENR20Cities : Drive.Data.OleDb.Jet40DALInt32Key, IComparable
	public class ENR20Cities : Drive.Data.SqlClient.SqlDALInt32Key, IComparable
	{
		#region /***** Member Variables *****/
		private	int			m_year = 0;
		private int			m_enrValue = 0;
		private bool		m_isNew = true;
		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		//mam 102309
		//public				ENR20Cities(int id)
		//	: base(WAMSource.ENRSource.ConnectionString, id)
		public				ENR20Cities(int id)
			: base(Globals.WamSqlConnectionString, id)
		{
		}

		public				ENR20Cities(string connectionString, int id)
			: base(connectionString, id)
		{
		}

		//mam 102309
		//protected			ENR20Cities(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.ENRSource.ConnectionString, reader)
		protected			ENR20Cities(SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
			{
		}
		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			m_year = reader.GetInt32(col++);
			m_enrValue = reader.GetInt32(col++);
			m_isNew = false;
		}

		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT enr_year, enr_value ");
			builder.Append("FROM ENR20Cities ");
			builder.AppendFormat("WHERE enr_year={0}", m_year);

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			
			StringBuilder	builder = new StringBuilder(250);

			builder.Remove(0, builder.Length);
			builder.Append("INSERT INTO ENR20Cities ");
			builder.Append("( enr_year, enr_value ) ");
			builder.Append(" VALUES (");
			builder.AppendFormat("{0}, ", m_year);
			builder.AppendFormat("{0} ", m_enrValue);
			builder.Append("); ");

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(150);

			builder.Append("UPDATE ENR20Cities SET ");
			builder.AppendFormat("enr_value={0} ", m_enrValue);
			builder.AppendFormat("WHERE (enr_year={0}); ", m_year);

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE FROM ENR20Cities WHERE enr_year={0}", m_year);
		}

		public override bool Valid
		{
			get
			{
				return !m_isNew;
			}
		}

		//mam 102309
		//public override bool Save(System.Data.OleDb.OleDbConnection oleDbConnection)
		public override bool Save(SqlConnection sqlConnection)
		{
			//mam 102309
			//OleDbCommand	sqlCommand = null;
			//OleDbDataReader	dataReader = null;
			SqlCommand		sqlCommand = null;
			SqlDataReader	dataReader = null;

			string			saveSqlString;
			bool			isNew = m_isNew;

			if (isNew)
				saveSqlString = GetInsertSql();
			else
				saveSqlString = GetUpdateSql();

			if (saveSqlString.Length == 0)
				return false;

			try
			{
				//mam 102309
				//sqlCommand = new OleDbCommand(saveSqlString, oleDbConnection);
				sqlCommand = new SqlCommand(saveSqlString, sqlConnection);

				sqlCommand.ExecuteNonQuery();
				m_id = 1;
				m_isNew = false;
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Debug.WriteLine(saveSqlString);
				System.Diagnostics.Trace.WriteLine(
					String.Format("{0}.Save Error: {1}\n", 
					this.ToString(), ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				//return false;
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (Valid)
			{
				Drive.Synchronization.SyncAction action;

				if (isNew)
					action = Drive.Synchronization.SyncAction.Add;
				else
					action = Drive.Synchronization.SyncAction.Edit;

				InvokeChangeEvent(this, new DataChangeEventArgs(this, action));
			}
			return Valid;
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public int			Year
		{
			get { return m_year; }
			set { m_year = value; }
		}

		public int			ENRValue
		{
			get { return m_enrValue; }
			set { m_enrValue = value; }
		}
		#endregion /***** Properties *****/

		#region /***** Static Methods *****/
		public static ENR20Cities[] LoadAll()
		{
			//mam 102309
			//return LoadAll(WAMSource.ENRSource.ConnectionString);
			return LoadAll(Common.Globals.WamSqlConnectionString);
		}

		public static ENR20Cities[] LoadAll(string connectionString)
		{
			//mam 102309 - no need to do this
//			//mam - check for the existence of the database
//			string dbPath = string.Format(@"{0}\20CitiesENR.mdb", Drive.IO.Directory.GetApplicationPath());
//			if (!System.IO.File.Exists(dbPath))
//				System.Windows.Forms.MessageBox.Show("The ENR database file (20CitiesENR.mdb) cannot be found.  All ENR values will be set to zero.", "Cannot Find Database",
//					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
//			//</mam>

			// open the database to retrieve info

			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			ENR20Cities		newObject;
			ENR20Cities[]	typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT enr_year, enr_value FROM ENR20Cities ");
			builder.Append("ORDER BY enr_year ASC ");

			try
			{
				sqlConnection.Open();

				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new ENR20Cities(dataReader);
					arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("ENR20Cities.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				sqlConnection.Dispose();
			}
			
			typedArray = new ENR20Cities[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}
		#endregion /***** Static Methods *****/

		#region IComparable Members
		public int CompareTo(object obj)
		{
			if (obj is ENR20Cities)
			{
				ENR20Cities comp = (ENR20Cities)obj;

				return Drive.Math.Compare(m_year, comp.m_year);
			}

			throw new ArgumentException("Not an ENR20Cities object!");
		}
		#endregion
	}

	public class ENR20CitiesCache
	{
		private static Hashtable ms_enrData;

		static ENR20CitiesCache()
		{
			ENR20Cities[]	enrData = ENR20Cities.LoadAll();

			// build a list of the 20 cities
			ms_enrData = new Hashtable(Drive.Math.FindHighestPrime(enrData.Length * 2), 1.0f);
			for (int pos = 0; pos < enrData.Length; pos++)
			{
				ms_enrData[enrData[pos].Year.GetHashCode()] = enrData[pos];
			}
		}

		public static int	GetENRValueForYear(int year)
		{
			ENR20Cities		enr = (ENR20Cities)ms_enrData[year.GetHashCode()];

			if (enr != null)
				return enr.ENRValue;
			
			return 0;
		}

		public static void	SetENRValueForYear(int year, int enrValue)
		{
			ENR20Cities		enr = (ENR20Cities)ms_enrData[year.GetHashCode()];

			if (enr != null)
			{
				enr.ENRValue = enrValue;
				enr.Save();
			}
			else
			{
				enr = new ENR20Cities(0);
				enr.Year = year;
				enr.ENRValue = enrValue;
				enr.Save();

				ms_enrData[year.GetHashCode()] = enr;
			}
		}

		public static bool	HasENRValueForYear(int year)
		{
			ENR20Cities		enr = (ENR20Cities)ms_enrData[year.GetHashCode()];

			return (enr != null);
		}

		public static void	DeleteENRValueForYear(int year)
		{
			ENR20Cities		enr = (ENR20Cities)ms_enrData[year.GetHashCode()];

			if (enr != null)
			{
				ms_enrData.Remove(year.GetHashCode());
				enr.Delete();
			}
		}

		public static ENR20Cities GetENRRecordForYear(int year)
		{
			ENR20Cities		enr = (ENR20Cities)ms_enrData[year.GetHashCode()];

			return enr;
		}

		public static ENR20Cities[] GetAllENRValues()
		{
			ICollection		items = ms_enrData.Values;
			ENR20Cities[]	enrItems = new ENR20Cities[items.Count];

			items.CopyTo(enrItems, 0);
			Array.Sort(enrItems);

			return enrItems;
		}
	}
}