using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave for importing treatment processes
using System.Data.OleDb;

using System.Text;
using System.Collections;
using System.Drawing;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for TreatmentProcess.
	/// </summary>

	//mam 102309
	//public class TreatmentProcess : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable, IGraphableUnit
	public class TreatmentProcess : Drive.Data.SqlClient.SqlDALInt32Key, IComparable, IFilterable, IGraphableUnit
	{
		#region /***** Member Variables *****/
		private int			m_facilityID = 0;
		private string		m_name = "";
		private double		m_CWPValue = 0.0;
		private decimal		m_orgCost = 0;
		private string		m_captionPhoto = "";
		private string		m_comments = "";
		private int			m_sortOrder = 65000;
		private bool		m_isFunded = false;
		private double		m_pctFunded = 0.0;
		private decimal		m_orgCostOrgVal = 0;
		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		//mam 102309
		//private string m_photo = "";

		//private int m_processId = 0;

		//mam 112806
		private bool mscOverrideAnyCurrentValue = false;
		private bool mscOverrideAnyRepairCost = false;
		private bool pipeOverrideAnyCurrentValue = false;
		private bool pipeOverrideAnyRepairCost = false;
		private bool nodeOverrideAnyCurrentValue = false;
		private bool nodeOverrideAnyRepairCost = false;

		//mam
		decimal adjustedTotal = 0;
		bool isNA = false;
		//</mam>

		//mam 090105
		private string facilityName = string.Empty;
		//private int facilityID = 0;
		//</mam>

		//mam 050806
		private int treeNodeIndex = 0;

		//mam 03202012
		private string m_photoFileName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public TreatmentProcess(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public TreatmentProcess(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public TreatmentProcess(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//protected TreatmentProcess(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected TreatmentProcess(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
		{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_facilityID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_CWPValue = reader.GetDouble(col++);
			m_orgCost = reader.GetDecimal(col++);
			m_captionPhoto = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_isFunded = reader.GetBoolean(col++);
			m_pctFunded = Drive.SQL.ReadNullableDouble(reader, col++);
			m_orgCostOrgVal = reader.GetDecimal(col++);
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(System.Data.SqlClient.SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_facilityID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_CWPValue = reader.GetDouble(col++);
			m_orgCost = reader.GetDecimal(col++);

			//mam 102309
			//m_captionPhoto = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			//m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_captionPhoto = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 03202012
			m_photoFileName = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 102309
			//m_photo = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_sortOrder = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			m_isFunded = reader.GetBoolean(col++);

			//mam 102309
			//m_pctFunded = Drive.SQL.ReadNullableDouble(reader, col++);
			m_pctFunded = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			m_orgCostOrgVal = reader.GetDecimal(col++);
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			TreatmentProcess comp = obj as TreatmentProcess;

			if (comp != null)
			{
				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);

				if (compare == 0)
					compare = Drive.Math.Compare(this.ID, comp.ID);

				return compare;
			}
			else
				throw new InvalidCastException("Not a treatment process");
		}

		//mam - compare Processes by their various values
		public int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)
		{
			TreatmentProcess rhs = obj as TreatmentProcess;
			int result = 0;

			this.isNA = this.CheckIfAllNADisciplineForProcess(this.InfoSetID, this.ID);
			rhs.isNA = rhs.CheckIfAllNADisciplineForProcess(rhs.InfoSetID, rhs.ID);

			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a treatment process");

			return result;
		}
		//</mam>

		//mam - compare each Treatment Process as necessary
		private int CompareToEach(TreatmentProcess rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;

			switch (which)
			{
				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
				//mam

				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.GetAcquisitionCost().CompareTo(rhs.GetAcquisitionCost());
					else
						result = rhs.GetAcquisitionCost().CompareTo(this.GetAcquisitionCost());

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.GetAcquisitionCostEscalated().CompareTo(rhs.GetAcquisitionCostEscalated());
					else
						result = rhs.GetAcquisitionCostEscalated().CompareTo(this.GetAcquisitionCostEscalated());

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.GetRehabCost().CompareTo(rhs.GetRehabCost());
					else
						result = rhs.GetRehabCost().CompareTo(this.GetRehabCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.GetReplacementValue().CompareTo(rhs.GetReplacementValue());
					else
						result = rhs.GetReplacementValue().CompareTo(this.GetReplacementValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.GetSalvageValue().CompareTo(rhs.GetSalvageValue());
					else
						result = rhs.GetSalvageValue().CompareTo(this.GetSalvageValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					//mam - use new method that will return -1 for N/A value
//					if (lowToHigh)
//						result = this.GetEvaluatedValue().CompareTo(rhs.GetEvaluatedValue());
//					else
//						result = rhs.GetEvaluatedValue().CompareTo(this.GetEvaluatedValue());
					if (lowToHigh)
						result = this.SortGetEvaluatedValue().CompareTo(rhs.SortGetEvaluatedValue());
					else
						result = rhs.SortGetEvaluatedValue().CompareTo(this.SortGetEvaluatedValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					//mam - use new method that will return -1 for N/A value
//					if (lowToHigh)
//						result = this.GetRepairCost().CompareTo(rhs.GetRepairCost());
//					else
//						result = rhs.GetRepairCost().CompareTo(this.GetRepairCost());
					if (lowToHigh)
						result = this.SortGetRepairCost().CompareTo(rhs.SortGetRepairCost());
					else
						result = rhs.SortGetRepairCost().CompareTo(this.SortGetRepairCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.GetAnnualMaintenanceCost().CompareTo(rhs.GetAnnualMaintenanceCost());
					else
						result = rhs.GetAnnualMaintenanceCost().CompareTo(this.GetAnnualMaintenanceCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
					//mam - use new method that will return a rounded value
//					if (lowToHigh)
//						result = this.GetOrgUsefulLife().CompareTo(rhs.GetOrgUsefulLife());
//					else
//						result = rhs.GetOrgUsefulLife().CompareTo(this.GetOrgUsefulLife());
					if (lowToHigh)
						result = this.SortGetOrgUsefulLife().CompareTo(rhs.SortGetOrgUsefulLife());
					else
						result = rhs.SortGetOrgUsefulLife().CompareTo(this.SortGetOrgUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
					//mam - use new method that will return a rounded value
//					if (lowToHigh)
//						result = this.GetRemainingUsefulLife().CompareTo(rhs.GetRemainingUsefulLife());
//					else
//						result = rhs.GetRemainingUsefulLife().CompareTo(this.GetRemainingUsefulLife());
					if (lowToHigh)
						result = this.SortGetRemainingUsefulLife().CompareTo(rhs.SortGetRemainingUsefulLife());
					else
						result = rhs.SortGetRemainingUsefulLife().CompareTo(this.SortGetRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
					//mam - use new method that will return a rounded value
//					if (lowToHigh)
//						result = this.GetEvaluatedRemainingUsefulLife().CompareTo(rhs.GetEvaluatedRemainingUsefulLife());
//					else
//						result = rhs.GetEvaluatedRemainingUsefulLife().CompareTo(this.GetEvaluatedRemainingUsefulLife());
					if (lowToHigh)
						result = this.SortGetEvaluatedRemainingUsefulLife().CompareTo(rhs.SortGetEvaluatedRemainingUsefulLife());
					else
						result = rhs.SortGetEvaluatedRemainingUsefulLife().CompareTo(this.SortGetEvaluatedRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
					if (lowToHigh)
						result = this.SortGetEconomicUsefulLife().CompareTo(rhs.SortGetEconomicUsefulLife());
					else
						result = rhs.SortGetEconomicUsefulLife().CompareTo(this.SortGetEconomicUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					//mam - use new method that will return a rounded value
//					if (lowToHigh)
//						result = this.GetRankPercent().CompareTo(rhs.GetRankPercent());
//					else
//						result = rhs.GetRankPercent().CompareTo(this.GetRankPercent());
					if (lowToHigh)
						result = this.SortGetRankPercent().CompareTo(rhs.SortGetRankPercent());
					else
						result = rhs.SortGetRankPercent().CompareTo(this.SortGetRankPercent());

					break;

//					case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
//						result = this.().CompareTo(rhs.GetBookValue());
//
//					case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
//					case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
				case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
					//mam - use new method that will return a rounded value
//					if (lowToHigh)
//						result = this.GetTotalProcRisk().CompareTo(rhs.GetTotalProcRisk());
//					else
//						result = rhs.GetTotalProcRisk().CompareTo(this.GetTotalProcRisk());
					if (lowToHigh)
						result = this.SortGetTotalProcRisk().CompareTo(rhs.SortGetTotalProcRisk());
					else
						result = rhs.SortGetTotalProcRisk().CompareTo(this.SortGetTotalProcRisk());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;
			}
			return result;
		}

		//</mam>
		#endregion /***** IComparable Members *****/

		#region /***** Nested Class TreatmentProcessComparer *****/
		//mam
		public class TreatmentProcessComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				TreatmentProcess l = (TreatmentProcess) lhs;
				TreatmentProcess r = (TreatmentProcess) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}

			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class TreatmentProcessComparer *****/

		#region /***** IFilterable Members *****/

		//mam 07072011
		public string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			//switch (source)
			//{
			//	case WAM.Logic.UnitFilter.FilterSource.AssetClass:
			//	{
			//		return AssetClass;
			//		break;
			//	}
			//}

			return "";
		}

		//mam 07072011
		public bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			return true;
		}

		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterSource.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterSource.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterSource.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterSource.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterSource.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterSource.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterSource.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

				//mam
				case WAM.Logic.UnitFilter.FilterSource.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
				//</mam>
				
				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterSource.RehabCost:
					return GetRehabCost();

				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					break;
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					return false;
			}

			return true;
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

				//mam
				case WAM.Logic.UnitFilter.FilterCompareTo.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
				//</mam>

				//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabCost:
					return GetRehabCost();

				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					break;
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					return false;
				default:
					break;
			}

			return true;
		}
		#endregion /***** IFilterable Members *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT ");
			builder.Append("process_id, facility_id, process_name, process_CWPTPValue, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("process_orgCost, process_captionPhoto, PhotoFileName, process_comments, ");

			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append("FROM TreatmentProcesses ");
			builder.AppendFormat("WHERE process_id={0}", id);

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		public string GetInsertSqlForCopy()
		{
			return GetInsertSql();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - added bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
				//string msg = "Error in " + this.Name + ".Save:" + Environment.NewLine + Environment.NewLine + ex.Message;
				//throw new Exception(msg);
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO TreatmentProcesses (");

			builder.Append("facility_id, process_name, process_CWPTPValue, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("process_orgCost, process_captionPhoto, PhotoFileName, process_comments, ");

			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_facilityID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0:F6}, ", m_CWPValue);
			builder.AppendFormat("{0:F2}, ", m_orgCost);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionPhoto));

			//mam 03202012
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			//mam 102309
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photo));

			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0}, ", m_sortOrder);
			builder.AppendFormat("{0}, ", Drive.SQL.BoolToBit(m_isFunded));
			builder.AppendFormat("{0:F6}, ", m_pctFunded);
			builder.AppendFormat("{0:F2} ", m_orgCostOrgVal);

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE TreatmentProcesses SET ");

			builder.AppendFormat("facility_id={0}, ", m_facilityID);
			builder.AppendFormat("process_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("process_CWPTPValue={0:F6}, ", m_CWPValue);
			builder.AppendFormat("process_orgCost={0:F2}, ", m_orgCost);
			builder.AppendFormat("process_captionPhoto={0}, ", Drive.SQL.StringToDBString(m_captionPhoto));

			//mam 03202012
			builder.AppendFormat("PhotoFileName={0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			builder.AppendFormat("process_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("process_sortOrder={0}, ", m_sortOrder);
			builder.AppendFormat("process_isFunded={0}, ", Drive.SQL.BoolToBit(m_isFunded));
			builder.AppendFormat("process_pctFunded={0:F6}, ", m_pctFunded);
			builder.AppendFormat("process_orgCostOrgVal={0:F2} ", m_orgCostOrgVal);
			builder.AppendFormat("WHERE (process_id={0}) ", ID);

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From TreatmentProcesses WHERE process_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Methods *****/

		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete()
		{
			this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
			using (SqlConnection connection = new SqlConnection(this.m_sqlConnectionString))
			{
				connection.Open();
				return this.Delete(connection);
			}
		}
		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete(SqlConnection sqlConnection)
		{
			//return base.Delete (sqlConnection);

			string deleteSql = this.GetDeleteSql();
			if (deleteSql.Length == 0)
			{
				return false;
			}
			try
			{
				new SqlCommand(deleteSql, sqlConnection).ExecuteNonQuery();
			}
			catch (SqlException exception)
			{
				throw exception;
			}
			InvokeChangeEvent(this, new DataChangeEventArgs(this, Drive.Synchronization.SyncAction.Delete));
			return true;
		}

		//mam
		public static TreatmentProcessComparer GetComparer()
		{
			return new TreatmentProcess.TreatmentProcessComparer();
		}
		//</mam>

		public bool			SaveAsXML(string filePath)
		{
			System.IO.FileStream file = null;
			System.IO.StreamWriter writer = null;

			try
			{
				file = new System.IO.FileStream(filePath, 
					System.IO.FileMode.Create, System.IO.FileAccess.Write);

				writer = new System.IO.StreamWriter(file);

				//mam - added parameters - always get photos when displaying data in the application
				//	and pass in an empty string for the selectedFilters, which only apply to reports
				writer.Write(GetXML(true, ""));
				//</mam>

				writer.Flush();
				writer.Close();
				writer = null;
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}
			return true;
		}

		public Facility		GetFacility()
		{
			return CacheManager.GetFacility(m_infoSetID, m_facilityID);
		}

		public string		GetFullName()
		{
			Facility		facility = GetFacility();

			//mam 090105
			facilityName = facility.Name;
			//</mam>

			return string.Format("{0} / {1}", facility.GetFullName(), Name);
		}

		public string		GetShortName()
		{
			return Name;
		}

		//mam
		public string GetFullNameWithInfoset()
		{
			return string.Format("{0} / {1}", CacheManager.GetInfosetNameForInfoSetID(this.InfoSetID), GetFullName());
		}
		//</mam>

		//mam 090105
		public int GetFacilityID()
		{
			return m_facilityID;
		}

		public string GetParentName()
		{
			//get the Facility name

			//just go ahead and call GetFacility to make sure that all of the data is refreshed
			//if (facilityName.Length == 0)
			{
				Facility facility = GetFacility();
			}

			return facilityName;
		}
		//</mam>

		//mam 050806
		public int GetParentID()
		{
			return GetFacilityID();
		}

		//mam 050806
		public int GetGrandparentID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public int GetInfosetID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public object GetUnitType()
		{
			return WAM.UI.NodeType.TreatmentProcess;
		}

		//mam - need a way to get pipes only or nodes only for graphing
		public decimal GetYAxisValue(GraphYAxis yAxis, bool pipesOnly, bool nodesOnly)
		{
			//there is no Condition, LOS, Vulnerability, Criticality, or Risk for Treatment Process
			return 0m;
		}
		//</mam>

		public decimal		GetYAxisValue(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return GetAcquisitionCost();
				case GraphYAxis.CurrentValue:
					return GetCurrentValue();
				case GraphYAxis.ReplacementValue:
					return GetReplacementValue();
				case GraphYAxis.BookValue:
					return GetBookValue();
				case GraphYAxis.SalvageValue:
					return GetSalvageValue();
				case GraphYAxis.AnnualDepreciation:
					return GetAnnualDepreciation();
				case GraphYAxis.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case GraphYAxis.EvaluatedValue:
					return GetEvaluatedValue();
				case GraphYAxis.RepairCost:
					return GetRepairCost();
				case GraphYAxis.AnnualMaintenanceCost:
					return GetAnnualMaintenanceCost();

				//mam 190105
//				case GraphYAxis.OriginalUsefulLife:
//					return (decimal)GetOrgUsefulLife();
//				case GraphYAxis.RemainingUsefulLife:
//					return (decimal)GetRemainingUsefulLife();
//				case GraphYAxis.EvaluatedRemainingUsefulLife:
//					return (decimal)GetEvaluatedRemainingUsefulLife();
//				case GraphYAxis.EconomicRemainingUsefulLife:
//					return (decimal)GetEconomicUsefulLife();

				//mam 050806
				case GraphYAxis.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case GraphYAxis.RehabCost:
					return GetRehabCost();
			}

			return 0m;
		}

		public int			GetYearValue()
		{
			// Return the year
			return GetFacility().CurrentYear;
		}

		//mam 050806
		public int GetInspectionYear()
		{
			return GetFacility().CurrentYear;
		}

		//mam - new method
		public int GetItemID()
		{
			//return the ID
			return ID;
		}
		//</mam>

		//mam - added parameter
		public string		GetXML(bool includePhotos, string selectedFilters)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam

			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();
			Facility		facility = CacheManager.GetFacility(m_infoSetID, m_facilityID);

			//mam 112806 - must check N/A for each facility or each process, as required
			//bool useNA = CheckIfAllNADiscipline();
			bool useNA = false;

			builder.Append("<ProcessData>\r\n");

			//mam 112806
			bool totalsOverrideCurrentValue = false;
			bool totalsOverrideRepairCost = false;

			// Populate the basic facility data
			builder.Append("\t<TreatmentProcess>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
			builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", facility.CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", facility.CurrentENR);

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			//mam - add Treatment Process totals
//			WAM.Logic.MajorComponentTotals componentTotals = GetComponentTotals();
//
//			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", componentTotals.GetTotalAcquisitionCost());
//			builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", componentTotals.GetTotalCurrentValue());
//			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", componentTotals.GetTotalReplacementValue());
//			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", componentTotals.GetTotalBookValue());
//			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", componentTotals.GetTotalSalvageValue());
//			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", componentTotals.GetTotalAnnualDepreciation());
//			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", componentTotals.GetTotalCumulativeDepreciation());
//
//			if (useNA)
//			{
//				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
//				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
//				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", componentTotals.GetTotalAnnualMaintenanceCost());
//				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
//			}
//			else
//			{
//				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", componentTotals.GetTotalEvaluatedValue().ToString("#,##0"));
//				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", componentTotals.GetTotalRepairCost().ToString("#,##0"));
//				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", componentTotals.GetTotalAnnualMaintenanceCost());
//				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", componentTotals.GetRankPercent());
//			}
//
//			builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", componentTotals.GetTotalOrgUsefulLife());
//			builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", componentTotals.GetTotalRemainingUsefulLife());
//
//			if (useNA)
//				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
//			else
//				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", componentTotals.GetTotalEvaluatedRemainingUsefulLife());
//
//			builder.AppendFormat("\t\t\t<Risk><![CDATA[{0:F2}]]></Risk>\r\n", componentTotals.GetTotalRisk());
			//</mam>

			//mam
			if (includePhotos)
			{
			//</mam>
				//mam 03202012 - changed GetImagePath to PhotoFileName (don't include path in photo file name because it is a 
				//	mapped path on the user's machine that will be different for all users)
				//builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePath());
				builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", PhotoFileName);

				builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto);
			}

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);
			builder.Append("\t</TreatmentProcess>\r\n");

			// Populate the major component data
			WAM.Logic.MajorComponentTotals componentTotals = GetComponentTotals();
			MajorComponent[] components = 
				CacheManager.GetComponents(m_infoSetID, ID);
			int				pos;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalValue = componentTotals.GetTotalCurrentValue();
			decimal			totalValue = componentTotals.GetTotalAcquisitionCost();
			decimal			totalValueRounded = componentTotals.GetTotalAcquisitionCostRoundIndividualValues();

			MajorComponent	component;
			double			cwpVal = 0.0;

			//mam
			adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(m_infoSetID, ID, totalValueRounded, WAM.UI.NodeType.TreatmentProcess);

			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}
			//</mam>

			builder.Append("\t<Components>\r\n");
			for (pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				//mam
				if (component.Retired)
					continue;

				//moved down
				//useNA = CheckIfAllNADisciplineForComponent(component.InfoSetID, component.ID);
				//</mam>

				builder.Append("\t\t<Component>\r\n");
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", component.Name);

				//mam 112806
				builder.AppendFormat("\t\t\t<GridRetired><![CDATA[{0}]]></GridRetired>\r\n", 
					component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(component.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(component.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}
				//</mam>

				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);

				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(component.GetAcquisitionCost(), roundDigit));

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(component.GetCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(component.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(component.GetReplacementValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", component.GetReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(component.GetRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(component.GetBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(component.GetSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(component.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(component.GetCumulativeDepreciation(), roundDigit));

				//mam 112806
				useNA = CheckIfAllNADisciplineForComponent(component.InfoSetID, component.ID);
				CheckIfComponentOverridden(component.InfoSetID, component.ID, true);

				//mam - added check for all Condition = N/A
				if (useNA)
				{
					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						//if any component has an overridden current value, set totalsOverrideCurrentValue to true;
						//	the value won't be reset to false until the next time this routine is called
						totalsOverrideCurrentValue = true;
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(component.GetCurrentValue(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						//if any component has an overridden repair cost, set totalsOverrideRepairCost to true;
						//	the value won't be reset to false until the next time this routine is called
						totalsOverrideRepairCost = true;
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(component.GetRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(component.GetAnnualMaintenanceCost(), roundDigit));
					builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(component.GetCurrentValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(component.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(component.GetRepairCost(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(component.GetAnnualMaintenanceCost(), roundDigit));

					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", "N/A");
					}
					else
					{
						//mam - use interpolated method
						//builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", component.GetRankPercent());
						builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", component.GetRankPercentInterpolated());
					}
				}
				//</mam>

				//set OUL and RUL = N/A only if component Total Current Value = 0
				if (component.GetCurrentValue() == 0)
				{
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", component.GetOrgUsefulLife());
					builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", component.GetRemainingUsefulLife());
				}

				//mam - added check for all Condition = N/A
				if (useNA)
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", component.GetEvaluatedRemainingUsefulLife());
						builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", component.GetEconomicUsefulLife());
					}
				}
				//</mam>

				//mam - include LOS, Criticality, Vulnerability and Risk in the report
				if (component.MechStructDisciplines)
				{
					builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", component.GetLOS());
					builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", component.GetOverallCriticality());
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0}]]></GridOverallCriticality>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridLOS><![CDATA[{0:F1}]]></GridLOS>\r\n", component.GetLOS());
						builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", component.GetOverallCriticality());
					}
				}

				if (WAM.Common.CommonTasks.GetAllERULZero(m_infoSetID, component.ID) 
					&& !WAM.Common.CommonTasks.GetAnyVulnerabilityOverridden(m_infoSetID, component.ID))
				{
					builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", "N/A");
						builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", "N/A");
					}
					else
					{
						//mam 090105 - round vuln to 4 decimals rather than 2
						//builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", component.GetVulnerability());
						builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", component.GetVulnerability());

//						//mam 090105 - call Vulnerability (GetVulnerability is returning the wrong value)
//						builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", component.Vulnerability);

						builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", component.GetRisk());
					}
				}
				//</mam>

				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", component.CWPValue * 100.0);
				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", WAMRounding.RoundNumber(component.GetComponentCost(), roundDigit));
				builder.Append("\t\t</Component>\r\n");
			}

			//************************

			//Totals

			useNA = CheckIfAllNADisciplineForProcess(this.InfoSetID, this.ID);

			builder.Append("\t\t<Component>\r\n");
			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", "Total");

			//mam - use the adjusted total when possible
			if (adjustedValues == null)
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", componentTotals.GetCalcTotalCWP());
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", adjustedTotal);
			}
			//</mam>

			//mam 112806 - use "" for totals row
			builder.AppendFormat("\t\t\t<GridRetired><![CDATA[{0}]]></GridRetired>\r\n", "");

			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalAcquisitionCost(), roundDigit));

			//mam 112806 check useNA and overrides
			if (useNA)
			{
				if (totalsOverrideCurrentValue)
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
				}
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
			}

			//mam 050806
			builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalAcquisitionCostEscalated(), roundDigit));

			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalReplacementValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", componentTotals.GetAverageReplacementValueYear());
			builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalRehabCost(), roundDigit));

			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalBookValue(), roundDigit));
			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalSalvageValue(), roundDigit));
			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalAnnualDepreciation(), roundDigit));
			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalCumulativeDepreciation(), roundDigit));

			//mam - added check for all Condition = N/A
			if (useNA)
			{
				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");

				//mam 112806
				if (totalsOverrideRepairCost)
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalAnnualMaintenanceCost(), roundDigit));
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalEvaluatedValue(), roundDigit).ToString("#,##0"));
				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalAnnualMaintenanceCost(), roundDigit));
			}
			//</mam>

			builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", componentTotals.GetTotalCWPValue() * 100.0);
			builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", WAMRounding.RoundNumber(componentTotals.GetTotalOrgCost(), roundDigit));
			builder.Append("\t\t</Component>\r\n");
			builder.Append("\t</Components>\r\n");
			builder.Append("</ProcessData>\r\n");
			return builder.ToString();
		}

		//mam
		public string GetXMLMatrix(bool includePhotos, string selectedFilters, string selectedSortOrder, ArrayList filteredItems)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam

			bool useNA = false;

			StringBuilder	builder = new StringBuilder();

			//remove (char)34
			if (selectedFilters != "" && selectedFilters.StartsWith(Convert.ToString((char)34)))
			{
				selectedFilters = selectedFilters.Remove(0,1);
				int j = selectedFilters.IndexOf((char)34);
				if (j > -1)
					selectedFilters = selectedFilters.Remove(j, 1);
			}

			builder.Append("<ProcessData>\r\n");

			builder.Append("\t<Filters>\r\n");
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			builder.AppendFormat("\t\t<SelectedSortOrder><![CDATA[{0}]]></SelectedSortOrder>\r\n", selectedSortOrder);
			builder.Append("\t</Filters>\r\n");
			
			WAM.Logic.TreatmentProcessTotals processTotals = null;
			int pos;
			int curProcPos = 0;
			int curFacID = 0;
			TreatmentProcess process;
			Facility facility;
			double			cwpVal = 0.0;

			builder.Append("\t<Processes>\r\n");

			for (pos = 0; pos < filteredItems.Count; pos++)
			{
				process = (TreatmentProcess)filteredItems[pos];
				facility = process.GetFacility();
				processTotals = facility.GetProcessTotals();

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//decimal totalValue = processTotals.GetTotalCurrentValue();
				decimal totalValue = processTotals.GetTotalAcquisitionCost();
				decimal totalValueRounded = processTotals.GetTotalAcquisitionCostRoundIndividualValues();

				decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(process.InfoSetID, process.FacilityID, totalValueRounded, WAM.UI.NodeType.Facility);

				//Variable 'pos' counts from 0 to the number of processes, which can include processes from multiple facilities.
				//	This is fine for the first facility, but because pos is never reset to zero, every subsequent facility 
				//	starts with a non-zero pos value.  This will result in an out-of-range error, so use curProcPos instead.
				if (curFacID == process.FacilityID)
				{
					curProcPos += 1;
				}
				else
				{
					curFacID = process.FacilityID;
					curProcPos = 0;
				}

				useNA = CheckIfAllNADisciplineForProcess(process.InfoSetID, process.ID);

				//mam 112806
				CheckIfProcessOverridden(process.InfoSetID, process.ID);

				builder.Append("\t\t<Process>\r\n");
				builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);
				builder.AppendFormat("\t\t\t<GridNameFac><![CDATA[{0}]]></GridNameFac>\r\n", facility.Name);
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", process.Name);

				builder.AppendFormat("\t\t\t<GridFacilityCurrentYear><![CDATA[{0:F0}]]></GridFacilityCurrentYear>\r\n", facility.CurrentYear);
				builder.AppendFormat("\t\t\t<GridFacilityCurrentENR>{0}</GridFacilityCurrentENR>\r\n", facility.CurrentENR);

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					//use curProcPos instead of pos
					//cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
					cwpVal = Convert.ToDouble(adjustedValues[curProcPos].ToString());
				}
				//</mam>

				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);
				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCost(), roundDigit));

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(process.GetReplacementValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", process.GetReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(process.GetRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(process.GetBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(process.GetSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(process.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(process.GetCumulativeDepreciation(), roundDigit));

				if (useNA)
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");

					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");	
					}

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}
				}
				else
				{
					//mam 112806 - moved from above
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit).ToString("#,##0"));

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(process.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("#,##0"));
				}

				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(process.GetAnnualMaintenanceCost(), roundDigit));
				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", process.GetRankPercent());
				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", process.OrgCost);
				builder.Append("\t\t</Process>\r\n");
			}

			builder.Append("\t</Processes>\r\n");
			builder.Append("</ProcessData>\r\n");

			return builder.ToString();
		}
		//</mam>

		//mam
		public string GetCSVData(string selectedFilters, string selectedSortOrder, ArrayList filteredItems, bool includeComponents)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam

			Facility facility;
			TreatmentProcess process;
			WAM.Logic.TreatmentProcessTotals processTotals = null;
			//int pos;
			double cwpVal = 0.0;
			int curProcPos = 0;
			int curFacID = 0;
			bool useNA = false;
			StringBuilder builder = new StringBuilder();
			string componentXML = "";
			
			if (includeComponents)
				builder.Append("Treatment Process / Basin / Zone Detail Report");
			else
				builder.Append("Treatment Process / Basin / Zone Summary Report");

			builder.Append("\r\n");

			if (selectedFilters != "")
			{
				//modify selectedFilters language if report is a detail report
				if (includeComponents)
				{
					selectedFilters = selectedFilters.Replace("The totals for this", "Each");
					selectedFilters = selectedFilters.Replace("have", "in this report has");
				}

				builder.Append("\r\n");
				//builder.AppendFormat((char)34 + selectedFilters + (char)34);
				builder.AppendFormat(selectedFilters);
				builder.Append("\r\n\r\n");
			}

			//include sort order on both summary and detail CSV reports
			//if (selectedSortOrder != "" && !includeComponents)
			if (selectedSortOrder != "")
			{
				builder.AppendFormat((char)34 + selectedSortOrder + (char)34);
				builder.Append("\r\n\r\n");
			}

			builder.Append((char)34 + "Facility / System" + (char)34);
			builder.Append("," + (char)34 + "Treatment Process / Basin / Zone" + (char)34);
			if (includeComponents)
			{
				builder.Append("," + (char)34 + "Major Component / Subbasin / Subzone" + (char)34);

				//mam 112806
				builder.Append("," + (char)34 + "Component Retired" + (char)34);
			}

			builder.Append("," + (char)34 + "Facility Current Year" + (char)34);
			builder.Append("," + (char)34 + "Facility Current ENR" + (char)34);
			builder.Append("," + (char)34 + "Treatment Process Cost Weighted Percentage of Asset Value (%)" + (char)34);
			if (includeComponents)
			{
				builder.Append("," + (char)34 + "Major Component Cost Weighted Percent of Asset Value (%)" + (char)34);
			}
			builder.Append("," + (char)34 + "Acquisition Cost" + (char)34);
			builder.Append("," + (char)34 + "Current Value" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Escalated Acquisition Cost" + (char)34);

			builder.Append("," + (char)34 + "Replacement Value" + (char)34);

			//mam 112806
			builder.Append("," + (char)34 + "Average Replacement Value Year" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Rehabilitation Cost" + (char)34);

			builder.Append("," + (char)34 + "Book Value" + (char)34);
			builder.Append("," + (char)34 + "Salvage Value" + (char)34);
			builder.Append("," + (char)34 + "Annual Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Cumulative Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Value" + (char)34);
			builder.Append("," + (char)34 + "Repair Cost" + (char)34);
			builder.Append("," + (char)34 + "Annual Maintenance Cost" + (char)34);
			if (includeComponents)
			{
				builder.Append("," + (char)34 + "Condition" + (char)34);
				builder.Append("," + (char)34 + "Original Useful Life" + (char)34);
				builder.Append("," + (char)34 + "Remaining Useful Life" + (char)34);
				builder.Append("," + (char)34 + "Evaluated Remaining Useful Life" + (char)34);
				builder.Append("," + (char)34 + "Economic Remaining Useful Life" + (char)34);
				builder.Append("," + (char)34 + "Level of Service" + (char)34);
				builder.Append("," + (char)34 + "Overall Criticality" + (char)34);
				builder.Append("," + (char)34 + "Vulnerability" + (char)34);
				builder.Append("," + (char)34 + "Risk" + (char)34);
			}

			//mam 011206
			builder.Append("," + (char)34 + "Comments" + (char)34);

			//mam 03202012
			builder.Append("," + (char)34 + "Photo File" + (char)34);
			builder.Append("," + (char)34 + "Photo Caption" + (char)34);

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				process = (TreatmentProcess)filteredItems[pos];
				facility = process.GetFacility();
				processTotals = facility.GetProcessTotals();

				//mam 112806 - use AcquisitionCost instead of CurrentValue
				//decimal totalValue = processTotals.GetTotalCurrentValue();
				decimal totalValue = processTotals.GetTotalAcquisitionCost();
				decimal totalValueRounded = processTotals.GetTotalAcquisitionCostRoundIndividualValues();

				//decimal totalValue = process.GetCurrentValue();
				decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(process.InfoSetID, process.FacilityID, totalValueRounded, WAM.UI.NodeType.Facility);
				useNA = CheckIfAllNADisciplineForProcess(process.InfoSetID, process.ID);

				//mam 112806
				CheckIfProcessOverridden(process.InfoSetID, process.ID);

				//Variable 'pos' counts from 0 to the number of processes, which can include processes from multiple facilities.
				//	This is fine for the first facility, but because pos is never reset to zero, every subsequent facility 
				//	starts with a non-zero pos value.  This will result in an out-of-range error, so use curProcPos instead.
				if (curFacID == process.FacilityID)
				{
					curProcPos += 1;
				}
				else
				{
					curFacID = process.FacilityID;
					curProcPos = 0;
				}

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					//use curProcPos instead of pos
					//cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
					cwpVal = Convert.ToDouble(adjustedValues[curProcPos].ToString());
				}
				//</mam>

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);

				if (includeComponents)
				{
					builder.Append(",");

					//mam 112806
					builder.Append(",");	//retired
				}

				builder.AppendFormat(",{0:F0}", facility.CurrentYear);
				builder.AppendFormat(",{0:F0}", facility.CurrentENR);
				builder.AppendFormat(",{0:F1}", cwpVal);
				if (includeComponents)
				{
					builder.Append(",");
				}

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAcquisitionCost(), roundDigit));

				//mam 112806 - check useNA and overrides
				if (useNA)
				{
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));
				}

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetReplacementValue(), roundDigit));

				//mam 112806
				builder.AppendFormat(",{0:F0}", process.GetReplacementValueYear());

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRehabCost(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetBookValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetSalvageValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCumulativeDepreciation(), roundDigit));

				if (useNA)
				{
					builder.Append(",N/A");

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("0"));
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetEvaluatedValue(), roundDigit).ToString("0"));
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("0"));
				}
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAnnualMaintenanceCost(), roundDigit));

				//mam 101107 - replace double quote in comments with two double quotes 
				string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@process.Comments);

				//mam 03202012
				string caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@process.CaptionPhoto);
				string photo = process.PhotoFileName;

				if (includeComponents)
				{
					//mam 101107
					////mam 011206
					//builder.Append(",,,,,,,,,," + (char)34 + process.Comments + (char)34);
					builder.Append(",,,,,,,,,," + (char)34 + commentsQuotes + (char)34);

					//mam 03202012
					builder.AppendFormat(",{0}", photo);
					builder.AppendFormat(",{0}", caption);

					componentXML = GetCSVDataComponents(process);
					builder.Append(componentXML);
				}
				else
				{
					//mam 101107
					////mam 011206
					//builder.Append("," + (char)34 + process.Comments + (char)34);
					builder.Append("," + (char)34 + commentsQuotes + (char)34);

					//mam 03202012
					builder.AppendFormat(",{0}", photo);
					builder.AppendFormat(",{0}", caption);
				}
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		private string GetCSVDataComponents(TreatmentProcess process)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam

			Facility facility = process.GetFacility();
			MajorComponent[] components = CacheManager.GetComponents(process.InfoSetID, process.ID);
			MajorComponent component;
			WAM.Logic.MajorComponentTotals componentTotals = process.GetComponentTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal totalValue = componentTotals.GetTotalCurrentValue();
			decimal totalValue = componentTotals.GetTotalAcquisitionCost();
			decimal totalValueRounded = componentTotals.GetTotalAcquisitionCostRoundIndividualValues();

			double cwpVal = 0.0;
			bool useNA = false;
			StringBuilder builder = new StringBuilder();

			adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(process.InfoSetID, process.ID, totalValueRounded, WAM.UI.NodeType.TreatmentProcess);
			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];
				useNA = CheckIfAllNADisciplineForComponent(component.InfoSetID, component.ID);

				//use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValue != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(component.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(component.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);

				//mam 112806
				builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				builder.AppendFormat(",");	//facility current year
				builder.AppendFormat(",");	//facility enr
				builder.AppendFormat(",");	//process cwp
				builder.AppendFormat(",{0:F1}", cwpVal);

				//mam 01042012 - if component is retired, show zero on report
				//builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAcquisitionCost(), roundDigit));
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAcquisitionCost(), roundDigit));
				}

				//mam 112806
				CheckIfComponentOverridden(component.InfoSetID, component.ID, true);


				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//XXXX
				}
				else
				{
					//mam 112806 - check useNA and overrides
					if (useNA)
					{
						if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
						{
							builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetCurrentValue(), roundDigit));
						}
						else
						{
							builder.AppendFormat(",N/A");
						}
					}
					else
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetCurrentValue(), roundDigit));
					}
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//XXXX
					builder.Append(",0");	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAcquisitionCostEscalated(), roundDigit));

					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetReplacementValue(), roundDigit));
				}

				//mam 112806
				builder.AppendFormat(",{0:F0}", component.GetReplacementValueYear());

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//XXXX
					builder.Append(",0");	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetRehabCost(), roundDigit));

					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetBookValue(), roundDigit));
				}

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetSalvageValue(), roundDigit));

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//XXXX
					builder.Append(",0");	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAnnualDepreciation(), roundDigit));
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetCumulativeDepreciation(), roundDigit));
				}

				//builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);

				if (useNA)
				{
					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//evaluated value	//XXXX
						builder.Append(",0");	//repair cost	//XXXX
					}
					else
					{
						builder.AppendFormat(",N/A");	//evaluated value

						//mam 112806
						if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
						{
							builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetRepairCost(), roundDigit));
						}
						else
						{
							builder.AppendFormat(",N/A");	
						}
					}
				
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAnnualMaintenanceCost(), roundDigit));
					builder.AppendFormat(",N/A");
				}
				else
				{
					//mam 01042012 - if component is retired, show zero on report
					if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
					{
						builder.Append(",0");	//evaluated value	//XXXX
						builder.Append(",0");	//repair cost	//XXXX
					}
					else
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetEvaluatedValue(), roundDigit));
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetRepairCost(), roundDigit));
					}

					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(component.GetAnnualMaintenanceCost(), roundDigit));
					builder.AppendFormat(",{0:F1}", component.GetRankPercentInterpolated());
				}
				
				//OUL, RUL
				if (component.GetCurrentValue() == 0)
				{
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F1}", WAMRounding.RoundNumber(component.GetOrgUsefulLife(), roundDigit));
					builder.AppendFormat(",{0:F1}", component.GetRemainingUsefulLife());
				}
				
				//EvRUL, EcRUL
				if (useNA)
				{
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F1}", component.GetEvaluatedRemainingUsefulLife());
						builder.AppendFormat(",{0:F1}", component.GetEconomicUsefulLife());
					}
				}

				//LOS and Overall Crit
				if (component.MechStructDisciplines)
				{
					builder.AppendFormat(",{0:F1}", component.GetLOS());
					builder.AppendFormat(",{0:F1}", component.GetOverallCriticality());
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
					else
					{
						builder.AppendFormat(",{0:F1}", component.GetLOS());
						builder.AppendFormat(",{0:F1}", component.GetOverallCriticality());
					}
				}

				//vuln and risk
				if (WAM.Common.CommonTasks.GetAllERULZero(component.InfoSetID, component.ID) 
					&& !WAM.Common.CommonTasks.GetAnyVulnerabilityOverridden(component.InfoSetID, component.ID))
				{
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else
				{
					if (component.GetCurrentValue() == 0)
					{
						builder.AppendFormat(",N/A");
						builder.AppendFormat(",N/A");
					}
					else
					{
						//mam 090105 - round vuln to 4 decimals rather than 2
						//builder.AppendFormat(",{0:F2}", component.GetVulnerability());
						builder.AppendFormat(",{0:F4}", component.GetVulnerability());

//						//mam 090105 - call Vulnerability (GetVulnerability is returning the wrong value)
//						builder.AppendFormat(",{0:F4}", component.Vulnerability);

						builder.AppendFormat(",{0:F2}", component.GetRisk());
					}
				}

				//mam 101107 - replace double quote in comments with two double quotes 
				string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@component.Comments);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);
				////mam 011206
				//builder.Append("," + (char)34 + component.Comments + (char)34);

				//mam 03202012
				string caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@component.CaptionPhoto);
				builder.AppendFormat(",{0}", component.PhotoFileName);
				builder.AppendFormat(",{0}", caption);
			}

			return builder.ToString();
		}
		//</mam>

		//mam - add routine to check whether Condition for all pipes is N/A
		private bool GetAllConditionNAPipes(int disciplineID)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, disciplineID);
			bool AllNA = true;

//			//mam 112806
//			pipeOverrideAnyCurrentValue = false;
//			pipeOverrideAnyRepairCost = false;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;

					break;

//					//mam 112806
//					if (pipes[pos].OverrideCurrentValue)
//					{
//						pipeOverrideAnyCurrentValue = true;
//					}
//					if (pipes[pos].OverrideRepairCost)
//					{
//						pipeOverrideAnyRepairCost = true;
//					}
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether Condition for all nodes is N/A
		private bool GetAllConditionNANodes(int disciplineID)
		{
			// Retrieve the pipe data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(InfoSetID, disciplineID);
			bool AllNA = true;

//			//mam 112806
//			nodeOverrideAnyCurrentValue = false;
//			nodeOverrideAnyRepairCost = false;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;

					break;

//					//mam 112806
//					if (nodes[pos].OverrideCurrentValue)
//					{
//						nodeOverrideAnyCurrentValue = true;
//					}
//					if (nodes[pos].OverrideRepairCost)
//					{
//						nodeOverrideAnyRepairCost = true;
//					}
				}

			return AllNA;
		}
		//</mam>

//		//mam 112806
//		private void CheckIfPipeOverridden(int disciplineID)
//		{
//			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, disciplineID);
//
//			pipeOverrideAnyCurrentValue = false;
//			pipeOverrideAnyRepairCost = false;
//
//			for (int pos = 0; pos < pipes.Length; pos++)
//			{
//				if (pipes[pos].OverrideCurrentValue)
//				{
//					pipeOverrideAnyCurrentValue = true;
//				}
//				if (pipes[pos].OverrideRepairCost)
//				{
//					pipeOverrideAnyRepairCost = true;
//				}
//			}
//		}
//		//</mam>

//		//mam 112806
//		private void CheckIfNodeOverridden(int disciplineID)
//		{
//			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(InfoSetID, disciplineID);
//
//			nodeOverrideAnyCurrentValue = false;
//			nodeOverrideAnyRepairCost = false;
//
//			for (int pos = 0; pos < nodes.Length; pos++)
//			{
//				if (nodes[pos].OverrideCurrentValue)
//				{
//					nodeOverrideAnyCurrentValue = true;
//				}
//				if (nodes[pos].OverrideRepairCost)
//				{
//					nodeOverrideAnyRepairCost = true;
//				}
//			}
//		}
		//</mam>

//		//mam 112806
//		private void CheckIfMscOverridden(int componentID)
//		{
//			//check whether any Current Value or Repair Cost is overridden for this Discipline
//
//			Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, componentID);
//			Discipline discipline;
//
//			mscOverrideAnyCurrentValue = false;
//			mscOverrideAnyRepairCost = false;
//
//			for (int pos = 0; pos < disciplines.Length; pos++)
//			{
//				if (discipline.Type == DisciplineType.Mechanical 
//					|| discipline.Type == DisciplineType.Structural
//					|| discipline.Type == DisciplineType.Land)
//				{
//					if (discipline.OverrideCurrentValue)
//					{
//						mscOverrideAnyCurrentValue = true;
//					}
//					if (discipline.OverrideRepairCost)
//					{
//						mscOverrideAnyRepairCost = true;
//					}
//				}
//			}
//
//			return false;
//		}
		//</mam>

		//mam 112806
		private void ResetOverrideVariables()
		{
			mscOverrideAnyCurrentValue = false;
			mscOverrideAnyRepairCost = false;
			pipeOverrideAnyCurrentValue = false;
			pipeOverrideAnyRepairCost = false;
			nodeOverrideAnyCurrentValue = false;
			nodeOverrideAnyRepairCost = false;
		}

		//mam 112806
		private void CheckIfComponentOverridden(int curInfosetID, int curComponentID, bool resetVariables)
		{
			Discipline[] disciplines = CacheManager.GetDisciplines(curInfosetID, curComponentID);
			Discipline discipline;
			DisciplinePipe pipe;
			DisciplineNode node;

			if (resetVariables)
			{
				ResetOverrideVariables();
			}

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];

				if (discipline.Type == DisciplineType.Pipes)
				{
//					PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(InfoSetID, discipline.ID);
//
//					for (int pos2 = 0; pos2 < pipes.Length; pos2++)
//					{
//						if (pipes[pos2].OverrideCurrentValue)
//						{
//							pipeOverrideAnyCurrentValue = true;
//						}
//						if (pipes[pos2].OverrideRepairCost)
//						{
//							pipeOverrideAnyRepairCost = true;
//						}

						pipe = discipline as DisciplinePipe;

						if (pipe.GetAnyCurrentValueOverridden())
						{
							pipeOverrideAnyCurrentValue = true;
						}
						if (pipe.GetAnyRepairCostOverridden())
						{
							pipeOverrideAnyRepairCost = true;
						}
//					}				
				}
				else if (discipline.Type == DisciplineType.Nodes)
				{
//					NodeData[] nodes = CacheManager.GetNodeDataForDiscipline(InfoSetID, discipline.ID);
//
//					for (int pos2 = 0; pos2 < nodes.Length; pos2++)
//					{
//						if (nodes[pos2].OverrideCurrentValue)
//						{
//							nodeOverrideAnyCurrentValue = true;
//						}
//						if (nodes[pos2].OverrideRepairCost)
//						{
//							nodeOverrideAnyRepairCost = true;
//						}
//					}

					node = discipline as DisciplineNode;

					if (node.GetAnyCurrentValueOverridden())
					{
						nodeOverrideAnyCurrentValue = true;
					}
					if (node.GetAnyRepairCostOverridden())
					{
						nodeOverrideAnyRepairCost = true;
					}
				}
				else
				{
					if (discipline.OverrideCurrentValue)
					{
						mscOverrideAnyCurrentValue = true;
					}

					if (discipline.OverrideRepairCost)
					{
						mscOverrideAnyRepairCost = true;
					}
				}
			}
		}
		//</mam>

		//mam 112806
		private void CheckIfProcessOverridden(int curInfosetID, int curProcessID)
		{
			MajorComponent[] components = CacheManager.GetComponents(curInfosetID, curProcessID);
			MajorComponent component;

			ResetOverrideVariables();

			for (int pos = 0; pos < components.Length; pos++)
			{
				component = components[pos];

				if (component.Retired)
					continue;

				CheckIfComponentOverridden(component.InfoSetID, component.ID, false);

				if ((mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					&& (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost))
				{
					break;
				}
			}
		}
		//</mam>

//		//mam 112806
//		private void CheckIfMscOverriddenForProcess()
//		{
//			//check whether any Current Value or Repair Cost is overridden for this Discipline
//
//			MajorComponent[] components = CacheManager.GetComponents(m_infoSetID, this.ID);
//			MajorComponent component;
//
//			mscOverrideAnyCurrentValue = false;
//			mscOverrideAnyRepairCost = false;
//
//			for (int pos = 0; pos < components.Length; pos++)
//			{
//				component = components[pos];
//
//				if (component.Retired)
//					continue;
//
//				Discipline[] disciplines = CacheManager.GetDisciplines(InfoSetID, component.ID);
//				Discipline discipline;
//
//				for (int pos = 0; pos < disciplines.Length; pos++)
//				{
//					if (discipline.Type == DisciplineType.Pipes)
//					{
//						if (!GetAllConditionNAPipes(discipline.ID))
//							return false;
//					}
//					else if (discipline.Type == DisciplineType.Nodes)
//					{
//						!CheckIfNodeOverridden(discipline.ID))
//							return false;
//					}
//					else if (discipline.Type == DisciplineType.Mechanical 
//						|| discipline.Type == DisciplineType.Structural
//						|| discipline.Type == DisciplineType.Land)
//					{
//						if (discipline.OverrideCurrentValue)
//						{
//							mscOverrideAnyCurrentValue = true;
//
//							if (mscOverrideAnyRepairCost)
//								return;
//						}
//						if (discipline.OverrideRepairCost)
//						{
//							mscOverrideAnyRepairCost = true;
//
//							if (mscOverrideAnyCurrentValue)
//								return;
//						}
//					}
//				}
//			}
//		}
//		//</mam>

//		//mam
//		private bool CheckIfAllNADiscipline()
//		{
//			//mam - check whether all Disciplines for this Process have Condition = N/A;
//
//			bool AllNA = true;
//
//			MajorComponent[] components = CacheManager.GetComponents(m_infoSetID, this.ID);
//			MajorComponent	component;
//
//			for (int pos = 0; pos < components.Length; pos++)
//			{
//				component = components[pos];
//
//				if (component.Retired)
//					continue;
//
//				Discipline[] disciplines = CacheManager.GetDisciplines(InfoSetID, component.ID);
//				Discipline discipline;
//
//				for (int pos2 = 0; pos2 < disciplines.Length; pos2++)
//				{
//					discipline = disciplines[pos2];
//
//					if (discipline.Type == DisciplineType.Pipes)
//					{
//						if (!GetAllConditionNAPipes(discipline.ID))
//							return false;
//					}
//					else if (discipline.Type == DisciplineType.Nodes)
//					{
//						if (!GetAllConditionNANodes(discipline.ID))
//							return false;
//					}
//					else if (discipline.Type == DisciplineType.Mechanical 
//							|| discipline.Type == DisciplineType.Structural
//							|| discipline.Type == DisciplineType.Land)
//						{
//							if (discipline.ConditionRanking != CondRank.No)
//								return false;
//						}
//					}
//				}
//
//			return AllNA;
//		}
//		//</mam>

		//mam
		private bool CheckIfAllNADisciplineForComponent(int curInfosetID, int curComponentID)
		{
			//mam - check whether all Disciplines in this Component have Condition = N/A;

			bool AllNA = true;

			Discipline[] disciplines = CacheManager.GetDisciplines(curInfosetID, curComponentID);
			Discipline discipline;

			DisciplinePipe	pipe;
			DisciplineNode	node;

			for (int pos = 0; pos < disciplines.Length; pos++)
			{
				discipline = disciplines[pos];
				if (discipline.Type == DisciplineType.Pipes)
				{
					pipe = discipline as DisciplinePipe;
					if (!pipe.GetAllConditionNA())
					{
						AllNA = false;
						break;
					}
				}
				if (discipline.Type == DisciplineType.Nodes)
				{
					node = discipline as DisciplineNode;
					if (!node.GetAllConditionNA())
					{
						AllNA = false;
						break;
					}
				}
				if (discipline.Type == DisciplineType.Mechanical 
					|| discipline.Type == DisciplineType.Structural
					|| discipline.Type == DisciplineType.Land)
				{
					AllNA = (discipline.ConditionRanking == CondRank.No);
					if (!AllNA)
						break;
				}
			}

			return AllNA;
		}
		//</mam>

		//mam
		private bool CheckIfAllNADisciplineForProcess(int curInfosetID, int curProcessID)
		{
			//mam - check whether all Disciplines for this Process have Condition = N/A;

			bool AllNA = true;

			//			TreatmentProcess[]	processes = CacheManager.GetProcesses(m_infoSetID, this.ID);
			//			TreatmentProcess	process;
			MajorComponent[]	components;
			MajorComponent		component;
			Discipline[] disciplines;
			Discipline discipline;

			//			for (int pos = 0; pos < processes.Length; pos++)
		{
			//				process = processes[pos];
			//components = CacheManager.GetComponents(m_infoSetID, process.ID);
			components = CacheManager.GetComponents(curInfosetID, curProcessID);

			for (int pos2 = 0; pos2 < components.Length; pos2++)
			{
				component = components[pos2];

				if (component.Retired)
					continue;

				//disciplines = CacheManager.GetDisciplines(InfoSetID, component.ID);
				disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);

				for (int pos3 = 0; pos3 < disciplines.Length; pos3++)
				{
					discipline = disciplines[pos3];

					if (discipline.Type == DisciplineType.Pipes)
					{
						if (!GetAllConditionNAPipes(discipline.ID))
							return false;
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						if (!GetAllConditionNANodes(discipline.ID))
							return false;
					}
					else if (discipline.Type == DisciplineType.Mechanical 
						|| discipline.Type == DisciplineType.Structural
						|| discipline.Type == DisciplineType.Land)
					{
						if (discipline.ConditionRanking != CondRank.No)
							return false;
					}
				}
			}
		}
			return AllNA;
		}
		//</mam>

		public void			CopyTo(TreatmentProcess copy)
		{
			//copy.m_facilityID = 0; // Don't copy FacilityID
			copy.m_name = m_name;
			copy.m_CWPValue = m_CWPValue;
			copy.m_orgCost = m_orgCost;
			copy.m_captionPhoto = m_captionPhoto;

			//mam 03202012
			copy.m_photoFileName = m_photoFileName;

			//mam 102309
			//copy.m_photo = m_photo;

			copy.m_comments = m_comments;
			copy.m_sortOrder = m_sortOrder;
			copy.m_isFunded = m_isFunded;
			copy.m_pctFunded = m_pctFunded;
			copy.m_orgCostOrgVal = m_orgCostOrgVal;
		}

		//mam - allow or disallow copying of photo
		public void CopyTo(TreatmentProcess copy, bool copyPhoto)
		{
			//copy.m_facilityID = 0; // Don't copy FacilityID
			copy.m_name = m_name;
			copy.m_CWPValue = m_CWPValue;
			copy.m_orgCost = m_orgCost;

			if (copyPhoto)
			{
				copy.m_captionPhoto = m_captionPhoto;

				//mam 03202012
				copy.m_photoFileName = m_photoFileName;

				//mam 102309
				//copy.m_photo = m_photo;
			}

			copy.m_comments = m_comments;
			copy.m_sortOrder = m_sortOrder;
			copy.m_isFunded = m_isFunded;
			copy.m_pctFunded = m_pctFunded;
			copy.m_orgCostOrgVal = m_orgCostOrgVal;
		}
		//</mam>

		//mam - allow new process name
		public void CopyTo(TreatmentProcess copy, string newProcessName, bool copyPhoto)
		{
			CopyTo(copy, copyPhoto);
			copy.m_name = newProcessName;
			//copy.m_CWPValue = 0;

			//mam 112806 - setting m_sortOrder here is overriding the value that was copied into it above
			//copy.m_sortOrder = 65000;

			//if (copy.m_sortOrder != 65000)
			//	copy.m_sortOrder = m_sortOrder + 1;
		}
		//</mam>

		//mam 101107 - replace double quote in comments with two double quotes 
		private string ReplaceDoubleQuoteWithTwoDoubleQuotes(string stringToChange)
		{
			stringToChange = stringToChange.Replace("\"", "\"\"");
			return stringToChange;
		}

		#endregion /***** Methods *****/

		#region /***** Properties *****/
		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public int			FacilityID
		{
			get { return m_facilityID; }
			set { m_facilityID = value; }
		}

		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public double		CWPValue
		{
			get { return m_CWPValue; }
			set { m_CWPValue = value; }
		}

		public decimal		OrgCost
		{
			get { return m_orgCost; }
			set { m_orgCost = value; }
		}

		public string		CaptionPhoto
		{
			get { return m_captionPhoto; }
			set
			{
				if (value.Length > 255)
					m_captionPhoto = value.Substring(255);
				else
					m_captionPhoto = value;
			}
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return m_photoFileName; }
			set { m_photoFileName = value; }
		}

//		public string Photo
//		{
//			get { return m_photo; }
//			set
//			{
//				if (value.Length > 255)
//					m_photo = value.Substring(255);
//				else
//					m_photo = value;
//			}
//		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public int			SortOrder
		{
			get { return m_sortOrder; }
			set { m_sortOrder = value; }
		}

		public bool			IsFunded
		{
			get { return m_isFunded; }
			set { m_isFunded = value; }
		}

		public double		PctFunded
		{
			get { return m_pctFunded; }
			set { m_pctFunded = value; }
		}

		public decimal		OrgCostOrgVal
		{
			get { return m_orgCostOrgVal; }
			set { m_orgCostOrgVal = value; }
		}

		//mam 050806
		public int TreeNodeIndex
		{
			get { return treeNodeIndex; }
			set { treeNodeIndex = value; }
		}

		//mam 102309
		//public int			ProcessId
		//{
		//	get { return m_processId; }
		//	set { m_processId = value; }
		//}

		#endregion /***** Properties *****/

		#region /***** Photo Methods *****/

		//mam 03202012 - renamed to indicate the photo file name is included
		//public string		GetImagePath()
		public string		GetImagePathWithPhotoFileName()
		{
			//mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value

			//Facility		facility = new Facility(m_sqlConnectionString, FacilityID);
			//InfoSet			infoSet = new InfoSet(m_sqlConnectionString, facility.InfoSetID);

			//mam 102309
			//string			path = string.Format(
			//	@"{0}\{1:D4}-{2:D4}.jpg", infoSet.GetImagePath(),
			//	facility.ID, ID);
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			//string photoName = this.Photo;
			//string photoNamePlusPath = photoPath + "\\" + photoName;

			//mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
			//mam 102309 - no - use ID method for photo names
			//if (photoName == null || photoName == "")
			//{
				//mam 03202012 - use the actual file name instead of the database ids
				//string photoName = string.Format(@"{0:D4}-{1:D4}.jpg", m_facilityID, ID);
				//photoPath += "\\" + photoName;
				photoPath += "\\" + m_photoFileName;
			//}

			return photoPath;
		}

		//mam 03202012
		public string GetImagePathIdStyle()
		{
			InfoSet infoSet = new InfoSet(m_sqlConnectionString, InfoSetID);
			string path = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", infoSet.GetImagePath(), FacilityID, ID);

			return path;
		}

		//mam 03202012 - this method is no longer being used
//		//mam 102309 - used only when deleting photos, and we are not deleting photos any more
//		//mam 102309 - yes, we are
//		//mam - pass in IDs so the path can be returned faster when deleting photos
//		public string		GetImagePath(int facilityID, int processID, int infoSetID)
//		{
//			InfoSet			infoSet = new InfoSet(m_sqlConnectionString, infoSetID);
//
//			//mam 03202012 - get the path - we are no longer formating the file names using database ids
//			//string			path = string.Format(@"{0}\{1:D4}-{2:D4}.jpg", infoSet.GetImagePath(), facilityID, processID);
//			string path = infoSet.GetImagePath();
//
//			return path;
//		}
//		//</mam>

		public Image		GetPhoto()
		{
			//mam 03202012 - changed GetImagePath to GetImagePathWithPhotoFileName
			//string			path = GetImagePath();
			string			path = GetImagePathWithPhotoFileName();

			Image			image = null;

			//mam 03202012 - the file name is no longer automatically the database ids, so we must add the actual file name to path
			//path += "\\" + m_photoFileName;

			//mam - added try/catch
			try
			{
				if (System.IO.File.Exists(path))
				{
					//image = Image.FromFile(path);
					//return image;

					//mam - set the file to be not read only, just in case the user has pulled a fast one and
					//	has copied a read-only image into the images folder
					System.IO.File.SetAttributes(path, System.IO.FileAttributes.Normal);
					//</mam>

					//mam - get the image from a filestream to alleviate
					//	"access denied" issues when deleting nodes and image folders
					using (System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open))
					{
						image = Image.FromStream(fileStream);
						fileStream.Close();
					}
					//</mam>
				}
			}
			catch
			{
				return null;
			}
			//</mam>

			return image;
		}

		#endregion /***** Photo Methods *****/

		#region		/***** Calculation Methods *****/
		private Logic.MajorComponentTotals
							m_componentTotals = null;

		public void			RefreshTotals()
		{
			m_componentTotals = new Logic.MajorComponentTotals(this);
		}

		public Logic.MajorComponentTotals GetComponentTotals()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals;
		}

		public bool			HasChildren
		{
			get
			{
				if (m_componentTotals == null)
					RefreshTotals();

				return m_componentTotals.GetMajorComponents().Length > 0;
			}
		}

		public decimal		GetAcquisitionCost()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalAcquisitionCost();
		}

		//mam 091607 - new method
		public decimal		GetAcquisitionCostRoundIndividualValues()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalAcquisitionCostRoundIndividualValues();
		}

		//mam 050806
		public decimal		GetAcquisitionCostEscalated()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalAcquisitionCostEscalated();
		}

		//mam 050806
		public decimal		GetRehabCost()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalRehabCost();
		}

		public decimal		GetCurrentValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalCurrentValue();
		}

		public decimal		GetReplacementValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalReplacementValue();
		}

		//mam 050806
		public int GetReplacementValueYear()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetAverageReplacementValueYear();
		}

		public decimal		GetBookValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalBookValue();
		}

		public decimal		GetSalvageValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalSalvageValue();
		}

		public decimal		GetAnnualDepreciation()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalAnnualDepreciation();
		}

		public decimal		GetCumulativeDepreciation()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalCumulativeDepreciation();
		}

		public decimal		GetEvaluatedValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalEvaluatedValue();
		}

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetEvaluatedValue()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return Math.Round(m_componentTotals.GetTotalEvaluatedValue(), 0);
		}
		//</mam>

		public decimal		GetRepairCost()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalRepairCost();
		}

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetRepairCost()
		{
			if (m_componentTotals == null)
				RefreshTotals();
			
			if (isNA)
				return -1;
			else
				return Math.Round(m_componentTotals.GetTotalRepairCost(), 0);
		}
		//</mam>

		public decimal		GetAnnualMaintenanceCost()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalAnnualMaintenanceCost();
		}

		public decimal		GetOrgCostLessStrtLineDep()
		{
			decimal			orgCostLessStrtLineDep = 0;
			decimal			procULBook = (decimal)GetRemainingUsefulLife();
			decimal			procULOrg = (decimal)GetOrgUsefulLife();

			if (procULBook <= 0m || procULOrg == 0m)
				return 0m;

			orgCostLessStrtLineDep = OrgCostOrgVal;
			orgCostLessStrtLineDep *= (procULBook / procULOrg);
			return orgCostLessStrtLineDep;
		}

		public double		GetRankPercent()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetRankPercent();
		}

		//mam - new method to use when sorting to return a rounded value
		public double SortGetRankPercent()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetRankPercent(), 1);
		}
		//</mam>

		public double		GetOrgUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalOrgUsefulLife();
		}

		//mam - new method to use when sorting to return a rounded value
		public double SortGetOrgUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetTotalOrgUsefulLife(), 1);
		}
		//</mam>

		public double		GetRemainingUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalRemainingUsefulLife();
		}

		//mam - new method to use when sorting to return a rounded value
		public double SortGetRemainingUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetTotalRemainingUsefulLife(), 1);
		}
		//</mam>

		public double		GetEvaluatedRemainingUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalEvaluatedRemainingUsefulLife();
		}

		//mam - new method to use when sorting to return a rounded value
		public double SortGetEvaluatedRemainingUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetTotalEvaluatedRemainingUsefulLife(), 1);
		}
		//</mam>

		//mam
		public double		GetEconomicUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalEconomicUsefulLife();
		}
		//</mam>

		//mam - new method to use when sorting to return a rounded value
		public double SortGetEconomicUsefulLife()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetTotalEconomicUsefulLife(), 1);
		}
		//</mam>

		//mam
		public double		GetTotalProcRisk()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalRisk();
		}
		//</mam>

		//mam - new method to use when sorting to return a rounded value
		public double SortGetTotalProcRisk()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return Math.Round(m_componentTotals.GetTotalRisk(), 2);
		}
		//</mam>

		public double		GetCWP()
		{
			if (m_componentTotals == null)
				RefreshTotals();

			return m_componentTotals.GetTotalCWPValue();
		}

//		//mam - add a routine that returns the unrounded CWP
//		public double		GetCWP(bool roundValue)
//		{
//			if (m_componentTotals == null)
//				RefreshTotals();
//
//			if (roundValue)
//				return m_componentTotals.GetTotalCWPValue();
//			else
//				return m_componentTotals.GetTotalCWPValue(false);
//		}
//		//</mam>

		public decimal		GetFundedAcquisitionCost()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetAcquisitionCost();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		//mam 091607 - new method
		public decimal		GetFundedAcquisitionCostRoundIndividualValues()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetAcquisitionCostRoundIndividualValues();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		//mam 050806
		public decimal		GetFundedAcquisitionCostEscalated()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetAcquisitionCostEscalated();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		//mam 050806
		public decimal		GetFundedRehabCost()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetRehabCost();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedCurrentValue()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetCurrentValue();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedReplacementValue()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetReplacementValue();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedBookValue()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetBookValue();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedSalvageValue()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetSalvageValue();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedAnnualDepreciation()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetAnnualDepreciation();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedCumulativeDepreciation()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetCumulativeDepreciation();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedEvaluatedValue()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetEvaluatedValue();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedRepairCost()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetRepairCost();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedAnnualMaintenanceCost()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedVal = GetAnnualMaintenanceCost();

			fundedVal *= (decimal)PctFunded;
			return fundedVal;
		}

		public decimal		GetFundedCost()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedCost = OrgCost;

			fundedCost *= (decimal)PctFunded;
			return fundedCost;
		}

		public decimal		GetFundedOrgCostOrgVal()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedOrgCostOrgVal = OrgCostOrgVal;

			fundedOrgCostOrgVal *= (decimal)PctFunded;
			return fundedOrgCostOrgVal;
		}

		public decimal		GetFundedCostLessStrtLineDep()
		{
			if (!IsFunded)
				return 0;

			decimal			fundedCostLessStrtLineDep = 0;
			decimal			procULBook = (decimal)GetRemainingUsefulLife();
			decimal			procULOrg = (decimal)GetOrgUsefulLife();

			if (procULBook <= 0m || procULOrg == 0m)
				return 0m;

			fundedCostLessStrtLineDep = OrgCostOrgVal;
			fundedCostLessStrtLineDep *= (decimal)PctFunded;
			fundedCostLessStrtLineDep *= (procULBook / procULOrg);
			return fundedCostLessStrtLineDep;
		}
		#endregion	/***** Calculation Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static TreatmentProcess[] LoadAllOleDb(int facilityID)
		{
			TreatmentProcess[] processes = LoadAllOleDb(WamSourceOleDb.CurrentSource.ConnectionString, facilityID);

			return processes;
		}

		//mam 102309
		public static TreatmentProcess[] LoadAllOleDb(string connectionString, int facilityID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			TreatmentProcess[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAllOleDb(sqlConnection, facilityID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static TreatmentProcess[] LoadAllOleDb(OleDbConnection sqlConnection, int facilityID)
		{
			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;

			TreatmentProcess		newObject;
			TreatmentProcess[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("process_id, facility_id, process_name, process_CWPTPValue, ");
			builder.Append("process_orgCost, process_captionPhoto, process_comments, ");
			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append("FROM TreatmentProcesses ");
			builder.AppendFormat("WHERE (facility_id={0}) ", facilityID);
			builder.Append("ORDER BY process_sortOrder Asc, process_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					//newObject = new TreatmentProcess(dataReader);
					newObject = new TreatmentProcess(0);
					newObject.LoadRecordData(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("TreatmentProcess.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new TreatmentProcess[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static TreatmentProcess[] LoadAll(int facilityID)
		{
			//mam 102309
			//TreatmentProcess[] processes = LoadAll(WAMSource.CurrentSource.ConnectionString, facilityID);
			TreatmentProcess[] processes = LoadAll(Globals.WamSqlConnectionString, facilityID);

			return processes;
		}

		public static TreatmentProcess[] LoadAll(string connectionString, int facilityID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			TreatmentProcess[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAll(sqlConnection, facilityID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static TreatmentProcess[] LoadAll(OleDbConnection sqlConnection, int facilityID)
		public static TreatmentProcess[] LoadAll(SqlConnection sqlConnection, int facilityID)
		{
			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			TreatmentProcess		newObject;
			TreatmentProcess[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("process_id, facility_id, process_name, process_CWPTPValue, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("process_orgCost, process_captionPhoto, PhotoFileName, process_comments, ");

			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append("FROM TreatmentProcesses ");
			builder.AppendFormat("WHERE (facility_id={0}) ", facilityID);
			builder.Append("ORDER BY process_sortOrder Asc, process_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new TreatmentProcess(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("TreatmentProcess.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new TreatmentProcess[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 03202012 - new method to get all processes for an infoset
		//@@@@
		public static TreatmentProcess[] LoadAllForInfoset(SqlConnection sqlConnection, int infosetID)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			TreatmentProcess		newObject;
			TreatmentProcess[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("P.process_id, P.facility_id, P.process_name, P.process_CWPTPValue, ");
			builder.Append("P.process_orgCost, P.process_captionPhoto, P.PhotoFileName, P.process_comments, ");
			builder.Append("P.process_sortOrder, P.process_isFunded, P.process_pctFunded, ");
			builder.Append("P.process_orgCostOrgVal ");
			builder.Append(" FROM TreatmentProcesses P LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetID);
			builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id");

			//builder.Append("SELECT P.*");
			//builder.Append(" FROM TreatmentProcesses P LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			//builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetID);
			//builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new TreatmentProcess(dataReader);
					if (newObject.ID != 0)
					{
						arrayList.Add(newObject);
					}
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("TreatmentProcess.LoadAll Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new TreatmentProcess[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		//public static TreatmentProcess[] LoadForProcessName(string processName, int facilityID, OleDbConnection sqlConnection)
		public static TreatmentProcess[] LoadForProcessName(string processName, int facilityID, SqlConnection sqlConnection)
		{
			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			TreatmentProcess		newObject;
			TreatmentProcess[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("process_id, facility_id, process_name, process_CWPTPValue, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("process_orgCost, process_captionPhoto, PhotoFileName, process_comments, ");

			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append("FROM TreatmentProcesses ");
			builder.Append("WHERE (");
			builder.AppendFormat("facility_id={0} AND ", facilityID);
			builder.AppendFormat("process_name='{0}') ", Drive.SQL.PadString(processName));
			builder.Append("ORDER BY process_sortOrder Asc, process_id Asc");

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new TreatmentProcess(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("TreatmentProcess.LoadForProcessName Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new TreatmentProcess[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		public static TreatmentProcess LoadOne(SqlConnection sqlConnection, int treatmentProcessId)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			TreatmentProcess		newObject = null;
			//TreatmentProcess[]		typedArray;
			//ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("process_id, facility_id, process_name, process_CWPTPValue, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("process_orgCost, process_captionPhoto, PhotoFileName, process_comments, ");

			builder.Append("process_sortOrder, process_isFunded, process_pctFunded, ");
			builder.Append("process_orgCostOrgVal ");

			builder.Append("FROM TreatmentProcesses ");
			builder.AppendFormat("WHERE (process_id={0}) ", treatmentProcessId);
			builder.Append("ORDER BY process_sortOrder Asc, process_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new TreatmentProcess(dataReader);
					//if (newObject.ID != 0)
					//	arrayList.Add(newObject);
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("TreatmentProcess.LoadOne Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			//typedArray = new TreatmentProcess[arrayList.Count];
			//arrayList.CopyTo(typedArray);
			//return typedArray;
			return newObject;
		}

		public static string GetTypeString()
		{
			return "TreatmentProcess";
		}

		#endregion /***** Static Methods *****/
	}

	#region /***** Cache Class *****/
	public class			TreatmentProcessCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable();

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.TreatmentProcess));
		private int			m_infoSetID = 0;

		public				TreatmentProcessCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			//mam 102309
			//m_changeDelegate = new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged);
			m_changeDelegate = new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged);

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(m_changeDelegate);
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(m_changeDelegate);
		}

		#region IDisposable Members
		~TreatmentProcessCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		public int			InfoSetID
		{
			get { return m_infoSetID; }
		}

		//mam 102309
		//private void DataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			TreatmentProcess obj = e.ChangedObject as TreatmentProcess;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
				{
					//mam 102309 - the first treatment process is duplicated when copying a facility 
					//	- check to see if it's already in the cache 

					m_treeHash.AddChild(obj.FacilityID, obj);
				}
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.FacilityID, obj);
			}
		}

		public TreatmentProcess[] GetForFacility(int id)
		{
			TreatmentProcess[] children = (TreatmentProcess[])m_treeHash.GetChildren(id);

			if (children == null)
			{
				System.Diagnostics.Trace.WriteLine("Generating TreatmentProcess cache");
				children = TreatmentProcess.LoadAll(id);
				m_treeHash.SetChildren(id, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					// Set info set for cache matching purposes
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}

			return children;
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public TreatmentProcess[] GetForFacilityForReport(int id)
		{
			TreatmentProcess[] children = (TreatmentProcess[])m_treeHash.GetChildren(id);

			//mam 06212012 - don't go to the database
			//if (children == null)
			//{
			//	System.Diagnostics.Trace.WriteLine("Generating TreatmentProcess cache");
			//	children = TreatmentProcess.LoadAll(id);
			//	m_treeHash.SetChildren(id, children);
			//	for (int pos = 0; pos < children.Length; pos++)
			//	{
			//		// Set info set for cache matching purposes
			//		children[pos].InfoSetID = m_infoSetID;
			//		m_hash[children[pos].GetHashCode()] = children[pos];
			//	}
			//}

			return children;
		}

		public void			SortForFacility(int id)
		{
			m_treeHash.Sort(id);
		}

		//mam 102309 - added this method, but commented it because it is not necessary
//		public TreatmentProcess AddTreatmentProcessToCache(int facilityId, int treatmentProcessId)
//		{
//			SqlConnection sqlConnection = new SqlConnection(WAM.Common.Globals.WamSqlConnectionString);
//
//			try
//			{
//				sqlConnection.Open();
//				TreatmentProcess child = TreatmentProcess.LoadOne(sqlConnection, treatmentProcessId);
//				m_treeHash.AddChild(facilityId, child);
//				child.InfoSetID = m_infoSetID;
//				m_hash[child.GetHashCode()] = child;
//				return child;
//			}
//			finally
//			{
//				if (sqlConnection != null)
//					sqlConnection.Dispose();
//			}
//		}

		//mam 102309
		//public TreatmentProcess[] BuildCacheForFacility(OleDbConnection connection, int id)
		public TreatmentProcess[] BuildCacheForFacility(SqlConnection connection, int id)
		{
			TreatmentProcess[] children = TreatmentProcess.LoadAll(connection, id);

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				// Set info set for cache matching purposes
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		//mam 03202012 - new method to get all processes for an infoset at once
		//@@@@
		public TreatmentProcess[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			TreatmentProcess[] children = TreatmentProcess.LoadAllForInfoset(connection, infosetId);

			foreach (TreatmentProcess process in children)
			{
				m_treeHash.AddChild(process.FacilityID, process);

				process.InfoSetID = m_infoSetID;
				m_hash[process.GetHashCode()] = process;
			}

			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		public TreatmentProcess GetTreatmentProcess(int id)
		{
			// Look up the process in the hash table
			TreatmentProcess process = m_hash[id.GetHashCode()] as TreatmentProcess;

			// If the process is not present, load it from the default database
			if (process == null)
			{
				process = new TreatmentProcess(id);
				process.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (process.ID != 0)
					m_hash[process.GetHashCode()] = process;
				else
					process = null;
			}

			return process;
		}
	}
	#endregion /***** Cache Class *****/
}
