using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for DisciplineStruct.
	/// </summary>
	public class DisciplineStruct : Discipline
	{
		#region /***** Member Variables *****/

		//mam - change all ItemStatus.No to ItemStatus.NotApplicable
//		private ItemStatus	m_concSpalling = ItemStatus.No;
//		private ItemStatus	m_structExcessiveCorrosion = ItemStatus.No;
//		private ItemStatus	m_membExcessiveCorrosion = ItemStatus.No;
//		private ItemStatus	m_corrosionCoating = ItemStatus.No;
//		private ItemStatus	m_paintGood = ItemStatus.No;
//		private ItemStatus	m_visibleDeformities = ItemStatus.No;
//		private ItemStatus	m_settingEvident = ItemStatus.No;
//		private ItemStatus	m_roofExcessiveDegradation = ItemStatus.No;
//		private ItemStatus	m_majorCracks = ItemStatus.No;

		private ItemStatus	m_concSpalling = ItemStatus.NotApplicable;
		private ItemStatus	m_structExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_membExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_corrosionCoating = ItemStatus.NotApplicable;
		private ItemStatus	m_paintGood = ItemStatus.NotApplicable;
		private ItemStatus	m_visibleDeformities = ItemStatus.NotApplicable;
		private ItemStatus	m_settingEvident = ItemStatus.NotApplicable;
		private ItemStatus	m_roofExcessiveDegradation = ItemStatus.NotApplicable;
		private ItemStatus	m_majorCracks = ItemStatus.NotApplicable;
		//</mam>

		private DateTime	m_dateInspected = DateTime.Now.Date;
		private string		m_assessedBy = "";
		private string		m_equipmentNumber = "";
		private string		m_manufacturer = "";
		private string		m_runHours = "";
		private string		m_photoCaption = "";
		private string		m_comments = "";
		private bool		m_runningAtInspect = false;

		//mam 102309
		//private string m_photo = "";

		//mam 07072011
		private bool forImport = false;

		////mam 03202012
		//private string m_photoFileName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public DisciplineStruct(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public DisciplineStruct(int id) : base(Globals.WamSqlConnectionString, id)
		{
			if (id == 0)
			{
				m_orgUsefulLife = 50;

				//mam 07072011
				m_rehabInterval = 25;
			}
		}

		public DisciplineStruct(string connectionString, int id)
			: base(connectionString, id)
		{
			if (id == 0)
			{
				m_orgUsefulLife = 50;

				//mam 07072011
				m_rehabInterval = 25;
			}
		}

		//mam 102309
		//public DisciplineStruct(System.Data.OleDb.OleDbConnection sqlConnection, int id)
		//	: base(sqlConnection.ConnectionString, id)
		public DisciplineStruct(SqlConnection sqlConnection, int id)
			: base(sqlConnection.ConnectionString, id)
		{
			if (id == 0)
			{
				m_orgUsefulLife = 50;

				//mam 07072011
				m_rehabInterval = 25;
			}
		}

		//mam 102309
		//protected DisciplineStruct(System.Data.OleDb.OleDbConnection sqlConnection, System.Data.OleDb.OleDbDataReader reader)
		//	: base(sqlConnection, reader)
		protected DisciplineStruct(SqlConnection sqlConnection, SqlDataReader reader)
			: base(sqlConnection, reader)
		{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_overrideAcquisitionCost = !reader.IsDBNull(col);
			m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_originalENR = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);
			m_concSpalling = (ItemStatus)reader.GetByte(col++);
			m_structExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_membExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_corrosionCoating = (ItemStatus)reader.GetByte(col++);
			m_paintGood = (ItemStatus)reader.GetByte(col++);
			m_visibleDeformities = (ItemStatus)reader.GetByte(col++);
			m_settingEvident = (ItemStatus)reader.GetByte(col++);
			m_roofExcessiveDegradation = (ItemStatus)reader.GetByte(col++);
			m_majorCracks = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_runningAtInspect = reader.GetBoolean(col++);

			//mam
			m_overrideCurrentValue = !reader.IsDBNull(col);
			m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			//</mam>

			//mam 050806
			m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_overrideRepairCost = !reader.IsDBNull(col);

			m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_rehabCost = Drive.SQL.ReadNullableDecimal(reader, col++);

			//mam 07072011 - no need for additional rehab values here because we are not updating the Access database to include them
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//InfoSetID = reader.GetInt32(col++);
			ComponentCipId = reader.GetInt32(col++);

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_originalENR = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);

			m_concSpalling = (ItemStatus)reader.GetByte(col++);
			m_structExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_membExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_corrosionCoating = (ItemStatus)reader.GetByte(col++);
			m_paintGood = (ItemStatus)reader.GetByte(col++);
			m_visibleDeformities = (ItemStatus)reader.GetByte(col++);
			m_settingEvident = (ItemStatus)reader.GetByte(col++);
			m_roofExcessiveDegradation = (ItemStatus)reader.GetByte(col++);
			m_majorCracks = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			//mam 102309
			//m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			//m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			//m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			//m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			//m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_assessedBy = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_equipmentNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_manufacturer = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_runHours = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			if (reader.IsDBNull(col)) m_installationYear = 0;
			else m_installationYear = reader.GetInt16(col);
			col++;
			m_photoCaption = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 03202012
			m_photoFileName = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 102309
			//m_photo = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_runningAtInspect = reader.GetBoolean(col++);

			//mam
			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;
			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			//m_rehabCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;
			m_rehabCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			//mam 07072011
			m_rehabCostYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 07072011 - set m_rehabInterval and m_rehabNext to zero if component cip mode is Replacement
			//if CipPlanningId = zero (the Major Component has no CipPlanningId), get rehab interval and rehab next from the database
			//if CipPlanningId = id for Replacement, set rehab interval and rehab next to zero
			//otherwise, get them from database

			//mam 07072011 begin
			m_rehabInterval = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			//mam 01222012 - no longer using override for Time to Next Rehab
			//m_overrideRehabNext = !reader.IsDBNull(col);

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//m_rehabNext = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabYearLast = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			//mam 07072011 end

			//if the planning mode is replacement, set the cache values to zero
			if (this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				m_rehabInterval = 0m;
				m_rehabNext = 0m;
			}

			//mam 07072011
			m_overrideNextReplacementYear = !reader.IsDBNull(col);
			m_nextReplacementYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 01222012
			m_replacementValueDesc = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_rehabCostDesc = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_overrideRehabYearNext = !reader.IsDBNull(col);
			m_rehabYearNext = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
		}

		//mam 03202012
		//@@@@
		protected void LoadRecordData(DataRow dataRow)
		{
			m_id = dataRow["disc2_id"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["disc2_id"]);

			if (m_id == 0)
			{
				return;
			}

			ComponentCipId = Convert.ToInt32(dataRow["CipPlanningId"]);

			m_componentID = Convert.ToInt32(dataRow["component_id"]);
			m_conditionRanking = (CondRank)Convert.ToByte(dataRow["disc2_conditionRanking"]);
			m_CWPAssetValue = Convert.ToDouble(dataRow["disc2_CWPAssetValue"]);
			m_orgUsefulLife = Convert.ToInt16(dataRow["disc2_originalUsefulLife"]);
			m_overrideAcquisitionCost = dataRow["disc2_acquisitionCost"] != DBNull.Value;
			m_acquisitionCost = dataRow["disc2_acquisitionCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["disc2_acquisitionCost"]);

			m_replacementValue = Convert.ToDecimal(dataRow["disc2_replacementValue"]);
			m_salvageValue = Convert.ToDecimal(dataRow["disc2_salvageValue"]);
			m_annualMaintCost = Convert.ToDecimal(dataRow["disc2_annualMaintCost"]);
			m_originalENR = Convert.ToInt32(dataRow["disc2_originalENR"]);
			m_currentENR = Convert.ToInt32(dataRow["disc2_currentENR"]);

			m_concSpalling = (ItemStatus)Convert.ToByte(dataRow["disc2_concSpalling"]);
			m_structExcessiveCorrosion = (ItemStatus)Convert.ToByte(dataRow["disc2_structExcessiveCorrosion"]);
			m_membExcessiveCorrosion = (ItemStatus)Convert.ToByte(dataRow["disc2_membExcessiveCorrosion"]);
			m_corrosionCoating = (ItemStatus)Convert.ToByte(dataRow["disc2_corrosionCoating"]);
			m_paintGood = (ItemStatus)Convert.ToByte(dataRow["disc2_paintGood"]);
			m_visibleDeformities = (ItemStatus)Convert.ToByte(dataRow["disc2_visibleDeformities"]);
			m_settingEvident = (ItemStatus)Convert.ToByte(dataRow["disc2_settingEvident"]);
			m_roofExcessiveDegradation = (ItemStatus)Convert.ToByte(dataRow["disc2_roofExcessiveDegradation"]);
			m_majorCracks = (ItemStatus)Convert.ToByte(dataRow["disc2_majorCracks"]);

			m_dateInspected = Convert.ToDateTime(dataRow["disc2_dateInspected"]);
			m_inspectionYear = m_dateInspected;

			m_assessedBy = dataRow["disc2_assessedBy"] == DBNull.Value ? "" : dataRow["disc2_assessedBy"].ToString();
			m_equipmentNumber = dataRow["disc2_equipmentNumber"] == DBNull.Value ? "" : dataRow["disc2_equipmentNumber"].ToString();
			m_manufacturer = dataRow["disc2_manufacturer"] == DBNull.Value ? "" : dataRow["disc2_manufacturer"].ToString();
			m_runHours = dataRow["disc2_runHours"] == DBNull.Value ? "" : dataRow["disc2_runHours"].ToString();
			m_installationYear = dataRow["disc2_installationYear"] == DBNull.Value ? Convert.ToInt16(0) : Convert.ToInt16(dataRow["disc2_installationYear"]);
			m_photoCaption = dataRow["disc2_photoCaption"] == DBNull.Value ? "" : dataRow["disc2_photoCaption"].ToString();
			m_photoFileName = dataRow["PhotoFileName"] == DBNull.Value ? "" : dataRow["PhotoFileName"].ToString();

			m_comments = dataRow["disc2_comments"] == DBNull.Value ? "" : dataRow["disc2_comments"].ToString();
			m_runningAtInspect = dataRow["disc2_runningAtInspect"] == DBNull.Value ? false : Convert.ToBoolean(dataRow["disc2_runningAtInspect"]);
			m_overrideCurrentValue = dataRow["CurrentValue"] != DBNull.Value;
			m_currentValue = dataRow["CurrentValue"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["CurrentValue"]);
			m_replacementValueYear = dataRow["ReplacementValueYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["ReplacementValueYear"]);

			m_overrideRepairCost = dataRow["RepairCost"] != DBNull.Value;
			m_repairCost = dataRow["RepairCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RepairCost"]);
			m_rehabCost = dataRow["RehabCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RehabCost"]);
			m_rehabCostYear = dataRow["RehabCostYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabCostYear"]);
			m_rehabInterval = dataRow["RehabInterval"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RehabInterval"]);
			m_rehabYearLast = dataRow["RehabYearLast"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabYearLast"]);

			//if the planning mode is replacement, set the cache values to zero
			if (this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				m_rehabInterval = 0m;
				m_rehabNext = 0m;
			}

			m_overrideNextReplacementYear = dataRow["NextReplacementYear"] != DBNull.Value;
			m_nextReplacementYear = dataRow["NextReplacementYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["NextReplacementYear"]);

			m_replacementValueDesc = dataRow["ReplacementValueDesc"] == DBNull.Value ? "" : dataRow["ReplacementValueDesc"].ToString();
			m_rehabCostDesc = dataRow["RehabCostDesc"] == DBNull.Value ? "" : dataRow["RehabCostDesc"].ToString();
			m_overrideRehabYearNext = dataRow["RehabYearNext"] != DBNull.Value;
			m_rehabYearNext = dataRow["RehabYearNext"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabYearNext"]);
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/

		//mam - compare Disciplines by their various values
		public new int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)		
		{
			DisciplineStruct rhs = obj as DisciplineStruct;
			int result = 0;
			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a discipline");

			return result;
		}
		//</mam>

		//mam - compare Disciplines by their various values
		private int CompareToEach(DisciplineStruct rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;
			
			switch (which)
			{
				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
				//mam

				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.AcquisitionCost.CompareTo(rhs.AcquisitionCost);
					else
						result = rhs.AcquisitionCost.CompareTo(this.AcquisitionCost);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.AcquisitionCostEscalated.CompareTo(rhs.AcquisitionCostEscalated);
					else
						result = rhs.AcquisitionCostEscalated.CompareTo(this.AcquisitionCostEscalated);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.RehabCost.CompareTo(rhs.RehabCost);
					else
						result = rhs.RehabCost.CompareTo(this.RehabCost);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabInterval:
					if (lowToHigh)
						result = this.RehabInterval.CompareTo(rhs.RehabInterval);
					else
						result = rhs.RehabInterval.CompareTo(this.RehabInterval);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabNext:
					if (lowToHigh)
						result = this.RehabNext.CompareTo(rhs.RehabNext);
					else
						result = rhs.RehabNext.CompareTo(this.RehabNext);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearLast:
					if (lowToHigh)
						result = this.RehabYearLast.CompareTo(rhs.RehabYearLast);
					else
						result = rhs.RehabYearLast.CompareTo(this.RehabYearLast);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearNext:
					if (lowToHigh)
						result = this.RehabYearNext.CompareTo(rhs.RehabYearNext);
					else
						result = rhs.RehabYearNext.CompareTo(this.RehabYearNext);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementNext:
					if (lowToHigh)
						result = this.ReplacementNext.CompareTo(rhs.ReplacementNext);
					else
						result = rhs.ReplacementNext.CompareTo(this.ReplacementNext);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.NextReplacementYear:
					if (lowToHigh)
						result = this.NextReplacementYear.CompareTo(rhs.NextReplacementYear);
					else
						result = rhs.NextReplacementYear.CompareTo(this.NextReplacementYear);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.ReplacementValue.CompareTo(rhs.ReplacementValue);
					else
						result = rhs.ReplacementValue.CompareTo(this.ReplacementValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.SalvageValue.CompareTo(rhs.SalvageValue);
					else
						result = rhs.SalvageValue.CompareTo(this.SalvageValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					if (lowToHigh)
						result = this.GetEvaluatedValue().CompareTo(rhs.GetEvaluatedValue());
					else
						result = rhs.GetEvaluatedValue().CompareTo(this.GetEvaluatedValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					if (lowToHigh)
						result = this.GetRepairCost().CompareTo(rhs.GetRepairCost());
					else
						result = rhs.GetRepairCost().CompareTo(this.GetRepairCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.AnnualMaintCost.CompareTo(rhs.AnnualMaintCost);
					else
						result = rhs.AnnualMaintCost.CompareTo(this.AnnualMaintCost);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InstallYear:
					if (lowToHigh)
						result = this.InstallationYear.CompareTo(rhs.InstallationYear);
					else
						result = rhs.InstallationYear.CompareTo(this.InstallationYear);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InspectionYear:
					if (lowToHigh)
						result = this.DateInspected.CompareTo(rhs.DateInspected);
					else
						result = rhs.DateInspected.CompareTo(this.DateInspected);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
					if (lowToHigh)
						result = this.OrgUsefulLife.CompareTo(rhs.OrgUsefulLife);
					else
						result = rhs.OrgUsefulLife.CompareTo(this.OrgUsefulLife);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
					if (lowToHigh)
						result = this.GetRemainingUsefulLife().CompareTo(rhs.GetRemainingUsefulLife());
					else
						result = rhs.GetRemainingUsefulLife().CompareTo(this.GetRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
					if (lowToHigh)
						result = this.GetEvaluatedRemainingUsefulLife().CompareTo(rhs.GetEvaluatedRemainingUsefulLife());
					else
						result = rhs.GetEvaluatedRemainingUsefulLife().CompareTo(this.GetEvaluatedRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
					if (lowToHigh)
						result = this.GetEconomicUsefulLife().CompareTo(rhs.GetEconomicUsefulLife());
					else
						result = rhs.GetEconomicUsefulLife().CompareTo(this.GetEconomicUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					if (lowToHigh)
						result = this.ConditionRanking.CompareTo(rhs.ConditionRanking);
					else
						result = rhs.ConditionRanking.CompareTo(this.ConditionRanking);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
					if (lowToHigh)
						result = this.GetLevelOfService().CompareTo(rhs.GetLevelOfService());
					else
						result = rhs.GetLevelOfService().CompareTo(this.GetLevelOfService());

					break;

//					case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
//					case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
//				case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
//					if (lowToHigh)
//						result = this.GetAverageRisk().CompareTo(rhs.GetAverageRisk());
//					else
//						result = rhs.GetAverageRisk().CompareTo(this.GetAverageRisk());
//
//					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;

			}
			return result;
		}
		//</mam>
		#endregion /***** IComparable Members *****/

		#region /***** Nested Class DisciplineComparer *****/
		//mam
		public class DisciplineComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				DisciplineStruct l = (DisciplineStruct) lhs;
				DisciplineStruct r = (DisciplineStruct) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}
			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class DisciplineComparer *****/

		#region /****** SQL Statements ******/

		//mam 102309
		//protected override string GetLoadSql(object id)
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//builder.Append("Facilities.infoset_id, " );
			builder.Append("MajorComponents.CipPlanningId, " );

			builder.Append("disc2_id, DisciplineStruct.component_id, disc2_conditionRanking, disc2_CWPAssetValue, ");
			builder.Append("disc2_originalUsefulLife, ");
			builder.Append("disc2_acquisitionCost, disc2_replacementValue, ");
			builder.Append("disc2_salvageValue, disc2_annualMaintCost, ");
			builder.Append("disc2_originalENR, disc2_currentENR, ");
			builder.Append("disc2_concSpalling, ");
			builder.Append("disc2_structExcessiveCorrosion, disc2_membExcessiveCorrosion, ");
			builder.Append("disc2_corrosionCoating, disc2_paintGood, ");
			builder.Append("disc2_visibleDeformities, disc2_settingEvident, ");
			builder.Append("disc2_roofExcessiveDegradation, disc2_majorCracks, ");
			builder.Append("disc2_dateInspected, disc2_assessedBy, disc2_equipmentNumber, ");
			builder.Append("disc2_manufacturer, disc2_runHours, disc2_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc2_photoCaption, DisciplineStruct.PhotoFileName, disc2_comments, disc2_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");
			//</mam>

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.Append(", RehabInterval");

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//builder.Append(", RehabNext");

			builder.Append(", RehabYearLast");
			//mam 07072011 end

			builder.Append(", NextReplacementYear");

			//mam 01222012
			builder.Append(", ReplacementValueDesc");
			builder.Append(", RehabCostDesc");
			builder.Append(", RehabYearNext");

			builder.Append(" FROM DisciplineStruct");

			//mam 07072011 - need cip planning id in loadrecord, so must get it here
			builder.Append(" INNER JOIN MajorComponents ON DisciplineStruct.component_id = MajorComponents.component_id");
			//builder.Append("INNER JOIN TreatmentProcesses ON MajorComponents.process_id = TreatmentProcesses.process_id ");
			//builder.Append("INNER JOIN Facilities ON TreatmentProcesses.facility_id = Facilities.facility_id ");

			builder.AppendFormat(" WHERE disc2_id={0}", id);

			return builder.ToString();
		}

		//mam 102309
//		public override string GetInsertSqlForCopy()
//		{
//			return GetInsertSql();
//		}

		//mam 102309
//		public override string GetUpdateSqlForImport()
//		{
//			return GetUpdateSql();
//		}

		//mam 07072011 - new save routine only for saving disciplines that are currently being imported
		public bool SaveForImport()
		{
			forImport = true;
			return Save();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - added bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}

					//mam 01222012 - let's go back to using InvokeChangeEvent rather than manually adding the discipline to the cache
					//mam - add discipline to cache manually, below;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));

					//the discipline is not getting added to the cache by calling InvokeChangeEvent - add it manually
					//if (add == Drive.Synchronization.SyncAction.Add)
					//{
					//	DisciplineCache disciplineCache = CacheManager.GetDisciplineCache(this.InfoSetID);
					//	disciplineCache.AddDisciplineToCache(this.ComponentID, this);
					//}
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				//mam 07072011 - OK to just return false without throwing an error or setting up an error row 
				//	in an error grid because this should be handled by the caller
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;

				//mam 07072011 - reset variable after saving
				forImport = false;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO DisciplineStruct (");

			builder.Append("component_id, disc2_conditionRanking, disc2_CWPAssetValue, ");
			builder.Append("disc2_originalUsefulLife, ");
			builder.Append("disc2_acquisitionCost, disc2_replacementValue, ");
			builder.Append("disc2_salvageValue, disc2_annualMaintCost, ");
			builder.Append("disc2_originalENR, disc2_currentENR, ");
			builder.Append("disc2_concSpalling, ");
			builder.Append("disc2_structExcessiveCorrosion, disc2_membExcessiveCorrosion, ");
			builder.Append("disc2_corrosionCoating, disc2_paintGood, ");
			builder.Append("disc2_visibleDeformities, disc2_settingEvident, ");
			builder.Append("disc2_roofExcessiveDegradation, disc2_majorCracks, ");
			builder.Append("disc2_dateInspected, disc2_assessedBy, disc2_equipmentNumber, ");
			builder.Append("disc2_manufacturer, disc2_runHours, disc2_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc2_photoCaption, PhotoFileName, disc2_comments, disc2_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");
			//</mam>

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.Append(", RehabInterval");

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//builder.Append(", RehabNext");

			builder.Append(", RehabYearLast");
			//mam 07072011 end

			//mam 07072011
			builder.Append(", NextReplacementYear");

			//mam01222012
			builder.Append(", ReplacementValueDesc");
			builder.Append(", RehabCostDesc");
			builder.Append(", RehabYearNext");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("{0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("{0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("{0}, ", m_orgUsefulLife);

			if (m_overrideAcquisitionCost)
				builder.AppendFormat("{0:F2}, ", m_acquisitionCost);
			else
				builder.Append("NULL, ");

			builder.AppendFormat("{0:F2}, ", m_replacementValue);
			builder.AppendFormat("{0:F2}, ", m_salvageValue);
			builder.AppendFormat("{0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("{0}, ", m_originalENR);
			builder.AppendFormat("{0}, ", m_currentENR);

			builder.AppendFormat("{0}, ", ((byte)m_concSpalling));
			builder.AppendFormat("{0}, ", ((byte)m_structExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_membExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_corrosionCoating));
			builder.AppendFormat("{0}, ", ((byte)m_paintGood));
			builder.AppendFormat("{0}, ", ((byte)m_visibleDeformities));
			builder.AppendFormat("{0}, ", ((byte)m_settingEvident));
			builder.AppendFormat("{0}, ", ((byte)m_roofExcessiveDegradation));
			builder.AppendFormat("{0}, ", ((byte)m_majorCracks));
			builder.AppendFormat("'{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_runHours));

			builder.AppendFormat("{0}, ", m_installationYear);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption));

			//mam 03202012
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			//mam 102309
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photo));

			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0} ", Drive.SQL.BoolToBit(m_runningAtInspect));

			//mam
			if (m_overrideCurrentValue)
				builder.AppendFormat(", {0:F2} ", m_currentValue);
			else
				builder.Append(", NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", {0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", {0:F2} ", m_repairCost);
			else
				builder.Append(", NULL ");

			//mam 050806
			builder.AppendFormat(", {0:F2} ", m_rehabCost);

			//mam 07072011 begin
			builder.AppendFormat(", {0}", m_rehabCostYear);
			builder.AppendFormat(", {0:F1}", m_rehabInterval);

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//if (m_overrideRehabNext)
			//	builder.AppendFormat(", {0:F1}", m_rehabNext);
			//else
			//	builder.Append(", NULL");

			builder.AppendFormat(", {0}", m_rehabYearLast);
			//mam 07072011 end

			//mam 07072011
			if (m_overrideNextReplacementYear)
				builder.AppendFormat(", {0}", m_nextReplacementYear);
			else
				builder.Append(", NULL");

			//mam 01222012
			builder.AppendFormat(", '{0}'", Drive.SQL.PadString(m_replacementValueDesc));
			builder.AppendFormat(", '{0}'", Drive.SQL.PadString(m_rehabCostDesc));
			if (m_overrideRehabYearNext)
				builder.AppendFormat(", {0:F1}", m_rehabYearNext);
			else
				builder.Append(", NULL");

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE DisciplineStruct SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("disc2_conditionRanking={0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("disc2_CWPAssetValue={0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("disc2_originalUsefulLife={0}, ", m_orgUsefulLife);

			if (m_overrideAcquisitionCost)
				builder.AppendFormat("disc2_acquisitionCost={0:F2}, ", m_acquisitionCost);
			else
				builder.Append("disc2_acquisitionCost=NULL, ");

			builder.AppendFormat("disc2_replacementValue={0:F2}, ", m_replacementValue);
			builder.AppendFormat("disc2_salvageValue={0:F2}, ", m_salvageValue);
			builder.AppendFormat("disc2_annualMaintCost={0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("disc2_originalENR={0}, ", m_originalENR);
			builder.AppendFormat("disc2_currentENR={0}, ", m_currentENR);

			builder.AppendFormat("disc2_concSpalling={0}, ", ((byte)m_concSpalling));
			builder.AppendFormat("disc2_structExcessiveCorrosion={0}, ", ((byte)m_structExcessiveCorrosion));
			builder.AppendFormat("disc2_membExcessiveCorrosion={0}, ", ((byte)m_membExcessiveCorrosion));
			builder.AppendFormat("disc2_corrosionCoating={0}, ", ((byte)m_corrosionCoating));
			builder.AppendFormat("disc2_paintGood={0}, ", ((byte)m_paintGood));
			builder.AppendFormat("disc2_visibleDeformities={0}, ", ((byte)m_visibleDeformities));
			builder.AppendFormat("disc2_settingEvident={0}, ", ((byte)m_settingEvident));
			builder.AppendFormat("disc2_roofExcessiveDegradation={0}, ", ((byte)m_roofExcessiveDegradation));
			builder.AppendFormat("disc2_majorCracks={0}, ", ((byte)m_majorCracks));
			builder.AppendFormat("disc2_dateInspected='{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("disc2_assessedBy='{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("disc2_equipmentNumber='{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("disc2_manufacturer='{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("disc2_runHours='{0}', ", Drive.SQL.PadString(m_runHours));
			builder.AppendFormat("disc2_installationYear={0}, ", m_installationYear);
			builder.AppendFormat("disc2_photoCaption={0}, ", Drive.SQL.StringToDBString(m_photoCaption));

			//mam 03202012
			builder.AppendFormat("PhotoFileName={0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			builder.AppendFormat("disc2_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("disc2_runningAtInspect={0} ", Drive.SQL.BoolToBit(m_runningAtInspect));

			//mam
			if (m_overrideCurrentValue)
				builder.AppendFormat(", CurrentValue={0:F2} ", m_currentValue);
			else
				builder.Append(", CurrentValue=NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", ReplacementValueYear={0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", RepairCost={0:F2} ", m_repairCost);
			else
				builder.Append(", RepairCost=NULL ");

			//mam 01222012 - planning mode now affects next replacement year, so check the planning mode
			if (forImport || this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				//planning mode = replacement
			
				//mam 07072011
				if (m_overrideNextReplacementYear)
					builder.AppendFormat(", NextReplacementYear={0}", m_nextReplacementYear);
				else
					builder.Append(", NextReplacementYear=NULL ");
			}

			//mam 07072011 - add check of CipPlanningId
			//	if the rehab interval and rehab next are zero because cip mode is Replacement, don't save them to the database
			//	(they are read only when cip mode is Replacement)
			//	so that when the user changes the cip planning mode, rehab interval and rehab next can be resurrected
			//if CipPlanningId is anything other than the Replacement id, save rehab interval and rehab next to the database

			//mam 050806
			builder.AppendFormat(", RehabCost={0:F2} ", m_rehabCost);

			//mam 07072011
			builder.AppendFormat(", RehabCostYear={0} ", m_rehabCostYear);

			//mam 07072011 begin
			if (forImport || this.ComponentCipId != Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				//planning mode = rehabilitation or we are saving a discipline that is currently being imported

				builder.AppendFormat(", RehabInterval={0:F1}", m_rehabInterval);

				//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
				//if (m_overrideRehabNext)
				//	builder.AppendFormat(", RehabNext={0:F1}", m_rehabNext);
				//else
				//	builder.Append(", RehabNext=NULL");

				//mam 01222012
				if (m_overrideRehabYearNext)
					builder.AppendFormat(", RehabYearNext={0:F0}", m_rehabYearNext);
				else
					builder.Append(", RehabYearNext=NULL");
			}
			builder.AppendFormat(", RehabYearLast={0}", m_rehabYearLast);
			//mam 07072011 end

			//mam 01222012
			builder.AppendFormat(", ReplacementValueDesc='{0}'", Drive.SQL.PadString(m_replacementValueDesc));
			builder.AppendFormat(", RehabCostDesc='{0}'", Drive.SQL.PadString(m_rehabCostDesc));
			//if (m_overrideRehabYearNext)
			//	builder.AppendFormat(", RehabYearNext={0}", m_rehabYearNext);
			//else
			//	builder.Append(", RehabYearNext=NULL");

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.AppendFormat(" WHERE (disc2_id={0})", ID);

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetDeleteSql()
		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From DisciplineStruct WHERE disc2_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public override string Name
		{
			get { return "Structural / Architectural"; }
		}

		public override DisciplineType Type
		{
			get { return DisciplineType.Structural; }
		}

		public ItemStatus	ConcreteSpalling
		{
			get { return m_concSpalling; }
			set { m_concSpalling = value; }
		}

		public ItemStatus	StructExcessiveCorrosion
		{
			get { return m_structExcessiveCorrosion; }
			set { m_structExcessiveCorrosion = value; }
		}

		public ItemStatus	MembExcessiveCorrosion
		{
			get { return m_membExcessiveCorrosion; }
			set { m_membExcessiveCorrosion = value; }
		}

		public ItemStatus	CorrosionCoating
		{
			get { return m_corrosionCoating; }
			set { m_corrosionCoating = value; }
		}

		public ItemStatus	PaintGood
		{
			get { return m_paintGood; }
			set { m_paintGood = value; }
		}

		public ItemStatus	VisibleDeformities
		{
			get { return m_visibleDeformities; }
			set { m_visibleDeformities = value; }
		}

		public ItemStatus	SettingEvident
		{
			get { return m_settingEvident; }
			set { m_settingEvident = value; }
		}

		public ItemStatus	RoofExcessiveDegradation
		{
			get { return m_roofExcessiveDegradation; }
			set { m_roofExcessiveDegradation = value; }
		}

		public ItemStatus	MajorCracks
		{
			get { return m_majorCracks; }
			set { m_majorCracks = value; }
		}

		public DateTime		DateInspected
		{
			get { return m_dateInspected; }
			set 
			{ 
				m_dateInspected = value; 

				//mam
				//m_inspectionYear = m_dateInspected.Year;
				m_inspectionYear = m_dateInspected;
				//</mam>
			}
		}

		public string		EquipmentNumber
		{
			get { return m_equipmentNumber; }
			set
			{
				if (value.Length > 255)
					m_equipmentNumber = value.Substring(255);
				else
					m_equipmentNumber = value;
			}
		}

		public string		AssessedBy
		{
			get { return m_assessedBy; }
			set
			{
				if (value.Length > 255)
					m_assessedBy = value.Substring(255);
				else
					m_assessedBy = value;
			}
		}

		public string		Manufacturer
		{
			get { return m_manufacturer; }
			set
			{
				if (value.Length > 255)
					m_manufacturer = value.Substring(255);
				else
					m_manufacturer = value;
			}
		}

		public string		RunHours
		{
			get { return m_runHours; }
			set
			{
				if (value.Length > 255)
					m_runHours = value.Substring(255);
				else
					m_runHours = value;
			}
		}

		public string		CaptionPhoto
		{
			get { return m_photoCaption; }
			set
			{
				if (value.Length > 255)
					m_photoCaption = value.Substring(255);
				else
					m_photoCaption = value;
			}
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return m_photoFileName; }
			set { m_photoFileName = value; }
		}

		//mam 102309
//		public override string Photo
//		{
//			get { return m_photo; }
//			set
//			{
//				if (value.Length > 255)
//					m_photo = value.Substring(255);
//				else
//					m_photo = value;
//			}
//		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public bool			RunningAtInspect
		{
			get { return m_runningAtInspect; }
			set { m_runningAtInspect = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		//mam
		public static DisciplineComparer GetComparer()
		{
			return new DisciplineComparer();
		}
		//</mam>

		//mam - added parameter
		public override string GetXML(bool includePhotos, string selectedFilters)
		{
			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();
			MajorComponent component = GetMajorComponent();
			TreatmentProcess process = CacheManager.GetTreatmentProcess(InfoSetID, component.ProcessID);
			Facility		facility = CacheManager.GetFacility(InfoSetID, process.FacilityID);

			builder.Append("<DisciplineStructuralData>\r\n");

			// Populate the basic data
			builder.Append("\t<DisciplineStructural>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
			builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", process.Name);
			builder.AppendFormat("\t\t<ComponentName><![CDATA[{0}]]></ComponentName>\r\n", component.Name);
			builder.AppendFormat("\t\t<Discipline><![CDATA[{0}]]></Discipline>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", facility.CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", facility.CurrentENR);

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			//mam 112806
			builder.AppendFormat("\t\t<Retired><![CDATA[{0}]]></Retired>\r\n", component.Retired);

			//mam
			if (includePhotos)
			{
			//</mam>
				//mam 03202012 - changed GetImagePath to PhotoFileName (don't include path in photo file name because it is a 
				//	mapped path on the user's machine that will be different for all users)
				//builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePath());
				builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", PhotoFileName);

				builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto);
			}

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", 0);
				builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 0);
			}
			else
			{
				//mam
				builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", Convert.ToInt32(m_overrideAcquisitionCost));
				builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", Convert.ToInt32(m_overrideCurrentValue));
				//</mam>
			}

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", 0);	//999999
			}
			else
			{
				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", AcquisitionCost);
				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", ReplacementValue);
			}

			//mam 01222012
			builder.AppendFormat("\t\t<ReplacementValueDesc><![CDATA[{0}]]></ReplacementValueDesc>\r\n", ReplacementValueDesc);

			builder.AppendFormat("\t\t<SalvageValue><![CDATA[{0:F0}]]></SalvageValue>\r\n", SalvageValue);
			builder.AppendFormat("\t\t<AnnualMaintenanceCost><![CDATA[{0:F0}]]></AnnualMaintenanceCost>\r\n", AnnualMaintCost);
			builder.AppendFormat("\t\t<InstallYear><![CDATA[{0:F0}]]></InstallYear>\r\n", InstallationYear);
			builder.AppendFormat("\t\t<OriginalENR><![CDATA[{0:F0}]]></OriginalENR>\r\n", OriginalENR);
			builder.AppendFormat("\t\t<OrgUsefulLife><![CDATA[{0:F1}]]></OrgUsefulLife>\r\n", OrgUsefulLife);
			builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", EnumHandlers.GetLOSShort(component.LOS));
			builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", EnumHandlers.GetConditionRankShort(ConditionRanking));
			builder.AppendFormat("\t\t<DateOfInspection><![CDATA[{0}]]></DateOfInspection>\r\n", DateInspected.ToString("MM/dd/yyyy"));

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", 0);	//999999
			}
			else
			{
				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", GetBookValue());
				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", GetAnnualDepreciation());
				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", GetCumulativeDepreciation());
			}

			builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F1}]]></RemainingUsefulLife>\r\n", GetRemainingUsefulLife());

			//mam 112806 - check condition and overrides
			if (ConditionRanking == CondRank.No)
			{
				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", 0.ToString("$#,##0"));	//999999
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", 0);	//999999
				}
				else
				{
					if (OverrideCurrentValue)
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", GetCurrentValue().ToString("$#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", "N/A");
					}

					if (OverrideRepairCost)
					{
						//mam 07072011
						//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost().ToString("$#,##0"));
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost());
					}
					else
					{
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", 0.ToString("$#,##0"));	//999999
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", GetCurrentValue().ToString("$#,##0"));

					//mam 07072011
					//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost().ToString("$#,##0"));
					//builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", GetEvaluatedValue().ToString("$#,##0"));
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost());
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", GetEvaluatedValue());
				}

				builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", GetEvaluatedRemainingUsefulLife());
				builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", GetEconomicUsefulLife());
			}

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", 0);	//999999
			}
			else
			{
				//mam 050806
				builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", AcquisitionCostEscalated);
				builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", RehabCost);
			}

			//mam 01222012
			builder.AppendFormat("\t\t<RehabCostDesc><![CDATA[{0}]]></RehabCostDesc>\r\n", RehabCostDesc);

			//mam 07072011 - new rehab values
			builder.AppendFormat("\t\t<RehabCostYear><![CDATA[{0:F0}]]></RehabCostYear>\r\n", RehabCostYear);
			builder.AppendFormat("\t\t<RehabInterval><![CDATA[{0:F1}]]></RehabInterval>\r\n", RehabInterval);
			builder.AppendFormat("\t\t<RehabYearLast><![CDATA[{0:F0}]]></RehabYearLast>\r\n", RehabYearLast);
			builder.AppendFormat("\t\t<RehabNext><![CDATA[{0:F1}]]></RehabNext>\r\n", RehabNext);
			builder.AppendFormat("\t\t<RehabYearNext><![CDATA[{0:F0}]]></RehabYearNext>\r\n", RehabYearNext);

			//mam 01222012 - no longer using override for Time to Next Rehab
			//builder.AppendFormat("\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", Convert.ToInt32(m_overrideRehabNext));

			//mam 01222012
			builder.AppendFormat("\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", Convert.ToInt32(m_overrideRehabYearNext));

			builder.AppendFormat("\t\t<ReplacementValueYear><![CDATA[{0:F0}]]></ReplacementValueYear>\r\n", ReplacementValueYear);
			builder.AppendFormat("\t\t<ReplacementValueYearENR><![CDATA[{0:F0}]]></ReplacementValueYearENR>\r\n", ReplacementENR);

			//mam 01222012
			builder.AppendFormat("\t\t<ReplacementNext><![CDATA[{0:F1}]]></ReplacementNext>\r\n", ReplacementNext);

			//mam 07072011
			builder.AppendFormat("\t\t<NextReplacementYear><![CDATA[{0:F0}]]></NextReplacementYear>\r\n", NextReplacementYear);
			builder.AppendFormat("\t\t<OverrideNextReplacementYear><![CDATA[{0}]]></OverrideNextReplacementYear>\r\n", Convert.ToInt32(m_overrideNextReplacementYear));

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 0);
			}
			else
			{
				builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", Convert.ToInt32(m_overrideRepairCost));
			}

			builder.AppendFormat("\t\t<AssessedBy><![CDATA[{0}]]></AssessedBy>\r\n", AssessedBy);
			builder.AppendFormat("\t\t<EquipmentNum><![CDATA[{0}]]></EquipmentNum>\r\n", EquipmentNumber);
			builder.AppendFormat("\t\t<Manufacturer><![CDATA[{0}]]></Manufacturer>\r\n", Manufacturer);
			builder.AppendFormat("\t\t<RunHours><![CDATA[{0}]]></RunHours>\r\n", RunHours);
			builder.AppendFormat("\t\t<RunningAtInspection><![CDATA[{0}]]></RunningAtInspection>\r\n", RunningAtInspect);

			builder.AppendFormat("\t\t<ConcSpalling><![CDATA[{0}]]></ConcSpalling>\r\n", 
				EnumHandlers.GetItemStatusShort(m_concSpalling));
			builder.AppendFormat("\t\t<StructExcessiveCorrosion><![CDATA[{0}]]></StructExcessiveCorrosion>\r\n", 
				EnumHandlers.GetItemStatusShort(m_structExcessiveCorrosion));
			builder.AppendFormat("\t\t<MembExcessiveCorrosion><![CDATA[{0}]]></MembExcessiveCorrosion>\r\n", 
				EnumHandlers.GetItemStatusShort(m_membExcessiveCorrosion));
			builder.AppendFormat("\t\t<CorrosionCoating><![CDATA[{0}]]></CorrosionCoating>\r\n", 
				EnumHandlers.GetItemStatusShort(m_corrosionCoating));
			builder.AppendFormat("\t\t<PaintGood><![CDATA[{0}]]></PaintGood>\r\n", 
				EnumHandlers.GetItemStatusShort(m_paintGood));
			builder.AppendFormat("\t\t<VisibleDeformities><![CDATA[{0}]]></VisibleDeformities>\r\n", 
				EnumHandlers.GetItemStatusShort(m_visibleDeformities));
			builder.AppendFormat("\t\t<SettingEvident><![CDATA[{0}]]></SettingEvident>\r\n", 
				EnumHandlers.GetItemStatusShort(m_settingEvident));
			builder.AppendFormat("\t\t<RoofExcessiveDegradation><![CDATA[{0}]]></RoofExcessiveDegradation>\r\n", 
				EnumHandlers.GetItemStatusShort(m_roofExcessiveDegradation));
			builder.AppendFormat("\t\t<MajorCracks><![CDATA[{0}]]></MajorCracks>\r\n", 
				EnumHandlers.GetItemStatusShort(m_majorCracks));

			builder.Append("\t</DisciplineStructural>\r\n");
			builder.Append("</DisciplineStructuralData>\r\n");
			return builder.ToString();
		}

		public override void CopyTo(Discipline copyBase)
		{
			base.CopyTo(copyBase);

			DisciplineStruct copy = (DisciplineStruct)copyBase;

			copy.m_concSpalling = m_concSpalling;
			copy.m_structExcessiveCorrosion = m_structExcessiveCorrosion;
			copy.m_membExcessiveCorrosion = m_membExcessiveCorrosion;
			copy.m_corrosionCoating = m_corrosionCoating;
			copy.m_paintGood = m_paintGood;
			copy.m_visibleDeformities = m_visibleDeformities;
			copy.m_settingEvident = m_settingEvident;
			copy.m_roofExcessiveDegradation = m_roofExcessiveDegradation;
			copy.m_majorCracks = m_majorCracks;
			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;
			copy.m_equipmentNumber = m_equipmentNumber;
			copy.m_manufacturer = m_manufacturer;
			copy.m_runHours = m_runHours;
			copy.m_photoCaption = m_photoCaption;

			//mam 03202012
			copy.m_photoFileName = m_photoFileName;

			//mam 102309
			//copy.m_photo = m_photo;

			copy.m_comments = m_comments;
			copy.m_runningAtInspect = m_runningAtInspect;
		}

		//mam - allow or disallow copying of photo
		public override void CopyTo(Discipline copyBase, bool copyPhoto, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			base.CopyTo(copyBase);

			DisciplineStruct copy = (DisciplineStruct)copyBase;

			//mam 07072011
			//check component planning mode, and get rehab int and rehab next from database if planning mode = replacement

			//mam 01222012
			DataAccess dataAccess = new DataAccess();
			try
			{

				if (IsComponentZeroRehab)
				{
					//mam 01222012
					//DataAccess dataAccess = new DataAccess();
					//try
					//{
					StringBuilder builder = new StringBuilder();

					//mam 01222012
					//builder.AppendFormat("SELECT RehabInterval, RehabNext FROM DisciplineStruct WHERE disc2_id = {0}", this.ID);
					builder.AppendFormat("SELECT RehabInterval, RehabYearNext FROM DisciplineStruct WHERE disc2_id = {0}", this.ID);

					DataTable dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
					copy.m_rehabInterval = dataTable.Rows[0]["RehabInterval"] == DBNull.Value ? 0m : Convert.ToDecimal(dataTable.Rows[0]["RehabInterval"]);

					//mam 01222012 - no longer overriding rehabNext, so it is no longer stored in the database
					//copy.m_rehabNext = dataTable.Rows[0]["RehabNext"] == DBNull.Value ? 0m : Convert.ToDecimal(dataTable.Rows[0]["RehabNext"]);

					//mam 01222012
					copy.m_rehabYearNext = dataTable.Rows[0]["RehabYearNext"] == DBNull.Value ? 0 : Convert.ToInt32(dataTable.Rows[0]["RehabYearNext"]);
					//}
					//mam 01222012
					//catch(Exception ex)
					//{
					//	Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, ex.Message);
					//}
					//finally
					//{
					//	dataAccess = null;
					//}
				}
				else
				{
					//mam 01222012
					StringBuilder builder = new StringBuilder();
					builder.AppendFormat("SELECT NextReplacementYear FROM DisciplineStruct WHERE disc2_id = {0}", this.ID);
					DataTable dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
					copy.m_nextReplacementYear = dataTable.Rows[0]["NextReplacementYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataTable.Rows[0]["NextReplacementYear"]);
				}
			}
			catch(Exception ex)
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, ex.Message);
			}
			finally
			{
				dataAccess = null;
			}

			copy.m_concSpalling = m_concSpalling;
			copy.m_structExcessiveCorrosion = m_structExcessiveCorrosion;
			copy.m_membExcessiveCorrosion = m_membExcessiveCorrosion;
			copy.m_corrosionCoating = m_corrosionCoating;
			copy.m_paintGood = m_paintGood;
			copy.m_visibleDeformities = m_visibleDeformities;
			copy.m_settingEvident = m_settingEvident;
			copy.m_roofExcessiveDegradation = m_roofExcessiveDegradation;
			copy.m_majorCracks = m_majorCracks;
			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;
			copy.m_equipmentNumber = m_equipmentNumber;
			copy.m_manufacturer = m_manufacturer;
			copy.m_runHours = m_runHours;

			if (copyPhoto)
			{
				copy.m_photoCaption = m_photoCaption;

				//mam 03202012
				copy.m_photoFileName = m_photoFileName;

				//mam 102309
				//copy.m_photo = m_photo;
			}

			copy.m_comments = m_comments;
			copy.m_runningAtInspect = m_runningAtInspect;
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static DisciplineStruct LoadForComponentOleDb(int componentID)
		{
			return LoadForComponent(WamSourceOleDb.CurrentSource.ConnectionString, componentID);
			//return LoadForComponent(Globals.WamSqlConnectionString, componentID);
		}

		//mam 102309
		public static DisciplineStruct LoadForComponentOleDb(string connectionString, int componentID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			DisciplineStruct retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponentOleDb(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static DisciplineStruct LoadForComponentOleDb(OleDbConnection sqlConnection, int componentID)
		//public static DisciplineStruct LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			DisciplineStruct		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc2_id, component_id, disc2_conditionRanking, disc2_CWPAssetValue, ");
			builder.Append("disc2_originalUsefulLife, ");
			builder.Append("disc2_acquisitionCost, disc2_replacementValue, ");
			builder.Append("disc2_salvageValue, disc2_annualMaintCost, ");
			builder.Append("disc2_originalENR, disc2_currentENR, ");
			builder.Append("disc2_concSpalling, ");
			builder.Append("disc2_structExcessiveCorrosion, disc2_membExcessiveCorrosion, ");
			builder.Append("disc2_corrosionCoating, disc2_paintGood, ");
			builder.Append("disc2_visibleDeformities, disc2_settingEvident, ");
			builder.Append("disc2_roofExcessiveDegradation, disc2_majorCracks, ");
			builder.Append("disc2_dateInspected, disc2_assessedBy, disc2_equipmentNumber, ");
			builder.Append("disc2_manufacturer, disc2_runHours, disc2_installationYear, ");
			builder.Append("disc2_photoCaption, disc2_comments, disc2_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost ");
			builder.Append(", RehabCost ");

			//mam 07072011 - no need for additional rehab values here because we are not updating the Access database to include them

			builder.Append("FROM DisciplineStruct ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
				{
					//mam 102309
					//newObject = new DisciplineStruct(sqlConnection, dataReader);
					newObject = new DisciplineStruct(0);
					newObject.LoadRecordData(dataReader);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplineStruct.LoadForComponent Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				//mam 102309
				//newObject = new DisciplineStruct(sqlConnection, 0);
				newObject = new DisciplineStruct(0);

				newObject.ComponentID = componentID;

				//mam - can't get current year through newObject when importing
				if (!MainForm.currentlyImporting)
				{
					newObject.InstallationYear = newObject.GetFacility().CurrentYear;
				}
				//</mam>

				//mam 112806 - changed to zero
				//mam 050806
				//newObject.m_replacementValueYear = DateTime.Now.Year;
				newObject.m_replacementValueYear = 0;
			}
			
			return newObject;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static DisciplineStruct LoadForComponent(int componentID)
		{
			//mam 102309
			//return LoadForComponent(WAMSource.CurrentSource.ConnectionString, componentID);
			return LoadForComponent(Globals.WamSqlConnectionString, componentID);
		}

		public static DisciplineStruct LoadForComponent(string connectionString, int componentID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			DisciplineStruct retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponent(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static DisciplineStruct LoadForComponent(OleDbConnection sqlConnection, int componentID)
		public static DisciplineStruct LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			DisciplineStruct		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//builder.Append("Facilities.infoset_id, " );
			builder.Append("MajorComponents.CipPlanningId, " );

			builder.Append("disc2_id, DisciplineStruct.component_id, disc2_conditionRanking, disc2_CWPAssetValue, ");
			builder.Append("disc2_originalUsefulLife, ");
			builder.Append("disc2_acquisitionCost, disc2_replacementValue, ");
			builder.Append("disc2_salvageValue, disc2_annualMaintCost, ");
			builder.Append("disc2_originalENR, disc2_currentENR, ");
			builder.Append("disc2_concSpalling, ");
			builder.Append("disc2_structExcessiveCorrosion, disc2_membExcessiveCorrosion, ");
			builder.Append("disc2_corrosionCoating, disc2_paintGood, ");
			builder.Append("disc2_visibleDeformities, disc2_settingEvident, ");
			builder.Append("disc2_roofExcessiveDegradation, disc2_majorCracks, ");
			builder.Append("disc2_dateInspected, disc2_assessedBy, disc2_equipmentNumber, ");
			builder.Append("disc2_manufacturer, disc2_runHours, disc2_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc2_photoCaption, DisciplineStruct.PhotoFileName, disc2_comments, disc2_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.AppendFormat(", RehabInterval");

			//mam 01222012 - no longer using override for Time to Next Rehab, so RehabNext will always be calcuated and never stored in the database
			//builder.AppendFormat(", RehabNext");

			builder.AppendFormat(", RehabYearLast");
			//mam 07072011 end

			//mam 07072011
			builder.AppendFormat(", NextReplacementYear");

			//mam 01222012
			builder.AppendFormat(", ReplacementValueDesc");
			builder.AppendFormat(", RehabCostDesc");
			builder.AppendFormat(", RehabYearNext");

			builder.Append(" FROM DisciplineStruct");

			//mam 07072011 - need cip planning id in loadrecord, so must get it here
			builder.Append(" INNER JOIN MajorComponents ON DisciplineStruct.component_id = MajorComponents.component_id");
			//builder.Append("INNER JOIN TreatmentProcesses ON MajorComponents.process_id = TreatmentProcesses.process_id ");
			//builder.Append("INNER JOIN Facilities ON TreatmentProcesses.facility_id = Facilities.facility_id ");

			builder.AppendFormat(" WHERE (DisciplineStruct.component_id={0})", componentID);

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
					newObject = new DisciplineStruct(sqlConnection, dataReader);
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplineStruct.LoadForComponent Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				newObject = new DisciplineStruct(sqlConnection, 0);
				newObject.ComponentID = componentID;

				//mam - can't get current year through newObject when importing
				if (!MainForm.currentlyImporting)
				{
					//mam 03202012
					short facilityYear = newObject.GetFacility().CurrentYear;

					//mam 03202012
					//newObject.InstallationYear = newObject.GetFacility().CurrentYear;
					newObject.InstallationYear = facilityYear;

					//mam 03202012
					//if newObject is null, that means that the discipline is not in the database
					//the installation year will default to the current calendar year
					//if the facility year is less than the current calendar year, the installation year 
					//	cannot be the current calendar year because it would violate the timing constraints:
					//	installation year < last rehab year < inspection year < facility year < next replacement/rehab year)
					//this can be avoided by setting the installation year to the facility year for disciplines
					//	that do not exist in the database
					//the inspection year, date of inspection, and last rehab year must also be set to the facility year for the same reason
					//it is not necessary to set next replacement/rehab years because they are n/a due to condition being n/a
					newObject.InspectionYear = Convert.ToDateTime("1/1/" + facilityYear.ToString());
					newObject.DateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
					newObject.RehabYearLast = facilityYear;
				}
				//</mam>

				//mam 112806 - changed to zero
				//mam 050806
				//newObject.m_replacementValueYear = DateTime.Now.Year;
				newObject.m_replacementValueYear = 0;
			}
			
			return newObject;
		}

		//mam 03202012 - new method to get all mech disciplines for an infoset
		//@@@@
		public static DisciplineStruct[] LoadForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			DisciplineStruct		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			DisciplineStruct[] typedArray;
			ArrayList arrayList = new ArrayList();

//			builder.Append("SELECT ");
//			builder.Append("MajorComponents.CipPlanningId, " );
//			builder.Append("disc2_id, DisciplineStruct.component_id, disc2_conditionRanking, disc2_CWPAssetValue, ");
//			builder.Append("disc2_originalUsefulLife, ");
//			builder.Append("disc2_acquisitionCost, disc2_replacementValue, ");
//			builder.Append("disc2_salvageValue, disc2_annualMaintCost, ");
//			builder.Append("disc2_originalENR, disc2_currentENR, ");
//			builder.Append("disc2_concSpalling, ");
//			builder.Append("disc2_structExcessiveCorrosion, disc2_membExcessiveCorrosion, ");
//			builder.Append("disc2_corrosionCoating, disc2_paintGood, ");
//			builder.Append("disc2_visibleDeformities, disc2_settingEvident, ");
//			builder.Append("disc2_roofExcessiveDegradation, disc2_majorCracks, ");
//			builder.Append("disc2_dateInspected, disc2_assessedBy, disc2_equipmentNumber, ");
//			builder.Append("disc2_manufacturer, disc2_runHours, disc2_installationYear, ");
//			builder.Append("disc2_photoCaption, DisciplineStruct.PhotoFileName, disc2_comments, disc2_runningAtInspect ");
//			builder.Append(", CurrentValue ");
//			builder.Append(", ReplacementValueYear ");
//			builder.Append(", RepairCost");
//			builder.Append(", RehabCost");
//			builder.Append(", RehabCostYear");
//			builder.AppendFormat(", RehabInterval");
//			builder.AppendFormat(", RehabYearLast");
//			builder.AppendFormat(", NextReplacementYear");
//			builder.AppendFormat(", ReplacementValueDesc");
//			builder.AppendFormat(", RehabCostDesc");
//			builder.AppendFormat(", RehabYearNext");
//			builder.Append(" FROM DisciplineStruct");
//			builder.Append(" INNER JOIN MajorComponents ON DisciplineStruct.component_id = MajorComponents.component_id");
//			builder.AppendFormat(" WHERE (DisciplineStruct.component_id={0})", componentID);

			builder.Append("SELECT C.CipPlanningId, D.*");
			builder.Append(" , F.facility_currentYear, F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id AS ComponentId");
			builder.Append(" FROM DisciplineStruct D LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			builder.Append(" UNION ALL");
			builder.Append(" SELECT C.CipPlanningId, D.*");
			builder.Append(" , F.facility_currentYear, F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");
			builder.Append(" FROM MajorComponents C LEFT JOIN DisciplineStruct D ON C.component_id = D.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0} AND C.component_id NOT IN (SELECT component_id FROM DisciplineStruct)", infosetId);
			builder.Append(" AND C.component_MechStructDisc = 1");
			builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				SqlDataAdapter adapter = new SqlDataAdapter();
				System.Data.DataTable dataTable = new System.Data.DataTable();
				adapter.SelectCommand = new SqlCommand(builder.ToString(), sqlConnection);
				adapter.Fill(dataTable);

				bool mainFormCurrentlyImporting = MainForm.currentlyImporting;
				foreach (DataRow dataRow in dataTable.Rows)
				{
					newObject = new DisciplineStruct(0);
					newObject.LoadRecordData(dataRow);

					if (newObject.ID != 0)
					{
						//arrayList.Add(newObject);
					}
					else
					{
						newObject.ComponentID = Convert.ToInt32(dataRow["ComponentId"]);

						if (!mainFormCurrentlyImporting)
						{
							short facilityYear = Convert.ToInt16(dataRow["facility_currentYear"]);
							newObject.InstallationYear = facilityYear;
							newObject.InspectionYear = Convert.ToDateTime("1/1/" + facilityYear.ToString());
							newObject.DateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
							newObject.RehabYearLast = facilityYear;
						}

						newObject.m_replacementValueYear = 0;
					}

					arrayList.Add(newObject);
				}			
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DisciplineStruct.LoadForComponent Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
				//if (dataReader != null && !dataReader.IsClosed)
				//	dataReader.Close();
			}

			typedArray = new DisciplineStruct[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods *****/
	}
}