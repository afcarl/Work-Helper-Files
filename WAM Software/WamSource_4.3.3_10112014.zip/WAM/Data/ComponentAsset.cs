using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for ComponentAsset.
	/// </summary>

	//mam - added IFilterable
	//public class ComponentAsset : Drive.Data.OleDb.Jet40DALInt32Key, IComparable
	//mam 102309
	//public class ComponentAsset : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable
	public class ComponentAsset : Drive.Data.SqlClient.SqlDALInt32Key, IComparable, IFilterable
	//</mam>
	{
		#region /***** Member Variables *****/

		private int			m_componentID = 0;
		private string		m_name = "";
		private string		m_description = "";
		private CondRank	m_conditionRanking = CondRank.C3;
		private decimal		m_replacementCost = 0;
		private int			m_sortOrder = 65000;

		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/

		//mam 102309
		//public ComponentAsset(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public ComponentAsset(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public ComponentAsset(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//protected ComponentAsset(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected ComponentAsset(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
			{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_description = Drive.SQL.ReadNullableString(reader, col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_replacementCost = reader.GetDecimal(col++);
			m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);

			//mam 102309
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_replacementCost = reader.GetDecimal(col++);

			//mam 102309
			//m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_sortOrder = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
		}
		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			ComponentAsset comp = obj as ComponentAsset;

			if (comp != null)
			{
				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);

				if (compare == 0)
					compare = Drive.Math.Compare(this.ID, comp.ID);

				return compare;
			}
			else
				throw new InvalidCastException("Not a ComponentAsset");
		}

		//mam - compare Assets by their various values
		public int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)		
		{
			ComponentAsset rhs = obj as ComponentAsset;
			int result = 0;
			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not an asset");

			return result;
		}
		//</mam>

		//mam - compare Assets by their various values
		private int CompareToEach(ComponentAsset rhs, WAM.Logic.UnitFilter.FilterSourceSort which, 
			bool lowToHigh)
		{
			int result = 0;
			switch (which)
			{
				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					if (lowToHigh)
						result = this.GetRankPercent().CompareTo(rhs.GetRankPercent());
					else
						result = rhs.GetRankPercent().CompareTo(this.GetRankPercent());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementCost:
					if (lowToHigh)
						result = this.GetReplacementCost().CompareTo(rhs.GetReplacementCost());
					else
						result = rhs.GetReplacementCost().CompareTo(this.GetReplacementCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;
			}
			return result;
		}
		//</mam>

		#endregion /***** IComparable Members *****/

		#region /***** Nested Class ComponentAssetComparer *****/
		//mam
		public class ComponentAssetComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				ComponentAsset l = (ComponentAsset) lhs;
				ComponentAsset r = (ComponentAsset) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}

			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class ComponentAssetComparer *****/

		#region /***** IFilterable Members *****/
		//mam - added region IFilterable Members
		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.ReplacementCost:
					return GetReplacementCost();
				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			// the combo boxes will only have valid selections, so return true
			return true;
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementCost:
					return GetReplacementCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			// the combo boxes will only have valid selections, so return true
			return true;
		}
		//</mam>

		//mam 07072011
		public string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			return "";

			//switch (source)
			//{
			//	case WAM.Logic.UnitFilter.FilterSource.ReplacementCost:
			//		return GetReplacementCost();
			//	case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
			//		return Math.Round(((decimal)GetRankPercent()), 1);
			//}

			//return 0m;
		}

		//mam 07072011
		public bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			// the combo boxes will only have valid selections, so return true
			return true;
		}

		#endregion /***** IFilterable Members *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT ");
			builder.Append("compasset_id, component_id, compasset_name, compasset_description, ");
			builder.Append("compasset_conditionRanking, compasset_replacementCost, ");
			builder.Append("compasset_sortOrder ");
			builder.Append("FROM ComponentAssets ");
			builder.AppendFormat("WHERE compasset_id={0}", id);

			return builder.ToString();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;

						//mam 03202012 - add this line to add the new component asset to the cache
						InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
						InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
					}
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO ComponentAssets (");

			builder.Append("component_id, compasset_name, compasset_description, ");
			builder.Append("compasset_conditionRanking, compasset_replacementCost, ");
			builder.Append("compasset_sortOrder ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("{0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("{0:F6}, ", m_replacementCost);
			builder.AppendFormat("{0} ", m_sortOrder);
			builder.Append(")");

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE ComponentAssets SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("compasset_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("compasset_description={0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("compasset_conditionRanking={0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("compasset_replacementCost={0:F6}, ", m_replacementCost);
			builder.AppendFormat("compasset_sortOrder={0} ", m_sortOrder);

			builder.AppendFormat("WHERE (compasset_id={0}) ", ID);
			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From ComponentAssets WHERE compasset_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public int			ComponentID
		{
			get { return m_componentID; }
			set { m_componentID = value; }
		}

		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public string		Description
		{
			get { return m_description; }
			set
			{
				if (value.Length > 255)
					m_description = value.Substring(255);
				else
					m_description = value;
			}
		}

		public CondRank		ConditionRanking
		{
			get { return m_conditionRanking; }
			set { m_conditionRanking = value; }
		}

		public decimal		ReplacementCost
		{
			get { return m_replacementCost; }
			set { m_replacementCost = value; }
		}

		public int			SortOrder
		{
			get { return m_sortOrder; }
			set { m_sortOrder = value; }
		}
		#endregion /***** Properties *****/

		#region /***** Methods *****/

		//mam
		public static ComponentAssetComparer GetComparer()
		{
			return new ComponentAsset.ComponentAssetComparer();
		}
		//</mam>

		public void			CopyTo(ComponentAsset copy)
		{
			//copy.m_componentID = 0;
			copy.m_name = m_name;
			copy.m_description = m_description;
			copy.m_conditionRanking = m_conditionRanking;
			copy.m_replacementCost = m_replacementCost;
			copy.m_sortOrder = m_sortOrder;
		}

		//mam
		public string GetCSVData(string selectedFilters, ArrayList filteredItems)
		{
			ComponentAsset asset;
			Facility facility;
			TreatmentProcess process;
			MajorComponent component;
			StringBuilder builder = new StringBuilder();
			
			builder.Append("Component Asset Report");
			builder.Append("\r\n");

			//don't use selectedFilters for Component Asset because this report has no totals on which to filter
			//if (selectedFilters != "")
			//{
			//	builder.Append("\r\n");
			//	//builder.AppendFormat((char)34 + selectedFilters + (char)34);
			//	builder.AppendFormat(selectedFilters);
			//	builder.Append("\r\n\r\n");
			//}

			builder.Append((char)34 + "Facility / System" + (char)34);
			builder.Append("," + (char)34 + "Treatment Process / Basin / Zone" + (char)34);
			builder.Append("," + (char)34 + "Major Component / Subbasin / Subzone" + (char)34);
			//builder.Append(",Facility Current Year");
			//builder.Append(",Facility Current ENR");
			builder.Append(",Asset ID Number");
			builder.Append(",Description");
			builder.Append(",Condition Ranking");
			builder.Append(",Replacement Cost");

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				asset = (ComponentAsset)filteredItems[pos];
				component = CacheManager.GetMajorComponent(asset.InfoSetID, asset.ComponentID);
				process = component.GetTreatmentProcess();
				facility = process.GetFacility();
				ComponentAsset[] assets = ComponentAsset.LoadAll(component.ID);

				for (int posAsset = 0; posAsset < assets.Length; posAsset++)
				{
					builder.Append("\r\n");

					asset = assets[posAsset];
					builder.Append((char)34 + facility.Name + (char)34);
					builder.Append("," + (char)34 + process.Name + (char)34);
					builder.Append("," + (char)34 + component.Name + (char)34);
					//builder.AppendFormat(",{0:F0}", facility.CurrentYear);
					//builder.AppendFormat(",{0:F0}", facility.CurrentENR);
					builder.Append("," + (char)34 + asset.Name.ToString() + (char)34);
					builder.AppendFormat(",{0}", asset.Description.ToString());
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetConditionRankString(asset.ConditionRanking));
					builder.AppendFormat(",{0:F0}", asset.ReplacementCost);
				}
			}

//			ComponentAsset[] assets = ComponentAsset.LoadAll(m_component.ID);
//			ComponentAsset	asset;
//			int				row = 1;
//
//			gridAssets.Redraw = false;
//			for (int pos = 0; pos < assets.Length; pos++)
//			{
//				asset = assets[pos];
//				gridAssets.Rows.Add().UserData = asset;
//				gridAssets.SetData(row, 0, asset.Name);
//				gridAssets.SetData(row, 1, asset.Description);
//				gridAssets.SetData(row, 2, (byte)asset.ConditionRanking);
//				gridAssets.SetData(row, 3, asset.ReplacementCost);
//				row++;
//			}

			//System.Windows.Forms.MessageBox.Show(builder.ToString());
			return builder.ToString();
		}
		//</mam>

		#endregion /***** Methods *****/

		#region		/***** Calculation Methods *****/
		//mam added region Calculation Methods
		public decimal		GetReplacementCost()
		{
			//return m_processTotals.GetTotalAcquisitionCost();
			return m_replacementCost;
		}

		public CondRank		GetRankPercent()
		{
			//return m_processTotals.GetRankPercent();
			return m_conditionRanking;
		}
		//</mam>
		#endregion		/***** Calculation Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static ComponentAsset[] LoadAllOleDb(int componentID)
		{
			return LoadAll(WamSourceOleDb.CurrentSource.ConnectionString, componentID);
			//return LoadAll(Globals.WamSqlConnectionString, componentID);
		}

		//mam 102309
		public static ComponentAsset[] LoadAllOleDb(string connectionString, int componentID)
		{
			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			ComponentAsset[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAllOleDb(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static ComponentAsset[] LoadAllOleDb(OleDbConnection sqlConnection, int componentID)
		//public static ComponentAsset[] LoadAll(SqlConnection sqlConnection, int componentID)
		{
			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			ComponentAsset	newObject;
			ComponentAsset[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("compasset_id, component_id, compasset_name, compasset_description, ");
			builder.Append("compasset_conditionRanking, compasset_replacementCost, ");
			builder.Append("compasset_sortOrder ");
			builder.Append("FROM ComponentAssets ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);
			builder.Append("ORDER BY compasset_sortOrder Asc, compasset_id Asc");

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					//mam 102309
					//newObject = new ComponentAsset(dataReader);
					newObject = new ComponentAsset(0);
					newObject.LoadRecordData(dataReader);

					if (newObject.ID != 0)
					{
						arrayList.Add(newObject);
					}
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("ComponentAsset.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new ComponentAsset[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static ComponentAsset[] LoadAll(int componentID)
		{
			//mam 102309
			//return LoadAll(WAMSource.CurrentSource.ConnectionString, componentID);
			return LoadAll(Globals.WamSqlConnectionString, componentID);
		}

		public static ComponentAsset[] LoadAll(string connectionString, int componentID)
		{
			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			ComponentAsset[] retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAll(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static ComponentAsset[] LoadAll(OleDbConnection sqlConnection, int componentID)
		public static ComponentAsset[] LoadAll(SqlConnection sqlConnection, int componentID)
		{
			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			ComponentAsset	newObject;
			ComponentAsset[] typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT ");
			builder.Append("compasset_id, component_id, compasset_name, compasset_description, ");
			builder.Append("compasset_conditionRanking, compasset_replacementCost, ");
			builder.Append("compasset_sortOrder ");
			builder.Append("FROM ComponentAssets ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);
			builder.Append("ORDER BY compasset_sortOrder Asc, compasset_id Asc");

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new ComponentAsset(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("ComponentAsset.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new ComponentAsset[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 03202012
		//@@@@
		public static ComponentAsset[] LoadAllForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			ComponentAsset newObject;
			ComponentAsset[] typedArray;
			ArrayList arrayList = new ArrayList();
			StringBuilder builder = new StringBuilder(300);

			//builder.Append("SELECT ");
			//builder.Append("compasset_id, component_id, compasset_name, compasset_description, ");
			//builder.Append("compasset_conditionRanking, compasset_replacementCost, ");
			//builder.Append("compasset_sortOrder ");
			//builder.Append("FROM ComponentAssets ");
			//builder.AppendFormat("WHERE (component_id={0}) ", componentID);
			//builder.Append("ORDER BY compasset_sortOrder Asc, compasset_id Asc");

			builder.Append("SELECT A.compasset_id, A.component_id, A.compasset_name, A.compasset_description");
			builder.Append(" , A.compasset_conditionRanking, A.compasset_replacementCost, A.compasset_sortOrder");
			builder.Append(" FROM ComponentAssets A LEFT JOIN MajorComponents C ON A.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			builder.Append(" ORDER BY A.compasset_sortOrder ASC, A.compasset_id ASC");

			try
			{
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new ComponentAsset(dataReader);
					if (newObject.ID != 0)
					{
						arrayList.Add(newObject);
					}
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("ComponentAsset.LoadAllForInfoset Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
				{
					dataReader.Close();
				}
			}
			
			typedArray = new ComponentAsset[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods *****/
	}

	#region /***** Cache Class *****/
	public class			ComponentAssetCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable();

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.ComponentAsset));
		private int			m_infoSetID = 0;

		public				ComponentAssetCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged));
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged));
		}

		#region IDisposable Members
		~ComponentAssetCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		//mam 102309
		//private void DataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			ComponentAsset obj = e.ChangedObject as ComponentAsset;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.ComponentID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.ComponentID, obj);
			}
		}

		public ComponentAsset[] GetForComponent(int id)
		{
			ComponentAsset[] children = (ComponentAsset[])m_treeHash.GetChildren(id);

			if (children == null)
			{
				//for testing only!!!
				//WAM.Common.Globals.DatabaseHitCount++;

				children = ComponentAsset.LoadAll(id);
				for (int pos = 0; pos < children.Length; pos++)
					children[pos].InfoSetID = m_infoSetID;

				m_treeHash.SetChildren(id, children);
			}

			return children;
		}

		//mam 06212012 - new method - called from UI.ReportFilterForm only - use this for the loading of the tree in the 
		//report form; prevent the report form from accessing the database when loading the tree - it should only 
		//	access the cache because everything it needs is already in the cache
		//@@@@@
		public ComponentAsset[] GetForComponentForComponent(int id)
		{
			ComponentAsset[] children = (ComponentAsset[])m_treeHash.GetChildren(id);

			//mam 06212012 - don't go to the database
			//if (children == null)
			//{
			//	children = ComponentAsset.LoadAll(id);
			//	for (int pos = 0; pos < children.Length; pos++)
			//		children[pos].InfoSetID = m_infoSetID;
			//
			//	m_treeHash.SetChildren(id, children);
			//}

			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
		}

		//mam 102309
		//public ComponentAsset[] BuildCacheForComponent(OleDbConnection connection, int id)
		public ComponentAsset[] BuildCacheForComponent(SqlConnection connection, int id)
		{
			ComponentAsset[] children = ComponentAsset.LoadAll(connection, id);

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				// Set info set for cache matching purposes
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		public ComponentAsset GetComponentAsset(int id)
		{
			// Look up the components in the hash table
			ComponentAsset asset = m_hash[id.GetHashCode()] as ComponentAsset;

			// If the asset is not present, load it from the default database
			if (asset == null)
			{
				asset = new ComponentAsset(id);
				asset.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (asset.ID != 0)
					m_hash[asset.GetHashCode()] = asset;
				else
					asset = null;
			}

			return asset;
		}

		//mam 03202012
		//@@@@
		public ComponentAsset[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			ComponentAsset[] children = ComponentAsset.LoadAllForInfoset(connection, infosetId);

			foreach (ComponentAsset asset in children)
			{
				m_treeHash.AddChild(asset.ComponentID, asset);

				asset.InfoSetID = m_infoSetID;
				m_hash[asset.GetHashCode()] = asset;
			}

			return children;
		}
	}
	#endregion /***** Cache Class *****/
}