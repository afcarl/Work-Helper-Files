using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave for importing from WAM databases
using System.Data.OleDb;

using System.Text;
using System.Collections;
using System.Drawing;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Facility.
	/// </summary>

	//mam 102309
	//public class Facility : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable, IGraphableUnit
	public class Facility : Drive.Data.SqlClient.SqlDALInt32Key, IComparable, IFilterable, IGraphableUnit
	{
		#region /***** Member Variables *****/
		private int			m_infoSetID = 0;
		private string		m_name = "";
		private short		m_currentYear = (short)DateTime.Now.Year;
		private int			m_currentENR = 0;
		private string		m_captionNorth = "";
		private string		m_captionSouth = "";
		private string		m_captionEast = "";
		private string		m_captionWest = "";
		private string		m_comments = "";
		private decimal		m_replacementVal = 0;
		private decimal		m_oldOrgCost = 0;
		private decimal		m_newFacilityCost = 0;
		private int			m_sortOrder = 65000;
		private decimal		m_fundedFacilityCost = 0;
		private decimal		m_fundedReplaceValue = 0;
		private bool		m_usesCustomENR = false;
		private Hashtable	m_customENRValues = null;

		//mam 112806
		private bool mscOverrideAnyCurrentValue = false;
		private bool mscOverrideAnyRepairCost = false;
		private bool pipeOverrideAnyCurrentValue = false;
		private bool pipeOverrideAnyRepairCost = false;
		private bool nodeOverrideAnyCurrentValue = false;
		private bool nodeOverrideAnyRepairCost = false;

		//mam
		decimal adjustedTotal = 0;
		bool isNA = false;
		private int m_customENRListID = 0;
		//</mam>

		//mam 01222012
		decimal m_facilityCriticality = 1M;

		private int treeNodeIndex = 0;

		//mam 03202012
		private string m_photoFileNameNorth = "";
		private string m_photoCaptionNorth = "";
		private string m_photoFileNameSouth = "";
		private string m_photoCaptionSouth = "";

		//mam 03202012 - need a way to determine if a facility that is being saved
		//	is a facility that is being imported
		private bool m_beingImported = false;

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public Facility(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public Facility(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public Facility(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//protected Facility(System.Data.OleDb.OleDbDataReader reader): base(WAMSource.CurrentSource.ConnectionString, reader)
		protected Facility(System.Data.SqlClient.SqlDataReader reader): base(Globals.WamSqlConnectionString, reader)
		{
		}

		//mam 102309
		//protected Facility(System.Data.OleDb.OleDbConnection sqlConnection, System.Data.OleDb.OleDbDataReader reader)
		//	: base(sqlConnection, reader)
		protected Facility(System.Data.SqlClient.SqlConnection sqlConnection, System.Data.SqlClient.SqlDataReader reader)
			: base(sqlConnection.ConnectionString, reader)
		{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_infoSetID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_currentYear = reader.GetInt16(col++);

			//mam - the field facility_currentENRin the Facilities is not used by
			//	the application; rather, the CurrentENR comes from the 20CitiesENR database
			//	or the CustomENR table in the WAM database
			//I changed the read value to a nullable value in case that (unused) field ends up being null
			//m_currentENR = reader.GetInt32(col++);

			m_currentENR = Drive.SQL.ReadNullableInt32(reader, col++);
			//</mam>

			m_captionNorth = Drive.SQL.ReadNullableString(reader, col++);
			m_captionSouth = Drive.SQL.ReadNullableString(reader, col++);
			m_captionEast = Drive.SQL.ReadNullableString(reader, col++);
			m_captionWest = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_replacementVal = reader.GetDecimal(col++);
			m_oldOrgCost = reader.GetDecimal(col++);
			m_newFacilityCost = reader.GetDecimal(col++);
			m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_fundedFacilityCost = reader.GetDecimal(col++);
			m_fundedReplaceValue = reader.GetDecimal(col++);
			m_usesCustomENR = reader.GetBoolean(col++);

			//mam
			m_customENRListID = Drive.SQL.ReadNullableInt32(reader, col++);
			//</mam>
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_infoSetID = reader.GetInt32(col++);
			m_name = reader.GetString(col++);
			m_currentYear = reader.GetInt16(col++);

			//mam - the field facility_currentENRin the Facilities is not used by
			//	the application; rather, the CurrentENR comes from the 20CitiesENR database
			//	or the CustomENR table in the WAM database
			//I changed the read value to a nullable value in case that (unused) field ends up being null
			//m_currentENR = reader.GetInt32(col++);

			//mam 102309
			//m_currentENR = Drive.SQL.ReadNullableInt32(reader, col++);
			m_currentENR = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//</mam>

			//mam 102309
			//m_captionNorth = Drive.SQL.ReadNullableString(reader, col++);
			//m_captionSouth = Drive.SQL.ReadNullableString(reader, col++);
			//m_captionEast = Drive.SQL.ReadNullableString(reader, col++);
			//m_captionWest = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_captionNorth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_captionSouth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_captionEast = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_captionWest = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 03202012
			m_photoFileNameNorth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_photoFileNameSouth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 102309
			//m_photoNorth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			//m_photoSouth = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_replacementVal = reader.GetDecimal(col++);
			m_oldOrgCost = reader.GetDecimal(col++);
			m_newFacilityCost = reader.GetDecimal(col++);

			//mam 102309
			//m_sortOrder = Drive.SQL.ReadNullableInt32(reader, col++);
			m_sortOrder = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			m_fundedFacilityCost = reader.GetDecimal(col++);
			m_fundedReplaceValue = reader.GetDecimal(col++);
			m_usesCustomENR = reader.GetBoolean(col++);

			//mam
			//mam 102309
			//m_customENRListID = Drive.SQL.ReadNullableInt32(reader, col++);
			m_customENRListID = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			//</mam>

			//mam 01222012
			m_facilityCriticality = reader.GetDecimal(col++);
		}
		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			Facility comp = obj as Facility;

			if (comp != null)
			{
				int			compare = Drive.Math.Compare(this.m_sortOrder, comp.m_sortOrder);

				if (compare == 0)
					compare = Drive.Math.Compare(this.ID, comp.ID);

				return compare;
			}
			else
				throw new InvalidCastException("Not a facility");
		}

		//mam - compare Facilities by their various values
		public int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)
		{
			Facility rhs = obj as Facility;
			int result = 0;

			this.isNA = this.CheckIfAllNADisciplineForFacility(this.InfoSetID, this.ID);
			rhs.isNA = rhs.CheckIfAllNADisciplineForFacility(rhs.InfoSetID, rhs.ID);

			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}

						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a facility");

			return result;
		}
		//</mam>

		//mam - compare each Facility as necessary
		private int CompareToEach(Facility rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;

			switch (which)
			{
				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
				//mam

				//case Facility.FacilityComparer.ComparisonType.AcquisitionCost:
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.GetAcquisitionCost().CompareTo(rhs.GetAcquisitionCost());
					else
						result = rhs.GetAcquisitionCost().CompareTo(this.GetAcquisitionCost());

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.GetAcquisitionCostEscalated().CompareTo(rhs.GetAcquisitionCostEscalated());
					else
						result = rhs.GetAcquisitionCostEscalated().CompareTo(this.GetAcquisitionCostEscalated());

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.GetRehabCost().CompareTo(rhs.GetRehabCost());
					else
						result = rhs.GetRehabCost().CompareTo(this.GetRehabCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.GetReplacementValue().CompareTo(rhs.GetReplacementValue());
					else
						result = rhs.GetReplacementValue().CompareTo(this.GetReplacementValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.GetSalvageValue().CompareTo(rhs.GetSalvageValue());
					else
						result = rhs.GetSalvageValue().CompareTo(this.GetSalvageValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					if (lowToHigh)
						result = this.SortGetEvaluatedValue().CompareTo(rhs.SortGetEvaluatedValue());
					else
						result = rhs.SortGetEvaluatedValue().CompareTo(this.SortGetEvaluatedValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					if (lowToHigh)
						result = this.SortGetRepairCost().CompareTo(rhs.SortGetRepairCost());
					else
						result = rhs.SortGetRepairCost().CompareTo(this.SortGetRepairCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.GetAnnualMaintenanceCost().CompareTo(rhs.GetAnnualMaintenanceCost());
					else
						result = rhs.GetAnnualMaintenanceCost().CompareTo(this.GetAnnualMaintenanceCost());

					break;

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSourceSort.FacilityCriticality:
					if (lowToHigh)
						result = this.FacilityCriticality.CompareTo(rhs.FacilityCriticality);
					else
						result = rhs.FacilityCriticality.CompareTo(this.FacilityCriticality);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;
			}
			return result;
		}
		//</mam>

		#endregion /***** IComparable Members *****/

		#region /***** Nested Class FacilityComparer *****/
		//mam
		public class FacilityComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				Facility l = (Facility) lhs;
				Facility r = (Facility) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}
			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class FacilityComparer *****/

		#region /***** IFilterable Members *****/

		//mam 07072011
		public string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			//switch (source)
			//{
			//	case WAM.Logic.UnitFilter.FilterSource.AssetClass:
			//	{
			//		return AssetClass;
			//		break;
			//	}
			//}

			return "";
		}

		//mam 07072011
		public bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			return true;
		}

		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterSource.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterSource.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterSource.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterSource.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterSource.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterSource.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterSource.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

				//mam
				case WAM.Logic.UnitFilter.FilterSource.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
				//</mam>

				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterSource.RehabCost:
					return GetRehabCost();

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSource.FacilityCriticality:
					return FacilityCriticality;

				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					break;
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
				case WAM.Logic.UnitFilter.FilterSource.Risk:

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:

					return false;
			}

			return true;
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCost:
					return GetAcquisitionCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValue:
					return GetReplacementValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.SalvageValue:
					return GetSalvageValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualMaintCost:
					return GetAnnualMaintenanceCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.OriginalUL:
					return Math.Round(((decimal)GetOrgUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

				//mam
				case WAM.Logic.UnitFilter.FilterCompareTo.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
				//</mam>

				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)GetRankPercent()), 1);

				//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabCost:
					return GetRehabCost();

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterCompareTo.FacilityCriticality:
					return FacilityCriticality;

				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					break;
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					return false;
				default:
					break;
			}

			return true;
		}
		#endregion /***** IFilterable Members *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, ");

			//mam 03202012
			builder.Append("PhotoFileNameNorth, PhotoFileNameSouth, ");

			builder.Append("facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID ");

			//mam 01222012
			builder.Append(", FacilityCriticality ");

			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE facility_id={0}", id);

			return builder.ToString();
		}

		//mam 102309
		public string GetInsertSqlForCopy()
		{
			return GetInsertSql();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - added bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				//string msg = "Error in " + this.Name + ".Save:" + Environment.NewLine + Environment.NewLine + ex.Message;
				//throw new Exception(msg);
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309 - remove override; change to public
		//protected override string GetInsertSql()
		public string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO Facilities (");

			builder.Append("infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, ");

			//mam 03202012
			builder.Append("PhotoFileNameNorth, PhotoFileNameSouth, ");

			builder.Append("facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID");

//			//mam - save CurrentENR
//			builder.Append(", facility_currentENR ");
//			//</mam>

			builder.Append(", FacilityCriticality ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_infoSetID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0}, ", m_currentYear);
			builder.AppendFormat("{0}, ", m_currentENR);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionNorth));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionSouth));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionEast));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_captionWest));

			//mam 03202012
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileNameNorth));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileNameSouth));

			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));

			//mam 102309
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoNorth));
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoSouth));

			builder.AppendFormat("{0:F2}, ", m_replacementVal);
			builder.AppendFormat("{0:F2}, ", m_oldOrgCost);
			builder.AppendFormat("{0:F2}, ", m_newFacilityCost);
			builder.AppendFormat("{0}, ", m_sortOrder);
			builder.AppendFormat("{0:F2}, ", m_fundedFacilityCost);
			builder.AppendFormat("{0:F2}, ", m_fundedReplaceValue);
			builder.AppendFormat("{0}, ", Drive.SQL.BoolToBit(m_usesCustomENR));

			//mam
			if (m_customENRListID == 0)
			{
				builder.AppendFormat("{0} ", "null");
			}
			else
			{
				builder.AppendFormat("{0} ", m_customENRListID);
			}
			//</mam>

			//mam 01222012
			builder.AppendFormat(", {0:F2} ", m_facilityCriticality);

//			//mam - save CurrentENR
//			builder.AppendFormat(", {0} ", m_currentENR);
//			//</mam>

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE Facilities SET ");
			builder.AppendFormat("infoset_id={0}, ", m_infoSetID);
			builder.AppendFormat("facility_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("facility_currentYear={0}, ", m_currentYear);
			builder.AppendFormat("facility_currentENR={0}, ", m_currentENR);
			builder.AppendFormat("facility_captionNorth={0}, ", Drive.SQL.StringToDBString(m_captionNorth));
			builder.AppendFormat("facility_captionSouth={0}, ", Drive.SQL.StringToDBString(m_captionSouth));
			builder.AppendFormat("facility_captionEast={0}, ", Drive.SQL.StringToDBString(m_captionEast));
			builder.AppendFormat("facility_captionWest={0}, ", Drive.SQL.StringToDBString(m_captionWest));

			//mam 03202012
			builder.AppendFormat("PhotoFileNameNorth={0}, ", Drive.SQL.StringToDBString(m_photoFileNameNorth));
			builder.AppendFormat("PhotoFileNameSouth={0}, ", Drive.SQL.StringToDBString(m_photoFileNameSouth));

			builder.AppendFormat("facility_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("facility_replacementValue={0:F2}, ", m_replacementVal);
			builder.AppendFormat("facility_oldOrgCost={0:F2}, ", m_oldOrgCost);
			builder.AppendFormat("facility_newFacilityCost={0:F2}, ", m_newFacilityCost);
			builder.AppendFormat("facility_sortOrder={0}, ", m_sortOrder);
			builder.AppendFormat("facility_fundedFacilityCost={0:F2}, ", m_fundedFacilityCost);
			builder.AppendFormat("facility_fundedReplaceValue={0:F2}, ", m_fundedReplaceValue);
			builder.AppendFormat("facility_usesCustomENR={0}, ", Drive.SQL.BoolToBit(m_usesCustomENR));

			//mam
			if (m_customENRListID == 0)
			{
				builder.AppendFormat("CustomENRListID={0} ", "null");
			}
			else
			{
				builder.AppendFormat("CustomENRListID={0} ", m_customENRListID);
			}
			//</mam>

			//mam 03202012 - if the facility is being imported, save the facility criticality regardless
			//	of whether or not ApplyFacilityCriticalityFactor is true
			//mam 01222012
			if (WAM.Common.Globals.ApplyFacilityCriticalityFactor || m_beingImported)
			{
				builder.AppendFormat(", FacilityCriticality={0:F2} ", m_facilityCriticality);
			}

//			//mam - save CurrentENR
//			builder.AppendFormat(", facility_currentENR={0} ", m_currentENR);
//			//</mam>

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.AppendFormat("WHERE (facility_id={0}) ", ID);

			//System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From Facilities WHERE facility_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Methods *****/

		//mam 102309 - override two delete methods because Drive library fails for WAMUSER when deleting facilities
		//	(connection string is missing password)
		public override bool Delete()
		{
			this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
			using (SqlConnection connection = new SqlConnection(this.m_sqlConnectionString))
			{
				connection.Open();
				return this.Delete(connection);
			}
		}
		public override bool Delete(SqlConnection sqlConnection)
		{
			//return base.Delete (sqlConnection);

			string deleteSql = this.GetDeleteSql();
			if (deleteSql.Length == 0)
			{
				return false;
			}
			try
			{
				new SqlCommand(deleteSql, sqlConnection).ExecuteNonQuery();
			}
			catch (SqlException exception)
			{
				//Trace.WriteLine(string.Format("{0}.Delete Error: {1}\n", this.ToString(), exception.Message));

				//mam 07072011
				throw exception;
			}
			InvokeChangeEvent(this, new DataChangeEventArgs(this, Drive.Synchronization.SyncAction.Delete));
			return true;
		}

		//mam
		public static FacilityComparer GetComparer()
		{
			return new Facility.FacilityComparer();
		}
		//</mam>

		public bool			SaveAsXML(string filePath)
		{
			System.IO.FileStream file = null;
			System.IO.StreamWriter writer = null;

			try
			{
				file = new System.IO.FileStream(filePath, 
					System.IO.FileMode.Create, System.IO.FileAccess.Write);

				writer = new System.IO.StreamWriter(file);

				//mam - added parameters - always get photos when displaying data in the application
				//	and pass in an empty string for the selectedFilters, which only apply to reports
				writer.Write(GetXML(true, ""));
				//</mam>

				writer.Flush();
				writer.Close();
				writer = null;
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}
			return true;
		}

		//mam - added parameters
		public string		GetXML(bool includePhotos, string selectedFilters)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;

			//mam 112806 - check all N/A for each facility or each process, as required
			//bool useNA = CheckIfAllNADiscipline();
			bool useNA = false;

			//mam 112806
			bool totalsOverrideCurrentValue = false;
			bool totalsOverrideRepairCost = false;

			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			//System.Diagnostics.Debug.WriteLine(selectedFilters.ToString());

			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();

			builder.Append("<FacilityData>\r\n");

			// Populate the basic facility data
			builder.Append("\t<Facility>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", CurrentENR);

			//mam 01222012
			decimal facCrit = WAM.Common.Globals.ApplyFacilityCriticalityFactor ? FacilityCriticality : 1.00M;
			builder.AppendFormat("\t\t<FacilityCriticality>{0:F2}</FacilityCriticality>\r\n", facCrit);

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			//mam
			if (includePhotos)
			{
			//</mam>

				//mam 03202012 - don't include path in photo file name because it is a mapped path on the user's machine that 
				//	will be different for all users
				//builder.AppendFormat("\t\t<Photo1Path><![CDATA[{0}]]></Photo1Path>\r\n", GetImage1PathReport());
				//builder.AppendFormat("\t\t<Photo2Path><![CDATA[{0}]]></Photo2Path>\r\n", GetImage2PathReport());
				builder.AppendFormat("\t\t<Photo1Path><![CDATA[{0}]]></Photo1Path>\r\n", PhotoFileNameNorth);
				builder.AppendFormat("\t\t<Photo2Path><![CDATA[{0}]]></Photo2Path>\r\n", PhotoFileNameSouth);

				builder.AppendFormat("\t\t<Photo1Caption><![CDATA[{0}]]></Photo1Caption>\r\n", CaptionNorth);
				builder.AppendFormat("\t\t<Photo2Caption><![CDATA[{0}]]></Photo2Caption>\r\n", CaptionSouth);
			}

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);

			decimal			acquisitionCost = GetAcquisitionCost();
			decimal			currentValue = GetCurrentValue();

			decimal			fundedAcquisitionCost = GetFundedAcquisitionCost();
			decimal			fundedCurrentValue = GetFundedCurrentValue();

			// FACILITY TOTALS

			//builder.AppendFormat("\t\t<TotalAcquisition><![CDATA[{0:F0}]]></TotalAcquisition>\r\n", acquisitionCost);
			builder.AppendFormat("\t\t<TotalAcquisition><![CDATA[{0:F0}]]></TotalAcquisition>\r\n", WAMRounding.RoundNumber(acquisitionCost, roundDigit));
			builder.AppendFormat("\t\t<TotalCurrentValue><![CDATA[{0:F0}]]></TotalCurrentValue>\r\n", WAMRounding.RoundNumber(currentValue, roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t<TotalAcquisitionEscalated><![CDATA[{0:F0}]]></TotalAcquisitionEscalated>\r\n", WAMRounding.RoundNumber(GetAcquisitionCostEscalated(), roundDigit));
			builder.AppendFormat("\t\t<TotalRehab><![CDATA[{0:F0}]]></TotalRehab>\r\n", WAMRounding.RoundNumber(GetRehabCost(), roundDigit));

			builder.AppendFormat("\t\t<AcqCostLessCumDepr><![CDATA[{0:F0}]]></AcqCostLessCumDepr>\r\n", WAMRounding.RoundNumber(acquisitionCost - GetCumulativeDepreciation(), roundDigit));
			builder.AppendFormat("\t\t<CurValLessRepairCost><![CDATA[{0:F0}]]></CurValLessRepairCost>\r\n", WAMRounding.RoundNumber(currentValue - GetRepairCost(), roundDigit));
			builder.AppendFormat("\t\t<ReplaceVal><![CDATA[{0:F0}]]></ReplaceVal>\r\n", WAMRounding.RoundNumber(GetReplacementValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t<ReplaceValYear><![CDATA[{0:F0}]]></ReplaceValYear>\r\n", GetReplacementValueYear());

			builder.AppendFormat("\t\t<FundedTotalAcquisition><![CDATA[{0:F0}]]></FundedTotalAcquisition>\r\n", WAMRounding.RoundNumber(fundedAcquisitionCost, roundDigit));
			builder.AppendFormat("\t\t<FundedTotalCurrentValue><![CDATA[{0:F0}]]></FundedTotalCurrentValue>\r\n", WAMRounding.RoundNumber(fundedCurrentValue, roundDigit));
			builder.AppendFormat("\t\t<FundedAcqCostLessCumDepr><![CDATA[{0:F0}]]></FundedAcqCostLessCumDepr>\r\n", WAMRounding.RoundNumber(fundedAcquisitionCost - GetFundedCumulativeDepreciation(), roundDigit));
			builder.AppendFormat("\t\t<FundedCurValLessRepairCost><![CDATA[{0:F0}]]></FundedCurValLessRepairCost>\r\n", WAMRounding.RoundNumber(fundedCurrentValue - GetFundedRepairCost(), roundDigit));
			builder.AppendFormat("\t\t<FundedReplaceVal><![CDATA[{0:F0}]]></FundedReplaceVal>\r\n", WAMRounding.RoundNumber(GetFundedReplacementValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t<FundedReplaceValYear><![CDATA[{0:F0}]]></FundedReplaceValYear>\r\n", GetReplacementValueYear());

			builder.Append("\t</Facility>\r\n");
			
			// TREATMENT PROCESS TOTALS

			// Populate the treatment process data
			WAM.Logic.TreatmentProcessTotals processTotals = GetProcessTotals();
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, ID);
			int				pos;

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalValue = processTotals.GetTotalCurrentValue();
			decimal			totalValue = processTotals.GetTotalAcquisitionCost();
			decimal			totalValueRounded = processTotals.GetTotalAcquisitionCostRoundIndividualValues();

			TreatmentProcess process;
			double			cwpVal = 0.0;
			decimal			orgCost = GetOrgCost();

			//mam
			adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(m_infoSetID, ID, totalValueRounded, WAM.UI.NodeType.Facility);
			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}
			//</mam>

			builder.Append("\t<Processes>\r\n");
			for (pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				builder.Append("\t\t<Process>\r\n");
				builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", process.Name);

				//mam - use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValueRounded != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}
				//</mam>

				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);
				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCost(), roundDigit));

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(process.GetReplacementValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", process.GetReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(process.GetRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(process.GetBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(process.GetSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(process.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(process.GetCumulativeDepreciation(), roundDigit));

				//mam 112806
				useNA = CheckIfAllNADisciplineForProcess(process.InfoSetID, process.ID);
				CheckIfProcessOverridden(process.InfoSetID, process.ID, true);

				//mam - added check for all Condition = N/A
				if (useNA)
				{
					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						//if any process has an overridden current value, set totalsOverrideCurrentValue to true;
						//	the value won't be reset to false until the next time this routine is called
						totalsOverrideCurrentValue = true;
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
					}

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						//if any process has an overridden repair cost, set totalsOverrideRepairCost to true;
						//	the value won't be reset to false until the next time this routine is called
						totalsOverrideRepairCost = true;
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
				}
				else
				{
					//mam 112806
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit).ToString("#,##0"));

					//builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", process.GetEvaluatedValue().ToString("#,##0"));
					//builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", process.GetRepairCost().ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(process.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("#,##0"));
				}

				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(process.GetAnnualMaintenanceCost(), roundDigit));
				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", process.GetRankPercent());
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", process.GetOrgUsefulLife());
				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", process.GetRemainingUsefulLife());

				if (useNA)
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", process.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", process.GetEconomicUsefulLife());
				}

				if (orgCost != 0m)
					cwpVal = Math.Round((double)(process.OrgCost / orgCost) * 100.0, 1);
				else
					cwpVal = 0.0;

				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", cwpVal);
				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", WAMRounding.RoundNumber(process.OrgCost, roundDigit));
				builder.Append("\t\t</Process>\r\n");
			}
			
			builder.Append("\t\t<Process>\r\n");
			builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", false);
			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", "Total");

			//mam - use the adjusted total when possible
			if (adjustedValues == null)
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", processTotals.GetCalcTotalCWP());
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", adjustedTotal);
			}
			//</mam>

			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalAcquisitionCost(), roundDigit));

			//mam 112806 - moved down
			//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalCurrentValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalAcquisitionCostEscalated(), roundDigit));

			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalReplacementValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", processTotals.GetAverageReplacementValueYear());
			builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalRehabCost(), roundDigit));

			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalBookValue(), roundDigit));
			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalSalvageValue(), roundDigit));
			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalAnnualDepreciation(), roundDigit));
			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalCumulativeDepreciation(), roundDigit));

			if (useNA)
			{
				//mam 112806
				if (totalsOverrideCurrentValue)
				{
					//mam 112806 - moved down from above
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
				}

				//mam 112806
				if (totalsOverrideRepairCost)
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalCurrentValue(), roundDigit).ToString("#,##0"));
				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalEvaluatedValue(), roundDigit).ToString("#,##0"));
				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalRepairCost(), roundDigit).ToString("#,##0"));
			}

			builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalAnnualMaintenanceCost(), roundDigit));
			builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", processTotals.GetRankPercent());
			builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", processTotals.GetTotalOrgUsefulLife());
			builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", processTotals.GetTotalRemainingUsefulLife());

			if (useNA)
			{
				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", processTotals.GetTotalEvaluatedRemainingUsefulLife());
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", processTotals.GetTotalEconomicUsefulLife());
			}

			builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", processTotals.GetTotalCWPValue() * 100.0);
			builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetTotalOrgCost(), roundDigit));
			builder.Append("\t\t</Process>\r\n");
			//</mam>

			builder.Append("\t</Processes>\r\n");

			//*******************************

			// Append Funded Processes

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//totalValue = processTotals.GetFundedTotalCurrentValue();
			totalValue = processTotals.GetFundedTotalAcquisitionCost();
			totalValueRounded = processTotals.GetFundedTotalAcquisitionCostRoundIndividualValues();

			builder.Append("\t<FundedProcesses>\r\n");
			for (pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				if (!process.IsFunded) // skip non-funded processes
					continue;

				builder.Append("\t\t<FundedProcess>\r\n");
				builder.AppendFormat("\t\t\t<FundGridName><![CDATA[{0}]]></FundGridName>\r\n", process.Name);
				builder.AppendFormat("\t\t\t<FundGridPctFunded><![CDATA[{0:F1}]]></FundGridPctFunded>\r\n", process.PctFunded * 100.0);

				//mam 091607 - use rounded values
				if (totalValueRounded != 0)
				{
					//mam 112806 - use AcquisitionCost instead of CurrentValue
					//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
					cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
				}
				else
				{
					cwpVal = 0.0;
				}

				builder.AppendFormat("\t\t\t<FundGridCWP><![CDATA[{0:F1}]]></FundGridCWP>\r\n", cwpVal);
				builder.AppendFormat("\t\t\t<FundGridAcquisitionCost><![CDATA[{0:F0}]]></FundGridAcquisitionCost>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCost(), roundDigit));

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<FundGridAcquisitionCostEscalated><![CDATA[{0:F0}]]></FundGridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(process.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<FundGridReplacementValue><![CDATA[{0:F0}]]></FundGridReplacementValue>\r\n", WAMRounding.RoundNumber(process.GetReplacementValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<FundGridReplacementValueYear><![CDATA[{0:F0}]]></FundGridReplacementValueYear>\r\n", process.GetReplacementValueYear());
				builder.AppendFormat("\t\t\t<FundGridRehabCost><![CDATA[{0:F0}]]></FundGridRehabCost>\r\n", WAMRounding.RoundNumber(process.GetRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<FundGridBookValue><![CDATA[{0:F0}]]></FundGridBookValue>\r\n", WAMRounding.RoundNumber(process.GetBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<FundGridSalvageValue><![CDATA[{0:F0}]]></FundGridSalvageValue>\r\n", WAMRounding.RoundNumber(process.GetSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<FundGridAnnualDepreciation><![CDATA[{0:F0}]]></FundGridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(process.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<FundGridCumulativeDepreciation><![CDATA[{0:F0}]]></FundGridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(process.GetCumulativeDepreciation(), roundDigit));

				//mam 11280
				useNA = CheckIfAllNADisciplineForProcess(process.InfoSetID, process.ID);
				CheckIfProcessOverridden(process.InfoSetID, process.ID, true);

				if (useNA)
				{
					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						totalsOverrideCurrentValue = true;

						//mam 112806 - moved down from above
						builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));
					}
					else
					{
						builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", "N/A");
					}

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						totalsOverrideRepairCost = true;
						builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", "N/A");
					}
					else
					{
						builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", "N/A");
				}
				else
				{
					//mam 112806
					builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));

					builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", WAMRounding.RoundNumber(process.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit).ToString("#,##0"));
				}

				builder.AppendFormat("\t\t\t<FundGridAnnualMaintenanceCost><![CDATA[{0:F0}]]></FundGridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(process.GetAnnualMaintenanceCost(), roundDigit));
				builder.AppendFormat("\t\t\t<FundGridRankPercent><![CDATA[{0:F1}]]></FundGridRankPercent>\r\n", process.GetRankPercent());
				builder.AppendFormat("\t\t\t<FundGridOrgUsefulLife><![CDATA[{0:F1}]]></FundGridOrgUsefulLife>\r\n", process.GetOrgUsefulLife());
				builder.AppendFormat("\t\t\t<FundGridRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridRemainingUsefulLife>\r\n", process.GetRemainingUsefulLife());

				if (useNA)
				{
					builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<FundGridEconomicUsefulLife><![CDATA[{0:F1}]]></FundGridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", process.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<FundGridEconomicUsefulLife><![CDATA[{0:F1}]]></FundGridEconomicUsefulLife>\r\n", process.GetEconomicUsefulLife());
				}

				builder.Append("\t\t</FundedProcess>\r\n");
			}
			builder.Append("\t\t<FundedProcess>\r\n");
			builder.AppendFormat("\t\t\t<FundGridName><![CDATA[{0}]]></FundGridName>\r\n", "Total");
			builder.Append("\t\t\t<FundGridPctFunded></FundGridPctFunded>\r\n");
			builder.AppendFormat("\t\t\t<FundGridCWP><![CDATA[{0:F1}]]></FundGridCWP>\r\n", processTotals.GetFundedCalcTotalCWP());
			builder.AppendFormat("\t\t\t<FundGridAcquisitionCost><![CDATA[{0:F0}]]></FundGridAcquisitionCost>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalAcquisitionCost(), roundDigit));

			//mam 112806 - moved down
			//builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalCurrentValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t\t<FundGridAcquisitionCostEscalated><![CDATA[{0:F0}]]></FundGridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalAcquisitionCostEscalated(), roundDigit));

			builder.AppendFormat("\t\t\t<FundGridReplacementValue><![CDATA[{0:F0}]]></FundGridReplacementValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalReplacementValue(), roundDigit));

			//mam 050806
			builder.AppendFormat("\t\t\t<FundGridReplacementValueYear><![CDATA[{0:F0}]]></FundGridReplacementValueYear>\r\n", processTotals.GetAverageReplacementValueYear());
			builder.AppendFormat("\t\t\t<FundGridRehabCost><![CDATA[{0:F0}]]></FundGridRehabCost>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalRehabCost(), roundDigit));

			builder.AppendFormat("\t\t\t<FundGridBookValue><![CDATA[{0:F0}]]></FundGridBookValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalBookValue(), roundDigit));
			builder.AppendFormat("\t\t\t<FundGridSalvageValue><![CDATA[{0:F0}]]></FundGridSalvageValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalSalvageValue(), roundDigit));
			builder.AppendFormat("\t\t\t<FundGridAnnualDepreciation><![CDATA[{0:F0}]]></FundGridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalAnnualDepreciation(), roundDigit));
			builder.AppendFormat("\t\t\t<FundGridCumulativeDepreciation><![CDATA[{0:F0}]]></FundGridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalCumulativeDepreciation(), roundDigit));

			if (useNA)
			{
				//mam 112806
				if (totalsOverrideCurrentValue)
				{
					//mam 112806 - moved down from above
					builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalCurrentValue(), roundDigit));
				}
				else
				{
					builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", "N/A");
				}

				//mam 112806
				if (totalsOverrideRepairCost)
				{
					builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalRepairCost(), roundDigit).ToString("#,##0"));
				}
				else
				{
					builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", "N/A");
			}
			else
			{
				//mam 112806
				builder.AppendFormat("\t\t\t<FundGridCurrentValue><![CDATA[{0:F0}]]></FundGridCurrentValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalCurrentValue(), roundDigit));

				builder.AppendFormat("\t\t\t<FundGridEvaluatedValue><![CDATA[{0:F0}]]></FundGridEvaluatedValue>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalEvaluatedValue(), roundDigit).ToString("#,##0"));
				builder.AppendFormat("\t\t\t<FundGridRepairCost><![CDATA[{0:F0}]]></FundGridRepairCost>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalRepairCost(), roundDigit).ToString("#,##0"));
			}

			builder.AppendFormat("\t\t\t<FundGridAnnualMaintenanceCost><![CDATA[{0:F0}]]></FundGridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(processTotals.GetFundedTotalAnnualMaintenanceCost(), roundDigit));
			builder.AppendFormat("\t\t\t<FundGridRankPercent><![CDATA[{0:F1}]]></FundGridRankPercent>\r\n", processTotals.GetRankPercent());
			builder.AppendFormat("\t\t\t<FundGridOrgUsefulLife><![CDATA[{0:F1}]]></FundGridOrgUsefulLife>\r\n", processTotals.GetFundedTotalOrgUsefulLife());
			builder.AppendFormat("\t\t\t<FundGridRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridRemainingUsefulLife>\r\n", processTotals.GetFundedTotalRemainingUsefulLife());

			if (useNA)
			{
				builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<FundGridEconomicUsefulLife><![CDATA[{0:F1}]]></FundGridEconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t\t<FundGridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></FundGridEvaluatedRemainingUsefulLife>\r\n", processTotals.GetFundedTotalEvaluatedRemainingUsefulLife());
				builder.AppendFormat("\t\t\t<FundGridEconomicUsefulLife><![CDATA[{0:F1}]]></FundGridEconomicUsefulLife>\r\n", processTotals.GetFundedTotalEconomicUsefulLife());
			}

			builder.Append("\t\t</FundedProcess>\r\n");
			builder.Append("\t</FundedProcesses>\r\n");

			builder.Append("</FacilityData>\r\n");

			return builder.ToString();
		}

		//mam
		public string GetXMLMatrix(bool includePhotos, string selectedFilters, string selectedSortOrder, ArrayList filteredItems)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			bool useNA = false;

			StringBuilder	builder = new StringBuilder();

			//remove (char)34
			if (selectedFilters != "" && selectedFilters.StartsWith(Convert.ToString((char)34)))
			{
				selectedFilters = selectedFilters.Remove(0,1);
				int j = selectedFilters.IndexOf((char)34);
				if (j > -1)
					selectedFilters = selectedFilters.Remove(j, 1);
			}

			builder.Append("<FacilityData>\r\n");

			builder.Append("\t<Filters>\r\n");
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			builder.AppendFormat("\t\t<SelectedSortOrder><![CDATA[{0}]]></SelectedSortOrder>\r\n", selectedSortOrder);
			builder.Append("\t</Filters>\r\n");
			
//			WAM.Logic.TreatmentProcessTotals processTotals = null;
			int				pos;
			//TreatmentProcess process;
			Facility facility;
//			double			cwpVal = 0.0;

			builder.Append("\t<Facilities>\r\n");
			//			for (pos = 0; pos < processes.Length; pos++)
			for (pos = 0; pos < filteredItems.Count; pos++)
			{
				//process = processes[pos];
				facility = (Facility)filteredItems[pos];
//				processTotals = facility.GetProcessTotals();
//				decimal totalValue = processTotals.GetTotalCurrentValue();
//				decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(process.InfoSetID, process.FacilityID, totalValue, WAM.UI.NodeType.Facility);

				//mam 112806
				useNA = CheckIfAllNADisciplineForFacility(facility.InfoSetID, facility.ID);
				CheckIfFacilityOverridden(facility.InfoSetID, facility.ID);

				builder.Append("\t\t<Facility>\r\n");
//				builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", facility.Name);

//				//mam - use the adjusted cwp value rather than a straight calculation when possible
//				if (adjustedValues == null)
//				{
//					if (totalValue != 0)
//						cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
//					else
//						cwpVal = 0.0;
//				}
//				else
//				{
//					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
//				}
//				//</mam>

				//builder.AppendFormat("\t\t\t<GridCWP><![CDATA[{0:F1}]]></GridCWP>\r\n", cwpVal);
				builder.AppendFormat("\t\t\t<GridCurrentYear><![CDATA[{0:F0}]]></GridCurrentYear>\r\n", facility.CurrentYear);
				builder.AppendFormat("\t\t\t<GridCurrentENR>{0}</GridCurrentENR>\r\n", facility.CurrentENR);

				//mam 01222012
				decimal facCrit = WAM.Common.Globals.ApplyFacilityCriticalityFactor ? facility.FacilityCriticality : 1.00M;
				builder.AppendFormat("\t\t\t<GridFacilityCriticality><![CDATA[{0:F2}]]></GridFacilityCriticality>\r\n", facCrit);

				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", WAMRounding.RoundNumber(facility.GetAcquisitionCost(), roundDigit));

				//mam 112806 - moved down
				//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(facility.GetCurrentValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", WAMRounding.RoundNumber(facility.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", WAMRounding.RoundNumber(facility.GetReplacementValue(), roundDigit));

				//mam 050806
				builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", facility.GetReplacementValueYear());
				builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", WAMRounding.RoundNumber(facility.GetRehabCost(), roundDigit));

				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", WAMRounding.RoundNumber(facility.GetBookValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", WAMRounding.RoundNumber(facility.GetSalvageValue(), roundDigit));
				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", WAMRounding.RoundNumber(facility.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", WAMRounding.RoundNumber(facility.GetCumulativeDepreciation(), roundDigit));

				if (useNA)
				{
					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(facility.GetCurrentValue(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", "N/A");
					}

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(facility.GetRepairCost(), roundDigit).ToString("#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
				}
				else
				{
					//mam 112806
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", WAMRounding.RoundNumber(facility.GetCurrentValue(), roundDigit).ToString("#,##0"));

					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", WAMRounding.RoundNumber(facility.GetEvaluatedValue(), roundDigit).ToString("#,##0"));
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", WAMRounding.RoundNumber(facility.GetRepairCost(), roundDigit).ToString("#,##0"));
				}

				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", WAMRounding.RoundNumber(facility.GetAnnualMaintenanceCost(), roundDigit));
				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", facility.GetRankPercent());
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", facility.GetOrgUsefulLife());
				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", facility.GetRemainingUsefulLife());

				if (useNA)
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", facility.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", facility.GetEconomicUsefulLife());
				}

				//				if (orgCost != 0m)
				//					cwpVal = Math.Round((double)(process.OrgCost / orgCost) * 100.0, 1);
				//				else
				//					cwpVal = 0.0;

				//				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", cwpVal);
////				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", process.OrgCost);


//				builder.AppendFormat("\t\t\t<GridCurrentYear><![CDATA[{0:F0}]]></GridCurrentYear>\r\n", facility.CurrentYear);
//				builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", processTotals.GetTotalAcquisitionCost());
//				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", processTotals.GetTotalCurrentValue());
//				builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", processTotals.GetTotalReplacementValue());
//				builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", processTotals.GetTotalBookValue());
//				builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", processTotals.GetTotalSalvageValue());
//				builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", processTotals.GetTotalAnnualDepreciation());
//				builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", processTotals.GetTotalCumulativeDepreciation());
//	
//				if (useNA)
//				{
//					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", "N/A");
//					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", "N/A");
//				}
//				else
//				{
//					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", processTotals.GetTotalEvaluatedValue().ToString("#,##0"));
//					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", processTotals.GetTotalRepairCost().ToString("#,##0"));
//				}
//	
//				builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", processTotals.GetTotalAnnualMaintenanceCost());
//				builder.AppendFormat("\t\t\t<GridRankPercent><![CDATA[{0:F1}]]></GridRankPercent>\r\n", processTotals.GetRankPercent());
//				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", processTotals.GetTotalOrgUsefulLife());
//				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", processTotals.GetTotalRemainingUsefulLife());
//	
//				if (useNA)
//					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
//				else
//					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", processTotals.GetTotalEvaluatedRemainingUsefulLife());
//
//				builder.AppendFormat("\t\t\t<AllocGridCWP><![CDATA[{0:F1}]]></AllocGridCWP>\r\n", processTotals.GetTotalCWPValue() * 100.0);
//				builder.AppendFormat("\t\t\t<AllocGridCurrentValue><![CDATA[{0:F0}]]></AllocGridCurrentValue>\r\n", processTotals.GetTotalOrgCost());

				builder.Append("\t\t</Facility>\r\n");
			}

			builder.Append("\t</Facilities>\r\n");

			builder.Append("</FacilityData>\r\n");

			//			builder.Append("</MatrixData>\r\n");

			return builder.ToString();
		}
		//</mam>

		//mam
		public string GetCSVData(string selectedFilters, string selectedSortOrder, ArrayList filteredItems, bool includeProcesses)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			Facility facility;
			StringBuilder builder = new StringBuilder();
			string processXML = "";
			bool useNA = false;
			
			if (includeProcesses)
                builder.Append((char)34 + "Facility / System Detail Report" + (char)34);
			else
				builder.Append((char)34 + "Facility / System Summary Report" + (char)34);

			builder.Append("\r\n");

			if (selectedFilters != "")
			{
				//modify selectedFilters language if report is a detail report
				if (includeProcesses)
				{
					selectedFilters = selectedFilters.Replace("The totals for this", "Each");
					selectedFilters = selectedFilters.Replace("have", "in this report has");
				}

				builder.Append("\r\n");
				//builder.AppendFormat((char)34 + selectedFilters + (char)34);
				builder.AppendFormat(selectedFilters);
				builder.Append("\r\n\r\n");
			}

			//include sort order on both summary and detail CSV reports
			//if (selectedSortOrder != "" && !includeProcesses)
			if (selectedSortOrder != "")
			{
				builder.AppendFormat((char)34 + selectedSortOrder + (char)34);
				builder.Append("\r\n\r\n");
			}

			builder.Append((char)34 + "Facility / System" + (char)34);
			if (includeProcesses)
			{
				builder.Append("," + (char)34 + "Treatment Process / Basin / Zone" + (char)34);
			}
			builder.Append("," + (char)34 + "Current Year" + (char)34);
			builder.Append("," + (char)34 + "Current ENR" + (char)34);

			//mam 01222012
			builder.Append("," + (char)34 + "Facility Criticality" + (char)34);

			if (includeProcesses)
			{
				builder.Append("," + (char)34 + "Cost Weighted Percent of Asset Value (%)" + (char)34);
			}
			builder.Append("," + (char)34 + "Acquisition Cost" + (char)34);
			builder.Append("," + (char)34 + "Current Value" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Escalated Acquisition Cost" + (char)34);

			builder.Append("," + (char)34 + "Replacement Value" + (char)34);

			//mam 112806
			builder.Append("," + (char)34 + "Average Replacement Value Year" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Rehabilitation Cost" + (char)34);

			builder.Append("," + (char)34 + "Book Value" + (char)34);
			builder.Append("," + (char)34 + "Salvage Value" + (char)34);
			builder.Append("," + (char)34 + "Annual Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Cumulative Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Value" + (char)34);
			builder.Append("," + (char)34 + "Repair Cost" + (char)34);
			builder.Append("," + (char)34 + "Annual Maintenance Cost" + (char)34);

			//mam 011206
			builder.Append("," + (char)34 + "Comments" + (char)34);

			//mam 03202012
			builder.Append("," + (char)34 + "Photo File 1" + (char)34);
			builder.Append("," + (char)34 + "Photo Caption 1" + (char)34);
			builder.Append("," + (char)34 + "Photo File 2" + (char)34);
			builder.Append("," + (char)34 + "Photo Caption 2" + (char)34);

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				facility = (Facility)filteredItems[pos];
				useNA = CheckIfAllNADisciplineForFacility(facility.InfoSetID, facility.ID);

				//mam 112806
				CheckIfFacilityOverridden(facility.InfoSetID, facility.ID);

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);

				if (includeProcesses)
				{
					builder.Append(",");
				}
				builder.AppendFormat(",{0:F0}", facility.CurrentYear);
				builder.AppendFormat(",{0:F0}", facility.CurrentENR);

				//mam 01222012
				if (WAM.Common.Globals.ApplyFacilityCriticalityFactor)
				{
					builder.AppendFormat(",{0:F2}", facility.FacilityCriticality);
				}
				else
				{
					builder.AppendFormat(",{0:F2}", 1.00M);
				}

				if (includeProcesses)
				{
					builder.Append(",");
				}
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetAcquisitionCost(), roundDigit));

				//mam 112806 - check useNA and overrides
				if (useNA)
				{
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetCurrentValue(), roundDigit));
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetCurrentValue(), roundDigit));
				}

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetReplacementValue(), roundDigit));

				//mam 112806
				builder.AppendFormat(",{0:F0}", facility.GetReplacementValueYear());

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetRehabCost(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetBookValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetSalvageValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetCumulativeDepreciation(), roundDigit));

				if (useNA)
				{
					builder.Append(",N/A");

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetRepairCost(), roundDigit).ToString("0"));
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetEvaluatedValue(), roundDigit).ToString("0"));
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetRepairCost(), roundDigit).ToString("0"));
				}
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(facility.GetAnnualMaintenanceCost(), roundDigit));

				//mam 101107 - replace double quote in comments with two double quotes 
				string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@facility.Comments);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);
				////mam 011206
				//builder.Append("," + (char)34 + facility.Comments + (char)34);

				//mam 03202012
				string caption1 = ReplaceDoubleQuoteWithTwoDoubleQuotes(@facility.CaptionNorth);
				string caption2 = ReplaceDoubleQuoteWithTwoDoubleQuotes(@facility.CaptionSouth);
				builder.AppendFormat(",{0}", facility.PhotoFileNameNorth);
				builder.AppendFormat(",{0}", caption1);
				builder.AppendFormat(",{0}", facility.PhotoFileNameSouth);
				builder.AppendFormat(",{0}", caption2);

				if (includeProcesses)
				{
					processXML = GetCSVDataProcesses(facility);
					builder.Append(processXML);
				}

				//builder.Append("Rank Percent");
				//builder.AppendFormat("<![CDATA[{0:F0}]]>", facility.GetRankPercent());
				//builder.Append("Original UsefulLife");
				//builder.AppendFormat("<![CDATA[{0:F1}]]>", facility.GetOrgUsefulLife());
				//builder.Append("Remaining UsefulLife");
				//builder.AppendFormat("<![CDATA[{0:F1}]]>", facility.GetRemainingUsefulLife());

				//if (useNA)
				//{
				//	builder.Append("Evaluated Remaining Useful Life");
				//	builder.Append("N/A");
				//}
				//else
				//{
				//	builder.Append("Evaluated Remaining UsefulLife");
				//	builder.AppendFormat("<![CDATA[{0:F1}]]>", facility.GetEvaluatedRemainingUsefulLife());
				//}
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		private string GetCSVDataProcesses(Facility facility)
		{
			//mam
			WAM.Common.Rounding WAMRounding = new WAM.Common.Rounding();
			double roundDigit = WAM.Common.Globals.AllowRoundingDigit;
			if (!WAM.Common.Globals.AllowRounding || roundDigit < 1)
			{
				roundDigit = 0;
			}
			//</mam>

			TreatmentProcess[] processes = CacheManager.GetProcesses(facility.InfoSetID, facility.ID);
			TreatmentProcess process;
			WAM.Logic.TreatmentProcessTotals processTotals = facility.GetProcessTotals();

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal totalValue = processTotals.GetTotalCurrentValue();
			decimal totalValue = processTotals.GetTotalAcquisitionCost();
			decimal totalValueRounded = processTotals.GetTotalAcquisitionCostRoundIndividualValues();

			double cwpVal = 0.0;

			//mam 112806 - check for each process, rather than for a facility
			//bool useNA = CheckIfAllNADiscipline(facility);
			bool useNA = false;

			StringBuilder builder = new StringBuilder();

			adjustedTotal = 0;
			decimal[] adjustedValues = WAM.Common.CommonTasks.AdjustCWPValues(facility.InfoSetID, facility.ID, totalValueRounded, WAM.UI.NodeType.Facility);
			if (adjustedValues != null)
			{
				for (int i = 0; i < adjustedValues.Length; i++)
				{
					adjustedTotal += adjustedValues[i];
				}
			}

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];

				//use the adjusted cwp value rather than a straight calculation when possible
				if (adjustedValues == null)
				{
					if (totalValueRounded != 0)
					{
						//mam 112806 - use AcquisitionCost instead of CurrentValue
						//cwpVal = Math.Round((double)(process.GetCurrentValue() / totalValue) * 100.0, 1);
						cwpVal = Math.Round((double)(process.GetAcquisitionCostRoundIndividualValues() / totalValueRounded) * 100.0, 1);
					}
					else
					{
						cwpVal = 0.0;
					}
				}
				else
				{
					cwpVal = Convert.ToDouble(adjustedValues[pos].ToString());
				}

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);

				builder.AppendFormat(",");	//current year
				builder.AppendFormat(",");	//current enr

				//mam 01222012
				builder.AppendFormat(",");	//facility criticality

				builder.AppendFormat(",{0:F1}", cwpVal);
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAcquisitionCost(), roundDigit));

				//mam 112806
				useNA = CheckIfAllNADisciplineForProcess(process.InfoSetID, process.ID);
				CheckIfProcessOverridden(process.InfoSetID, process.ID, true);

				//mam 112806 - check useNA and overrides
				if (useNA)
				{
					//mam 112806
					if (mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));
					}
					else
					{
						builder.AppendFormat(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCurrentValue(), roundDigit));
				}

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAcquisitionCostEscalated(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetReplacementValue(), roundDigit));

				//mam 112806
				builder.AppendFormat(",{0:F0}", process.GetReplacementValueYear());

				//mam 050806
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRehabCost(), roundDigit));

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetBookValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetSalvageValue(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAnnualDepreciation(), roundDigit));
				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetCumulativeDepreciation(), roundDigit));

				//builder.AppendFormat("\t\t\t<GridFunded>{0}</GridFunded>\r\n", process.IsFunded);

				if (useNA)
				{
					builder.AppendFormat(",N/A");

					//mam 112806
					if (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost)
					{
						builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit));
					}
					else
					{
						builder.AppendFormat(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetEvaluatedValue(), roundDigit));
					builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetRepairCost(), roundDigit));
				}

				builder.AppendFormat(",{0:F0}", WAMRounding.RoundNumber(process.GetAnnualMaintenanceCost(), roundDigit));

				//mam 101107 - replace double quote in comments with two double quotes 
				string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@process.Comments);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);
				////mam 011206
				//builder.Append("," + (char)34 + process.Comments + (char)34);

				//builder.AppendFormat(",{0:F1}", process.GetRankPercent());
				//builder.AppendFormat(",{0:F1}", process.GetOrgUsefulLife());
				//builder.AppendFormat(",{0:F1}", process.GetRemainingUsefulLife());

				//if (useNA)
				//	builder.AppendFormat(",N/A");
				//else
				//	builder.AppendFormat(",{0:F1}", process.GetEvaluatedRemainingUsefulLife());

				//mam 03202012
				string caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@process.CaptionPhoto);
				builder.AppendFormat(",{0}", process.PhotoFileName);
				builder.AppendFormat(",{0}", caption);
			}

			return builder.ToString();
		}
		//</mam>

		//mam - add routine to check whether Condition for all pipes is N/A
		private bool GetAllConditionNAPipes(int curInfosetID, int curDisciplineID)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(curInfosetID, curDisciplineID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether Condition for all nodes is N/A
		private bool GetAllConditionNANodes(int curInfosetID, int curDisciplineID)
		{
			// Retrieve the pipe data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(curInfosetID, curDisciplineID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam 112806
		private void CheckIfProcessOverridden(int curInfosetID, int curProcessID, bool resetVariables)
		{
			MajorComponent[] components = CacheManager.GetComponents(curInfosetID, curProcessID);
			MajorComponent component;
			Discipline discipline;
			DisciplinePipe pipe;
			DisciplineNode node;

			if (resetVariables)
			{
				ResetOverrideVariables();
			}

			for (int posComp = 0; posComp < components.Length; posComp++)
			{
				component = components[posComp];

				if (component.Retired)
					continue;

				Discipline[] disciplines = CacheManager.GetDisciplines(InfoSet.CurrentID, component.ID);

				for (int pos = 0; pos < disciplines.Length; pos++)
				{
					discipline = disciplines[pos];

					if (discipline.Type == DisciplineType.Pipes)
					{
						pipe = discipline as DisciplinePipe;

						if (pipe.GetAnyCurrentValueOverridden())
						{
							pipeOverrideAnyCurrentValue = true;
						}
						if (pipe.GetAnyRepairCostOverridden())
						{
							pipeOverrideAnyRepairCost = true;
						}
					}
					else if (discipline.Type == DisciplineType.Nodes)
					{
						node = discipline as DisciplineNode;

						if (node.GetAnyCurrentValueOverridden())
						{
							nodeOverrideAnyCurrentValue = true;
						}
						if (node.GetAnyRepairCostOverridden())
						{
							nodeOverrideAnyRepairCost = true;
						}
					}
					else
					{
						if (discipline.OverrideCurrentValue)
						{
							mscOverrideAnyCurrentValue = true;
						}

						if (discipline.OverrideRepairCost)
						{
							mscOverrideAnyRepairCost = true;
						}
					}
				}
			}
		}
		//</mam>

		//mam 112806
		private void CheckIfFacilityOverridden(int curInfosetID, int curFacilityID)
		{
			TreatmentProcess[] processes = CacheManager.GetProcesses(m_infoSetID, curFacilityID);

			ResetOverrideVariables();

			for (int pos = 0; pos < processes.Length; pos++)
			{
				CheckIfProcessOverridden(processes[pos].InfoSetID, processes[pos].ID, false);

				if ((mscOverrideAnyCurrentValue || pipeOverrideAnyCurrentValue || nodeOverrideAnyCurrentValue)
					&& (mscOverrideAnyRepairCost || pipeOverrideAnyRepairCost || nodeOverrideAnyRepairCost))
				{
					break;
				}
			}
		}
		//</mam>

		//mam 112806
		private void ResetOverrideVariables()
		{
			mscOverrideAnyCurrentValue = false;
			mscOverrideAnyRepairCost = false;
			pipeOverrideAnyCurrentValue = false;
			pipeOverrideAnyRepairCost = false;
			nodeOverrideAnyCurrentValue = false;
			nodeOverrideAnyRepairCost = false;
		}

		//mam
		private bool CheckIfAllNADisciplineForProcess(int curInfosetID, int curProcessID)
		{
			//mam - check whether all Disciplines for this Facility have Condition = N/A;

			bool AllNA = true;

			//TreatmentProcess[]	processes = CacheManager.GetProcesses(curInfosetID, curProcessID);
			//TreatmentProcess	process;
			TreatmentProcess process = CacheManager.GetTreatmentProcess(curInfosetID, curProcessID);
			MajorComponent[]	components;
			MajorComponent		component;
			Discipline[] disciplines;
			Discipline discipline;

			//for (int pos = 0; pos < processes.Length; pos++)
			{
				//process = processes[pos];
				components = CacheManager.GetComponents(process.InfoSetID, process.ID);

				for (int pos2 = 0; pos2 < components.Length; pos2++)
				{
					component = components[pos2];

					if (component.Retired)
						continue;

					disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);

					for (int pos3 = 0; pos3 < disciplines.Length; pos3++)
					{
						discipline = disciplines[pos3];

						if (discipline.Type == DisciplineType.Pipes)
						{
							if (!GetAllConditionNAPipes(discipline.InfoSetID, discipline.ID))
								return false;
						}
						else if (discipline.Type == DisciplineType.Nodes)
						{
							if (!GetAllConditionNANodes(discipline.InfoSetID, discipline.ID))
								return false;
						}
						else if (discipline.Type == DisciplineType.Mechanical 
							|| discipline.Type == DisciplineType.Structural
							|| discipline.Type == DisciplineType.Land)
						{
							if (discipline.ConditionRanking != CondRank.No)
								return false;
						}
					}
				}
			}
			return AllNA;
		}
		//</mam>

		//mam
		//private bool CheckIfAllNADiscipline(Facility facility)
		private bool CheckIfAllNADisciplineForFacility(int curInfosetID, int curFacilityID)
		{
			//mam - check whether all Disciplines for this Facility have Condition = N/A;

			bool AllNA = true;

			TreatmentProcess[]	processes = CacheManager.GetProcesses(curInfosetID, curFacilityID);
			TreatmentProcess	process;
			MajorComponent[]	components;
			MajorComponent		component;
			Discipline[] disciplines;
			Discipline discipline;

			for (int pos = 0; pos < processes.Length; pos++)
			{
				process = processes[pos];
				components = CacheManager.GetComponents(process.InfoSetID, process.ID);

				for (int pos2 = 0; pos2 < components.Length; pos2++)
				{
					component = components[pos2];

					if (component.Retired)
						continue;

					disciplines = CacheManager.GetDisciplines(component.InfoSetID, component.ID);

					for (int pos3 = 0; pos3 < disciplines.Length; pos3++)
					{
						discipline = disciplines[pos3];

						if (discipline.Type == DisciplineType.Pipes)
						{
							if (!GetAllConditionNAPipes(discipline.InfoSetID, discipline.ID))
								return false;
						}
						else if (discipline.Type == DisciplineType.Nodes)
						{
							if (!GetAllConditionNANodes(discipline.InfoSetID, discipline.ID))
								return false;
						}
						else if (discipline.Type == DisciplineType.Mechanical 
							|| discipline.Type == DisciplineType.Structural
							|| discipline.Type == DisciplineType.Land)
						{
							if (discipline.ConditionRanking != CondRank.No)
								return false;
						}
					}
				}
			}
			return AllNA;
		}
		//</mam>

		public void			CopyTo(Facility copy)
		{
			//copy.m_infoSetID = 0; // Don't copy InfoSet
			copy.m_name = m_name;
			copy.m_currentYear = m_currentYear;
			copy.m_currentENR = m_currentENR;
			copy.m_captionNorth = m_captionNorth;
			copy.m_captionSouth = m_captionSouth;
			copy.m_captionEast = m_captionEast;
			copy.m_captionWest = m_captionWest;
			copy.m_comments = m_comments;

			//mam 03202012
			copy.m_photoFileNameNorth = m_photoFileNameNorth;
			copy.m_photoFileNameSouth = m_photoFileNameSouth;

			//mam 102309
			//copy.m_photoNorth = m_photoNorth;
			//copy.m_photoSouth = m_photoSouth;

			copy.m_replacementVal = m_replacementVal;
			copy.m_oldOrgCost = m_oldOrgCost;
			copy.m_newFacilityCost = m_newFacilityCost;
			copy.m_sortOrder = m_sortOrder;
			copy.m_fundedFacilityCost = m_fundedFacilityCost;
			copy.m_fundedReplaceValue = m_fundedReplaceValue;
			copy.m_usesCustomENR = m_usesCustomENR;

			//mam
			copy.m_customENRListID = m_customENRListID;
			//</mam>

			//mam 01222012
			copy.m_facilityCriticality = m_facilityCriticality;
		}

		//mam - allow or disallow copying of photos
		public void CopyTo(Facility copy, bool copyPhoto)
		{
			//copy.m_infoSetID = 0; // Don't copy InfoSet
			copy.m_name = m_name;
			copy.m_currentYear = m_currentYear;
			copy.m_currentENR = m_currentENR;

			if (copyPhoto)
			{
				copy.m_captionNorth = m_captionNorth;
				copy.m_captionSouth = m_captionSouth;
				copy.m_captionEast = m_captionEast;
				copy.m_captionWest = m_captionWest;

				//mam 03202012
				copy.m_photoFileNameNorth = m_photoFileNameNorth;
				copy.m_photoFileNameSouth = m_photoFileNameSouth;

				//mam 102309
				//copy.m_photoNorth = m_photoNorth;
				//copy.m_photoSouth = m_photoSouth;
			}

			copy.m_comments = m_comments;
			copy.m_replacementVal = m_replacementVal;
			copy.m_oldOrgCost = m_oldOrgCost;
			copy.m_newFacilityCost = m_newFacilityCost;
			copy.m_sortOrder = m_sortOrder;
			copy.m_fundedFacilityCost = m_fundedFacilityCost;
			copy.m_fundedReplaceValue = m_fundedReplaceValue;
			copy.m_usesCustomENR = m_usesCustomENR;

			//mam
			copy.m_customENRListID = m_customENRListID;
			//</mam>

			//mam 01222012
			copy.m_facilityCriticality = m_facilityCriticality;
		}
		//</mam>

		//mam - allow new facility name
		public void CopyTo(Facility copy, string newFacilityName, bool copyPhoto)
		{
			CopyTo(copy, copyPhoto);
			copy.m_name = newFacilityName;

			//mam 112806 - setting m_sortOrder here is overriding the value that was copied into it above
			//copy.m_sortOrder = 65000;

			//if (copy.m_sortOrder != 65000)
			//	copy.m_sortOrder = m_sortOrder + 1;
		}
		//</mam>

		//mam - this method has been replaced (below)
		//public void			CopyENRTable(Facility copy)
		//{
		//	if (m_usesCustomENR)
		//	{
		//		LoadCustomENRValues();
		//
		//		ENRCustom[] values = GetAllENRValues();
		//
		//		for (int pos = 0; pos < values.Length; pos++)
		//			copy.SetENRValueForYear(values[pos].Year, values[pos].ENRValue);
		//	}
		//}
		//</mam>

		//mam - modified the method above to copy custom ENR values from one database to another, as this routine
		//	is used only when importing infosets from another database
		//mam 102309
		//public void CopyENRTable(Facility newFacility, OleDbConnection sourceConnection)
		public void CopyENRTable(Facility newFacility, SqlConnection sourceConnection)
		{
			// update the CustomENRList and CustomENR database tables
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			// insert a record into the CustomENRList table
			string executeStatement = string.Format(
				@"INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", newFacility.InfoSetID, Drive.SQL.PadString(newFacility.Name));
			int newCustomENRID = dataAccess.ExecuteCommandReturnAutoID(executeStatement);

			if (newCustomENRID == 0)
			{
				System.Windows.Forms.MessageBox.Show("An error has occurred.  The ENR Table was not imported.", "Create ENR Table", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			}
			else
			{
				//if (AddNewCustomENRValuesToDatabase(ref dataAccess, newFacility.m_customENRListID, newCustomENRID, sourceConnection))
				if (AddNewCustomENRValuesToDatabase(ref dataAccess, this.m_customENRListID, newCustomENRID, sourceConnection))
				{
					newFacility.m_customENRListID = newCustomENRID;
					executeStatement = string.Format("UPDATE Facilities SET CustomENRListID = {0} WHERE facility_id = {1}", newCustomENRID , newFacility.ID);
					dataAccess.ExecuteCommand(executeStatement);
				}
			}

			dataAccess = null;
		}
		//</mam>

		//mam - additional method to insert the proper CustomENRListID when copying the ENR table is not desired
		//mam 102309
		//public void CopyENRTable(Facility newFacility, OleDbConnection sourceConnection, int useENRID)
		public void CopyENRTable(Facility newFacility, SqlConnection sourceConnection, int useENRID)
		{
			// update the CustomENRList and CustomENR database tables
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			string executeStatement = string.Format("UPDATE Facilities SET CustomENRListID = {0} WHERE facility_id = {1}", useENRID , newFacility.ID);
			dataAccess.ExecuteCommand(executeStatement);

			dataAccess = null;
		}
		//</mam>

		//mam
		//mam 102309
		//private bool AddNewCustomENRValuesToDatabase(ref WAM.Common.DataAccess dataAccess, int facilityCustomENRListID, int newCustomENRID, OleDbConnection sourceConnection)
		private bool AddNewCustomENRValuesToDatabase(ref WAM.Common.DataAccess dataAccess, int facilityCustomENRListID, int newCustomENRID, SqlConnection sourceConnection)
		{
			//string queryString = string.Format(@"SELECT * FROM CustomENR WHERE CustomENRListID = {0}", m_customENRListID);
			string queryString = string.Format(@"SELECT * FROM CustomENR WHERE CustomENRListID = {0}", facilityCustomENRListID);
			DataTable dataTableSource = dataAccess.GetDisconnectedDataTable(queryString, sourceConnection.ConnectionString);

			queryString = string.Format(@"SELECT * FROM CustomENR WHERE CustomENRListID = 0");
			DataSet dataSetDestination = dataAccess.GetDisconnectedDataset(queryString);

			if (dataTableSource == null || dataSetDestination == null)
			{
				return false;
			}
			else
			{
				// update the CustomENR table
				for (int i = 0; i < dataTableSource.Rows.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSetDestination.Tables[0].NewRow();
					dataRow["enr_year"] = dataTableSource.Rows[i]["enr_year"];
					dataRow["enr_value"] = dataTableSource.Rows[i]["enr_value"];
					dataRow["CustomENRListID"] = newCustomENRID;
					dataSetDestination.Tables[0].Rows.Add(dataRow);
				}
			}

			return dataAccess.UpdateDatabase(dataSetDestination, queryString);
		}
		//</mam>

		#region Copy Custom ENR Values From Access To SQL Server

		//mam 102309
		//public void CopyENRTable(Facility newFacility, OleDbConnection sourceConnection)
		public void CopyENRTable(Facility newFacility, OleDbConnection sourceConnection, SqlConnection destConnection)
		{
			// update the CustomENRList and CustomENR database tables
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			WAM.Common.DataAccessOleDb dataAccessOleDb = new WAM.Common.DataAccessOleDb();

			// insert a record into the CustomENRList table
			string executeStatement = string.Format(
				@"INSERT INTO CustomENRList (InfosetID, CustomENRListName) VALUES ({0}, '{1}')", newFacility.InfoSetID, Drive.SQL.PadString(newFacility.Name));
			int newCustomENRID = dataAccess.ExecuteCommandReturnAutoID(executeStatement);

			if (newCustomENRID == 0)
			{
				System.Windows.Forms.MessageBox.Show("An error has occurred.  The ENR Table was not imported.", "Create ENR Table", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
			}
			else
			{
				//if (AddNewCustomENRValuesToDatabase(ref dataAccess, newFacility.m_customENRListID, newCustomENRID, sourceConnection))
				//if (AddNewCustomENRValuesToDatabase(ref dataAccess, this.m_customENRListID, newCustomENRID, sourceConnection))
				if (AddNewCustomENRValuesToDatabase(ref dataAccessOleDb, ref dataAccess, this.m_customENRListID, newCustomENRID, sourceConnection, destConnection))
				{
					newFacility.m_customENRListID = newCustomENRID;
					executeStatement = string.Format("UPDATE Facilities SET CustomENRListID = {0} WHERE facility_id = {1}", newCustomENRID , newFacility.ID);
					dataAccess.ExecuteCommand(executeStatement);
				}
			}

			dataAccess = null;
			dataAccessOleDb = null;
		}

		//mam 102309 - copy custom ENR values from Access database to SQL Server
		private bool AddNewCustomENRValuesToDatabase(ref WAM.Common.DataAccessOleDb dataAccessOleDb, ref WAM.Common.DataAccess dataAccess, 
			int facilityCustomENRListID, int newCustomENRID, OleDbConnection sourceConnection, SqlConnection destConnection)
		{
			string queryString = string.Format(@"SELECT * FROM CustomENR WHERE CustomENRListID = {0}", facilityCustomENRListID);
			DataTable dataTableSource = dataAccessOleDb.GetDisconnectedDataTable(queryString, sourceConnection.ConnectionString);

			queryString = string.Format(@"SELECT * FROM CustomENR WHERE CustomENRListID = 0");
			DataSet dataSetDestination = dataAccess.GetDisconnectedDataset(queryString);

			if (dataTableSource == null || dataSetDestination == null)
			{
				return false;
			}
			else
			{
				// update the CustomENR table
				for (int i = 0; i < dataTableSource.Rows.Count; i++)
				{
					DataRow dataRow;
					dataRow = dataSetDestination.Tables[0].NewRow();
					dataRow["enr_year"] = dataTableSource.Rows[i]["enr_year"];
					dataRow["enr_value"] = dataTableSource.Rows[i]["enr_value"];
					dataRow["CustomENRListID"] = newCustomENRID;
					dataSetDestination.Tables[0].Rows.Add(dataRow);
				}
			}

			return dataAccess.UpdateDatabase(dataSetDestination, queryString);
		}

		#endregion Copy Custom ENR Values From Access To SQL Server

		private void		LoadCustomENRValues()
		{
			if (m_usesCustomENR && m_customENRValues == null)
			{
				ENRCustom[]	enrData = ENRCustom.LoadForFacility(ID);

				m_customENRValues = new Hashtable(Drive.Math.FindHighestPrime(enrData.Length * 2), 1.0f);
				for (int pos = 0; pos < enrData.Length; pos++)
					m_customENRValues[enrData[pos].Year.GetHashCode()] = enrData[pos];
			}
		}

		//mam - need public method to force reloading of custom ENR values
		public void		LoadCustomENRValues(int customENRListID)
		{
			if (m_usesCustomENR)
			{
				this.m_customENRListID = customENRListID;
				ENRCustom[]	enrData = ENRCustom.LoadForFacility(ID, customENRListID);
				//ENRCustom[]	enrData = ENRCustom.LoadForFacility(ID);

				m_customENRValues = new Hashtable(Drive.Math.FindHighestPrime(enrData.Length * 2), 1.0f);
				for (int pos = 0; pos < enrData.Length; pos++)
					m_customENRValues[enrData[pos].Year.GetHashCode()] = enrData[pos];
			}
		}
		//</mam>

		public int			GetENRValueForYear(int year)
		{
			if (m_usesCustomENR)
			{
				// Make sure that the custom cache is loaded
				LoadCustomENRValues();
				ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				if (enr != null)
					return enr.ENRValue;

				return 0;
			}
			else
			{
				return ENR20CitiesCache.GetENRValueForYear(year);
			}
		}

		public void			SetENRValueForYear(int year, int enrValue)
		{
			if (m_usesCustomENR)
			{
				// Make sure that the custom cache is loaded
				LoadCustomENRValues();

				ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];

				if (enr != null)
				{
					enr.ENRValue = enrValue;
					enr.Save();
				}
				else
				{
					enr = new ENRCustom(0);

					//mam - no longer tying ENR tables only to one facility
					//enr.FacilityID = ID;
					//</mam>
					enr.Year = year;
					enr.ENRValue = enrValue;
					enr.CustomENRListID = m_customENRListID;
					enr.Save();

					m_customENRValues[year.GetHashCode()] = enr;
				}
			}
		}

		public bool			HasENRValueForYear(int year)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();
				ENR20Cities		enr = (ENR20Cities)m_customENRValues[year.GetHashCode()];
				return (enr != null);
			}
			
			return false;
		}

		//mam - moved this method to ManageCustomENRForm
//		public void			DeleteENRValueForYear(int year)
//		{
//			if (m_usesCustomENR)
//			{
//				LoadCustomENRValues();
//
//				ENRCustom	enr = (ENRCustom)m_customENRValues[year.GetHashCode()];
//
//				if (enr != null)
//				{
//					m_customENRValues.Remove(year.GetHashCode());
//					enr.Delete();
//				}
//			}
//		}

		//mam - moved this method to ManageCustomENRForm
//		public ENRCustom	GetENRRecordForYear(int year)
//		{
//			
//			if (m_usesCustomENR)
//			{
//				LoadCustomENRValues();
//
//				ENRCustom enr = (ENRCustom)m_customENRValues[year.GetHashCode()];
//
//				return enr;
//			}
//
//			return null;
//		}
		//</mam>

		public ENRCustom[] GetAllENRValues()
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues();

				ICollection	items = m_customENRValues.Values;
				ENRCustom[]	enrItems = new ENRCustom[items.Count];

				items.CopyTo(enrItems, 0);
				Array.Sort(enrItems);

				return enrItems;
			}

			return new ENRCustom[0];
		}

		//mam - added customENRListID parameter so that custom ENR values can be added 
		//	based on ENR combo box selection
		public ENRCustom[] GetAllENRValues(int customENRListID)
		{
			if (m_usesCustomENR)
			{
				LoadCustomENRValues(customENRListID);

				ICollection	items = m_customENRValues.Values;
				ENRCustom[]	enrItems = new ENRCustom[items.Count];

				items.CopyTo(enrItems, 0);
				Array.Sort(enrItems);

				return enrItems;
			}

			return new ENRCustom[0];
		}
		//</mam>

		public string		GetFullName()
		{
			return Name;
		}

		public string		GetShortName()
		{
			return Name;
		}

		//mam
		public string GetFullNameWithInfoset()
		{
			return string.Format("{0} / {1}", CacheManager.GetInfosetNameForInfoSetID(this.InfoSetID), GetFullName());
		}
		//</mam>

		//mam 090105
		public int GetFacilityID()
		{
			return this.ID;
		}

		public string GetParentName()
		{
			//get the InfoSet name

			return CacheManager.GetInfosetNameForInfoSetID(this.InfoSetID);
		}
		//</mam>

		//mam 050806
		public int GetParentID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public int GetGrandparentID()
		{
			return 0;
		}

		//mam 050806
		public int GetInfosetID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public object GetUnitType()
		{
			return WAM.UI.NodeType.Facility;
		}

		//mam - need a way to get pipes only or nodes only for graphing
		public decimal GetYAxisValue(GraphYAxis yAxis, bool pipesOnly, bool nodesOnly)
		{
			//there is no Condition, LOS, Vulnerability, Criticality, or Risk for Treatment Process
			return 0m;
		}
		//</mam>

		public decimal		GetYAxisValue(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return GetAcquisitionCost();
				case GraphYAxis.CurrentValue:
					return GetCurrentValue();
				case GraphYAxis.ReplacementValue:
					return GetReplacementValue();
				case GraphYAxis.BookValue:
					return GetBookValue();
				case GraphYAxis.SalvageValue:
					return GetSalvageValue();
				case GraphYAxis.AnnualDepreciation:
					return GetAnnualDepreciation();
				case GraphYAxis.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case GraphYAxis.EvaluatedValue:
					return GetEvaluatedValue();
				case GraphYAxis.RepairCost:
					return GetRepairCost();
				case GraphYAxis.AnnualMaintenanceCost:
					return GetAnnualMaintenanceCost();

				//mam 050806
				case GraphYAxis.AcquisitionCostEscalated:
					return GetAcquisitionCostEscalated();
				case GraphYAxis.RehabCost:
					return GetRehabCost();
			}

			return 0m;
		}

		public int			GetYearValue()
		{
			// Return the year
			return CurrentYear;
		}

		//mam 050806
		public int GetInspectionYear()
		{
			return CurrentYear;
		}

		//mam - new method
		public int GetItemID()
		{
			//return the ID
			return ID;
		}
		//</mam>

//		//mam 050806
//		public override string ToString()
//		{
//			return this.Name;
//		}

		//mam 101107 - replace double quote in comments with two double quotes 
		private string ReplaceDoubleQuoteWithTwoDoubleQuotes(string stringToChange)
		{
			stringToChange = stringToChange.Replace("\"", "\"\"");
			return stringToChange;
		}

		//mam 01222012
		public static void CheckFacilityYearConstraints(int facilityId, int proposedCurrentYear
			, out int minCurrentYear, out int maxCurrentYear, out bool allowProposedCurrentYear)
		{
			try
			{
				WAM.Common.DataAccess dataAccess = new DataAccess();
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP(
					"CheckValidFacilityYear", "@facilityId", "@proposedFacilityYear", facilityId, proposedCurrentYear);

				minCurrentYear = proposedCurrentYear;
				maxCurrentYear = proposedCurrentYear;
				allowProposedCurrentYear = true;

				if (dataTable.Rows.Count > 0)
				{
					//minCurrentYear = dataTable.Rows[0]["MinCurrentYear"] == DBNull.Value ? proposedCurrentYear : Convert.ToInt32(dataTable.Rows[0]["MinCurrentYear"]);
					//maxCurrentYear = dataTable.Rows[0]["MaxCurrentYear"] == DBNull.Value ? proposedCurrentYear : Convert.ToInt32(dataTable.Rows[0]["MaxCurrentYear"]);
					minCurrentYear = dataTable.Rows[0]["MinCurrentYear"] == DBNull.Value ? -1 : Convert.ToInt32(dataTable.Rows[0]["MinCurrentYear"]);
					maxCurrentYear = dataTable.Rows[0]["MaxCurrentYear"] == DBNull.Value ? 99999 : Convert.ToInt32(dataTable.Rows[0]["MaxCurrentYear"]);
					allowProposedCurrentYear = dataTable.Rows[0]["AllowProposedCurrentYear"] == DBNull.Value ? true : Convert.ToBoolean(dataTable.Rows[0]["AllowProposedCurrentYear"]);
				}
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}

		//mam 01222012
		public static void UpdateOverriddenYears(int facilityId, int currentYear)
		{
			//update all RehabYearNext and NextReplacementYear values that are overridden and are less than currentYear

			try
			{
				WAM.Common.DataAccess dataAccess = new DataAccess();
				dataAccess.ExecuteCommandSP("UpdateRehabReplacementYears", "@facilityId", "@year", facilityId, currentYear);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}

		//mam 01222012
		public static void UpdateDisciplineCacheOverriddenYears(int infoSetId, int facilityId, int currentYear)
		{
			try
			{
				//TreatmentProcess process = CacheManager.GetTreatmentProcess(curInfosetID, curProcessID);
				TreatmentProcess[] processes = CacheManager.GetProcesses(infoSetId, facilityId);
				MajorComponent[] components;
				Discipline[] disciplines;
				TreatmentProcess process;
				MajorComponent component;
				Discipline discipline;

				//int processCount = processes.Length;
				//int componentCount = 0;
				//int componentCountMech = 0;
				//int disciplineCount = 0;
				//int disciplineCountMech = 0;
				//int counter = 0;

				for (int posProc = 0; posProc < processes.Length; posProc++)
				{
					process = processes[posProc];
					components = CacheManager.GetComponents(process.InfoSetID, process.ID);

					//componentCount += components.Length;

					for (int posComp = 0; posComp < components.Length; posComp++)
					{
						if (components[posComp].MechStructDisciplines)
						{
							component = components[posComp];

							//componentCountMech++;
							disciplines = CacheManager.GetDisciplines(infoSetId, component.ID);

							//disciplineCountMech += disciplines.Length;

							for (int posDisc = 0; posDisc < disciplines.Length; posDisc++)
							{
								//counter++;
								discipline = disciplines[posDisc];

								if (component.CipPlanningId == CommonTasks.ZeroRehabCostCipPlanningId)
								{
									//planning mode is replacement, so set the cache value only for the replacement year
									//(the cache contains a zero for NextRehabYear because of the planning mode
									//	and the cache can only be changed to a non-zero value by changing the planning mode)
									if (discipline.OverrideNextReplacementYear && discipline.NextReplacementYear < currentYear)
									{
										discipline.NextReplacementYear = currentYear;
									}
								}
								else
								{
									//planning mode is rehabilitation, so set the cache value only for the rehabilitation year
									//(the cache contains a zero for NextReplacementYear because of the planning mode
									//	and the cache can only be changed to a non-zero value by changing the planning mode)
									if (discipline.OverrideRehabYearNext && discipline.RehabYearNext < currentYear)
									{
										discipline.RehabYearNext = currentYear;
									}
								}
							}
						}
					}
				}

				//string msg = "process count = \t" + processCount.ToString()
				//	+ "\r\ncomponent count = \t" + componentCount.ToString()
				//	+ "\r\ncomponent count Mech = \t" + componentCountMech.ToString()
				//	+ "\r\ndiscipline count Mech = \t" + disciplineCountMech.ToString();
				//System.Windows.Forms.MessageBox.Show(msg);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}

		#endregion /***** Methods *****/

		#region /***** Properties *****/
		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public short		CurrentYear
		{
			get { return m_currentYear; }
			set 
			{ 
				m_currentYear = value;

				// For now, let's go ahead and keep m_currentENR in sync with the 
				// ENR table
				m_currentENR = GetENRValueForYear(m_currentYear);
			}
		}

		public int			CurrentENR
		{
			get { return GetENRValueForYear(m_currentYear); }
			set { m_currentENR = value; }
		}

		public string		CaptionNorth
		{
			get { return m_captionNorth; }
			set
			{
				if (value.Length > 255)
					m_captionNorth = value.Substring(255);
				else
					m_captionNorth = value;
			}
		}

		public string		CaptionSouth
		{
			get { return m_captionSouth; }
			set
			{
				if (value.Length > 255)
					m_captionSouth = value.Substring(255);
				else
					m_captionSouth = value;
			}
		}

		public string		CaptionEast
		{
			get { return m_captionEast; }
			set
			{
				if (value.Length > 255)
					m_captionEast = value.Substring(255);
				else
					m_captionEast = value;
			}
		}

		public string		CaptionWest
		{
			get { return m_captionWest; }
			set
			{
				if (value.Length > 255)
					m_captionWest = value.Substring(255);
				else
					m_captionWest = value;
			}
		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		//mam 102309
		//mam 102309 - don't do it this way
//		public string		PhotoNorth
//		{
//			get { return m_photoNorth; }
//			set
//			{
//				if (value.Length > 255)
//					m_photoNorth = value.Substring(255);
//				else
//					m_photoNorth = value;
//			}
//		}

		//mam 102309
		//mam 102309 - don't do it this way
//		public string		PhotoSouth
//		{
//			get { return m_photoSouth; }
//			set
//			{
//				if (value.Length > 255)
//					m_photoSouth = value.Substring(255);
//				else
//					m_photoSouth = value;
//			}
//		}

		public decimal		ReplacementValue
		{
			get { return m_replacementVal; }
			set { m_replacementVal = value; }
		}

		public decimal		OldOrgCost
		{
			get { return m_oldOrgCost; }
			set { m_oldOrgCost = value; }
		}

		public decimal		NewFacilityCost
		{
			get { return m_newFacilityCost; }
			set { m_newFacilityCost = value; }
		}

		public decimal		FundedFacilityCost
		{
			get { return m_fundedFacilityCost; }
			set { m_fundedFacilityCost = value; }
		}

		public decimal		FundedReplaceValue
		{
			get { return m_fundedReplaceValue; }
			set { m_fundedReplaceValue = value; }
		}

		public int			SortOrder
		{
			get { return m_sortOrder; }
			set { m_sortOrder = value; }
		}

		public bool			UsesCustomENRTable
		{
			get { return m_usesCustomENR; }
			set { m_usesCustomENR = value; }
		}

		//mam
		public int CustomENRListID
		{
			get { return m_customENRListID; }
			set { m_customENRListID = value; }
		}
		//</mam>

		//mam 050806
		public int TreeNodeIndex
		{
			get { return treeNodeIndex; }
			set { treeNodeIndex = value; }
		}

		//mam 01222012
		public decimal FacilityCriticality
		{
			get { return m_facilityCriticality; }
			set { m_facilityCriticality = value; }
		}

		//mam 03202012
		public string PhotoFileNameNorth
		{
			get { return m_photoFileNameNorth; }
			set { m_photoFileNameNorth = value; }
		}

		//mam 03202012
		public string PhotoFileNameSouth
		{
			get { return m_photoFileNameSouth; }
			set { m_photoFileNameSouth = value; }
		}

		//mam 03202012 - need a way to determine if a facility that is being saved
		//	is a facility that is being imported
		public bool BeingImported
		{
			get { return m_beingImported; }
			set { m_beingImported = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Photo Methods *****/

		//mam 03202012 - replace original GetImage1Path()
		public string GetImage1Path()
		{
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			photoPath += "\\" + m_photoFileNameNorth;

			return photoPath;
		}

		//mam 03202012 - replace original GetImage2Path()
		public string GetImage2Path()
		{
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			photoPath += "\\" + m_photoFileNameSouth;

			return photoPath;
		}

		//GetImagePathWithPhotoFileNameIdStyle

		//mam 03202012
		public string GetImage1PathIdStyle()
		{
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			string photoName = string.Format(@"{0:D4}-N.jpg", ID);
			photoPath += "\\" + photoName;
		
			return photoPath;
		}

		//mam 03202012
		public string GetImage2PathIdStyle()
		{
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			string photoName = string.Format(@"{0:D4}-S.jpg", ID);
			photoPath += "\\" + photoName;
		
			return photoPath;
		}

		//mam 03202012 - this has been replaced
		//public string		GetImage1Path()
		//{
		//	//mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value
		//	//mam 102309 - no - just use the ID photo names
		//
		//	//InfoSet infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);
		//	//string path = string.Format(@"{0}\{1:D4}-N.jpg", infoSet.GetImagePath(), ID);
		//	string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
		//	//string photoName = this.PhotoNorth;
		//	//string photoNamePlusPath = photoPath + "\\" + photoName;
		//
		//	//mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
		//	//if (photoName == null || photoName == "")
		//	//{
		//		string photoName = string.Format(@"{0:D4}-N.jpg", ID);
		//		photoPath += "\\" + photoName;
		//	//}
		//
		//	return photoPath;
		//}

		//mam 03202012 - this has been replaced
		//public string		GetImage2Path()
		//{
		//	//mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value
		//	//mam 102309 - no - just use the ID photo names
		//
		//	//InfoSet infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);
		//	//string path = string.Format(@"{0}\{1:D4}-S.jpg", infoSet.GetImagePath(), ID);
		//	string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
		//	//string photoName = this.PhotoSouth;
		//	//string photoNamePlusPath = photoPath + "\\" + photoName;
		//
		//	//mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
		//	//if (photoName == null || photoName == "")
		//	//{
		//		string photoName = string.Format(@"{0:D4}-S.jpg", ID);
		//		photoPath += "\\" + photoName;
		//	//}
		//
		//	return photoPath;
		//}

		//mam 03202012 - no longer used
		//mam 102309 - used only when deleting photos, and we are not deleting photos any more
		//mam 102309 - yes, we are deleting photos
		//mam - pass in IDs so the path can be returned faster when deleting photos
		//public string		GetImage1Path(int facilityID, int infoSetID)
		//{
		//	//mam 102309 - added assignment of m_sqlConnectionString variable here because in the Drive library it is missing the password
		//	this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
		//
		//	InfoSet infoSet = new InfoSet(m_sqlConnectionString, infoSetID);
		//	string path = string.Format(@"{0}\{1:D4}-N.jpg", infoSet.GetImagePath(), facilityID);
		//	return path;
		//}
		//</mam>

		//mam 03202012 - no longer used
		//mam 102309 - used only when deleting photos, and we are not deleting photos any more
		//mam 102309 - yes, we are deleting photos
		//mam - pass in IDs so the path can be returned faster when deleting photos
		//public string		GetImage2Path(int facilityID, int infoSetID)
		//{
		//	//mam 102309 - added assignment of m_sqlConnectionString variable here because in the Drive library it is missing the password
		//	this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
		//
		//	InfoSet infoSet = new InfoSet(m_sqlConnectionString, infoSetID);
		//	string path = string.Format(@"{0}\{1:D4}-S.jpg", infoSet.GetImagePath(), facilityID);
		//	return path;
		//}
		//</mam>

		//mam
		public string		GetImage1PathReport()
		{
			//mam 03202012
			return GetImage1Path();

			//InfoSet			infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);

			//------------------------------
			//mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value
			//mam 102309 - no - just use ID method for photo names

			//string path = string.Format(@"{0}\{1:D4}-N.jpg", infoSet.GetImagePath(), ID);
			//if the photo file doesn't exist, return empty string
			//	(GetPhoto1 and GetPhoto2, where the existence of the image file is verified,
			//	are not called by the reporting function, causing problems if Photo2 exists but Photo1 doesn't) 
			//if (!System.IO.File.Exists(path))
			//	path = "";

			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			//string photoName = this.PhotoNorth;
			//string photoNamePlusPath = photoPath + "\\" + photoName;

			//mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
			//if (photoName == null || photoName == "")
			//{
				string photoName = string.Format(@"{0:D4}-N.jpg", ID);
				photoPath += "\\" + photoName;
			//}

			if (!System.IO.File.Exists(photoPath))
			{
				photoPath = "";
			}

			return photoPath;
			//------------------------------
		}
		//</mam>

		//mam
		public string		GetImage2PathReport()
		{
			//mam 03202012
			return GetImage2Path();

			//InfoSet			infoSet = new InfoSet(m_sqlConnectionString, m_infoSetID);

			//------------------------------
			//mam 102309 - check to see if photo with ID string name exists; if it does not, check the database value
			//mam 102309 - no - just use ID method for photo names

			//string path = string.Format(@"{0}\{1:D4}-S.jpg", infoSet.GetImagePath(), ID);
			//if the photo file doesn't exist, return empty string
			//	(GetPhoto1 and GetPhoto2, where the existence of the image file is verified,
			//	are not called by the reporting function, causing problems if Photo2 exists but Photo1 doesn't) 
			//if (!System.IO.File.Exists(path))
			//	path = "";

			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			//string photoName = this.PhotoSouth;
			//string photoNamePlusPath = photoPath + "\\" + photoName;

			//mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
			//if (photoName == null || photoName == "")
			//{
				string photoName = string.Format(@"{0:D4}-S.jpg", ID);
				photoPath += "\\" + photoName;
			//}

			if (!System.IO.File.Exists(photoPath))
			{
				photoPath = "";
			}

			return photoPath;
			//------------------------------
		}
		//<mam>

		public Image		GetPhoto1()
		{
			string			path = GetImage1Path();
			Image			image = null;

			//mam - added try/catch
			try
			{
				if (System.IO.File.Exists(path))
				{
					//image = Image.FromFile(path);
					//return image;

					//mam - set the file to be not read only, just in case the user has pulled a fast one and
					//	has copied a read-only image into the images folder
					System.IO.File.SetAttributes(path, System.IO.FileAttributes.Normal);
					//</mam>

					//mam - get the image from a filestream to alleviate
					//	"access denied" issues when deleting nodes and image folders
					using (System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open))
					{
						image = Image.FromStream(fileStream);
						fileStream.Close();
					}
					//</mam>
				}
			}
			catch
			{
				return null;
			}
			//</mam>

			return image;
		}

		public Image		GetPhoto2()
		{
			string			path = GetImage2Path();
			Image			image = null;

			//mam - added try/catch
			try
			{
				if (System.IO.File.Exists(path))
				{
					//image = Image.FromFile(path);
					//return image;

					//mam - set the file to be not read only, just in case the user has pulled a fast one and
					//	has copied a read-only image into the images folder
					System.IO.File.SetAttributes(path, System.IO.FileAttributes.Normal);
					//</mam>

					//mam - get the image from a filestream to alleviate
					//	"access denied" issues when deleting nodes and image folders
					using (System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open))
					{
						image = Image.FromStream(fileStream);
						fileStream.Close();
					}
					//</mam>
				}
			}
			catch
			{
				return null;
			}
			//</mam>

			return image;
		}
		#endregion /***** Photo Methods *****/

		#region		/***** Calculation Methods *****/
		private Logic.TreatmentProcessTotals
							m_processTotals = null;

		public void			RefreshTotals()
		{
			m_processTotals = new Logic.TreatmentProcessTotals(this);
		}

		public TreatmentProcess[] GetChildProcesses()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTreatmentProcesses();
		}

		public Logic.TreatmentProcessTotals GetProcessTotals()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals;
		}

		public bool			HasChildren
		{
			get
			{
				if (m_processTotals == null)
					RefreshTotals();

				return m_processTotals.GetTreatmentProcesses().Length > 0;
			}
		}

		public decimal		GetOldOrgCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCostOrgVal();
		}

		public decimal		GetOrgCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCost();
		}

		public decimal		GetAcquisitionCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAcquisitionCost();
		}

		//mam 091607 - new method
		public decimal		GetAcquisitionCostRoundIndividualValues()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAcquisitionCostRoundIndividualValues();
		}

		//mam 050806
		public decimal		GetAcquisitionCostEscalated()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAcquisitionCostEscalated();
		}

		//mam 050806
		public decimal		GetRehabCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalRehabCost();
		}

		public decimal		GetCurrentValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalCurrentValue();
		}

		public decimal		GetReplacementValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalReplacementValue();
		}

		//mam 050806
		public int GetReplacementValueYear()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetAverageReplacementValueYear();
		}

		public decimal		GetBookValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalBookValue();
		}

		public decimal		GetSalvageValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalSalvageValue();
		}

		public decimal		GetAnnualDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAnnualDepreciation();
		}

		public decimal		GetCumulativeDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalCumulativeDepreciation();
		}

		public decimal		GetEvaluatedValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalEvaluatedValue();
		}

		//mam - new method tha accounts for N/A when sorting
		public decimal SortGetEvaluatedValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			if (isNA)
				return -1;
			else
				return m_processTotals.GetTotalEvaluatedValue();
		}
		//</mam>

		public decimal		GetRepairCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalRepairCost();
		}

		//mam - new method that accounts for N/A when sorting
		public decimal SortGetRepairCost()
		{
			if (m_processTotals == null)
				RefreshTotals();
			
			if (isNA)
				return -1;
			else
				return m_processTotals.GetTotalRepairCost();
		}
		//</mam>

		public decimal		GetAnnualMaintenanceCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalAnnualMaintenanceCost();
		}

		public double		GetOrgUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgUsefulLife();
		}

		public double		GetRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalRemainingUsefulLife();
		}

		public double		GetEvaluatedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalEvaluatedRemainingUsefulLife();
		}

		//mam
		public double		GetEconomicUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalEconomicUsefulLife();
		}
		//</mam>

		public double		GetRankPercent()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetRankPercent();
		}

		public decimal		GetFacilityStraightLineA()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetTotalOrgCostLessStrtLineDep();
		}

		public decimal		GetFacilityValue()
		{
			return GetOrgCost() - GetRepairCost();
		}

		public decimal		GetFundedCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalOrgCost();
		}

		public decimal		GetFundedAcquisitionCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAcquisitionCost();
		}

		//mam 050806
		public decimal		GetFundedAcquisitionCostEscalated()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAcquisitionCostEscalated();
		}

		//mam 050806
		public decimal		GetFundedRehabCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalRehabCost();
		}

		public decimal		GetFundedCurrentValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCurrentValue();
		}

		public decimal		GetFundedReplacementValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalReplacementValue();
		}

		public decimal		GetFundedBookValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalBookValue();
		}

		public decimal		GetFundedSalvageValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalSalvageValue();
		}

		public decimal		GetFundedAnnualDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAnnualDepreciation();
		}

		public decimal		GetFundedCumulativeDepreciation()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCumulativeDepreciation();
		}

		public decimal		GetFundedEvaluatedValue()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalEvaluatedValue();
		}

		public decimal		GetFundedRepairCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalRepairCost();
		}

		public decimal		GetFundedAnnualMaintenanceCost()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalAnnualMaintenanceCost();
		}

		public double		GetFundedOrgUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalOrgUsefulLife();
		}

		public double		GetFundedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalRemainingUsefulLife();
		}

		public double		GetFundedEvaluatedRemainingUsefulLife()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalEvaluatedRemainingUsefulLife();
		}

		public decimal		GetFundedOrgCostLessStrtLineDep()
		{
			if (m_processTotals == null)
				RefreshTotals();

			return m_processTotals.GetFundedTotalCostLessStrtLineDep();
		}

		public decimal		GetFundedValue()
		{
			return GetFundedCost() - GetFundedRepairCost();
		}

		#endregion		/***** Calculation Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static Facility[] LoadAllOleDb(int infoSetID)
		{
			Facility[] facilities = LoadAll(WamSourceOleDb.CurrentSource.ConnectionString, infoSetID);

			return facilities;
		}

		//mam 102309
		public static Facility[] LoadAllOleDb(string connectionString, int infoSetID)
		{
			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);

			Facility[]		retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAllOleDb(sqlConnection, infoSetID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static Facility[] LoadAllOleDb(OleDbConnection oleDbConnection, int infoSetID)
		//public static Facility[] LoadAll(SqlConnection sqlConnection, int infoSetID)
		{
			// open the database to retrieve info

			//SqlConnection sqlConnection = new SqlConnection(WAM.Common.Globals.WamSqlConnectionString);
			//sqlConnection.Open;

			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			Facility		newObject;
			Facility[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID ");
			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE infoset_id={0} ", infoSetID);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			//			System.Diagnostics.Debug.WriteLine("");
			//System.Diagnostics.Debug.Write(builder.ToString());
			//			System.Diagnostics.Debug.WriteLine("");

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), oleDbConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					//newObject = new Facility(sqlConnection, dataReader);
					newObject = new Facility(0);
					newObject.LoadRecordData(dataReader);

					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadAllOleDb Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
				{
					dataReader.Close();
				}
			}
			
			typedArray = new Facility[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static Facility[] LoadAll(int infoSetID)
		{
			//mam 102309
			//Facility[] facilities = LoadAll(WAMSource.CurrentSource.ConnectionString, infoSetID);
			Facility[] facilities = LoadAll(Globals.WamSqlConnectionString, infoSetID);

			return facilities;
		}

		public static Facility[] LoadAll(string connectionString, int infoSetID)
		{
			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			Facility[]		retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadAll(sqlConnection, infoSetID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static Facility[] LoadAll(OleDbConnection sqlConnection, int infoSetID)
		public static Facility[] LoadAll(SqlConnection sqlConnection, int infoSetID)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			Facility		newObject;
			Facility[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest,  ");

			//mam 03202012
			builder.Append("PhotoFileNameNorth, PhotoFileNameSouth,  ");

			builder.Append("facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID ");

			//mam 01222012
			builder.Append(", FacilityCriticality ");

			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE infoset_id={0} ", infoSetID);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			//System.Diagnostics.Debug.Write(builder.ToString());

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new Facility(sqlConnection, dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadAll Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new Facility[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		//public static Facility[] LoadForFacilityName(string facilityName, int infoSetID, OleDbConnection sqlConnection)
		public static Facility[] LoadForFacilityName(string facilityName, int infoSetID, SqlConnection sqlConnection)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			Facility		newObject;
			Facility[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, ");

			//mam 03202012
			builder.Append("PhotoFileNameNorth, PhotoFileNameSouth, ");

			builder.Append("facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID ");

			//mam 01222012
			builder.Append(", FacilityCriticality ");

			builder.Append("FROM Facilities ");
			builder.Append("WHERE (");
			builder.AppendFormat("facility_name='{0}' AND ", Drive.SQL.PadString(facilityName));
			builder.AppendFormat("infoset_id={0}) ", infoSetID);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new Facility(sqlConnection, dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadForFacilityName Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			typedArray = new Facility[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 102309
		public static Facility LoadOne(SqlConnection sqlConnection, int facilityId)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			Facility		newObject = null;
			//Facility[]		typedArray;
			//ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			builder.Append("SELECT facility_id, infoset_id, facility_name, facility_currentYear, ");
			builder.Append("facility_currentENR, facility_captionNorth, facility_captionSouth, ");
			builder.Append("facility_captionEast, facility_captionWest, ");

			//mam 03202012
			builder.Append("PhotFileNameNorth, PhotFileNameSouth, ");

			builder.Append("facility_comments, ");
			builder.Append("facility_replacementValue, facility_oldOrgCost, facility_newFacilityCost, ");
			builder.Append("facility_sortOrder, facility_fundedFacilityCost, facility_fundedReplaceValue, ");
			builder.Append("facility_usesCustomENR, CustomENRListID ");

			//mam 01222012
			builder.Append(", FacilityCriticality ");

			builder.Append("FROM Facilities ");
			builder.AppendFormat("WHERE facility_id={0} ", facilityId);
			builder.Append("ORDER BY facility_sortOrder Asc, facility_id Asc");

			//			System.Diagnostics.Debug.WriteLine("");
			//System.Diagnostics.Debug.Write(builder.ToString());
			//			System.Diagnostics.Debug.WriteLine("");

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new Facility(sqlConnection, dataReader);
					//if (newObject.ID != 0)
					//	arrayList.Add(newObject);
				}
			}
				//mam 102309
				//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("Facility.LoadOne Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}
			
			//typedArray = new Facility[arrayList.Count];
			//arrayList.CopyTo(typedArray);
			//return typedArray;
			return newObject;
		}

		public static string GetTypeString()
		{
			return "Facility";
		}

		#endregion /***** Static Methods *****/
	}

	#region /***** Cache Class *****/
	public class			FacilityCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable(17);

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.Facility));
		private int			m_infoSetID = 0;

		public				FacilityCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			//mam 102309
			//m_changeDelegate = 
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged);
			m_changeDelegate = 
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged);

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(m_changeDelegate);
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(m_changeDelegate);
		}

		public int			InfoSetID
		{
			get { return m_infoSetID; }
		}

		#region IDisposable Members
		~FacilityCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		//mam 102309
		//private void DataChanged(object sender, 
		//	Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, 
			Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
			{
			Facility		obj = e.ChangedObject as Facility;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.InfoSetID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.InfoSetID, obj);
			}
		}

		public Facility[]	GetAll()
		{
			Facility[] children = (Facility[])m_treeHash.GetChildren(m_infoSetID);

			if (children == null)
			{
				System.Diagnostics.Trace.WriteLine("Generating Facility cache");
				children = Facility.LoadAll(m_infoSetID);
				m_treeHash.SetChildren(m_infoSetID, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}

			return children;
		}

		public void			Sort()
		{
			m_treeHash.Sort(m_infoSetID);
		}

		//mam 102309
		//public Facility[] BuildCache(OleDbConnection connection)
		public Facility[] BuildCache(SqlConnection connection)
		{
			Facility[]		children = Facility.LoadAll(connection, m_infoSetID);

			m_treeHash.SetChildren(m_infoSetID, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		//mam
//		public void RemoveFacilityFromCache(Facility facilityRemove)
//		{
//			if (m_hash[facilityRemove.GetHashCode()] != null)
//				m_hash.Remove(facilityRemove);
//
//			m_treeHash.RemoveChild(facilityRemove.InfoSetID, facilityRemove);
//
//			m_hash[facilityRemove.GetHashCode()] = null;
//
//			Clear();
//
//			//m_cacheHash[infoSetID.GetHashCode()] = cache;
//			//m_hash.Remove(facilityRemove.InfoSetID.GetHashCode());
//
//			//**************
//
////			Cache			cache = null;
////			cache = (Cache)m_cacheHash[infoSetID.GetHashCode()];
////			if (cache == null)
////			{
////				cache = new Cache(infoSetID);
////				m_cacheHash[infoSetID.GetHashCode()] = cache;
////			}
//		}

		public void RemoveFacilityFromCache(int facilityRemoveID)
		{
			Facility facilityRemove = GetFacility(facilityRemoveID);
			if (m_hash[facilityRemove.GetHashCode()] != null)
				m_hash.Remove(facilityRemove);

			m_treeHash.RemoveChild(facilityRemove.InfoSetID, facilityRemove);
			m_hash[facilityRemove.GetHashCode()] = null;
		}
		//</mam>

		public Facility		GetFacility(int id)
		{
			// Look up the facility in the hash table
			Facility		facility = m_hash[id.GetHashCode()] as Facility;

			// If the facility is not present, load it from the default database
			if (facility == null)
			{
				facility = new Facility(id);

				// If it doesn't exist in the database, then reset it
				if (facility.ID != 0)
					m_hash[facility.GetHashCode()] = facility;
				else
					facility = null;
			}

			return facility;
		}
	}
	#endregion /***** Cache Class *****/
}
