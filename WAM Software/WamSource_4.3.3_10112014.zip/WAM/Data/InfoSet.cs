using System;
using System.Configuration;
using System.Data;

//mam 102309
using System.Data.OleDb;

using System.Text;
using System.Collections;
using System.Windows.Forms;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for InfoSet.
	/// </summary>

	public class InfoSetOriginal : Drive.Data.OleDb.Jet40DALInt32Key
	{
		private string		m_name = "";
		private string		m_oldName = "";
		private string		m_description = "";

		//mam
		//private string m_databaseImageFolder = "";
		private bool m_isFixed = false;
		//</mam>

		#region /***** Construction *****/
		//mam 102309
		public InfoSetOriginal(int id) : base(WamSourceOleDb.CurrentSource.ConnectionString, id)
		{
			m_oldName = m_name;
		}

		public InfoSetOriginal(string connectionString, int id) : base(connectionString, id)
		{
			m_oldName = m_name;
		}

		//mam 102309 - leave this one
		protected InfoSetOriginal(System.Data.OleDb.OleDbDataReader reader)
			: base(WamSourceOleDb.CurrentSource.ConnectionString, reader)
		{
			m_oldName = m_name;
		}

		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/

		//mam 102309
		protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_name = reader.GetString(col++);

			//mam 102309
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam
			m_fixed = (reader.GetByte(col++) != 0);
			m_isFixed = m_fixed;
			//</mam>
		}

		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT infoset_id, infoset_name, infoset_description ");

			//mam
			builder.Append(", FixedInfoSet ");
			//</mam>

			builder.Append("FROM InfoSets ");
			builder.AppendFormat("WHERE infoset_id={0}", id);

			return builder.ToString();
		}

		//mam 102309
		protected override string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO InfoSets ");
			builder.Append("( infoset_name, infoset_description ) ");
			builder.Append(" VALUES (");
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0} ", Drive.SQL.StringToDBString(m_description));
			builder.Append("); ");

			return builder.ToString();
		}

		//mam 102309
		protected override string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(150);

			builder.Append("UPDATE InfoSets SET ");
			builder.AppendFormat("infoset_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("infoset_description={0} ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("WHERE (infoset_id={0}); ", ID);

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			//mam - don't allow fixed infosets to be deleted
			//mam - changed my mind - allow fixed infosets to be deleted
			return string.Format("DELETE From InfoSets WHERE infoset_id={0}", ID);
			//return string.Format("DELETE From InfoSets WHERE infoset_id={0}", ID + " AND FixedInfoSet <> 1");
			//</mam>
		}

		//mam 102309 - nothing to save, and no longer using Access databases
//		public override bool Save(OleDbConnection oleDbConnection)
//		{
//			bool isNew = (ID == 0);
//			
//			//mam 102309
//			bool success = base.Save(oleDbConnection);
//
//			if (success)
//			{
//				// Make sure that the images folder directory name is updated
//				if (m_name != m_oldName)
//				{
//					if (isNew)
//					{
//						GetImagePath();
//					}
//					else
//					{
//						// Rename the old image path to the new name
//						//mam - call GetImageBasePathWithDatabaseName() instead because checks for database images folder name
//						//string dbImagePath = GetDBImagePath();
//						string dbImagePath = GetImageBasePathWithDatabaseName();
//						//</mam>
//
//						string oldPath = string.Format(@"{0}\{1}", 
//							dbImagePath, m_oldName);
//						string newPath = string.Format(@"{0}\{1}", 
//							dbImagePath, m_name);
//
//						try
//						{
//							if (System.IO.Directory.Exists(oldPath))
//							{
//								//mam - can't Move if newPath already exists
//								if (!System.IO.Directory.Exists(newPath))
//								{
//									//</mam>
//									System.IO.Directory.Move(oldPath, newPath);
//								}
//							}
//							else
//							{
//								System.IO.Directory.CreateDirectory(newPath);
//							}
//						}
//						catch(Exception ex)
//						{
//							System.Windows.Forms.MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error",
//								System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
//						}
//					}
//				}
//			}
//
//			return success;
//		}
		#endregion /****** SQL Statements ******/

		#region /***** Methods *****/
		public void			CopyTo(InfoSet copy)
		{
			// Don't copy name; needs to remain unique

			//mam 102309
			//copy.m_description = m_description;
			copy.Description = m_description;
		}
		#endregion /***** Methods *****/

		#region /***** Properties *****/
		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public string		Description
		{
			get { return m_description; }
			set { m_description = value; }
		}

		//mam 102309 - not used
//		public string GetDBImagePath()
//		{
//			//mam 102309
//			//string		path = Drive.IO.Directory.GetFilePath(DatabasePath);
//			//string		dbImagesPath = string.Format(@"{0}\Images", path);
//			string dbImagesPath = WAM.Common.Globals.WamPhotoPath;
//
//			//mam - add try/catch
//			try
//			{
//				if (!System.IO.Directory.Exists(dbImagesPath))
//				{
//					System.IO.Directory.CreateDirectory(dbImagesPath);
//				}
//			}
//			catch
//			{
//			}
//
//			return dbImagesPath;
//		}

		//mam 102309 - not used
//		public string GetImagePath()
//		{
//			//mam - add database name to path, if appropriate
//			//string		infosetImagePath = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
//			string		infosetImagePath = GetImagePathWithDatabaseName();
//			//</mam>
//
//			//mam - add try/catch
//			try
//			{
//				if (!System.IO.Directory.Exists(infosetImagePath))
//				{
//					System.IO.Directory.CreateDirectory(infosetImagePath);
//				}
//			}
//			catch
//			{
//				infosetImagePath = "";
//			}
//
//			return infosetImagePath;
//		}

		//mam 102309 - not used
		//mam
//		public string GetImagePath(bool checkDatabaseName)
//		{
//			string infosetImagePath = "";
//
//			if (checkDatabaseName)
//			{
//				infosetImagePath = GetImagePathWithDatabaseName();
//			}
//			else
//			{
//				infosetImagePath = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
//
//				try
//				{
//					if (!System.IO.Directory.Exists(infosetImagePath))
//					{
//						System.IO.Directory.CreateDirectory(infosetImagePath);
//					}
//				}
//				catch
//				{
//					infosetImagePath = "";
//				}
//			}
//
//			return infosetImagePath;
//		}
		//</mam>

		//mam 102309 - not used
		//mam
//		public string GetImageBasePathWithDatabaseName()
//		{
//			string dbFolderName = MainForm.currentDatabaseImageFolder;
//
//			if (dbFolderName == "")
//			{
//				//if there is no database name, just use the infoset name as the folder name
//				dbFolderName = string.Format(@"{0}", GetDBImagePath());
//			}
//
//			return dbFolderName;
//		}
		//</mam>

		//mam 102309 - not used
		//mam
//		public string GetImagePathWithDatabaseName()
//		{
//			string dbFolderName = MainForm.currentDatabaseImageFolder;
//			if (dbFolderName == "")
//			{
//				//if there is no database name, just use the infoset name as the folder name
//				dbFolderName = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
//
//				try
//				{
//					if (!System.IO.Directory.Exists(dbFolderName))
//					{
//						System.IO.Directory.CreateDirectory(dbFolderName);
//					}
//				}
//				catch
//				{
//					dbFolderName = "";
//				}
//			}
//			else
//			{
//				//a database folder name exists, so use it, along with the infoset name
//				dbFolderName += @"\" + Name;
//
//				//create the folder, if necessary
//				try
//				{
//					if (!System.IO.Directory.Exists(dbFolderName))
//					{
//						System.IO.Directory.CreateDirectory(dbFolderName);
//					}
//				}
//				catch
//				{
//					dbFolderName = "";
//				}
//			}
//
//			return dbFolderName;
//		}
		//</mam>

		//mam
		public bool GetFixed()
		{
			return m_isFixed;
		}
		//</mam>

		#endregion /***** Properties *****/

		#region /***** Static Methods *****/
		public static InfoSetOriginal[] LoadAll()
		{
			//mam 102309
			return LoadAll(WamSourceOleDb.CurrentSource.ConnectionString);
		}

		public static InfoSetOriginal[] LoadAll(string connectionString)
		{
			// open the database to retrieve info

			//mam 102309
			OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			//SqlConnection sqlConnection = new SqlConnection(connectionString);
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			InfoSetOriginal			newObject;
			InfoSetOriginal[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			//mam - get FixedInfoSet field
			//builder.Append("SELECT infoset_id, infoset_name, infoset_description FROM InfoSets ");
			builder.Append("SELECT infoset_id, infoset_name, infoset_description, FixedInfoSet FROM InfoSets ");
			//</mam>

			builder.Append("ORDER BY infoset_name ");

			//System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				sqlConnection.Open();

				//mam 102309
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				//System.Diagnostics.Debug.WriteLine(builder.ToString());
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new InfoSetOriginal(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
				//mam 102309
			catch (OleDbException ex)
				//catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("InfoSetOriginal.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
				MessageBox.Show("An error has occurred.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return null;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				sqlConnection.Dispose();
			}
			
			typedArray = new InfoSetOriginal[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		static InfoSetOriginal()
		{
			// Initialize the default set
			InfoSetOriginal[]		infoSets = LoadAll();

			if (infoSets.Length > 0)
			{
				m_currentSet = 
					Drive.Configuration.AppSettings.Settings.GetSettingInt(
					"Defaults", "LastInfoSet", infoSets[0].ID);

				bool		found = false;
				for (int pos = 0; pos < infoSets.Length; pos++)
				{
					if (infoSets[pos].ID == m_currentSet)
					{
						found = true;
						break;
					}
				}

				if (!found)
					m_currentSet = infoSets[0].ID;
			}
			else
			{
				// Create a default info set
				InfoSetOriginal		defaultSet = new InfoSetOriginal(0);
				defaultSet.Name = "Default";
				defaultSet.Save();

				m_currentSet = defaultSet.ID;
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "LastInfoSet", m_currentSet.ToString());
			}
		}

		public static int	CurrentID
		{
			get
			{
				return m_currentSet;
			}
			set
			{
				m_currentSet = value;

				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "LastInfoSet", m_currentSet.ToString());
			}
		}

		private static int	m_currentSet = 0;

		//mam
		private static bool m_fixed = false;
		//</mam>

		//mam
		public static bool IsFixed
		{
			get
			{
				return m_fixed;
			}
			set
			{
				m_fixed = value;
			}
		}
		//</mam>

		#endregion /***** Static Methods *****/
	}

	//mam 102309
	//public class InfoSet : Drive.Data.OleDb.Jet40DALInt32Key
	public class InfoSet : Drive.Data.SqlClient.SqlDALInt32Key
	{
		private string		m_name = "";
		private string		m_oldName = "";
		private string		m_description = "";

		//mam
		//private string m_databaseImageFolder = "";
		private bool m_isFixed = false;
		//</mam>

		#region /***** Construction *****/
		//mam 102309
		//public InfoSet(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public InfoSet(int id) : base(Globals.WamSqlConnectionString, id)
		{
			m_oldName = m_name;
		}

		public InfoSet(string connectionString, int id) : base(connectionString, id)
		{
			m_oldName = m_name;
		}

		//mam 102309
		//protected InfoSet(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected InfoSet(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
		{
			m_oldName = m_name;
		}

		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/

		//mam 102309 - added
		protected override void StoreSaveInfo(SqlDataReader reader)
		{
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_name = reader.GetString(col++);

			//mam 102309
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam
			m_fixed = (reader.GetByte(col++) != 0);
			m_isFixed = m_fixed;
			//</mam>
		}

		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(100);

			builder.Append("SELECT infoset_id, infoset_name, infoset_description ");

			//mam
			builder.Append(", FixedInfoSet ");
			//</mam>

			builder.Append("FROM InfoSets ");
			builder.AppendFormat("WHERE infoset_id={0}", id);

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO InfoSets ");
			builder.Append("( infoset_name, infoset_description ) ");
			builder.Append(" VALUES (");
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("{0} ", Drive.SQL.StringToDBString(m_description));
			builder.Append("); ");

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(150);

			builder.Append("UPDATE InfoSets SET ");
			builder.AppendFormat("infoset_name='{0}', ", Drive.SQL.PadString(m_name));
			builder.AppendFormat("infoset_description={0} ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("WHERE (infoset_id={0}); ", ID);

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			//mam - don't allow fixed infosets to be deleted
			//mam - changed my mind - allow fixed infosets to be deleted
			return string.Format("DELETE From InfoSets WHERE infoset_id={0}", ID);
			//return string.Format("DELETE From InfoSets WHERE infoset_id={0}", ID + " AND FixedInfoSet <> 1");
			//</mam>
		}

		//mam 102309 - unnecessary, but keep for posterity
//		//public override bool Save(OleDbConnection oleDbConnection)
//		public bool SaveOrig(SqlConnection sqlConnection)
//		{
//			bool isNew = (ID == 0);
//			
//			//mam 102309
//			//bool success = base.Save(oleDbConnection);
//			bool success = base.Save(sqlConnection);
//
//			if (success)
//			{
//				// Make sure that the images folder directory name is updated
//				if (m_name != m_oldName)
//				{
//					if (isNew)
//					{
//						GetImagePath();
//					}
//					else
//					{
//						// Rename the old image path to the new name
//						//mam - call GetImageBasePathWithDatabaseName() instead because checks for database images folder name
//						//string dbImagePath = GetDBImagePath();
//						string dbImagePath = GetImageBasePathWithDatabaseName();
//						//</mam>
//
//						string oldPath = string.Format(@"{0}\{1}", 
//							dbImagePath, m_oldName);
//						string newPath = string.Format(@"{0}\{1}", 
//							dbImagePath, m_name);
//
//						try
//						{
//							if (System.IO.Directory.Exists(oldPath))
//							{
//								//mam - can't Move if newPath already exists
//								if (!System.IO.Directory.Exists(newPath))
//								{
//									//</mam>
//									System.IO.Directory.Move(oldPath, newPath);
//								}
//							}
//							else
//							{
//								System.IO.Directory.CreateDirectory(newPath);
//							}
//						}
//						catch(Exception ex)
//						{
//							System.Windows.Forms.MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error",
//								System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
//						}
//					}
//				}
//			}
//
//			return success;
//		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		#endregion /****** SQL Statements ******/

		#region /***** Methods *****/
		public void			CopyTo(InfoSet copy)
		{
			// Don't copy name; needs to remain unique
			copy.m_description = m_description;
		}
		#endregion /***** Methods *****/

		#region /***** Properties *****/
		public string		Name
		{
			get { return m_name; }
			set
			{
				if (value.Length > 255)
					m_name = value.Substring(255);
				else
					m_name = value;
			}
		}

		public string		Description
		{
			get { return m_description; }
			set { m_description = value; }
		}

		//mam 102309 - not used
//		public string		GetDBImagePath()
//		{
//			//mam 102309 - disable for now
//			return AppDomain.CurrentDomain.BaseDirectory;
//
////			string		path = Drive.IO.Directory.GetFilePath(DatabasePath);
////			string		dbImagesPath = string.Format(@"{0}\Images", path);
////
////			//mam - add try/catch
////			try
////			{
////				if (!System.IO.Directory.Exists(dbImagesPath))
////				{
////					System.IO.Directory.CreateDirectory(dbImagesPath);
////				}
////			}
////			catch
////			{
////			}
////
////			return dbImagesPath;
//		}

		public string GetImagePath()
		{
			//mam 102309 - get path from app settings
			//mam 102309 - go back to the original method
			//return WAM.Common.CommonTasks.GetInfosetImagePath(this.ID);

			//mam - add database name to path, if appropriate
			//string		infosetImagePath = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
			string		infosetImagePath = GetImagePathWithDatabaseName();
			//</mam>

			//mam - add try/catch
//			try
//			{
//				if (!System.IO.Directory.Exists(infosetImagePath))
//				{
//					System.IO.Directory.CreateDirectory(infosetImagePath);
//				}
//			}
//			catch
//			{
//				infosetImagePath = "";
//			}

			return infosetImagePath;
		}

		//mam 102309 - not used
		//mam
//		public string GetImagePath(bool checkDatabaseName)
//		{
//			string infosetImagePath = "";
//
//			if (checkDatabaseName)
//			{
//				infosetImagePath = GetImagePathWithDatabaseName();
//			}
//			else
//			{
//				infosetImagePath = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
//
//				try
//				{
//					if (!System.IO.Directory.Exists(infosetImagePath))
//					{
//						System.IO.Directory.CreateDirectory(infosetImagePath);
//					}
//				}
//				catch
//				{
//					infosetImagePath = "";
//				}
//			}
//
//			return infosetImagePath;
//		}
		//</mam>

		//mam 102309 - not used
//		//mam
//		public string GetImageBasePathWithDatabaseName()
//		{
//			string dbFolderName = MainForm.currentDatabaseImageFolder;
//
//			if (dbFolderName == "")
//			{
//				//if there is no database name, just use the infoset name as the folder name
//				dbFolderName = string.Format(@"{0}", GetDBImagePath());
//			}
//
//			return dbFolderName;
//		}
//		//</mam>

		//mam 102309 - not used
		//mam 102309 - use, but modify
		public string GetImagePathWithDatabaseName()
		{
			//mam 102309 - there is no longer a database name
			//string dbFolderName = MainForm.currentDatabaseImageFolder;
			string dbFolderName = WAM.Common.CommonTasks.GetInfosetImagePath(this.ID);

//			//if (dbFolderName == "")
//			//{
//				//if there is no database name, just use the infoset name as the folder name
//				//string dbFolderName = string.Format(@"{0}\{1}", GetDBImagePath(), Name);
//
//				try
//				{
//					if (!System.IO.Directory.Exists(dbFolderName))
//					{
//						System.IO.Directory.CreateDirectory(dbFolderName);
//					}
//				}
//				catch
//				{
//					dbFolderName = "";
//				}
//			//}
//			//else
//			//{
//			//	//a database folder name exists, so use it, along with the infoset name
//			//	dbFolderName += @"\" + Name;
//
//			//	//create the folder, if necessary
//			//	try
//			//	{
//			//		if (!System.IO.Directory.Exists(dbFolderName))
//			//		{
//			//			System.IO.Directory.CreateDirectory(dbFolderName);
//			//		}
//			//	}
//			//	catch
//			//	{
//			//		dbFolderName = "";
//			//	}
//			//}

			return dbFolderName;
		}
		//</mam>

		//mam
		public bool GetFixed()
		{
			return m_isFixed;
		}
		//</mam>

		#endregion /***** Properties *****/

		#region /***** Static Methods *****/
		public static InfoSet[] LoadAll()
		{
			//mam 102309
			//return LoadAll(WAMSource.CurrentSource.ConnectionString);
			return LoadAll(Globals.WamSqlConnectionString);
		}

		public static InfoSet[] LoadAll(string connectionString)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbConnection	sqlConnection = new OleDbConnection(connectionString);
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			InfoSet			newObject;
			InfoSet[]		typedArray;
			ArrayList		arrayList = new ArrayList();
			StringBuilder	builder = new StringBuilder(300);

			//mam - get FixedInfoSet field
			//builder.Append("SELECT infoset_id, infoset_name, infoset_description FROM InfoSets ");
			builder.Append("SELECT infoset_id, infoset_name, infoset_description, FixedInfoSet FROM InfoSets ");
			//</mam>

			builder.Append("ORDER BY infoset_name ");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				sqlConnection.Open();

				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				//System.Diagnostics.Debug.WriteLine(builder.ToString());
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new InfoSet(dataReader);
					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("InfoSet.LoadAll Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
				MessageBox.Show("An error has occurred.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return null;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				sqlConnection.Dispose();
			}
			
			typedArray = new InfoSet[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		static InfoSet()
		{
			// Initialize the default set
			InfoSet[]		infoSets = LoadAll();

			if (infoSets.Length > 0)
			{
				m_currentSet = 
					Drive.Configuration.AppSettings.Settings.GetSettingInt(
					"Defaults", "LastInfoSet", infoSets[0].ID);

				bool		found = false;
				for (int pos = 0; pos < infoSets.Length; pos++)
				{
					if (infoSets[pos].ID == m_currentSet)
					{
						found = true;
						break;
					}
				}

				if (!found)
					m_currentSet = infoSets[0].ID;
			}
			else
			{
				// Create a default info set
				InfoSet		defaultSet = new InfoSet(0);
				defaultSet.Name = "Default";
				defaultSet.Save();

				m_currentSet = defaultSet.ID;
				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "LastInfoSet", m_currentSet.ToString());
			}
		}

		public static int	CurrentID
		{
			get
			{
				return m_currentSet;
			}
			set
			{
				m_currentSet = value;

				Drive.Configuration.AppSettings.Settings.SetSetting(
					"Defaults", "LastInfoSet", m_currentSet.ToString());
			}
		}

		private static int	m_currentSet = 0;

		//mam
		private static bool m_fixed = false;
		//</mam>

		//mam
		public static bool IsFixed
		{
			get
			{
				return m_fixed;
			}
			set
			{
				m_fixed = value;
			}
		}
		//</mam>

		#endregion /***** Static Methods *****/
	}
}
