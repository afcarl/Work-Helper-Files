using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for PipeData.
	/// </summary>

	//mam 102309
	//public class PipeData : Drive.Data.OleDb.Jet40DALInt32Key, ICloneable, IComparable
	public class PipeData : Drive.Data.SqlClient.SqlDALInt32Key, ICloneable, IComparable
	{
		#region /***** Member Variables *****/
		private int			m_discPipeID = 0;
		private string		m_idNumber = "";
		private string		m_description = "";
		private string		m_type = "";
		private string		m_size = "";
		private int			m_length = 0;
		private decimal		m_unitCost = 0m;
		private short		m_installYear = (short)DateTime.Now.Year;
		private int			m_originalENR = 0;
		private decimal		m_replacementValue = 0;
		private decimal		m_salvageValue = 0;
		private decimal		m_annualMaintCost = 0;

		//mam
		private double		m_vulnerability2 = 0;
		private bool		m_overrideVulnerability = false;
		//</mam>

		//mam 050806
		private int m_replacementValueYear = 0;
		private decimal m_repairCost = 0;
		private bool m_overrideRepairCost = false;
		private decimal m_acquisitionCost = 0;
		private decimal m_currentValue = 0;
		private decimal m_rehabCost = 0;
		private bool m_overrideAcquisitionCost = false;
		private bool m_overrideCurrentValue = false;
		private int m_redundantAssetCount = 1;
		private int m_currentENR = 0;
		//private int m_replacementENR = 0;

		//mam - make CondRank.No the default, rather than CondRank.C0
		//private CondRank	m_conditionRank = CondRank.C0;
		private CondRank	m_conditionRank = CondRank.No;
		//</mam>

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using the four fixed crits
		//private CriticalityPublicHealth m_critPublic = CriticalityPublicHealth.NoEffect;
		//private CriticalityEnvironmental m_critEnvironmental = CriticalityEnvironmental.NoEffect;
		//private CriticalityRepairCost m_critRepair = CriticalityRepairCost.LessThan5k;
		//private CriticalityCustomerEffect m_critCustEffect = CriticalityCustomerEffect.NoEffect;
		private byte m_critPublic = 0;
		private byte m_critEnvironmental = 0;
		private byte m_critRepair = 0;
		private byte m_critCustEffect = 0;

		//mam - change to LOS2
		//private LevelOfService m_LOS = LevelOfService.LOS2;
		private LevelOfService m_LOS = LevelOfService.LOS1;
		//mam

		private Vulnerability m_vulnerability = Vulnerability.FailureLikely50;

		private short		m_orgUsefulLife = 50;

		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		//mam 07072011
		//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
		private MajorComponentSelectedCriticalityFactorsCollection pipeSelectedCritFactorCollection = new MajorComponentSelectedCriticalityFactorsCollection();

		#endregion /***** Member Variables *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			PipeData comp = obj as PipeData;

			if (comp != null)
			{
				return Drive.Math.Compare((int)this.ID, (int)comp.ID);
			}
			else
				throw new InvalidCastException("PipeData");
		}
		#endregion /***** IComparable Members *****/

		#region /***** Construction *****/
		//mam 102309
		//public PipeData(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public PipeData(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		public PipeData(string connectionString, int id) : base(connectionString, id)
		{
		}

		//protected PipeData(System.Data.OleDb.OleDbDataReader reader)
		//	: base(WAMSource.CurrentSource.ConnectionString, reader)
		protected PipeData(System.Data.SqlClient.SqlDataReader reader)
			: base(Globals.WamSqlConnectionString, reader)
			{
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(System.Data.SqlClient.SqlDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_discPipeID = reader.GetInt32(col++);

			//mam 102309
			//m_idNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			//m_type = Drive.SQL.ReadNullableString(reader, col++);
			//m_size = Drive.SQL.ReadNullableString(reader, col++);
			m_idNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_type = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_size = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_length = reader.GetInt32(col++);
			m_unitCost = reader.GetDecimal(col++);
			m_installYear = reader.GetInt16(col++);

			//mam 102309
			//m_originalENR = Drive.SQL.ReadNullableInt32(reader, col++);
			m_originalENR = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_conditionRank = (CondRank)reader.GetByte(col++);

			//mam 07072011 - no longer using the four fixed criticalities
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);

			m_LOS = (LevelOfService)reader.GetByte(col++);
			m_vulnerability = (Vulnerability)reader.GetByte(col++);
			m_orgUsefulLife = reader.GetInt16(col++);

			//mam
			//m_vulnerability2 = reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			//mam 102309
			//m_vulnerability2 = Drive.SQL.ReadNullableDouble(reader, col++);
			m_vulnerability2 = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabCost = reader.GetDecimal(col++);
			m_redundantAssetCount = reader.GetInt32(col++);
		}

		//mam 11142011 - new method - need this when importing from Access
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_discPipeID = reader.GetInt32(col++);

			//mam 102309
			//m_idNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_description = Drive.SQL.ReadNullableString(reader, col++);
			//m_type = Drive.SQL.ReadNullableString(reader, col++);
			//m_size = Drive.SQL.ReadNullableString(reader, col++);
			m_idNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_description = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_type = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_size = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_length = reader.GetInt32(col++);
			m_unitCost = reader.GetDecimal(col++);
			m_installYear = reader.GetInt16(col++);

			//mam 102309
			//m_originalENR = Drive.SQL.ReadNullableInt32(reader, col++);
			m_originalENR = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_conditionRank = (CondRank)reader.GetByte(col++);

			//mam 11142011 - need these when importing from Access
			//m_critPublic = (CriticalityPublicHealth)reader.GetByte(col++);
			//m_critEnvironmental = (CriticalityEnvironmental)reader.GetByte(col++);
			//m_critRepair = (CriticalityRepairCost)reader.GetByte(col++);
			//m_critCustEffect = (CriticalityCustomerEffect)reader.GetByte(col++);
			m_critPublic = reader.GetByte(col++);
			m_critEnvironmental = reader.GetByte(col++);
			m_critRepair = reader.GetByte(col++);
			m_critCustEffect = reader.GetByte(col++);

			m_LOS = (LevelOfService)reader.GetByte(col++);
			m_vulnerability = (Vulnerability)reader.GetByte(col++);
			m_orgUsefulLife = reader.GetInt16(col++);

			//mam
			//m_vulnerability2 = reader.GetDouble(col++);
			m_overrideVulnerability = !reader.IsDBNull(col);

			//mam 102309
			//m_vulnerability2 = Drive.SQL.ReadNullableDouble(reader, col++);
			m_vulnerability2 = reader.IsDBNull(col) ? 0 : reader.GetDouble(col); col++;

			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabCost = reader.GetDecimal(col++);
			m_redundantAssetCount = reader.GetInt32(col++);
		}

		#endregion /***** Construction *****/

		#region /****** SQL Statements ******/
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("SELECT ");
			builder.Append("pipe_id, ");
			builder.Append("discpipe_id, ");
			builder.Append("pipe_IDNumber, ");
			builder.Append("pipe_description, ");
			builder.Append("pipe_type, ");
			builder.Append("pipe_size, ");
			builder.Append("pipe_length, ");
			builder.Append("pipe_unitCost, ");
			builder.Append("pipe_installYear, ");
			builder.Append("pipe_originalENR, ");
			builder.Append("pipe_replacementValue, ");
			builder.Append("pipe_salvageValue, ");
			builder.Append("pipe_annualMaintCost, ");
			builder.Append("pipe_conditionRank, ");

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.Append("pipe_critPublicHealth, ");
			//builder.Append("pipe_critEnvironmental, ");
			//builder.Append("pipe_critRepairCost, ");
			//builder.Append("pipe_critCustomerEffect, ");

			builder.Append("pipe_levelOfService, ");
			builder.Append("pipe_vulnerability, ");
			builder.Append("pipe_originalUsefulLife ");

			//mam
			builder.Append(", pipe_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", pipe_acquisitionCost");
			builder.Append(", pipe_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");

			builder.Append("FROM PipingComponents ");
			builder.AppendFormat("WHERE pipe_id={0}", id);

			System.Diagnostics.Debug.Write(builder.ToString());

			return builder.ToString();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());

				}
				else
				{
					//mam 07072011 - add bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}

					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for saving all criticality values
		public bool SaveCriticalityValuesAll()
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				string xmlString = Common.CommonTasks.CreateCriticalityXmlString(pipeSelectedCritFactorCollection);
				dataAccess.ExecuteCommandInsertCriticalityValuesPipeNode(this.ID, xmlString, true);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				//mam 07072011 - throw error
				//System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				//return false;
				throw ex;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting criticality values from one major component to another
		public bool InsertCriticalityValuesAllCopy(int sourcePipeId, int destinationPipeId)
		{
			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityCopyPipe", "@sourcePipeId", "@destinationPipeId", sourcePipeId, destinationPipeId);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 07072011 - new save routine for inserting all criticality default values
		public bool InsertCriticalityValuesAllDefault()
		{
			//this is used when creating a new Major Component

			DataAccess dataAccess = new DataAccess();

			try
			{
				dataAccess.ExecuteCommandSP("InsertCriticalityDefaultPipe", "@pipeId", this.ID);

				//populate the crit collection for this major component
				System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityPipe", "@pipeId", this.ID);
				ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(dataTable);

				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					add = Drive.Synchronization.SyncAction.Edit;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				return false;
			}
			finally
			{
				dataAccess = null;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO PipingComponents (");
			builder.Append("discpipe_id, ");
			builder.Append("pipe_IDNumber, ");
			builder.Append("pipe_description, ");
			builder.Append("pipe_type, ");
			builder.Append("pipe_size, ");
			builder.Append("pipe_length, ");
			builder.Append("pipe_unitCost, ");
			builder.Append("pipe_installYear, ");
			builder.Append("pipe_originalENR, ");
			builder.Append("pipe_replacementValue, ");
			builder.Append("pipe_salvageValue, ");
			builder.Append("pipe_annualMaintCost, ");
			builder.Append("pipe_conditionRank, ");

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.Append("pipe_critPublicHealth, ");
			//builder.Append("pipe_critEnvironmental, ");
			//builder.Append("pipe_critRepairCost, ");
			//builder.Append("pipe_critCustomerEffect, ");

			builder.Append("pipe_levelOfService, ");
			builder.Append("pipe_vulnerability, ");
			builder.Append("pipe_originalUsefulLife ");

			//mam
			builder.Append(", pipe_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", pipe_acquisitionCost");
			builder.Append(", pipe_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_discPipeID);
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_idNumber));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_type));
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_size));
			builder.AppendFormat("{0}, ", m_length);
			builder.AppendFormat("{0:F2}, ", m_unitCost);
			builder.AppendFormat("{0}, ", m_installYear);
			builder.AppendFormat("{0}, ", m_originalENR);
			builder.AppendFormat("{0:F2}, ", m_replacementValue);
			builder.AppendFormat("{0:F2}, ", m_salvageValue);
			builder.AppendFormat("{0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("{0}, ", (byte)m_conditionRank);

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.AppendFormat("{0}, ", (byte)m_critPublic);
			//builder.AppendFormat("{0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("{0}, ", (byte)m_critRepair);
			//builder.AppendFormat("{0}, ", (byte)m_critCustEffect);

			builder.AppendFormat("{0}, ", (byte)m_LOS);
			builder.AppendFormat("{0}, ", (byte)m_vulnerability);
			builder.AppendFormat("{0} ", m_orgUsefulLife);

			//mam
			if (m_overrideVulnerability)
				builder.AppendFormat(", {0} ", m_vulnerability2);
			else
				builder.Append(", NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", {0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", {0} ", m_repairCost);
			else
				builder.Append(", NULL ");
			if (m_overrideAcquisitionCost)
				builder.AppendFormat(", {0} ", m_acquisitionCost);
			else
				builder.Append(", NULL ");
			if (m_overrideCurrentValue)
				builder.AppendFormat(", {0} ", m_currentValue);
			else
				builder.Append(", NULL ");
			builder.AppendFormat(", {0:F2} ", m_rehabCost);
			builder.AppendFormat(", {0} ", m_redundantAssetCount);

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE PipingComponents SET ");
			builder.AppendFormat("discpipe_id={0}, ", m_discPipeID);
			builder.AppendFormat("pipe_IDNumber='{0}', ", Drive.SQL.PadString(m_idNumber));
			builder.AppendFormat("pipe_description={0}, ", Drive.SQL.StringToDBString(m_description));
			builder.AppendFormat("pipe_type={0}, ", Drive.SQL.StringToDBString(m_type));
			builder.AppendFormat("pipe_size={0}, ", Drive.SQL.StringToDBString(m_size));
			builder.AppendFormat("pipe_length={0}, ", m_length);
			builder.AppendFormat("pipe_unitCost={0:F2}, ", m_unitCost);
			builder.AppendFormat("pipe_installYear={0}, ", m_installYear);
			builder.AppendFormat("pipe_originalENR={0}, ", m_originalENR);
			builder.AppendFormat("pipe_replacementValue={0:F2}, ", m_replacementValue);
			builder.AppendFormat("pipe_salvageValue={0:F2}, ", m_salvageValue);
			builder.AppendFormat("pipe_annualMaintCost={0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("pipe_conditionRank={0}, ", (byte)m_conditionRank);

			//mam 07072011 - no longer using the four fixed criticalities
			//builder.AppendFormat("pipe_critPublicHealth={0}, ", (byte)m_critPublic);
			//builder.AppendFormat("pipe_critEnvironmental={0}, ", (byte)m_critEnvironmental);
			//builder.AppendFormat("pipe_critRepairCost={0}, ", (byte)m_critRepair);
			//builder.AppendFormat("pipe_critCustomerEffect={0}, ", (byte)m_critCustEffect);

			builder.AppendFormat("pipe_levelOfService={0}, ", (byte)m_LOS);
			builder.AppendFormat("pipe_vulnerability={0}, ", (byte)m_vulnerability);
			builder.AppendFormat("pipe_originalUsefulLife={0} ", m_orgUsefulLife);

			//mam
			//builder.AppendFormat(", pipe_vulnerability2={0} ", m_vulnerability2);
			if (m_overrideVulnerability)
				builder.AppendFormat(", pipe_vulnerability2={0} ", m_vulnerability2);
			else
				builder.Append(", pipe_vulnerability2=NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", ReplacementValueYear={0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", RepairCost={0:F2} ", m_repairCost);
			else
				builder.Append(", RepairCost=NULL ");
			if (m_overrideAcquisitionCost)
				builder.AppendFormat(", pipe_acquisitionCost={0:F2} ", m_acquisitionCost);
			else
				builder.Append(", pipe_acquisitionCost=NULL ");
			if (m_overrideCurrentValue)
				builder.AppendFormat(", pipe_currentValue={0:F2} ", m_currentValue);
			else
				builder.Append(", pipe_currentValue=NULL ");

			//mam 050806
			builder.AppendFormat(", RehabCost={0:F2} ", m_rehabCost);
			builder.AppendFormat(", RedundantAssetCount={0} ", m_redundantAssetCount);

			builder.AppendFormat("WHERE (pipe_id={0}) ", ID);

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		protected override string GetDeleteSql()
		{
			return string.Format("DELETE From PipingComponents WHERE pipe_id={0}", ID);
		}

		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public int			InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public int			DiscPipeID
		{
			get { return m_discPipeID; }
			set { m_discPipeID = value; }
		}

		public string		IDNumber
		{
			get { return m_idNumber; }
			set
			{
				if (value.Length > 50)
					m_idNumber = value.Substring(0, 50);
				else
					m_idNumber = value;
			}
		}

		public string		Description
		{
			get { return m_description; }
			set 
			{
				if (value.Length > 255)
					m_description = value.Substring(0, 255);
				else
					m_description = value;
			}
		}

		public string		Type
		{
			get { return m_type; }
			set 
			{
				if (value.Length > 255)
					m_type = value.Substring(0, 255);
				else
					m_type = value;
			}
		}

		public string		Size
		{
			get { return m_size; }
			set 
			{
				if (value.Length > 50)
					m_size = value.Substring(0, 50);
				else
					m_size = value;
			}
		}

		public int			Length
		{
			get { return m_length; }
			set { m_length = value; }
		}

		public decimal		UnitCost
		{
			get { return m_unitCost; }
			set { m_unitCost = value; }
		}

		public short		InstallYear
		{
			get { return m_installYear; }
			set { m_installYear = value; }
		}

//		//mam 050806
//		public int ReplacementENR
//		{
//			get
//			{
//				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
//				Facility	facility = discipline.GetFacility();
//
//				if (facility != null)
//					return facility.GetENRValueForYear(m_replacementValueYear);
//
//				return 0;
//			}
//			set { m_replacementENR = value; }
//		}

		//mam 050806
		public int CurrentENR
		{
			get
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.CurrentENR;

				return 0;
			}
			set { m_currentENR = value; }
		}

		public int			OriginalENR
		{
			get
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(m_installYear);

				return 0;
			}
			set { m_originalENR = value; }
		}

		//mam 050806
		public decimal AcquisitionCostEscalated
		{
			get
			{
				if (OriginalENR == 0)
				{
					return 0;
				}

				return AcquisitionCost * (decimal)CurrentENR / (decimal)OriginalENR;
			}
		}

		public decimal		AcquisitionCost
		{
			//mam 050806 - we are now calculating AC based on pipe Length x Unit Cost
			//			get 
			//			{ 
			//				Discipline		discipline = 
			//					CacheManager.GetDiscipline(m_infoSetID, 
			//					m_discPipeID, DisciplineType.Pipes);
			//
			//				int				currentENR = discipline.CurrentENR;
			//
			//				if (currentENR == 0)
			//					return 0m;
			//
			//				return GetCurrentValue() * ((decimal)OriginalENR / (decimal)currentENR);
			//			}
			//			set {  }

			//mam 050806 - new calculation
			get
			{
				if (m_overrideAcquisitionCost)
				{
					return m_acquisitionCost;
				}
				else
				{
					//AC = Replacement Value * ENR Install Year / ENR Replacement Year

					int replacementYearENR = GetENRValueForYear((short)ReplacementValueYear);

					if (replacementYearENR == 0)
					{
						return 0;
					}

					return ReplacementValue * (decimal)OriginalENR / (decimal)replacementYearENR;
				}
			}
			set
			{
				m_acquisitionCost = value;
			}
		}

		//mam 050806
		public decimal RehabCost
		{
			get { return m_rehabCost; }
			set { m_rehabCost = value; }
		}

		//mam 050806
		public decimal CurrentValue
		{
			get 
			{ 
				//mam 112806 - take override into account
				//return m_currentValue; 
				if (m_overrideCurrentValue)
					return m_currentValue;
				else
					return GetCurrentValue();
			}

			set { m_currentValue = value; }
		}

		public decimal		ReplacementValue
		{
			get { return m_replacementValue; }
			set { m_replacementValue = value; }
		}

		public int		ReplacementValueYear
		{
			get { return m_replacementValueYear; }
			set { m_replacementValueYear = value; }
		}

		public decimal		SalvageValue
		{
			get { return m_salvageValue; }
			set { m_salvageValue = value; }
		}

		public decimal		AnnualMaintCost
		{
			get { return m_annualMaintCost; }
			set { m_annualMaintCost = value; }
		}

		public CondRank		ConditionRank
		{
			get { return m_conditionRank; }
			set { m_conditionRank = value; }
		}

		//mam 07072011 - provide a way for other objects to get the collection
		public MajorComponentSelectedCriticalityFactorsCollection ComponentSelectedCriticalityFactorsCollection
		{
			//this collection will contain only the user-selected factors (one per criticality) rather than all of the factors for each criticality
			get { return pipeSelectedCritFactorCollection; }
			set { pipeSelectedCritFactorCollection = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityPublicHealth CritPublicHealth
//		{
//			get { return m_critPublic; }
//			set { m_critPublic = value; }
//		}
		public byte CritPublicHealth
		{
			get { return m_critPublic; }
			set { m_critPublic = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityEnvironmental CritEnvironmental
//		{
//			get { return m_critEnvironmental; }
//			set { m_critEnvironmental = value; }
//		}
		public byte CritEnvironmental
		{
			get { return m_critEnvironmental; }
			set { m_critEnvironmental = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityRepairCost CritRepair
//		{
//			get { return m_critRepair; }
//			set { m_critRepair = value; }
//		}
		public byte CritRepair
		{
			get { return m_critRepair; }
			set { m_critRepair = value; }
		}

		//mam 11142011 - we need these when importing data from an Access database
		//mam 07072011 - no longer using four fixed crits
//		public CriticalityCustomerEffect CritCustEffect
//		{
//			get { return m_critCustEffect; }
//			set { m_critCustEffect = value; }
//		}
		public byte CritCustEffect
		{
			get { return m_critCustEffect; }
			set { m_critCustEffect = value; }
		}

		public LevelOfService LevelOfService
		{
			get { return m_LOS; }
			set { m_LOS = value; }
		}

		public Vulnerability Vulnerability
		{
			get { return m_vulnerability; }
			set { m_vulnerability = value; }
		}

		//mam
		public double Vulnerability2
		{
			get { return m_vulnerability2; }
			set { m_vulnerability2 = value; }
		}
		//</mam>

		//mam 050806
		public decimal RepairCost
		{
			get { return m_repairCost; }
			set { m_repairCost = value; }
		}
		//</mam>

		public short		OrgUsefulLife
		{
			get { return m_orgUsefulLife; }
			set { m_orgUsefulLife = value; }
		}

		//mam 050806
		public int RedundantAssetCount
		{
			get { return m_redundantAssetCount; }
			set { m_redundantAssetCount = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete()
		{
			this.m_sqlConnectionString = WAM.Common.Globals.WamSqlConnectionString;
			using (SqlConnection connection = new SqlConnection(this.m_sqlConnectionString))
			{
				connection.Open();
				return this.Delete(connection);
			}
		}
		//mam 07072011 - override two delete methods so we can catch any error that occurs
		public override bool Delete(SqlConnection sqlConnection)
		{
			//return base.Delete (sqlConnection);

			string deleteSql = this.GetDeleteSql();
			if (deleteSql.Length == 0)
			{
				return false;
			}
			try
			{
				new SqlCommand(deleteSql, sqlConnection).ExecuteNonQuery();
			}
			catch (SqlException exception)
			{
				throw exception;
			}
			InvokeChangeEvent(this, new DataChangeEventArgs(this, Drive.Synchronization.SyncAction.Delete));
			return true;
		}

		//mam 07072011 - new method to calculate overall criticality
		private double CalculateCritTotal()
		{
			double total = 0.0;

			foreach (MajorComponentSelectedCriticalityFactors critFactor in pipeSelectedCritFactorCollection)
			{
				total += ((double)critFactor.CriticalityWeight * critFactor.CritFactor.Score / 100);
			}

			return total;
		}

		//mam 050806 - change from int to double
		//public int GetOverallCriticality()
		public double GetOverallCriticality()
		{
			//mam 050806 - change from int to double
			//int				total = 0;
			double total = 0.0;

			//mam 07072011 - no longer using the four fixed crits
			//total += EnumHandlers.GetCritPublicHealthValue(m_critPublic);
			//total += EnumHandlers.GetCritEnvironmentalValue(m_critEnvironmental);
			//total += EnumHandlers.GetCritRepairCostValue(m_critRepair);
			//total += EnumHandlers.GetCritCustomerEffectValue(m_critCustEffect);

			//mam 07072011 - new way to calculate total
			total = CalculateCritTotal();

			//mam 050806
			//total /= RedundantAssetCount;
			//total = Math.Round(total, 1);

			//mam 112806
			total *= Convert.ToDouble(WAM.Common.CommonTasks.GetRedundantPercentage(RedundantAssetCount));

			//mam 01222012
			if (WAM.Common.Globals.ApplyFacilityCriticalityFactor)
			{
				//mam 03202012
				//Discipline discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
				Discipline discipline = CacheManager.GetDiscipline(InfoSet.CurrentID, m_discPipeID, DisciplineType.Pipes);

				total *= (double)(discipline.GetFacility().FacilityCriticality);
			}

			total = Math.Round(total, 1);

			return total;
		}

		public double		GetRisk()
		{
			//mam
			//return Math.Round(GetOverallCriticality() * 
			//	EnumHandlers.GetVulnerabilityValue(m_vulnerability), 2);
			return Math.Round(GetOverallCriticality() * m_vulnerability2, 2);
			//</mam>
		}

		//mam
		public double GetVulnerability()
		{
			if (m_overrideVulnerability)
				return m_vulnerability2;
			else
			{
				double evalRUL = GetEvaluatedRemainingUsefulLife();

				if (evalRUL == 0 && !OverrideVulnerability)
					return 0;

				m_vulnerability2 = (double)Math.Round(1 / (decimal)evalRUL, 4);
				return m_vulnerability2;
			}
		}
		//</mam>

		public double		GetCWP()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discPipeID, DisciplineType.Pipes);

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//decimal			totalCurrentValue = discipline.GetCurrentValue();
			decimal			totalCurrentValue = discipline.AcquisitionCost;

			if (totalCurrentValue == 0)
				return 0.0;

            // Current Value / discipline Total Current Value 

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			//return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
			return Math.Round((double)(AcquisitionCost / totalCurrentValue), 2);
		}

		//mam - add a routine that returns the unrounded CWP
		public double		GetCWP(bool roundValue)
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discPipeID, DisciplineType.Pipes);

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			decimal			totalCurrentValue = discipline.AcquisitionCost;

			if (totalCurrentValue == 0)
				return 0.0;

			// Current Value / discipline Total Current Value 

			//mam 112806 - use AcquisitionCost instead of CurrentValue
			if (roundValue)
			{
				//return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
				return Math.Round((double)(AcquisitionCost / totalCurrentValue), 2);
			}
			else
			{
				//return (double)(GetCurrentValue(false) / totalCurrentValue);
				return (double)(AcquisitionCost / totalCurrentValue);
			}
		}
		//</mam>

		//mam 112806 - added new CWP routine because the original CWP is now using AC, and the Pipes/Nodes Averages need CWP based on CV
		public double GetCWPCurrentValue()
		{
			Discipline		discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
			decimal			totalCurrentValue = discipline.GetCurrentValue();

			if (totalCurrentValue == 0)
				return 0.0;

			// Current Value / discipline Total Current Value 
			return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
		}

		//mam 112806 - added new CWP routine because the original CWP is now using AC, and the Pipes/Nodes Averages need CWP based on CV
		public double GetCWPCurrentValue(bool roundValue)
		{
			Discipline		discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
			decimal			totalCurrentValue = discipline.GetCurrentValue();

			if (totalCurrentValue == 0)
				return 0.0;

			// Current Value / discipline Total Current Value 
			if (roundValue)
			{
				return Math.Round((double)(GetCurrentValue() / totalCurrentValue), 2);
			}
			else
			{
				return (double)(GetCurrentValue(false) / totalCurrentValue);
			}
		}
		//</mam>

		//mam 050806 - get ENR for Replacement Year
		public int GetENRValueForYear(short yearENR)
		{
			try
			{
				Discipline	discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
				Facility	facility = discipline.GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(yearENR);
			
				return 0;
			}
			catch
			{
				return 0;
			}
		}
		//</mam>

		public decimal GetCurrentValue()
		{
			if (m_overrideCurrentValue)
				return m_currentValue;

			//mam 050806
			//Discipline discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
			//int currentENR = discipline.CurrentENR;

			////return Math.Round(((decimal)Length) * UnitCost, 0);
			//return Math.Round(((decimal)Length) * UnitCost * ((decimal)currentENR / (decimal)OriginalENR), 0);

			//mam 050806
			//return AcquisitionCost * (decimal)currentENR / (decimal)OriginalENR;

			//***********************

			//mam 050806 - new calculation for Current Value

			//if (OriginalENR == 0)
			//	return 0;

			//decimal tempCV = AcquisitionCost + RehabCost;
			//decimal tempACE = AcquisitionCostEscalated;
			//tempCV = tempCV > tempACE? tempACE: tempCV;
			//return Math.Round(tempCV, 0);

			//***********************

			//mam 050806 - update - new calculation for CV
			//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

			//mam 112806 - update - new calculation for CV
			//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

			//if there is no condition, the current value cannot be calculated
			if (ConditionRank == CondRank.No)
				return 0;

			decimal tempACE = AcquisitionCostEscalated;
			decimal condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
				
			//return Math.Round(tempACE + RehabCost - (tempACE * condPct), 0);

			//mam 112806
			return Math.Round((tempACE * condPct) + RehabCost, 0);
		}

		//mam - add a routine that returns the unrounded CurrentValue
		public decimal GetCurrentValue(bool roundValue)
		{
			//mam 112806 - added check for overridden CV
			if (m_overrideCurrentValue)
			{
				if (roundValue)
				{
					return Math.Round(m_currentValue, 2);
				}
				else
				{
					return m_currentValue;
				}
			}

			if (roundValue)
			{
				//mam 050806
				//return Math.Round(((decimal)Length) * UnitCost, 0);
				return this.GetCurrentValue();
			}
			else
			{
				//mam 050806
				//Discipline discipline = CacheManager.GetDiscipline(m_infoSetID, m_discPipeID, DisciplineType.Pipes);
				//int currentENR = discipline.CurrentENR;

				////return ((decimal)Length) * UnitCost;
				//return ((decimal)Length) * UnitCost * ((decimal)currentENR / (decimal)OriginalENR);

				//mam 050806
				//return AcquisitionCost * (decimal)currentENR / (decimal)OriginalENR;

				//***********************

				//mam 050806 - new calculation for Current Value

				//if (OriginalENR == 0)
				//	return 0;

				//decimal tempCV = AcquisitionCost + RehabCost;
				//decimal tempACE = AcquisitionCostEscalated;
				//tempCV = tempCV > tempACE? tempACE: tempCV;
				//return tempCV;

				//***********************

				//mam 050806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

				//mam 112806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

				//if there is no condition, the current value cannot be calculated
				if (ConditionRank == CondRank.No)
					return 0;

				decimal tempACE = AcquisitionCostEscalated;
				decimal condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
				
				//return tempACE + RehabCost - (tempACE * condPct);

				//System.Diagnostics.Debug.WriteLine(tempACE.ToString() + "; " + condPct.ToString() + "; " + RehabCost.ToString());
				//mam 112806
				return (tempACE * condPct) + RehabCost;
			}
		}
		//</mam>

		public decimal		GetBookValue()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discPipeID, DisciplineType.Pipes);

			// Acquisition Cost - (Annual Depreciation * 
			//   (Current Year - Installation Year))
			decimal			val = Math.Round((AcquisitionCost - 
				(GetAnnualDepreciation() * 
				(discipline.CurrentYear - InstallYear))), 0);

			if (val < 0m)
				val = 0m;

			return val;
		}

		public decimal		GetAnnualDepreciation()
		{
			// (Acquisition Cost - Salvage Value) / Original Useful Life
			if (OrgUsefulLife == 0)
				return 0m;

			return Math.Round(((AcquisitionCost - SalvageValue) / (decimal)OrgUsefulLife), 0);
		}

		public decimal		GetCumulativeDepreciation()
		{
			return AcquisitionCost - GetBookValue();
		}

		public decimal		GetEvaluatedValue()
		{
			//mam 050806 - new calculation for EV
			//EV = EAC * (1 - Condition Fraction)

			//return Math.Round(GetCurrentValue() * 
			//	(1m - (decimal)EnumHandlers.GetConditionRankValue(m_conditionRank)), 0);
			
			return Math.Round(AcquisitionCostEscalated * (1m - (decimal)EnumHandlers.GetConditionRankValue(m_conditionRank)), 0);
		}

		public decimal		GetRepairCost()
		{
			// Repair Cost = Current Value * ( Fraction associated with Condition - 
			//   Fraction associated with Level of Service ). 
			// 
			// If Condition is 0 or 5, and LOS is 1, Repair Cost = Replacement Cost. 
			// When Condition <= LOS, Repair Cost is 0.  Min of 0.

			//mam 050806
			//when Condition = N/A, Repair Cost = N/A

			//mam 050806
			if (m_overrideRepairCost)
				return m_repairCost;

			if ((m_conditionRank == CondRank.C0 ||
				m_conditionRank == CondRank.C5 || 
				m_conditionRank == CondRank.No) &&
				m_LOS == LevelOfService.LOS1)
			{
				return ReplacementValue;
			}

			// When condition <= LOS, repair cost = 0
			if (m_conditionRank != CondRank.No &&
				(byte)m_conditionRank <= (byte)m_LOS)
			{
				return 0;
			}

			// Get the condition percent modifier
			decimal			condPct = 
				(decimal)EnumHandlers.GetConditionRankValue(m_conditionRank);

			//new equation: Repair Cost = Current Value * (Condition Fraction � LOS Fraction)
			//original code:
			//decimal			repairCost = GetCurrentValue() * (1m - condPct);
			//new code:
			decimal losPct = (decimal)EnumHandlers.GetLOSValue(m_LOS );

			//mam 020607 - new equation for Repair Cost = EAC * (Cond - LOS)
			//decimal repairCost = GetCurrentValue() * (condPct - losPct);
			decimal repairCost = AcquisitionCostEscalated * (condPct - losPct);
			//</mam>

			// Min of 0
			if (repairCost < 0)
				return 0;
			
			return Math.Round(repairCost, 0);
		}

		public double		GetRemainingUsefulLife()
		{
			Discipline		discipline = 
				CacheManager.GetDiscipline(m_infoSetID, 
				m_discPipeID, DisciplineType.Pipes);

			// Original Useful Life - (Current Year - Installation Year)
			return Math.Round((double)
				(OrgUsefulLife - (discipline.CurrentYear - InstallYear)), 1);
		}

		public double		GetEvaluatedRemainingUsefulLife()
		{
			// Evaluated Remaining Useful Life = (1 - (Fraction associated with Condition)) * 
			//	 Original Useful Life

			// This used to be Evaluated Remaining Useful Life
			if (ConditionRank == CondRank.No)
				return 0;

			//mam 051708 - get cond value for use in calculating useful life values
			// Get the condition percent modifier
			//decimal			condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRank);
			decimal			condPct = 1m - EnumHandlers.GetConditionRankValueForUsefulLife(ConditionRank);

			return (double)Math.Round(((decimal)OrgUsefulLife * condPct), 1);
		}

		//mam
		public double GetEconomicUsefulLife()
		{
			//Economic Remaining Useful Life = (Original UL/2) - (Original UL * Condition Fraction)

			if (ConditionRank == CondRank.No)
				return 0;

			//mam 051708 - get cond value for use in calculating useful life values
			// Get the condition percent modifier
			//decimal condPct = EnumHandlers.GetConditionRankValue(ConditionRank);
			decimal condPct = EnumHandlers.GetConditionRankValueForUsefulLife(ConditionRank);

			return (double)(Math.Round((decimal)OrgUsefulLife / 2m - (decimal)OrgUsefulLife * condPct, 1));
		}
		//</mam>

		//mam
		public virtual bool	OverrideVulnerability
		{
			get { return m_overrideVulnerability; }
			set
			{
				if (m_overrideVulnerability == value)
					return;

				// Set to the default vulnerability when turning 
				// override on, and set back to zero when turning it off
				if (!m_overrideVulnerability)
					m_vulnerability2 = Math.Round(Vulnerability2, 4);
				//else
				//	m_vulnerability2 = 0;

				m_overrideVulnerability = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideRepairCost
		{
			get { return m_overrideRepairCost; }
			set
			{
				if (m_overrideRepairCost == value)
					return;

				//set Repair Cost to zero when turning override on
				//if (!m_overrideRepairCost)
					//m_repairCost = 0.0;

				m_overrideRepairCost = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideAcquisitionCost
		{
			get { return m_overrideAcquisitionCost; }
			set
			{
				if (m_overrideAcquisitionCost == value)
					return;

				m_overrideAcquisitionCost = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual bool	OverrideCurrentValue
		{
			get { return m_overrideCurrentValue; }
			set
			{
				if (m_overrideCurrentValue == value)
					return;

				m_overrideCurrentValue = value;
			}
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Static Methods *****/

		private static string GetBaseSelect()
		{
			StringBuilder builder = new StringBuilder(150);

			builder.Append("SELECT ");
			builder.Append("pipe_id, ");
			builder.Append("discpipe_id, ");
			builder.Append("pipe_IDNumber, ");
			builder.Append("pipe_description, ");
			builder.Append("pipe_type, ");
			builder.Append("pipe_size, ");
			builder.Append("pipe_length, ");
			builder.Append("pipe_unitCost, ");
			builder.Append("pipe_installYear, ");
			builder.Append("pipe_originalENR, ");
			builder.Append("pipe_replacementValue, ");
			builder.Append("pipe_salvageValue, ");
			builder.Append("pipe_annualMaintCost, ");
			builder.Append("pipe_conditionRank, ");

			//mam 07072011 - no longer using the four fixed crits
			//builder.Append("pipe_critPublicHealth, ");
			//builder.Append("pipe_critEnvironmental, ");
			//builder.Append("pipe_critRepairCost, ");
			//builder.Append("pipe_critCustomerEffect, ");

			builder.Append("pipe_levelOfService, ");
			builder.Append("pipe_vulnerability, ");
			builder.Append("pipe_originalUsefulLife ");

			//mam
			builder.Append(", pipe_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", pipe_acquisitionCost");
			builder.Append(", pipe_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");

			builder.Append("FROM PipingComponents ");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		#region /***** OleDb *****/

		//mam 102309
		public static PipeData[] LoadForDisciplineOleDb(int disciplineID)
		{
			return LoadForDisciplineOleDb(WamSourceOleDb.CurrentSource.ConnectionString, disciplineID);
			//return LoadForDiscipline(Globals.WamSqlConnectionString, disciplineID);
		}

		//mam 102309
		public static PipeData[] LoadForDisciplineOleDb(string connectionString, int disciplineID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			//SqlConnection sqlConnection = new SqlConnection(connectionString);

			try
			{
				sqlConnection.Open();
				return LoadForDisciplineOleDb(sqlConnection, disciplineID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}
		}

		//mam 102309
		public static PipeData[] LoadForDisciplineOleDb(OleDbConnection sqlConnection, int disciplineID)
			//public static PipeData[] LoadForDiscipline(SqlConnection sqlConnection, int disciplineID)
		{
			//mam 11142011
			//StringBuilder	builder = new StringBuilder(GetBaseSelect());
			StringBuilder	builder = new StringBuilder(GetBaseSelectOleDb());

			builder.AppendFormat("WHERE (discpipe_id={0}) ", disciplineID);
			return LoadBulkOleDb(sqlConnection, builder.ToString());
		}

		//mam 102309
		private static PipeData[] LoadBulkOleDb(OleDbConnection connection, string query)
			//private static PipeData[] LoadBulk(SqlConnection connection, string query)
		{
			// open the database to retrieve info

			OleDbDataReader dataReader = null;
			OleDbCommand dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			PipeData 		newObject = null;
			PipeData[]		typedArray;
			ArrayList		arrayList = new ArrayList();

			try
			{
				dataCommand = new OleDbCommand(query, connection);
				//dataCommand = new SqlCommand(query, connection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					//mam 102309
					//newObject = new PipeData(dataReader);
					newObject = new PipeData(dataReader.GetInt32(0));

					//mam 11142011 - get the data for the pipe
					newObject.LoadRecordData(dataReader);

					if (newObject.ID != 0)
						arrayList.Add(newObject);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("PipeData.LoadBulk Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			typedArray = new PipeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 11142011 - new method need this when importing from Access
		private static string GetBaseSelectOleDb()
		{
			StringBuilder builder = new StringBuilder(150);

			builder.Append("SELECT ");
			builder.Append("pipe_id, ");
			builder.Append("discpipe_id, ");
			builder.Append("pipe_IDNumber, ");
			builder.Append("pipe_description, ");
			builder.Append("pipe_type, ");
			builder.Append("pipe_size, ");
			builder.Append("pipe_length, ");
			builder.Append("pipe_unitCost, ");
			builder.Append("pipe_installYear, ");
			builder.Append("pipe_originalENR, ");
			builder.Append("pipe_replacementValue, ");
			builder.Append("pipe_salvageValue, ");
			builder.Append("pipe_annualMaintCost, ");
			builder.Append("pipe_conditionRank, ");

			builder.Append("pipe_critPublicHealth, ");
			builder.Append("pipe_critEnvironmental, ");
			builder.Append("pipe_critRepairCost, ");
			builder.Append("pipe_critCustomerEffect, ");

			builder.Append("pipe_levelOfService, ");
			builder.Append("pipe_vulnerability, ");
			builder.Append("pipe_originalUsefulLife ");

			//mam
			builder.Append(", pipe_vulnerability2 ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear");
			builder.Append(", RepairCost");
			builder.Append(", pipe_acquisitionCost");
			builder.Append(", pipe_currentValue");
			builder.Append(", RehabCost");
			builder.Append(", RedundantAssetCount ");

			builder.Append("FROM PipingComponents ");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		#endregion /***** OleDb *****/

		//mam 102309
		//private static PipeData[] LoadBulk(OleDbConnection connection, string query)
		private static PipeData[] LoadBulk(SqlConnection connection, string query)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader dataReader = null;
			//OleDbCommand dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			PipeData 		newObject = null;
			PipeData[]		typedArray;
			ArrayList		arrayList = new ArrayList();

			//mam 07072011
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(query, connection);
				dataCommand = new SqlCommand(query, connection);

				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new PipeData(dataReader);
					if (newObject.ID != 0)
					{
						//mam 07072011 - load crit values into new object
						System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityPipe", "@pipeId", newObject.ID);
						newObject.ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(dataTable);

						arrayList.Add(newObject);
					}
				}
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("PipeData.LoadBulk Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				//mam 07072011
				dataAccess = null;
			}

			typedArray = new PipeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		public static PipeData[] LoadForDiscipline(int disciplineID)
		{
			//mam 102309
			//return LoadForDiscipline(WAMSource.CurrentSource.ConnectionString, disciplineID);
			return LoadForDiscipline(Globals.WamSqlConnectionString, disciplineID);
		}

		public static PipeData[] LoadForDiscipline(string connectionString, int disciplineID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);

			try
			{
				sqlConnection.Open();
				return LoadForDiscipline(sqlConnection, disciplineID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}
		}

		//mam 102309
		//public static PipeData[] LoadForDiscipline(OleDbConnection sqlConnection, int disciplineID)
		public static PipeData[] LoadForDiscipline(SqlConnection sqlConnection, int disciplineID)
		{
			StringBuilder	builder = new StringBuilder(GetBaseSelect());

			builder.AppendFormat("WHERE (discpipe_id={0}) ", disciplineID);
			return LoadBulk(sqlConnection, builder.ToString());
		}

		//mam 03202012
		//@@@@
		public static PipeData[] LoadForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			PipeData newObject = null;
			PipeData[] typedArray;
			ArrayList arrayList = new ArrayList();

			StringBuilder builder = new StringBuilder();

			builder.Append("SELECT PC.pipe_id, PC.discpipe_id, PC.pipe_IDNumber, PC.pipe_description, PC.pipe_type, PC.pipe_size, PC.pipe_length");
			builder.Append(" , PC.pipe_unitCost, PC.pipe_installYear, PC.pipe_originalENR, PC.pipe_replacementValue, PC.pipe_salvageValue");
			builder.Append(" , PC.pipe_annualMaintCost, PC.pipe_conditionRank, PC.pipe_levelOfService, PC.pipe_vulnerability, PC.pipe_originalUsefulLife");
			builder.Append(" , PC.pipe_vulnerability2, PC.ReplacementValueYear, PC.RepairCost, PC.pipe_acquisitionCost, PC.pipe_currentValue");
			builder.Append(" , PC.RehabCost, PC.RedundantAssetCount ");
			builder.Append(" FROM PipingComponents PC LEFT JOIN DisciplinePipes D ON PC.discpipe_id = D.discpipe_id");
			builder.Append(" LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);

			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();

			//get the active crits for all components
			//System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityPipe", "@componentId", 0);
			StringBuilder builderCrits = new StringBuilder();
			builderCrits.Append("SELECT M.pipe_id, M.CriticalityId, C.Criticality, C.CriticalityWeight, C.Active");
			builderCrits.Append(", S.CriticalityScore");
			builderCrits.Append(", CS.CriticalityToScoreId, M.CriticalityScoreId, CS.CriticalityFactor");
			builderCrits.Append(", C.OrderBy AS CriticalityOrderBy, S.OrderBy AS FactorOrderBy");
			builderCrits.Append(" FROM PipeToCriticality M");
			builderCrits.Append(" INNER JOIN PipingComponents MC ON M.pipe_id = MC.pipe_id");
			builderCrits.Append(" INNER JOIN CriticalityScore S ON M.CriticalityScoreId = S.CriticalityScoreId");
			builderCrits.Append(" INNER JOIN Criticality C ON M.CriticalityId = C.CriticalityId");
			builderCrits.Append(" INNER JOIN CriticalityToScore CS ON M.CriticalityScoreId = CS.CriticalityScoreId AND M.CriticalityId = CS.CriticalityId");
			builderCrits.Append(" LEFT JOIN DisciplinePipes D ON MC.discpipe_id = D.discpipe_id");
			builderCrits.Append(" LEFT JOIN MajorComponents M2 ON D.component_id = M2.component_id");
			builderCrits.Append(" LEFT JOIN TreatmentProcesses P ON M2.process_id = P.process_id");
			builderCrits.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builderCrits.AppendFormat(" WHERE C.Active = 'true' AND F.infoset_id = {0}", infosetId);
			builderCrits.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id");
			builderCrits.Append(", M2.component_sortOrder, M2.component_id, C.OrderBy, S.OrderBy");

			try
			{
				System.Data.DataTable dataTableCritsAll = dataAccess.GetDisconnectedDataTable(builderCrits.ToString());

				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);
				dataReader = dataCommand.ExecuteReader();

				while (dataReader.Read())
				{
					newObject = new PipeData(dataReader);
					if (newObject.ID != 0)
					{
						//System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTableSP("GetListCriticalityPipe", "@pipeId", newObject.ID);
						DataRow[] rows = dataTableCritsAll.Select("pipe_id = " + newObject.ID);
						newObject.ComponentSelectedCriticalityFactorsCollection = LoadCriticalitiesForComponent(rows);

						arrayList.Add(newObject);
					}
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("PipeData.LoadBulk Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();

				dataAccess = null;
			}

			typedArray = new PipeData[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		//mam 03202012 - this method gets called only during pipe import
		public static PipeData[] LoadForDisciplineAndPipeID(int disciplineID, string pipeID)
		{
			StringBuilder	builder = new StringBuilder(GetBaseSelect());

			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(WAMSource.CurrentSource.ConnectionString);
			SqlConnection sqlConnection = new SqlConnection(Globals.WamSqlConnectionString);

			PipeData[]		pipeData = null;

			builder.AppendFormat("WHERE (discpipe_id={0} AND pipe_IDNumber='{1}') ", 
				disciplineID, Drive.SQL.PadString(pipeID));

			try
			{
				sqlConnection.Open();
				pipeData = LoadBulk(sqlConnection, builder.ToString());
			}
			catch
			{
				pipeData = new PipeData[0];
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return pipeData;
		}

		//mam 07072011
		private static MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesForComponent(System.Data.DataTable dataTable)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			//int counter = 0;
			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in dataTable.Rows)
			{
				//counter++;

				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				//curCrit.CriticalityNumber = counter;
				curCrit.CriticalityNumber = ((Criticality)Common.CommonTasks.Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				//critColl.Add(curCrit);
				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}
		//</mam>

		//mam 03202012
		//@@@@
		private static MajorComponentSelectedCriticalityFactorsCollection LoadCriticalitiesForComponent(System.Data.DataRow[] dataRows)
		{
			//the MajorComponentSelectedCriticalityFactorsCollection collection contains only the user-selected factors (one per criticality) 
			//	rather than all of the factors for each criticality

			MajorComponentSelectedCriticalityFactors curCrit = new MajorComponentSelectedCriticalityFactors();
			MajorComponentSelectedCriticalityFactorsCollection critColl = new MajorComponentSelectedCriticalityFactorsCollection();
			CriticalityFactor critFactor = new CriticalityFactor();
			ArrayList arrayListCrits = new ArrayList();

			foreach (System.Data.DataRow dataRow in dataRows)
			{
				curCrit = new MajorComponentSelectedCriticalityFactors();
				curCrit.CriticalityId = Convert.ToInt32(dataRow["CriticalityId"]);

				//make sure the criticality number is the same as the master crit list, which is the Criticalities collection, loaded on app startup
				curCrit.CriticalityNumber = ((Criticality)Common.CommonTasks.Criticalities.ItemById(curCrit.CriticalityId)).CriticalityNumber;

				curCrit.CriticalityWeight = Convert.ToInt32(dataRow["CriticalityWeight"]);
				curCrit.CriticalityName = dataRow["Criticality"].ToString();
				curCrit.CriticalityOrderBy = Convert.ToInt32(dataRow["CriticalityOrderBy"]);
				
				critFactor = new CriticalityFactor();
				critFactor.FactorId = Convert.ToInt32(dataRow["CriticalityToScoreId"]);
				critFactor.ScoreId = Convert.ToInt32(dataRow["CriticalityScoreId"]);
				critFactor.FactorName = dataRow["CriticalityFactor"].ToString();
				critFactor.Score = Convert.ToInt32(dataRow["CriticalityScore"]);;
				critFactor.FactorOrderBy = Convert.ToInt32(dataRow["FactorOrderBy"]);
				curCrit.CritFactor = critFactor;

				arrayListCrits.Add(curCrit);
			}

			arrayListCrits.Sort();

			for (int i = 0; i < arrayListCrits.Count; i++)
			{
				critColl.Add((MajorComponentSelectedCriticalityFactors)arrayListCrits[i]);
			}

			return critColl;
		}

		#endregion /***** Static Methods *****/

		#region /***** ICloneable Members *****/
		public object		Clone()
		{
			PipeData		pipe = new PipeData(0);

			pipe.m_id = m_id;
			pipe.CopyFrom(this);
			return pipe;
		}

		public void			CopyFrom(PipeData rhs)
		{
			m_discPipeID = rhs.m_discPipeID;
			m_idNumber = rhs.m_idNumber;
			m_description = rhs.m_description;
			m_type = rhs.m_type;
			m_size = rhs.m_size;
			m_length = rhs.m_length;
			m_unitCost = rhs.m_unitCost;
			m_installYear = rhs.m_installYear;
			m_originalENR = rhs.m_originalENR;
			m_replacementValue = rhs.m_replacementValue;
			m_salvageValue = rhs.m_salvageValue;
			m_annualMaintCost = rhs.m_annualMaintCost;
			m_conditionRank = rhs.m_conditionRank;

			//mam 07072011 - no longer using the four fixed crits
			//m_critPublic = rhs.m_critPublic;
			//m_critEnvironmental = rhs.m_critEnvironmental;
			//m_critRepair = rhs.m_critRepair;
			//m_critCustEffect = rhs.m_critCustEffect;

			//mam 07072011
			ComponentSelectedCriticalityFactorsCollection = rhs.ComponentSelectedCriticalityFactorsCollection;

			m_LOS = rhs.m_LOS;
			m_vulnerability = rhs.m_vulnerability;
			m_orgUsefulLife = rhs.m_orgUsefulLife;

			//mam
			m_vulnerability2 = rhs.m_vulnerability2;
			m_overrideVulnerability = rhs.m_overrideVulnerability;
			//</mam>

			//mam 050806
			m_replacementValueYear = rhs.m_replacementValueYear;
			m_repairCost = rhs.m_repairCost;
			m_overrideRepairCost = rhs.m_overrideRepairCost;
			m_acquisitionCost = rhs.m_acquisitionCost;
			m_overrideAcquisitionCost = rhs.m_overrideAcquisitionCost;
			m_currentValue = rhs.m_currentValue;
			m_overrideCurrentValue = rhs.m_overrideCurrentValue;
			m_rehabCost = rhs.m_rehabCost;
			m_redundantAssetCount = rhs.m_redundantAssetCount;
		}

		public void			CopyTo(PipeData copy)
		{
			copy.m_discPipeID = 0;
			copy.m_idNumber = m_idNumber;
			copy.m_description = m_description;
			copy.m_type = m_type;
			copy.m_size = m_size;
			copy.m_length = m_length;
			copy.m_unitCost = m_unitCost;
			copy.m_installYear = m_installYear;
			copy.m_originalENR = m_originalENR;
			copy.m_replacementValue = m_replacementValue;
			copy.m_salvageValue = m_salvageValue;
			copy.m_annualMaintCost = m_annualMaintCost;
			copy.m_conditionRank = m_conditionRank;

			//mam 07072011 - no longer using four fixed criticalities
			//copy.m_critPublic = m_critPublic;
			//copy.m_critEnvironmental = m_critEnvironmental;
			//copy.m_critRepair = m_critRepair;
			//copy.m_critCustEffect = m_critCustEffect;

			//mam 07072011
			int test = ComponentSelectedCriticalityFactorsCollection.Count;
			copy.ComponentSelectedCriticalityFactorsCollection = this.ComponentSelectedCriticalityFactorsCollection;

			copy.m_LOS = m_LOS;
			copy.m_vulnerability = m_vulnerability;
			copy.m_orgUsefulLife = m_orgUsefulLife;

			//mam
			copy.m_vulnerability2 = m_vulnerability2;
			copy.m_overrideVulnerability = m_overrideVulnerability;
			//</mam>

			//mam 050806
			copy.m_replacementValueYear = m_replacementValueYear;
			copy.m_repairCost = m_repairCost;
			copy.m_overrideRepairCost = m_overrideRepairCost;
			copy.m_acquisitionCost = m_acquisitionCost;
			copy.m_overrideAcquisitionCost = m_overrideAcquisitionCost;
			copy.m_currentValue = m_currentValue;
			copy.m_overrideCurrentValue = m_overrideCurrentValue;
			copy.m_rehabCost = m_rehabCost;
			copy.m_redundantAssetCount = m_redundantAssetCount;
		}
		#endregion /***** ICloneable Members *****/
	}

	#region /***** Cache Class *****/
	public class			PipeDataCache : IDisposable
	{
		private Hashtable	m_hash = new Hashtable();

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.PipeData));
		private int			m_infoSetID = 0;

		public				PipeDataCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged));
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged));
		}

		#region IDisposable Members
		~PipeDataCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SuppressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		//mam 102309
		//private void DataChanged(object sender, Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
		{
			PipeData obj = e.ChangedObject as PipeData;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				m_hash[obj.GetHashCode()] = obj;

				// Update the parent tree, too
				if (e.Action == Drive.Synchronization.SyncAction.Add)
					m_treeHash.AddChild(obj.DiscPipeID, obj);
			}
			else if (e.Action == Drive.Synchronization.SyncAction.Delete)
			{
				if (m_hash[obj.GetHashCode()] != null)
					m_hash.Remove(obj);

				m_treeHash.RemoveChild(obj.DiscPipeID, obj);
			}
		}

		public PipeData[] GetForDiscipline(int id)
		{
			PipeData[] children = (PipeData[])m_treeHash.GetChildren(id);
			if (children == null)
			{
				children = PipeData.LoadForDiscipline(id);
				m_treeHash.SetChildren(id, children);
				for (int pos = 0; pos < children.Length; pos++)
				{
					// Set info set for cache matching purposes
					children[pos].InfoSetID = m_infoSetID;
					m_hash[children[pos].GetHashCode()] = children[pos];
				}
			}
			return children;
		}

		//mam 03202012 - this method is never called
		//mam 102309
		//public PipeData[] BuildCacheForDiscipline(OleDbConnection connection, int id)
		public PipeData[] BuildCacheForDiscipline(SqlConnection connection, int id)
		{
			PipeData[] children = PipeData.LoadForDiscipline(connection, id);

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				// Set info set for cache matching purposes
				children[pos].InfoSetID = m_infoSetID;
				m_hash[children[pos].GetHashCode()] = children[pos];
			}
			return children;
		}

		//mam 03202012
		//@@@@
		public PipeData[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			PipeData[] children = PipeData.LoadForInfoset(connection, infosetId);

			foreach (PipeData pipeData in children)
			{
				m_treeHash.AddChild(pipeData.DiscPipeID, pipeData);

				pipeData.InfoSetID = m_infoSetID;
				m_hash[pipeData.GetHashCode()] = pipeData;
			}

			return children;
		}

		public void			Clear()
		{
			m_hash.Clear();
			m_treeHash.Clear();
		}

		public PipeData GetPipeData(int id)
		{
			// Look up the components in the hash table
			PipeData pipe = m_hash[id.GetHashCode()] as PipeData;

			// If the component is not present, load it from the default database
			if (pipe == null)
			{
				pipe = new PipeData(id);
				pipe.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (pipe.ID != 0)
					m_hash[pipe.GetHashCode()] = pipe;
				else
					pipe = null;
			}

			return pipe;
		}
	}
	#endregion /***** Cache Class *****/
}