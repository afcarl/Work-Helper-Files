using System;
using System.Collections;
using System.Data;
using System.Windows.Forms;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class VerifyDatabaseSchema
	{
		//mam - this class checks the database table and field names (as they existed when I started
		//	working on this application) to determine whether the prospective database is valid

		//mam 102309
		//private string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;

		#region /***** TableName Enums *****/
		
		private enum DatabaseTableNames
		{
			ComponentAssets,
			CustomENR,
			DisciplineLand,
			DisciplineMech,
			DisciplineNodes,
			DisciplinePipes,
			DisciplineStruct,
			Facilities,
			InfoSets,
			MajorComponents,
			NodeAppurtComponents,
			PipingComponents,
			TreatmentProcesses
		}

		#endregion /***** TableName Enums *****/

		#region /***** FieldName Enums *****/

		private enum TableComponentAssets
		{
			compasset_conditionRanking,
			compasset_description,
			compasset_id,
			compasset_name,
			compasset_replacementCost,
			compasset_sortOrder,
			component_id
		}

		private enum TableCustomENR
		{
			enr_value,
			enr_year,
			facility_id
		}

		private enum TableDisciplineLand
		{
			component_id,
			disc3_acquisitionCost,
			disc3_annualMaintCost,
			disc3_assessedBy,
			disc3_comments,
			disc3_conditionRanking,
			disc3_currentENR,
			disc3_CWPAssetValue,
			disc3_dateInspected,
			disc3_equipmentNumber,
			disc3_excessiveErosion,
			disc3_expansionSpace,
			disc3_facilitiesSecure,
			disc3_fencingAdequate,
			disc3_functionCover,
			disc3_id,
			disc3_installationYear,
			disc3_manufacturer,
			disc3_originalENR,
			disc3_originalUsefulLife,
			disc3_photoCaption1,
			disc3_photoCaption2,
			disc3_photoCaption3,
			disc3_replacementValue,
			disc3_roadDegradation,
			disc3_runHours,
			disc3_runningAtInspect,
			disc3_salvageValue,
			disc3_severalPotholes
		}

		private enum TableDisciplineMech
		{
			component_id,
			disc1_acquisitionCost,
			disc1_annualMaintCost,
			disc1_assessedBy,
			disc1_comments,
			disc1_conditionRanking,
			disc1_currentENR,
			disc1_CWPAssetValue,
			disc1_dateInspected,
			disc1_elecCleanContacts,
			disc1_elecExcessiveCorrosion,
			disc1_elecPartsAvailable,
			disc1_elecSpareCapacity,
			disc1_equipmentNumber,
			disc1_id,
			disc1_installationYear,
			disc1_instrAlarmFunctional,
			disc1_instrIndicationFunctional,
			disc1_instrPartsAvailable,
			disc1_instrPartsMissing,
			disc1_instrSpareCapacity,
			disc1_manufacturer,
			disc1_mechAdequate,
			disc1_mechCanRunWhenInspected,
			disc1_mechExcessiveCorrosion,
			disc1_mechExcessiveLeaks,
			disc1_mechExcessiveNoise,
			disc1_mechExcessiveVibration,
			disc1_mechMotorAmps,
			disc1_mechPartsAvailable,
			disc1_mechPartsMissing,
			disc1_mechRunningHot,
			disc1_mechSupportIsFunctional,
			disc1_originalENR,
			disc1_originalUsefulLife,
			disc1_photoCaption,
			disc1_pipeExcessiveCorrosion,
			disc1_pipeExcessiveLeaks,
			disc1_pipePaintGood,
			disc1_replacementValue,
			disc1_runHours,
			disc1_runningAtInspect,
			disc1_salvageValue
		}

		private enum TableDisciplineNodes
		{
			component_id,
			discnode_assessedBy,
			discnode_comments,
			discnode_currentENR,
			discnode_dateInspected,
			discnode_id,
			discnode_photoCaption
		}

		private enum TableDisciplinePipes
		{
			component_id,
			discpipe_assessedBy,
			discpipe_comments,
			discpipe_currentENR,
			discpipe_dateInspected,
			discpipe_id,
			discpipe_photoCaption
		}

		private enum TableDisciplineStruct
		{
			component_id,
			disc2_acquisitionCost,
			disc2_annualMaintCost,
			disc2_assessedBy,
			disc2_comments,
			disc2_concSpalling,
			disc2_conditionRanking,
			disc2_corrosionCoating,
			disc2_currentENR,
			disc2_CWPAssetValue,
			disc2_dateInspected,
			disc2_equipmentNumber,
			disc2_id,
			disc2_installationYear,
			disc2_majorCracks,
			disc2_manufacturer,
			disc2_membExcessiveCorrosion,
			disc2_originalENR,
			disc2_originalUsefulLife,
			disc2_paintGood,
			disc2_photoCaption,
			disc2_replacementValue,
			disc2_roofExcessiveDegradation,
			disc2_runHours,
			disc2_runningAtInspect,
			disc2_salvageValue,
			disc2_settingEvident,
			disc2_structExcessiveCorrosion,
			disc2_visibleDeformities
		}

		private enum TableFacilities
		{
			facility_captionEast,
			facility_captionNorth,
			facility_captionSouth,
			facility_captionWest,
			facility_comments,
			facility_currentENR,
			facility_currentYear,
			facility_fundedFacilityCost,
			facility_fundedReplaceValue,
			facility_id,
			facility_name,
			facility_newFacilityCost,
			facility_oldOrgCost,
			facility_replacementValue,
			facility_sortOrder,
			facility_usesCustomENR,
			infoset_id
		}

		private enum TableInfoSets
		{
			infoset_description,
			infoset_id,
			infoset_name
		}

		private enum TableMajorComponents
		{
			component_captionPhoto,
			component_comments,
			component_critCustomerEffect,
			component_critEnvironmental,
			component_critPublicHealth,
			component_critRepairCost,
			component_CWPValue,
			component_id,
			component_LevelOfService,
			component_MechStructDisc,
			component_name,
			component_retired,
			component_sortOrder,
			component_vulnerability,
			facility_id,
			process_id
		}

		private enum TableNodeAppurtComponents
		{
			discnode_id,
			node_acquisitionCost,
			node_annualMaintCost,
			node_conditionRank,
			node_critCustomerEffect,
			node_critEnvironmental,
			node_critPublicHealth,
			node_critRepairCost,
			node_description,
			node_id,
			node_IDNumber,
			node_installYear,
			node_levelOfService,
			node_originalENR,
			node_originalUsefulLife,
			node_replacementValue,
			node_salvageValue,
			node_size,
			node_type,
			node_vulnerability
		}

		private enum TablePipingComponents
		{
			discpipe_id,
			pipe_annualMaintCost,
			pipe_conditionRank,
			pipe_critCustomerEffect,
			pipe_critEnvironmental,
			pipe_critPublicHealth,
			pipe_critRepairCost,
			pipe_description,
			pipe_id,
			pipe_IDNumber,
			pipe_installYear,
			pipe_length,
			pipe_levelOfService,
			pipe_originalENR,
			pipe_originalUsefulLife,
			pipe_replacementValue,
			pipe_salvageValue,
			pipe_size,
			pipe_type,
			pipe_unitCost,
			pipe_vulnerability
		}

		private enum TableTreatmentProcesses
		{
			facility_id,
			process_captionPhoto,
			process_comments,
			process_CWPTPValue,
			process_id,
			process_isFunded,
			process_name,
			process_orgCost,
			process_orgCostOrgVal,
			process_pctFunded,
			process_sortOrder
		}


		#endregion /***** FieldName Enums *****/

		public VerifyDatabaseSchema()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region /***** VerifyDatabase *****/

		public bool VerifyTableNamesAndFields(string databaseName)
		{
			//mam 102309
			//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			WAM.Common.DataAccessOleDb dataAccess = new WAM.Common.DataAccessOleDb();
			DataTable dataTable = new DataTable();
			DataRow[] dataRows;
			bool DatabaseOK = true;

			// get all fields from the selected database for all tables
			dataTable = dataAccess.GetFields("", databaseName);
			if (dataTable == null)
			{
				DatabaseOK = false;
				return DatabaseOK;
			}

			foreach (string databaseTableName in Enum.GetNames(typeof(DatabaseTableNames)))
			{
				if (!DatabaseOK)
					break;

				dataRows = dataTable.Select("TABLE_NAME = '" + databaseTableName + "'");
				if (dataRows == null)
				{
					DatabaseOK = false;
					break;
				}
				if (dataRows.Length == 0)
				{
					DatabaseOK = false;
					break;
				}

				//dataTable = dataAccess.GetTables(databaseTableName);
				//if (dataTable == null)
				//{
				//	DatabaseOK = false;
				//	break;
				//}
				//else
				//{
				//dataTableFields = dataAccess.GetFields(databaseTableName);
				switch (databaseTableName)
				{
					case "ComponentAssets":
					{
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableComponentAssets)))
						{
							//if (!CheckField(dataTableFields, databaseFieldName))
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;
					}
					case "DisciplineLand":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableDisciplineLand)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "DisciplineMech":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableDisciplineMech)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "DisciplineNodes":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableDisciplineNodes)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "DisciplinePipes":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableDisciplinePipes)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "DisciplineStruct":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableDisciplineStruct)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "Facilities":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableFacilities)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "InfoSets":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableInfoSets)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "MajorComponents":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableMajorComponents)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "NodeAppurtComponents":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableNodeAppurtComponents)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "PipingComponents":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TablePipingComponents)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;

					case "TreatmentProcesses":
						foreach (string databaseFieldName in Enum.GetNames(typeof(TableTreatmentProcesses)))
						{
							if (!CheckField(dataRows, databaseFieldName))
							{
								DatabaseOK = false;
								break;
							}
						}
						break;
				}
				//}
			}

			return DatabaseOK;
		}

		public bool VerifyTables(string databaseName)
		{
			WAM.Common.DataAccessOleDb dataAccess = new WAM.Common.DataAccessOleDb();
			DataTable dataTable = new DataTable();
			DataRow[] dataRows;
			bool DatabaseOK = true;

			// get all tables from the selected database
			dataTable = dataAccess.GetTables("", databaseName);
			if (dataTable == null)
				DatabaseOK = false;

			foreach (string databaseTableName in Enum.GetNames(typeof(DatabaseTableNames)))
			{
				if (!DatabaseOK)
					break;

				dataRows = dataTable.Select("TABLE_NAME = '" + databaseTableName + "'");
				if (dataRows == null)
				{
					DatabaseOK = false;
					break;
				}
				if (dataRows.Length == 0)
				{
					DatabaseOK = false;
					break;
				}
			}

			return DatabaseOK;
		}

		private bool CheckField(DataTable dataTableFields, string databaseFieldName)
		{
			bool fieldFound = false;
			for (int i = 0; i < dataTableFields.Rows.Count; i++)
			{
				if (dataTableFields.Rows[i].ItemArray[3].ToString() == databaseFieldName)
				{
					fieldFound = true;
					break;
				}
			}
			return fieldFound;
		}

		private bool CheckField(DataRow[] dataRows, string databaseFieldName)
		{
			bool fieldFound = false;
			for (int i = 0; i < dataRows.Length; i++)
			{
				if (dataRows[i].ItemArray[3].ToString() == databaseFieldName)
				{
					fieldFound = true;
					break;
				}
			}
			return fieldFound;
		}


		#endregion /***** VerifyDatabase *****/
	}
}
