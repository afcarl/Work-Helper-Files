using System;
using System.Configuration;
using System.Data;

//mam 102309 - leave as is for importing from Access databases
using System.Data.OleDb;

using System.Text;
using System.Collections;

//mam 102309
using System.Data.SqlClient;

//mam 102309
using WAM.Common;

namespace WAM.Data
{
	/// <summary>
	/// Summary description for DisciplineMech.
	/// </summary>
	public class DisciplineMech : Discipline
	{
		#region /***** Member Variables *****/

		//mam - change all ItemStatus.No to ItemStatus.NotApplicable
//		private ItemStatus	m_mechExcessiveVibration = ItemStatus.No;
//		private ItemStatus	m_mechExcessiveNoise = ItemStatus.No;
//		private ItemStatus	m_mechExcessiveCorrosion = ItemStatus.No;
//		private ItemStatus	m_mechExcessiveLeaks = ItemStatus.No;
//		private ItemStatus	m_mechRunningHot = ItemStatus.No;
//		private ItemStatus	m_mechCanRunWhenInspected = ItemStatus.No;
//		private ItemStatus	m_mechSupportIsFunctional = ItemStatus.No;
//		private ItemStatus	m_mechPartsMissing = ItemStatus.No;
//		private ItemStatus	m_mechPartsAvailable = ItemStatus.No;
//		private ItemStatus	m_mechAdequate = ItemStatus.No;
//		private ItemStatus	m_mechMotorAmps = ItemStatus.No;
//		private ItemStatus	m_instrIndicationFunctional = ItemStatus.No;
//		private ItemStatus	m_instrAlarmFunctional = ItemStatus.No;
//		private ItemStatus	m_instrPartsMissing = ItemStatus.No;
//		private ItemStatus	m_instrPartsAvailable = ItemStatus.No;
//		private ItemStatus	m_instrSpareCapacity = ItemStatus.No;
//		private ItemStatus	m_elecExcessiveCorrosion = ItemStatus.No;
//		private ItemStatus	m_elecCleanContacts = ItemStatus.No;
//		private ItemStatus	m_elecPartsAvailable = ItemStatus.No;
//		private ItemStatus	m_elecSpareCapacity = ItemStatus.No;
//		private ItemStatus	m_pipeExcessiveCorrosion = ItemStatus.No;
//		private ItemStatus	m_pipeExcessiveLeaks = ItemStatus.No;
//		private ItemStatus	m_pipePaintGood = ItemStatus.No;
		
		private ItemStatus	m_mechExcessiveVibration = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveNoise = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_mechExcessiveLeaks = ItemStatus.NotApplicable;
		private ItemStatus	m_mechRunningHot = ItemStatus.NotApplicable;
		private ItemStatus	m_mechCanRunWhenInspected = ItemStatus.NotApplicable;
		private ItemStatus	m_mechSupportIsFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_mechPartsMissing = ItemStatus.NotApplicable;
		private ItemStatus	m_mechPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_mechAdequate = ItemStatus.NotApplicable;
		private ItemStatus	m_mechMotorAmps = ItemStatus.NotApplicable;
		private ItemStatus	m_instrIndicationFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_instrAlarmFunctional = ItemStatus.NotApplicable;
		private ItemStatus	m_instrPartsMissing = ItemStatus.NotApplicable;
		private ItemStatus	m_instrPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_instrSpareCapacity = ItemStatus.NotApplicable;
		private ItemStatus	m_elecExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_elecCleanContacts = ItemStatus.NotApplicable;
		private ItemStatus	m_elecPartsAvailable = ItemStatus.NotApplicable;
		private ItemStatus	m_elecSpareCapacity = ItemStatus.NotApplicable;
		private ItemStatus	m_pipeExcessiveCorrosion = ItemStatus.NotApplicable;
		private ItemStatus	m_pipeExcessiveLeaks = ItemStatus.NotApplicable;
		private ItemStatus	m_pipePaintGood = ItemStatus.NotApplicable;
		//</mam>

		private DateTime	m_dateInspected = DateTime.Now.Date;
		private string		m_equipmentNumber = "";
		private string		m_assessedBy = "";
		private string		m_manufacturer = "";
		private string		m_runHours = "";
		private string		m_photoCaption = "";
		private string		m_comments = "";
		private bool		m_runningAtInspect = false;

		//mam 102309
		//private string m_photo = "";

		//mam 07072011
		private bool forImport = false;

		////mam 03202012
		//private string m_photoFileName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//public DisciplineMech(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		public DisciplineMech(int id) : base(Globals.WamSqlConnectionString, id)
		{
			//mam 07072011
			if (id == 0)
			{
				m_rehabInterval = 10;
			}
		}

		public DisciplineMech(string connectionString, int id) : base(connectionString, id)
		{
			//mam 07072011
			if (id == 0)
			{
				m_rehabInterval = 10;
			}
		}

		//mam 102309
		//public DisciplineMech(System.Data.OleDb.OleDbConnection sqlConnection, int id)
		//	: base(sqlConnection.ConnectionString, id)
		public DisciplineMech(SqlConnection sqlConnection, int id)
			: base(sqlConnection.ConnectionString, id)
		{
			//mam 07072011
			if (id == 0)
			{
				m_rehabInterval = 10;
			}
		}

		//mam 102309
		//protected DisciplineMech(System.Data.OleDb.OleDbConnection sqlConnection, System.Data.OleDb.OleDbDataReader reader)
		//	: base(sqlConnection, reader)
		protected DisciplineMech(SqlConnection sqlConnection, SqlDataReader reader)
			: base(sqlConnection, reader)
		{
		}

		//mam 102309
		protected void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		{
			int				col = 0;

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_overrideAcquisitionCost = !reader.IsDBNull(col);
			m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_originalENR = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);
			m_mechExcessiveVibration = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveNoise = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_mechRunningHot = (ItemStatus)reader.GetByte(col++);
			m_mechCanRunWhenInspected = (ItemStatus)reader.GetByte(col++);
			m_mechSupportIsFunctional = (ItemStatus)reader.GetByte(col++);
			m_mechPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_mechPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_mechAdequate = (ItemStatus)reader.GetByte(col++);
			m_mechMotorAmps = (ItemStatus)reader.GetByte(col++);
			m_instrIndicationFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrAlarmFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_instrPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_instrSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_elecExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_elecCleanContacts = (ItemStatus)reader.GetByte(col++);
			m_elecPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_elecSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_pipePaintGood = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_runningAtInspect = reader.GetBoolean(col++);

			//mam
			m_overrideCurrentValue = !reader.IsDBNull(col);
			m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			//</mam>

			//mam 050806
			m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);

			m_overrideRepairCost = !reader.IsDBNull(col);

			m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_rehabCost = Drive.SQL.ReadNullableDecimal(reader, col++);

			//mam 07072011 - no need for additional rehab values here because we are not updating the Access database to include them
		}

		//mam 102309
		//protected override void LoadRecordData(System.Data.OleDb.OleDbDataReader reader)
		protected override void LoadRecordData(SqlDataReader reader)
		{
			int				col = 0;

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//InfoSetID = reader.GetInt32(col++);
			ComponentCipId = reader.GetInt32(col++);

			m_id = reader.GetInt32(col++);
			m_componentID = reader.GetInt32(col++);
			m_conditionRanking = (CondRank)reader.GetByte(col++);
			m_CWPAssetValue = reader.GetDouble(col++);
			m_orgUsefulLife = reader.GetInt16(col++);
			m_overrideAcquisitionCost = !reader.IsDBNull(col);

			//mam 102309
			//m_acquisitionCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_acquisitionCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_replacementValue = reader.GetDecimal(col++);
			m_salvageValue = reader.GetDecimal(col++);
			m_annualMaintCost = reader.GetDecimal(col++);
			m_originalENR = reader.GetInt32(col++);
			m_currentENR = reader.GetInt32(col++);

			m_mechExcessiveVibration = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveNoise = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_mechExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_mechRunningHot = (ItemStatus)reader.GetByte(col++);
			m_mechCanRunWhenInspected = (ItemStatus)reader.GetByte(col++);
			m_mechSupportIsFunctional = (ItemStatus)reader.GetByte(col++);
			m_mechPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_mechPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_mechAdequate = (ItemStatus)reader.GetByte(col++);
			m_mechMotorAmps = (ItemStatus)reader.GetByte(col++);
			m_instrIndicationFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrAlarmFunctional = (ItemStatus)reader.GetByte(col++);
			m_instrPartsMissing = (ItemStatus)reader.GetByte(col++);
			m_instrPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_instrSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_elecExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_elecCleanContacts = (ItemStatus)reader.GetByte(col++);
			m_elecPartsAvailable = (ItemStatus)reader.GetByte(col++);
			m_elecSpareCapacity = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveCorrosion = (ItemStatus)reader.GetByte(col++);
			m_pipeExcessiveLeaks = (ItemStatus)reader.GetByte(col++);
			m_pipePaintGood = (ItemStatus)reader.GetByte(col++);
			m_dateInspected = reader.GetDateTime(col++);

			//mam
			//m_inspectionYear = m_dateInspected.Year;
			m_inspectionYear = m_dateInspected;
			//</mam>

			//mam 102309
			//m_assessedBy = Drive.SQL.ReadNullableString(reader, col++);
			//m_equipmentNumber = Drive.SQL.ReadNullableString(reader, col++);
			//m_manufacturer = Drive.SQL.ReadNullableString(reader, col++);
			//m_runHours = Drive.SQL.ReadNullableString(reader, col++);
			//m_installationYear = Drive.SQL.ReadNullableInt16(reader, col++);
			//m_photoCaption = Drive.SQL.ReadNullableString(reader, col++);
			//m_comments = Drive.SQL.ReadNullableString(reader, col++);
			m_assessedBy = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_equipmentNumber = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_manufacturer = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			m_runHours = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
			if (reader.IsDBNull(col)) m_installationYear = 0;
			else m_installationYear = reader.GetInt16(col);
			col++;
			m_photoCaption = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 03202012
			m_photoFileName = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			//mam 102309
			//m_photo = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_comments = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;

			m_runningAtInspect = reader.GetBoolean(col++);

			//mam
			m_overrideCurrentValue = !reader.IsDBNull(col);

			//mam 102309
			//m_currentValue = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_currentValue = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			//</mam>

			//mam 050806
			//mam 102309
			//m_replacementValueYear = Drive.SQL.ReadNullableInt32(reader, col++);
			m_replacementValueYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			m_overrideRepairCost = !reader.IsDBNull(col);

			//mam 102309
			//m_repairCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			//m_rehabCost = Drive.SQL.ReadNullableDecimal(reader, col++);
			m_repairCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;
			m_rehabCost = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			//mam 07072011
			m_rehabCostYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//mam 07072011 - set m_rehabInterval and m_rehabNext to zero if component cip mode is Replacement
			//if CipPlanningId = zero (the Major Component has no CipPlanningId), get rehab interval and rehab next from the database
			//if CipPlanningId = id for Replacement, set rehab interval and rehab next to zero
			//otherwise, get them from database

			//mam 07072011 begin
			m_rehabInterval = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			//mam 01222012 - no longer using override for Time to Next Rehab
			//m_overrideRehabNext = !reader.IsDBNull(col);

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//m_rehabNext = reader.IsDBNull(col) ? 0 : reader.GetDecimal(col); col++;

			m_rehabYearLast = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			//mam 07072011 end

			//if the planning mode is replacement, set the cache values to zero
			if (this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				m_rehabInterval = 0m;
				m_rehabNext = 0m;
			}

			//mam 07072011
			m_overrideNextReplacementYear = !reader.IsDBNull(col);
			m_nextReplacementYear = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;

			//***************************************
			//builder.Append(", RehabCostYear");
			//builder.Append(", RehabInterval");
			////builder.Append(", RehabNext");
			//builder.Append(", RehabYearLast");
			//builder.Append(", NextReplacementYear");
			//builder.Append(", ReplacementValueDesc");
			//builder.Append(", RehabCostDesc");
			//builder.Append(", RehabYearNext");
			//***************************************

			//mam 01222012
			try
			{
				//m_replacementValueDesc = Drive.SQL.ReadNullableString(reader, col++);
				m_replacementValueDesc = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
				m_rehabCostDesc = reader.IsDBNull(col) ? "" : reader.GetString(col); col++;
				m_overrideRehabYearNext = !reader.IsDBNull(col);
				m_rehabYearNext = reader.IsDBNull(col) ? 0 : reader.GetInt32(col); col++;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
			}
		}

		//mam 03202012
		//@@@@
		protected void LoadRecordData(DataRow dataRow)
		{
			m_id = dataRow["disc1_id"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["disc1_id"]);

			if (m_id == 0)
			{
				return;
			}

			ComponentCipId = Convert.ToInt32(dataRow["CipPlanningId"]);

			m_componentID = Convert.ToInt32(dataRow["component_id"]);
			m_conditionRanking = (CondRank)Convert.ToByte(dataRow["disc1_conditionRanking"]);
			m_CWPAssetValue = Convert.ToDouble(dataRow["disc1_CWPAssetValue"]);
			m_orgUsefulLife = Convert.ToInt16(dataRow["disc1_originalUsefulLife"]);
			m_overrideAcquisitionCost = dataRow["disc1_acquisitionCost"] != DBNull.Value;
			m_acquisitionCost = dataRow["disc1_acquisitionCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["disc1_acquisitionCost"]);

			m_replacementValue = Convert.ToDecimal(dataRow["disc1_replacementValue"]);
			m_salvageValue = Convert.ToDecimal(dataRow["disc1_salvageValue"]);
			m_annualMaintCost = Convert.ToDecimal(dataRow["disc1_annualMaintCost"]);
			m_originalENR = Convert.ToInt32(dataRow["disc1_originalENR"]);
			m_currentENR = Convert.ToInt32(dataRow["disc1_currentENR"]);

			m_mechExcessiveVibration = (ItemStatus)Convert.ToByte(dataRow["disc1_mechExcessiveVibration"]);
			m_mechExcessiveNoise = (ItemStatus)Convert.ToByte(dataRow["disc1_mechExcessiveNoise"]);
			m_mechExcessiveCorrosion = (ItemStatus)Convert.ToByte(dataRow["disc1_mechExcessiveCorrosion"]);
			m_mechExcessiveLeaks = (ItemStatus)Convert.ToByte(dataRow["disc1_mechExcessiveLeaks"]);
			m_mechRunningHot = (ItemStatus)Convert.ToByte(dataRow["disc1_mechRunningHot"]);
			m_mechCanRunWhenInspected = (ItemStatus)Convert.ToByte(dataRow["disc1_mechCanRunWhenInspected"]);
			m_mechSupportIsFunctional = (ItemStatus)Convert.ToByte(dataRow["disc1_mechSupportIsFunctional"]);
			m_mechPartsMissing = (ItemStatus)Convert.ToByte(dataRow["disc1_mechPartsMissing"]);
			m_mechPartsAvailable = (ItemStatus)Convert.ToByte(dataRow["disc1_mechPartsAvailable"]);
			m_mechAdequate = (ItemStatus)Convert.ToByte(dataRow["disc1_mechAdequate"]);
			m_mechMotorAmps = (ItemStatus)Convert.ToByte(dataRow["disc1_mechMotorAmps"]);
			m_instrIndicationFunctional = (ItemStatus)Convert.ToByte(dataRow["disc1_instrIndicationFunctional"]);
			m_instrAlarmFunctional = (ItemStatus)Convert.ToByte(dataRow["disc1_instrAlarmFunctional"]);
			m_instrPartsMissing = (ItemStatus)Convert.ToByte(dataRow["disc1_instrPartsMissing"]);
			m_instrPartsAvailable = (ItemStatus)Convert.ToByte(dataRow["disc1_instrPartsAvailable"]);
			m_instrSpareCapacity = (ItemStatus)Convert.ToByte(dataRow["disc1_instrSpareCapacity"]);
			m_elecExcessiveCorrosion = (ItemStatus)Convert.ToByte(dataRow["disc1_elecExcessiveCorrosion"]);
			m_elecCleanContacts = (ItemStatus)Convert.ToByte(dataRow["disc1_elecCleanContacts"]);
			m_elecPartsAvailable = (ItemStatus)Convert.ToByte(dataRow["disc1_elecPartsAvailable"]);
			m_elecSpareCapacity = (ItemStatus)Convert.ToByte(dataRow["disc1_elecSpareCapacity"]);
			m_pipeExcessiveCorrosion = (ItemStatus)Convert.ToByte(dataRow["disc1_pipeExcessiveCorrosion"]);
			m_pipeExcessiveLeaks = (ItemStatus)Convert.ToByte(dataRow["disc1_pipeExcessiveLeaks"]);
			m_pipePaintGood = (ItemStatus)Convert.ToByte(dataRow["disc1_pipePaintGood"]);

			m_dateInspected = Convert.ToDateTime(dataRow["disc1_dateInspected"]);
			m_inspectionYear = m_dateInspected;

			m_assessedBy = dataRow["disc1_assessedBy"] == DBNull.Value ? "" : dataRow["disc1_assessedBy"].ToString();
			m_equipmentNumber = dataRow["disc1_equipmentNumber"] == DBNull.Value ? "" : dataRow["disc1_equipmentNumber"].ToString();
			m_manufacturer = dataRow["disc1_manufacturer"] == DBNull.Value ? "" : dataRow["disc1_manufacturer"].ToString();
			m_runHours = dataRow["disc1_runHours"] == DBNull.Value ? "" : dataRow["disc1_runHours"].ToString();
			m_installationYear = dataRow["disc1_installationYear"] == DBNull.Value ? Convert.ToInt16(0) : Convert.ToInt16(dataRow["disc1_installationYear"]);
			m_photoCaption = dataRow["disc1_photoCaption"] == DBNull.Value ? "" : dataRow["disc1_photoCaption"].ToString();
			m_photoFileName = dataRow["PhotoFileName"] == DBNull.Value ? "" : dataRow["PhotoFileName"].ToString();

			m_comments = dataRow["disc1_comments"] == DBNull.Value ? "" : dataRow["disc1_comments"].ToString();
			m_runningAtInspect = dataRow["disc1_runningAtInspect"] == DBNull.Value ? false : Convert.ToBoolean(dataRow["disc1_runningAtInspect"]);
			m_overrideCurrentValue = dataRow["CurrentValue"] != DBNull.Value;
			m_currentValue = dataRow["CurrentValue"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["CurrentValue"]);
			m_replacementValueYear = dataRow["ReplacementValueYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["ReplacementValueYear"]);

			m_overrideRepairCost = dataRow["RepairCost"] != DBNull.Value;
			m_repairCost = dataRow["RepairCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RepairCost"]);
			m_rehabCost = dataRow["RehabCost"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RehabCost"]);
			m_rehabCostYear = dataRow["RehabCostYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabCostYear"]);
			m_rehabInterval = dataRow["RehabInterval"] == DBNull.Value ? 0 : Convert.ToDecimal(dataRow["RehabInterval"]);
			m_rehabYearLast = dataRow["RehabYearLast"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabYearLast"]);

			//if the planning mode is replacement, set the cache values to zero
			if (this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				m_rehabInterval = 0m;
				m_rehabNext = 0m;
			}

			m_overrideNextReplacementYear = dataRow["NextReplacementYear"] != DBNull.Value;
			m_nextReplacementYear = dataRow["NextReplacementYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["NextReplacementYear"]);

			try
			{
				m_replacementValueDesc = dataRow["ReplacementValueDesc"] == DBNull.Value ? "" : dataRow["ReplacementValueDesc"].ToString();
				m_rehabCostDesc = dataRow["RehabCostDesc"] == DBNull.Value ? "" : dataRow["RehabCostDesc"].ToString();
				m_overrideRehabYearNext = dataRow["RehabYearNext"] != DBNull.Value;
				m_rehabYearNext = dataRow["RehabYearNext"] == DBNull.Value ? 0 : Convert.ToInt32(dataRow["RehabYearNext"]);
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
			}
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/

		//mam - compare Disciplines by their various values
		public new int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)		
		{
			DisciplineMech rhs = obj as DisciplineMech;
			int result = 0;
			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a discipline");

			return result;
		}
		//</mam>

		//mam - compare Disciplines by their various values
		private int CompareToEach(DisciplineMech rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;
			
			switch (which)
			{
				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
				//mam

				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.AcquisitionCost.CompareTo(rhs.AcquisitionCost);
					else
						result = rhs.AcquisitionCost.CompareTo(this.AcquisitionCost);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.AcquisitionCostEscalated.CompareTo(rhs.AcquisitionCostEscalated);
					else
						result = rhs.AcquisitionCostEscalated.CompareTo(this.AcquisitionCostEscalated);

					break;

				//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.RehabCost.CompareTo(rhs.RehabCost);
					else
						result = rhs.RehabCost.CompareTo(this.RehabCost);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabInterval:
					if (lowToHigh)
						result = this.RehabInterval.CompareTo(rhs.RehabInterval);
					else
						result = rhs.RehabInterval.CompareTo(this.RehabInterval);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabNext:
					if (lowToHigh)
						result = this.RehabNext.CompareTo(rhs.RehabNext);
					else
						result = rhs.RehabNext.CompareTo(this.RehabNext);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearLast:
					if (lowToHigh)
						result = this.RehabYearLast.CompareTo(rhs.RehabYearLast);
					else
						result = rhs.RehabYearLast.CompareTo(this.RehabYearLast);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearNext:
					if (lowToHigh)
						result = this.RehabYearNext.CompareTo(rhs.RehabYearNext);
					else
						result = rhs.RehabYearNext.CompareTo(this.RehabYearNext);

					break;

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementNext:
					if (lowToHigh)
						result = this.ReplacementNext.CompareTo(rhs.ReplacementNext);
					else
						result = rhs.ReplacementNext.CompareTo(this.ReplacementNext);

					break;

				//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.NextReplacementYear:
					if (lowToHigh)
						result = this.NextReplacementYear.CompareTo(rhs.NextReplacementYear);
					else
						result = rhs.NextReplacementYear.CompareTo(this.NextReplacementYear);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.ReplacementValue.CompareTo(rhs.ReplacementValue);
					else
						result = rhs.ReplacementValue.CompareTo(this.ReplacementValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.SalvageValue.CompareTo(rhs.SalvageValue);
					else
						result = rhs.SalvageValue.CompareTo(this.SalvageValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					if (lowToHigh)
						result = this.GetEvaluatedValue().CompareTo(rhs.GetEvaluatedValue());
					else
						result = rhs.GetEvaluatedValue().CompareTo(this.GetEvaluatedValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					if (lowToHigh)
						result = this.GetRepairCost().CompareTo(rhs.GetRepairCost());
					else
						result = rhs.GetRepairCost().CompareTo(this.GetRepairCost());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.AnnualMaintCost.CompareTo(rhs.AnnualMaintCost);
					else
						result = rhs.AnnualMaintCost.CompareTo(this.AnnualMaintCost);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InstallYear:
					if (lowToHigh)
						result = this.InstallationYear.CompareTo(rhs.InstallationYear);
					else
						result = rhs.InstallationYear.CompareTo(this.InstallationYear);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InspectionYear:
					if (lowToHigh)
						result = this.DateInspected.CompareTo(rhs.DateInspected);
					else
						result = rhs.DateInspected.CompareTo(this.DateInspected);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
					if (lowToHigh)
						result = this.OrgUsefulLife.CompareTo(rhs.OrgUsefulLife);
					else
						result = rhs.OrgUsefulLife.CompareTo(this.OrgUsefulLife);
					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
					if (lowToHigh)
						result = this.GetRemainingUsefulLife().CompareTo(rhs.GetRemainingUsefulLife());
					else
						result = rhs.GetRemainingUsefulLife().CompareTo(this.GetRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
					if (lowToHigh)
						result = this.GetEvaluatedRemainingUsefulLife().CompareTo(rhs.GetEvaluatedRemainingUsefulLife());
					else
						result = rhs.GetEvaluatedRemainingUsefulLife().CompareTo(this.GetEvaluatedRemainingUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
					if (lowToHigh)
						result = this.GetEconomicUsefulLife().CompareTo(rhs.GetEconomicUsefulLife());
					else
						result = rhs.GetEconomicUsefulLife().CompareTo(this.GetEconomicUsefulLife());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					if (lowToHigh)
						result = this.ConditionRanking.CompareTo(rhs.ConditionRanking);
					else
						result = rhs.ConditionRanking.CompareTo(this.ConditionRanking);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
					if (lowToHigh)
						result = this.GetLevelOfService().CompareTo(rhs.GetLevelOfService());
					else
						result = rhs.GetLevelOfService().CompareTo(this.GetLevelOfService());

					break;

//					case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
//					case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
//						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
//
//				case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
//					if (lowToHigh)
//						result = this.GetAverageRisk().CompareTo(rhs.GetAverageRisk());
//					else
//						result = rhs.GetAverageRisk().CompareTo(this.GetAverageRisk());
//
//					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;

			}
			return result;
		}
		//</mam>
		#endregion /***** IComparable Members *****/

		#region /***** Nested Class DisciplineComparer *****/
		//mam
		public class DisciplineComparer : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				DisciplineMech l = (DisciplineMech) lhs;
				DisciplineMech r = (DisciplineMech) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}
			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class DisciplineComparer *****/

		#region /****** SQL Statements ******/

		//mam 102309
		//protected override string GetLoadSql(object id)
		protected override string GetLoadSql(object id)
		{
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//builder.Append("Facilities.infoset_id, " );
			builder.Append("MajorComponents.CipPlanningId, " );

			builder.Append("disc1_id, DisciplineMech.component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, ");
			builder.Append("disc1_acquisitionCost, disc1_replacementValue, ");
			builder.Append("disc1_salvageValue, disc1_annualMaintCost, ");
			builder.Append("disc1_originalENR, disc1_currentENR, ");
			builder.Append("disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc1_photoCaption, DisciplineMech.PhotoFileName, disc1_comments, disc1_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");
			//</mam>

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.Append(", RehabInterval");

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//builder.Append(", RehabNext");

			builder.Append(", RehabYearLast");
			//mam 07072011 end

			builder.Append(", NextReplacementYear");

			//mam 01222012
			builder.Append(", ReplacementValueDesc");
			builder.Append(", RehabCostDesc");
			builder.Append(", RehabYearNext");

			builder.Append(" FROM DisciplineMech");

			//mam 07072011 - need cip planning id in loadrecord, so must get it here
			builder.Append(" INNER JOIN MajorComponents ON DisciplineMech.component_id = MajorComponents.component_id");
			//builder.Append("INNER JOIN TreatmentProcesses ON MajorComponents.process_id = TreatmentProcesses.process_id ");
			//builder.Append("INNER JOIN Facilities ON TreatmentProcesses.facility_id = Facilities.facility_id ");

			builder.AppendFormat(" WHERE disc1_id={0}", id);

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
//		public override string GetInsertSqlForCopy()
//		{
//			return GetInsertSql();
//		}

		//mam 102309
//		public override string GetUpdateSqlForImport()
//		{
//			return GetUpdateSql();
//		}

		//mam 07072011 - new save routine only for saving disciplines that are currently being imported
		public bool SaveForImport()
		{
			forImport = true;
			return Save();
		}

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
		public override bool Save()
		{
			DataAccess dataAccess = new DataAccess();

			//mam 07072011
			bool success = true;

			try
			{
				bool flag = !this.Valid;
				if (flag)
				{
					this.m_id = dataAccess.ExecuteCommandReturnAutoID(this.GetInsertSql());
				}
				else
				{
					//mam 07072011 - add bool success
					success = dataAccess.ExecuteCommand(this.GetUpdateSql());
				}
				
				if (this.Valid)
				{
					Drive.Synchronization.SyncAction add;
					if (flag)
					{
						add = Drive.Synchronization.SyncAction.Add;
					}
					else
					{
						add = Drive.Synchronization.SyncAction.Edit;
					}

					//mam 01222012 - let's go back to using InvokeChangeEvent rather than manually adding the discipline to the cache
					//mam - add discipline to cache manually, below;
					InvokeChangeEvent(this, new DataChangeEventArgs(this, add));

					//the discipline is not getting added to the cache by calling InvokeChangeEvent - add it manually
					//if (add == Drive.Synchronization.SyncAction.Add)
					//{
					//	DisciplineCache disciplineCache = CacheManager.GetDisciplineCache(this.InfoSetID);
					//	disciplineCache.AddDisciplineToCache(this.ComponentID, this);
					//}
				}

				//mam 07072011
				if (!success)
				{
					return false;
				}

				return this.Valid;
			}
			catch(Exception ex)
			{
				//mam 07072011 - OK to just return false without throwing an error or setting up an error row 
				//	in an error grid because this should be handled by the caller
				System.Diagnostics.Trace.WriteLine(string.Format("{0}.Save Error: {1}\n", this.ToString(), ex.Message));
				string msg = "Error in " + this.Name + ".Save:  " + ex.Message;

				dataAccess.LogError("DisciplineMech.Save", "Code", "", ex.Message);

				//let's not throw an error because we could end up with many errors, which would result in either multiple message boxes, 
				//	or an unstable tree if we're copying or adding nodes to it
				//throw new Exception(msg);
				return false;
			}
			finally
			{
				dataAccess = null;

				//mam 07072011 - reset variable after saving
				forImport = false;
			}
		}

		//mam 102309
		//protected override string GetInsertSql()
		protected string GetInsertSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("INSERT INTO DisciplineMech (");

			builder.Append("component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, ");
			builder.Append("disc1_acquisitionCost, disc1_replacementValue, ");
			builder.Append("disc1_salvageValue, disc1_annualMaintCost, ");
			builder.Append("disc1_originalENR, disc1_currentENR, ");
			builder.Append("disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc1_photoCaption, PhotoFileName, disc1_comments, disc1_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");
			//</mam>

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.Append(", RehabInterval");

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//builder.Append(", RehabNext");

			builder.Append(", RehabYearLast");
			//mam 07072011 end

			//mam 07072011
			builder.Append(", NextReplacementYear");

			//mam01222012
			builder.Append(", ReplacementValueDesc");
			builder.Append(", RehabCostDesc");
			builder.Append(", RehabYearNext");

			builder.Append(") VALUES (");
			builder.AppendFormat("{0}, ", m_componentID);
			builder.AppendFormat("{0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("{0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("{0}, ", m_orgUsefulLife);

			if (m_overrideAcquisitionCost)
				builder.AppendFormat("{0:F2}, ", m_acquisitionCost);
			else
				builder.Append("NULL, ");

			builder.AppendFormat("{0:F2}, ", m_replacementValue);
			builder.AppendFormat("{0:F2}, ", m_salvageValue);
			builder.AppendFormat("{0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("{0}, ", m_originalENR);
			builder.AppendFormat("{0}, ", m_currentENR);

			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveVibration));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveNoise));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_mechExcessiveLeaks));
			builder.AppendFormat("{0}, ", ((byte)m_mechRunningHot));
			builder.AppendFormat("{0}, ", ((byte)m_mechCanRunWhenInspected));
			builder.AppendFormat("{0}, ", ((byte)m_mechSupportIsFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_mechPartsMissing));
			builder.AppendFormat("{0}, ", ((byte)m_mechPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_mechAdequate));
			builder.AppendFormat("{0}, ", ((byte)m_mechMotorAmps));
			builder.AppendFormat("{0}, ", ((byte)m_instrIndicationFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_instrAlarmFunctional));
			builder.AppendFormat("{0}, ", ((byte)m_instrPartsMissing));
			builder.AppendFormat("{0}, ", ((byte)m_instrPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_instrSpareCapacity));
			builder.AppendFormat("{0}, ", ((byte)m_elecExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_elecCleanContacts));
			builder.AppendFormat("{0}, ", ((byte)m_elecPartsAvailable));
			builder.AppendFormat("{0}, ", ((byte)m_elecSpareCapacity));
			builder.AppendFormat("{0}, ", ((byte)m_pipeExcessiveCorrosion));
			builder.AppendFormat("{0}, ", ((byte)m_pipeExcessiveLeaks));
			builder.AppendFormat("{0}, ", ((byte)m_pipePaintGood));
			builder.AppendFormat("'{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("'{0}', ", Drive.SQL.PadString(m_runHours));

			builder.AppendFormat("{0}, ", m_installationYear);
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoCaption));

			//mam 03202012
			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			//mam 102309
			//builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_photo));

			builder.AppendFormat("{0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("{0} ", Drive.SQL.BoolToBit(m_runningAtInspect));

			//mam
			if (m_overrideCurrentValue)
				builder.AppendFormat(", {0:F2} ", m_currentValue);
			else
				builder.Append(", NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", {0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", {0:F2} ", m_repairCost);
			else
				builder.Append(", NULL ");

			//mam 050806
			builder.AppendFormat(", {0:F2} ", m_rehabCost);

			//mam 07072011 begin
			builder.AppendFormat(", {0}", m_rehabCostYear);
			builder.AppendFormat(", {0:F1}", m_rehabInterval);

			//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
			//if (m_overrideRehabNext)
			//	builder.AppendFormat(", {0:F1}", m_rehabNext);
			//else
			//	builder.Append(", NULL");

			builder.AppendFormat(", {0}", m_rehabYearLast);
			//mam 07072011 end

			//mam 07072011
			if (m_overrideNextReplacementYear)
				builder.AppendFormat(", {0}", m_nextReplacementYear);
			else
				builder.Append(", NULL");

			//mam 01222012
			builder.AppendFormat(", '{0}'", Drive.SQL.PadString(m_replacementValueDesc));
			builder.AppendFormat(", '{0}'", Drive.SQL.PadString(m_rehabCostDesc));
			if (m_overrideRehabYearNext)
				builder.AppendFormat(", {0:F1}", m_rehabYearNext);
			else
				builder.Append(", NULL");

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.Append(")");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetUpdateSql()
		protected string GetUpdateSql()
		{
			StringBuilder	builder = new StringBuilder(250);

			builder.Append("UPDATE DisciplineMech SET ");

			builder.AppendFormat("component_id={0}, ", m_componentID);
			builder.AppendFormat("disc1_conditionRanking={0}, ", (byte)m_conditionRanking);
			builder.AppendFormat("disc1_CWPAssetValue={0:F6}, ", m_CWPAssetValue);
			builder.AppendFormat("disc1_originalUsefulLife={0}, ", m_orgUsefulLife);

			if (m_overrideAcquisitionCost)
				builder.AppendFormat("disc1_acquisitionCost={0:F2}, ", m_acquisitionCost);
			else
				builder.Append("disc1_acquisitionCost=NULL, ");

			builder.AppendFormat("disc1_replacementValue={0:F2}, ", m_replacementValue);
			builder.AppendFormat("disc1_salvageValue={0:F2}, ", m_salvageValue);
			builder.AppendFormat("disc1_annualMaintCost={0:F2}, ", m_annualMaintCost);
			builder.AppendFormat("disc1_originalENR={0}, ", m_originalENR);
			builder.AppendFormat("disc1_currentENR={0}, ", m_currentENR);

			builder.AppendFormat("disc1_mechExcessiveVibration={0}, ", ((byte)m_mechExcessiveVibration));
			builder.AppendFormat("disc1_mechExcessiveNoise={0}, ", ((byte)m_mechExcessiveNoise));
			builder.AppendFormat("disc1_mechExcessiveCorrosion={0}, ", ((byte)m_mechExcessiveCorrosion));
			builder.AppendFormat("disc1_mechExcessiveLeaks={0}, ", ((byte)m_mechExcessiveLeaks));
			builder.AppendFormat("disc1_mechRunningHot={0}, ", ((byte)m_mechRunningHot));
			builder.AppendFormat("disc1_mechCanRunWhenInspected={0}, ", ((byte)m_mechCanRunWhenInspected));
			builder.AppendFormat("disc1_mechSupportIsFunctional={0}, ", ((byte)m_mechSupportIsFunctional));
			builder.AppendFormat("disc1_mechPartsMissing={0}, ", ((byte)m_mechPartsMissing));
			builder.AppendFormat("disc1_mechPartsAvailable={0}, ", ((byte)m_mechPartsAvailable));
			builder.AppendFormat("disc1_mechAdequate={0}, ", ((byte)m_mechAdequate));
			builder.AppendFormat("disc1_mechMotorAmps={0}, ", ((byte)m_mechMotorAmps));
			builder.AppendFormat("disc1_instrIndicationFunctional={0}, ", ((byte)m_instrIndicationFunctional));
			builder.AppendFormat("disc1_instrAlarmFunctional={0}, ", ((byte)m_instrAlarmFunctional));
			builder.AppendFormat("disc1_instrPartsMissing={0}, ", ((byte)m_instrPartsMissing));
			builder.AppendFormat("disc1_instrPartsAvailable={0}, ", ((byte)m_instrPartsAvailable));
			builder.AppendFormat("disc1_instrSpareCapacity={0}, ", ((byte)m_instrSpareCapacity));
			builder.AppendFormat("disc1_elecExcessiveCorrosion={0}, ", ((byte)m_elecExcessiveCorrosion));
			builder.AppendFormat("disc1_elecCleanContacts={0}, ", ((byte)m_elecCleanContacts));
			builder.AppendFormat("disc1_elecPartsAvailable={0}, ", ((byte)m_elecPartsAvailable));
			builder.AppendFormat("disc1_elecSpareCapacity={0}, ", ((byte)m_elecSpareCapacity));
			builder.AppendFormat("disc1_pipeExcessiveCorrosion={0}, ", ((byte)m_pipeExcessiveCorrosion));
			builder.AppendFormat("disc1_pipeExcessiveLeaks={0}, ", ((byte)m_pipeExcessiveLeaks));
			builder.AppendFormat("disc1_pipePaintGood={0}, ", ((byte)m_pipePaintGood));
			builder.AppendFormat("disc1_dateInspected='{0}', ", Drive.SQL.DateToString(m_dateInspected, false));
			builder.AppendFormat("disc1_assessedBy='{0}', ", Drive.SQL.PadString(m_assessedBy));
			builder.AppendFormat("disc1_equipmentNumber='{0}', ", Drive.SQL.PadString(m_equipmentNumber));
			builder.AppendFormat("disc1_manufacturer='{0}', ", Drive.SQL.PadString(m_manufacturer));
			builder.AppendFormat("disc1_runHours='{0}', ", Drive.SQL.PadString(m_runHours));
			builder.AppendFormat("disc1_installationYear={0}, ", m_installationYear);
			builder.AppendFormat("disc1_photoCaption={0}, ", Drive.SQL.StringToDBString(m_photoCaption));

			//mam 03202012
			builder.AppendFormat("PhotoFileName={0}, ", Drive.SQL.StringToDBString(m_photoFileName));

			builder.AppendFormat("disc1_comments={0}, ", Drive.SQL.StringToDBString(m_comments));
			builder.AppendFormat("disc1_runningAtInspect={0} ", Drive.SQL.BoolToBit(m_runningAtInspect));

			//mam
			if (m_overrideCurrentValue)
				builder.AppendFormat(", CurrentValue={0:F2} ", m_currentValue);
			else
				builder.Append(", CurrentValue=NULL ");
			//</mam>

			//mam 050806
			builder.AppendFormat(", ReplacementValueYear={0} ", m_replacementValueYear);
			if (m_overrideRepairCost)
				builder.AppendFormat(", RepairCost={0:F2} ", m_repairCost);
			else
				builder.Append(", RepairCost=NULL ");

			//mam 01222012 - planning mode now affects next replacement year, so check the planning mode
			if (forImport || this.ComponentCipId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				//planning mode = replacement
			
				//mam 07072011
				if (m_overrideNextReplacementYear)
					builder.AppendFormat(", NextReplacementYear={0}", m_nextReplacementYear);
				else
					builder.Append(", NextReplacementYear=NULL ");
			}

			//mam 07072011 - add check of CipPlanningId
			//	if the rehab interval and rehab next are zero because cip mode is Replacement, don't save them to the database
			//	(they are read only when cip mode is Replacement)
			//	so that when the user changes the cip planning mode, rehab interval and rehab next can be resurrected
			//if CipPlanningId is anything other than the Replacement id, save rehab interval and rehab next to the database

			//mam 050806
			builder.AppendFormat(", RehabCost={0:F2} ", m_rehabCost);

			//mam 07072011
			builder.AppendFormat(", RehabCostYear={0} ", m_rehabCostYear);

			//mam 07072011 begin
			if (forImport || this.ComponentCipId != Common.CommonTasks.ZeroRehabCostCipPlanningId)
			{
				//planning mode = rehabilitation or we are saving a discipline that is currently being imported

				builder.AppendFormat(", RehabInterval={0:F1}", m_rehabInterval);

				//mam 01222012 - since override is no longer being used, Time to Next Rehab is no longer being stored in the database
				//if (m_overrideRehabNext)
				//	builder.AppendFormat(", RehabNext={0:F1}", m_rehabNext);
				//else
				//	builder.Append(", RehabNext=NULL");

				//mam 01222012
				if (m_overrideRehabYearNext)
					builder.AppendFormat(", RehabYearNext={0:F0}", m_rehabYearNext);
				else
					builder.Append(", RehabYearNext=NULL");
			}
			builder.AppendFormat(", RehabYearLast={0}", m_rehabYearLast);
			//mam 07072011 end

			//mam 01222012
			builder.AppendFormat(", ReplacementValueDesc='{0}'", Drive.SQL.PadString(m_replacementValueDesc));
			builder.AppendFormat(", RehabCostDesc='{0}'", Drive.SQL.PadString(m_rehabCostDesc));
			//if (m_overrideRehabYearNext)
			//	builder.AppendFormat(", RehabYearNext={0}", m_rehabYearNext);
			//else
			//	builder.Append(", RehabYearNext=NULL");

			//mam 07072011 - for testing only - cause an error
			//builder.Append(",");

			builder.AppendFormat(" WHERE (disc1_id={0})", ID);

			return builder.ToString();
		}

		//mam 102309
		//protected override string GetDeleteSql()
		protected override string GetDeleteSql()
		{
			return string.Format(
				"DELETE From DisciplineMech WHERE disc1_id={0}", ID);
		}
		#endregion /****** SQL Statements ******/

		#region /***** Properties *****/
		public override string Name
		{
			get { return "Mechanical / Electrical / Instrumentation / Piping"; }
		}

		public override DisciplineType Type
		{
			get { return DisciplineType.Mechanical; }
		}

		public ItemStatus	MechExcessiveVibration
		{
			get { return m_mechExcessiveVibration; }
			set { m_mechExcessiveVibration = value; }
		}

		public ItemStatus	MechExcessiveNoise
		{
			get { return m_mechExcessiveNoise; }
			set { m_mechExcessiveNoise = value; }
		}

		public ItemStatus	MechExcessiveCorrosion
		{
			get { return m_mechExcessiveCorrosion; }
			set { m_mechExcessiveCorrosion = value; }
		}

		public ItemStatus	MechExcessiveLeaks
		{
			get { return m_mechExcessiveLeaks; }
			set { m_mechExcessiveLeaks = value; }
		}

		public ItemStatus	MechRunningHot
		{
			get { return m_mechRunningHot; }
			set { m_mechRunningHot = value; }
		}

		public ItemStatus	MechCanRunWhenInspected
		{
			get { return m_mechCanRunWhenInspected; }
			set { m_mechCanRunWhenInspected = value; }
		}

		public ItemStatus	MechSupportIsFunctional
		{
			get { return m_mechSupportIsFunctional; }
			set { m_mechSupportIsFunctional = value; }
		}

		public ItemStatus	MechPartsMissing
		{
			get { return m_mechPartsMissing; }
			set { m_mechPartsMissing = value; }
		}

		public ItemStatus	MechPartsAvailable
		{
			get { return m_mechPartsAvailable; }
			set { m_mechPartsAvailable = value; }
		}

		public ItemStatus	MechAdequate
		{
			get { return m_mechAdequate; }
			set { m_mechAdequate = value; }
		}

		public ItemStatus	MechMotorAmps
		{
			get { return m_mechMotorAmps; }
			set { m_mechMotorAmps = value; }
		}

		public ItemStatus	InstrIndicationFunctional
		{
			get { return m_instrIndicationFunctional; }
			set { m_instrIndicationFunctional = value; }
		}

		public ItemStatus	InstrAlarmFunctional
		{
			get { return m_instrAlarmFunctional; }
			set { m_instrAlarmFunctional = value; }
		}

		public ItemStatus	InstrPartsMissing
		{
			get { return m_instrPartsMissing; }
			set { m_instrPartsMissing = value; }
		}

		public ItemStatus	InstrPartsAvailable
		{
			get { return m_instrPartsAvailable; }
			set { m_instrPartsAvailable = value; }
		}

		public ItemStatus	InstrSpareCapacity
		{
			get { return m_instrSpareCapacity; }
			set { m_instrSpareCapacity = value; }
		}

		public ItemStatus	ElecExcessiveCorrosion
		{
			get { return m_elecExcessiveCorrosion; }
			set { m_elecExcessiveCorrosion = value; }
		}

		public ItemStatus	ElecCleanContacts
		{
			get { return m_elecCleanContacts; }
			set { m_elecCleanContacts = value; }
		}

		public ItemStatus	ElecPartsAvailable
		{
			get { return m_elecPartsAvailable; }
			set { m_elecPartsAvailable = value; }
		}

		public ItemStatus	ElecSpareCapacity
		{
			get { return m_elecSpareCapacity; }
			set { m_elecSpareCapacity = value; }
		}

		public ItemStatus	PipeExcessiveCorrosion
		{
			get { return m_pipeExcessiveCorrosion; }
			set { m_pipeExcessiveCorrosion = value; }
		}

		public ItemStatus	PipeExcessiveLeaks
		{
			get { return m_pipeExcessiveLeaks; }
			set { m_pipeExcessiveLeaks = value; }
		}

		public ItemStatus	PipePaintGood
		{
			get { return m_pipePaintGood; }
			set { m_pipePaintGood = value; }
		}

		public DateTime		DateInspected
		{
			get { return m_dateInspected; }
			set 
			{ 
				m_dateInspected = value; 

				//mam
				//m_inspectionYear = m_dateInspected.Year;
				m_inspectionYear = m_dateInspected;
				//</mam>
			}
		}

		public string		EquipmentNumber
		{
			get { return m_equipmentNumber; }
			set
			{
				if (value.Length > 255)
					m_equipmentNumber = value.Substring(255);
				else
					m_equipmentNumber = value;
			}
		}

		public string		AssessedBy
		{
			get { return m_assessedBy; }
			set
			{
				if (value.Length > 255)
					m_assessedBy = value.Substring(255);
				else
					m_assessedBy = value;
			}
		}

		public string		Manufacturer
		{
			get { return m_manufacturer; }
			set
			{
				if (value.Length > 255)
					m_manufacturer = value.Substring(255);
				else
					m_manufacturer = value;
			}
		}

		public string		RunHours
		{
			get { return m_runHours; }
			set
			{
				if (value.Length > 255)
					m_runHours = value.Substring(255);
				else
					m_runHours = value;
			}
		}

		public string		CaptionPhoto
		{
			get { return m_photoCaption; }
			set
			{
				if (value.Length > 255)
					m_photoCaption = value.Substring(255);
				else
					m_photoCaption = value;
			}
		}

		//mam 03202012
		public string PhotoFileName
		{
			get { return m_photoFileName; }
			set { m_photoFileName = value; }
		}

		//mam 102309
//		public override string Photo
//		{
//			get { return m_photo; }
//			set
//			{
//				if (value.Length > 255)
//					m_photo = value.Substring(255);
//				else
//					m_photo = value;
//			}
//		}

		public string		Comments
		{
			get { return m_comments; }
			set
			{
				if (value.Length > Int16.MaxValue)
					m_comments = value.Substring(Int16.MaxValue);
				else
					m_comments = value;
			}
		}

		public bool			RunningAtInspect
		{
			get { return m_runningAtInspect; }
			set { m_runningAtInspect = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Methods *****/

		//mam
		public static DisciplineComparer GetComparer()
		{
			return new DisciplineComparer();
		}
		//</mam>

		//mam - added parameter
		public override string GetXML(bool includePhotos, string selectedFilters)
		{
			// This method is a great way to see how it all fits together
			StringBuilder	builder = new StringBuilder();
			MajorComponent component = GetMajorComponent();
			TreatmentProcess process = CacheManager.GetTreatmentProcess(InfoSetID, component.ProcessID);
			Facility		facility = CacheManager.GetFacility(InfoSetID, process.FacilityID);

			builder.Append("<DisciplineMechanicalData>\r\n");

			// Populate the basic data
			builder.Append("\t<DisciplineMechanical>\r\n");
			builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
			builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", process.Name);
			builder.AppendFormat("\t\t<ComponentName><![CDATA[{0}]]></ComponentName>\r\n", component.Name);
			builder.AppendFormat("\t\t<Discipline><![CDATA[{0}]]></Discipline>\r\n", Name);
			builder.AppendFormat("\t\t<CurrentYear>{0}</CurrentYear>\r\n", facility.CurrentYear);
			builder.AppendFormat("\t\t<CurrentENR>{0}</CurrentENR>\r\n", facility.CurrentENR);

			//mam
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			//</mam>

			//mam 112806
			builder.AppendFormat("\t\t<Retired><![CDATA[{0}]]></Retired>\r\n", component.Retired);

			//mam
			if (includePhotos)
			{
			//</mam>
				//mam 03202012 - changed GetImagePath to PhotoFileName (don't include path in photo file name because it is a 
				//	mapped path on the user's machine that will be different for all users)
				//builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePath());
				builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", PhotoFileName);

				builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto);
			}

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", 0);
				builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 0);
			}
			else
			{
				//mam
				builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", Convert.ToInt32(m_overrideAcquisitionCost));
				builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", Convert.ToInt32(m_overrideCurrentValue));
				//</mam>
			}

			builder.AppendFormat("\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", 0);	//999999
			}
			else
			{
				builder.AppendFormat("\t\t<AcquisitionCost><![CDATA[{0:F0}]]></AcquisitionCost>\r\n", AcquisitionCost);
				builder.AppendFormat("\t\t<ReplacementValue><![CDATA[{0:F0}]]></ReplacementValue>\r\n", ReplacementValue);
			}

			//mam 01222012
			builder.AppendFormat("\t\t<ReplacementValueDesc><![CDATA[{0}]]></ReplacementValueDesc>\r\n", ReplacementValueDesc);

			builder.AppendFormat("\t\t<SalvageValue><![CDATA[{0:F0}]]></SalvageValue>\r\n", SalvageValue);
			builder.AppendFormat("\t\t<AnnualMaintenanceCost><![CDATA[{0:F0}]]></AnnualMaintenanceCost>\r\n", AnnualMaintCost);
			builder.AppendFormat("\t\t<InstallYear><![CDATA[{0:F0}]]></InstallYear>\r\n", InstallationYear);
			builder.AppendFormat("\t\t<OriginalENR><![CDATA[{0:F0}]]></OriginalENR>\r\n", OriginalENR);
			builder.AppendFormat("\t\t<OrgUsefulLife><![CDATA[{0:F1}]]></OrgUsefulLife>\r\n", OrgUsefulLife);
			builder.AppendFormat("\t\t<LevelOfService><![CDATA[{0}]]></LevelOfService>\r\n", EnumHandlers.GetLOSShort(component.LOS));
			builder.AppendFormat("\t\t<Condition><![CDATA[{0}]]></Condition>\r\n", EnumHandlers.GetConditionRankShort(ConditionRanking));
			builder.AppendFormat("\t\t<DateOfInspection><![CDATA[{0}]]></DateOfInspection>\r\n", DateInspected.ToString("MM/dd/yyyy"));

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", 0);	//999999
			}
			else
			{
				builder.AppendFormat("\t\t<BookValue><![CDATA[{0:F0}]]></BookValue>\r\n", GetBookValue());
				builder.AppendFormat("\t\t<AnnualDepreciation><![CDATA[{0:F0}]]></AnnualDepreciation>\r\n", GetAnnualDepreciation());
				builder.AppendFormat("\t\t<CumulativeDepreciation><![CDATA[{0:F0}]]></CumulativeDepreciation>\r\n", GetCumulativeDepreciation());
			}

			builder.AppendFormat("\t\t<RemainingUsefulLife><![CDATA[{0:F1}]]></RemainingUsefulLife>\r\n", GetRemainingUsefulLife());

			//mam 112806 - check condition and overrides
			if (ConditionRanking == CondRank.No)
			{
				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", 0.ToString("$#,##0"));	//999999
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", 0);	//999999
				}
				else
				{
					if (OverrideCurrentValue)
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", GetCurrentValue().ToString("$#,##0"));
					}
					else
					{
						builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", "N/A");
					}

					if (OverrideRepairCost)
					{
						//mam 07072011
						//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost().ToString("$#,##0"));
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost());
					}
					else
					{
						builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", "N/A");
					}

					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", 0.ToString("$#,##0"));	//999999
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t<CurrentValue><![CDATA[{0:F0}]]></CurrentValue>\r\n", GetCurrentValue().ToString("$#,##0"));

					//mam 07072011
					//builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost().ToString("$#,##0"));
					//builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", GetEvaluatedValue().ToString("$#,##0"));
					builder.AppendFormat("\t\t<RepairCost><![CDATA[{0:F0}]]></RepairCost>\r\n", GetRepairCost());
					builder.AppendFormat("\t\t<EvaluatedValue><![CDATA[{0:F0}]]></EvaluatedValue>\r\n", GetEvaluatedValue());
				}
			
				builder.AppendFormat("\t\t<EvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></EvaluatedRemainingUsefulLife>\r\n", GetEvaluatedRemainingUsefulLife());
				builder.AppendFormat("\t\t<EconomicUsefulLife><![CDATA[{0:F1}]]></EconomicUsefulLife>\r\n", GetEconomicUsefulLife());
			}

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", 0);	//999999
				builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", 0);	//999999
			}
			else
			{
				//mam 050806
				builder.AppendFormat("\t\t<AcquisitionCostEscalated><![CDATA[{0:F0}]]></AcquisitionCostEscalated>\r\n", AcquisitionCostEscalated);
				builder.AppendFormat("\t\t<RehabCost><![CDATA[{0:F0}]]></RehabCost>\r\n", RehabCost);
			}

			//mam 01222012
			builder.AppendFormat("\t\t<RehabCostDesc><![CDATA[{0}]]></RehabCostDesc>\r\n", RehabCostDesc);

			//mam 07072011 - new rehab values
			builder.AppendFormat("\t\t<RehabCostYear><![CDATA[{0:F0}]]></RehabCostYear>\r\n", RehabCostYear);
			builder.AppendFormat("\t\t<RehabInterval><![CDATA[{0:F1}]]></RehabInterval>\r\n", RehabInterval);
			builder.AppendFormat("\t\t<RehabYearLast><![CDATA[{0:F0}]]></RehabYearLast>\r\n", RehabYearLast);
			builder.AppendFormat("\t\t<RehabNext><![CDATA[{0:F1}]]></RehabNext>\r\n", RehabNext);
			builder.AppendFormat("\t\t<RehabYearNext><![CDATA[{0:F0}]]></RehabYearNext>\r\n", RehabYearNext);

			//mam 01222012 - no longer using override for Time to Next Rehab
			//builder.AppendFormat("\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", Convert.ToInt32(m_overrideRehabNext));

			//mam 01222012
			builder.AppendFormat("\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", Convert.ToInt32(m_overrideRehabYearNext));

			builder.AppendFormat("\t\t<ReplacementValueYear><![CDATA[{0:F0}]]></ReplacementValueYear>\r\n", ReplacementValueYear);
			builder.AppendFormat("\t\t<ReplacementValueYearENR><![CDATA[{0:F0}]]></ReplacementValueYearENR>\r\n", ReplacementENR);

			//mam 01222012
			builder.AppendFormat("\t\t<ReplacementNext><![CDATA[{0:F1}]]></ReplacementNext>\r\n", ReplacementNext);

			//mam 07072011
			builder.AppendFormat("\t\t<NextReplacementYear><![CDATA[{0:F0}]]></NextReplacementYear>\r\n", NextReplacementYear);
			builder.AppendFormat("\t\t<OverrideNextReplacementYear><![CDATA[{0}]]></OverrideNextReplacementYear>\r\n", Convert.ToInt32(m_overrideNextReplacementYear));

			//mam 01042012 - if component is retired, show zero on report
			if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
			{
				builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 0);
			}
			else
			{
				builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", Convert.ToInt32(m_overrideRepairCost));
			}

			builder.AppendFormat("\t\t<AssessedBy><![CDATA[{0}]]></AssessedBy>\r\n", AssessedBy);
			builder.AppendFormat("\t\t<EquipmentNum><![CDATA[{0}]]></EquipmentNum>\r\n", EquipmentNumber);
			builder.AppendFormat("\t\t<Manufacturer><![CDATA[{0}]]></Manufacturer>\r\n", Manufacturer);
			builder.AppendFormat("\t\t<RunHours><![CDATA[{0}]]></RunHours>\r\n", RunHours);
			builder.AppendFormat("\t\t<RunningAtInspection><![CDATA[{0}]]></RunningAtInspection>\r\n", RunningAtInspect);
			builder.AppendFormat("\t\t<MechExcessiveVibration><![CDATA[{0}]]></MechExcessiveVibration>\r\n", EnumHandlers.GetItemStatusShort(m_mechExcessiveVibration));
			builder.AppendFormat("\t\t<MechExcessiveNoise><![CDATA[{0}]]></MechExcessiveNoise>\r\n", EnumHandlers.GetItemStatusShort(m_mechExcessiveNoise));
			builder.AppendFormat("\t\t<MechExcessiveCorrosion><![CDATA[{0}]]></MechExcessiveCorrosion>\r\n", EnumHandlers.GetItemStatusShort(m_mechExcessiveCorrosion));
			builder.AppendFormat("\t\t<MechExcessiveLeaks><![CDATA[{0}]]></MechExcessiveLeaks>\r\n", EnumHandlers.GetItemStatusShort(m_mechExcessiveLeaks));
			builder.AppendFormat("\t\t<MechRunningHot><![CDATA[{0}]]></MechRunningHot>\r\n", EnumHandlers.GetItemStatusShort(m_mechRunningHot));
			builder.AppendFormat("\t\t<MechCanRunWhenInspected><![CDATA[{0}]]></MechCanRunWhenInspected>\r\n", EnumHandlers.GetItemStatusShort(m_mechCanRunWhenInspected));
			builder.AppendFormat("\t\t<MechSupportIsFunctional><![CDATA[{0}]]></MechSupportIsFunctional>\r\n", EnumHandlers.GetItemStatusShort(m_mechSupportIsFunctional));
			builder.AppendFormat("\t\t<MechPartsMissing><![CDATA[{0}]]></MechPartsMissing>\r\n", EnumHandlers.GetItemStatusShort(m_mechPartsMissing));
			builder.AppendFormat("\t\t<MechPartsAvailable><![CDATA[{0}]]></MechPartsAvailable>\r\n", EnumHandlers.GetItemStatusShort(m_mechPartsAvailable));
			builder.AppendFormat("\t\t<MechAdequate><![CDATA[{0}]]></MechAdequate>\r\n", 
				EnumHandlers.GetItemStatusShort(m_mechAdequate));
			builder.AppendFormat("\t\t<MechMotorAmps><![CDATA[{0}]]></MechMotorAmps>\r\n", 
				EnumHandlers.GetItemStatusShort(m_mechMotorAmps));
			builder.AppendFormat("\t\t<InstrIndicationFunctional><![CDATA[{0}]]></InstrIndicationFunctional>\r\n", 
				EnumHandlers.GetItemStatusShort(m_instrIndicationFunctional));
			builder.AppendFormat("\t\t<InstrAlarmFunctional><![CDATA[{0}]]></InstrAlarmFunctional>\r\n", 
				EnumHandlers.GetItemStatusShort(m_instrAlarmFunctional));
			builder.AppendFormat("\t\t<InstrPartsMissing><![CDATA[{0}]]></InstrPartsMissing>\r\n", 
				EnumHandlers.GetItemStatusShort(m_instrPartsMissing));
			builder.AppendFormat("\t\t<InstrPartsAvailable><![CDATA[{0}]]></InstrPartsAvailable>\r\n", 
				EnumHandlers.GetItemStatusShort(m_instrPartsAvailable));
			builder.AppendFormat("\t\t<InstrSpareCapacity><![CDATA[{0}]]></InstrSpareCapacity>\r\n", 
				EnumHandlers.GetItemStatusShort(m_instrSpareCapacity));
			builder.AppendFormat("\t\t<ElecExcessiveCorrosion><![CDATA[{0}]]></ElecExcessiveCorrosion>\r\n", 
				EnumHandlers.GetItemStatusShort(m_elecExcessiveCorrosion));
			builder.AppendFormat("\t\t<ElecCleanContacts><![CDATA[{0}]]></ElecCleanContacts>\r\n", 
				EnumHandlers.GetItemStatusShort(m_elecCleanContacts));
			builder.AppendFormat("\t\t<ElecPartsAvailable><![CDATA[{0}]]></ElecPartsAvailable>\r\n", 
				EnumHandlers.GetItemStatusShort(m_elecPartsAvailable));
			builder.AppendFormat("\t\t<ElecSpareCapacity><![CDATA[{0}]]></ElecSpareCapacity>\r\n", 
				EnumHandlers.GetItemStatusShort(m_elecSpareCapacity));
			builder.AppendFormat("\t\t<PipeExcessiveCorrosion><![CDATA[{0}]]></PipeExcessiveCorrosion>\r\n", 
				EnumHandlers.GetItemStatusShort(m_pipeExcessiveCorrosion));
			builder.AppendFormat("\t\t<PipeExcessiveLeaks><![CDATA[{0}]]></PipeExcessiveLeaks>\r\n", 
				EnumHandlers.GetItemStatusShort(m_pipeExcessiveLeaks));
			builder.AppendFormat("\t\t<PipePaintGood><![CDATA[{0}]]></PipePaintGood>\r\n", 
				EnumHandlers.GetItemStatusShort(m_pipePaintGood));
			builder.Append("\t</DisciplineMechanical>\r\n");
			builder.Append("</DisciplineMechanicalData>\r\n");

			//System.Diagnostics.Debug.WriteLine(builder);

			return builder.ToString();
		}

		public override void CopyTo(Discipline copyBase)
		{
			base.CopyTo(copyBase);

			DisciplineMech copy = (DisciplineMech)copyBase;

			copy.m_mechExcessiveVibration = m_mechExcessiveVibration;
			copy.m_mechExcessiveNoise = m_mechExcessiveNoise;
			copy.m_mechExcessiveCorrosion = m_mechExcessiveCorrosion;
			copy.m_mechExcessiveLeaks = m_mechExcessiveLeaks;
			copy.m_mechRunningHot = m_mechRunningHot;
			copy.m_mechCanRunWhenInspected = m_mechCanRunWhenInspected;
			copy.m_mechSupportIsFunctional = m_mechSupportIsFunctional;
			copy.m_mechPartsMissing = m_mechPartsMissing;
			copy.m_mechPartsAvailable = m_mechPartsAvailable;
			copy.m_mechAdequate = m_mechAdequate;
			copy.m_mechMotorAmps = m_mechMotorAmps;
			copy.m_instrIndicationFunctional = m_instrIndicationFunctional;
			copy.m_instrAlarmFunctional = m_instrAlarmFunctional;
			copy.m_instrPartsMissing = m_instrPartsMissing;
			copy.m_instrPartsAvailable = m_instrPartsAvailable;
			copy.m_instrSpareCapacity = m_instrSpareCapacity;
			copy.m_elecExcessiveCorrosion = m_elecExcessiveCorrosion;
			copy.m_elecCleanContacts = m_elecCleanContacts;
			copy.m_elecPartsAvailable = m_elecPartsAvailable;
			copy.m_elecSpareCapacity = m_elecSpareCapacity;
			copy.m_pipeExcessiveCorrosion = m_pipeExcessiveCorrosion;
			copy.m_pipeExcessiveLeaks = m_pipeExcessiveLeaks;
			copy.m_pipePaintGood = m_pipePaintGood;

			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;
			copy.m_equipmentNumber = m_equipmentNumber;
			copy.m_manufacturer = m_manufacturer;
			copy.m_runHours = m_runHours;
			copy.m_photoCaption = m_photoCaption;

			//mam 03202012
			copy.m_photoFileName = m_photoFileName;

			//mam 102309
			//copy.m_photo = m_photo;

			copy.m_comments = m_comments;
			copy.m_runningAtInspect = m_runningAtInspect;
		}

		//mam - allow or disallow copying of photo
		public override void CopyTo(Discipline copyBase, bool copyPhoto, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			base.CopyTo(copyBase);

			DisciplineMech copy = (DisciplineMech)copyBase;

			//mam 07072011
			//check component planning mode, and get rehab int and rehab next from database if planning mode = replacement

			//mam 01222012
			DataAccess dataAccess = new DataAccess();

			try
			{
				if (IsComponentZeroRehab)
				{
					//mam 01222012
					//DataAccess dataAccess = new DataAccess();
					//try
					//{
					StringBuilder builder = new StringBuilder();

					//mam 01222012
					//builder.AppendFormat("SELECT RehabInterval, RehabNext FROM DisciplineMech WHERE disc1_id = {0}", this.ID);
					builder.AppendFormat("SELECT RehabInterval, RehabYearNext FROM DisciplineMech WHERE disc1_id = {0}", this.ID);

					DataTable dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
					copy.m_rehabInterval = dataTable.Rows[0]["RehabInterval"] == DBNull.Value ? 0m : Convert.ToDecimal(dataTable.Rows[0]["RehabInterval"]);

					//mam 01222012 - no longer overriding rehabNext, so it is no longer stored in the database
					//copy.m_rehabNext = dataTable.Rows[0]["RehabNext"] == DBNull.Value ? 0m : Convert.ToDecimal(dataTable.Rows[0]["RehabNext"]);

					//mam 01222012
					copy.m_rehabYearNext = dataTable.Rows[0]["RehabYearNext"] == DBNull.Value ? 0 : Convert.ToInt32(dataTable.Rows[0]["RehabYearNext"]);
					//}

					//mam 01222012
					//catch(Exception ex)
					//{
					//	Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, ex.Message);
					//}
					//finally
					//{
					//	dataAccess = null;
					//}
				}
				else
				{
					//mam 01222012
					StringBuilder builder = new StringBuilder();
					builder.AppendFormat("SELECT NextReplacementYear FROM DisciplineMech WHERE disc1_id = {0}", this.ID);
					DataTable dataTable = dataAccess.GetDisconnectedDataTable(builder.ToString());
					copy.m_nextReplacementYear = dataTable.Rows[0]["NextReplacementYear"] == DBNull.Value ? 0 : Convert.ToInt32(dataTable.Rows[0]["NextReplacementYear"]);
				}
			}
			//mam 01222012
			catch(Exception ex)
			{
				Common.CommonTasks.PopulateErrorGridRow(ref gridErrors, ex.Message);
			}
			finally
			{
				dataAccess = null;
			}

			copy.m_mechExcessiveVibration = m_mechExcessiveVibration;
			copy.m_mechExcessiveNoise = m_mechExcessiveNoise;
			copy.m_mechExcessiveCorrosion = m_mechExcessiveCorrosion;
			copy.m_mechExcessiveLeaks = m_mechExcessiveLeaks;
			copy.m_mechRunningHot = m_mechRunningHot;
			copy.m_mechCanRunWhenInspected = m_mechCanRunWhenInspected;
			copy.m_mechSupportIsFunctional = m_mechSupportIsFunctional;
			copy.m_mechPartsMissing = m_mechPartsMissing;
			copy.m_mechPartsAvailable = m_mechPartsAvailable;
			copy.m_mechAdequate = m_mechAdequate;
			copy.m_mechMotorAmps = m_mechMotorAmps;
			copy.m_instrIndicationFunctional = m_instrIndicationFunctional;
			copy.m_instrAlarmFunctional = m_instrAlarmFunctional;
			copy.m_instrPartsMissing = m_instrPartsMissing;
			copy.m_instrPartsAvailable = m_instrPartsAvailable;
			copy.m_instrSpareCapacity = m_instrSpareCapacity;
			copy.m_elecExcessiveCorrosion = m_elecExcessiveCorrosion;
			copy.m_elecCleanContacts = m_elecCleanContacts;
			copy.m_elecPartsAvailable = m_elecPartsAvailable;
			copy.m_elecSpareCapacity = m_elecSpareCapacity;
			copy.m_pipeExcessiveCorrosion = m_pipeExcessiveCorrosion;
			copy.m_pipeExcessiveLeaks = m_pipeExcessiveLeaks;
			copy.m_pipePaintGood = m_pipePaintGood;

			copy.m_dateInspected = m_dateInspected;
			copy.m_assessedBy = m_assessedBy;
			copy.m_equipmentNumber = m_equipmentNumber;
			copy.m_manufacturer = m_manufacturer;
			copy.m_runHours = m_runHours;

			if (copyPhoto)
			{
				copy.m_photoCaption = m_photoCaption;

				//mam 03202012
				copy.m_photoFileName = m_photoFileName;

				//mam 102309
				//copy.m_photo = m_photo;
			}

			copy.m_comments = m_comments;
			copy.m_runningAtInspect = m_runningAtInspect;
		}
		//</mam>

		#endregion /***** Methods *****/

		#region /***** Static Methods OleDb *****/

		//mam 102309
		public static DisciplineMech LoadForComponentOleDb(int componentID)
		{
			return LoadForComponentOleDb(WamSourceOleDb.CurrentSource.ConnectionString, componentID);
		}

		//mam 102309
		public static DisciplineMech LoadForComponentOleDb(string connectionString, int componentID)
		{
			OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			DisciplineMech retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponentOleDb(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		public static DisciplineMech LoadForComponentOleDb(OleDbConnection sqlConnection, int componentID)
		//public static DisciplineMech LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			OleDbDataReader	dataReader = null;
			OleDbCommand	dataCommand = null;
			//SqlDataReader dataReader = null;
			//SqlCommand dataCommand = null;

			DisciplineMech		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");
			builder.Append("disc1_id, component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, ");
			builder.Append("disc1_acquisitionCost, disc1_replacementValue, ");
			builder.Append("disc1_salvageValue, disc1_annualMaintCost, ");
			builder.Append("disc1_originalENR, disc1_currentENR, ");
			builder.Append("disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");
			builder.Append("disc1_photoCaption, disc1_comments, disc1_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost ");
			builder.Append(", RehabCost ");

			//mam 07072011 - no need for additional rehab values here because we are not updating the Access database to include them

			builder.Append("FROM DisciplineMech ");
			builder.AppendFormat("WHERE (component_id={0}) ", componentID);

			try
			{
				dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				//dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
				{
					//mam 102309
					//newObject = new DisciplineMech(sqlConnection, dataReader);
					newObject = new DisciplineMech(0);
					newObject.LoadRecordData(dataReader);
				}
			}
			catch (OleDbException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplineMech.LoadForComponent Error: {0}\n", ex.Message));
				System.Diagnostics.Debug.Assert(false, ex.Message);
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				//mam 102309
				//newObject = new DisciplineMech(sqlConnection, 0);
				newObject = new DisciplineMech(0);

				newObject.ComponentID = componentID;

				//mam - can't get current year through newObject when importing
				if (!MainForm.currentlyImporting)
					//</mam>
				{
					newObject.InstallationYear = newObject.GetFacility().CurrentYear;
				}

				//mam 112806 - changed to zero
				//mam 050806
				//newObject.m_replacementValueYear = DateTime.Now.Year;
				newObject.m_replacementValueYear = 0;
			}
			
			return newObject;
		}

		#endregion /***** Static Methods OleDb *****/

		#region /***** Static Methods *****/

		public static DisciplineMech LoadForComponent(int componentID)
		{
			//mam 102309
			//return LoadForComponent(WAMSource.CurrentSource.ConnectionString, componentID);
			return LoadForComponent(Globals.WamSqlConnectionString, componentID);
		}

		public static DisciplineMech LoadForComponent(string connectionString, int componentID)
		{
			//mam 102309
			//OleDbConnection sqlConnection = new OleDbConnection(connectionString);
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			DisciplineMech retVal = null;

			try
			{
				sqlConnection.Open();
				retVal = LoadForComponent(sqlConnection, componentID);
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}

			return retVal;
		}

		//mam 102309
		//public static DisciplineMech LoadForComponent(OleDbConnection sqlConnection, int componentID)
		public static DisciplineMech LoadForComponent(SqlConnection sqlConnection, int componentID)
		{
			// open the database to retrieve info

			//mam 102309
			//OleDbDataReader	dataReader = null;
			//OleDbCommand	dataCommand = null;
			SqlDataReader dataReader = null;
			SqlCommand dataCommand = null;

			DisciplineMech		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			builder.Append("SELECT ");

			//mam 07072011 - get infoset_id
			//	no - get component cip id
			//builder.Append("Facilities.infoset_id, " );
			builder.Append("MajorComponents.CipPlanningId, " );

			builder.Append("disc1_id, DisciplineMech.component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			builder.Append("disc1_originalUsefulLife, ");
			builder.Append("disc1_acquisitionCost, disc1_replacementValue, ");
			builder.Append("disc1_salvageValue, disc1_annualMaintCost, ");
			builder.Append("disc1_originalENR, disc1_currentENR, ");
			builder.Append("disc1_mechExcessiveVibration, ");
			builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");

			//mam 03202012 - added PhotoFileName
			builder.Append("disc1_photoCaption, DisciplineMech.PhotoFileName, disc1_comments, disc1_runningAtInspect ");

			//mam
			builder.Append(", CurrentValue ");
			//</mam>

			//mam 050806
			builder.Append(", ReplacementValueYear ");
			builder.Append(", RepairCost");
			builder.Append(", RehabCost");

			//mam 07072011 begin
			builder.Append(", RehabCostYear");
			builder.AppendFormat(", RehabInterval");

			//mam 01222012 - no longer using override for Time to Next Rehab, so RehabNext will always be calcuated and never stored in the database
			//builder.AppendFormat(", RehabNext");

			builder.AppendFormat(", RehabYearLast");
			//mam 07072011 end

			//mam 07072011
			builder.AppendFormat(", NextReplacementYear");

			//mam 01222012
			builder.AppendFormat(", ReplacementValueDesc");
			builder.AppendFormat(", RehabCostDesc");
			builder.AppendFormat(", RehabYearNext");

			builder.Append(" FROM DisciplineMech");

			//mam 07072011 - need cip planning id in loadrecord, so must get it here
			builder.Append(" INNER JOIN MajorComponents ON DisciplineMech.component_id = MajorComponents.component_id");
			//builder.Append("INNER JOIN TreatmentProcesses ON MajorComponents.process_id = TreatmentProcesses.process_id ");
			//builder.Append("INNER JOIN Facilities ON TreatmentProcesses.facility_id = Facilities.facility_id ");

			builder.AppendFormat(" WHERE (DisciplineMech.component_id={0}) ", componentID);

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				//mam 102309
				//dataCommand = new OleDbCommand(builder.ToString(), sqlConnection);
				dataCommand = new SqlCommand(builder.ToString(), sqlConnection);

				dataReader = dataCommand.ExecuteReader();

				if (dataReader.Read())
					newObject = new DisciplineMech(sqlConnection, dataReader);
			}
			//mam 102309
			//catch (OleDbException ex)
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(
					String.Format("DisciplineMech.LoadForComponent Error: {0}\n", ex.Message));
				//System.Diagnostics.Debug.Assert(false, ex.Message);
				throw ex;
			}
			finally
			{
				if (dataReader != null && !dataReader.IsClosed)
					dataReader.Close();
			}

			if (newObject == null)
			{
				newObject = new DisciplineMech(sqlConnection, 0);
				newObject.ComponentID = componentID;

				//mam - can't get current year through newObject when importing
				if (!MainForm.currentlyImporting)
				//</mam>
				{
					//mam 03202012
					short facilityYear = newObject.GetFacility().CurrentYear;

					//mam 03202012
					//newObject.InstallationYear = newObject.GetFacility().CurrentYear;
					newObject.InstallationYear = facilityYear;

					//mam 03202012
					//if newObject is null, that means that the discipline is not in the database
					//the installation year will default to the current calendar year
					//if the facility year is less than the current calendar year, the installation year 
					//	cannot be the current calendar year because it would violate the timing constraints:
					//	installation year < last rehab year < inspection year < facility year < next replacement/rehab year)
					//this can be avoided by setting the installation year to the facility year for disciplines
					//	that do not exist in the database
					//the inspection year, date of inspection, and last rehab year must also be set to the facility year for the same reason
					//it is not necessary to set next replacement/rehab years because they are n/a due to condition being n/a
					newObject.InspectionYear = Convert.ToDateTime("1/1/" + facilityYear.ToString());
					newObject.DateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
					newObject.RehabYearLast = facilityYear;
				}

				//mam 112806 - changed to zero
				//mam 050806
				//newObject.m_replacementValueYear = DateTime.Now.Year;
				newObject.m_replacementValueYear = 0;
			}
			
			return newObject;
		}

		//mam 03202012 - new method to get all mech disciplines for an infoset
		//@@@@
		public static DisciplineMech[] LoadForInfoset(SqlConnection sqlConnection, int infosetId)
		{
			DisciplineMech		newObject = null;
			StringBuilder	builder = new StringBuilder(400);

			DisciplineMech[] typedArray;
			ArrayList arrayList = new ArrayList();

			//builder.Append("SELECT ");
			//builder.Append("MajorComponents.CipPlanningId, " );
			//builder.Append("disc1_id, DisciplineMech.component_id, disc1_conditionRanking, disc1_CWPAssetValue, ");
			//builder.Append("disc1_originalUsefulLife, ");
			//builder.Append("disc1_acquisitionCost, disc1_replacementValue, ");
			//builder.Append("disc1_salvageValue, disc1_annualMaintCost, ");
			//builder.Append("disc1_originalENR, disc1_currentENR, ");
			//builder.Append("disc1_mechExcessiveVibration, ");
			//builder.Append("disc1_mechExcessiveNoise, disc1_mechExcessiveCorrosion, ");
			//builder.Append("disc1_mechExcessiveLeaks, disc1_mechRunningHot, ");
			//builder.Append("disc1_mechCanRunWhenInspected, disc1_mechSupportIsFunctional, ");
			//builder.Append("disc1_mechPartsMissing, disc1_mechPartsAvailable, ");
			//builder.Append("disc1_mechAdequate, disc1_mechMotorAmps, ");
			//builder.Append("disc1_instrIndicationFunctional, disc1_instrAlarmFunctional, ");
			//builder.Append("disc1_instrPartsMissing, disc1_instrPartsAvailable, ");
			//builder.Append("disc1_instrSpareCapacity, disc1_elecExcessiveCorrosion, ");
			//builder.Append("disc1_elecCleanContacts, disc1_elecPartsAvailable, ");
			//builder.Append("disc1_elecSpareCapacity, disc1_pipeExcessiveCorrosion, ");
			//builder.Append("disc1_pipeExcessiveLeaks, disc1_pipePaintGood, ");
			//builder.Append("disc1_dateInspected, disc1_assessedBy, disc1_equipmentNumber, ");
			//builder.Append("disc1_manufacturer, disc1_runHours, disc1_installationYear, ");
			//builder.Append("disc1_photoCaption, DisciplineMech.PhotoFileName, disc1_comments, disc1_runningAtInspect ");
			//builder.Append(", CurrentValue ");
			//builder.Append(", ReplacementValueYear ");
			//builder.Append(", RepairCost");
			//builder.Append(", RehabCost");
			//builder.Append(", RehabCostYear");
			//builder.AppendFormat(", RehabInterval");
			//builder.AppendFormat(", RehabYearLast");
			//builder.AppendFormat(", NextReplacementYear");
			//builder.AppendFormat(", ReplacementValueDesc");
			//builder.AppendFormat(", RehabCostDesc");
			//builder.AppendFormat(", RehabYearNext");
			//builder.Append(" FROM DisciplineMech");
			//builder.Append(" INNER JOIN MajorComponents ON DisciplineMech.component_id = MajorComponents.component_id");
			//builder.AppendFormat(" WHERE (DisciplineMech.component_id={0}) ", componentID);

			//builder.Append("SELECT C.CipPlanningId, D.*");
			//builder.Append(" FROM DisciplineMech D LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			//builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			//builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			//builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			//builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");

			builder.Append("SELECT C.CipPlanningId, D.*");
			builder.Append(" , F.facility_currentYear, F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id AS ComponentId");
			builder.Append(" FROM DisciplineMech D LEFT JOIN MajorComponents C ON D.component_id = C.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0}", infosetId);
			builder.Append(" UNION ALL");
			builder.Append(" SELECT C.CipPlanningId, D.*");
			builder.Append(" , F.facility_currentYear, F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");
			builder.Append(" FROM MajorComponents C LEFT JOIN DisciplineMech D ON C.component_id = D.component_id");
			builder.Append(" LEFT JOIN TreatmentProcesses P ON C.process_id = P.process_id");
			builder.Append(" LEFT JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE F.infoset_id = {0} AND C.component_id NOT IN (SELECT component_id FROM DisciplineMech)", infosetId);
			builder.Append(" AND C.component_MechStructDisc = 1");
			builder.Append(" ORDER BY F.facility_sortOrder, F.facility_id, P.process_sortOrder, P.process_id, C.component_sortOrder, C.component_id");

			System.Diagnostics.Debug.WriteLine(builder.ToString());

			try
			{
				SqlDataAdapter adapter = new SqlDataAdapter();
				System.Data.DataTable dataTable = new System.Data.DataTable();
				adapter.SelectCommand = new SqlCommand(builder.ToString(), sqlConnection);
				adapter.Fill(dataTable);

				bool mainFormCurrentlyImporting = MainForm.currentlyImporting;
				foreach (DataRow dataRow in dataTable.Rows)
				{
					newObject = new DisciplineMech(0);
					newObject.LoadRecordData(dataRow);

					if (newObject.ID != 0)
					{
						//arrayList.Add(newObject);
					}
					else
					{
						newObject.ComponentID = Convert.ToInt32(dataRow["ComponentId"]);

						if (!mainFormCurrentlyImporting)
						{
							short facilityYear = Convert.ToInt16(dataRow["facility_currentYear"]);
							newObject.InstallationYear = facilityYear;
							newObject.InspectionYear = Convert.ToDateTime("1/1/" + facilityYear.ToString());
							newObject.DateInspected = Convert.ToDateTime("1/1/" + facilityYear.ToString());
							newObject.RehabYearLast = facilityYear;
						}

						newObject.m_replacementValueYear = 0;
					}

					arrayList.Add(newObject);
				}
			}
			catch (SqlException ex)
			{
				System.Diagnostics.Trace.WriteLine(String.Format("DisciplineMech.LoadForComponent Error: {0}\n", ex.Message));
				throw ex;
			}
			finally
			{
			}

			typedArray = new DisciplineMech[arrayList.Count];
			arrayList.CopyTo(typedArray);
			return typedArray;
		}

		#endregion /***** Static Methods *****/
	}
}