using System;
using System.Collections;
using System.Drawing;

//mam 102309
using WAM.Common;

//mam 102309
//using System.Data.OleDb;

using System.Text;

//mam 102309
using System.Data.SqlClient;

namespace WAM.Data
{
	public enum DisciplineType
	{
		Mechanical = 0, // Component Type A
		Structural,		// Component Type A
		Land,			// Component Type A
		Pipes,			// Component Type B
		Nodes,			// Component Type B
	}

	//mam 01222012
	//public enum ConstraintType
	//{
	//	InstallationYear,
	//	LastRehabYear,
	//	InspectionYear,
	//	CurrentYear,
	//	NextRehabYear,
	//	NextReplacementYear,
	//}

	/// <summary>
	/// Summary description for Discipline.
	/// </summary>

	//mam 102309
	//public abstract class Discipline : Drive.Data.OleDb.Jet40DALInt32Key, IComparable, IFilterable, IGraphableUnit
	public abstract class Discipline : Drive.Data.SqlClient.SqlDALInt32Key, IComparable, IFilterable, IGraphableUnit
	{
		#region /***** Member Variables *****/
		protected int		m_componentID = 0;
		protected CondRank	m_conditionRanking = CondRank.No;
		protected double	m_CWPAssetValue = 0.0;
		protected short		m_orgUsefulLife = 20;
		protected short		m_installationYear = (short)DateTime.Now.Year;
		protected int		m_currentENR = 0;
		protected decimal	m_acquisitionCost = 0;
		protected bool		m_overrideAcquisitionCost = false;
		protected decimal	m_replacementValue = 0;
		protected decimal	m_salvageValue = 0;
		protected decimal	m_annualMaintCost = 0;
		protected int		m_originalENR = 0;

		//mam
		protected double	m_vulnerability2 = 0.0;
		protected bool		m_overrideVulnerability = false;

		protected decimal	m_currentValue = 0;
		protected bool		m_overrideCurrentValue = false;
		//protected int		m_inspectionYear = 0;
		protected DateTime	m_inspectionYear = DateTime.Now.Date;
		
		//mam 050806
		protected int m_replacementValueYear = 0;
		protected int m_replacementENR = 0;
		protected decimal m_repairCost = 0.0M;
		protected bool m_overrideRepairCost = false;
		protected decimal m_rehabCost = 0;

		//mam 07072011 begin
		protected int m_rehabCostYear = 0;
		protected decimal m_rehabInterval = 10;	//default OUL / 2
		protected decimal m_rehabNext = 0M;

		//mam 01222012 - no longer using Time to Next Rehab override
		//protected bool m_overrideRehabNext = false;

		protected int m_rehabYearLast = 0;
		protected int m_rehabYearNext = 0;
		protected int m_componentCipId = 0;
		//mam 07072011 end

		//mam 07072011
		protected int m_nextReplacementYear = 0;
		protected bool m_overrideNextReplacementYear = false;

		bool isNA = false;
		//WAM.Logic.DisciplineTotals disciplineTotalsSort = null;
		//bool nodesERULVulnNASort = false;
		//bool pipesERULVulnNASort = false;
		bool allERULzero = false;
		bool anyORVuln = false;
		decimal totalCurrentValueSort = 0;
		//</mam>

		//mam 090105
		private string componentName = string.Empty;
		private string processName = string.Empty;
		private int facilityID = 0;
		//</mam>

		//mam 050806
		private int parentID = 0;
		private int grandparentID = 0;
		private int treeNodeIndex = 0;

		private int			m_infoSetID = 0; // For cache purposes, track Info Set

		//mam 01222012
		protected string m_replacementValueDesc = string.Empty;
		protected string m_rehabCostDesc = string.Empty;
		//protected int m_rehabYearNext = 0;
		protected decimal m_replacementNext = 0M;	//time to next replacement
		protected bool m_overrideRehabYearNext = false;

		//mam 03202012
		protected string m_photoFileName = "";

		#endregion /***** Member Variables *****/

		#region /***** Construction *****/
		//mam 102309
		//protected Discipline(int id) : base(WAMSource.CurrentSource.ConnectionString, id)
		protected Discipline(int id) : base(Globals.WamSqlConnectionString, id)
		{
		}

		protected Discipline(string connectionString, int id) : base(connectionString, id)
		{
		}

		//mam 102309
		//protected Discipline(System.Data.OleDb.OleDbConnection sqlConnection, System.Data.OleDb.OleDbDataReader reader)
		//	: base(sqlConnection.ConnectionString, reader)
		protected Discipline(SqlConnection sqlConnection, SqlDataReader reader)
			: base(sqlConnection.ConnectionString, reader)
		{
		}

		#endregion /***** Construction *****/

		#region /***** IComparable Members *****/
		public int CompareTo(object obj)
		{
			Discipline comp = obj as Discipline;

			if (comp != null)
			{
				return Drive.Math.Compare((int)this.Type, (int)comp.Type);
			}
			else
				throw new InvalidCastException("Discipline");
		}

		//mam - compare Disciplines by their various values
		public int CompareTo(object obj, 
			WAM.Logic.UnitFilter.FilterSourceSort which1, 
			WAM.Logic.UnitFilter.FilterSourceSort which2,
			WAM.Logic.UnitFilter.FilterSourceSort which3,
			WAM.Logic.UnitFilter.FilterSourceSort which4,
			WAM.Logic.UnitFilter.FilterSourceSort which5,
			bool lowToHigh1, bool lowToHigh2, bool lowToHigh3, bool lowToHigh4, bool lowToHigh5)		
		{
			Discipline rhs = obj as Discipline;
			int result = 0;

			this.totalCurrentValueSort = this.GetCurrentValue();
			rhs.totalCurrentValueSort = rhs.GetCurrentValue();

			if (this is DisciplinePipe)
			{
				this.isNA = GetAllConditionNA((DisciplinePipe)this);
				this.allERULzero = GetAllERULZero((DisciplinePipe)this);
				this.anyORVuln = GetAnyVulnerabilityOverridden((DisciplinePipe)this);
			}
			else if (this is DisciplineNode)
			{
				this.isNA = GetAllConditionNA((DisciplineNode)this);
				this.allERULzero = GetAllERULZero((DisciplineNode)this);
				this.anyORVuln = GetAnyVulnerabilityOverridden((DisciplineNode)this);
			}

			if (rhs is DisciplinePipe)
			{
				rhs.isNA = GetAllConditionNA((DisciplinePipe)rhs);
				rhs.allERULzero = GetAllERULZero((DisciplinePipe)rhs);
				rhs.anyORVuln = GetAnyVulnerabilityOverridden((DisciplinePipe)rhs);
			}
			else if (rhs is DisciplineNode)
			{
				rhs.isNA = GetAllConditionNA((DisciplineNode)rhs);
				rhs.allERULzero = GetAllERULZero((DisciplineNode)rhs);
				rhs.anyORVuln = GetAnyVulnerabilityOverridden((DisciplineNode)rhs);
			}
			
			if (rhs != null)
			{
				result = CompareToEach(rhs, which1, lowToHigh1);
				if (result == 0)
				{
					result = CompareToEach(rhs, which2, lowToHigh2);
					if (result == 0)
					{
						result = CompareToEach(rhs, which3, lowToHigh3);
						if (result == 0)
						{
							result = CompareToEach(rhs, which4, lowToHigh4);
							if (result == 0)
							{
								result = CompareToEach(rhs, which5, lowToHigh5);

								//mam 050806
								if (result == 0)
								{
									//sort by tree order as the final sort
									result = CompareToEach(rhs, WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex, true);
								}
								//mam
							}
						}
					}
				}
			}
			else
				throw new InvalidCastException("Not a discipline");

			return result;
		}
		//</mam>

		//mam - compare Disciplines by their various values
		private int CompareToEach(Discipline rhs, WAM.Logic.UnitFilter.FilterSourceSort which, bool lowToHigh)
		{
			int result = 0;
			
			switch (which)
			{
					//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.TreeNodeIndex:
					result = this.TreeNodeIndex.CompareTo(rhs.TreeNodeIndex);
					break;
					//mam

				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCost:
					if (lowToHigh)
						result = this.AcquisitionCost.CompareTo(rhs.AcquisitionCost);
					else
						result = rhs.AcquisitionCost.CompareTo(this.AcquisitionCost);

					break;

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.AcquisitionCostEscalated:
					if (lowToHigh)
						result = this.AcquisitionCostEscalated.CompareTo(rhs.AcquisitionCostEscalated);
					else
						result = rhs.AcquisitionCostEscalated.CompareTo(this.AcquisitionCostEscalated);

					break;

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCost:
					if (lowToHigh)
						result = this.RehabCost.CompareTo(rhs.RehabCost);
					else
						result = rhs.RehabCost.CompareTo(this.RehabCost);

					break;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabCostYear:
					if (lowToHigh)
						result = this.RehabYearLast.CompareTo(rhs.RehabYearLast);
					else
						result = rhs.RehabYearLast.CompareTo(this.RehabYearLast);

					break;


					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabInterval:
					if (lowToHigh)
						result = this.RehabInterval.CompareTo(rhs.RehabInterval);
					else
						result = rhs.RehabInterval.CompareTo(this.RehabInterval);

					break;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabNext:
					if (lowToHigh)
						result = this.RehabNext.CompareTo(rhs.RehabNext);
					else
						result = rhs.RehabNext.CompareTo(this.RehabNext);

					break;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearLast:
					if (lowToHigh)
						result = this.RehabYearLast.CompareTo(rhs.RehabYearLast);
					else
						result = rhs.RehabYearLast.CompareTo(this.RehabYearLast);

					break;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSourceSort.RehabYearNext:
					if (lowToHigh)
						result = this.RehabYearNext.CompareTo(rhs.RehabYearNext);
					else
						result = rhs.RehabYearNext.CompareTo(this.RehabYearNext);

					break;

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementNext:
					if (lowToHigh)
						result = this.ReplacementNext.CompareTo(rhs.ReplacementNext);
					else
						result = rhs.ReplacementNext.CompareTo(this.ReplacementNext);

					break;

				//mam 01222012
				case WAM.Logic.UnitFilter.FilterSourceSort.NextReplacementYear:
					if (lowToHigh)
						result = this.NextReplacementYear.CompareTo(rhs.NextReplacementYear);
					else
						result = rhs.NextReplacementYear.CompareTo(this.NextReplacementYear);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CurrentValue:
					if (lowToHigh)
						result = this.GetCurrentValue().CompareTo(rhs.GetCurrentValue());
					else
						result = rhs.GetCurrentValue().CompareTo(this.GetCurrentValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValue:
					if (lowToHigh)
						result = this.ReplacementValue.CompareTo(rhs.ReplacementValue);
					else
						result = rhs.ReplacementValue.CompareTo(this.ReplacementValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.BookValue:
					if (lowToHigh)
						result = this.GetBookValue().CompareTo(rhs.GetBookValue());
					else
						result = rhs.GetBookValue().CompareTo(this.GetBookValue());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.SalvageValue:
					if (lowToHigh)
						result = this.SalvageValue.CompareTo(rhs.SalvageValue);
					else
						result = rhs.SalvageValue.CompareTo(this.SalvageValue);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualDepreciation:
					if (lowToHigh)
						result = this.GetAnnualDepreciation().CompareTo(rhs.GetAnnualDepreciation());
					else
						result = rhs.GetAnnualDepreciation().CompareTo(this.GetAnnualDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.CumulativeDepreciation:
					if (lowToHigh)
						result = this.GetCumulativeDepreciation().CompareTo(rhs.GetCumulativeDepreciation());
					else
						result = rhs.GetCumulativeDepreciation().CompareTo(this.GetCumulativeDepreciation());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvaluatedValue:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetEvaluatedValueLocal().CompareTo(rhs.SortGetEvaluatedValueLocal());
					else
						result = rhs.SortGetEvaluatedValueLocal().CompareTo(this.SortGetEvaluatedValueLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RepairCost:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRepairCostLocal().CompareTo(rhs.SortGetRepairCostLocal());
					else
						result = rhs.SortGetRepairCostLocal().CompareTo(this.SortGetRepairCostLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.AnnualMaintCost:
					if (lowToHigh)
						result = this.AnnualMaintCost.CompareTo(rhs.AnnualMaintCost);
					else
						result = rhs.AnnualMaintCost.CompareTo(this.AnnualMaintCost);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.InstallYear:
					if (lowToHigh)
						result = this.InstallationYear.CompareTo(rhs.InstallationYear);
					else
						result = rhs.InstallationYear.CompareTo(this.InstallationYear);
					break;

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSourceSort.ReplacementValueYear:
					if (lowToHigh)
						result = this.ReplacementValueYear.CompareTo(rhs.ReplacementValueYear);
					else
						result = rhs.ReplacementValueYear.CompareTo(this.ReplacementValueYear);
					break;

					//mam
				case WAM.Logic.UnitFilter.FilterSourceSort.InspectionYear:
					if (lowToHigh)
						result = this.InspectionYear.CompareTo(rhs.InspectionYear);
					else
						result = rhs.InspectionYear.CompareTo(this.InspectionYear);
					break;
					//</mam>

				case WAM.Logic.UnitFilter.FilterSourceSort.OriginalUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortOrgUsefulLifeLocal().CompareTo(rhs.SortOrgUsefulLifeLocal());
					else
						result = rhs.SortOrgUsefulLifeLocal().CompareTo(this.SortOrgUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.RemainingUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRemainingUsefulLifeLocal().CompareTo(rhs.SortGetRemainingUsefulLifeLocal());
					else
						result = rhs.SortGetRemainingUsefulLifeLocal().CompareTo(this.SortGetRemainingUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EvalRemainingUL:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetEvaluatedRemainingUsefulLifeLocal().CompareTo(rhs.SortGetEvaluatedRemainingUsefulLifeLocal());
					else
						result = rhs.SortGetEvaluatedRemainingUsefulLifeLocal().CompareTo(this.SortGetEvaluatedRemainingUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.EconomicUL:
					if (lowToHigh)
						result = this.SortGetEconomicUsefulLifeLocal().CompareTo(rhs.SortGetEconomicUsefulLifeLocal());
					else
						result = rhs.SortGetEconomicUsefulLifeLocal().CompareTo(this.SortGetEconomicUsefulLifeLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.ConditionRank:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortConditionRankingLocal.CompareTo(rhs.SortConditionRankingLocal);
					else
						result = rhs.SortConditionRankingLocal.CompareTo(this.SortConditionRankingLocal);

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.LevelOfService:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetLevelOfServiceLocal().CompareTo(rhs.SortGetLevelOfServiceLocal());
					else
						result = rhs.SortGetLevelOfServiceLocal().CompareTo(this.SortGetLevelOfServiceLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.OverallCriticality:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetOverallCriticalityLocal().CompareTo(rhs.SortGetOverallCriticalityLocal());
					else
						result = rhs.SortGetOverallCriticalityLocal().CompareTo(this.SortGetOverallCriticalityLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Vulnerability:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetVulnerabilityLocal().CompareTo(rhs.SortGetVulnerabilityLocal());
					else
						result = rhs.SortGetVulnerabilityLocal().CompareTo(this.SortGetVulnerabilityLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Risk:
					//mam - use new method that will return -1 for N/A value
					if (lowToHigh)
						result = this.SortGetRiskLocal().CompareTo(rhs.SortGetRiskLocal());
					else
						result = rhs.SortGetRiskLocal().CompareTo(this.SortGetRiskLocal());

					break;

				case WAM.Logic.UnitFilter.FilterSourceSort.Undefined:
					break;

				default:
					System.Windows.Forms.MessageBox.Show("This sort option does not exist.", "Sort",
						System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);

					break;

			}
			return result;
		}
		//</mam>

		#endregion /***** IComparable Members *****/

		#region /***** Nested Class DisciplineComparerBase *****/
		//mam
		public class DisciplineComparerBase : IComparer
		{
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison1;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison2;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison3;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison4;
			private WAM.Logic.UnitFilter.FilterSourceSort whichComparison5;

			private  bool sortLowToHigh1 = true;
			private  bool sortLowToHigh2 = true;
			private  bool sortLowToHigh3 = true;
			private  bool sortLowToHigh4 = true;
			private  bool sortLowToHigh5 = true;

			public int Compare(object lhs, object rhs)
			{
				Discipline l = (Discipline) lhs;
				Discipline r = (Discipline) rhs;
				return l.CompareTo(r, WhichComparison1, WhichComparison2, WhichComparison3, 
					WhichComparison4, WhichComparison5, SortLowToHigh1, SortLowToHigh2, 
					SortLowToHigh3, SortLowToHigh4, SortLowToHigh5);
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison1
			{
				get
				{
					return whichComparison1;
				}
				set
				{
					whichComparison1 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison2
			{
				get
				{
					return whichComparison2;
				}
				set
				{
					whichComparison2 = value;
				}
			}

			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison3
			{
				get
				{
					return whichComparison3;
				}
				set
				{
					whichComparison3 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison4
			{
				get
				{
					return whichComparison4;
				}
				set
				{
					whichComparison4 = value;
				}
			}
			public WAM.Logic.UnitFilter.FilterSourceSort WhichComparison5
			{
				get
				{
					return whichComparison5;
				}
				set
				{
					whichComparison5 = value;
				}
			}

			public bool SortLowToHigh1
			{
				get
				{
					return sortLowToHigh1;
				}
				set
				{
					sortLowToHigh1 = value;
				}
			}
			public bool SortLowToHigh2
			{
				get
				{
					return sortLowToHigh2;
				}
				set
				{
					sortLowToHigh2 = value;
				}
			}
			public bool SortLowToHigh3
			{
				get
				{
					return sortLowToHigh3;
				}
				set
				{
					sortLowToHigh3 = value;
				}
			}
			public bool SortLowToHigh4
			{
				get
				{
					return sortLowToHigh4;
				}
				set
				{
					sortLowToHigh4 = value;
				}
			}
			public bool SortLowToHigh5
			{
				get
				{
					return sortLowToHigh5;
				}
				set
				{
					sortLowToHigh5 = value;
				}
			}
		}
		//</mam>
		#endregion /***** Nested Class DisciplineComparer *****/

		#region /***** IFilterable Members *****/

		//mam 07072011
		public string GetLHValueString(WAM.Logic.UnitFilter.FilterSource source)
		{
			//switch (source)
			//{
			//	case WAM.Logic.UnitFilter.FilterSource.AssetClass:
			//	{
			//		return AssetClass;
			//		break;
			//	}
			//}

			return "";
		}

		//mam 07072011
		public bool IsLHValueStringValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			// Disciplines support every field
			return true;
		}

		public decimal GetLHValue(WAM.Logic.UnitFilter.FilterSource source)
		{
			switch (source)
			{
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCost:
					return AcquisitionCost;
				case WAM.Logic.UnitFilter.FilterSource.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValue:
					return ReplacementValue;
				case WAM.Logic.UnitFilter.FilterSource.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterSource.SalvageValue:
					return SalvageValue;
				case WAM.Logic.UnitFilter.FilterSource.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterSource.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterSource.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterSource.AnnualMaintCost:
					return AnnualMaintCost;
				case WAM.Logic.UnitFilter.FilterSource.OriginalUL:
					return Math.Round(((decimal)OrgUsefulLife), 1);
				case WAM.Logic.UnitFilter.FilterSource.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterSource.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.AcquisitionCostEscalated:
					return AcquisitionCostEscalated;
				case WAM.Logic.UnitFilter.FilterSource.RehabCost:
					return RehabCost;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterSource.RehabCostYear:
					return RehabCostYear;
				case WAM.Logic.UnitFilter.FilterSource.RehabInterval:
					return RehabInterval;
				case WAM.Logic.UnitFilter.FilterSource.RehabNext:
					return RehabNext;
				case WAM.Logic.UnitFilter.FilterSource.RehabYearLast:
					return RehabYearLast;
				case WAM.Logic.UnitFilter.FilterSource.RehabYearNext:
					return RehabYearNext;

					//mam 01222012
				case WAM.Logic.UnitFilter.FilterSource.ReplacementNext:
					return ReplacementNext;

					//mam
				case WAM.Logic.UnitFilter.FilterSource.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
					//</mam>

				case WAM.Logic.UnitFilter.FilterSource.ConditionRank:
					return Math.Round(((decimal)ConditionRanking), 1);

				case WAM.Logic.UnitFilter.FilterSource.LevelOfService:
					return Math.Round(((decimal)GetLevelOfService()), 1);
				case WAM.Logic.UnitFilter.FilterSource.OverallCriticality:
				{
					return Math.Round(((decimal)GetOverallCriticality()), 1);
				}

					//mam - use probability
					//case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
					//	return decimal.Parse(EnumHandlers.GetVulnerabilityShort(GetVulnerability()));
				case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
					//mam 090105 - round vuln to 4 decimals rather than 2
					//return Math.Round(((decimal)GetVulnerability()), 2);
					return Math.Round(((decimal)GetVulnerability()), 4);
					//</mam>

				case WAM.Logic.UnitFilter.FilterSource.Risk:
				{
					return Math.Round(((decimal)GetRisk()), 2);
				}

				case WAM.Logic.UnitFilter.FilterSource.InstallYear:
					return InstallationYear;

					//mam 050806
				case WAM.Logic.UnitFilter.FilterSource.ReplacementValueYear:
					return ReplacementValueYear;

					//mam
				case WAM.Logic.UnitFilter.FilterSource.InspectionYear:
					//mam 01222012 - why does InspectionYear return a date rather than an int?
					//	everything seems to be working with it that way except for the report filter
					//	so, rather than changing InspectionYear, change the return value from this method
					//return Convert.ToDecimal(InspectionYear);
					if (InspectionYear.GetType() == typeof(DateTime))
					{
						return InspectionYear.Year;
					}
					else
					{
						return Convert.ToDecimal(InspectionYear);
					}

					//</mam>
			}

			return 0m;
		}

		public bool		IsLHValueValid(WAM.Logic.UnitFilter.FilterSource source)
		{
			// Disciplines support every field
			return true;
		}

		public decimal GetRHValue(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			switch (compareTo)
			{
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCost:
					return AcquisitionCost;
				case WAM.Logic.UnitFilter.FilterCompareTo.CurrentValue:
					return GetCurrentValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValue:
					return ReplacementValue;
				case WAM.Logic.UnitFilter.FilterCompareTo.BookValue:
					return GetBookValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.SalvageValue:
					return SalvageValue;
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualDepreciation:
					return GetAnnualDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case WAM.Logic.UnitFilter.FilterCompareTo.EvaluatedValue:
					return GetEvaluatedValue();
				case WAM.Logic.UnitFilter.FilterCompareTo.RepairCost:
					return GetRepairCost();
				case WAM.Logic.UnitFilter.FilterCompareTo.AnnualMaintCost:
					return AnnualMaintCost;
				case WAM.Logic.UnitFilter.FilterCompareTo.OriginalUL:
					return Math.Round(((decimal)OrgUsefulLife), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.RemainingUL:
					return Math.Round(((decimal)GetRemainingUsefulLife()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.EvalRemainingUL:
					return Math.Round(((decimal)GetEvaluatedRemainingUsefulLife()), 1);

					//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.AcquisitionCostEscalated:
					return AcquisitionCostEscalated;
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabCost:
					return RehabCost;

					//mam 07072011
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabCostYear:
					return RehabCostYear;
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabInterval:
					return RehabInterval;
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabNext:
					return RehabNext;
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabYearLast:
					return RehabYearLast;
				case WAM.Logic.UnitFilter.FilterCompareTo.RehabYearNext:
					return RehabYearNext;

					//mam 01222012
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementNext:
					return ReplacementNext;

					//mam
				case WAM.Logic.UnitFilter.FilterCompareTo.EconomicUL:
					return Math.Round(((decimal)GetEconomicUsefulLife()), 1);
					//</mam>

				case WAM.Logic.UnitFilter.FilterCompareTo.ConditionRank:
					return Math.Round(((decimal)ConditionRanking), 1);

				case WAM.Logic.UnitFilter.FilterCompareTo.LevelOfService:
					return Math.Round(((decimal)GetLevelOfService()), 1);
				case WAM.Logic.UnitFilter.FilterCompareTo.OverallCriticality:
				{
					return Math.Round(((decimal)GetOverallCriticality()), 1);
				}

					//mam - use probability
					//case WAM.Logic.UnitFilter.FilterSource.Vulnerability:
					//	return decimal.Parse(EnumHandlers.GetVulnerabilityShort(GetVulnerability()));
				case WAM.Logic.UnitFilter.FilterCompareTo.Vulnerability:
					//mam 090105 - round vuln to 4 decimals rather than 2
					//return Math.Round(((decimal)GetVulnerability()), 2);
					return Math.Round(((decimal)GetVulnerability()), 4);
					//</mam>

					//mam - added the following items to match GetLHValue
				case WAM.Logic.UnitFilter.FilterCompareTo.Risk:
					return Math.Round(((decimal)GetRisk()), 2);
					//</mam>

				case WAM.Logic.UnitFilter.FilterCompareTo.InstallYear:
					return InstallationYear;

					//mam 050806
				case WAM.Logic.UnitFilter.FilterCompareTo.ReplacementValueYear:
					return ReplacementValueYear;

					//mam
				case WAM.Logic.UnitFilter.FilterCompareTo.InspectionYear:
				{
					//mam 01222012 - why does InspectionYear return a date rather than an int?
					//	everything seems to be working with it that way except for the report filter
					//	so, rather than changing InspectionYear, change the return value from this method
					//return Convert.ToDecimal(InspectionYear);
					if (InspectionYear.GetType() == typeof(DateTime))
					{
						return InspectionYear.Year;
					}
					else
					{
						return Convert.ToDecimal(InspectionYear);
					}
					//</mam>
				}
			}

			return 0m;
		}

		public bool		IsRHValueValid(WAM.Logic.UnitFilter.FilterCompareTo compareTo)
		{
			return true;
		}
		#endregion /***** IFilterable Members *****/

		#region /***** Properties *****/
		public int InfoSetID
		{
			get { return m_infoSetID; }
			set { m_infoSetID = value; }
		}

		public virtual string Name
		{
			get { return "Discipline"; }
		}

		public int			ComponentID
		{
			get { return m_componentID; }
			set { m_componentID = value; }
		}

		public virtual CondRank	ConditionRanking
		{
			get { return m_conditionRanking; }
			set { m_conditionRanking = value; }
		}

		public virtual double CWPAssetValue
		{
			get { return m_CWPAssetValue; }
			set { m_CWPAssetValue = value; }
		}

		//mam
		public virtual double Vulnerability2
		{
			get { return m_vulnerability2; }
			set { m_vulnerability2 = value; }
		}
		//</mam>

		//mam - add routine to check whether Vulnerability is overridden
		public virtual bool GetVulnerabilityOverridden()
		{
			return m_overrideVulnerability;
		}
		//</mam>

		public virtual short OrgUsefulLife
		{
			get { return m_orgUsefulLife; }
			set { m_orgUsefulLife = value; }
		}

		public virtual short InstallationYear
		{
			get { return m_installationYear; }
			set { m_installationYear = value; }
		}

		//mam
		//		public virtual int InspectionYear
		//		{
		//			get { return m_inspectionYear; }
		//			set { m_inspectionYear = value; }
		//		}
		//</mam>
		//mam
		public virtual DateTime InspectionYear
		{
			get { return m_inspectionYear; }
			set { m_inspectionYear = value; }
		}
		//</mam>

		public abstract DisciplineType Type
		{
			get;
		}

		//mam 050806
		public virtual decimal AcquisitionCostEscalated
		{
			get
			{
				if (OriginalENR == 0)
				{
					return 0;
				}

				return AcquisitionCost * (decimal)CurrentENR / (decimal)OriginalENR;
			}
		}

		public virtual decimal AcquisitionCost
		{
			get
			{
				if (m_overrideAcquisitionCost)
					return m_acquisitionCost;
				else
				{
					//mam 050806 - update - AC is now not always overridden
					//AC = Replacement Value * ENR Install Year / ENR Replacement Year

					int replacementYearENR = GetReplacementYearENR((short)ReplacementValueYear);

					if (replacementYearENR == 0)
					{
						return 0;
					}

					return ReplacementValue * (decimal)OriginalENR / (decimal)replacementYearENR;

					//*************************

					//					//mam 050806 - this code will no longer run because Acquisition Cost is now always overridden
					//					//original method (AC = CV * OENR/CENR or AC based on percentage of discipline):
					//
					//					int		currentENR = CurrentENR;
					//
					//					if (currentENR == 0)
					//						return 0;
					//
					//					// = CurrentValue * (Original ENR / Current ENR)
					//					//mam - unless CV is overridden, in which case AC = CV * OrigENR / CurrENR
					//
					//					if (m_overrideCurrentValue)
					//					{
					//						//mam - return unrounded value
					//						//return Math.Round((GetCurrentValue() *
					//						//	((decimal)OriginalENR / (decimal)currentENR)), 0);
					//						return (GetCurrentValue() * ((decimal)OriginalENR / (decimal)currentENR));
					//					}
					//					else
					//					{
					//						//mam - return unrounded value
					//						//return Math.Round((GetDisciplineCost() * 
					//						//	((decimal)OriginalENR / (decimal)currentENR)), 0);
					//						return (GetDisciplineCost() * ((decimal)OriginalENR / (decimal)currentENR));
					//					}
				}
			}
			set
			{
				m_acquisitionCost = value;
			}
		}

		//mam 091607 - new method
		public virtual decimal AcquisitionCostRoundIndividualValues
		{
			get
			{
				if (m_overrideAcquisitionCost)
					return Math.Round(m_acquisitionCost, 0);
				else
				{
					//mam 07072011 - this is returning the wrong values for pipes and nodes because AC for pipes and nodes is calculated
					//	differently from other disciplines, and this method is not overridden in pipes and nodes
					//AcquisitionCost is overridden in pipes and nodes, so we can either just call that here and not calculate a value here,
					//	or we can override AcquisitionCostRoundIndividualValues in pipes and nodes
					//since calling AcquisitionCost in this method would be a change in calculation, even though this routine is doing the same thing,
					//	let's override AcquisitionCostRoundIndividualValues in pipes and nodes, because the problem occurs only for pipes
					//	and nodes, and we would be correcting that problem without changing this method as it is currently used
					//	by other disciplines

					//mam 050806 - update - AC is now not always overridden
					//AC = Replacement Value * ENR Install Year / ENR Replacement Year

					int replacementYearENR = GetReplacementYearENR((short)ReplacementValueYear);

					if (replacementYearENR == 0)
					{
						return 0;
					}

					//return ReplacementValue * (decimal)OriginalENR / (decimal)replacementYearENR;
					decimal roundedAC = ReplacementValue * (decimal)OriginalENR / (decimal)replacementYearENR;

					return Math.Round(roundedAC, 0);
				}
			}
		}

		public virtual bool	OverrideAcquisitionCost
		{
			get { return m_overrideAcquisitionCost; }
			set
			{
				if (m_overrideAcquisitionCost == value)
					return;

				// Set to the default acquisition cost when turning 
				// override on, and set back to zero when turning it off
				if (!m_overrideAcquisitionCost)
				{
					//mam 050806 - round to two decimals
					//m_acquisitionCost = Math.Round(AcquisitionCost, 0);
					m_acquisitionCost = Math.Round(AcquisitionCost, 2);
				}
				else
					m_acquisitionCost = 0;

				m_overrideAcquisitionCost = value;
			}
		}

		//mam
		public virtual decimal CurrentValue
		{
			//mam - when changing this method, make sure to change GetCurrentValue, too

			get
			{
				//mam
				if (m_overrideCurrentValue)
					return m_currentValue;

				//***********************

				//mam 050806 - new calculation for Current Value

				//if (OriginalENR == 0)
				//	return 0;

				//decimal tempAC = AcquisitionCost + RehabCost;
				//decimal tempACE = AcquisitionCostEscalated;
				//return tempAC > tempACE? tempACE: tempAC;

				//***********************

				//mam 050806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

				//mam 112806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

				//if there is no condition, the current value cannot be calculated
				if (m_conditionRanking == CondRank.No)
					return 0;

				decimal tempACE = AcquisitionCostEscalated;
				decimal condPct = 1m - EnumHandlers.GetConditionRankValue(m_conditionRanking);
				
				//return tempACE + RehabCost - (tempACE * condPct);

				//mam 112806
				return (tempACE * condPct) + RehabCost;

				//***********************

				//				//</mam>
				//				if (m_overrideAcquisitionCost)
				//				{
				//					if (OriginalENR == 0)
				//						return 0;
				//
				//					// = AcquisitionCost * (current ENR / original ENR)
				//					//mam - return unrounded value
				//					//return Math.Round(AcquisitionCost * 
				//					//	((decimal)CurrentENR) / (decimal)OriginalENR, 0);
				//					return AcquisitionCost * ((decimal)CurrentENR) / (decimal)OriginalENR;
				//					//</mam>
				//				}
				//				else
				//				{
				//					//mam 050806 - this code will no longer run because Acquisition Cost is now always overridden
				//					//update - we are allowing AC to be overridden
				//
				//					//mam - using GetDisciplineCost() can cause the CurrentValue to 
				//					//	be rounded to a value different than when the AcquisitionCost is used;
				//					//  (note that GetDisciplineCost() calculates the CurrentValue that is used
				//					//	to calculate AcquisitionCost)
				//
				//					//However, when the Facility's Current Year is set to a year that has no
				//					//	ENR data, and the Current ENR is thus zero, using the Acquisition Cost to 
				//					//	calculate Current Value results in CV = 0, while using GetDisciplineCost
				//					//	to calculate CV results in CV having a value (if the Cost Allocation %
				//					//	tab has values)
				//
				//					//for now, go back to using GetDisciplineCost
				//
				//					//instead, return GetDisciplineCost if CurrentENR is zero; otherwise
				//					//	return AC * CurrENR / OrigENR 
				//
				//					//no, this is causing roll-up rounding issues
				//					//	go back to using GetDisciplineCost
				//
				//					//if (CurrentENR == 0)
				//					//{
				//						return GetDisciplineCost();
				//					//}
				//					//else
				//					//{
				//					//	if (OriginalENR == 0)
				//					//		return 0;
				//
				//					//	return Math.Round(AcquisitionCost * 
				//					//		((decimal)CurrentENR) / (decimal)OriginalENR, 0);
				//					//}
				//				}
			}	
			set
			{
				m_currentValue = value;
			}
		}
		//</mam>

		//mam
		public virtual bool OverrideCurrentValue
		{
			get { return m_overrideCurrentValue; }
			set
			{
				if (m_overrideCurrentValue == value)
					return;

				// Set to the default current value when turning 
				// override on, and set back to zero when turning it off

				//mam
				if (!m_overrideCurrentValue)
					m_currentValue = Math.Round(CurrentValue, 0);
				else
					m_currentValue = 0;

				m_overrideCurrentValue = value;
			}
		}
		//</mam>

		public virtual decimal RepairCost
		{
			get
			{
				// Change to use LOS
				MajorComponent	component = 
					CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

				//mam 050806
				if (m_overrideRepairCost)
					return m_repairCost;

				if ((m_conditionRanking == CondRank.C0 ||
					m_conditionRanking == CondRank.C5 || 
					m_conditionRanking == CondRank.No) &&
					component.LOS == LevelOfService.LOS1)
				{
					return ReplacementValue;
				}
				// When condition <= LOS, repair cost = 0
				if (m_conditionRanking != CondRank.No &&
					(byte)m_conditionRanking <= (byte)component.LOS)
				{
					return 0;
				}
			
				// Get the condition percent modifier
				decimal			condPct = 
					(decimal)EnumHandlers.GetConditionRankValue(m_conditionRanking);

				//mam - new Repair Cost equation uses LOS

				//original code:
				//decimal			repairCost = GetCurrentValue() * (1m - condPct);

				//new equation: Repair Cost = Current Value * (Condition Fraction � LOS Fraction)
				//new code:
				decimal losPct = (decimal)EnumHandlers.GetLOSValue(component.LOS );
				//decimal repairCost = GetCurrentValue() * (condPct - losPct);
				//</mam>

				//mam 020607 - new Repair Cost equation = EAC * (Cond - LOS)
				decimal repairCost = AcquisitionCostEscalated * (condPct - losPct);

				if (repairCost < 0)
					return 0;
			
				//mam - return unrounded value
				//return Math.Round(repairCost, 0);
				return repairCost;
			}
			set
			{
				m_repairCost = value;
			}
		}

		//mam
		public virtual bool OverrideRepairCost
		{
			get { return m_overrideRepairCost; }
			set
			{
				if (m_overrideRepairCost == value)
					return;

				// Set to the default acquisition cost when turning 
				// override on, and set back to zero when turning it off

				//mam
				if (!m_overrideRepairCost)
					m_repairCost = Math.Round(RepairCost);
				else
					m_repairCost = 0;

				m_overrideRepairCost = value;
			}
		}
		//</mam>

		//mam 050806
		public virtual decimal RehabCost
		{
			get { return m_rehabCost; }
			set { m_rehabCost = value; }
		}

		//mam 07072011
		public virtual int RehabCostYear
		{
			get { return m_rehabCostYear; }
			set { m_rehabCostYear = value; }
		}

		//mam 07072011
		public virtual decimal RehabInterval
		{
			get 
			{ 
				MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					return 0m;
				}

				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is replacement - rehab interval = 0
					return 0m;
				}

				return m_rehabInterval;
			}
			set { m_rehabInterval = value; }
		}

		//mam 07072011
		public virtual decimal RehabNext
		{
			//time to next rehab (in years)
			//rehab next = rehab year last + rehab interval - current year
			//a negative result means that rehab is overdue
			//rehab next = 0 if planning mode = replacement

			//mam 01222012
			//rehab next = EcRUL + inspection year - current year
			//if next rehab year is overridden, rehab next = next rehab year - current year
			//if rehab next < 0, rehab next = 0
			//constraints:  installation year <= last rehab year <= inspection year <= current year <= next rehab year

			get 
			{ 
				//rehab next = rehab year last + rehab interval - current year
				//if planning mode = replacement, then rehab next = 0, whether or not it is overridden

				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					return 0m;
				}

				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is replacement - rehab next = 0
					return 0m;
				}

				//mam 0122012 - no longer using override for Time to Next Rehab
				//if (m_overrideRehabNext)
				//{
				//	return m_rehabNext;
				//}

				//mam 01222012 - superseded by new calc
				////if RehabYearLast is zero or RehabInterval is zero, the calculation becomes meaningless, so return zero
				//decimal rehabInterval = RehabInterval;
				//if (RehabYearLast == 0 || rehabInterval == 0)
				//{
				//	return 0m;
				//}

				//decimal rehabNext = Math.Round(RehabYearLast + rehabInterval - CurrentYear, 1);

				//*****************************

				//mam 01222012 - new calc

				//rehab next = EcRUL + inspection year - current year
				//if next rehab year is overridden, rehab next = next rehab year - current year
				//if rehab next < 0, rehab next = 0
				//constraints:  installation year <= last rehab year <= inspection year <= current year <= next rehab year

				decimal rehabNext = 0M;
				if (OverrideRehabYearNext)
				{
					rehabNext = RehabYearNext - CurrentYear;
				}
				else
				{
					rehabNext = Convert.ToDecimal(Math.Round(GetEconomicUsefulLife() + GetInspectionYear() - CurrentYear, 1));
				}

				rehabNext = rehabNext < 0 ? 0 : rehabNext;

				//*****************************

				return rehabNext;
			}
			set 
			{ 
				m_rehabNext = value;
			}
		}

		//mam 01222012 - no longer using override for Time to Next Rehab
		//mam 07072011
		//public virtual bool OverrideRehabNext
		//{
		//	get { return m_overrideRehabNext; }
		//	set
		//	{
		//		if (m_overrideRehabNext == value)
		//			return;
		//
		//		// Calculate rehab next when turning override off (unchecking the box), 
		//		//	and set back to zero when turning it on (checking the box)
		//
		//		if (!m_overrideRehabNext)
		//			m_rehabNext = Math.Round(RehabNext, 1);
		//		else
		//			m_rehabNext = 0;
		//
		//		m_overrideRehabNext = value;
		//	}
		//}
		//</mam>

		//mam 07072011
		public virtual int RehabYearLast
		{
			get { return m_rehabYearLast; }
			set { m_rehabYearLast = value; }
		}

		//mam 01222012
		public virtual decimal ReplacementNext
		{
			//get { return m_replacementNext; }
			//set { m_replacementNext = value; }

			//mam 01222012
			//replacement next = EvRUL + inspection year - current year
			//if next replacement year is overridden, replacement next = next replacement year - current year
			//if replacement next < 0, replacement next = 0
			//if planning mode = rehabilitation, then replacement next = 0
			//constraints:  installation year <= last rehab year <= inspection year <= current year <= next replacement year

			get 
			{ 
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					return 0m;
				}

				if (component.CipPlanningId != Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is rehabilitation - replacement next = 0
					return 0m;
				}

				decimal replacementNext = 0M;
				if (OverrideNextReplacementYear)
				{
					replacementNext = NextReplacementYear - CurrentYear;
				}
				else
				{
					replacementNext = Convert.ToDecimal(Math.Round(GetEvaluatedRemainingUsefulLife() + GetInspectionYear() - CurrentYear, 1));
				}

				replacementNext = replacementNext < 0 ? 0 : replacementNext;

				//*****************************

				return replacementNext;
			}
			set 
			{ 
				m_replacementNext = value;
			}
		}

		//mam 01222012
		public virtual bool OverrideRehabYearNext
		{
			get { return m_overrideRehabYearNext; }
			set
			{
				if (m_overrideRehabYearNext == value)
					return;

				// Calculate next rehab year when turning override off (unchecking the box), 
				//	and set back to zero when turning it on (checking the box)

				if (!m_overrideRehabYearNext)
					m_rehabYearNext = RehabYearNext;
				else
					m_rehabYearNext = 0;

				m_overrideRehabYearNext = value;
			}
		}

		//mam 07072011
		public virtual bool IsComponentZeroRehab
		{
			get 
			{ 
				MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					//this shouldn't ever happen
					return true;
				}

				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is replacement
					return true;
				}

				return false;
			}
		}

		//mam 07072011
		public virtual int GetRehabYearLastDefault()
		{
			if (OrgUsefulLife == 0)
			{
				//mam 01222012 - return installation year rather than zero
				//return 0;
				return InstallationYear;
			}

			double rehabInterval = OrgUsefulLife / 2;

			Facility facility = GetFacility();
			if (facility == null)
			{
				return 0;
			}

			int facilityYear = facility.CurrentYear;

			//original method adds multiples of rehab intervals to installation year with the result being <= facility year
			//	(unless facility year and/or installation year are in the future, which can result in a value > facility year)
			//second method uses the same idea, but instead of adding to the installation year, it subtracts from the facility year
			//	the amount subtracted is the modulus of the difference between facility year and installation year, divided by the rehab interval
			//  this gives the same result as the original method in 'normal' cases where both the facility year and the installation year are not in the future
			//	if either year is in the future, the result for the second method has a maximum value equal to the facility year
			//use the second method, as it never exceeds facility year, contains fewer variables, and we get to use the modulus operator, which is always fun

			//original method (very lightly tested - if it is to be used, it needs full testing):
			//do it in three steps:
			//double increment = facilityYear > m_installationYear ? Math.Floor((double)(facilityYear - m_installationYear) / rehabInterval) 
			//	: Math.Ceiling((double)(facilityYear - m_installationYear) / rehabInterval);
			//int originalMethod = Convert.ToInt32(Math.Floor(increment * rehabInterval + m_installationYear));
			////constrain value to facility year
			//originalMethod = originalMethod > facilityYear ? facilityYear : originalMethod;

			//second method:
			//get fac year minus install year mod rehab interval; if negative, use zero
			//subtract the increment from the fac year
			//second method max is already constrained to facility year
			//do it in two steps:
			//decimal increment = Math.Max(facilityYear - m_installationYear, 0) % (double)RehabInterval;
			//int secondMethod = facilityYear - Convert.ToInt32(Math.Ceiling((double)increment));
			//do it in one step:
			int secondMethod = facilityYear - Convert.ToInt32(Math.Ceiling((double)Math.Max(facilityYear - m_installationYear, 0) % rehabInterval));

			//mam 01222012 - last rehab year must be >= installation year and <= inspection year
			//installation year and inspection year are assumed to be within constraints
			if (secondMethod < m_installationYear)
			{
				secondMethod = m_installationYear;
			}
			else if (secondMethod > m_inspectionYear.Year)
			{
				secondMethod = m_inspectionYear.Year;
			}

			//m_installationYear
			//facilityYear
			//m_inspectionYear
			//m_rehabYearLast
			//m_nextReplacementYear
	
			return secondMethod;
		}

		//mam 01222012
		public virtual short GetInstallationYearDefault()
		{
			Facility facility = GetFacility();
			if (facility == null)
			{
				return 0;
			}

			short facilityYear = facility.CurrentYear;
			short calendarYear = Convert.ToInt16(DateTime.Now.Year);

			//if the facility current year is less than the current calendar, set the default Installation Year to the facility current year
			return facilityYear < calendarYear ? facilityYear : calendarYear;
		}

		//mam 01222012
		public virtual DateTime GetInspectionDateDefault()
		{
			Facility facility = GetFacility();
			if (facility == null)
			{
				return DateTime.Now;
			}

			int facilityYear = facility.CurrentYear;

			DateTime defaultDate = Convert.ToDateTime("1/1/" + facilityYear.ToString());

			//if the facility current year is less than the current calendar, set the default InspectionDate to January 1st of the facility current year
			return facilityYear < DateTime.Now.Year ? defaultDate : DateTime.Now;
		}

		//mam 07072011
		public virtual int RehabYearNext
		{
			get 
			{
				//next rehab year = last rehab year + rehab interval
				//if planning mode = replacement, next rehab year = 0
				//if time To next rehab is overridden, then next rehab year = Current Year + Time to Next Rehabilitation
				//if rehab interval = 0 or last rehab year = 0, then next rehab year = 0 (unless time to next rehab is overridden)

				//mam 01222012
				//next rehab year = current year + time to next rehab
				//if next rehab year < current year, next rehab year = current year
				//constraints:  last rehab year <= inspection year <= current year <= next rehab year

				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					return 0;
				}

				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is replacement - next rehab year is zero
					return 0;
				}

				//mam 0122012
				if (m_overrideRehabYearNext)
				{
					return m_rehabYearNext;
				}

				decimal rehabYearNext = 0M;

				//******************************

				//mam 01222012 - old calc

				//decimal rehabInterval = RehabInterval;

				////mam 01222012 - no longer using override for Time to Next Rehab
				////if (m_overrideRehabNext)
				////{
				////	//rehab year next = Current Year + rehab next
				////	rehabYearNext = CurrentYear + RehabNext;
				////}
				//if (rehabInterval > 0 && RehabYearLast > 0)
				//{
				//	//rehab year next = rehab year last + rehab interval
				//	rehabYearNext = RehabYearLast + rehabInterval;
				//}
				//
				//return Convert.ToInt32(Math.Floor(Convert.ToDouble(rehabYearNext)));

				//******************************

				//mam 01222012 - new calc

				int returnValue = 0;
				int cy = CurrentYear;

				rehabYearNext = cy + RehabNext;
				returnValue = Convert.ToInt32(Math.Floor(Convert.ToDouble(rehabYearNext)));
				
				return returnValue < cy ? cy : returnValue;
			}
			set 
			{
				m_rehabYearNext = value;
			}
		}

		//mam 07072011
		public virtual int ComponentCipId
		{
			get { return m_componentCipId; }
			set { m_componentCipId = value; }
		}

		public virtual decimal ReplacementValue
		{
			get { return m_replacementValue; }
			set { m_replacementValue = value; }
		}

		//mam 050806
		public virtual int ReplacementValueYear
		{
			get { return m_replacementValueYear; }
			set { m_replacementValueYear = value; }
		}

		//mam 01222012 - superseded by new calculation, below
		//mam 07072011
		//public virtual int NextReplacementYear
		//{
		//	get 
		//	{ 
		//		//next replacement year = date of inspection year + evaulated remaining useful life (EvRUL = (1 - cond fraction) * OUL)
		//		//always round up to the next year whenever there is a partial year, if the value is calculated
		//		//next replacement year can be overridden
		//		//if planning mode = rehabilitation, next replacement year = 0, unless it is overridden
		//		//UPDATE:  don't ever set next replacement year to zero, regardless of planning mode
		//		//if planning mode = replacement, next replacement year is calculated, unless it is overridden
		//		//if next replacement year is overridden, changing the planning mode has no effect
		//
		//		//UPDATE:  planning mode has no effect on next replacement year
		//
		//		//max possible value = 9999 + 9999 = 19998, which is less than int32 max, so we can safely convert to int
		//
		//		if (m_overrideNextReplacementYear)
		//		{
		//			return m_nextReplacementYear;
		//		}
		//
		//		MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
		//		if (component == null)
		//		{
		//			return 0;
		//		}
		//
		//		//don't check cip because we're not changing next replacement year based on cip
		//		//if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
		//		//{
		//		//	//cip mode is replacement - use calculated next replacement year
		//		//}
		//		//else
		//		//{
		//		//	//cip mode is rehabilitation - next replacement year = zero
		//		//	return 0;
		//		//}
		//
		//		double nextRepYear = Math.Ceiling(GetInspectionYear() + GetEvaluatedRemainingUsefulLife());
		//		return Convert.ToInt32(nextRepYear);
		//	}
		//	set 
		//	{
		//		m_nextReplacementYear = value; 
		//	}
		//}

		//mam 01222012 - new calc
		public virtual int NextReplacementYear
		{
			get 
			{
				//next replacement year = current year + time to next replacement
				//if next replacement year < current year, next replacement year = current year
				//constraints:  last rehab year <= inspection year <= current year <= next replacement year

				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				if (component == null)
				{
					return 0;
				}

				if (component.CipPlanningId != Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					//cip mode is rehabilitation - next replacement year is zero
					return 0;
				}

				if (m_overrideNextReplacementYear)
				{
					return m_nextReplacementYear;
				}

				decimal nextReplacementYear = 0M;
				int cy = CurrentYear;
				int returnValue = 0;

				nextReplacementYear = cy + ReplacementNext;
				returnValue = Convert.ToInt32(Math.Floor(Convert.ToDouble(nextReplacementYear)));
				
				return returnValue < cy ? cy : returnValue;
			}
			set 
			{
				m_nextReplacementYear = value;
			}
		}

		//mam 07072011
		public virtual bool OverrideNextReplacementYear
		{
			get { return m_overrideNextReplacementYear; }
			set
			{
				if (m_overrideNextReplacementYear == value)
					return;

				// Calculate next replacement year when turning override off (unchecking the box), 
				//	and set back to zero when turning it on (checking the box)

				if (!m_overrideNextReplacementYear)
					m_nextReplacementYear = NextReplacementYear;
				else
					m_nextReplacementYear = 0;

				m_overrideNextReplacementYear = value;
			}
		}
		//</mam>

		public virtual decimal SalvageValue
		{
			get { return m_salvageValue; }
			set { m_salvageValue = value; }
		}

		public virtual decimal AnnualMaintCost
		{
			get { return m_annualMaintCost; }
			set { m_annualMaintCost = value; }
		}

		public virtual int	OriginalENR
		{
			get
			{
				Facility	facility = GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(m_installationYear);

				return 0;

//				return m_originalENR;
			}
			set { m_originalENR = value; }
		}

		//mam - get OriginalENR by passing in a year (for Pipes and Nodes reports)
		public virtual int GetOriginalENR(short yearENR)
		{
			Facility	facility = GetFacility();

			if (facility != null)
				return facility.GetENRValueForYear(yearENR);

			return 0;
		}
		//</mam>

		//mam 050806
		public virtual int ReplacementENR
		{
			get
			{
				Facility facility = GetFacility();

				if (facility != null)
					return facility.GetENRValueForYear(m_replacementValueYear);

				return 0;
			}
			set { m_replacementENR = value; }
		}

		//mam 050806 - get ENR for Replacement Year
		public virtual int GetReplacementYearENR(short yearENR)
		{
			Facility	facility = GetFacility();

			if (facility != null)
				return facility.GetENRValueForYear(yearENR);

			return 0;
		}

		public virtual int	CurrentENR
		{
			get 
			{
				Facility	facility = GetFacility();

				if (facility != null)
					return facility.CurrentENR;

				return 0;
			}
		}

		public int			CurrentYear
		{
			get
			{
				// Get the associated major component
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, ComponentID);
				TreatmentProcess process;
				Facility	facility;

				if (component == null)
					return 0;

				process = CacheManager.GetTreatmentProcess(m_infoSetID, 
					component.ProcessID);

				// Not likely that this will fail
				if (process == null)
					return 0;

				facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);
				if (facility == null)
					return 0;

				return facility.CurrentYear;
			}
		}

		//mam 050806
		public int TreeNodeIndex
		{
			get { return treeNodeIndex; }
			set { treeNodeIndex = value; }
		}

		//mam 01222012
		public string ReplacementValueDesc
		{
			get { return m_replacementValueDesc; }
			set { m_replacementValueDesc = value; }
		}

		//mam 01222012
		public string RehabCostDesc
		{
			get { return m_rehabCostDesc; }
			set { m_rehabCostDesc = value; }
		}

		#endregion /***** Properties *****/

		#region /***** Photo Methods *****/

		//mam 03202012 - renamed to indicate the photo file name is included
		//public string		GetImagePath()
		public string		GetImagePathWithPhotoFileName()
		{
			//mam 03202012
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(m_infoSetID);
			photoPath += "\\" + m_photoFileName;
			return photoPath;

			////mam 11142011 - get the component from the CacheManager rather than creating a new one so we can get the process id
			////mam 102309
			////MajorComponent	component = new MajorComponent(m_sqlConnectionString, m_componentID);
			//MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
			//
			////TreatmentProcess process = new TreatmentProcess(m_sqlConnectionString, component.ProcessID);
			////Facility		facility = new Facility(m_sqlConnectionString, process.FacilityID);
			////InfoSet			infoSet = new InfoSet(m_sqlConnectionString, facility.InfoSetID);
			////string			path = string.Format(
			////	@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", infoSet.GetImagePath(),
			////	facility.ID, process.ID, component.ID, (int)this.Type);
			////return path;
			//
			//string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(InfoSetID);
			////string photoName = this.Photo;
			////string photoNamePlusPath = photoPath + "\\" + photoName;
			//
			////mam 102309 - if there is no photo file name in the database, use the string of IDs to find the photo
			////mam 102309 - no - just use ID method for photo names
			////if (photoName == null || photoName == "")
			////{
			//	string photoName = string.Format(@"{0:D4}-{1:D4}-{2:D4}-{3:D2}-01.jpg", 
			//		GetFacilityID(), component.ProcessID, m_componentID, (int)this.Type);
			//	photoPath += "\\" + photoName;
			////}
			//
			////return photoPath;
		}

		//mam 03202012 - no longer used
		//mam 102309 - used only when deleting photos, and we are not deleting photos any more
		//mam 102309 - yes, we are
		//mam - pass in IDs so the path can be returned faster when copying photos
		//public string		GetImagePath(int facilityID, int processID, int componentID, int infoSetID)
		//{
		//	InfoSet			infoSet = new InfoSet(m_sqlConnectionString, infoSetID);
		//	string path = string.Format(
		//		@"{0}\{1:D4}-{2:D4}-{3:D4}-{4:D2}-01.jpg", infoSet.GetImagePath(),
		//		facilityID, processID, componentID, (int)this.Type);
		//	return path;
		//}
		//</mam>

		//mam 03202012
		public string GetImagePathWithPhotoFileNameIdStyle()
		{
			MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
			string photoPath = WAM.Common.CommonTasks.GetInfosetImagePath(InfoSetID);
			string photoName = string.Format(@"{0:D4}-{1:D4}-{2:D4}-{3:D2}-01.jpg", GetFacilityID(), component.ProcessID, m_componentID, (int)this.Type);

			photoPath += "\\" + photoName;

			return photoPath;
		}

		public Image		GetPhoto()
		{
			//mam 03202012
			//string			path = GetImagePath();
			string			path = GetImagePathWithPhotoFileName();

			Image			image = null;

			//mam - added try/catch
			try
			{
				if (System.IO.File.Exists(path))
				{

					//image = Image.FromFile(path);
					//return image;

					//mam - set the file to be not read only, just in case the user has pulled a fast one and
					//	has copied a read-only image into the images folder
					System.IO.File.SetAttributes(path, System.IO.FileAttributes.Normal);
					//</mam>

					//mam - get the image from a filestream to alleviate
					//	"access denied" issues when deleting nodes and image folders
					using (System.IO.FileStream fileStream = new System.IO.FileStream(path, System.IO.FileMode.Open))
					{
						image = Image.FromStream(fileStream);
						fileStream.Close();
					}
					//</mam>
				}
			}
			catch
			{
				return null;
			}
			//</mam>

			return image;
		}
		#endregion /***** Photo Methods *****/

		#region /***** Calculation Methods *****/

		//mam 050806
		public static DisciplineType GetDisciplineTypeFromInt(int discTypeInt)
		{
			switch (discTypeInt)
			{
				case 0:
					return DisciplineType.Mechanical;
				case 1:
					return DisciplineType.Structural;
				case 2:
					return DisciplineType.Land;
				case 3:
					return DisciplineType.Pipes;
				case 4:
					return DisciplineType.Nodes;
			}
			return DisciplineType.Mechanical;
		}

		//mam
		public virtual int GetItemCount()
		{
			return 0;
		}
		//</mam>

		public virtual decimal GetCurrentValue()
		{
			//mam - when changing this method, make sure to change CurrentValue, too

			//mam
			if (m_overrideCurrentValue)
				return m_currentValue;
			else
			{

				//***********************

				//mam 050806 - new calculation for Current Value

				//if (OriginalENR == 0)
				//	return 0;

				//decimal tempCV = AcquisitionCost + RehabCost;
				//decimal tempACE = AcquisitionCostEscalated;
				//return tempCV > tempACE? tempACE: tempCV;

				//***********************

				//mam 050806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost + Rehab Cost - Escalated Acquisition Cost * (1 - condition fraction)

				//mam 112806 - update - new calculation for CV
				//CV = Escalated Acquisition Cost * (1 - condition fraction) + Rehab Cost

				//if there is no condition, the current value cannot be calculated
				if (m_conditionRanking == CondRank.No)
					return 0;

				decimal tempACE = AcquisitionCostEscalated;
				decimal condPct = 1m - EnumHandlers.GetConditionRankValue(m_conditionRanking);
				
				//mam 050806
				//return tempACE + RehabCost - (tempACE * condPct);

				//mam 112806
				return (tempACE * condPct) + RehabCost;

				//***********************

//				//</mam>
//				if (m_overrideAcquisitionCost)
//				{
//					if (OriginalENR == 0)
//						return 0;
//
//					// = AcquisitionCost * (current ENR / original ENR)
//
//					//mam - return unrounded value
//					//return Math.Round(AcquisitionCost * 
//					//	((decimal)CurrentENR) / (decimal)OriginalENR, 0);
//					return AcquisitionCost * ((decimal)CurrentENR) / (decimal)OriginalENR + RehabCost;
//				}
//				else
//				{
//					//mam 050806 - no longer using GetDisciplineCost (which used the Cost Allocation tab values)
//					return GetDisciplineCost();
//				}
			}
		}

		public virtual decimal GetRepairCost()
		{
			// Change to use LOS
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			//mam 050806
			if (m_overrideRepairCost)
				return m_repairCost;

			//mam 050806
			if (m_conditionRanking == CondRank.No)
				return 0;

			if ((m_conditionRanking == CondRank.C0 ||
				m_conditionRanking == CondRank.C5 || 
				m_conditionRanking == CondRank.No) &&
				component.LOS == LevelOfService.LOS1)
			{
				return ReplacementValue;
			}
			// When condition <= LOS, repair cost = 0
			if (m_conditionRanking != CondRank.No &&
				(byte)m_conditionRanking <= (byte)component.LOS)
			{
				return 0;
			}
		
			// Get the condition percent modifier
			decimal			condPct = 
				(decimal)EnumHandlers.GetConditionRankValue(m_conditionRanking);

			//mam - new Repair Cost equation uses LOS

			//original code:
			//decimal			repairCost = GetCurrentValue() * (1m - condPct);

			//new equation: Repair Cost = Current Value * (Condition Fraction � LOS Fraction)
			//new code:
			decimal losPct = (decimal)EnumHandlers.GetLOSValue(component.LOS );

			//mam 050806 - round CurrentValue because whole numbers are used on the forms
			//mam 020607 - new Repair Cost equation = EAC * (Cond - LOS)
			//decimal repairCost = Math.Round(GetCurrentValue()) * (condPct - losPct);
			decimal repairCost = Math.Round(AcquisitionCostEscalated) * (condPct - losPct);
			//</mam>

			if (repairCost < 0)
				return 0;
		
			//mam - return unrounded value
			//return Math.Round(repairCost, 0);
			return repairCost;
		}

		public virtual decimal GetBookValue()
		{
			//mam - BookValue cannot be < zero

			//original code:
			//return Math.Round(AcquisitionCost - (GetAnnualDepreciation() * 
			//	(decimal)(CurrentYear - InstallationYear)), 0);

			//new code:
			//mam - return unrounded value
			//decimal bookValue = Math.Round(AcquisitionCost - (GetAnnualDepreciation() * 
			//	(decimal)(CurrentYear - InstallationYear)), 0);

			decimal bookValue = AcquisitionCost - (GetAnnualDepreciation() * (decimal)(CurrentYear - InstallationYear));
			if (bookValue < 0)
				return 0;
			else
				return bookValue;
			//</mam>
		}

		public virtual decimal GetAnnualDepreciation()
		{
			if (m_orgUsefulLife != 0)
				return ((AcquisitionCost - SalvageValue) / (decimal)OrgUsefulLife);
			else
				return 0;
		}

		public virtual decimal GetCumulativeDepreciation()
		{
			return (AcquisitionCost - GetBookValue());
		}

		public virtual decimal GetEvaluatedValue()
		{
			decimal			condPct = 1.0M - 
				EnumHandlers.GetConditionRankValue(ConditionRanking);

			//mam 050806 round CurrentValue because round numbers are used on the form
			//return (Math.Round(GetCurrentValue()) * condPct);

			//mam 050806 - new calculation for EV
			//EV = EAC * (1 - Condition Fraction)

			return AcquisitionCostEscalated * condPct;
		}

		public virtual decimal GetDisciplineCost()
		{
			decimal			retVal = 0;

			// Get the associated major component
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, ComponentID);
			TreatmentProcess process;

			if (component == null)
				return retVal;

			process = CacheManager.GetTreatmentProcess(m_infoSetID, component.ProcessID);

			// Not likely that this will fail
			if (process == null)
				return retVal;

			retVal = process.OrgCost;
			retVal *= (decimal)component.CWPValue;
			retVal *= (decimal)CWPAssetValue;

			//mam - return unrounded value
			//return Math.Round(retVal, 0);
			return retVal;
		}

		public virtual double GetRemainingUsefulLife()
		{
			// This used to be Book Useful Life
			if (InstallationYear <= 0)
				return 0.0;

			// Get the facility (need to get the component to get facility)
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
			Facility		facility;
			int				usefulLife = 0;

			if (component.ID == 0)
				return usefulLife;

			TreatmentProcess process = 
				CacheManager.GetTreatmentProcess(m_infoSetID, component.ProcessID);

			facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);

			usefulLife = OrgUsefulLife;
			usefulLife -= (facility.CurrentYear - InstallationYear);

			//mam - don't allow Remaining Useful Life to be < zero
			if (usefulLife < 0)
				return 0;
			else
			//</mam>
				return usefulLife;
		}

		public virtual double GetEvaluatedRemainingUsefulLife()
		{
			// This used to be Evaluated Remaining Useful Life
			if (ConditionRanking == CondRank.No)
				return 0;

			//mam 051708 - use cond fractions used to calc useful life
			// Get the condition percent modifier
			//decimal			condPct = 1m - EnumHandlers.GetConditionRankValue(ConditionRanking);
			decimal			condPct = 1m - EnumHandlers.GetConditionRankValueForUsefulLife(ConditionRanking);

			return Math.Round((double)(OrgUsefulLife * condPct), 1);
		}

		//mam
		public virtual double GetEconomicUsefulLife()
		{
			//Economic Remaining Useful Life = (Original UL/2) - (Original UL * Condition Fraction)

			// Get the facility (need to get the component to get facility)
			//Facility facility;
			MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
			double usefulLife = 0;

			if (component.ID == 0)
				return 0.0;

			// When condition = N/A, return 0
			if (m_conditionRanking == CondRank.No)
				return 0.0;
			
			//mam 051708 - use cond fractions used to calc useful life
			// Get the condition percent modifier
			//decimal condPct = (decimal)EnumHandlers.GetConditionRankValue(m_conditionRanking);
			decimal condPct = (decimal)EnumHandlers.GetConditionRankValueForUsefulLife(m_conditionRanking);

			//TreatmentProcess process = 
			//	CacheManager.GetTreatmentProcess(m_infoSetID, component.ProcessID);
			//facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);

			usefulLife = Math.Round((double)(OrgUsefulLife / 2m) - (double)(OrgUsefulLife * condPct), 1);

			return usefulLife;
		}
		//</mam>

		public virtual LevelOfService GetLevelOfService()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			return component.LOS;
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public virtual decimal GetLevelOfService(bool pipesOnly, bool nodesOnly)
		{
			decimal tempValue = 0m;

			if (pipesOnly)
			{
				DisciplinePipe discipline = this as DisciplinePipe;
				tempValue = (decimal)discipline.GetAverageLOS();
			}
			else if (nodesOnly)
			{
				DisciplineNode discipline = this as DisciplineNode;
				tempValue = (decimal)discipline.GetAverageLOS();
			}
			if (pipesOnly || nodesOnly)
			{
				if (tempValue == 0)
				{
					tempValue = -1;
				}
				return tempValue;
			}
			else
			{
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				return (decimal)component.GetLOS(pipesOnly, nodesOnly);
			}
		}
		//</mam>

		public virtual double GetOverallCriticality()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			return (double)component.GetOverallCriticality();
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public virtual double GetOverallCriticality(bool pipesOnly, bool nodesOnly)
		{
			decimal tempValue = 0m;

			if (pipesOnly)
			{
				DisciplinePipe discipline = this as DisciplinePipe;
				tempValue = (decimal)discipline.GetAverageCriticality();
			}
			else if (nodesOnly)
			{
				DisciplineNode discipline = this as DisciplineNode;
				tempValue = (decimal)discipline.GetAverageCriticality();
			}
			if (pipesOnly || nodesOnly)
			{
				if (tempValue == 0)
				{
					tempValue = -1;
				}
				return (double)tempValue;
			}
			else
			{
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				return (double)component.GetOverallCriticality(pipesOnly, nodesOnly);
			}
		}
		//mam

		//mam - change to double
		//public virtual Vulnerability GetVulnerability()
		public virtual double GetVulnerability()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			return component.Vulnerability;
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public virtual double GetVulnerability(bool pipesOnly, bool nodesOnly)
		{
			decimal tempValue = 0m;

			if (pipesOnly)
			{
				DisciplinePipe discipline = this as DisciplinePipe;
				tempValue = discipline.GetCurrentValue();

				if (tempValue == 0 || (discipline.GetAllERULZero() && !discipline.GetAnyVulnerabilityOverridden()))
					tempValue = -1;
				else
					tempValue = (decimal)discipline.GetAverageVulnerability();

				return (double)tempValue;
			}
			else if (nodesOnly)
			{
				DisciplineNode discipline = this as DisciplineNode;
				tempValue = discipline.GetCurrentValue();

				if (tempValue == 0 || (discipline.GetAllERULZero() && !discipline.GetAnyVulnerabilityOverridden()))
					tempValue = -1;
				else
					tempValue = (decimal) discipline.GetAverageVulnerability();

				return (double)tempValue;
			}
			else
			{
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				return component.Vulnerability;
			}
		}
		//mam

		public virtual double GetRisk()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			return (double)component.GetRisk();
		}

		//mam - need a way to get only pipes or only nodes for graphing
		public virtual double GetRisk(bool pipesOnly, bool nodesOnly)
		{
			decimal tempValue = 0m;

			if (pipesOnly)
			{
				DisciplinePipe discipline = this as DisciplinePipe;
				tempValue = discipline.GetCurrentValue();

				if (tempValue == 0 || (discipline.GetAllERULZero() && !discipline.GetAnyVulnerabilityOverridden()))
					tempValue = -1;
				else
					tempValue = (decimal)discipline.GetAverageRisk();

				return (double)tempValue;
			}
			else if (nodesOnly)
			{
				DisciplineNode discipline = this as DisciplineNode;
				tempValue = discipline.GetCurrentValue();

				if (tempValue == 0 || (discipline.GetAllERULZero() && !discipline.GetAnyVulnerabilityOverridden()))
					tempValue = -1;
				else
					tempValue = (decimal)discipline.GetAverageRisk();

				return (double)tempValue;
			}
			else
			{
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				return (double)component.GetRisk(pipesOnly, nodesOnly);
			}
		}
		//</mam>

		//mam - need a way to get only pipes or only nodes for graphing
		public double GetCondition(bool pipesOnly, bool nodesOnly)
		{
			if (pipesOnly)
			{
				DisciplinePipe discipline = this as DisciplinePipe;

				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				bool allNA = commonTasks.GetAllConditionNA(discipline);
				commonTasks = null;

				//if all nodes have condition = n/a, return zero
				if (allNA)
					return -1;
				else
					return (double)discipline.GetAverageCondition();
			}
			else if (nodesOnly)
			{
				DisciplineNode discipline = this as DisciplineNode;

				WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
				bool allNA = commonTasks.GetAllConditionNA(discipline);
				commonTasks = null;

				//if all nodes have condition = n/a, return -1 (an invalid value for Condition)
				if (allNA)
					return -1;
				else
					return (double)discipline.GetAverageCondition();
			}
			else
			{
				MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
				return (double)component.GetRankPercentInterpolated(pipesOnly, nodesOnly);
			}
		}
		//</mam>

		//mam - added this method
		public virtual double		GetAverageConditionForInterpolatedRank()
		{
			return 0;
		}
		//</mam>

		#endregion /***** Calculation Methods *****/

		#region / ***** Local Calculation Properties and Methods for Sorting *****/

		private short SortOrgUsefulLifeLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return OrgUsefulLife;
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else
					return (short)Math.Round((double)SortOrgUsefulLife(), 1);
			}
		}

		private double SortGetRemainingUsefulLifeLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return GetRemainingUsefulLife();
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else
					return Math.Round(SortGetRemainingUsefulLife(), 1);
			}
		}

		private double SortGetEvaluatedRemainingUsefulLifeLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return GetEvaluatedRemainingUsefulLife();
			else
			{
				if (totalCurrentValueSort == 0 || isNA)
					return -1;
				else
					return Math.Round(SortGetEvaluatedRemainingUsefulLife(), 1);
			}
		}

		//mam
		private double SortGetEconomicUsefulLifeLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return GetEconomicUsefulLife();
			else
			{
				if (totalCurrentValueSort == 0 || isNA)
					return -1;
				else
					return Math.Round(SortGetEconomicUsefulLife(), 1);
			}
		}
		//</mam>

		private decimal SortGetRepairCostLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return GetRepairCost();
			else
			{
				if (isNA)
					return -1;
				else
					return Math.Round(SortGetRepairCost(), 0);
			}
		}

		private decimal SortGetEvaluatedValueLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return GetEvaluatedValue();
			else
			{
				if (isNA)
					return -1;
				else
					return Math.Round(SortGetEvaluatedValue(), 0);
			}
		}

		//mam - new method to return value based on Discipline type
		private decimal SortConditionRankingLocal
		{
			get 
			{ 
				MajorComponent	component = 
					CacheManager.GetMajorComponent(m_infoSetID, ComponentID);

				if (component.MechStructDisciplines)
					return (decimal)(CondRank)m_conditionRanking;
				else
				{
					if (totalCurrentValueSort == 0 || isNA)
						return -1;
					else
						return Math.Round(SortConditionRanking, 1);
				}
			}
			set {}
		}

		//mam
		private decimal SortGetLevelOfServiceLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
				return (decimal)component.LOS;
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else
					return Math.Round(SortGetLevelOfService(), 1);
			}
		}
		//</mam>

		//mam
		private double SortGetOverallCriticalityLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
			{
				//return (double)component.GetOverallCriticality();
				//return -1 because there is no overall criticality for MSL disciplines
				return -1;
			}
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else
					return Math.Round(SortGetOverallCriticality(), 1);
			}
		}
		//</mam>

		//mam
		private decimal SortGetVulnerabilityLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
			{
				//return component.Vulnerability;
				//return -1 because there is no vulnerability for MSL disciplines
				return -1;
			}
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else if (isNA && allERULzero && !anyORVuln)
					return -1;
				else
					return Math.Round(SortGetVulnerability(), 4);
			}
		}
		//</mam>

		//mam
		private double SortGetRiskLocal()
		{
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.MechStructDisciplines)
			{
				//return (double)component.GetRisk();
				//return -1 because there is no Risk for MSL disciplines
				return -1;
			}
			else
			{
				if (totalCurrentValueSort == 0)
					return -1;
				else if (isNA && allERULzero && !anyORVuln)
					return -1;
				else
				{
					return Math.Round(SortGetRisk(), 2);
				}
			}
		}
		//</mam>

		#endregion / ***** Local Calculation Properties and Methods for Sorting *****/

		#region / ***** Calculation Properties and Methods for Sorting *****/

		public virtual short SortOrgUsefulLife()
		{
			return (short)Math.Round((double)SortOrgUsefulLife(), 1);
		}

		public virtual double SortGetRemainingUsefulLife()
		{
			return Math.Round(SortGetRemainingUsefulLife(), 1);
		}

		public virtual double SortGetEvaluatedRemainingUsefulLife()
		{
			return Math.Round(SortGetEvaluatedRemainingUsefulLife(), 1);
		}

		//mam
		public virtual double SortGetEconomicUsefulLife()
		{
			return Math.Round(SortGetEconomicUsefulLife(), 1);
		}
		//</mam>

		public virtual decimal SortGetRepairCost()
		{
			return Math.Round(SortGetRepairCost(), 0);
		}

		public virtual decimal SortGetEvaluatedValue()
		{
			return Math.Round(SortGetEvaluatedValue(), 0);
		}

		//mam - new method to return value based on Discipline type
		public virtual decimal SortConditionRanking
		{
			get 
			{ 
				return Math.Round(SortConditionRanking, 1);
			}
			set {}
		}

		//mam
		public virtual decimal SortGetLevelOfService()
		{
			return Math.Round(SortGetLevelOfService(), 1);
		}
		//</mam>

		//mam
		public virtual double SortGetOverallCriticality()
		{
			return Math.Round(SortGetOverallCriticality(), 1);
		}
		//</mam>

		//mam
		public virtual decimal SortGetVulnerability()
		{
			return Math.Round(SortGetVulnerability(), 4);
		}
		//</mam>

		//mam
		public virtual double SortGetRisk()
		{
			return Math.Round(SortGetRisk(), 2);
		}
		//</mam>

		#endregion / ***** Calculation Properties and Methods for Sorting *****/

		#region /***** Methods *****/

		//mam 102309
		//public abstract string GetInsertSqlForCopy();

		//mam 102309
		//public abstract string GetUpdateSqlForImport();

		//mam 102309 - override Drive.Data.SqlClient.Save because it does not distinguish between inserting and updating
//		public override bool Save()
//		{
//			return false;
//		}

		//mam
		public static DisciplineComparerBase GetComparerBase()
		{
			return new Discipline.DisciplineComparerBase();
		}
		//</mam>

		public virtual void	CopyTo(Discipline copy)
		{
			//copy.m_componentID = 0; // Don't copy ComponentID
			copy.m_conditionRanking = m_conditionRanking;
			copy.m_CWPAssetValue = m_CWPAssetValue;
			copy.m_orgUsefulLife = m_orgUsefulLife;
			copy.m_installationYear = m_installationYear;
			copy.m_currentENR = m_currentENR;
			copy.m_acquisitionCost = m_acquisitionCost;
			copy.m_overrideAcquisitionCost = m_overrideAcquisitionCost;
			copy.m_overrideVulnerability = m_overrideVulnerability;
			copy.m_replacementValue = m_replacementValue;
			copy.m_salvageValue = m_salvageValue;
			copy.m_annualMaintCost = m_annualMaintCost;
			copy.m_originalENR = m_originalENR;

			//mam 050806
			copy.m_rehabCost = m_rehabCost;

			//mam 07072011 begin
			copy.m_rehabCostYear = m_rehabCostYear;
			copy.m_rehabInterval = m_rehabInterval;
			copy.m_rehabNext = m_rehabNext;

			//mam 01222012 - no longer using override for Time to Next Rehab
			//copy.m_overrideRehabNext = m_overrideRehabNext;

			copy.m_rehabYearLast = m_rehabYearLast;
			copy.m_rehabYearNext = m_rehabYearNext;
			//mam 07072011 end

			//mam 07072011
			copy.m_nextReplacementYear = m_nextReplacementYear;
			copy.m_overrideNextReplacementYear = m_overrideNextReplacementYear;

			//mam 01222012
			copy.m_replacementValueDesc = m_replacementValueDesc;
			copy.m_rehabCostDesc = m_rehabCostDesc;
			copy.m_replacementNext = m_replacementNext;
			copy.m_overrideRehabYearNext = m_overrideRehabYearNext;

			//mam
			copy.m_currentValue = m_currentValue;
			copy.m_overrideCurrentValue = m_overrideCurrentValue;
			//</mam>

			//mam 050806
			copy.m_replacementValueYear = m_replacementValueYear;
			copy.m_repairCost = m_repairCost;
			copy.m_overrideRepairCost = m_overrideRepairCost;
		}

		//mam - allow or disallow copying of photo
		public virtual void	CopyTo(Discipline copy, bool copyPhoto, ref C1.Win.C1FlexGrid.C1FlexGrid gridErrors)
		{
			//copy.m_componentID = 0; // Don't copy ComponentID
			copy.m_conditionRanking = m_conditionRanking;
			copy.m_CWPAssetValue = m_CWPAssetValue;
			copy.m_orgUsefulLife = m_orgUsefulLife;
			copy.m_installationYear = m_installationYear;
			copy.m_currentENR = m_currentENR;
			copy.m_acquisitionCost = m_acquisitionCost;
			copy.m_overrideAcquisitionCost = m_overrideAcquisitionCost;
			copy.m_overrideVulnerability = m_overrideVulnerability;
			copy.m_replacementValue = m_replacementValue;
			copy.m_salvageValue = m_salvageValue;
			copy.m_annualMaintCost = m_annualMaintCost;
			copy.m_originalENR = m_originalENR;

			//mam 050806
			copy.m_rehabCost = m_rehabCost;

			//mam 07072011 begin
			copy.m_rehabCostYear = m_rehabCostYear;
			copy.m_rehabInterval = m_rehabInterval;
			copy.m_rehabNext = m_rehabNext;

			//mam 01222012 - no longer using override for Time to Next Rehab
			//copy.m_overrideRehabNext = m_overrideRehabNext;

			copy.m_rehabYearLast = m_rehabYearLast;
			copy.m_rehabYearNext = m_rehabYearNext;
			//mam 07072011 end

			//mam 07072011
			copy.m_nextReplacementYear = m_nextReplacementYear;
			copy.m_overrideNextReplacementYear = m_overrideNextReplacementYear;

			//mam 01222012
			copy.m_replacementValueDesc = m_replacementValueDesc;
			copy.m_rehabCostDesc = m_rehabCostDesc;
			copy.m_replacementNext = m_replacementNext;
			copy.m_overrideRehabYearNext = m_overrideRehabYearNext;

			//mam
			copy.m_currentValue = m_currentValue;
			copy.m_overrideCurrentValue = m_overrideCurrentValue;
			//</mam>

			//mam 050806
			copy.m_replacementValueYear = m_replacementValueYear;
			copy.m_repairCost = m_repairCost;
			copy.m_overrideRepairCost = m_overrideRepairCost;
		}

		public virtual bool	SaveAsXML(string filePath)
		{
			System.IO.FileStream file = null;
			System.IO.StreamWriter writer = null;

			try
			{
				file = new System.IO.FileStream(filePath, 
					System.IO.FileMode.Create, System.IO.FileAccess.Write);

				writer = new System.IO.StreamWriter(file);

				//mam - added parameters - always get photos when displaying data in the application
				//	and pass in an empty string for the selectedFilters, which only apply to reports
				writer.Write(GetXML(true, ""));
				//</mam>

				writer.Flush();
				writer.Close();
				writer = null;
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}
			return true;
		}

		//mam - added parameter
		public virtual string GetXML(bool includePhotos, string selectedFilters)
		{
			return "";
		}

		//mam
		public string GetCSVData(string selectedFilters, string selectedSortOrder, ArrayList filteredItems, bool includePipesNodes)
		{
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			Discipline discipline = null;
			MajorComponent component = null;
			TreatmentProcess process = null;
			Facility facility = null;

			//mam 07072011
			int critCount = Common.CommonTasks.Criticalities.Count;

			if (includePipesNodes)
                builder.Append("Discipline Detail Report");
			else
				builder.Append("Discipline Summary Report");

			builder.Append("\r\n");

			if (selectedFilters != "")
			{
				//modify selectedFilters language if report is a detail report
				if (includePipesNodes)
				{
					selectedFilters = selectedFilters.Replace("This", "Each");
					selectedFilters = selectedFilters.Replace("has", "in this report has");
				}

				builder.Append("\r\n");
				//builder.AppendFormat((char)34 + selectedFilters + (char)34);
				builder.AppendFormat(selectedFilters);
				builder.Append("\r\n\r\n");
			}

			//include sort order on both summary and detail CSV reports
			//if (selectedSortOrder != "" && !includePipesNodes)
			if (selectedSortOrder != "")
			{
				builder.AppendFormat((char)34 + selectedSortOrder + (char)34);
				builder.Append("\r\n\r\n");
			}

			builder.Append((char)34 + "Facility / System" + (char)34);
			builder.Append("," + (char)34 + "Treatment Process / Basin / Zone" + (char)34);
			builder.Append("," + (char)34 + "Major Component / Subbasin / Subzone" + (char)34);
			builder.Append("," + (char)34 + "Discipline" + (char)34);

			if (includePipesNodes)
				builder.Append("," + (char)34 + "Pipe/Node ID" + (char)34);

			builder.Append("," + (char)34 + "Component Retired" + (char)34);

			builder.Append("," + (char)34 + "Facility Current Year" + (char)34);
			builder.Append("," + (char)34 + "Facility Current ENR" + (char)34);
			builder.Append("," + (char)34 + "Discipline Installation Year" + (char)34);
			builder.Append("," + (char)34 + "Discipline Original ENR" + (char)34);

			//builder.Append(",CWP");
			builder.Append("," + (char)34 + "Acquisition Cost" + (char)34);
			builder.Append("," + (char)34 + "Override Acquisition Cost" + (char)34);
			builder.Append("," + (char)34 + "Current Value" + (char)34);
			builder.Append("," + (char)34 + "Override Current Value" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Escalated Acquisition Cost" + (char)34);

			builder.Append("," + (char)34 + "Replacement Value" + (char)34);

			//mam 01222012
			builder.Append("," + (char)34 + "Replacement Value Source/Description" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Replacement Value Year" + (char)34);
			builder.Append("," + (char)34 + "Replacement Value Year ENR" + (char)34);

			//mam 01222012
			builder.Append("," + (char)34 + "Time to Next Replacement" + (char)34);

			//mam 07072011
			builder.Append("," + (char)34 + "Next Replacement Year" + (char)34);
			builder.Append("," + (char)34 + "Override Next Replacement Year" + (char)34);

			builder.Append("," + (char)34 + "Rehabilitation Cost" + (char)34);

			//mam 01222012
			builder.Append("," + (char)34 + "Rehabilitation Cost Source/Description" + (char)34);

			//mam 07072011 begin
			builder.Append("," + (char)34 + "Rehabilitation Cost Year" + (char)34);
			builder.Append("," + (char)34 + "Rehabilitation Interval" + (char)34);
			builder.Append("," + (char)34 + "Last Rehabilitation Year" + (char)34);
			builder.Append("," + (char)34 + "Time to Next Rehabilitation" + (char)34);

			//mam 01222012 - no longer using override for Time to Next Rehabilitation
			//builder.Append("," + (char)34 + "Override Time to Next Rehabilitation" + (char)34);

			builder.Append("," + (char)34 + "Next Rehabilitation Year" + (char)34);
			//mam 07072011 end

			//mam 01222012
			builder.Append("," + (char)34 + "Override Next Rehabilitation Year" + (char)34);

			builder.Append("," + (char)34 + "Book Value" + (char)34);
			builder.Append("," + (char)34 + "Salvage Value" + (char)34);
			builder.Append("," + (char)34 + "Annual Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Cumulative Depreciation" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Value" + (char)34);
			builder.Append("," + (char)34 + "Repair Cost" + (char)34);

			//mam 050806
			builder.Append("," + (char)34 + "Override Repair Cost" + (char)34);

			builder.Append("," + (char)34 + "Annual Maintenance Cost" + (char)34);

			if (includePipesNodes)
			{
				//mam 050806
				builder.Append("," + (char)34 + "Number of Assets with Similar Functionality" + (char)34);

				//mam 07072011 - no longer using four fixed crits
				//builder.Append("," + (char)34 + "Criticality - Public Health and Safety" + (char)34);
				//builder.Append("," + (char)34 + "Criticality - Environmental" + (char)34);
				//builder.Append("," + (char)34 + "Criticality - Cost of Repairs" + (char)34);
				//builder.Append("," + (char)34 + "Criticality - Effect on Customers" + (char)34);

				//mam 07072011 - new crits
				foreach (Criticality crit in Common.CommonTasks.Criticalities)
				{
					string critNumberText = "Crit" + crit.CriticalityNumber.ToString();
					builder.Append("," + (char)34 + "Criticality - " + crit.CriticalityName + (char)34);
				}
			}
			builder.Append("," + (char)34 + "Overall Criticality" + (char)34);
			builder.Append("," + (char)34 + "Vulnerability" + (char)34);
			if (includePipesNodes)
			{
				builder.Append("," + (char)34 + "Override Vulnerability" + (char)34);
			}
			builder.Append("," + (char)34 + "Risk" + (char)34);
			builder.Append("," + (char)34 + "Level of Service" + (char)34);
			builder.Append("," + (char)34 + "Condition" + (char)34);
			builder.Append("," + (char)34 + "Original Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Evaluated Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Economic Remaining Useful Life" + (char)34);
			builder.Append("," + (char)34 + "Date of Inspection" + (char)34);
			builder.Append("," + (char)34 + "Equipment/ID Number" + (char)34);
			builder.Append("," + (char)34 + "Manufacturer" + (char)34);
			builder.Append("," + (char)34 + "Assessed By" + (char)34);

			//mam 112806
			builder.Append("," + (char)34 + "Run Hours" + (char)34);
			builder.Append("," + (char)34 + "Running at Inspection" + (char)34);

			if (includePipesNodes)
			{
				builder.Append("," + (char)34 + "Pipe Cost Weighted Percentage of Asset Value (%)" + (char)34);
				builder.Append("," + (char)34 + "ID Number" + (char)34);
				builder.Append("," + (char)34 + "Description" + (char)34);
				builder.Append("," + (char)34 + "Type" + (char)34);
				builder.Append("," + (char)34 + "Diameter (in)" + (char)34);
				builder.Append("," + (char)34 + "Length (ft)" + (char)34);
				builder.Append("," + (char)34 + "Unit Cost ($/ft)" + (char)34);
				builder.Append("," + (char)34 + "Installation Year" + (char)34);
				builder.Append("," + (char)34 + "Original ENR" + (char)34);
			}

			//mam 011206
			builder.Append("," + (char)34 + "Comments" + (char)34);

			//mam 112806 - added discipline component info for MSC disciplines
			//mech
			builder.Append("," + (char)34 + "Mech Excessive Vibration" + (char)34);
			builder.Append("," + (char)34 + "Mech Excessive Noise" + (char)34);
			builder.Append("," + (char)34 + "Mech Excessive Corrosion" + (char)34);
			builder.Append("," + (char)34 + "Mech Excessive Leaks" + (char)34);
			builder.Append("," + (char)34 + "Mech Running Hot" + (char)34);
			builder.Append("," + (char)34 + "Mech Can Run When Inspected" + (char)34);
			builder.Append("," + (char)34 + "Mech Support Equipment Functional" + (char)34);
			builder.Append("," + (char)34 + "Mech Parts Missing" + (char)34);
			builder.Append("," + (char)34 + "Mech Parts Available" + (char)34);
			builder.Append("," + (char)34 + "Mech Adequate" + (char)34);
			builder.Append("," + (char)34 + "Mech Motor Amps" + (char)34);
			builder.Append("," + (char)34 + "Mech Instrument Indication Functional" + (char)34);
			builder.Append("," + (char)34 + "Mech Instrument Alarms Functional" + (char)34);
			builder.Append("," + (char)34 + "Mech Instrument Parts Missing" + (char)34);
			builder.Append("," + (char)34 + "Mech Instrument Parts Available" + (char)34);
			builder.Append("," + (char)34 + "Mech Electrical Excessive Corrosion" + (char)34);
			builder.Append("," + (char)34 + "Mech Electrical Clean Contacts" + (char)34);
			builder.Append("," + (char)34 + "Mech Electrical Parts Available" + (char)34);
			builder.Append("," + (char)34 + "Mech Piping Excessive Corrosion" + (char)34);
			builder.Append("," + (char)34 + "Mech Piping Excessive Leaks" + (char)34);
			builder.Append("," + (char)34 + "Mech Piping Paint Good" + (char)34);

			//struct
			builder.Append("," + (char)34 + "Struct Concrete Spalling" + (char)34);
			builder.Append("," + (char)34 + "Struct Excessive Corrosion" + (char)34);
			builder.Append("," + (char)34 + "Struct Member Excessive Corrosion" + (char)34);
			builder.Append("," + (char)34 + "Struct Corrosion Coating" + (char)34);
			builder.Append("," + (char)34 + "Struct Paint Good" + (char)34);
			builder.Append("," + (char)34 + "Struct Visible Deformities" + (char)34);
			builder.Append("," + (char)34 + "Struct Settling Evident" + (char)34);
			builder.Append("," + (char)34 + "Struct Major Cracks" + (char)34);
			
			//civil
			builder.Append("," + (char)34 + "Civil Several Potholes" + (char)34);
			builder.Append("," + (char)34 + "Civil Excessive Erosion" + (char)34);
			builder.Append("," + (char)34 + "Civil Road Degradation" + (char)34);
			builder.Append("," + (char)34 + "Civil Expansion Space" + (char)34);
			builder.Append("," + (char)34 + "Civil Functional Ground Cover" + (char)34);
			builder.Append("," + (char)34 + "Civil Fencing Adequate" + (char)34);
			builder.Append("," + (char)34 + "Civil Facilities Secure" + (char)34);
			builder.Append("," + (char)34 + "Civil Clay Liner" + (char)34);
			builder.Append("," + (char)34 + "Civil Berm Erosion Interior" + (char)34);
			builder.Append("," + (char)34 + "Civil Berm Erosion Exterior" + (char)34);
			builder.Append("," + (char)34 + "Civil Berm Vegetation" + (char)34);
			builder.Append("," + (char)34 + "Civil Berm Settlement" + (char)34);
			builder.Append("," + (char)34 + "Civil Berm Seepage" + (char)34);
			builder.Append("," + (char)34 + "Civil Burrow Holes" + (char)34);
			builder.Append("," + (char)34 + "Civil Erosion Protection Present" + (char)34);
			builder.Append("," + (char)34 + "Civil Erosion Protection Adequate" + (char)34);
			builder.Append("," + (char)34 + "Civil Algal Blooms" + (char)34);
			builder.Append("," + (char)34 + "Civil Drainage Adequate" + (char)34);

			//mam 03202012
			builder.Append("," + (char)34 + "Photo File" + (char)34);
			builder.Append("," + (char)34 + "Photo Caption" + (char)34);

			//**************************************

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				discipline = (Discipline)filteredItems[pos];

				if ((Discipline)filteredItems[pos] is DisciplinePipe)
				{
					string csvPipeNode = GetCSVDataPipe(selectedFilters, (DisciplinePipe)filteredItems[pos], includePipesNodes);
					builder.Append(csvPipeNode);
					continue;
				}
				else if ((Discipline)filteredItems[pos] is DisciplineNode)
				{
					string csvPipeNode = GetCSVDataNode(selectedFilters, (DisciplineNode)filteredItems[pos], includePipesNodes);
					builder.Append(csvPipeNode);
					continue;
				}

				component = discipline.GetMajorComponent();
				process = CacheManager.GetTreatmentProcess(discipline.InfoSetID, component.ProcessID);
				facility = CacheManager.GetFacility(discipline.InfoSetID, process.FacilityID);

				//mam 01222012
				PlanningMode planningMode = PlanningMode.Rehabilitation;
				if (component.CipPlanningId == Common.CommonTasks.ZeroRehabCostCipPlanningId)
				{
					planningMode = PlanningMode.Replacement;
				}

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + (char)34);

				if (includePipesNodes)
					builder.Append(",N/A");

				//mam 112806
				//builder.AppendFormat(",{0}", Convert.ToBoolean(component.Retired));
				builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				builder.AppendFormat(",{0}", facility.CurrentYear);
				builder.AppendFormat(",{0}", facility.CurrentENR);
				builder.AppendFormat(",{0}", discipline.InstallationYear);

				//if (component.MechStructDisciplines)
					builder.AppendFormat(",{0}", discipline.OriginalENR);
				//else
				//	builder.AppendFormat(",{0}", "N/A");					

				//mam 050806
				//builder.Append(",YEAR");
				//builder.Append(",ENR");

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//acquisition cost	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.AcquisitionCost);
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//override acquisition cost OROR	//XXXX
				}
				else
				{
					//mam
					if (discipline.m_overrideAcquisitionCost)
						builder.AppendFormat(",{0}", "TRUE");
					else
						builder.AppendFormat(",{0}", "");
					//</mam>
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//current value	//XXXX
				}
				else
				{
					//mam 112806 - check condition and override
					if (discipline.ConditionRanking != CondRank.No)
					{
						builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
					}
					else if (discipline.OverrideCurrentValue)
					{
						builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
					}
					else
					{
						builder.Append(",N/A");
					}
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//override current value OROR	//XXXX
				}
				else
				{
					//mam
					if (discipline.m_overrideCurrentValue)
						builder.AppendFormat(",{0}", "TRUE");
					else
						builder.AppendFormat(",{0}", "");
					//</mam>
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//escalated acquisition cost	//XXXX
					builder.Append(",0");	//replacement value	//XXXX

					//mam 01222012
					builder.Append(",0");	//replacement value source/description	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", discipline.AcquisitionCostEscalated);

					builder.AppendFormat(",{0:F0}", discipline.ReplacementValue);

					//mam 01222012
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.ReplacementValueDesc));
				}

				//mam 050806
				builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);
				builder.AppendFormat(",{0}", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));
				//builder.AppendFormat(",{0:F0}", discipline.ReplacementENR);

				//mam 01222012
				if (planningMode == PlanningMode.Rehabilitation)
				{
					//values are always zero if planning mode is rehabilitation
					builder.AppendFormat(",{0:F1}", 0);
					builder.AppendFormat(",{0:F0}", 0);
				}
				else if (discipline.OverrideNextReplacementYear)
				{
					//planning mode = replacement; always show values when next replacement year is overridden
					builder.AppendFormat(",{0:F1}", discipline.ReplacementNext);
					builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);
				}
				else
				{
					//planning mode = replacement; values are N/A when condition is N/A
					if (discipline.ConditionRanking == CondRank.No)
					{
						builder.Append(",N/A");	//Time to Next Replacement
						builder.AppendFormat(",{0}", "N/A");	//next replacement year
					}
					else
					{
						//planning mode = replacement
						builder.AppendFormat(",{0:F1}", discipline.ReplacementNext);
						builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);
					}
				}

				//mam 07072011
				//mam 01222012 - moved up
				//builder.AppendFormat(",{0:F0}", discipline.NextReplacementYear);

				builder.AppendFormat(",{0:F0}", discipline.OverrideNextReplacementYear);

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//rehabilitation cost	//XXXX

					//mam 01222012
					builder.Append(",0");	//rehab cost source/description	//XXXX
				}
				else
				{
					//mam 050806
					builder.AppendFormat(",{0:F0}", discipline.RehabCost);

					//mam 01222012
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.RehabCostDesc));
				}

				//mam 07072011 begin
				builder.AppendFormat(",{0:F0}", discipline.RehabCostYear);

				//mam 01222012 - moved down
				//builder.AppendFormat(",{0:F1}", discipline.RehabInterval);
				//builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);

				//*************************
				//mam 01222012
				//last rehab year is always a value, regardless of planning mode, condition, or whether next rehab year is overridden
				if (planningMode == PlanningMode.Replacement)
				{
					//values are always zero if planning mode is replacement
					builder.AppendFormat(",{0:F1}", 0);	//rehab interval
					builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);
					builder.AppendFormat(",{0:F1}", 0);	//time to next rehab
					builder.AppendFormat(",{0:F0}", 0);	//next rehab year
				}
				else if (discipline.OverrideRehabYearNext)
				{
					//planning mode = rehabilitation; always show values when next rehab year is overridden
					builder.AppendFormat(",{0:F1}", discipline.RehabInterval);
					builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);
					builder.AppendFormat(",{0:F1}", discipline.RehabNext);
					builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);
				}
				else
				{
					//planning mode = rehabilitation; values are N/A when condition is N/A
					if (discipline.ConditionRanking == CondRank.No)
					{
						builder.Append(",N/A");	//rehab interval
						builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);
						builder.Append(",N/A");	//time to next rehab
						builder.Append(",N/A");	//next rehab year
					}
					else
					{
						//planning mode = rehabilitation
						builder.AppendFormat(",{0:F1}", discipline.RehabInterval);
						builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);
						builder.AppendFormat(",{0:F1}", discipline.RehabNext);
						builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);
					}
				}
				//*************************

				//mam 01222012 - no longer using override for Time to Next Rehab
				//builder.AppendFormat(",{0:F0}", discipline.OverrideRehabNext);

				//mam 01222012 - moved up
				//builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);

				//mam 01222012
				builder.AppendFormat(",{0:F0}", discipline.OverrideRehabYearNext);
				//mam 07072011 end

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//book value	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.GetBookValue());
				}

				builder.AppendFormat(",{0:F0}", discipline.SalvageValue);

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//annual depreciation	//XXXX
					builder.Append(",0");	//cumulative depreciation	//XXXX
				}
				else
				{
					builder.AppendFormat(",{0:F0}", discipline.GetAnnualDepreciation());
					builder.AppendFormat(",{0:F0}", discipline.GetCumulativeDepreciation());
				}

				//builder.AppendFormat(",{0:F0}", discipline.GetEvaluatedValue());

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//evaluated value	//XXXX
					builder.Append(",0");	//repair cost	//XXXX
				}
				else
				{
					//mam 112806 - check condition and override
					if (discipline.ConditionRanking != CondRank.No)
					{
						builder.AppendFormat(",{0:F0}", discipline.GetEvaluatedValue());
						builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
					}
					else
					{
						builder.Append(",N/A");	//evaluated value
						if (discipline.OverrideRepairCost)
						{
							builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
						}
						else
						{
							builder.Append(",N/A");
						}
					}
				}

				//mam 01042012 - if component is retired, show zero on report
				if (component.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.Append(",0");	//override repair cost OROR	//XXXX
				}
				else
				{
					//mam 050806
					if (discipline.m_overrideRepairCost)
						builder.AppendFormat(",{0}", "TRUE");
					else
						builder.AppendFormat(",{0}", "");
					//</mam>
				}

				builder.AppendFormat(",{0:F0}", discipline.AnnualMaintCost);

				if (includePipesNodes)
				{
					//mam 050806 - redundant asset count
					builder.Append(",N/A");

					//mam 07072011 - no longer using four fixed crits
					//four crit values
					//builder.Append(",N/A");
					//builder.Append(",N/A");
					//builder.Append(",N/A");
					//builder.Append(",N/A");

					//mam 07072011 - use correct number of crits
					for (int i = 0; i < critCount; i++)
					{
						builder.Append(",N/A");
					}
				}

				//overall crit, vuln
				builder.Append(",N/A");
				builder.Append(",N/A");

				//mam 050806
				if (includePipesNodes)
				{
					//override vuln
					builder.Append(",N/A");
				}

				//risk
				builder.Append(",N/A");

				//mam - shouldn't average condition be used for pipes and nodes?
				//	no - pipes and nodes don't get this far - they have their own methods, above (GetCSVDataPipe and GetCSVDataNode)
				builder.AppendFormat(",{0}", EnumHandlers.GetLOSShort(component.LOS));
				builder.AppendFormat(",{0}", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
				builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
				builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());


				//mam 112806 - check condition
				if (discipline.ConditionRanking == CondRank.No)
				{
					builder.Append(",N/A");	//EvRUL
					builder.Append(",N/A");	//EcRUL
				}
				else
				{
					builder.AppendFormat(",{0:F1}", discipline.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat(",{0:F1}", discipline.GetEconomicUsefulLife());
				}
				
				if (discipline is DisciplineLand)
				{
					builder.AppendFormat(",{0}", ((DisciplineLand)discipline).DateInspected.ToString("MM/dd/yyyy"));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineLand)discipline).EquipmentNumber));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineLand)discipline).Manufacturer));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineLand)discipline).AssessedBy));

					//mam 112806
					builder.Append(",N/A");	//RunHours;
					builder.Append(",N/A");	//RunningAtInspect;

					//mam 101107 - replace double quote in comments with two double quotes 
					string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineLand)discipline).Comments);

					//mam 011206
					if (includePipesNodes)
					{
						//mam 101107
						//builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + ((DisciplineLand)discipline).Comments + (char)34);
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + commentsQuotes + (char)34);
					}
					else
					{
						//mam 101107
						//builder.Append("," + (char)34 + ((DisciplineLand)discipline).Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);
					}

					//mam 112806
					//mechanical
					builder.Append(",N/A");	//MechExcessiveVibration
					builder.Append(",N/A");	//MechExcessiveNoise
					builder.Append(",N/A");	//MechExcessiveCorrosion
					builder.Append(",N/A");	//MechExcessiveLeaks
					builder.Append(",N/A");	//MechRunningHot
					builder.Append(",N/A");	//MechCanRunWhenInspected
					builder.Append(",N/A");	//MechSupportIsFunctional
					builder.Append(",N/A");	//MechPartsMissing
					builder.Append(",N/A");	//MechPartsAvailable
					builder.Append(",N/A");	//MechAdequate
					builder.Append(",N/A");	//MechMotorAmps
					builder.Append(",N/A");	//InstrIndicationFunctional
					builder.Append(",N/A");	//InstrAlarmFunctional
					builder.Append(",N/A");	//InstrPartsMissing
					builder.Append(",N/A");	//InstrPartsAvailable
					builder.Append(",N/A");	//ElecExcessiveCorrosion
					builder.Append(",N/A");	//ElecCleanContacts
					builder.Append(",N/A");	//ElecPartsAvailable
					builder.Append(",N/A");	//PipeExcessiveCorrosion
					builder.Append(",N/A");	//PipeExcessiveLeaks
					builder.Append(",N/A");	//PipePaintGood

					//structural
					builder.Append(",N/A");	//ConcreteSpalling
					builder.Append(",N/A");	//StructExcessiveCorrosion
					builder.Append(",N/A");	//MembExcessiveCorrosion
					builder.Append(",N/A");	//CorrosionCoating
					builder.Append(",N/A");	//PaintGood
					builder.Append(",N/A");	//VisibleDeformities
					builder.Append(",N/A");	//SettingEvident
					builder.Append(",N/A");	//MajorCracks

					//civil
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).SeveralPotholes) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).ExcessiveErosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).RoadDegradation) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).ExpansionSpace) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FunctionCover) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FencingAdequate) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).FacilitiesSecure) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppClayLiner) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermErosionInterior) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermErosionBermExterior) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermVegetation) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermSettlement) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBermSeepage) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppBurrowHoles) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppErosionProtectionPresent) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppErosionProtectionAdequate) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppAlgalBlooms) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineLand)discipline).LandAppDrainageAdequate) + (char)34);

					//mam 03202012
					string caption = ((DisciplineLand)discipline).CaptionPhoto1;
					caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
					builder.AppendFormat(",{0}", ((DisciplineLand)discipline).PhotoFileName);
					builder.AppendFormat(",{0}", caption);

				}
				else if (discipline is DisciplineMech)
				{
					builder.AppendFormat(",{0}", ((DisciplineMech)discipline).DateInspected.ToString("MM/dd/yyyy"));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineMech)discipline).EquipmentNumber));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineMech)discipline).Manufacturer));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineMech)discipline).AssessedBy));

					//mam 112806
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ((DisciplineMech)discipline).RunHours);
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ((DisciplineMech)discipline).RunningAtInspect);

					//mam 101107 - replace double quote in comments with two double quotes 
					string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineMech)discipline).Comments);

					//mam 011206
					if (includePipesNodes)
					{
						//mam 101107
						//builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + ((DisciplineMech)discipline).Comments + (char)34);
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + commentsQuotes + (char)34);
					}
					else
					{
						//mam 101107
						//builder.Append("," + (char)34 + ((DisciplineMech)discipline).Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);
					}

					//mam 112806
					//mechanical
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveVibration) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveNoise) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveCorrosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechExcessiveLeaks) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechRunningHot) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechCanRunWhenInspected) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechSupportIsFunctional) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechPartsMissing) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechPartsAvailable) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechAdequate) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).MechMotorAmps) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrIndicationFunctional) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrAlarmFunctional) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrPartsMissing)+ (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).InstrPartsAvailable) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecExcessiveCorrosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecCleanContacts) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).ElecPartsAvailable) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipeExcessiveCorrosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipeExcessiveLeaks) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineMech)discipline).PipePaintGood) + (char)34);

					//structural
					builder.Append(",N/A");	//ConcreteSpalling
					builder.Append(",N/A");	//StructExcessiveCorrosion
					builder.Append(",N/A");	//MembExcessiveCorrosion
					builder.Append(",N/A");	//CorrosionCoating
					builder.Append(",N/A");	//PaintGood
					builder.Append(",N/A");	//VisibleDeformities
					builder.Append(",N/A");	//SettingEvident
					builder.Append(",N/A");	//MajorCracks

					//civil
					builder.Append(",N/A");	//SeveralPotholes
					builder.Append(",N/A");	//ExcessiveErosion
					builder.Append(",N/A");	//RoadDegradation
					builder.Append(",N/A");	//ExpansionSpace
					builder.Append(",N/A");	//FunctionCover
					builder.Append(",N/A");	//FencingAdequate
					builder.Append(",N/A");	//FacilitiesSecure
					builder.Append(",N/A");	//LandAppClayLiner
					builder.Append(",N/A");	//LandAppBermErosionInterior
					builder.Append(",N/A");	//LandAppBermErosionBermExterior
					builder.Append(",N/A");	//LandAppBermVegetation
					builder.Append(",N/A");	//LandAppBermSettlement
					builder.Append(",N/A");	//LandAppBermSeepage
					builder.Append(",N/A");	//LandAppBurrowHoles
					builder.Append(",N/A");	//LandAppErosionProtectionPresent
					builder.Append(",N/A");	//LandAppErosionProtectionAdequate
					builder.Append(",N/A");	//LandAppAlgalBlooms
					builder.Append(",N/A");	//LandAppDrainageAdequate

					//mam 03202012
					string caption = ((DisciplineMech)discipline).CaptionPhoto;
					caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
					builder.AppendFormat(",{0}", ((DisciplineMech)discipline).PhotoFileName);
					builder.AppendFormat(",{0}", caption);
				}
				else if (discipline is DisciplineStruct)
				{
					builder.AppendFormat(",{0}", ((DisciplineStruct)discipline).DateInspected.ToString("MM/dd/yyyy"));

					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineStruct)discipline).EquipmentNumber));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineStruct)discipline).Manufacturer));
					builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineStruct)discipline).AssessedBy));

					//mam 112806
					builder.Append(",N/A");	//RunHours;
					builder.Append(",N/A");	//RunningAtInspect;

					//mam 101107 - replace double quote in comments with two double quotes 
					string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(((DisciplineStruct)discipline).Comments);

					//mam 011206
					if (includePipesNodes)
					{
						//mam 101107
						//builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + ((DisciplineStruct)discipline).Comments + (char)34);
						builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + commentsQuotes + (char)34);
					}
					else
					{
						//mam 101107
						//builder.Append("," + (char)34 + ((DisciplineStruct)discipline).Comments + (char)34);
						builder.Append("," + (char)34 + commentsQuotes + (char)34);
					}

					//mam 112806
					//mechanical
					builder.Append(",N/A");	//MechExcessiveVibration
					builder.Append(",N/A");	//MechExcessiveNoise
					builder.Append(",N/A");	//MechExcessiveCorrosion
					builder.Append(",N/A");	//MechExcessiveLeaks
					builder.Append(",N/A");	//MechRunningHot
					builder.Append(",N/A");	//MechCanRunWhenInspected
					builder.Append(",N/A");	//MechSupportIsFunctional
					builder.Append(",N/A");	//MechPartsMissing
					builder.Append(",N/A");	//MechPartsAvailable
					builder.Append(",N/A");	//MechAdequate
					builder.Append(",N/A");	//MechMotorAmps
					builder.Append(",N/A");	//InstrIndicationFunctional
					builder.Append(",N/A");	//InstrAlarmFunctional
					builder.Append(",N/A");	//InstrPartsMissing
					builder.Append(",N/A");	//InstrPartsAvailable
					builder.Append(",N/A");	//ElecExcessiveCorrosion
					builder.Append(",N/A");	//ElecCleanContacts
					builder.Append(",N/A");	//ElecPartsAvailable
					builder.Append(",N/A");	//PipeExcessiveCorrosion
					builder.Append(",N/A");	//PipeExcessiveLeaks
					builder.Append(",N/A");	//PipePaintGood

					//structural
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).ConcreteSpalling) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).StructExcessiveCorrosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).MembExcessiveCorrosion) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).CorrosionCoating) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).PaintGood) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).VisibleDeformities) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).SettingEvident) + (char)34);
					builder.Append("," + (char)34 + EnumHandlers.GetItemStatusShort(((DisciplineStruct)discipline).MajorCracks) + (char)34);

					//civil
					builder.Append(",N/A");	//SeveralPotholes
					builder.Append(",N/A");	//ExcessiveErosion
					builder.Append(",N/A");	//RoadDegradation
					builder.Append(",N/A");	//ExpansionSpace
					builder.Append(",N/A");	//FunctionCover
					builder.Append(",N/A");	//FencingAdequate
					builder.Append(",N/A");	//FacilitiesSecure
					builder.Append(",N/A");	//LandAppClayLiner
					builder.Append(",N/A");	//LandAppBermErosionInterior
					builder.Append(",N/A");	//LandAppBermErosionBermExterior
					builder.Append(",N/A");	//LandAppBermVegetation
					builder.Append(",N/A");	//LandAppBermSettlement
					builder.Append(",N/A");	//LandAppBermSeepage
					builder.Append(",N/A");	//LandAppBurrowHoles
					builder.Append(",N/A");	//LandAppErosionProtectionPresent
					builder.Append(",N/A");	//LandAppErosionProtectionAdequate
					builder.Append(",N/A");	//LandAppAlgalBlooms
					builder.Append(",N/A");	//LandAppDrainageAdequate

					//mam 03202012
					string caption = ((DisciplineStruct)discipline).CaptionPhoto;
					caption = ReplaceDoubleQuoteWithTwoDoubleQuotes(@caption);
					builder.AppendFormat(",{0}", ((DisciplineStruct)discipline).PhotoFileName);
					builder.AppendFormat(",{0}", caption);
				}
			}

			//mam 011206
			//builder.Append("," + (char)34 + component.Comments + (char)34);

			return builder.ToString();
		}
		//</mam>

		//mam
		public string GetCSVDataPipe(string selectedFilters, DisciplinePipe discipline, bool includePipesNodes)
		{
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			MajorComponent component = null;
			TreatmentProcess process = null;
			Facility facility = null;
			decimal totalCurrentValue = discipline.GetCurrentValue();
			bool useNA = GetAllConditionNA(discipline);
			string pipeDataXML = "";

			component = discipline.GetMajorComponent();
			process = CacheManager.GetTreatmentProcess(discipline.InfoSetID, component.ProcessID);
			facility = CacheManager.GetFacility(discipline.InfoSetID, process.FacilityID);

			builder.Append("\r\n");

			builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + " (Total and Average Values)" + (char)34);

			if (includePipesNodes)
			{
				//Pipe/Node ID
				builder.Append(",N/A");
			}

			//mam 112806
			builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

			builder.AppendFormat(",{0}", facility.CurrentYear);
			builder.AppendFormat(",{0}", facility.CurrentENR);

			//mam - this is the average installation year if a pipe or a node (otherwise, it's just the install year)
			builder.AppendFormat(",{0}", discipline.InstallationYear);

			//if it's a standard report, use ENR; otherwise, use N/A
			//if (includePipesNodes)
			//{
			//	//mam 050806 - get the ENR for the average installation year
			//	//builder.AppendFormat(",{0}", discipline.OriginalENR);
				builder.AppendFormat(",{0}", discipline.GetOriginalENR(Convert.ToInt16(discipline.InstallationYear)));
			//}
			//else
			//{
			//	builder.AppendFormat(",{0}", "N/A");
			//}

			builder.AppendFormat(",{0:F0}", discipline.AcquisitionCost);

			//spacer for override acquisition cost
			builder.Append(",N/A");

			//mam 112806 - check condition and override
			if (useNA && !discipline.GetAnyCurrentValueOverridden())
			{
				builder.Append(",N/A");
			}
			else
			{
				builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
			}

			//spacer for override current value
			builder.Append(",N/A");

			//mam 050806
			builder.AppendFormat(",{0:F0}", discipline.AcquisitionCostEscalated);

			builder.AppendFormat(",{0:F0}", discipline.ReplacementValue);

			//mam 01222012
			builder.Append(",N/A");	//placeholder for ReplacementValueDesc

			//mam 050806
			builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);
			//if (includePipesNodes)
			//{
			//	//get ENR value for average Replacement Value Year
				builder.AppendFormat(",{0}", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));
			//}
			//else
			//{
			//	builder.AppendFormat(",{0}", "N/A");
			//}

			//mam 03202012
			builder.Append(",N/A");	//time to next replacement

			//mam 07072011
			builder.Append(",N/A");	//discipline.NextReplacementYear
			builder.Append(",N/A");	//discipline.OverrideNextReplacementYear

			//mam 050806
			//builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);
			//builder.AppendFormat(",{0:F0}", discipline.ReplacementENR);
			builder.AppendFormat(",{0:F0}", discipline.RehabCost);

			//mam 01222012
			builder.Append(",N/A");	//placeholder for RehabCostDesc

			//mam 07072011 - add placeholders for new rehab values
			builder.Append(",N/A");	//discipline.RehabCostYear);
			//these rehab values are not in the main pipe data (only in the detail data)
			builder.Append(",N/A");	//discipline.RehabInterval);
			builder.Append(",N/A");	//discipline.RehabNext);
			builder.Append(",N/A");	//discipline.OverrideRehabNext)
			builder.Append(",N/A");	//discipline.RehabYearLast);
			builder.Append(",N/A");	//discipline.RehabYearNext);

			builder.AppendFormat(",{0:F0}", discipline.GetBookValue());
			builder.AppendFormat(",{0:F0}", discipline.SalvageValue);
			builder.AppendFormat(",{0:F0}", discipline.GetAnnualDepreciation());
			builder.AppendFormat(",{0:F0}", discipline.GetCumulativeDepreciation());

			if (useNA == true)
			{
				builder.Append(",N/A");	//evaluated value

				//mam 112806 - check override
				if (discipline.GetAnyRepairCostOverridden())
				{
					builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
				}
				else
				{
					builder.Append(",N/A");
				}
			}
			else
			{
				builder.AppendFormat(",{0:F0}", discipline.GetEvaluatedValue());
				builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
			}

			//mam 050806 - spacer for override repair cost
			builder.Append(",N/A");

			builder.AppendFormat(",{0:F0}", discipline.AnnualMaintCost);

			if (includePipesNodes)
			{
				//mam 050806 - spacer for Redundant Assets column
				builder.Append(",N/A");

				//spacers for four crit columns

				//mam 07072011 - no longer using four fixed crits
				//mam 090105 - changed to N/A
				////builder.Append(",");
				////builder.Append(",");
				////builder.Append(",");
				////builder.Append(",");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
				{
					builder.Append(",N/A");
				}
			}

			//if Total Current Value = zero, then OUL, LOS, Crit, Vuln, RUL, and Risk = N/A
			if (totalCurrentValue == 0)
			{
				//Avg Crit, Avg Vuln, Override Vuln, Avg Risk, 
				builder.Append(",N/A");
				builder.Append(",N/A");
				if (includePipesNodes)
				{
					builder.Append(",N/A");
				}
				builder.Append(",N/A");

				//Avg LOS, Avg Cond, OUL, RUL, EvRUL, EcRUL
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");

				//Economic Remaining Useful Life
				builder.Append(",N/A");
			}
			else
			{
				builder.AppendFormat(",{0:F1}", discipline.GetAverageCriticality());
				if (GetAllERULZero(discipline) && !GetAnyVulnerabilityOverridden(discipline))
				{
					builder.Append(",N/A");
					if (includePipesNodes)
					{
						builder.Append(",");
					}
					builder.Append(",N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat(",{0:F2}", discipline.GetAverageVulnerability());
					builder.AppendFormat(",{0:F4}", discipline.GetAverageVulnerability());
					if (includePipesNodes)
					{
						builder.Append(",");
					}
					builder.AppendFormat(",{0:F2}", discipline.GetAverageRisk());
				}

				builder.AppendFormat(",{0:F1}", discipline.GetAverageLOS());

				if (useNA)
				{
					builder.Append(",N/A");
					builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
					builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
					builder.Append(",N/A");
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F1}", discipline.GetAverageCondition());
					builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
					builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
					builder.AppendFormat(",{0:F1}", discipline.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat(",{0:F1}", discipline.GetEconomicUsefulLife());
				}
			}

			//inspection date, equip id, mfr, assessed by, run hours, running at inspection
			builder.AppendFormat(",{0}", discipline.DateInspected.ToString("MM/dd/yyyy"));
			builder.AppendFormat(",N/A");
			builder.AppendFormat(",N/A");
			builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.AssessedBy));
			builder.AppendFormat(",N/A");
			builder.AppendFormat(",N/A");

			//builder.AppendFormat(",{0}", discipline.DateInspected.ToString("MM/dd/yyyy"));
			//builder.AppendFormat(",{0}", discipline.AssessedBy);
			//builder.AppendFormat(",{0}", discipline.EquipmentNumber);
			//builder.AppendFormat(",{0}", discipline.Manufacturer);
			//builder.AppendFormat(",{0}", discipline.RunHours);
			//builder.AppendFormat(",{0}", discipline.RunningAtInspect);

			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_severalPotholes));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_excessiveErosion));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_roadDegradation));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_expansionSpace));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_functionCover));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_fencingAdequate));
			//builder.AppendFormat(",{0}", EnumHandlers.GetItemStatusShort(m_facilitiesSecure));

			//mam 101107 - replace double quote in comments with two double quotes 
			string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@discipline.Comments);

			//mam 011206
			if (includePipesNodes)
			{
				//mam 101107
				//builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + discipline.Comments + (char)34);
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + commentsQuotes + (char)34);
			}
			else
			{
				//mam 101107
				//builder.Append("," + (char)34 + discipline.Comments + (char)34);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);
			}

			//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");

			if (includePipesNodes)
			{
				pipeDataXML = GetCSVDataPipesDetail(discipline);
				builder.Append(pipeDataXML);
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		public string GetCSVDataNode(string selectedFilters, DisciplineNode discipline, bool includePipesNodes)
		{
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			MajorComponent component = null;
			TreatmentProcess process = null;
			Facility facility = null;
			decimal totalCurrentValue = discipline.GetCurrentValue();
			bool useNA = GetAllConditionNA(discipline);
			string nodeDataXML = "";

			component = discipline.GetMajorComponent();
			process = CacheManager.GetTreatmentProcess(discipline.InfoSetID, component.ProcessID);
			facility = CacheManager.GetFacility(discipline.InfoSetID, process.FacilityID);

			builder.Append("\r\n");

			builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
			//builder.Append("," + (char)34 + discipline.Name + (char)34);
			builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + " (Total and Average Values)" + (char)34);

			if (includePipesNodes)
			{
				//Pipe/Node ID
				builder.Append(",N/A");
			}

			//mam 112806
			builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

			builder.AppendFormat(",{0}", facility.CurrentYear);
			builder.AppendFormat(",{0}", facility.CurrentENR);
			builder.AppendFormat(",{0}", discipline.InstallationYear);

			//if it's a standard report, use ENR; otherwise, use N/A
			//mam 050806 - always show Original ENR
			//if (includePipesNodes)
			//{
				//mam 050806 - get the ENR for the average installation year
				//builder.AppendFormat(",{0}", discipline.OriginalENR);
				builder.AppendFormat(",{0}", discipline.GetOriginalENR(Convert.ToInt16(discipline.InstallationYear)));
			//}
			//else
			//{
			//	builder.AppendFormat(",{0}", "N/A");
			//}

			builder.AppendFormat(",{0:F0}", discipline.AcquisitionCost);

			//spacer for override acquisition cost
			builder.Append(",N/A");

			//mam 112806 - check condition and override
			if (useNA && !discipline.GetAnyCurrentValueOverridden())
			{
				builder.Append(",N/A");
			}
			else
			{
				builder.AppendFormat(",{0:F0}", discipline.GetCurrentValue());
			}

			//spacer for override current value
			builder.Append(",N/A");

			//mam 050806
			builder.AppendFormat(",{0:F0}", discipline.AcquisitionCostEscalated);

			builder.AppendFormat(",{0:F0}", discipline.ReplacementValue);

			//mam 01222012
			builder.Append(",N/A");	//placeholder for ReplacementValueDesc

			//mam 050806
			builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);
			//if (includePipesNodes)
			//{
				//get ENR value for average Replacement Value Year
				builder.AppendFormat(",{0}", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));
			//}
			//else
			//{
			//	builder.AppendFormat(",{0}", "N/A");
			//}

			//mam 03202012
			builder.Append(",N/A");	//time to next replacement

			//mam 07072011
			builder.Append(",N/A");	//discipline.NextReplacementYear
			builder.Append(",N/A");	//discipline.OverrideNextReplacementYear

//			//mam 050806
//			builder.AppendFormat(",{0:F0}", discipline.ReplacementValueYear);
//			builder.AppendFormat(",{0:F0}", discipline.ReplacementENR);
			builder.AppendFormat(",{0:F0}", discipline.RehabCost);

			//mam 01222012
			builder.Append(",N/A");	//placeholder for RehabCostDesc

			//mam 07072011 - add placeholders for new rehab values
			builder.Append(",N/A");	//discipline.RehabCostYear);
			//these rehab values are not in the main pipe data (only in the detail data)
			builder.Append(",N/A");	//discipline.RehabInterval);
			builder.Append(",N/A");	//discipline.RehabNext);
			builder.Append(",N/A");	//discipline.OverrideRehabNext)
			builder.Append(",N/A");	//discipline.RehabYearLast);
			builder.Append(",N/A");	//discipline.RehabYearNext);

			builder.AppendFormat(",{0:F0}", discipline.GetBookValue());
			builder.AppendFormat(",{0:F0}", discipline.SalvageValue);
			builder.AppendFormat(",{0:F0}", discipline.GetAnnualDepreciation());
			builder.AppendFormat(",{0:F0}", discipline.GetCumulativeDepreciation());

			if (useNA == true)
			{
				builder.Append(",N/A");	//evaluated value

				//mam 112806 - check override
				if (discipline.GetAnyRepairCostOverridden())
				{
					builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
				}
				else
				{
					builder.Append(",N/A");
				}
			}
			else
			{
				builder.AppendFormat(",{0:F0}", discipline.GetEvaluatedValue());
				builder.AppendFormat(",{0:F0}", discipline.GetRepairCost());
			}

			//mam 050806 - spacer for override repair cost
			builder.Append(",N/A");

			builder.AppendFormat(",{0:F0}", discipline.AnnualMaintCost);

			if (includePipesNodes)
			{
				//mam 050806 - spacer for Redundant Assets column
				builder.Append(",N/A");

				//spacers for four crit columns

				//mam 07072011 - no longer using four fixed crits
				//mam 090105 - changed to N/A
				////builder.Append(",");
				////builder.Append(",");
				////builder.Append(",");
				////builder.Append(",");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				//builder.Append(",N/A");
				//mam 07072011
				for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
				{
					builder.Append(",N/A");
				}
			}

			//if Total Current Value = zero, then OUL, LOS, Crit, Vuln, RUL, and Risk = N/A
			if (totalCurrentValue == 0)
			{
				//Avg Crit, Avg Vuln, Override Vuln, Avg Risk, 
				builder.Append(",N/A");
				builder.Append(",N/A");
				if (includePipesNodes)
				{
					builder.Append(",N/A");
				}
				builder.Append(",N/A");

				//Avg LOS, Avg Cond, OUL, RUL, EvRUL, EcRUL
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");

				//Economic Remaining Useful Life
				builder.Append(",N/A");
			}
			else
			{
				builder.AppendFormat(",{0:F1}", discipline.GetAverageCriticality());
				if (GetAllERULZero(discipline) && !GetAnyVulnerabilityOverridden(discipline))
				{
					builder.Append(",N/A");
					if (includePipesNodes)
					{
						builder.Append(",");
					}
					builder.Append(",N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat(",{0:F2}", discipline.GetAverageVulnerability());
					builder.AppendFormat(",{0:F4}", discipline.GetAverageVulnerability());
					if (includePipesNodes)
					{
						builder.Append(",");
					}
					builder.AppendFormat(",{0:F2}", discipline.GetAverageRisk());
				}

				builder.AppendFormat(",{0:F1}", discipline.GetAverageLOS());

				if (useNA)
				{
					builder.Append(",N/A");
					builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
					builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
					builder.Append(",N/A");
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F1}", discipline.GetAverageCondition());
					builder.AppendFormat(",{0:F1}", discipline.OrgUsefulLife);
					builder.AppendFormat(",{0:F1}", discipline.GetRemainingUsefulLife());
					builder.AppendFormat(",{0:F1}", discipline.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat(",{0:F1}", discipline.GetEconomicUsefulLife());
				}
			}

			//inspection date, equip id, mfr, assessed by, run hours, running at inspection
			builder.AppendFormat(",{0}", discipline.DateInspected.ToString("MM/dd/yyyy"));
			builder.AppendFormat(",N/A");
			builder.AppendFormat(",N/A");
			builder.AppendFormat("," + (char)34 + "{0}" + (char)34, ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.AssessedBy));
			builder.AppendFormat(",N/A");
			builder.AppendFormat(",N/A");

			//mam 101107 - replace double quote in comments with two double quotes 
			string commentsQuotes = ReplaceDoubleQuoteWithTwoDoubleQuotes(@discipline.Comments);

			//mam 011206
			if (includePipesNodes)
			{
				//mam 101107
				//builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + discipline.Comments + (char)34);
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A," + (char)34 + commentsQuotes + (char)34);
			}
			else
			{
				//mam 101107
				//builder.Append("," + (char)34 + discipline.Comments + (char)34);
				builder.Append("," + (char)34 + commentsQuotes + (char)34);
			}

			//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");

			if (includePipesNodes)
			{
				nodeDataXML = GetCSVDataNodesDetail(discipline);
				builder.Append(nodeDataXML);
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		private string GetCSVDataPipesDetail(DisciplinePipe discipline)
		{
			MajorComponent component = discipline.GetMajorComponent();
			TreatmentProcess process = component.GetTreatmentProcess();
			Facility facility = process.GetFacility();
			PipeData[] pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			PipeData pipe;
			bool useNA = false;
			StringBuilder builder = new StringBuilder();

			for (int pos = 0; pos < pipes.Length; pos++)
			{
				pipe = pipes[pos];
				CondRank currentCondition = pipe.ConditionRank;
				useNA = (pipe.ConditionRank == CondRank.No);

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + (char)34);
				//builder.Append("," + (char)34 + pipe.IDNumber.Replace((char)34, (char)47) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.IDNumber) + (char)34);

				//mam 112806
				builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				builder.AppendFormat(",{0}", facility.CurrentYear);
				builder.AppendFormat(",{0}", facility.CurrentENR);

				//mam 050806 - don't use average values here
				//builder.AppendFormat(",{0}", discipline.InstallationYear);
				//builder.AppendFormat(",{0}", discipline.OriginalENR);
				builder.AppendFormat(",{0}", pipe.InstallYear);
				builder.AppendFormat(",{0}", pipe.OriginalENR);

				builder.AppendFormat(",{0:F0}", pipe.AcquisitionCost);

				//mam 050806
				//builder.AppendFormat(",N/A");
				if (pipe.OverrideAcquisitionCost)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>

				//mam 112806 - check condition and override
				if (useNA && !pipe.OverrideCurrentValue)
				{
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F0}", pipe.GetCurrentValue());
				}

				//mam 050806
				//builder.AppendFormat(",N/A");
				if (pipe.OverrideCurrentValue)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>

				//mam 050806
				builder.AppendFormat(",{0:F0}", pipe.AcquisitionCostEscalated);

				builder.AppendFormat(",{0:F0}", pipe.ReplacementValue);

				//mam 01222012
				builder.Append(",N/A");	//placeholder for ReplacementValueDesc

				//mam 050806
				builder.AppendFormat(",{0:F0}", pipe.ReplacementValueYear);
				builder.AppendFormat(",{0:F0}", pipe.GetENRValueForYear(Convert.ToInt16(pipe.ReplacementValueYear)));

				//mam 03202012
				builder.Append(",N/A");	//time to next replacement

				//mam 07072011
				builder.Append(",N/A");	//discipline.NextReplacementYear
				builder.Append(",N/A");	//discipline.OverrideNextReplacementYear

				builder.AppendFormat(",{0:F0}", pipe.RehabCost);

				//mam 01222012
				builder.Append(",N/A");	//placeholder for RehabCostDesc

				//mam 07072011
				builder.Append(",N/A");	//discipline.RehabCostYear
				//these values don't exist at the individual pipe level (below the discipline level)
				builder.Append(",N/A");	//discipline.RehabInterval
				builder.Append(",N/A");	//discipline.RehabYearLast)
				builder.Append(",N/A");	//discipline.RehabNext)
				builder.Append(",N/A");	//discipline.OverrideRehabNext)
				builder.Append(",N/A");	//discipline.RehabYearNext)

				builder.AppendFormat(",{0:F0}", pipe.GetBookValue());
				builder.AppendFormat(",{0:F0}", pipe.SalvageValue);
				builder.AppendFormat(",{0:F0}", pipe.GetAnnualDepreciation());
				builder.AppendFormat(",{0:F0}", pipe.GetCumulativeDepreciation());

				//eval value, repair cost
				if (useNA == true)
				{
					builder.Append(",N/A");	//evaluated value

					//mam 112806
					if (pipe.OverrideRepairCost)
					{
						builder.AppendFormat(",{0:F0}", pipe.GetRepairCost());
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", pipe.GetEvaluatedValue());
					builder.AppendFormat(",{0:F0}", pipe.GetRepairCost());
				}

				//mam 050806
				if (pipe.OverrideRepairCost)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>

				builder.AppendFormat(",{0:F0}", pipe.AnnualMaintCost);

				//mam 050806 - added Redundant Assets column
				builder.AppendFormat(",{0:F0}", pipe.RedundantAssetCount);

				//mam 07072011 - no longer using four fixed crits
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritPublicHealthString(pipe.CritPublicHealth));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritEnvironmentalString(pipe.CritEnvironmental));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritRepairCostString(pipe.CritRepair));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritCustomerEffectString(pipe.CritCustEffect));

				//mam 07072011 - new crits
				foreach (MajorComponentSelectedCriticalityFactors critFactor in pipe.ComponentSelectedCriticalityFactorsCollection)
				{
					builder.AppendFormat("," + (char)34 + critFactor.CritFactor.FactorName + (char)34);
				}

				builder.AppendFormat(",{0}", pipe.GetOverallCriticality());

				if ((currentCondition == CondRank.No || pipe.GetEvaluatedRemainingUsefulLife() == 0) 
					&& !pipe.OverrideVulnerability)
				{
					builder.Append(",N/A");
					builder.Append(",FALSE");
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F4}", pipe.GetVulnerability());
					builder.AppendFormat(",{0}", Convert.ToBoolean(pipe.OverrideVulnerability));
					builder.AppendFormat(",{0:F2}", pipe.GetRisk());
				}

				builder.AppendFormat(",{0}", EnumHandlers.GetLOSShort(pipe.LevelOfService));
				builder.AppendFormat(",{0}", EnumHandlers.GetConditionRankShort(pipe.ConditionRank));

				builder.AppendFormat(",{0}", pipe.OrgUsefulLife);
				builder.AppendFormat(",{0:F2}", pipe.GetRemainingUsefulLife());

				if (useNA == true || currentCondition == CondRank.No)
				{
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F2}", pipe.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat(",{0:F2}", pipe.GetEconomicUsefulLife());
				}

				//******************************************

				//date of inspection, equip id, mfr, assessed by, run hours, running at inspection
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");

				builder.AppendFormat(",{0:F1}", pipe.GetCWP(false) * 100.0);

				//builder.AppendFormat(",{0}", pipe.IDNumber);
				//builder.AppendFormat(",{0}", pipe.Description);
				//builder.AppendFormat(",{0}", pipe.Type);

				//builder.Append("," + (char)34 + pipe.IDNumber.Replace((char)34, (char)47) + (char)34);
				//builder.Append("," + (char)34 + pipe.Description.Replace((char)34, (char)47) + (char)34);
				//builder.Append("," + (char)34 + pipe.Type.Replace((char)34, (char)47) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.IDNumber) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.Description) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.Type) + (char)34);

				//builder.AppendFormat(",{0}", pipe.Size);

				//mam 07072011 - 34 is being prepended to the pipe diameter - reformat the string
				//builder.AppendFormat(",{0}", + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.Size) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(pipe.Size) + (char)34);

				builder.AppendFormat(",{0}", pipe.Length);
				builder.AppendFormat(",{0:F2}", pipe.UnitCost);
				builder.AppendFormat(",{0}", pipe.InstallYear);
				builder.AppendFormat(",{0}", pipe.OriginalENR);

				//mam 112806 - don't show N/A for comments
				//mam 050806 - comments
				//builder.AppendFormat(",N/A");
				builder.AppendFormat(",");

				//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			}

			return builder.ToString();
		}
		//</mam>

		//mam
		private string GetCSVDataNodesDetail(DisciplineNode discipline)
		{
			MajorComponent component = discipline.GetMajorComponent();
			TreatmentProcess process = component.GetTreatmentProcess();
			Facility facility = process.GetFacility();
			NodeData[] nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			NodeData node;
			bool useNA = false;
			StringBuilder builder = new StringBuilder();

			for (int pos = 0; pos < nodes.Length; pos++)
			{
				node = nodes[pos];
				CondRank currentCondition = node.ConditionRank;
				useNA = (node.ConditionRank == CondRank.No);

				builder.Append("\r\n");

				builder.Append((char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(facility.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(process.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(component.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(discipline.Name) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.IDNumber) + (char)34);

				//mam 112806
				builder.AppendFormat(",{0}", component.Retired? Convert.ToBoolean(component.Retired).ToString(): "");

				builder.AppendFormat(",{0}", facility.CurrentYear);
				builder.AppendFormat(",{0}", facility.CurrentENR);

				//mam 050806 - don't use average values here
				//builder.AppendFormat(",{0}", discipline.InstallationYear);
				//builder.AppendFormat(",{0}", discipline.OriginalENR);
				builder.AppendFormat(",{0}", node.InstallYear);
				builder.AppendFormat(",{0}", node.OriginalENR);

				builder.AppendFormat(",{0:F0}", node.AcquisitionCost);

				//mam 050806
				//builder.AppendFormat(",N/A");
				if (node.OverrideAcquisitionCost)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>
				
				//mam 112806 - check condition and override
				if (useNA && !node.OverrideCurrentValue)
				{
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F0}", node.GetCurrentValue());
				}

				//mam 112806 - changed OverrideAcquisitionCost to OverrideCurrentValue
				//mam 050806
				//builder.AppendFormat(",N/A");
				if (node.OverrideCurrentValue)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>

				//mam 050806
				builder.AppendFormat(",{0:F0}", node.AcquisitionCostEscalated);

				builder.AppendFormat(",{0:F0}", node.ReplacementValue);

				//mam 01222012
				builder.Append(",N/A");	//placeholder for ReplacementValueDesc

				//mam 050806
				builder.AppendFormat(",{0:F0}", node.ReplacementValueYear);
				builder.AppendFormat(",{0:F0}", node.GetENRValueForYear(Convert.ToInt16(node.ReplacementValueYear)));

				//mam 03202012
				builder.Append(",N/A");	//time to next replacement

				//mam 07072011
				builder.Append(",N/A");	//discipline.NextReplacementYear
				builder.Append(",N/A");	//discipline.OverrideNextReplacementYear

				builder.AppendFormat(",{0:F0}", node.RehabCost);

				//mam 01222012
				builder.Append(",N/A");	//placeholder for RehabCostDesc

				//mam 07072011 - added rehab values
				builder.Append(",N/A");	//discipline.RehabCostYear
				//oops - these values don't exist at the individual pipe level (below the discipline level)
				//builder.AppendFormat(",{0:F1}", discipline.RehabInterval);
				//builder.AppendFormat(",{0:F0}", discipline.RehabYearLast);
				//builder.AppendFormat(",{0:F1}", discipline.RehabNext);
				//builder.AppendFormat(",{0:F0}", discipline.RehabYearNext);
				builder.Append(",N/A");	//discipline.RehabInterval
				builder.Append(",N/A");	//discipline.RehabYearLast)
				builder.Append(",N/A");	//discipline.RehabNext)
				builder.Append(",N/A");	//discipline.OverrideRehabNext)
				builder.Append(",N/A");	//discipline.RehabYearNext)

				builder.AppendFormat(",{0:F0}", node.GetBookValue());
				builder.AppendFormat(",{0:F0}", node.SalvageValue);
				builder.AppendFormat(",{0:F0}", node.GetAnnualDepreciation());
				builder.AppendFormat(",{0:F0}", node.GetCumulativeDepreciation());

				//eval value, repair cost
				if (useNA == true)
				{
					builder.Append(",N/A");	//evaluated value

					//mam 112806
					if (node.OverrideRepairCost)
					{
						builder.AppendFormat(",{0:F0}", node.GetRepairCost());
					}
					else
					{
						builder.Append(",N/A");
					}
				}
				else
				{
					builder.AppendFormat(",{0:F0}", node.GetEvaluatedValue());
					builder.AppendFormat(",{0:F0}", node.GetRepairCost());
				}

				//mam 050806
				if (node.OverrideRepairCost)
					builder.AppendFormat(",{0}", "TRUE");
				else
					builder.AppendFormat(",{0}", "");
				//</mam>

				builder.AppendFormat(",{0:F0}", node.AnnualMaintCost);

				//mam 050806 - added Redundant Assets column
				builder.AppendFormat(",{0:F0}", node.RedundantAssetCount);

				//mam 07072011 - no longer using four fixed crits
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritPublicHealthString(node.CritPublicHealth));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritEnvironmentalString(node.CritEnvironmental));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritRepairCostString(node.CritRepair));
				//builder.AppendFormat("," + (char)34 + "{0}" + (char)34, EnumHandlers.GetCritCustomerEffectString(node.CritCustEffect));
//				for (int i = 0; i < Common.CommonTasks.Criticalities.Count; i++)
//				{
//					builder.Append(",correct?");
//				}
				//mam 07072011 - new crits
				foreach (MajorComponentSelectedCriticalityFactors critFactor in node.ComponentSelectedCriticalityFactorsCollection)
				{
					//builder.AppendFormat("\t\t\t<" + critNumberText + "><![CDATA[{0}]]></" + critNumberText + ">\r\n", critFactor.CritFactor.FactorName);
					builder.AppendFormat("," + (char)34 + critFactor.CritFactor.FactorName + (char)34);
				}

				builder.AppendFormat(",{0}", node.GetOverallCriticality());

				if ((currentCondition == CondRank.No || node.GetEvaluatedRemainingUsefulLife() == 0) 
					&& !node.OverrideVulnerability)
				{
					builder.Append(",N/A");
					builder.Append(",FALSE");
					builder.Append(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F4}", node.GetVulnerability());
					builder.AppendFormat(",{0}", Convert.ToBoolean(node.OverrideVulnerability));
					builder.AppendFormat(",{0:F2}", node.GetRisk());
				}

				builder.AppendFormat(",{0}", EnumHandlers.GetLOSShort(node.LevelOfService));
				builder.AppendFormat(",{0}", EnumHandlers.GetConditionRankShort(node.ConditionRank));

				builder.AppendFormat(",{0}", node.OrgUsefulLife);
				builder.AppendFormat(",{0:F2}", node.GetRemainingUsefulLife());

				if (useNA == true || currentCondition == CondRank.No)
				{
					builder.AppendFormat(",N/A");
					builder.AppendFormat(",N/A");
				}
				else
				{
					builder.AppendFormat(",{0:F2}", node.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat(",{0:F2}", node.GetEconomicUsefulLife());
				}

				//******************************************

				//date of inspection, equip id, mfr, assessed by, run hours, running at inspection
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");
				builder.Append(",N/A");

				builder.AppendFormat(",{0:F1}", node.GetCWP(false) * 100.0);

				//builder.AppendFormat(",{0}", node.IDNumber);

				//builder.Append("," + (char)34 + node.IDNumber.Replace((char)34, (char)47) + (char)34);
				//builder.Append("," + (char)34 + node.Description.Replace((char)34, (char)47) + (char)34);
				//builder.Append("," + (char)34 + node.Type.Replace((char)34, (char)47) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.IDNumber) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.Description) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.Type) + (char)34);

				//builder.AppendFormat(",{0}", node.Size);

				//mam 07072011 - 34 is being prepended to the node size - reformat the string
				//builder.AppendFormat(",{0}", + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.Size) + (char)34);
				builder.Append("," + (char)34 + ReplaceDoubleQuoteWithTwoDoubleQuotes(node.Size) + (char)34);
				
				builder.AppendFormat(",");
				builder.AppendFormat(",");
				builder.AppendFormat(",{0}", node.InstallYear);
				builder.AppendFormat(",{0}", node.OriginalENR);

				//mam 112806 - don't show N/A for comments
				//mam 050806 - comments
				//builder.AppendFormat(",N/A");
				builder.AppendFormat(",");

				//mam 112806 - 47 N/A values as placeholders for discipline component info radio buttons that occur only in MSC disciplines
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A,N/A");
				builder.Append(",N/A,N/A,N/A,N/A,N/A,N/A,N/A");
			}

			return builder.ToString();
		}
		//</mam>

		//mam - add routine to check whether Condition for all pipes is N/A
		public bool GetAllConditionNA(DisciplinePipe discipline)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = true;

			// Retrieve the Condition from the pipe data
			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether ERUL for all pipes is zero
		public bool GetAllERULZero(DisciplinePipe discipline)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = true;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].GetEvaluatedRemainingUsefulLife() != 0)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether any Vulnerability value is overridden
		public bool GetAnyVulnerabilityOverridden(DisciplinePipe discipline)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = false;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideVulnerability)
				{
					AllNA = true;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam 050806 - add routine to check whether any Repair Cost is overridden
		public bool GetAnyRepairCostOverridden(DisciplinePipe discipline)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AnyOR = false;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideRepairCost)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		//mam 050806 - add routine to check whether any Current Value is overridden
		public bool GetAnyCurrentValueOverridden(DisciplinePipe discipline)
		{
			// Retrieve the pipe data for the current discipline
			PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AnyOR = false;

			for (int pos = 0; pos < pipes.Length; pos++)
				if (pipes[pos].OverrideCurrentValue)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		//mam - add routine to check whether Condition for all pipes is N/A
		public bool GetAllConditionNA(DisciplineNode discipline)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = true;

			// Retrieve the Condition from the node data
			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].ConditionRank != CondRank.No)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether ERUL for all pipes is zero
		public bool GetAllERULZero(DisciplineNode discipline)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = true;

			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].GetEvaluatedRemainingUsefulLife() != 0)
				{
					AllNA = false;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam - add routine to check whether any Vulnerability value is overridden
		public bool GetAnyVulnerabilityOverridden(DisciplineNode discipline)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AllNA = false;

			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].OverrideVulnerability)
				{
					AllNA = true;
					break;
				}

			return AllNA;
		}
		//</mam>

		//mam 050806 - add routine to check whether any Repair Cost is overridden
		public bool GetAnyRepairCostOverridden(DisciplineNode discipline)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AnyOR = false;

			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].OverrideRepairCost)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		//mam 050806 - add routine to check whether any Current Value is overridden
		public bool GetAnyCurrentValueOverridden(DisciplineNode discipline)
		{
			// Retrieve the node data for the current discipline
			NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
			bool AnyOR = false;

			for (int pos = 0; pos < nodes.Length; pos++)
				if (nodes[pos].OverrideCurrentValue)
				{
					AnyOR = true;
					break;
				}

			return AnyOR;
		}
		//</mam>

		public MajorComponent GetMajorComponent()
		{
			// Get the facility (need to get the component to get facility)
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			return component;
		}

		public TreatmentProcess	GetTreatmentProcess()
		{
			// Get the facility (need to get the component to get facility)
			MajorComponent	component = 
				CacheManager.GetMajorComponent(m_infoSetID, m_componentID);

			if (component.ID == 0)
				return null;

			TreatmentProcess process = 
				CacheManager.GetTreatmentProcess(m_infoSetID, component.ProcessID);

			return process;
		}

		public Facility	GetFacility()
		{
			// Get the facility (need to get the component to get facility)
			MajorComponent	component = CacheManager.GetMajorComponent(m_infoSetID, m_componentID);
			Facility		facility;

			//mam - added code for null case
			if (component == null)
				return null;
			//</mam>

			if (component.ID == 0)
				return null;

			TreatmentProcess process = CacheManager.GetTreatmentProcess(m_infoSetID, component.ProcessID);

			facility = CacheManager.GetFacility(m_infoSetID, process.FacilityID);
			return facility;
		}

		public string		GetFullName()
		{
			MajorComponent component = GetMajorComponent();
			componentName = component.Name;

			return string.Format("{0} / {1}", component.GetFullName(), Name);
		}

		public string		GetShortName()
		{
			return Name;
		}

		//mam
		public string GetFullNameWithInfoset()
		{
			return string.Format("{0} / {1}", CacheManager.GetInfosetNameForInfoSetID(this.InfoSetID), GetFullName());
		}
		//</mam>

		//mam 090105
		public int GetFacilityID()
		{
			if (facilityID == 0)
			{
				Facility facility = GetFacility();
				facilityID = facility.ID;
			}

			return facilityID;
		}

		public string GetParentName()
		{
			//get the Component name

			//just go ahead and call GetMajorComponent to make sure that all of the data is refreshed
			//if (componentName.Length == 0)
			{
				MajorComponent component = GetMajorComponent();
				componentName = component.Name;
			}

			//just go ahead and call GetTreatmentProcess to make sure that all of the data is refreshed
			//if (processName.Length == 0)
			{
				TreatmentProcess process = GetTreatmentProcess();
				processName = process.Name;
			}

			return processName + " / " + componentName;
		}
		//</mam>

		//mam 050806
		public int GetParentID()
		{
			parentID = ComponentID;
			return parentID;
		}

		//mam 050806
		public int GetGrandparentID()
		{
			MajorComponent component = CacheManager.GetMajorComponent(m_infoSetID, ComponentID);
			if (component == null)
				return 0;

			grandparentID = component.ProcessID;
			return grandparentID;
		}

		//mam 050806
		public int GetInfosetID()
		{
			return m_infoSetID;
		}

		//mam 050806
		public object GetUnitType()
		{
			return WAM.UI.NodeType.DisciplineMech;
		}

		//mam - need a way to get only the pipes, or only the nodes, because the graph is showing
		//	both pipes and nodes when the user has selected either pipes only or nodes only
		public decimal GetYAxisValue(GraphYAxis yAxis, bool pipesOnly, bool nodesOnly)
		{
			switch (yAxis)
			{
				case GraphYAxis.Criticality:
					return Math.Round((decimal)GetOverallCriticality(pipesOnly, nodesOnly), 1);
				case GraphYAxis.Vulnerability:
					//mam 090105 - round vuln to 4 decimals rather than 2
					//return Math.Round((decimal)GetVulnerability(pipesOnly, nodesOnly), 2);
					return Math.Round((decimal)GetVulnerability(pipesOnly, nodesOnly), 4);
				case GraphYAxis.Risk:
					return Math.Round(((decimal)GetRisk(pipesOnly, nodesOnly)), 2);
				case GraphYAxis.Condition:
					return Math.Round(((decimal)GetCondition(pipesOnly, nodesOnly)), 1);
				case GraphYAxis.LOS:
					return (decimal)GetLevelOfService(pipesOnly, nodesOnly);
				default:
					return GetYAxisValue(yAxis);
			}
		}
		//</mam>

		public decimal		GetYAxisValue(GraphYAxis yAxis)
		{
			switch (yAxis)
			{
				case GraphYAxis.AcquisitionCost:
					return AcquisitionCost;
				case GraphYAxis.CurrentValue:
					return GetCurrentValue();
				case GraphYAxis.ReplacementValue:
					return ReplacementValue;
				case GraphYAxis.BookValue:
					return GetBookValue();
				case GraphYAxis.SalvageValue:
					return SalvageValue;
				case GraphYAxis.AnnualDepreciation:
					return GetAnnualDepreciation();
				case GraphYAxis.CumulativeDepreciation:
					return GetCumulativeDepreciation();
				case GraphYAxis.EvaluatedValue:
					return GetEvaluatedValue();
				case GraphYAxis.RepairCost:
					return GetRepairCost();
				case GraphYAxis.AnnualMaintenanceCost:
					return AnnualMaintCost;
				case GraphYAxis.Criticality:
					return (decimal)GetOverallCriticality();

				//mam 050806
				case GraphYAxis.AcquisitionCostEscalated:
					return AcquisitionCostEscalated;
				case GraphYAxis.RehabCost:
					return RehabCost;

				//mam - use probability
				//case GraphYAxis.Vulnerability:
				//	return decimal.Parse(EnumHandlers.GetVulnerabilityShort(GetVulnerability()));
				case GraphYAxis.Vulnerability:
					return (decimal)GetVulnerability();
				//</mam>

				case GraphYAxis.Risk:
					return Math.Round(((decimal)GetRisk()), 2);

				case GraphYAxis.Condition:
					//mam - get value rather than rank
					//mam - no this is a mistake - it is returning the Component value, 
					//	rather than the individual Discipline value - get the Condition Rank

					//don't return zero, because the bar graph axis is reversed (1 on top, 5 at the origin) so that
					//	a zero value causes the bar to reach the top of the graph (the 1 position), making it look
					//	like that is the value
					//if (ConditionRanking == CondRank.No)
					//	return 0m;

					//this gets the individual discipline condition for MSL disciplines
					return (decimal)ConditionRanking;

					//this gets the Component condition value:
					//return (decimal)GetCondition(false, false);

				case GraphYAxis.LOS:
					//mam - get decimal value not from enumeration
					//return (decimal)GetLevelOfService();
					return (decimal)GetLevelOfService(false, false);

				//mam 190105
				case GraphYAxis.OriginalUsefulLife:
					return (decimal)OrgUsefulLife;
				case GraphYAxis.RemainingUsefulLife:
					return (decimal)GetRemainingUsefulLife();
				case GraphYAxis.EvaluatedRemainingUsefulLife:
					return (decimal)GetEvaluatedRemainingUsefulLife();
				case GraphYAxis.EconomicRemainingUsefulLife:
					return (decimal)GetEconomicUsefulLife();
			}

			return 0m;
		}

		public int			GetYearValue()
		{
			// Return the year
			return GetFacility().CurrentYear;

			//return  inspecteDate
		}

		//mam 050806
		public int GetInspectionYear()
		{
			// Return the year
			return InspectionYear.Year;
		}

		//mam - new method
		public int GetItemID()
		{
			//return the ID
			return ID;
		}
		//</mam>

		//mam 101107 - replace double quote in comments with two double quotes 
		private string ReplaceDoubleQuoteWithTwoDoubleQuotes(string stringToChange)
		{
			stringToChange = stringToChange.Replace("\"", "\"\"");
			return stringToChange;
		}

		//mam 01222012
		//public static bool CheckConstraints(string textBoxName, int valueToCheck)
		//{
		//	//constraints:
		//	//	installation year <= last rehab year <= inspection year <= current year <= next rehab year or next replacement year
		//
		//	//int year1 = m_discipline.RehabYearLast;
		//	//int year2 = m_discipline.InspectionYear.Year;
		//	//int year3 = m_discipline.CurrentYear;
		//	//int year4 = m_discipline.RehabYearNext;
		//	//int year5 = m_discipline.NextReplacementYear;
		//
		//	if (textBoxName == ConstraintType.InstallationYear)
		//	{
		//		return valueToCheck <= RehabYearLast;
		//	}
		//	if (textBoxName == ConstraintType.LastRehabYear)
		//	{
		//		return valueToCheck <= InspectionYear.Year;
		//	}
		//	if (textBoxName == ConstraintType.InspectionYear)
		//	{
		//		return valueToCheck <= CurrentYear;
		//	}
		//	if (textBoxName == ConstraintType.NextRehabYear)
		//	{
		//		return valueToCheck >= CurrentYear;
		//	}
		//	if (textBoxName == ConstraintType.NextReplacementYear)
		//	{
		//		return valueToCheck >= CurrentYear;
		//	}
		//}

		#endregion /***** Methods *****/
	}

	#region /***** Cache Class *****/
	public class			DisciplineCache : IDisposable
	{
		private TreeHash	m_treeHash = new TreeHash(typeof(WAM.Data.Discipline));
		private Hashtable[]	m_discTypeHashes = null;

		//mam 102309
		//private Drive.Data.OleDb.OleDbDALBase.DataChangedHandler
		//					m_changeDelegate = null;
		private Drive.Data.SqlClient.SqlDALBase.DataChangedHandler
			m_changeDelegate = null;

		private int			m_infoSetID = 0;

		public				DisciplineCache(int infoSetID)
		{
			m_infoSetID = infoSetID;

			m_discTypeHashes = 
				new Hashtable[Enum.GetValues(typeof(DisciplineType)).Length];
			for (int pos = 0; pos < m_discTypeHashes.Length; pos++)
			{
				m_discTypeHashes[pos] = new Hashtable();
			}

			//mam 102309
			//m_changeDelegate = 
			//	new Drive.Data.OleDb.OleDbDALBase.DataChangedHandler(this.DataChanged);
			m_changeDelegate = 
				new Drive.Data.SqlClient.SqlDALBase.DataChangedHandler(this.DataChanged);

			// Handle the global event

			//mam 102309
			//Drive.Data.OleDb.OleDbDALBase.AddChangeEventHandler(m_changeDelegate);
			Drive.Data.SqlClient.SqlDALBase.AddChangeEventHandler(m_changeDelegate);

		}

		#region IDisposable Members
		~DisciplineCache()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose(false);
		}

		public void Dispose()
		{
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue 
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
		}

        private void Dispose(bool disposing)
        {
            // If disposing equals true, dispose all managed 
            // and unmanaged resources.
            if (disposing)
            {
				// Dispose managed resources.
				if (m_changeDelegate != null)
				{
					// Unregister the data change event

					//mam 102309
					//Drive.Data.OleDb.OleDbDALBase.RemoveChangeEventHandler(
					//	m_changeDelegate);
					Drive.Data.SqlClient.SqlDALBase.RemoveChangeEventHandler(
						m_changeDelegate);

					m_changeDelegate = null;
				}
            }
        }
		#endregion

		public int			InfoSetID
		{
			get { return m_infoSetID; }
		}

		//mam 102309
		//private void DataChanged(object sender, 
		//	Drive.Data.OleDb.OleDbDALBase.DataChangeEventArgs e)
		private void DataChanged(object sender, 
			Drive.Data.SqlClient.SqlDALBase.DataChangeEventArgs e)
			{
			Discipline obj = e.ChangedObject as Discipline;

			if (obj == null || obj.InfoSetID != m_infoSetID)
				return;

			if (e.Action == Drive.Synchronization.SyncAction.Add || 
				e.Action == Drive.Synchronization.SyncAction.Edit)
			{
				// Add the object to the hash or update it
				(m_discTypeHashes[(int)obj.Type])[obj.GetHashCode()] = obj;
			}
		}

		public Discipline[] GetForComponent(int id)
		{
			Discipline[]	children = (Discipline[])m_treeHash.GetChildren(id);
			Discipline		discipline;

			if (children == null)
			{
				children = DisciplineLoader.LoadForComponent(id);
				for (int pos = 0; pos < children.Length; pos++)
				{
					discipline = children[pos];
					discipline.InfoSetID = m_infoSetID;

					if (discipline.ID == 0)
						continue;
					(m_discTypeHashes[(int)discipline.Type])[discipline.ID.GetHashCode()] = 
						discipline;
				}
				m_treeHash.SetChildren(id, children);
			}

			return children;
		}

		public Discipline	GetDiscipline(int id, DisciplineType type)
		{
			// Look up the components in the hash table
			Discipline discipline = 
				(m_discTypeHashes[(int)type])[id.GetHashCode()] as Discipline;

			// If the component is not present, load it from the default database
			if (discipline == null)
			{
				discipline = DisciplineLoader.LoadForID(id, type);
				discipline.InfoSetID = m_infoSetID;

				// If it doesn't exist in the database, then reset it
				if (discipline != null && discipline.ID != 0)
					(m_discTypeHashes[(int)discipline.Type])[discipline.GetHashCode()] = discipline;
				else
					discipline = null;
			}

			return discipline;
		}

		//mam 102309 - added this method, but commented it because it is not necessary
		//public Discipline[] AddDisciplineToCache(int componentId, int disciplineId)
		public Discipline AddDisciplineToCache(int componentId, Discipline newDiscipline)
		{
			SqlConnection sqlConnection = new SqlConnection(WAM.Common.Globals.WamSqlConnectionString);

			try
			{
				sqlConnection.Open();
				//Discipline[]	children = DisciplineLoader.LoadForComponent(sqlConnection, componentId);
				Discipline child = DisciplineLoader.LoadForID(newDiscipline.ID, newDiscipline.Type);
				//foreach (Discipline child in children)
				{
					m_treeHash.AddChild(componentId, child);
					child.InfoSetID = m_infoSetID;
					//m_discTypeHashes[child.GetHashCode()] = child;
					(m_discTypeHashes[(int)child.Type])[child.ID.GetHashCode()] = child;
				}
				//return children;
				return child;
			}
			finally
			{
				if (sqlConnection != null)
					sqlConnection.Dispose();
			}
		}

		//mam 102309
		//public Discipline[] BuildCacheForComponent(System.Data.OleDb.OleDbConnection connection, int id)
		public Discipline[] BuildCacheForComponent(SqlConnection connection, int id)
		{
			Discipline[]	children = DisciplineLoader.LoadForComponent(connection, id);
			Discipline		discipline;

			m_treeHash.SetChildren(id, children);
			for (int pos = 0; pos < children.Length; pos++)
			{
				discipline = children[pos];
				discipline.InfoSetID = m_infoSetID;
				if (discipline.ID == 0)
					continue;
				(m_discTypeHashes[(int)discipline.Type])[discipline.ID.GetHashCode()] = 
					discipline;
			}
			return children;
		}

		//mam 03202012 - new method to get all disciplines for an infoset at once
		//@@@@
		public Discipline[] BuildCacheForInfoset(SqlConnection connection, int infosetId)
		{
			Discipline[] children = DisciplineLoader.LoadForInfoset(connection, infosetId);

			int counter = 0;
			foreach (Discipline discipline in children)
			{
				counter++;
				m_treeHash.AddChild(discipline.ComponentID, discipline);

				discipline.InfoSetID = m_infoSetID;
				if (discipline.ID == 0)
				{
					continue;
				}
				(m_discTypeHashes[(int)discipline.Type])[discipline.ID.GetHashCode()] = discipline;
			}

			return children;
		}

		public void			Clear()
		{
			m_treeHash.Clear();
			for (int pos = 0; pos < m_discTypeHashes.Length; pos++)
				m_discTypeHashes[pos].Clear();
		}
	}
	#endregion /***** Cache Class *****/

	#region /***** Discipline Loader *****/

	public class DisciplineLoader
	{
		public static Discipline[] LoadForComponent(int componentID)
		{
			Discipline[] disciplines;
			MajorComponent component = new MajorComponent(componentID);

			if (component.MechStructDisciplines)
			{
				disciplines = new Discipline[3];
				disciplines[(int)DisciplineType.Mechanical] = DisciplineMech.LoadForComponent(componentID);
				disciplines[(int)DisciplineType.Structural] = DisciplineStruct.LoadForComponent(componentID);
				disciplines[(int)DisciplineType.Land] = DisciplineLand.LoadForComponent(componentID);
			}
			else
			{
				disciplines = new Discipline[2];
				disciplines[0] = DisciplinePipe.LoadForComponent(componentID);
				disciplines[1] = DisciplineNode.LoadForComponent(componentID);
			}

			return disciplines;
		}

		public static Discipline[] LoadForComponent(string sqlConnectionString, int componentID)
		{
			Discipline[] disciplines;
			MajorComponent component = new MajorComponent(componentID);

			if (component.MechStructDisciplines)
			{
				disciplines = new Discipline[3];
				disciplines[(int)DisciplineType.Mechanical] = DisciplineMech.LoadForComponent(sqlConnectionString, componentID);
				disciplines[(int)DisciplineType.Structural] = DisciplineStruct.LoadForComponent(sqlConnectionString, componentID);
				disciplines[(int)DisciplineType.Land] = DisciplineLand.LoadForComponent(sqlConnectionString, componentID);
			}
			else
			{
				disciplines = new Discipline[2];
				disciplines[0] = DisciplinePipe.LoadForComponent(sqlConnectionString, componentID);
				disciplines[1] = DisciplineNode.LoadForComponent(sqlConnectionString, componentID);
			}

			return disciplines;
		}

		//mam 11142011 - pass in source component - why are we getting a new component?
		public static Discipline[] LoadForComponent(System.Data.OleDb.OleDbConnection connection, int componentID
			, MajorComponent sourceComponent)
		//mam 102309 - leave as is for importing from Access databases
		//public static Discipline[] LoadForComponent(System.Data.OleDb.OleDbConnection connection, int componentID)
		//public static Discipline[] LoadForComponent(SqlConnection connection, int componentID)
		{
			Discipline[] disciplines;

			//mam 11142011 - don't get a new component
			//MajorComponent component = new MajorComponent(componentID);

			//mam 11142011
			//if (component.MechStructDisciplines)
			if (sourceComponent.MechStructDisciplines)
			{
				disciplines = new Discipline[3];

				disciplines[(int)DisciplineType.Mechanical] = DisciplineMech.LoadForComponentOleDb(connection, componentID);
				disciplines[(int)DisciplineType.Structural] = DisciplineStruct.LoadForComponentOleDb(connection, componentID);
				disciplines[(int)DisciplineType.Land] = DisciplineLand.LoadForComponentOleDb(connection, componentID);

			}
			else
			{
				disciplines = new Discipline[2];
				disciplines[0] = DisciplinePipe.LoadForComponentOleDb(connection, componentID);
				disciplines[1] = DisciplineNode.LoadForComponentOleDb(connection, componentID);
			}

			return disciplines;
		}

		//mam 102309
		//public static Discipline[] LoadForComponent(
		//	System.Data.OleDb.OleDbConnection connection, int componentID)
		public static Discipline[] LoadForComponent(SqlConnection connection, int componentID)
		{
			Discipline[] disciplines;
			MajorComponent component = new MajorComponent(componentID);

			if (component.MechStructDisciplines)
			{
				disciplines = new Discipline[3];

				disciplines[(int)DisciplineType.Mechanical] = DisciplineMech.LoadForComponent(connection, componentID);
				disciplines[(int)DisciplineType.Structural] = DisciplineStruct.LoadForComponent(connection, componentID);
				disciplines[(int)DisciplineType.Land] = DisciplineLand.LoadForComponent(connection, componentID);

			}
			else
			{
				disciplines = new Discipline[2];
				disciplines[0] = DisciplinePipe.LoadForComponent(connection, componentID);
				disciplines[1] = DisciplineNode.LoadForComponent(connection, componentID);
			}

			return disciplines;
		}

		//mam 03202012 - new method to get all disciplines for an infoset
		//@@@@
		public static Discipline[] LoadForInfoset(SqlConnection connection, int infosetId)
		{
			DisciplineMech[] disciplinesMech = DisciplineMech.LoadForInfoset(connection, infosetId);
			DisciplineStruct[] disciplinesStruct = DisciplineStruct.LoadForInfoset(connection, infosetId);
			DisciplineLand[] disciplinesLand = DisciplineLand.LoadForInfoset(connection, infosetId);
			DisciplinePipe[] disciplinesPipe = DisciplinePipe.LoadForInfoset(connection, infosetId);
			DisciplineNode[] disciplinesNode = DisciplineNode.LoadForInfoset(connection, infosetId);

			int discCount = disciplinesMech.Length + disciplinesStruct.Length + disciplinesLand.Length + disciplinesPipe.Length + disciplinesNode.Length;
			Discipline[] disciplines = new Discipline[discCount];
			Array.Copy(disciplinesMech, disciplines, disciplinesMech.Length);
			Array.Copy(disciplinesStruct, 0, disciplines, disciplinesMech.Length, disciplinesStruct.Length);
			Array.Copy(disciplinesLand, 0, disciplines, disciplinesMech.Length + disciplinesStruct.Length, disciplinesLand.Length);

			int curLength = disciplinesMech.Length + disciplinesStruct.Length + disciplinesLand.Length;
			Array.Copy(disciplinesPipe, 0, disciplines, curLength, disciplinesPipe.Length);

			curLength += disciplinesPipe.Length;
			Array.Copy(disciplinesNode, 0, disciplines, curLength, disciplinesNode.Length);

			return disciplines;
		}

		public static Discipline LoadForID(int id, DisciplineType type)
		{
			switch (type)
			{
				case DisciplineType.Mechanical:
					return new DisciplineMech(id);
				case DisciplineType.Structural:
					return new DisciplineStruct(id);
				case DisciplineType.Land:
					return new DisciplineLand(id);
				case DisciplineType.Pipes:
					return new DisciplinePipe(id);
				case DisciplineType.Nodes:
					return new DisciplineNode(id);
			}

			return null;
		}
	}

	#endregion /***** Discipline Loader *****/
}