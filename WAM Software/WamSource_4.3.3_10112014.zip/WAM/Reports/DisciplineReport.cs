using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for DisciplineMechanical.
	/// </summary>
	public class DisciplineReport : ReportBase
	{
		private WAM.Data.Discipline m_discipline = null;

		#region /***** Member Variables *****/

		public ReportOptionsBase options = new ReportOptionsBase ();

		//mam
		private static string currentSelectedFilters = "";
		//</mam>

		//mam - add 'bool printOnly' and 'bool includePhotos'
		public static bool Print(WAM.Data.Discipline discipline, bool printOnly, 
			bool includePhotos, string selectedFilters)
		{
			DisciplineReport myReport = null;
			ReportOptionsBase options = null;

			myReport = new DisciplineReport();
			myReport.m_discipline = discipline;
			options = myReport.LoadReportSettings(discipline.ID);

			//mam changed from true to printOnly
			options.PrintOnly = printOnly;
			//</mam>

			//mam
			if (!includePhotos)
			{
				options.ReportTitle = options.ReportTitle + " No Photos";
			}
			//</mam>

			//mam - added parameter
			options.XML = discipline.GetXML(includePhotos, selectedFilters);

			//mam - get discipline name
			string tempString = options.XML;
			//int start = tempString.IndexOf("<Discipline>");
			//int end = tempString.IndexOf("</Discipline>");
			//options.ItemName = "Discipline " + @tempString.Substring(start + 12 + 9, end - (start + 12 + 9 + 3));

			if (discipline is WAM.Data.DisciplineMech)
				options.ItemName = "Discipline Mech";
			else if (discipline is WAM.Data.DisciplineLand)
				options.ItemName = "Discipline Land";
			else if (discipline is WAM.Data.DisciplineStruct)
				options.ItemName = "Discipline Struc";
			else if (discipline is WAM.Data.DisciplinePipe)
				options.ItemName = "Discipline Pipe";
			else if (discipline is WAM.Data.DisciplineNode)
				options.ItemName = "Discipline Node";
			//</mam>

			//mam
			currentSelectedFilters = selectedFilters;
			//</mam>

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//mam
		}

		#endregion /***** Member Variables *****/
		
		#region /***** Member Methods *****/

//		public bool PrintReport(int certificateID)
//		{			
//			return RenderReport(LoadReportSettings(certificateID), true);
//		}

		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/

		public override ReportOptionsBase LoadReportSettings(int id)
		{
			if (m_discipline == null)
				return null;

			switch (m_discipline.Type)
			{
				case WAM.Data.DisciplineType.Mechanical:
					options.ReportTitle = "Discipline Mechanical";
					options.fileName = "DisciplineMechanical.XML";

					//mam - add subreport
					options.SubReports = new SubReportOptionsBase[1] 
					{
						new SubReportOptionsBase()
					};
					options.SubReports[0].FieldName = "SubreportGeneralFilter";
					options.SubReports[0].SubReportTitle = "SubreportGeneralFilter";
					options.SubReports[0].RecordSource = "DisciplineMechanical";
					//</mam>

					break;

				case WAM.Data.DisciplineType.Structural:
					options.ReportTitle = "Discipline Structural";
					options.fileName = "DisciplineStructural.XML";

					//mam - add subreport
					options.SubReports = new SubReportOptionsBase[1] 
					{
						new SubReportOptionsBase()
					};
					options.SubReports[0].FieldName = "SubreportGeneralFilter";
					options.SubReports[0].SubReportTitle = "SubreportGeneralFilter";
					options.SubReports[0].RecordSource = "DisciplineStructural";
					//</mam>
					
					break;

				case WAM.Data.DisciplineType.Land:
					options.ReportTitle = "Discipline Land";
					options.fileName = "DisciplineLand.XML";

					//mam - add subreport
					options.SubReports = new SubReportOptionsBase[1] 
					{
						new SubReportOptionsBase()
					};
					options.SubReports[0].FieldName = "SubreportGeneralFilter";
					options.SubReports[0].SubReportTitle = "SubreportGeneralFilter";
					options.SubReports[0].RecordSource = "DisciplineLand";
					//</mam>

					break;

				case WAM.Data.DisciplineType.Pipes:
					options.ReportTitle = "Discipline Pipes";
					options.fileName = "DisciplinePipes.XML";
					
					//mam - change from 3 to 4
					options.SubReports = new SubReportOptionsBase[5] 
					{
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase()
					};
					//</mam>

					options.SubReports[0].FieldName = "Pipe Record 1 Subreport";
					options.SubReports[0].SubReportTitle = "Pipe Record 1 Subreport";
					options.SubReports[0].RecordSource = "PipeRecord";

					options.SubReports[1].FieldName = "Pipe Record 2 Subreport";
					options.SubReports[1].SubReportTitle = "Pipe Record 2 Subreport";
					options.SubReports[1].RecordSource = "PipeRecord";

					options.SubReports[2].FieldName = "Pipe Record 3 Subreport";
					options.SubReports[2].SubReportTitle = "Pipe Record 3 Subreport";
					options.SubReports[2].RecordSource = "PipeRecord";

					//mam 050806 - new subreport
					options.SubReports[3].FieldName = "Pipe Record 4 Subreport";
					options.SubReports[3].SubReportTitle = "Pipe Record 4 Subreport";
					options.SubReports[3].RecordSource = "PipeRecord";

					//mam - set new subreport options
					options.SubReports[4].FieldName = "SubreportGeneralFilter";
					options.SubReports[4].SubReportTitle = "SubreportGeneralFilter";
					options.SubReports[4].RecordSource = "DisciplinePipes";
					//</mam>

					break;

				case WAM.Data.DisciplineType.Nodes:
					options.ReportTitle = "Discipline Node";
					options.fileName = "DisciplineNode.XML";
					
					//mam - change from 3 to 4
					options.SubReports = new SubReportOptionsBase[5]
					{
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase(),
						new SubReportOptionsBase()
					};
					//</mam>

					options.SubReports[0].FieldName = "Node Record 1 Subreport";
					options.SubReports[0].SubReportTitle = "Node Record 1 Subreport";
					options.SubReports[0].RecordSource = "NodeRecord";

					options.SubReports[1].FieldName = "Node Record 2 Subreport";
					options.SubReports[1].SubReportTitle = "Node Record 2 Subreport";
					options.SubReports[1].RecordSource = "NodeRecord";

					options.SubReports[2].FieldName = "Node Record 3 Subreport";
					options.SubReports[2].SubReportTitle = "Node Record 3 Subreport";
					options.SubReports[2].RecordSource = "NodeRecord";

					//mam 050806 - new subreport
					options.SubReports[3].FieldName = "Node Record 4 Subreport";
					options.SubReports[3].SubReportTitle = "Node Record 4 Subreport";
					options.SubReports[3].RecordSource = "NodeRecord";

					//mam - set new subreport options
					options.SubReports[4].FieldName = "SubreportGeneralFilter";
					options.SubReports[4].SubReportTitle = "SubreportGeneralFilter";
					options.SubReports[4].RecordSource = "DisciplineNodes";
					//</mam>

					break;
			}
			
			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{	
			//mam - comment	
			//return "";

			//mam - set new parameters
			if (currentSelectedFilters == "")
				return "SubreportGeneralFilter.Visible = False :";
			else
				return "SubreportGeneralFilter.Visible = True :";
			//</mam>
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ReportOptionsBase MyOptions = options;

			if (SaveXMLFile(MyOptions.XML, MyOptions.fileName))
			{
				switch (m_discipline.Type)
				{
					case WAM.Data.DisciplineType.Mechanical:
						return "DisciplineMechanical";
					case WAM.Data.DisciplineType.Structural:
						return "DisciplineStructural";
					case WAM.Data.DisciplineType.Land:
						return "DisciplineLand";
					case WAM.Data.DisciplineType.Pipes:
						return "DisciplinePipes";
					case WAM.Data.DisciplineType.Nodes:
						return "DisciplineNodes";
				}
			}

			return null;
		}

		#endregion /***** Overrides *****/

	}
}