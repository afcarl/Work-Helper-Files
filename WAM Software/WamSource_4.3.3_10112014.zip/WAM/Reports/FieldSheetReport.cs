using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for FieldSheetReport.
	/// </summary>
	public class FieldSheetReport : ReportBase
	{
		#region /***** Member Variables *****/
		public ReportOptionsBase m_options = new ReportOptionsBase();

		private WAM.Data.MajorComponent m_component = null;
		private WAM.Data.Discipline m_discipline = null;
		#endregion /***** Member Variables *****/

		#region /***** Member Methods *****/
		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/
		public override ReportOptionsBase LoadReportSettings(int id)
		{
			switch (m_discipline.Type.ToString())
			{
				case "Mechanical":
					m_options.ReportTitle = "Field Sheet Report Mech";
					break;
				case "Structural":
					m_options.ReportTitle = "Field Sheet Report Struct";
					break;
				case "Land":
					m_options.ReportTitle = "Field Sheet Report Land";
					break;
			}
			return m_options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{					
			StringBuilder builder = new StringBuilder(100);	

			if (m_discipline != null)
				builder.AppendFormat("[DisciplineName] = \"{0}\" : ", m_discipline.Name);
			else
				builder.Append("[DisciplineName] = \"\" : ");

			if (m_component != null)
			{
				builder.AppendFormat("[ComponentName] = \"{0}\" : ", m_component.Name);
				builder.AppendFormat("[ProcessName] = \"{0}\" : ", m_component.GetTreatmentProcess().Name);
				builder.AppendFormat("[FacilityName] = \"{0}\" : ", m_component.GetFacility().Name);

				// If they decide that they want current year or current ENR 
				// prefilled, get that from the facility object
			}
			else
			{
				builder.Append("[FacilityName] = \"\" : ");
				builder.Append("[ProcessName] = \"\" : ");
				builder.Append("[ComponentName] = \"\" : ");
			}

			//System.Diagnostics.Debug.WriteLine("builder = " + builder);
			return builder.ToString();
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			return null;
		}

		public static bool Print(WAM.Data.MajorComponent component)
		{
			FieldSheetReport myReport = null;
			ReportOptionsBase options = null;

			myReport = new FieldSheetReport();

			myReport.m_component = component;
			options = myReport.LoadReportSettings(component.ProcessID);

			//mam - added parameters (false = don't include photos)
			//	and pass in an empty string for the selectedFilters, which only apply to reports
			options.XML = component.GetXML(false, "");
			//</mam

			options.PrintOnly = true;

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//</mam>
		}

		public static bool Print(WAM.Data.Discipline discipline)
		{
			FieldSheetReport myReport = null;
			ReportOptionsBase options = null;

			myReport = new FieldSheetReport();
			myReport.m_discipline = discipline;

			myReport.m_component = discipline.GetMajorComponent();
			options = myReport.LoadReportSettings(discipline.ID);

			//mam - added parameters (false = don't include photos)
			//	and pass in an empty string for the selectedFilters, which only apply to reports
			options.XML = discipline.GetXML(false, "");
			//</mam

			options.PrintOnly = true;

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//</mam>
		}
		#endregion /***** Overrides *****/
	}
}