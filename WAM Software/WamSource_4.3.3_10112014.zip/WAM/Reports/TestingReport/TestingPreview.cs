using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using C1.Win.C1Report;

namespace WAM.Reports.TestingReport
{
	/// <summary>
	/// Summary description for TestingPreview.
	/// </summary>
	public class TestingPreview : System.Windows.Forms.Form
	{
		//private C1.C1PrintDocument.C1PrintDocument c1PrintDocument1;
		private System.Windows.Forms.Button button1;
		private C1.Win.C1PrintPreview.C1PrintPreview c1PrintPreview1 = new C1.Win.C1PrintPreview.C1PrintPreview();
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton1;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton2;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton3;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton4;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton5;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton6;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton7;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton8;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton9;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton10;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton11;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton12;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton13;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton14;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton15;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton16;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton17;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton18;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton19;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton20;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton21;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton22;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton23;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton24;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton25;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton26;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton27;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton28;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton29;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton30;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton31;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton32;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton33;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestingPreview()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();


			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

//		protected override void OnLoad(EventArgs e)
//		{
//			button1_Click(null, null);
//			base.OnLoad(e);
//		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.c1PrintPreview1 = new C1.Win.C1PrintPreview.C1PrintPreview();
			this.previewToolBarButton1 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton2 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton3 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton4 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton5 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton6 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton7 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton8 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton9 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton10 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton11 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton12 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton13 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton14 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton15 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton16 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton17 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton18 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton19 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton20 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton21 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton22 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton23 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton24 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton25 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton26 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton27 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton28 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton29 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton30 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton31 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton32 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton33 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			((System.ComponentModel.ISupportInitialize)(this.c1PrintPreview1)).BeginInit();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.button1.Location = new System.Drawing.Point(8, 283);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(48, 16);
			this.button1.TabIndex = 2;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// c1PrintPreview1
			// 
			this.c1PrintPreview1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1PrintPreview1.C1DPageSettings = "color:False;landscape:False;margins:100,100,100,100;papersize:850,1100,TABlAHQAdA" +
				"BlAHIA";
			this.c1PrintPreview1.Location = new System.Drawing.Point(4, 4);
			this.c1PrintPreview1.Name = "c1PrintPreview1";
			this.c1PrintPreview1.NavigationBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview1.NavigationBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview1.NavigationBar.OutlineView.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview1.NavigationBar.OutlineView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview1.NavigationBar.OutlineView.Indent = 19;
			this.c1PrintPreview1.NavigationBar.OutlineView.ItemHeight = 16;
			this.c1PrintPreview1.NavigationBar.OutlineView.TabIndex = 0;
			this.c1PrintPreview1.NavigationBar.OutlineView.Visible = false;
			this.c1PrintPreview1.NavigationBar.Padding = new System.Drawing.Point(6, 3);
			this.c1PrintPreview1.NavigationBar.TabIndex = 2;
			this.c1PrintPreview1.NavigationBar.ThumbnailsView.AutoArrange = true;
			this.c1PrintPreview1.NavigationBar.ThumbnailsView.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview1.NavigationBar.ThumbnailsView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview1.NavigationBar.ThumbnailsView.TabIndex = 0;
			this.c1PrintPreview1.NavigationBar.ThumbnailsView.Visible = true;
			this.c1PrintPreview1.NavigationBar.Width = 160;
			this.c1PrintPreview1.Size = new System.Drawing.Size(368, 272);
			this.c1PrintPreview1.Splitter.Cursor = System.Windows.Forms.Cursors.VSplit;
			this.c1PrintPreview1.Splitter.Width = 3;
			this.c1PrintPreview1.StatusBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview1.StatusBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview1.StatusBar.TabIndex = 4;
			this.c1PrintPreview1.TabIndex = 3;
			this.c1PrintPreview1.ToolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																									   this.previewToolBarButton1,
																									   this.previewToolBarButton2,
																									   this.previewToolBarButton3,
																									   this.previewToolBarButton4,
																									   this.previewToolBarButton5,
																									   this.previewToolBarButton6,
																									   this.previewToolBarButton7,
																									   this.previewToolBarButton8,
																									   this.previewToolBarButton9,
																									   this.previewToolBarButton10,
																									   this.previewToolBarButton11,
																									   this.previewToolBarButton12,
																									   this.previewToolBarButton13,
																									   this.previewToolBarButton14,
																									   this.previewToolBarButton15,
																									   this.previewToolBarButton16,
																									   this.previewToolBarButton17,
																									   this.previewToolBarButton18,
																									   this.previewToolBarButton19,
																									   this.previewToolBarButton20,
																									   this.previewToolBarButton21,
																									   this.previewToolBarButton22,
																									   this.previewToolBarButton23,
																									   this.previewToolBarButton24,
																									   this.previewToolBarButton25,
																									   this.previewToolBarButton26,
																									   this.previewToolBarButton27,
																									   this.previewToolBarButton28,
																									   this.previewToolBarButton29,
																									   this.previewToolBarButton30,
																									   this.previewToolBarButton31,
																									   this.previewToolBarButton32,
																									   this.previewToolBarButton33});
			this.c1PrintPreview1.ToolBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview1.ToolBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			// 
			// previewToolBarButton1
			// 
			this.previewToolBarButton1.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileOpen;
			this.previewToolBarButton1.ImageIndex = 0;
			this.previewToolBarButton1.ToolTipText = "File Open";
			// 
			// previewToolBarButton2
			// 
			this.previewToolBarButton2.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileSave;
			this.previewToolBarButton2.ImageIndex = 1;
			this.previewToolBarButton2.ToolTipText = "File Save";
			// 
			// previewToolBarButton3
			// 
			this.previewToolBarButton3.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FilePrint;
			this.previewToolBarButton3.ImageIndex = 2;
			this.previewToolBarButton3.ToolTipText = "Print";
			// 
			// previewToolBarButton4
			// 
			this.previewToolBarButton4.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.PageSetup;
			this.previewToolBarButton4.ImageIndex = 3;
			this.previewToolBarButton4.ToolTipText = "Page Setup";
			// 
			// previewToolBarButton5
			// 
			this.previewToolBarButton5.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Reflow;
			this.previewToolBarButton5.ImageIndex = 4;
			this.previewToolBarButton5.ToolTipText = "Reflow";
			// 
			// previewToolBarButton6
			// 
			this.previewToolBarButton6.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Stop;
			this.previewToolBarButton6.ImageIndex = 5;
			this.previewToolBarButton6.ToolTipText = "Stop";
			this.previewToolBarButton6.Visible = false;
			// 
			// previewToolBarButton7
			// 
			this.previewToolBarButton7.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton8
			// 
			this.previewToolBarButton8.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ShowNavigationBar;
			this.previewToolBarButton8.ImageIndex = 6;
			this.previewToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton8.ToolTipText = "Show Navigation Bar";
			// 
			// previewToolBarButton9
			// 
			this.previewToolBarButton9.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton9.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton10
			// 
			this.previewToolBarButton10.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseHand;
			this.previewToolBarButton10.ImageIndex = 7;
			this.previewToolBarButton10.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton10.ToolTipText = "Hand Tool";
			// 
			// previewToolBarButton11
			// 
			this.previewToolBarButton11.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoom;
			this.previewToolBarButton11.ImageIndex = 8;
			this.previewToolBarButton11.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton11.ToolTipText = "Zoom In Tool";
			// 
			// previewToolBarButton12
			// 
			this.previewToolBarButton12.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoomOut;
			this.previewToolBarButton12.ImageIndex = 25;
			this.previewToolBarButton12.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton12.ToolTipText = "Zoom Out Tool";
			this.previewToolBarButton12.Visible = false;
			// 
			// previewToolBarButton13
			// 
			this.previewToolBarButton13.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseSelect;
			this.previewToolBarButton13.ImageIndex = 9;
			this.previewToolBarButton13.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton13.ToolTipText = "Select Text";
			// 
			// previewToolBarButton14
			// 
			this.previewToolBarButton14.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FindText;
			this.previewToolBarButton14.ImageIndex = 10;
			this.previewToolBarButton14.ToolTipText = "Find Text";
			// 
			// previewToolBarButton15
			// 
			this.previewToolBarButton15.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton15.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton16
			// 
			this.previewToolBarButton16.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoFirst;
			this.previewToolBarButton16.ImageIndex = 11;
			this.previewToolBarButton16.ToolTipText = "First Page";
			// 
			// previewToolBarButton17
			// 
			this.previewToolBarButton17.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoPrev;
			this.previewToolBarButton17.ImageIndex = 12;
			this.previewToolBarButton17.ToolTipText = "Previous Page";
			// 
			// previewToolBarButton18
			// 
			this.previewToolBarButton18.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoNext;
			this.previewToolBarButton18.ImageIndex = 13;
			this.previewToolBarButton18.ToolTipText = "Next Page";
			// 
			// previewToolBarButton19
			// 
			this.previewToolBarButton19.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoLast;
			this.previewToolBarButton19.ImageIndex = 14;
			this.previewToolBarButton19.ToolTipText = "Last Page";
			// 
			// previewToolBarButton20
			// 
			this.previewToolBarButton20.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton20.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton21
			// 
			this.previewToolBarButton21.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryPrev;
			this.previewToolBarButton21.ImageIndex = 15;
			this.previewToolBarButton21.ToolTipText = "Previous View";
			// 
			// previewToolBarButton22
			// 
			this.previewToolBarButton22.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryNext;
			this.previewToolBarButton22.ImageIndex = 16;
			this.previewToolBarButton22.ToolTipText = "Next View";
			// 
			// previewToolBarButton23
			// 
			this.previewToolBarButton23.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton23.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton23.Visible = false;
			// 
			// previewToolBarButton24
			// 
			this.previewToolBarButton24.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomOut;
			this.previewToolBarButton24.ImageIndex = 17;
			this.previewToolBarButton24.ToolTipText = "Zoom Out";
			this.previewToolBarButton24.Visible = false;
			// 
			// previewToolBarButton25
			// 
			this.previewToolBarButton25.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomIn;
			this.previewToolBarButton25.ImageIndex = 18;
			this.previewToolBarButton25.ToolTipText = "Zoom In";
			this.previewToolBarButton25.Visible = false;
			// 
			// previewToolBarButton26
			// 
			this.previewToolBarButton26.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton26.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton26.Visible = false;
			// 
			// previewToolBarButton27
			// 
			this.previewToolBarButton27.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewActualSize;
			this.previewToolBarButton27.ImageIndex = 19;
			this.previewToolBarButton27.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton27.ToolTipText = "Actual Size";
			// 
			// previewToolBarButton28
			// 
			this.previewToolBarButton28.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFullPage;
			this.previewToolBarButton28.ImageIndex = 20;
			this.previewToolBarButton28.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton28.ToolTipText = "Full Page";
			// 
			// previewToolBarButton29
			// 
			this.previewToolBarButton29.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewPageWidth;
			this.previewToolBarButton29.ImageIndex = 21;
			this.previewToolBarButton29.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton29.ToolTipText = "Page Width";
			// 
			// previewToolBarButton30
			// 
			this.previewToolBarButton30.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewTwoPages;
			this.previewToolBarButton30.ImageIndex = 22;
			this.previewToolBarButton30.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton30.ToolTipText = "Two Pages";
			// 
			// previewToolBarButton31
			// 
			this.previewToolBarButton31.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFourPages;
			this.previewToolBarButton31.ImageIndex = 23;
			this.previewToolBarButton31.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton31.ToolTipText = "Four Pages";
			// 
			// previewToolBarButton32
			// 
			this.previewToolBarButton32.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton32.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton32.Visible = false;
			// 
			// previewToolBarButton33
			// 
			this.previewToolBarButton33.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Help;
			this.previewToolBarButton33.ImageIndex = 24;
			this.previewToolBarButton33.ToolTipText = "Help";
			this.previewToolBarButton33.Visible = false;
			// 
			// TestingPreview
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(376, 302);
			this.Controls.Add(this.c1PrintPreview1);
			this.Controls.Add(this.button1);
			this.Name = "TestingPreview";
			this.Text = "TestingPreview";
			((System.ComponentModel.ISupportInitialize)(this.c1PrintPreview1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


		private void button1_Click(object sender, System.EventArgs e)
		{
			//****************************

			C1.C1PrintDocument.C1PrintDocument c1PrintDocument1 = new C1.C1PrintDocument.C1PrintDocument();

			ArrayList arrayAllPages = new ArrayList();
			C1.Win.C1Report.C1Report reportTest = new C1Report();

			//****************************
//			// open xml file
//			string fileName = Path.GetDirectoryName(Application.ExecutablePath) + @"\SaveReportsTest.xml";
//			System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(fileName, System.Text.Encoding.Default);
//
//			// initialize xml file
//			writer.Formatting = System.Xml.Formatting.Indented;
//			writer.Indentation = 2;
//			writer.WriteStartDocument();
//			writer.WriteStartElement("Reports");
//
////			// save Customers report
////			//RenderCustomers();
////			c1r.ReportName = "Customers";
////			c1r.Save(writer);
////
////			// save Employees report
////			//RenderEmployees()
////			c1r.ReportName = "Employees";
////			c1r.Save(writer);
////
////			// close xml file
////			writer.WriteEndElement();
////			writer.Close();

			//****************************

//			FileStream fileStream = null;
//			//StreamWriter streamWriter = null;
//			//string filePath = @"E:\Projects\WAM\Testing\Preview\Reports.xml";
//			string filePath = @"E:\Projects\WAM\Testing\Preview\FacilityReport.xml";
//			//string filePath = @"E:\Projects\WAM\Testing\Preview\ReportOGR632068262253750000.xml";
//			//string filePath = @"E:\Projects\WAM\Testing\Preview";
//			fileStream = new FileStream(filePath, FileMode.Open);

//			c1PrintDocument1 = new C1.C1PrintDocument.C1PrintDocument();
//			c1PrintDocument1.Load(fileStream);
//			for (int i = 0; i < c1PrintDocument1.PageCount; i++)
//			{
//				//c1PrintPreview1.AddPage( c1PrintDocument1.PageAsMetafile
//				c1PrintPreview1.Pages.Add(c1PrintDocument1.PageAsMetafile(i + 1, true));
//			}

			//c1PrintDocument1.PageAsMetafile

			//****************************

			C1.Win.C1Report.C1Report report = new C1Report();
			//report.Load(@"E:\Projects\WAM\Testing\Preview\Reports.xml", "Facility Report");
			//report.Load(@"E:\Projects\WAM\Testing\Preview\MyReports2.xml", "Facility Report No Photos");
			//report.Load(@"E:\Projects\WAM\Testing\Preview\MyReports3.xml", "Facility Report No Photos");
			report.Load(@"E:\Projects\WAM\Testing\Preview\Reports.xml", "Facility Report");
			//c1PrintDocument1.Load(@"E:\Projects\WAM\Testing\Preview\Reports.xml");
			//****************************

			//filter test
			//report.DataSource.Filter = "CurrentYear > 2001";
			
			report.Render();
			Application.DoEvents();
			//report.Save(writer);
			//reportTest.Render();

			foreach (Image img in report.PageImages)
			{
				arrayAllPages.Add(img.Clone());
			}

//			for (int i = 0; i < c1PrintDocument1.PageCount; i++)
//			{
//				c1PrintPreview1.Pages.Add(c1PrintDocument1.PageAsMetafile(i + 1, true));
//			}

			//c1PrintDocument1.PageAsMetafile

			//System.IO.Stream stream = new Stream();
			//report.RenderToStream(stream, C1.Win.C1Report.FileFormatEnum.Excel);

			//save reports to xml file

			//****************************

			//assign report document to previewer
//			c1PrintPreview1.Document = report.Document;
//			foreach (Image img in report.PageImages)
//			{
//				c1PrintPreview1.AddPage(img);
//			}
//			//return;
			//****************************

			//arrayAllPages.AddRange(report.PageImages);
			reportTest.PageImages.AddRange(report.PageImages);

			//****************************

			//for (int i = 0; i <= 1; i++)
			//{
				C1.Win.C1Report.C1Report report2 = new C1Report();
				//report.Clear();
				//report.Load(@"E:\Projects\WAM\Testing\Preview\Reports.xml", "Facility Report");
				report2.Load(@"E:\Projects\WAM\Testing\Preview\MyReports2.xml", "Facility Report No Photos");
				report2.Render();
				c1PrintDocument1.Load(@"E:\Projects\WAM\Testing\Preview\MyReports2.xml");
				//report2.Save(writer);
				//****************************

				//alternatively, add pages from report to previewer
				//			for (int i = 0; i <= 19; i++)
				//			{
				foreach (Image img in report2.PageImages)
				{
					arrayAllPages.Add(img.Clone());

//					//builder.AppendFormat("Loading page " + c1PrintPreview.PageCount + "...");
//					//c1PrintPreview.StatusBar.Text = builder.ToString();
//					//c1PrintPreview1.StatusBar.Text = "Loading page " + (c1PrintPreview1.PageCount + 1) + "...";
//					//c1PrintPreview1.Pages.Add(img);
//					//c1PrintPreview1.Pages.AddPage(img);
//					c1PrintPreview1.AddPage(img);
//					//c1PrintPreview1.Pages.Add(report.Document.PageAsMetafile(i + 1, true);
				}
				//			}
			//}

			//arrayAllPages.AddRange(report2.PageImages);
			reportTest.PageImages.AddRange(report2.PageImages);
			//reportTest.Render();

//			for (int i = 0; i < arrayAllPages.Count; i++)
//			{
//				c1PrintPreview1.AddPage((Image)arrayAllPages[i]);
//			}

			Application.DoEvents();
			//reportTest.Document.Print();
			//c1PrintPreview1.Document = reportTest.Document;

			foreach (object o in arrayAllPages)
				this.c1PrintPreview1.Pages.Add(o);

//			for (int i = 0; i < c1PrintDocument1.PageCount; i++)
//			{
//				c1PrintPreview1.Pages.Add(c1PrintDocument1.PageAsMetafile(i + 1, true));
//			}


//			// close xml file
//			writer.WriteEndElement();
//			writer.Close();

			//c1PrintPreview1.StatusBar.Text = "Ready";

//			foreach (Image img in report.PageImages)
//			{
//				//builder.AppendFormat("Loading page " + c1PrintPreview.PageCount + "...");
//				//c1PrintPreview.StatusBar.Text = builder.ToString();
//				c1PrintPreview1.StatusBar.Text = "Loading page " + (c1PrintPreview1.PageCount + 1) + "...";
//				//c1PrintPreview1.Pages.Add(img);
//				c1PrintPreview1.Pages.AddPage(img);
//			}

			//****************************

			//****************************
			
			//C1.C1PrintDocument.C1PrintDocument oPrintDocument = new C1.C1PrintDocument.C1PrintDocument();
			//oPrintDocument.Load(filePath);
			//this.c1PrintPreview1.Document=oPrintDocument;

			//foreach (Image img in m_report.PageImages)
//			foreach (Image img in report.PageImages)
//			{
//				//builder.AppendFormat("Loading page " + c1PrintPreview.PageCount + "...");
//				//c1PrintPreview.StatusBar.Text = builder.ToString();
//				//c1PrintPreview.StatusBar.Text = "Loading page " + (c1PrintPreview.PageCount + 1) + "...";
//				c1PrintPreview1.Pages.Add(img);
//			}


		}
	}
}
