using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.Reports.TestingReport
{
	/// <summary>
	/// Summary description for TestingComboBox.
	/// </summary>
	public class TestingComboBox : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ComboBox comboBoxReportType;
		private System.Windows.Forms.TreeView treeView1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.TextBox textBoxTest;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		string allowedChar = "0123456789";
		char[] allowedChars = new char[10];
		string existingText = "";
		private System.Windows.Forms.Button buttonGetDataTable;
		int currentPos = 0;

		public TestingComboBox()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		protected override void OnLoad(EventArgs e)
		{
//			System.Data.DataSet dataSet = new System.Data.DataSet();
//			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
//			ArrayList ComboBoxItems = new ArrayList();
//
//			dataSet = dataAccess.GetDisconnectedDataset(
//				@"SELECT FilterReportLevelID AS ID, FilterReportLevel AS EnumValue, 
//				FilterReportLevelText AS Description FROM FilterReportLevel ORDER BY SortBy");
//			System.Data.DataTable dataTable = dataSet.Tables["ComboBoxItems"];
//
//			if (dataTable == null)
//				throw new Exception("Unable to load combo box");
//			
//			foreach (System.Data.DataRow dataRow in dataTable.Rows)
//			{
//				ComboBoxItems.Add(new WAM.Common.ComboBoxItem((int)dataRow["ID"], (string)dataRow["Description"], (int)dataRow["EnumValue"]));
//			}
//
//			comboBoxReportType.DataSource = ComboBoxItems;
//			
//			if (comboBoxReportType.Items.Count > 0)
//				comboBoxReportType.SelectedIndex = 0;
//
//			comboBoxReportType.SelectedIndexChanged += new EventHandler(comboBoxReportType_SelectedIndexChanged);
//			comboBoxReportType.DisplayMember = "ItemDescription";
//			comboBoxReportType.ValueMember = "ItemID";
		}

		private void comboBoxReportType_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (comboBoxReportType.SelectedIndex != -1)
			{
				// this gives the ID
				MessageBox.Show(comboBoxReportType.SelectedValue.ToString());

				// this calls the overriden string method
				MessageBox.Show(comboBoxReportType.SelectedItem.ToString());
			}
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.comboBoxReportType = new System.Windows.Forms.ComboBox();
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.textBoxTest = new System.Windows.Forms.TextBox();
			this.buttonGetDataTable = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// comboBoxReportType
			// 
			this.comboBoxReportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxReportType.DropDownWidth = 194;
			this.comboBoxReportType.Location = new System.Drawing.Point(16, 16);
			this.comboBoxReportType.MaxDropDownItems = 10;
			this.comboBoxReportType.Name = "comboBoxReportType";
			this.comboBoxReportType.Size = new System.Drawing.Size(194, 21);
			this.comboBoxReportType.TabIndex = 45;
			// 
			// treeView1
			// 
			this.treeView1.FullRowSelect = true;
			this.treeView1.HideSelection = false;
			this.treeView1.ImageIndex = -1;
			this.treeView1.Indent = 15;
			this.treeView1.Location = new System.Drawing.Point(24, 64);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.ShowLines = false;
			this.treeView1.ShowPlusMinus = false;
			this.treeView1.ShowRootLines = false;
			this.treeView1.Size = new System.Drawing.Size(248, 176);
			this.treeView1.TabIndex = 46;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(224, 16);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(56, 24);
			this.button1.TabIndex = 47;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(16, 280);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(64, 24);
			this.button2.TabIndex = 48;
			this.button2.Text = "button2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(104, 280);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(64, 24);
			this.button3.TabIndex = 49;
			this.button3.Text = "button3";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(192, 280);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(72, 24);
			this.button4.TabIndex = 50;
			this.button4.Text = "button4";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// textBoxTest
			// 
			this.textBoxTest.Location = new System.Drawing.Point(320, 72);
			this.textBoxTest.Name = "textBoxTest";
			this.textBoxTest.Size = new System.Drawing.Size(144, 20);
			this.textBoxTest.TabIndex = 51;
			this.textBoxTest.Text = "textBox1";
			this.textBoxTest.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTest_KeyPress);
			this.textBoxTest.TextChanged += new System.EventHandler(this.textBoxTest_TextChanged);
			// 
			// buttonGetDataTable
			// 
			this.buttonGetDataTable.Location = new System.Drawing.Point(352, 160);
			this.buttonGetDataTable.Name = "buttonGetDataTable";
			this.buttonGetDataTable.Size = new System.Drawing.Size(120, 40);
			this.buttonGetDataTable.TabIndex = 52;
			this.buttonGetDataTable.Text = "Get Data Table";
			this.buttonGetDataTable.Click += new System.EventHandler(this.buttonGetDataTable_Click);
			// 
			// TestingComboBox
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(544, 326);
			this.Controls.Add(this.buttonGetDataTable);
			this.Controls.Add(this.textBoxTest);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.treeView1);
			this.Controls.Add(this.comboBoxReportType);
			this.Name = "TestingComboBox";
			this.Text = "TestingComboBox";
			this.Load += new System.EventHandler(this.TestingComboBox_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			TreeNode node;

			treeView1.BeginUpdate();
			treeView1.Nodes.Clear();

//			node = new TreeNode();
//			node.Text = "This is the first node";
//			treeView1.Nodes.Add(node);
//
//			node = new TreeNode();
//			node.Text = "This is the second node";
//			node.ForeColor = Color.Gray;
//			treeView1.Nodes.Add(node);
//
//			node = new TreeNode();
//			node.Text = "This is the third node";
//			treeView1.Nodes.Add(node);

			node = new TreeNode();
			node.Text = "Parent";
			treeView1.Nodes.Add(node);

			node = new TreeNode();
			node.Text = "Parent\\Child";
			treeView1.Nodes.Add(node);

			node = new TreeNode();
			node.Text = @"Parent\Child\Grandchild";
			treeView1.Nodes.Add(node);

			treeView1.EndUpdate();
		}

		private void TestingComboBox_Load(object sender, System.EventArgs e)
		{
		
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(@"E:\Projects\WAM\WAM\bin\Debug");
			foreach (System.IO.FileInfo f in dir.GetFiles("*.mdb"))
			{
				MessageBox.Show(f.Name);
//				//LOAD FILES
//				ListViewItem lSingleItem = listView1.Items.Add(f.Name);
//				//SUB ITEMS
//				lSingleItem.SubItems.Add(Convert.ToString(f.Length));
//				lSingleItem.SubItems.Add(f.Extension);
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
			System.Data.DataTable dataTable;
			
//			//get table names
//			dataTable = update1.GetTables("");
//			//dataTable = update1.GetTables("CustomENR");
//			//dataTable = update1.GetTables("NoSuchTableNameExists");
//			if (dataTable == null)
//				throw new Exception("Error getting data from database.");
//			//list the tables in the database
//			//foreach (System.Data.DataRow dataRow in dataTable.Rows)
//			for (int i = 0; i < dataTable.Rows.Count; i++) 
//			{
//				//display table name
//				MessageBox.Show(dataTable.Rows[i].ItemArray[2].ToString());
//			}



//			//get table names
//			dataTable = dataAccess.GetTables("");
//			if (dataTable == null)
//				throw new Exception("Error getting data from database.");
//
//			for (int i = 0; i < dataTable.Rows.Count; i++) 
//			{
//				//display table name
//				//MessageBox.Show("Table name = " + dataTable.Rows[i].ItemArray[2].ToString());
//				System.Diagnostics.Debug.WriteLine("");
//				System.Diagnostics.Debug.WriteLine("TABLE: " + dataTable.Rows[i].ItemArray[2].ToString());
//				
//				//get field names
//				dataTableFields = dataAccess.GetFields(dataTable.Rows[i].ItemArray[2].ToString());
//				//MessageBox.Show("dataTable = " + dataTable.TableName);
//				if (dataTableFields == null)
//					MessageBox.Show("dataTableFields = null");
//
//				for (int j = 0; j < dataTableFields.Rows.Count; j++) 
//				{
//					//MessageBox.Show("Field name = " + dataTableFields.Rows[j].ItemArray[3].ToString());
//					System.Diagnostics.Debug.WriteLine(dataTableFields.Rows[j].ItemArray[3].ToString());
//				}
//			}

//			//get schema info
//			dataTable = dataAccess.GetTables("CustomENR");
//			if (dataTable == null)
//				throw new Exception("Error getting data from database.");
//			//List the schema info for the CustomENR table
//			for(int i = 0; i < dataTable.Columns.Count; i++) 
//			{
//				MessageBox.Show(dataTable.Columns[i].ToString() + " : " + 
//					dataTable.Rows[0][i].ToString());
//			}


			//get field names
			dataTable = dataAccess.GetFields("");
			//dataTable = update1.GetFields("CustomENR");
			//dataTable = update1.GetFields("NoSuchTableNameExists");
			if (dataTable == null)
				MessageBox.Show("dataTable = null");

			foreach(System.Data.DataColumn column in dataTable.Columns) 
			{
				MessageBox.Show(column.ToString());
			}

			dataTable.Select("TABLE_NAME = 'ComponentAssets'");
			for (int i = 0; i < dataTable.Rows.Count; i++) 
			{
				MessageBox.Show(dataTable.Rows[i].ItemArray[2].ToString());
				MessageBox.Show(dataTable.Rows[i].ItemArray[3].ToString());
			}
			//list columns for table CustomENR
//			for(int i = 0; i < dataTable.Columns.Count; i++) 
//			{
//				//MessageBox.Show(dataTable.Rows[i].ItemArray[3].ToString());
//				//MessageBox.Show(dataTable.Columns[i].ItemArray[3].ToString());
//				MessageBox.Show(dataTable.Columns[i].ToString());
//				//dataTable.Columns[3]. ToString()
//			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			WAM.Data.VerifyDatabaseSchema verify = new WAM.Data.VerifyDatabaseSchema();

//			if (verify.VerifyTableNamesAndFields("20CitiesENR.mdb"))
//				MessageBox.Show("20CitiesENR.mdb is valid");
//			else
//				MessageBox.Show("VB 20CitiesENR.mdb is not valid");
			
			if (verify.VerifyTableNamesAndFields("WAMUsing.mdb"))
			{
				MessageBox.Show("WAMUsing.mdb is valid");
				Drive.Data.OleDb.Jet40DataSource dataSource = new Drive.Data.OleDb.Jet40DataSource("WAMUsing.mdb");
				WAM.Data.WAMSource.CurrentSource =  dataSource;

//************************************************
				// Check to make sure that the database exists; if not, create it
				string dbPath = string.Format(@"{0}\WAMUsing.mdb", Drive.IO.Directory.GetApplicationPath());

//				if (!System.IO.File.Exists(dbPath))
//				{
//					string dbClean = string.Format(@"{0}\FreshWAM.dat", 
//						Drive.IO.Directory.GetApplicationPath());
//
//					if (!System.IO.File.Exists(dbClean))
//					{
//						MessageBox.Show(
//							"Unable to find database.",
//							"Invalid Database",
//							MessageBoxButtons.OK, MessageBoxIcon.Stop);
//						return;
//					}
//					else
//					{
//						System.IO.File.Copy(dbClean, dbPath, true);
//						System.IO.File.SetAttributes(dbPath, 
//							System.IO.FileAttributes.Normal);
//					}
//				}

				// Show splash screen
				WAM.UI.SplashScreenForm form = new WAM.UI.SplashScreenForm();
				form.Show();

				// Build the default cache
				WAM.Data.CacheManager.GetCacheForInfoSetID(WAM.Data.InfoSet.CurrentID);
				form.Close();
				form.Dispose();
//************************************************
			}
			else
				MessageBox.Show("VB WAMUsing.mdb is not valid");

//			if (verify.VerifyTableNamesAndFields("20CitiesENR.mdb"))
//				MessageBox.Show("20CitiesENR.mdb is valid");
//			else
//				MessageBox.Show("VB 20CitiesENR.mdb is not valid");
		}


		private void textBoxTest_TextChanged(object sender, System.EventArgs e)
		{
			//this.labelFileName.Text = this.textBoxTest.Text + ".mdb";

			bool changedText = false;
			string currentText = textBoxTest.Text;
			string correctedText = currentText;

			for (int i = currentText.Length - 1; i >= 0; i--)
			{
				//if (disallowedChar.IndexOf(currentText.Substring(i, 1)) > -1)
				if (allowedChar.IndexOf(currentText.Substring(i, 1)) == -1)
				{
					changedText = true;
					correctedText = correctedText.Remove(i, 1);
				}
			}

			if (changedText)
			{
				textBoxTest.Text = correctedText;
				currentPos = currentPos + (correctedText.Length - existingText.Length);
				if (currentPos > -1)
					textBoxTest.SelectionStart = currentPos;
			}
		}

		private void textBoxTest_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			currentPos = textBoxTest.SelectionStart;
			existingText = textBoxTest.Text;

			//if (disallowedChar.IndexOf(e.KeyChar) > -1)
			if (allowedChar.IndexOf(e.KeyChar) < 0)
			{
				e.Handled = true;
			}
		}

		private void LoadCharArray()
		{
			allowedChars[0] = '0';
			allowedChars[1] = '1';
			allowedChars[2] = '2';
			allowedChars[3] = '3';
			allowedChars[4] = '4';
			allowedChars[5] = '5';
			allowedChars[6] = '6';
			allowedChars[7] = '7';
			allowedChars[8] = '8';
			allowedChars[9] = '9';
		}

		private void buttonGetDataTable_Click(object sender, System.EventArgs e)
		{
//			//write xml file
//
//			string connectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
//			System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection(@connectionString);
//			System.Data.DataSet dataSet = new System.Data.DataSet();
//
////			System.Data.OleDb.OleDbDataAdapter dataAdapter1 = new System.Data.OleDb.OleDbDataAdapter(@"SELECT * FROM FieldSheetFac", conn);
////			System.Data.OleDb.OleDbDataAdapter dataAdapter2 = new System.Data.OleDb.OleDbDataAdapter(@"SELECT * FROM FieldSheetProc", conn);
////			dataAdapter1.Fill(dataSet, "FieldSheetFac");
////			dataAdapter2.Fill(dataSet, "FieldSheetProc");
//
//			System.Data.OleDb.OleDbDataAdapter dataAdapter = null;
//			dataAdapter = new System.Data.OleDb.OleDbDataAdapter(@"SELECT * FROM FieldSheetFac", conn);
//			dataAdapter.Fill(dataSet, "FieldSheetFac");
//			dataAdapter = new System.Data.OleDb.OleDbDataAdapter(@"SELECT * FROM FieldSheetProc", conn);
//			dataAdapter.Fill(dataSet, "FieldSheetProc");
//			
//			//doesn't work with Jet 4.0
////			System.Data.OleDb.OleDbDataAdapter dataAdapter1 = new System.Data.OleDb.OleDbDataAdapter(
////				"SELECT * FROM FieldSheetFac" + "SELECT * FROM FieldSheetProc", conn);
////			dataAdapter1.Fill(dataSet);
//
//			// Create a file name to write to.
//			string filenameWrite = @"E:\Projects\WAM\Testing\XML\Test4.xml";
//			// Create the FileStream to write with.
//			System.IO.FileStream myFileStreamWrite = new System.IO.FileStream
//				(filenameWrite, System.IO.FileMode.Create);
//			// Write to the file with the WriteXml method.
//			//thisDataSet.WriteXml(myFileStream);  
//
//			dataSet.WriteXml(myFileStreamWrite);
//
//			return;
//
//			foreach(System.Data.DataTable t in dataSet.Tables)
//			{
//				//Console.WriteLine("TableName: " + t.TableName);
//				MessageBox.Show("TableName: " + t.TableName);
//				foreach(System.Data.DataRow dataRow in t.Rows)
//				{
//					MessageBox.Show(dataRow["InfoSetID"].ToString() + "; " + dataRow["NodeID"].ToString());
////					foreach(System.Data.DataColumn c in t.Columns)
////					{
////						//Console.Write("\t " + r[c] );
////						MessageBox.Show(dataRow[c].ToString());
////					}
//					//Console.WriteLine();
//				}
//			}
//
//			return;
//
//			//*****************************************
//
//			//write xml file
//
//			WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
//			//System.Data.DataSet dataSet = dataAccess.GetDisconnectedDataset(@"SELECT * FROM FieldSheetFac");
//			dataSet = dataAccess.GetDisconnectedDataset(@"SELECT * FROM FieldSheetFac");
//
//			// Create a file name to write to.
//			string filename = @"E:\Projects\WAM\Testing\XML\Test3.xml";
//			// Create the FileStream to write with.
//			System.IO.FileStream myFileStream = new System.IO.FileStream
//				(filename, System.IO.FileMode.Create);
//			// Write to the file with the WriteXml method.
//			//thisDataSet.WriteXml(myFileStream);  
//
//			dataSet.WriteXml(myFileStream);
//
//			return;
//
////			if (dataSet == null)
////			{
////				throw new Exception("Database Error.");
////			}
////
////			foreach (System.Data.DataRow dataRow in dataTable.Rows)
//
//
//			//*****************************************************
//
//			//read xml file
//			System.Data.DataSet newDataSet = new System.Data.DataSet("New DataSet");
//			System.IO.FileStream fsReadXml = new System.IO.FileStream
//				(@"E:\Projects\WAM\Testing\XML\Test2.xml", System.IO.FileMode.Open);
//   
//			newDataSet.ReadXml(fsReadXml);
//			//PrintValues(newDataSet,"New DataSet");
//
//			foreach(System.Data.DataTable t in newDataSet.Tables)
//			{
//				//Console.WriteLine("TableName: " + t.TableName);
//				MessageBox.Show("TableName: " + t.TableName);
//				foreach(System.Data.DataRow r in t.Rows)
//				{
//					foreach(System.Data.DataColumn c in t.Columns)
//					{
//						//Console.Write("\t " + r[c] );
//						MessageBox.Show(r[c].ToString());
//					}
//					//Console.WriteLine();
//				}
//			}
//
//			return;
//
////		}
////
////		private void PrintValues(DataSet ds, string label)
////		{
////			Console.WriteLine("\n" + label);
////			foreach(DataTable t in ds.Tables)
////			{
////				Console.WriteLine("TableName: " + t.TableName);
////				foreach(DataRow r in t.Rows)
////				{
////					foreach(DataColumn c in t.Columns)
////					{
////						Console.Write("\t " + r[c] );
////					}
////					Console.WriteLine();
////				}
////			}
////		}
//			//*****************************************************
//
//			//WAM.Common.DataAccess dataAccess = new WAM.Common.DataAccess();
//			System.Data.DataTable dataTable = dataAccess.GetDisconnectedDataTable(@"SELECT * FROM FieldSheetFac");
//
//			//System.Data.DataTable dataTable = dataSet.Tables[0];
//
//			//			if (dataSet == null)
//			//			{
//			//				throw new Exception("Database Error.  ReportFilterForm.SetReportTemplateSettings.");
//			//			}
//			//
//			//			System.Data.DataTable dataTable = dataSet.Tables[0];
//
//			if (dataTable == null)
//			{
//				throw new Exception("Database Error.");
//			}
//
//			foreach (System.Data.DataRow dataRow in dataTable.Rows)
//			{
//				MessageBox.Show(dataRow["InfoSetID"].ToString() + "; " + dataRow["NodeID"].ToString());
//					//				if (dataRow["ReportType"] == System.DBNull.Value)
//					//					comboBoxReportType.SelectedIndex = 0;
//					//				else
//					//					comboBoxReportType.SelectedIndex = Convert.ToInt32(dataRow["ReportType"]);
//			}

		}

	}
}
