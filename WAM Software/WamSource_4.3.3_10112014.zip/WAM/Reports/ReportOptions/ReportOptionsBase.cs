using System;
using System.Configuration;

namespace WAM.Reports.ReportOptions
{
	/// <summary>
	/// Summary description for ReportOptions.
	/// </summary>
	public class ReportOptionsBase
	{
		public string StartString = "";
		public bool PrintOnly = false;
		public SubReportOptionsBase[] SubReports = null;
		public string ReportTitle = "";
		public string XML = "";
		public string fileName = "";

		//mam - this string will get set - there is no need to set it here (plus, it needs to be checked for a password)
		//public string ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
		//	Drive.IO.Directory.GetApplicationPath() + @"\WAM.mdb";
		public string ConnectionString = "";
		//</mam>
		
		//mam
		public bool IncludePhotos = true;
		public bool RenderToFile = false;
		public string ItemName = "";
		public string RenderFileExtension = "";
		//</mam>
	}

	public class SubReportOptionsBase
	{
		public string		FieldName = "";
		public string		SubReportTitle = "";
		public string		RecordSource = "";
	}
}
