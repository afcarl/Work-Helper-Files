using System;

namespace WAM.Reports.ReportOptions
{
	/// <summary>
	/// Summary description for ComponentAssetOptions.
	/// </summary>
	public class ComponentAssetOptions : ReportOptionsBase
	{
		public string FacilityName = "";
		public string ProcessName = "";
		public string ComponentName = "";
		public string DisciplineName = "";
		public int ID = 0;
	}
}
