using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WAM.Reports.UI
{
	/// <summary>
	/// Summary description for ReportViewerToolbar.
	/// </summary>
	public class ReportViewerToolbar : System.Windows.Forms.Form
	{
		private C1.Win.C1PrintPreview.C1PreviewToolBar c1PreviewToolbar1;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton34;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton35;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton36;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton37;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton38;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton39;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton40;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton41;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton42;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton43;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton44;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton45;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton46;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton47;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton48;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton49;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton50;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton51;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton52;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton53;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton54;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton55;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton56;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton57;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton58;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton59;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton60;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton61;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton62;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton63;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton64;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton65;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton66;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ReportViewerToolbar()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.c1PreviewToolbar1 = new C1.Win.C1PrintPreview.C1PreviewToolBar();
			this.previewToolBarButton34 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton35 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton36 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton37 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton38 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton39 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton40 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton41 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton42 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton43 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton44 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton45 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton46 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton47 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton48 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton49 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton50 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton51 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton52 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton53 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton54 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton55 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton56 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton57 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton58 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton59 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton60 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton61 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton62 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton63 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton64 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton65 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton66 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.panel1 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.c1PreviewToolbar1)).BeginInit();
			this.SuspendLayout();
			// 
			// c1PreviewToolbar1
			// 
			this.c1PreviewToolbar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.c1PreviewToolbar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																								 this.previewToolBarButton34,
																								 this.previewToolBarButton35,
																								 this.previewToolBarButton36,
																								 this.previewToolBarButton37,
																								 this.previewToolBarButton38,
																								 this.previewToolBarButton39,
																								 this.previewToolBarButton40,
																								 this.previewToolBarButton41,
																								 this.previewToolBarButton42,
																								 this.previewToolBarButton43,
																								 this.previewToolBarButton44,
																								 this.previewToolBarButton45,
																								 this.previewToolBarButton46,
																								 this.previewToolBarButton47,
																								 this.previewToolBarButton48,
																								 this.previewToolBarButton49,
																								 this.previewToolBarButton50,
																								 this.previewToolBarButton51,
																								 this.previewToolBarButton52,
																								 this.previewToolBarButton53,
																								 this.previewToolBarButton54,
																								 this.previewToolBarButton55,
																								 this.previewToolBarButton56,
																								 this.previewToolBarButton57,
																								 this.previewToolBarButton58,
																								 this.previewToolBarButton59,
																								 this.previewToolBarButton60,
																								 this.previewToolBarButton61,
																								 this.previewToolBarButton62,
																								 this.previewToolBarButton63,
																								 this.previewToolBarButton64,
																								 this.previewToolBarButton65,
																								 this.previewToolBarButton66});
			this.c1PreviewToolbar1.ButtonSize = new System.Drawing.Size(21, 21);
			this.c1PreviewToolbar1.DropDownArrows = true;
			this.c1PreviewToolbar1.ImageSet = C1.Win.C1PrintPreview.ToolBarImageSetEnum.XpStyle16;
			this.c1PreviewToolbar1.Location = new System.Drawing.Point(0, 0);
			this.c1PreviewToolbar1.MergeZoomButtons = true;
			this.c1PreviewToolbar1.Name = "c1PreviewToolbar1";
			this.c1PreviewToolbar1.PreviewPane = null;
			this.c1PreviewToolbar1.PrintPreview = null;
			this.c1PreviewToolbar1.ShowToolTips = true;
			this.c1PreviewToolbar1.Size = new System.Drawing.Size(656, 28);
			this.c1PreviewToolbar1.TabIndex = 1;
			this.c1PreviewToolbar1.Wrappable = false;
			// 
			// previewToolBarButton34
			// 
			this.previewToolBarButton34.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileOpen;
			this.previewToolBarButton34.ImageIndex = 0;
			this.previewToolBarButton34.ToolTipText = "File Open";
			// 
			// previewToolBarButton35
			// 
			this.previewToolBarButton35.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileSave;
			this.previewToolBarButton35.ImageIndex = 1;
			this.previewToolBarButton35.ToolTipText = "File Save";
			// 
			// previewToolBarButton36
			// 
			this.previewToolBarButton36.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FilePrint;
			this.previewToolBarButton36.ImageIndex = 2;
			this.previewToolBarButton36.ToolTipText = "Print";
			// 
			// previewToolBarButton37
			// 
			this.previewToolBarButton37.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.PageSetup;
			this.previewToolBarButton37.ImageIndex = 3;
			this.previewToolBarButton37.ToolTipText = "Page Setup";
			// 
			// previewToolBarButton38
			// 
			this.previewToolBarButton38.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Reflow;
			this.previewToolBarButton38.ImageIndex = 4;
			this.previewToolBarButton38.ToolTipText = "Reflow";
			// 
			// previewToolBarButton39
			// 
			this.previewToolBarButton39.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Stop;
			this.previewToolBarButton39.ImageIndex = 5;
			this.previewToolBarButton39.ToolTipText = "Stop";
			this.previewToolBarButton39.Visible = false;
			// 
			// previewToolBarButton40
			// 
			this.previewToolBarButton40.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton40.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton41
			// 
			this.previewToolBarButton41.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ShowNavigationBar;
			this.previewToolBarButton41.ImageIndex = 6;
			this.previewToolBarButton41.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton41.ToolTipText = "Show Navigation Bar";
			// 
			// previewToolBarButton42
			// 
			this.previewToolBarButton42.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton42.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton43
			// 
			this.previewToolBarButton43.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseHand;
			this.previewToolBarButton43.ImageIndex = 7;
			this.previewToolBarButton43.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton43.ToolTipText = "Hand Tool";
			// 
			// previewToolBarButton44
			// 
			this.previewToolBarButton44.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoom;
			this.previewToolBarButton44.ImageIndex = 8;
			this.previewToolBarButton44.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton44.ToolTipText = "Zoom In Tool";
			// 
			// previewToolBarButton45
			// 
			this.previewToolBarButton45.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoomOut;
			this.previewToolBarButton45.ImageIndex = 25;
			this.previewToolBarButton45.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton45.ToolTipText = "Zoom Out Tool";
			this.previewToolBarButton45.Visible = false;
			// 
			// previewToolBarButton46
			// 
			this.previewToolBarButton46.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseSelect;
			this.previewToolBarButton46.ImageIndex = 9;
			this.previewToolBarButton46.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton46.ToolTipText = "Select Text";
			// 
			// previewToolBarButton47
			// 
			this.previewToolBarButton47.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FindText;
			this.previewToolBarButton47.ImageIndex = 10;
			this.previewToolBarButton47.ToolTipText = "Find Text";
			// 
			// previewToolBarButton48
			// 
			this.previewToolBarButton48.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton48.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton49
			// 
			this.previewToolBarButton49.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoFirst;
			this.previewToolBarButton49.ImageIndex = 11;
			this.previewToolBarButton49.ToolTipText = "First Page";
			// 
			// previewToolBarButton50
			// 
			this.previewToolBarButton50.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoPrev;
			this.previewToolBarButton50.ImageIndex = 12;
			this.previewToolBarButton50.ToolTipText = "Previous Page";
			// 
			// previewToolBarButton51
			// 
			this.previewToolBarButton51.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoNext;
			this.previewToolBarButton51.ImageIndex = 13;
			this.previewToolBarButton51.ToolTipText = "Next Page";
			// 
			// previewToolBarButton52
			// 
			this.previewToolBarButton52.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoLast;
			this.previewToolBarButton52.ImageIndex = 14;
			this.previewToolBarButton52.ToolTipText = "Last Page";
			// 
			// previewToolBarButton53
			// 
			this.previewToolBarButton53.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton53.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton54
			// 
			this.previewToolBarButton54.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryPrev;
			this.previewToolBarButton54.ImageIndex = 15;
			this.previewToolBarButton54.ToolTipText = "Previous View";
			this.previewToolBarButton54.Visible = false;
			// 
			// previewToolBarButton55
			// 
			this.previewToolBarButton55.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryNext;
			this.previewToolBarButton55.ImageIndex = 16;
			this.previewToolBarButton55.ToolTipText = "Next View";
			this.previewToolBarButton55.Visible = false;
			// 
			// previewToolBarButton56
			// 
			this.previewToolBarButton56.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton56.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton56.Visible = false;
			// 
			// previewToolBarButton57
			// 
			this.previewToolBarButton57.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomOut;
			this.previewToolBarButton57.ImageIndex = 17;
			this.previewToolBarButton57.ToolTipText = "Zoom Out";
			this.previewToolBarButton57.Visible = false;
			// 
			// previewToolBarButton58
			// 
			this.previewToolBarButton58.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomIn;
			this.previewToolBarButton58.ImageIndex = 18;
			this.previewToolBarButton58.ToolTipText = "Zoom In";
			this.previewToolBarButton58.Visible = false;
			// 
			// previewToolBarButton59
			// 
			this.previewToolBarButton59.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton59.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton59.Visible = false;
			// 
			// previewToolBarButton60
			// 
			this.previewToolBarButton60.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewActualSize;
			this.previewToolBarButton60.ImageIndex = 19;
			this.previewToolBarButton60.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton60.ToolTipText = "Actual Size";
			// 
			// previewToolBarButton61
			// 
			this.previewToolBarButton61.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFullPage;
			this.previewToolBarButton61.ImageIndex = 20;
			this.previewToolBarButton61.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton61.ToolTipText = "Full Page";
			// 
			// previewToolBarButton62
			// 
			this.previewToolBarButton62.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewPageWidth;
			this.previewToolBarButton62.ImageIndex = 21;
			this.previewToolBarButton62.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton62.ToolTipText = "Page Width";
			// 
			// previewToolBarButton63
			// 
			this.previewToolBarButton63.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewTwoPages;
			this.previewToolBarButton63.ImageIndex = 22;
			this.previewToolBarButton63.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton63.ToolTipText = "Two Pages";
			// 
			// previewToolBarButton64
			// 
			this.previewToolBarButton64.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFourPages;
			this.previewToolBarButton64.ImageIndex = 23;
			this.previewToolBarButton64.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton64.ToolTipText = "Four Pages";
			// 
			// previewToolBarButton65
			// 
			this.previewToolBarButton65.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton65.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton65.Visible = false;
			// 
			// previewToolBarButton66
			// 
			this.previewToolBarButton66.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Help;
			this.previewToolBarButton66.ImageIndex = 24;
			this.previewToolBarButton66.ToolTipText = "Help";
			this.previewToolBarButton66.Visible = false;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 28);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(656, 458);
			this.panel1.TabIndex = 4;
			// 
			// ReportViewerToolbar
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(656, 486);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.c1PreviewToolbar1);
			this.Name = "ReportViewerToolbar";
			this.Text = "ReportViewerToolbar";
			((System.ComponentModel.ISupportInitialize)(this.c1PreviewToolbar1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

	}
}
