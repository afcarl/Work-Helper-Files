using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using C1.Win.C1Report;
using C1.Win.C1PrintPreview;
using System.Text;
using Drive.Configuration;
using WAM.UI;
using System.IO;

namespace WAM.Reports.UI
{
	/// <summary>
	/// Summary description for C1ReportDisplayerForm.
	/// </summary>
	public class C1ReportDisplayerForm : System.Windows.Forms.Form
	{
		#region /***** Member Variables ******/

		//mam - changed from private to public
		public C1.Win.C1PrintPreview.C1PrintPreview c1PrintPreview;
		public ArrayList filteredItemsReport;
		public string selectedFiltersReport = "";
		public string selectedSortOrderReport = "";
		private bool renderToFileOnly = false;
		private string currentMessage;
		private string reportExtension = "";
		//private string reportFolder = "";
		private string reportfileName = "";
		private C1.Win.C1Report.FileFormatEnum fileFormat;
		private ReportPrintStatusRender reportPrintStatusForm = new ReportPrintStatusRender();
		private WAM.UI.ReportPrintStatusRender.ReportUpdateEventArgs eventArgs = new WAM.UI.ReportPrintStatusRender.ReportUpdateEventArgs();
		//private System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
		private WAM.Data.ReportFormat reportFormat;
		//private System.IO.StreamWriter streamWriter = new System.IO.StreamWriter(@"E:\Projects\WAM\TestStream.rtf", true);
		//private System.IO.FileStream stream = new System.IO.FileStream(@"E:\Projects\WAM\TestStream.rtf", System.IO.FileMode.Append, System.IO.FileAccess.Read);
		//private int testCounter = 0;
		//</mam>

		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton1;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton2;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton3;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton4;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton5;
		public C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton6;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton7;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton8;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton9;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton10;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton11;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton12;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton13;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton14;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton15;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton16;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton17;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton18;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton19;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton20;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton21;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton22;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton23;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton24;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton25;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton26;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton27;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton28;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton29;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton30;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton31;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton32;
		private C1.Win.C1PrintPreview.PreviewToolBarButton previewToolBarButton33;
		private C1.Win.C1Report.C1Report m_report;

		//mam
		private ArrayList arrayAllPages = new ArrayList();
		//private C1.Win.C1Report.C1Report reportAllPages = new C1Report();
		private System.Windows.Forms.ToolBarButton toolBarButtonTest;
		//private bool allowButtonClick = false;
		public bool userCancelPreview = false;
		private System.Windows.Forms.ToolBarButton toolBarButtonSeparator1;
		
		private System.Windows.Forms.Timer timerStatus;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.RichTextBox richTextBox2;
		private System.Windows.Forms.HelpProvider helpProvider1;

		private System.ComponentModel.IContainer components;

		#endregion /***** Member Variables ******/
		
		#region /***** Constructors *****/
		public C1ReportDisplayerForm(Form parent)
		{
			//this.MdiParent = parent;
			InitializeComponent();
		}
		#endregion /***** Constructors *****/

		#region /***** Overrides *****/
		protected override void OnLoad(EventArgs e)
		{
			FormState	formState = 
				new FormState(AppSettings.Settings.GetSetting("ScreenSettings",	this.Name));
			formState.RestoreState(this);
			
			c1PrintPreview.PreviewButtonClick += 
				new PreviewToolBarButtonClickEventHandler(toolbarButtonClickHandler);

			this.Visible = true;

			//previewToolBarButton1.Visible = false;
			//previewToolBarButton4.Visible = false;

			c1PrintPreview.PreviewPane.ZoomMode = (C1.Win.C1PrintPreview.ZoomModeEnum)
				AppSettings.Settings.GetSettingInt(@"C1ReportDisplayerForm", "ZoomMode", 
				(int)C1.Win.C1PrintPreview.ZoomModeEnum.FullPage);

			//mam
			//c1PrintPreview.PreviewPane.ZoomPercent = 33;
			c1PrintPreview.PreviewPane.ZoomPercent = 
				AppSettings.Settings.GetSettingInt(@"C1ReportDisplayerForm", "ZoomPercent", (int)33);
			//</mam>

			bool NavBar = AppSettings.Settings.GetSettingBool
				(@"C1ReportDisplayerForm", "ShowNavigationBar", false);
			if (NavBar)
                c1PrintPreview.C1PreviewNavigationBar.Show();
			else
				c1PrintPreview.C1PreviewNavigationBar.Hide();

			c1PrintPreview.StatusBar.Text = "Loading...";

			base.OnLoad (e);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			CancelPreview = true;

			if (!SaveSettings())
			{
				e.Cancel = true;
				return;
			}

			AppSettings.Settings.SetSetting(@"ScreenSettings", this.Name, new FormState(this).ToString());
            				
			base.OnClosing (e);
			this.Dispose(true);
		}

		/// <summary>Clean up any resources being used.</summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion /***** Overrides *****/

		#region /***** Member Methods *****/
		private bool SaveSettings()
		{
			AppSettings.Settings.SetSetting(@"C1ReportDisplayerForm", "ShowNavigationBar", 
				previewToolBarButton8.Pushed.ToString());
			AppSettings.Settings.SetSetting(@"C1ReportDisplayerForm", "ZoomMode", 
				((int)c1PrintPreview.PreviewPane.ZoomMode).ToString());
			AppSettings.Settings.SetSetting(@"C1ReportDisplayerForm", "ZoomPercent", 
				((int)c1PrintPreview.PreviewPane.ZoomPercent).ToString());
			AppSettings.Settings.Save();
			return true;
		}

		public bool LoadReport(C1Report MyReport, string reportItemName)
		{
			try
			{
				StringBuilder builder = new StringBuilder(60);
				m_report = MyReport;

				//			//mam - just say "Loading" because the displaying the report names is not useful 
				//			//	(such as "CSS 1" for Major Component report)
				//			//builder.AppendFormat("Loading {0}", m_report.ReportName);
				//			builder.AppendFormat("Loading report...");
				//			c1PrintPreview.StatusBar.Text = builder.ToString();
				//			//</mam>
			
				//mam - we will be adding pages to the previewer, rather than assigning a document
				//c1PrintPreview.Document = m_report.Document;
				//<mam>

				//mam - new code to render the report so that PageImages is available
				m_report.Render();

				if (renderToFileOnly)
				{
					if (fileFormat == C1.Win.C1Report.FileFormatEnum.RTF)
					{
						try
						{
							System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
							m_report.RenderToStream(memoryStream, fileFormat);
							// Display the entire contents of the stream by setting its position to 0
							memoryStream.Position = 0;
							richTextBox1.Clear();
							richTextBox1.LoadFile(memoryStream, System.Windows.Forms.RichTextBoxStreamType.RichText);

							//replace the Wingdings font checked checkbox character with "true"
							int pos = 0;
							while (pos > -1)
							{
								pos = richTextBox1.Find("�", pos + 1, System.Windows.Forms.RichTextBoxFinds.None);
								if (pos > 0)
									richTextBox1.SelectedText = "    true";
							}

							//replace the Wingdings font unchecked checkbox character spaces
							pos = 0;
							while (pos > -1)
							{
								pos = richTextBox1.Find("�", pos + 1, System.Windows.Forms.RichTextBoxFinds.None);
								if (pos > 0)
									richTextBox1.SelectedText = "        ";
							}

							//USING THIS CODE:
							//System.IO.StreamWriter streamWriter = new System.IO.StreamWriter(@"D:\Projects\WAM\TestStream.rtf", false);
							//m_report.RenderToStream(streamWriter.BaseStream, C1.Win.C1Report.FileFormatEnum.RTF);
							//streamWriter.Close();
							////richTextBox1.LoadFile(@reportFolder + reportItemName + reportExtension);
							//richTextBox1.Clear();
							//richTextBox1.LoadFile(@"E:\Projects\WAM\TestStream.rtf");

							richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
							richTextBox2.SelectionLength = 0;
							richTextBox2.SelectedRtf = richTextBox1.Rtf;
							memoryStream.Flush();
						}
						catch (System.ArgumentException ex)
						{
							MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
					}
					else
					{
						//csv
						//never mind
					}
				}
				else
				{

					//mam - add each page of the report to the previewer
					arrayAllPages.Clear();
					foreach (Image img in m_report.PageImages)
					{
						arrayAllPages.Add(img.Clone());
					}

					foreach (object obj in arrayAllPages)
						c1PrintPreview.Pages.Add(obj);

					//mam - move the following code to UI\ReportFilterForm
					//			c1PrintPreview.StatusBar.Text = "Ready";
					//			c1PrintPreview.PreviewPane.ZoomMode = (C1.Win.C1PrintPreview.ZoomModeEnum)
					//				AppSettings.Settings.GetSettingInt(@"C1ReportDisplayerForm", "ZoomMode", 
					//				(int)C1.Win.C1PrintPreview.ZoomModeEnum.FullPage);
					//</mam>
				}

				return true;
			}
			//mam 07072011 - added Exception and changed error message
			catch(Exception ex)
			{
				//MessageBox.Show(this, "An error has occurred in LoadReport.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				Common.CommonTasks.ShowErrorMessage("ReportDisplayerForm.LoadReport", ex.Message);
				return false;
			}
		}

		public bool LoadReportMatrix(C1Report MyReport)
		{
			try
			{
				StringBuilder builder = new StringBuilder(60);

				m_report = MyReport;

				//mam - try, catch
				//mam 07072011 - added Exception
				try
				{
					m_report.Render();
				}
				catch(Exception ex)
				{
					//System.Diagnostics.Debug.WriteLine(ex.Message);
					string msg = "An error has occurred:" + Environment.NewLine + Environment.NewLine + ex.Message;
					//	+ Environment.NewLine + Environment.NewLine + m_report.DataSource.ConnectionString;
					//MessageBox.Show(this, ex.Message.ToString(), "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					MessageBox.Show(this, msg, "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return false;
				}

				if (renderToFileOnly)
				{
					return true;
				}

				c1PrintPreview.Document = m_report.Document;
				return true;
			}
			catch
			{
				MessageBox.Show(this, "An error has occurred.", "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		#endregion /***** Member Methods *****/

		#region /***** Toolbar *****/

		private void txtMessage(string str)
		{
			currentMessage = str;
		}

		private void timerStatus_Tick(object sender, System.EventArgs e)
		{
			if (currentMessage.Length != 0)
			{
				currentMessage = "";
				timerStatus.Enabled = false;

				RenderReportsToFile();

				try
				{
					reportPrintStatusForm.Close();
				}
				catch
				{
					System.Diagnostics.Debug.WriteLine("PrintStatusReport form did not close in timer_Tick");
				}
			}
		}

		private void RenderReportsToFile()
		{
			for (int pos = 0; pos < filteredItemsReport.Count; pos++)
			{
				if (filteredItemsReport[pos] is WAM.Data.Facility)
				{
					if (CurrentReportFormat == WAM.Data.ReportFormat.Matrix)
					{
						string reportXML = ((WAM.Data.Facility)filteredItemsReport[pos]).GetXMLMatrix(false, selectedFiltersReport, selectedSortOrderReport, filteredItemsReport);

						WAM.Reports.MatrixReport.PrintMatrix(
							(WAM.Data.Facility)filteredItemsReport[pos], false, false, selectedFiltersReport, selectedSortOrderReport, reportXML);
						break;
					}
					else
					{
						if (pos > 0)
						{
							richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
							richTextBox2.SelectionLength = 0;
							richTextBox2.SelectedText = ((char)12).ToString();
						}

						WAM.Reports.FacilityReport.Print((WAM.Data.Facility)filteredItemsReport[pos], false, false, selectedFiltersReport);
					}
				}
				else if (filteredItemsReport[pos] is WAM.Data.TreatmentProcess)
				{
					if (CurrentReportFormat == WAM.Data.ReportFormat.Matrix)
					{
						string reportXML = ((WAM.Data.TreatmentProcess)filteredItemsReport[pos]).GetXMLMatrix(false, selectedFiltersReport, selectedSortOrderReport, filteredItemsReport);

						WAM.Reports.MatrixReport.PrintMatrix(
							(WAM.Data.TreatmentProcess)filteredItemsReport[pos], false, false, selectedFiltersReport, selectedSortOrderReport, reportXML);
						break;
					}
					else
					{
						if (pos > 0)
						{
							richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
							richTextBox2.SelectionLength = 0;
							richTextBox2.SelectedText = ((char)12).ToString();
						}

						WAM.Reports.TreatmentProcessReport.Print((WAM.Data.TreatmentProcess)filteredItemsReport[pos], false, false, selectedFiltersReport);
					}
				}
				else if (filteredItemsReport[pos] is WAM.Data.MajorComponent)
				{
					if (CurrentReportFormat == WAM.Data.ReportFormat.Matrix)
					{
						string reportXML = ((WAM.Data.MajorComponent)filteredItemsReport[pos]).GetXMLMatrix(false, selectedFiltersReport, selectedSortOrderReport, filteredItemsReport);

						WAM.Reports.MatrixReport.PrintMatrix(
							(WAM.Data.MajorComponent)filteredItemsReport[pos], false, false, selectedFiltersReport, selectedSortOrderReport, reportXML);
						break;
					}
					else
					{
						if (pos > 0)
						{
							richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
							richTextBox2.SelectionLength = 0;
							richTextBox2.SelectedText = ((char)12).ToString();
						}

						WAM.Reports.MajorComponentReport.Print((WAM.Data.MajorComponent)filteredItemsReport[pos], false, false, selectedFiltersReport);
					}
				}
				else if (filteredItemsReport[pos] is WAM.Data.Discipline)
				{
					if (CurrentReportFormat == WAM.Data.ReportFormat.Matrix)
					{
						//string reportXML = ((WAM.Data.Discipline)filteredItemsReport[pos]).GetXMLMatrix(false, selectedFiltersReport, filteredItemsReport);
						WAM.Reports.MatrixReport matrixReport = new WAM.Reports.MatrixReport();
						string reportXML = matrixReport.GetXMLMatrix(false, selectedFiltersReport, selectedSortOrderReport, filteredItemsReport);

						WAM.Reports.MatrixReport.PrintMatrix(
							(WAM.Data.Discipline)filteredItemsReport[pos], false, false, selectedFiltersReport, selectedSortOrderReport, reportXML);
						break;
					}
					else
					{
						if (pos > 0)
						{
							richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
							richTextBox2.SelectionLength = 0;
							richTextBox2.SelectedText = ((char)12).ToString();
						}

						WAM.Reports.DisciplineReport.Print((WAM.Data.Discipline)filteredItemsReport[pos], false, false, selectedFiltersReport);
					}
				}
				else if (filteredItemsReport[pos] is WAM.Data.ComponentAsset)
				{
					// Get the component
					if (pos > 0)
					{
						richTextBox2.SelectionStart = richTextBox2.Rtf.Length;
						richTextBox2.SelectionLength = 0;
						richTextBox2.SelectedText = ((char)12).ToString();
					}
					WAM.Data.ComponentAsset tempAsset = (WAM.Data.ComponentAsset)filteredItemsReport[pos];
					WAM.Data.MajorComponent tempComponent = 
						WAM.Data.CacheManager.GetMajorComponent(tempAsset.InfoSetID, tempAsset.ComponentID);

					// Print Component Assets
					WAM.Reports.ComponentAssetsReport.Print(tempComponent, false, selectedFiltersReport);
				}

				//*******************
				if (reportPrintStatusForm.CancelPreview)
				{
					reportPrintStatusForm.CancelPreview = false;
					reportPrintStatusForm.Close();
					MessageBox.Show("The saving of reports has been cancelled.", "Save Reports", 
						MessageBoxButtons.OK, MessageBoxIcon.Information);

					return;
				}
				else
				{
					eventArgs.Status = "Saving report " + (pos + 1) + " of " + filteredItemsReport.Count.ToString();
					WAM.UI.ReportPrintStatusRender.InvokeUpdateEvent(null, eventArgs); 
				}
			}
		}

		private void toolbarButtonClickHandler(object sender, PreviewToolBarButtonClickEventArgs e)
		{
			//Control requestingControl = (Control)sender;

			if (e.Action == C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileOpen)
			{
				e.Handled = true;
				//allowButtonClick = false;
			}
			else if (e.Action == C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileSave)
			{
				e.Handled = true;

				string fileName = "";
				currentMessage = "";
				reportExtension = "";
				renderToFileOnly = false;

				//open the file save dialog
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.Filter = "Comma-Delimited (*.csv)|*.csv|Adobe pdf (*.pdf)|*.pdf|Word Rich Text Format (*.rtf)|*.rtf";
				saveFileDialog.Title = "Save Reports to File";
				saveFileDialog.ValidateNames = true;
				saveFileDialog.OverwritePrompt = true;
				saveFileDialog.CheckPathExists = true;
				saveFileDialog.ShowHelp = true;
				saveFileDialog.AddExtension = true;
				//saveFileDialog.CreatePrompt = true;
				//saveFileDialog.DefaultExt = true;
				saveFileDialog.ShowDialog();
				
				if(saveFileDialog.FileName == "")
				{
					//no file name selected
					return;
				}
				else
				{
					fileName = saveFileDialog.FileName.ToString();
					switch (saveFileDialog.FilterIndex)
					{
						case 1:
							//csv
							reportExtension = ".csv";
							if (!fileName.EndsWith(".csv"))
								fileName += ".csv";
							break;
						case 2:
							//pdf
							reportExtension = ".pdf";
							if (!fileName.EndsWith(".pdf"))
								fileName += ".pdf";
							break;
						case 3:
							//rtf
							reportExtension = ".rtf";
							fileFormat = C1.Win.C1Report.FileFormatEnum.RTF;
							if (!fileName.EndsWith(".rtf"))
								fileName += ".rtf";
							break;
					}
				}
				reportfileName = fileName;
				if (reportExtension == ".pdf")
				{
					renderToFileOnly = false;

					C1.C1PrintDocument.Export.PdfExporter pdfExporter = new C1.C1PrintDocument.Export.PdfExporter();
					try
					{
						this.Cursor = Cursors.WaitCursor;
						pdfExporter.Document = c1PrintPreview.Pages.ClonePageImages();
						//pdfExporter.Document = c1PrintPreview.Document;
						pdfExporter.EmbedTrueTypeFonts = false;
						pdfExporter.PreviewInAcrobat = false;
						pdfExporter.ShowOptions = false;
						pdfExporter.UseCompression = true;
						pdfExporter.OutputFileName = @fileName;
						pdfExporter.Export();

						this.Cursor = Cursors.Default;
						MessageBox.Show("The file has been saved successfully.", "Save Reports", 
							MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					catch(Exception ex)
					{
						this.Cursor = Cursors.Default;
						MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					finally
					{
						this.Cursor = Cursors.Default;
						pdfExporter = null;
					}

					return;
				}
				else if (reportExtension == ".csv")
				{
					renderToFileOnly = true;
				}
				else
				{
					renderToFileOnly = true;
				}

				if (reportExtension == ".rtf")
				{
					this.Cursor = Cursors.AppStarting;
					currentMessage = "";
					if (reportPrintStatusForm.IsDisposed || reportPrintStatusForm == null)
					{
						reportPrintStatusForm = new ReportPrintStatusRender();
					}
					timerStatus.Enabled = true;
					reportPrintStatusForm.OnMessage += new ReportPrintStatusRender.Message(this.txtMessage);
					reportPrintStatusForm.ShowDialog();

					if (CurrentReportFormat == WAM.Data.ReportFormat.Standard || filteredItemsReport[0] is WAM.Data.ComponentAsset)
					{
						try
						{
							richTextBox2.SaveFile(@fileName);
							this.Cursor = Cursors.Default;
							MessageBox.Show("The file has been saved successfully.", "Save Reports", 
								MessageBoxButtons.OK, MessageBoxIcon.Information);
						}
						catch(Exception ex)
						{
							this.Cursor = Cursors.Default;
							MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						finally
						{
							this.Cursor = Cursors.Default;
						}
					}
					else
					{
						try
						{
							System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
							m_report.RenderToStream(memoryStream, fileFormat);
							// Display the entire contents of the stream by setting its position to 0
							memoryStream.Position = 0;
							richTextBox1.Clear();
							richTextBox1.LoadFile(memoryStream, System.Windows.Forms.RichTextBoxStreamType.RichText);

							//System.Diagnostics.Debug.WriteLine(richTextBox1.Text.ToString());

							//replace the Wingdings font checked checkbox character with a tab and "true"
							int pos = 0;
							while (pos > -1)
							{
								pos = richTextBox1.Find("�", pos + 1, System.Windows.Forms.RichTextBoxFinds.None);
								if (pos > 0)
									richTextBox1.SelectedText = "	true";
							}

							//replace the Wingdings font unchecked checkbox character with a tab and spaces
							pos = 0;
							while (pos > -1)
							{
								pos = richTextBox1.Find("�", pos + 1, System.Windows.Forms.RichTextBoxFinds.None);
								if (pos > 0)
									richTextBox1.SelectedText = "	    ";
							}

							richTextBox1.SaveFile(@reportfileName, System.Windows.Forms.RichTextBoxStreamType.RichText);
							this.Cursor = Cursors.Default;
							MessageBox.Show("The file has been saved successfully.", "Save Reports", 
								MessageBoxButtons.OK, MessageBoxIcon.Information);
						}
						catch(Exception ex)
						{
							this.Cursor = Cursors.Default;
							MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
								MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						finally
						{
							this.Cursor = Cursors.Default;
						}
					}
				}
				else if (reportExtension == ".csv")
				{
					this.Cursor = Cursors.WaitCursor;
					System.IO.FileStream fileStream = null;
					System.IO.StreamWriter streamWriter = null;
					string reportCSV = "";

					if (filteredItemsReport[0] is WAM.Data.Facility)
					{
						WAM.Data.Facility facility = (WAM.Data.Facility)filteredItemsReport[0];
						reportCSV = facility.GetCSVData(selectedFiltersReport, selectedSortOrderReport, filteredItemsReport, (CurrentReportFormat == WAM.Data.ReportFormat.Standard));
					}
					else if (filteredItemsReport[0] is WAM.Data.TreatmentProcess)
					{
						WAM.Data.TreatmentProcess process = (WAM.Data.TreatmentProcess)filteredItemsReport[0];
						reportCSV = process.GetCSVData(selectedFiltersReport, selectedSortOrderReport, filteredItemsReport, (CurrentReportFormat == WAM.Data.ReportFormat.Standard));
					}
					else if (filteredItemsReport[0] is WAM.Data.MajorComponent)
					{
						WAM.Data.MajorComponent component = (WAM.Data.MajorComponent)filteredItemsReport[0];
						reportCSV = component.GetCSVData(selectedFiltersReport, selectedSortOrderReport, filteredItemsReport, (CurrentReportFormat == WAM.Data.ReportFormat.Standard));
					}
					else if (filteredItemsReport[0] is WAM.Data.Discipline)
					{
						WAM.Data.Discipline discipline = (WAM.Data.Discipline)filteredItemsReport[0];
						//if (discipline is WAM.Data.DisciplinePipe || discipline is WAM.Data.DisciplineNode)
							reportCSV = discipline.GetCSVData(selectedFiltersReport, selectedSortOrderReport, filteredItemsReport, (CurrentReportFormat == WAM.Data.ReportFormat.Standard));
						//else
						//	reportCSV = discipline.GetCSVData(selectedFiltersReport, selectedSortOrderReport, filteredItemsReport, false);
					}
					else if (filteredItemsReport[0] is WAM.Data.ComponentAsset)
					{
						WAM.Data.ComponentAsset componentAsset = (WAM.Data.ComponentAsset)filteredItemsReport[0];
						reportCSV = componentAsset.GetCSVData(selectedFiltersReport, filteredItemsReport);
					}	

					try
					{
						fileStream = new System.IO.FileStream(@fileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
						streamWriter = new System.IO.StreamWriter(fileStream);
						streamWriter.Write(reportCSV);

						this.Cursor = Cursors.Default;
						MessageBox.Show("The file has been saved successfully.", "Save Reports", 
							MessageBoxButtons.OK, MessageBoxIcon.Information);

						streamWriter.Close();
						fileStream.Close();
						streamWriter = null;
						fileStream = null;
					}
					catch(Exception ex)
					{
						this.Cursor = Cursors.Default;
						MessageBox.Show("An error has occurred: " + ex.Message.ToString(), "Error", 
							MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					finally
					{
						this.Cursor = Cursors.Default;
						if (streamWriter != null)
							streamWriter.Close();
						else if (fileStream != null)
							fileStream.Close();
					}
				}

				renderToFileOnly = false;
				return;
			}
			else if (e.Action == C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Help)
			{
				e.Handled = true;
				//MessageBox.Show("The help feature is not yet available.", "Help", 
				//	MessageBoxButtons.OK, MessageBoxIcon.Information);
				Help.ShowHelp(this, "WAMHelp.chm", System.Windows.Forms.HelpNavigator.Topic, "ReportsPrintPreview.htm");

				//this.menuItemHelpAbout_Click(sender, e);
			}
			else if (e.Action == C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Stop)
			{
				e.Handled = true;
				CancelPreview = true;
			}
		}

		#endregion /***** Toolbar *****/

		#region /***** Properties *****/

		//mam
		public bool CancelPreview
		{
			get { return userCancelPreview; }
			set { userCancelPreview = value; }
		}
		//</mam>

		//mam
		public WAM.Data.ReportFormat CurrentReportFormat
		{
			get { return reportFormat; }
			set { reportFormat = value; }
		}
		//</mam>

		#endregion /***** Properties *****/

		#region /***** Windows Form Designer generated code *****/
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(C1ReportDisplayerForm));
			this.c1PrintPreview = new C1.Win.C1PrintPreview.C1PrintPreview();
			this.previewToolBarButton1 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton2 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton3 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton4 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton5 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.toolBarButtonSeparator1 = new System.Windows.Forms.ToolBarButton();
			this.previewToolBarButton6 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton7 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton8 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton9 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton10 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton11 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton12 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton13 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton14 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton15 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton16 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton17 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton18 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton19 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton20 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton21 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton22 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton23 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton24 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton25 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton26 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton27 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton28 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton29 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton30 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton31 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton32 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.previewToolBarButton33 = new C1.Win.C1PrintPreview.PreviewToolBarButton();
			this.toolBarButtonTest = new System.Windows.Forms.ToolBarButton();
			this.m_report = new C1.Win.C1Report.C1Report();
			this.timerStatus = new System.Windows.Forms.Timer(this.components);
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.richTextBox2 = new System.Windows.Forms.RichTextBox();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			((System.ComponentModel.ISupportInitialize)(this.c1PrintPreview)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_report)).BeginInit();
			this.SuspendLayout();
			// 
			// c1PrintPreview
			// 
			this.c1PrintPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.c1PrintPreview.C1DPageSettings = "color:True;landscape:False;margins:100,100,100,100;papersize:850,1100,TABlAHQAdAB" +
				"lAHIA";
			this.c1PrintPreview.Location = new System.Drawing.Point(4, 0);
			this.c1PrintPreview.Name = "c1PrintPreview";
			this.c1PrintPreview.NavigationBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview.NavigationBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview.NavigationBar.OutlineView.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview.NavigationBar.OutlineView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview.NavigationBar.OutlineView.Indent = 19;
			this.c1PrintPreview.NavigationBar.OutlineView.ItemHeight = 16;
			this.c1PrintPreview.NavigationBar.OutlineView.TabIndex = 0;
			this.c1PrintPreview.NavigationBar.OutlineView.Visible = false;
			this.c1PrintPreview.NavigationBar.Padding = new System.Drawing.Point(6, 3);
			this.c1PrintPreview.NavigationBar.TabIndex = 2;
			this.c1PrintPreview.NavigationBar.ThumbnailsView.AutoArrange = true;
			this.c1PrintPreview.NavigationBar.ThumbnailsView.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview.NavigationBar.ThumbnailsView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview.NavigationBar.ThumbnailsView.TabIndex = 0;
			this.c1PrintPreview.NavigationBar.ThumbnailsView.Visible = true;
			this.c1PrintPreview.NavigationBar.Width = 160;
			this.c1PrintPreview.Size = new System.Drawing.Size(698, 490);
			this.c1PrintPreview.Splitter.Cursor = System.Windows.Forms.Cursors.VSplit;
			this.c1PrintPreview.Splitter.Width = 3;
			this.c1PrintPreview.StatusBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview.StatusBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview.StatusBar.TabIndex = 4;
			this.c1PrintPreview.TabIndex = 0;
			this.c1PrintPreview.ToolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																									  this.previewToolBarButton1,
																									  this.previewToolBarButton2,
																									  this.previewToolBarButton3,
																									  this.previewToolBarButton4,
																									  this.previewToolBarButton5,
																									  this.toolBarButtonSeparator1,
																									  this.previewToolBarButton6,
																									  this.previewToolBarButton7,
																									  this.previewToolBarButton8,
																									  this.previewToolBarButton9,
																									  this.previewToolBarButton10,
																									  this.previewToolBarButton11,
																									  this.previewToolBarButton12,
																									  this.previewToolBarButton13,
																									  this.previewToolBarButton14,
																									  this.previewToolBarButton15,
																									  this.previewToolBarButton16,
																									  this.previewToolBarButton17,
																									  this.previewToolBarButton18,
																									  this.previewToolBarButton19,
																									  this.previewToolBarButton20,
																									  this.previewToolBarButton21,
																									  this.previewToolBarButton22,
																									  this.previewToolBarButton23,
																									  this.previewToolBarButton24,
																									  this.previewToolBarButton25,
																									  this.previewToolBarButton26,
																									  this.previewToolBarButton27,
																									  this.previewToolBarButton28,
																									  this.previewToolBarButton29,
																									  this.previewToolBarButton30,
																									  this.previewToolBarButton31,
																									  this.previewToolBarButton32,
																									  this.previewToolBarButton33,
																									  this.toolBarButtonTest});
			this.c1PrintPreview.ToolBar.Cursor = System.Windows.Forms.Cursors.Default;
			this.c1PrintPreview.ToolBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.c1PrintPreview.ToolBar.ImageSet = C1.Win.C1PrintPreview.ToolBarImageSetEnum.XpStyle16;
			// 
			// previewToolBarButton1
			// 
			this.previewToolBarButton1.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileOpen;
			this.previewToolBarButton1.ImageIndex = 0;
			this.previewToolBarButton1.ToolTipText = "File Open";
			this.previewToolBarButton1.Visible = false;
			// 
			// previewToolBarButton2
			// 
			this.previewToolBarButton2.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FileSave;
			this.previewToolBarButton2.ImageIndex = 1;
			this.previewToolBarButton2.ToolTipText = "File Save";
			// 
			// previewToolBarButton3
			// 
			this.previewToolBarButton3.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FilePrint;
			this.previewToolBarButton3.ImageIndex = 2;
			this.previewToolBarButton3.ToolTipText = "Print";
			// 
			// previewToolBarButton4
			// 
			this.previewToolBarButton4.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.PageSetup;
			this.previewToolBarButton4.ImageIndex = 3;
			this.previewToolBarButton4.ToolTipText = "Page Setup";
			// 
			// previewToolBarButton5
			// 
			this.previewToolBarButton5.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Reflow;
			this.previewToolBarButton5.ImageIndex = 4;
			this.previewToolBarButton5.ToolTipText = "Reflow";
			this.previewToolBarButton5.Visible = false;
			// 
			// toolBarButtonSeparator1
			// 
			this.toolBarButtonSeparator1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton6
			// 
			this.previewToolBarButton6.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Stop;
			this.previewToolBarButton6.ImageIndex = 5;
			this.previewToolBarButton6.ToolTipText = "Stop";
			// 
			// previewToolBarButton7
			// 
			this.previewToolBarButton7.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton8
			// 
			this.previewToolBarButton8.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ShowNavigationBar;
			this.previewToolBarButton8.ImageIndex = 6;
			this.previewToolBarButton8.Pushed = true;
			this.previewToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton8.ToolTipText = "Show Navigation Bar";
			// 
			// previewToolBarButton9
			// 
			this.previewToolBarButton9.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton9.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton10
			// 
			this.previewToolBarButton10.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseHand;
			this.previewToolBarButton10.ImageIndex = 7;
			this.previewToolBarButton10.Pushed = true;
			this.previewToolBarButton10.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton10.ToolTipText = "Hand Tool";
			// 
			// previewToolBarButton11
			// 
			this.previewToolBarButton11.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoom;
			this.previewToolBarButton11.ImageIndex = 8;
			this.previewToolBarButton11.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton11.ToolTipText = "Zoom In Tool";
			// 
			// previewToolBarButton12
			// 
			this.previewToolBarButton12.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseZoomOut;
			this.previewToolBarButton12.ImageIndex = 25;
			this.previewToolBarButton12.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton12.ToolTipText = "Zoom Out Tool";
			this.previewToolBarButton12.Visible = false;
			// 
			// previewToolBarButton13
			// 
			this.previewToolBarButton13.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.MouseSelect;
			this.previewToolBarButton13.ImageIndex = 9;
			this.previewToolBarButton13.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton13.ToolTipText = "Select Text";
			// 
			// previewToolBarButton14
			// 
			this.previewToolBarButton14.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.FindText;
			this.previewToolBarButton14.ImageIndex = 10;
			this.previewToolBarButton14.ToolTipText = "Find Text";
			// 
			// previewToolBarButton15
			// 
			this.previewToolBarButton15.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton15.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton16
			// 
			this.previewToolBarButton16.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoFirst;
			this.previewToolBarButton16.Enabled = false;
			this.previewToolBarButton16.ImageIndex = 11;
			this.previewToolBarButton16.ToolTipText = "First Page";
			// 
			// previewToolBarButton17
			// 
			this.previewToolBarButton17.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoPrev;
			this.previewToolBarButton17.Enabled = false;
			this.previewToolBarButton17.ImageIndex = 12;
			this.previewToolBarButton17.ToolTipText = "Previous Page";
			// 
			// previewToolBarButton18
			// 
			this.previewToolBarButton18.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoNext;
			this.previewToolBarButton18.ImageIndex = 13;
			this.previewToolBarButton18.ToolTipText = "Next Page";
			// 
			// previewToolBarButton19
			// 
			this.previewToolBarButton19.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.GoLast;
			this.previewToolBarButton19.ImageIndex = 14;
			this.previewToolBarButton19.ToolTipText = "Last Page";
			// 
			// previewToolBarButton20
			// 
			this.previewToolBarButton20.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton20.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton21
			// 
			this.previewToolBarButton21.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryPrev;
			this.previewToolBarButton21.Enabled = false;
			this.previewToolBarButton21.ImageIndex = 15;
			this.previewToolBarButton21.ToolTipText = "Previous View";
			this.previewToolBarButton21.Visible = false;
			// 
			// previewToolBarButton22
			// 
			this.previewToolBarButton22.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.HistoryNext;
			this.previewToolBarButton22.Enabled = false;
			this.previewToolBarButton22.ImageIndex = 16;
			this.previewToolBarButton22.ToolTipText = "Next View";
			this.previewToolBarButton22.Visible = false;
			// 
			// previewToolBarButton23
			// 
			this.previewToolBarButton23.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton23.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton23.Visible = false;
			// 
			// previewToolBarButton24
			// 
			this.previewToolBarButton24.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomOut;
			this.previewToolBarButton24.ImageIndex = 17;
			this.previewToolBarButton24.ToolTipText = "Zoom Out";
			this.previewToolBarButton24.Visible = false;
			// 
			// previewToolBarButton25
			// 
			this.previewToolBarButton25.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ZoomIn;
			this.previewToolBarButton25.ImageIndex = 18;
			this.previewToolBarButton25.ToolTipText = "Zoom In";
			this.previewToolBarButton25.Visible = false;
			// 
			// previewToolBarButton26
			// 
			this.previewToolBarButton26.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton26.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			this.previewToolBarButton26.Visible = false;
			// 
			// previewToolBarButton27
			// 
			this.previewToolBarButton27.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewActualSize;
			this.previewToolBarButton27.ImageIndex = 19;
			this.previewToolBarButton27.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton27.ToolTipText = "Actual Size";
			// 
			// previewToolBarButton28
			// 
			this.previewToolBarButton28.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFullPage;
			this.previewToolBarButton28.ImageIndex = 20;
			this.previewToolBarButton28.Pushed = true;
			this.previewToolBarButton28.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton28.ToolTipText = "Full Page";
			// 
			// previewToolBarButton29
			// 
			this.previewToolBarButton29.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewPageWidth;
			this.previewToolBarButton29.ImageIndex = 21;
			this.previewToolBarButton29.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton29.ToolTipText = "Page Width";
			// 
			// previewToolBarButton30
			// 
			this.previewToolBarButton30.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewTwoPages;
			this.previewToolBarButton30.ImageIndex = 22;
			this.previewToolBarButton30.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
			this.previewToolBarButton30.ToolTipText = "Two Pages";
			// 
			// previewToolBarButton31
			// 
			this.previewToolBarButton31.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.ViewFourPages;
			this.previewToolBarButton31.ImageIndex = 23;
			this.previewToolBarButton31.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
			this.previewToolBarButton31.ToolTipText = "Four Pages";
			// 
			// previewToolBarButton32
			// 
			this.previewToolBarButton32.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.None;
			this.previewToolBarButton32.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// previewToolBarButton33
			// 
			this.previewToolBarButton33.Action = C1.Win.C1PrintPreview.ToolBarButtonActionEnum.Help;
			this.previewToolBarButton33.ImageIndex = 24;
			this.previewToolBarButton33.ToolTipText = "Help";
			// 
			// toolBarButtonTest
			// 
			this.toolBarButtonTest.ImageIndex = 16;
			this.toolBarButtonTest.Visible = false;
			// 
			// timerStatus
			// 
			this.timerStatus.Tick += new System.EventHandler(this.timerStatus_Tick);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(184, 96);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(48, 48);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "";
			// 
			// richTextBox2
			// 
			this.richTextBox2.Location = new System.Drawing.Point(184, 156);
			this.richTextBox2.Name = "richTextBox2";
			this.richTextBox2.Size = new System.Drawing.Size(48, 48);
			this.richTextBox2.TabIndex = 2;
			this.richTextBox2.Text = "";
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "WAMHelp.chm";
			// 
			// C1ReportDisplayerForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(708, 494);
			this.Controls.Add(this.c1PrintPreview);
			this.Controls.Add(this.richTextBox2);
			this.Controls.Add(this.richTextBox1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "C1ReportDisplayerForm";
			this.Text = "C1ReportDisplayerForm";
			((System.ComponentModel.ISupportInitialize)(this.c1PrintPreview)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_report)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


	}
}
