using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for CSS1Report.
	/// </summary>
	public class MajorComponentReport : ReportBase
	{
		private WAM.Data.MajorComponent m_component = null;

		#region /***** Member Variables *****/

		public ReportOptionsBase options = new ReportOptionsBase();

		//mam
		private static string currentSelectedFilters = "";
		//</mam>

		#endregion /***** Member Variables *****/
		
		#region /***** Member Methods *****/

//		public bool PrintReport(int certificateID)
//		{			
//			return RenderReport(LoadReportSettings(certificateID), true);
//		}

		//mam - add 'bool printOnly' and 'bool includePhotos' and 'selectedFilters'
		public static bool Print(WAM.Data.MajorComponent component, bool printOnly, 
			bool includePhotos, string selectedFilters)
		{
			MajorComponentReport myReport = null;
			ReportOptionsBase options = null;

			myReport = new MajorComponentReport();
			myReport.m_component = component;
			options = myReport.LoadReportSettings(component.ID);

			//mam changed from true to printOnly
			options.PrintOnly = printOnly;
			//</mam>

			//mam
			if (!includePhotos)
			{
				//options.ReportTitle = "CSS 1 No Photos";
				options.ReportTitle = options.ReportTitle + " No Photos";
			}
			//</mam>

			//mam
			currentSelectedFilters = selectedFilters;
			//</mam>

			//mam - added parameter
			options.XML = component.GetXML(includePhotos, selectedFilters);

			//mam - get component name
			string tempString = options.XML;
			int start = tempString.IndexOf("<ComponentName>");
			int end = tempString.IndexOf("</ComponentName>");
			options.ItemName = "Major Component " + @tempString.Substring(start + 15 + 9, end - (start + 15 + 9 + 3));
			//</mam>

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//</mam>
		}

		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/

		public override ReportOptionsBase LoadReportSettings(int id)
		{
			if (m_component.MechStructDisciplines)
			{
				options.ReportTitle = "CSS 1";
				options.fileName = "MajorComponent1.XML";
				
				//mam - remove SubReport[3] because it contains two fields that are duplicates of fields
				//	on another subreport
				//options.SubReports = new SubReportOptionsBase[4] { new SubReportOptionsBase(),
				//													 new SubReportOptionsBase(), new SubReportOptionsBase(), new SubReportOptionsBase()};

				//add new subreport
				//mam 07072011 - add two more subreports
				//mam 01222012 - added one more subreport
				//options.SubReports = new SubReportOptionsBase[4] 
				options.SubReports = new SubReportOptionsBase[7] 
					{
						new SubReportOptionsBase(),
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase()
					};
				//</mam>

				options.SubReports[0].FieldName = "CSS1 Record 1 Subreport";
				options.SubReports[0].SubReportTitle = "CSS1 Record 1 Subreport";

				//mam 07072011 - added subreport 1.5
				options.SubReports[1].FieldName = "CSS1 Record 1.5 Subreport";
				options.SubReports[1].SubReportTitle = "CSS1 Record 1.5 Subreport";

				//mam 07072011 - added subreport 1.6
				options.SubReports[2].FieldName = "CSS1 Record 1.6 Subreport";
				options.SubReports[2].SubReportTitle = "CSS1 Record 1.6 Subreport";

				//mam 01222012 - added subreport 1.7
				options.SubReports[3].FieldName = "CSS1 Record 1.7 Subreport";
				options.SubReports[3].SubReportTitle = "CSS1 Record 1.7 Subreport";

				options.SubReports[4].FieldName = "CSS1 Record 2 Subreport";
				options.SubReports[4].SubReportTitle = "CSS1 Record 2 Subreport";

				options.SubReports[5].FieldName = "CSS1 Record 3 Subreport";
				options.SubReports[5].SubReportTitle = "CSS1 Record 3 Subreport";

				//mam  - set RecordSource
				options.SubReports[0].RecordSource = "MajorComponent";

				//mam 07072011
				options.SubReports[1].RecordSource = "MajorComponent";

				options.SubReports[2].RecordSource = "Discipline";
				options.SubReports[3].RecordSource = "Discipline";

				//mam 07072011
				options.SubReports[4].RecordSource = "Discipline";
				//</mam>

				//mam 01222012
				options.SubReports[5].RecordSource = "Discipline";

				options.SubReports[6].FieldName = "SubreportGeneralFilter";
				options.SubReports[6].SubReportTitle = "SubreportGeneralFilter";
				options.SubReports[6].RecordSource = "MajorComponent";

				options.ConnectionString = GetXMLConnectionString(options.fileName);
			}
			else
			{
				options.ReportTitle = "CSS 2";
				options.fileName = "MajorComponent2.XML";

				//mam - remove SubReport[3] because it contains only fields that are duplicates of fields
				//	on another subreport
				//options.SubReports = new SubReportOptionsBase[4] { new SubReportOptionsBase(),
				//	new SubReportOptionsBase(), new SubReportOptionsBase(), new SubReportOptionsBase()};

				//mam - change count from 3 to 4 for new subreport
				options.SubReports = new SubReportOptionsBase[5] 
					{ 
						new SubReportOptionsBase(),
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase(), 
						new SubReportOptionsBase()
					};
				//</mam>

				options.SubReports[0].FieldName = "CSS2 Record 1 Subreport";
				options.SubReports[0].SubReportTitle = "CSS2 Record 1 Subreport";

				options.SubReports[1].FieldName = "CSS2 Record 2 Subreport";
				options.SubReports[1].SubReportTitle = "CSS2 Record 2 Subreport";

				options.SubReports[2].FieldName = "CSS2 Record 3 Subreport";
				options.SubReports[2].SubReportTitle = "CSS2 Record 3 Subreport";

				//mam - remove SubReport[3]
				//options.SubReports[3].FieldName = "CSS2 Record 4 Subreport";
				//options.SubReports[3].SubReportTitle = "CSS2 Record 4 Subreport";
				//</mam>

				//mam 050806 - add subreport 4
				options.SubReports[3].FieldName = "CSS2 Record 4 Subreport";
				options.SubReports[3].SubReportTitle = "CSS2 Record 4 Subreport";

				//mam  - set RecordSource
				options.SubReports[0].RecordSource = "MajorComponent";
				options.SubReports[1].RecordSource = "Discipline";
				options.SubReports[2].RecordSource = "Discipline";
				options.SubReports[3].RecordSource = "Discipline";
				//</mam>

				//mam - add new subreport
				options.SubReports[4].FieldName = "SubreportGeneralFilter";
				options.SubReports[4].SubReportTitle = "SubreportGeneralFilter";
				options.SubReports[4].RecordSource = "MajorComponent";
				//</mam>

				options.ConnectionString = GetXMLConnectionString(options.fileName);
			}


			return options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{					
			//mam - comment	
			//return "";

			//mam - set new parameters
			if (currentSelectedFilters == "")
				return "SubreportGeneralFilter.Visible = False :";
			else
				return "SubreportGeneralFilter.Visible = True :";
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ReportOptionsBase MyOptions = options;

			if (SaveXMLFile(MyOptions.XML, MyOptions.fileName))
				return "MajorComponent";
			else
				return null;
		}
		#endregion /***** Overrides *****/

	}
}
