using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;
using WAM.Data;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for MatrixReport.
	/// </summary>
	public class MatrixReport : ReportBase
	{
//		public MatrixReport()
//		{
//			//
//			// TODO: Add constructor logic here
//			//
//		}

		#region /***** Member Variables *****/
		public ReportOptionsBase options = new ReportOptionsBase ();

		private static string currentSelectedFilters = "";
		private static string currentSortOrder = "";
		private static string reportType = "";

		#endregion /***** Member Variables *****/
		
		#region /***** Member Print Methods *****/

		public static bool PrintMatrix(WAM.Data.Facility facility, bool printOnly, 
			bool includePhotos, string selectedFilters, string selectedSortOrder, string reportXML)
		{
			ReportBase		myReport = null;
			ReportOptionsBase options = null;

			myReport = new MatrixReport();
			reportType = "Facility";
			
			options = myReport.LoadReportSettingsMatrixFacility();
			options.PrintOnly = printOnly;
			options.XML = reportXML;
			currentSelectedFilters = selectedFilters;
			currentSortOrder = selectedSortOrder;
			
			return myReport.RenderReport(options, true);
		}

		public static bool PrintMatrix(WAM.Data.TreatmentProcess process, bool printOnly, 
			bool includePhotos, string selectedFilters, string selectedSortOrder, string reportXML)
		{
			ReportBase		myReport = null;
			ReportOptionsBase options = null;

			myReport = new MatrixReport();
			reportType = "Process";
			
			options = myReport.LoadReportSettingsMatrixProcess();
			options.PrintOnly = printOnly;
			options.XML = reportXML;
			currentSelectedFilters = selectedFilters;
			currentSortOrder = selectedSortOrder;
			
			return myReport.RenderReport(options, true);
		}

		public static bool PrintMatrix(WAM.Data.MajorComponent component, bool printOnly, 
			bool includePhotos, string selectedFilters, string selectedSortOrder, string reportXML)
		{
			try
			{
				ReportBase		myReport = null;
				ReportOptionsBase options = null;

				myReport = new MatrixReport();
				reportType = "Component";
			
				options = myReport.LoadReportSettingsMatrixComponent();
				options.PrintOnly = printOnly;
				options.XML = reportXML;
				currentSelectedFilters = selectedFilters;
				currentSortOrder = selectedSortOrder;
			
				return myReport.RenderReport(options, true);
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error has occurred in PrintMatrix: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		public static bool PrintMatrix(WAM.Data.Discipline discipline, bool printOnly, 
			bool includePhotos, string selectedFilters, string selectedSortOrder, string reportXML)
		{
			ReportBase		myReport = null;
			ReportOptionsBase options = null;

			myReport = new MatrixReport();
			reportType = "Discipline";
			
			options = myReport.LoadReportSettingsMatrixDiscipline();
			options.PrintOnly = printOnly;
			options.XML = reportXML;
			currentSelectedFilters = selectedFilters;
			currentSortOrder = selectedSortOrder;
			
			return myReport.RenderReport(options, true);
		}

		#endregion /***** Member Print Methods *****/

		#region /***** GetXML Methods *****/

		public string GetXMLMatrix(bool includePhotos, string selectedFilters, string selectedSortOrder, System.Collections.ArrayList filteredItems)
		{
			StringBuilder builder = new StringBuilder();
			Discipline discipline = null;
			MajorComponent curComponent = null;
			TreatmentProcess curProcess = null;
			Facility curFacility = null;
			decimal totalCurrentValue = 0;

			//remove (char)34
			if (selectedFilters != "" && selectedFilters.StartsWith(Convert.ToString((char)34)))
			{
				selectedFilters = selectedFilters.Remove(0,1);
				int j = selectedFilters.IndexOf((char)34);
				if (j > -1)
					selectedFilters = selectedFilters.Remove(j, 1);
			}

			builder.Append("<DisciplineData>\r\n");
			builder.Append("\t<Filters>\r\n");
			builder.AppendFormat("\t\t<SelectedFilters><![CDATA[{0}]]></SelectedFilters>\r\n", selectedFilters);
			builder.AppendFormat("\t\t<SelectedSortOrder><![CDATA[{0}]]></SelectedSortOrder>\r\n", selectedSortOrder);
			builder.Append("\t</Filters>\r\n");

			builder.Append("\t<Disciplines>\r\n");

			for (int pos = 0; pos < filteredItems.Count; pos++)
			{
				if ((Discipline)filteredItems[pos] is DisciplinePipe)
				{
					string xmlPipeNode = GetXMLMatrixPipe((DisciplinePipe)filteredItems[pos]);
					builder.Append(xmlPipeNode);
					continue;
				}
				else if ((Discipline)filteredItems[pos] is DisciplineNode)
				{
					string xmlPipeNode = GetXMLMatrixNode((DisciplineNode)filteredItems[pos]);
					builder.Append(xmlPipeNode);
					continue;
				}

				discipline = (Discipline)filteredItems[pos];
				curComponent = discipline.GetMajorComponent();
				curProcess = CacheManager.GetTreatmentProcess(discipline.InfoSetID, curComponent.ProcessID);
				curFacility = CacheManager.GetFacility(discipline.InfoSetID, curProcess.FacilityID);
				totalCurrentValue = discipline.GetCurrentValue();

				builder.Append("\t\t<Discipline>\r\n");
				//builder.AppendFormat("\t\t<FacilityName><![CDATA[{0}]]></FacilityName>\r\n", facility.Name);
				//builder.AppendFormat("\t\t<ProcessName><![CDATA[{0}]]></ProcessName>\r\n", process.Name);
				//builder.AppendFormat("\t\t<ComponentName><![CDATA[{0}]]></ComponentName>\r\n", component.Name);
				//builder.AppendFormat("\t\t<Discipline><![CDATA[{0}]]></Discipline>\r\n", Name);

				builder.AppendFormat("\t\t\t<GridNameFac><![CDATA[{0}]]></GridNameFac>\r\n", curFacility.Name);
				builder.AppendFormat("\t\t\t<GridNameProc><![CDATA[{0}]]></GridNameProc>\r\n", curProcess.Name);
				builder.AppendFormat("\t\t\t<GridNameComp><![CDATA[{0}]]></GridNameComp>\r\n", curComponent.Name);
				builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", discipline.Name);

				//mam 112806
				builder.AppendFormat("\t\t\t<GridRetired><![CDATA[{0}]]></GridRetired>\r\n", 
					curComponent.Retired? Convert.ToBoolean(curComponent.Retired).ToString(): "");

				builder.AppendFormat("\t\t\t<GridFacilityCurrentYear>{0}</GridFacilityCurrentYear>\r\n", curFacility.CurrentYear);
				builder.AppendFormat("\t\t\t<GridFacilityCurrentENR>{0}</GridFacilityCurrentENR>\r\n", curFacility.CurrentENR);

				//				if (includePhotos)
				//				{
				//					//removed two of the photos (the other Disciplines have only one photo)
				//					builder.AppendFormat("\t\t<PhotoPath><![CDATA[{0}]]></PhotoPath>\r\n", GetImagePath(1));
				//					builder.AppendFormat("\t\t<PhotoCaption><![CDATA[{0}]]></PhotoCaption>\r\n", CaptionPhoto1);
				//					//builder.AppendFormat("\t\t<PhotoPath2><![CDATA[{0}]]></PhotoPath2>\r\n", GetImagePath(2));
				//					//builder.AppendFormat("\t\t<PhotoCaption2><![CDATA[{0}]]></PhotoCaption2>\r\n", CaptionPhoto2);
				//					//builder.AppendFormat("\t\t<PhotoPath3><![CDATA[{0}]]></PhotoPath3>\r\n", GetImagePath(3));
				//					//builder.AppendFormat("\t\t<PhotoCaption3><![CDATA[{0}]]></PhotoCaption3>\r\n", CaptionPhoto3);
				//				}

				//mam 01042012 - if component is retired, show zero on report
				if (curComponent.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", 0);
					builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", 0);
					builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", 0);
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", discipline.ReplacementValueYear);
					builder.AppendFormat("\t\t\t<GridReplacementValueYearENR><![CDATA[{0:F0}]]></GridReplacementValueYearENR>\r\n", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));
				}
				else
				{
					//mam
					builder.AppendFormat("\t\t<OverrideAcquisitionCost><![CDATA[{0}]]></OverrideAcquisitionCost>\r\n", Convert.ToInt32(discipline.OverrideAcquisitionCost));
					builder.AppendFormat("\t\t<OverrideCurrentValue><![CDATA[{0}]]></OverrideCurrentValue>\r\n", Convert.ToInt32(discipline.OverrideCurrentValue));
					//</mam>

					//mam 050806
					builder.AppendFormat("\t\t<OverrideRepairCost><![CDATA[{0}]]></OverrideRepairCost>\r\n", Convert.ToInt32(discipline.OverrideRepairCost));

					//builder.AppendFormat("\t\t\t<Comments><![CDATA[{0}]]></Comments>\r\n", Comments);
					builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", discipline.AcquisitionCost);

					//mam 050806
					builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", discipline.AcquisitionCostEscalated);
					builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", discipline.ReplacementValueYear);
					builder.AppendFormat("\t\t\t<GridReplacementValueYearENR><![CDATA[{0:F0}]]></GridReplacementValueYearENR>\r\n", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));
				}

				//mam 01222012
				builder.AppendFormat("\t\t\t<GridReplacementNext><![CDATA[{0:F1}]]></GridReplacementNext>\r\n", discipline.ReplacementNext);

				//mam 07072011
				builder.AppendFormat("\t\t\t<GridNextReplacementYear><![CDATA[{0:F0}]]></GridNextReplacementYear>\r\n", discipline.NextReplacementYear);
				builder.AppendFormat("\t\t<OverrideNextReplacementYear><![CDATA[{0}]]></OverrideNextReplacementYear>\r\n", Convert.ToInt32(discipline.OverrideNextReplacementYear));

				//mam 01042012 - if component is retired, show zero on report
				if (curComponent.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", 0);	//999999
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", discipline.RehabCost);
				}

				//mam 07072011
				if (discipline is DisciplineLand)
				{
					builder.AppendFormat("\t\t\t<GridRehabCostYear><![CDATA[{0:F0}]]></GridRehabCostYear>\r\n", ((DisciplineLand)discipline).RehabCostYear);
					builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0:F1}]]></GridRehabInterval>\r\n", ((DisciplineLand)discipline).RehabInterval);
					builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0:F0}]]></GridRehabYearLast>\r\n", ((DisciplineLand)discipline).RehabYearLast);
					builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", ((DisciplineLand)discipline).RehabNext);

					//mam 01222012 - no longer using override for Time to Next Rehab
					//builder.AppendFormat("\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", Convert.ToInt32(((DisciplineLand)discipline).OverrideRehabNext));

					builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", ((DisciplineLand)discipline).RehabYearNext);

					//mam 01222012
					builder.AppendFormat("\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", Convert.ToInt32(((DisciplineLand)discipline).OverrideRehabYearNext));
				}
				else if (discipline is DisciplineMech)
				{
					builder.AppendFormat("\t\t\t<GridRehabCostYear><![CDATA[{0:F0}]]></GridRehabCostYear>\r\n", ((DisciplineMech)discipline).RehabCostYear);
					builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0:F1}]]></GridRehabInterval>\r\n", ((DisciplineMech)discipline).RehabInterval);
					builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0:F0}]]></GridRehabYearLast>\r\n", ((DisciplineMech)discipline).RehabYearLast);
					builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", ((DisciplineMech)discipline).RehabNext);

					//mam 01222012 - no longer using override for Time to Next Rehab
					//builder.AppendFormat("\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", Convert.ToInt32(((DisciplineMech)discipline).OverrideRehabNext));

					builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", ((DisciplineMech)discipline).RehabYearNext);

					//mam 01222012
					builder.AppendFormat("\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", Convert.ToInt32(((DisciplineMech)discipline).OverrideRehabYearNext));
				}
				else if (discipline is DisciplineStruct)
				{
					builder.AppendFormat("\t\t\t<GridRehabCostYear><![CDATA[{0:F0}]]></GridRehabCostYear>\r\n", ((DisciplineStruct)discipline).RehabCostYear);
					builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0:F1}]]></GridRehabInterval>\r\n", ((DisciplineStruct)discipline).RehabInterval);
					builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0:F0}]]></GridRehabYearLast>\r\n", ((DisciplineStruct)discipline).RehabYearLast);
					builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0:F1}]]></GridRehabNext>\r\n", ((DisciplineStruct)discipline).RehabNext);

					//mam 01222012 - no longer using override for Time to Next Rehab
					//builder.AppendFormat("\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", Convert.ToInt32(((DisciplineStruct)discipline).OverrideRehabNext));

					builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0:F0}]]></GridRehabYearNext>\r\n", ((DisciplineStruct)discipline).RehabYearNext);

					//mam 01222012
					builder.AppendFormat("\t\t<OverrideRehabYearNext><![CDATA[{0}]]></OverrideRehabYearNext>\r\n", Convert.ToInt32(((DisciplineStruct)discipline).OverrideRehabYearNext));
				}
				//</mam>

				//mam 01042012 - if component is retired, show zero on report
				if (curComponent.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", discipline.SalvageValue);
					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", discipline.AnnualMaintCost);
					builder.AppendFormat("\t\t\t<GridDisciplineInstallYear><![CDATA[{0:F0}]]></GridDisciplineInstallYear>\r\n", discipline.InstallationYear);
					builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipline.OriginalENR);
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
					builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0}]]></GridLevelOfService>\r\n", EnumHandlers.GetLOSShort(curComponent.LOS));
					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", 0);	//999999
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", string.Format("{0:#,##0}", 0));	//999999

					//mam 01222012
					builder.AppendFormat("\t\t\t<GridReplacementValueDesc><![CDATA[{0}]]></GridReplacementValueDesc>\r\n", "");	//XXXX
					builder.AppendFormat("\t\t\t<GridRehabCostDesc><![CDATA[{0}]]></GridRehabCostDesc>\r\n", "");	//XXXX
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", discipline.ReplacementValue);
					builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", discipline.SalvageValue);
					builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", discipline.AnnualMaintCost);
					builder.AppendFormat("\t\t\t<GridDisciplineInstallYear><![CDATA[{0:F0}]]></GridDisciplineInstallYear>\r\n", discipline.InstallationYear);
					builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipline.OriginalENR);
					builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
					builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0}]]></GridLevelOfService>\r\n", EnumHandlers.GetLOSShort(curComponent.LOS));
					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", EnumHandlers.GetConditionRankShort(discipline.ConditionRanking));
					builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", discipline.GetBookValue());
					builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", discipline.GetAnnualDepreciation());
					builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", discipline.GetCumulativeDepreciation());
					builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", string.Format("{0:#,##0}", discipline.GetEvaluatedValue()));

					//mam 01222012
					builder.AppendFormat("\t\t\t<GridReplacementValueDesc><![CDATA[{0}]]></GridReplacementValueDesc>\r\n", discipline.ReplacementValueDesc);
					builder.AppendFormat("\t\t\t<GridRehabCostDesc><![CDATA[{0}]]></GridRehabCostDesc>\r\n", discipline.RehabCostDesc);
				}

				//mam 01042012 - if component is retired, show zero on report
				if (curComponent.Retired && WAM.Common.Globals.ShowCostsAsZeroInReportForRetiredAssets)
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", 0));	//999999
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", 0));	//999999
				}
				else
				{
					//mam 112806 - check condition and overrides
					if (discipline.ConditionRanking == CondRank.No)
					{
						if (discipline.OverrideCurrentValue)
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0}]]></GridCurrentValue>\r\n", "N/A");
						}

						if (discipline.OverrideRepairCost)
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
						}
						else
						{
							builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0}]]></GridRepairCost>\r\n", "N/A");
						}
					}
					else
					{
						builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));
						builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
					}
				}

				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", discipline.GetEvaluatedRemainingUsefulLife());
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", discipline.GetEconomicUsefulLife());

				//note: there is no crit, vuln or risk at the disc level for land, mech, struct disciplines
				builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0}]]></GridOverallCriticality>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");

				if (discipline is DisciplineLand)
				{
					builder.AppendFormat("\t\t\t<GridDateOfInspection><![CDATA[{0}]]></GridDateOfInspection>\r\n", ((DisciplineLand)discipline).DateInspected.ToString("MM/dd/yyyy"));
					builder.AppendFormat("\t\t\t<GridEquipmentNum><![CDATA[{0}]]></GridEquipmentNum>\r\n", ((DisciplineLand)discipline).EquipmentNumber);
					builder.AppendFormat("\t\t\t<GridManufacturer><![CDATA[{0}]]></GridManufacturer>\r\n", ((DisciplineLand)discipline).Manufacturer);
					builder.AppendFormat("\t\t\t<GridAssessedBy><![CDATA[{0}]]></GridAssessedBy>\r\n", ((DisciplineLand)discipline).AssessedBy);
				}
				else if (discipline is DisciplineMech)
				{
					builder.AppendFormat("\t\t\t<GridDateOfInspection><![CDATA[{0}]]></GridDateOfInspection>\r\n", ((DisciplineMech)discipline).DateInspected.ToString("MM/dd/yyyy"));
					builder.AppendFormat("\t\t\t<GridEquipmentNum><![CDATA[{0}]]></GridEquipmentNum>\r\n", ((DisciplineMech)discipline).EquipmentNumber);
					builder.AppendFormat("\t\t\t<GridManufacturer><![CDATA[{0}]]></GridManufacturer>\r\n", ((DisciplineMech)discipline).Manufacturer);
					builder.AppendFormat("\t\t\t<GridAssessedBy><![CDATA[{0}]]></GridAssessedBy>\r\n", ((DisciplineMech)discipline).AssessedBy);
				}
				else if (discipline is DisciplineStruct)
				{
					builder.AppendFormat("\t\t\t<GridDateOfInspection><![CDATA[{0}]]></GridDateOfInspection>\r\n", ((DisciplineStruct)discipline).DateInspected.ToString("MM/dd/yyyy"));
					builder.AppendFormat("\t\t\t<GridEquipmentNum><![CDATA[{0}]]></GridEquipmentNum>\r\n", ((DisciplineStruct)discipline).EquipmentNumber);
					builder.AppendFormat("\t\t\t<GridManufacturer><![CDATA[{0}]]></GridManufacturer>\r\n", ((DisciplineStruct)discipline).Manufacturer);
					builder.AppendFormat("\t\t\t<GridAssessedBy><![CDATA[{0}]]></GridAssessedBy>\r\n", ((DisciplineStruct)discipline).AssessedBy);
				}

				//builder.AppendFormat("\t\t\t<GridRunHours><![CDATA[{0}]]></GridRunHours>\r\n", discipline.RunHours);
				//builder.AppendFormat("\t\t\t<GridRunningAtInspection><![CDATA[{0}]]></GridRunningAtInspection>\r\n", discipline.RunningAtInspect);

				builder.Append("\t\t</Discipline>\r\n");
				
				//System.Diagnostics.Debug.WriteLine("Disc = " + builder);
			}

			builder.Append("\t</Disciplines>\r\n");
			builder.Append("</DisciplineData>\r\n");

			System.Diagnostics.Debug.WriteLine("Entire XML String = " + builder.ToString());

			return builder.ToString();
		}

		private string GetXMLMatrixPipe(DisciplinePipe discipline)
		{
			StringBuilder builder = new StringBuilder();
			MajorComponent curComponent = null;
			TreatmentProcess curProcess = null;
			Facility curFacility = null;
			decimal totalCurrentValue = 0;

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			bool useNA = commonTasks.GetAllConditionNA(discipline);
			commonTasks = null;

			curComponent = discipline.GetMajorComponent();
			curProcess = CacheManager.GetTreatmentProcess(discipline.InfoSetID, curComponent.ProcessID);
			curFacility = CacheManager.GetFacility(discipline.InfoSetID, curProcess.FacilityID);
			totalCurrentValue = discipline.GetCurrentValue();

			builder.Append("\t\t<Discipline>\r\n");

			builder.AppendFormat("\t\t\t<GridNameFac><![CDATA[{0}]]></GridNameFac>\r\n", curFacility.Name);
			builder.AppendFormat("\t\t\t<GridNameProc><![CDATA[{0}]]></GridNameProc>\r\n", curProcess.Name);
			builder.AppendFormat("\t\t\t<GridNameComp><![CDATA[{0}]]></GridNameComp>\r\n", curComponent.Name);
			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", discipline.Name);

			//mam 112806
			builder.AppendFormat("\t\t\t<GridRetired><![CDATA[{0}]]></GridRetired>\r\n", 
				curComponent.Retired? Convert.ToBoolean(curComponent.Retired).ToString(): "");

			builder.AppendFormat("\t\t\t<GridFacilityCurrentYear>{0}</GridFacilityCurrentYear>\r\n", curFacility.CurrentYear);
			builder.AppendFormat("\t\t\t<GridFacilityCurrentENR>{0}</GridFacilityCurrentENR>\r\n", curFacility.CurrentENR);
			builder.AppendFormat("\t\t\t<GridDisciplineInstallYear><![CDATA[{0:F0}]]></GridDisciplineInstallYear>\r\n", discipline.InstallationYear);

			//pipes and nodes disciplines don't have ENR (only the individual pipe and node components do)
			//builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipine.OriginalENR);
			builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0}]]></GridDisciplineOriginalENR>\r\n", "N/A");
			//builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipline.GetOriginalENR(discipline.InstallationYear));

			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", discipline.AcquisitionCost);

			//mam 050806
			builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", discipline.AcquisitionCostEscalated);

			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", discipline.ReplacementValue);

			//mam 050806
			builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", discipline.ReplacementValueYear);
			builder.AppendFormat("\t\t\t<GridReplacementValueYearENR><![CDATA[{0:F0}]]></GridReplacementValueYearENR>\r\n", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));

			//mam 07072011
			builder.AppendFormat("\t\t\t<GridNextReplacementYear><![CDATA[{0}]]></GridNextReplacementYear>\r\n", "N/A");

			//mam 01042012
			builder.AppendFormat("\t\t\t<OverrideNextReplacementYear><![CDATA[{0}]]></OverrideNextReplacementYear>\r\n", 0);

			builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", discipline.RehabCost);

			//mam 07072011 - these rehab values do not exist at the discipline level for pipe disciplines
			builder.AppendFormat("\t\t\t<GridRehabCostYear><![CDATA[{0}]]></GridRehabCostYear>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0}]]></GridRehabInterval>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0}]]></GridRehabYearLast>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0}]]></GridRehabNext>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", 0);
			builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0}]]></GridRehabYearNext>\r\n", "N/A");

			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", discipline.SalvageValue);
			builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", discipline.AnnualMaintCost);
			//builder.AppendFormat("\t\t\t<GridInstallYear><![CDATA[{0:F0}]]></GridInstallYear>\r\n", discipline.InstallationYear);

			//if Total Current Value = zero, then OUL, LOS, Crit, Vuln, RUL, and Risk = N/A
			if (totalCurrentValue == 0)
			{
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0}]]></GridOrgUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0}]]></GridLevelOfService>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0}]]></GridOverallCriticality>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0}]]></GridRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");

				//mam 01042012 - add Economic Remaining Useful Life
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0}]]></GridEconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
				builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0:F1}]]></GridLevelOfService>\r\n", discipline.GetAverageLOS());
				builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", discipline.GetAverageCriticality());

				if (useNA)
				{

					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", string.Format("{0:F1}", discipline.GetAverageCondition()));
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", discipline.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", discipline.GetEconomicUsefulLife());
				}

				if (GetAllERULZero(discipline) && !GetAnyVulnerabilityOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", discipline.GetAverageVulnerability());
					builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", discipline.GetAverageVulnerability());
					builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", discipline.GetAverageRisk());
				}

				builder.AppendFormat("\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
				
			}

			//mam 112806 - moved down
			//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));

			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", discipline.GetBookValue());
			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", discipline.GetAnnualDepreciation());
			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", discipline.GetCumulativeDepreciation());

			if (useNA == true)
			{
				//mam 112806 - check useNA and override
				if (GetAnyCurrentValueOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0}]]></GridCurrentValue>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0}]]></GridEvaluatedValue>\r\n", "N/A");

				//mam 112806 - check override
				if (GetAnyRepairCostOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0}]]></GridRepairCost>\r\n", "N/A");
				}
			}
			else
			{
				//mam 112806
				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));

				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", string.Format("{0:#,##0}", discipline.GetEvaluatedValue()));
				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
			}

			builder.AppendFormat("\t\t\t<GridDateOfInspection><![CDATA[{0}]]></GridDateOfInspection>\r\n", ((DisciplinePipe)discipline).DateInspected.ToString("MM/dd/yyyy"));
			builder.AppendFormat("\t\t\t<GridEquipmentNum><![CDATA[{0}]]></GridEquipmentNum>\r\n", "");
			builder.AppendFormat("\t\t\t<GridManufacturer><![CDATA[{0}]]></GridManufacturer>\r\n", "");
			builder.AppendFormat("\t\t\t<GridAssessedBy><![CDATA[{0}]]></GridAssessedBy>\r\n", ((DisciplinePipe)discipline).AssessedBy);
			//**********************

			builder.Append("\t\t</Discipline>\r\n");

			System.Diagnostics.Debug.WriteLine("Pipe XML String = " + builder.ToString());
			System.Diagnostics.Debug.WriteLine("");

			return builder.ToString();
		}

		private string GetXMLMatrixNode(DisciplineNode discipline)
		{
			StringBuilder builder = new StringBuilder();
			MajorComponent curComponent = null;
			TreatmentProcess curProcess = null;
			Facility curFacility = null;
			decimal totalCurrentValue = 0;

			WAM.Common.CommonTasks commonTasks = new WAM.Common.CommonTasks();
			bool useNA = commonTasks.GetAllConditionNA(discipline);
			commonTasks = null;

			curComponent = discipline.GetMajorComponent();
			curProcess = CacheManager.GetTreatmentProcess(discipline.InfoSetID, curComponent.ProcessID);
			curFacility = CacheManager.GetFacility(discipline.InfoSetID, curProcess.FacilityID);
			totalCurrentValue = discipline.GetCurrentValue();

			builder.Append("\t\t<Discipline>\r\n");

			builder.AppendFormat("\t\t\t<GridNameFac><![CDATA[{0}]]></GridNameFac>\r\n", curFacility.Name);
			builder.AppendFormat("\t\t\t<GridNameProc><![CDATA[{0}]]></GridNameProc>\r\n", curProcess.Name);
			builder.AppendFormat("\t\t\t<GridNameComp><![CDATA[{0}]]></GridNameComp>\r\n", curComponent.Name);
			builder.AppendFormat("\t\t\t<GridName><![CDATA[{0}]]></GridName>\r\n", discipline.Name);

			//mam 112806
			builder.AppendFormat("\t\t\t<GridRetired><![CDATA[{0}]]></GridRetired>\r\n", 
				curComponent.Retired? Convert.ToBoolean(curComponent.Retired).ToString(): "");

			builder.AppendFormat("\t\t\t<GridFacilityCurrentYear>{0}</GridFacilityCurrentYear>\r\n", curFacility.CurrentYear);
			builder.AppendFormat("\t\t\t<GridFacilityCurrentENR>{0}</GridFacilityCurrentENR>\r\n", curFacility.CurrentENR);

			builder.AppendFormat("\t\t\t<GridDisciplineInstallYear><![CDATA[{0:F0}]]></GridDisciplineInstallYear>\r\n", discipline.InstallationYear);

			//pipes and nodes disciplines don't have ENR (only the individual pipe and node components do)
			//builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipline.OriginalENR);
			//builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridDisciplineOriginalENR><![CDATA[{0:F0}]]></GridDisciplineOriginalENR>\r\n", discipline.GetOriginalENR(discipline.InstallationYear));

			builder.AppendFormat("\t\t\t<GridAcquisitionCost><![CDATA[{0:F0}]]></GridAcquisitionCost>\r\n", discipline.AcquisitionCost);

			//mam 050806
			builder.AppendFormat("\t\t\t<GridAcquisitionCostEscalated><![CDATA[{0:F0}]]></GridAcquisitionCostEscalated>\r\n", discipline.AcquisitionCostEscalated);
			builder.AppendFormat("\t\t\t<GridReplacementValueYear><![CDATA[{0:F0}]]></GridReplacementValueYear>\r\n", discipline.ReplacementValueYear);
			builder.AppendFormat("\t\t\t<GridReplacementValueYearENR><![CDATA[{0:F0}]]></GridReplacementValueYearENR>\r\n", discipline.GetOriginalENR(Convert.ToInt16(discipline.ReplacementValueYear)));

			//mam 07072011
			builder.AppendFormat("\t\t\t<GridNextReplacementYear><![CDATA[{0}]]></GridNextReplacementYear>\r\n", "N/A");

			//mam 01042012
			builder.AppendFormat("\t\t\t<OverrideNextReplacementYear><![CDATA[{0}]]></OverrideNextReplacementYear>\r\n", 0);

			builder.AppendFormat("\t\t\t<GridRehabCost><![CDATA[{0:F0}]]></GridRehabCost>\r\n", discipline.RehabCost);

			//mam 07072011 - these rehab values do not exist at the discipline level for pipe disciplines
			builder.AppendFormat("\t\t\t<GridRehabCostYear><![CDATA[{0}]]></GridRehabCostYear>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabInterval><![CDATA[{0}]]></GridRehabInterval>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabYearLast><![CDATA[{0}]]></GridRehabYearLast>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<GridRehabNext><![CDATA[{0}]]></GridRehabNext>\r\n", "N/A");
			builder.AppendFormat("\t\t\t<OverrideRehabNext><![CDATA[{0}]]></OverrideRehabNext>\r\n", 0);
			builder.AppendFormat("\t\t\t<GridRehabYearNext><![CDATA[{0}]]></GridRehabYearNext>\r\n", "N/A");

			builder.AppendFormat("\t\t\t<GridReplacementValue><![CDATA[{0:F0}]]></GridReplacementValue>\r\n", discipline.ReplacementValue);
			builder.AppendFormat("\t\t\t<GridSalvageValue><![CDATA[{0:F0}]]></GridSalvageValue>\r\n", discipline.SalvageValue);
			builder.AppendFormat("\t\t\t<GridAnnualMaintenanceCost><![CDATA[{0:F0}]]></GridAnnualMaintenanceCost>\r\n", discipline.AnnualMaintCost);

			//builder.AppendFormat("\t\t\t<GridDisciplineInstallYear><![CDATA[{0:F0}]]></GridDisciplineInstallYear>\r\n", discipline.InstallationYear);

			//if Total Current Value = zero, then OUL, LOS, Crit, Vuln, RUL, and Risk = N/A
			if (totalCurrentValue == 0)
			{
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0}]]></GridOrgUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0}]]></GridLevelOfService>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0}]]></GridOverallCriticality>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridRemainingUsefulLife><![CDATA[{0}]]></GridRemainingUsefulLife>\r\n", "N/A");
				builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");

				//mam 01042012 - add Economic Remaining Useful Life
				builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0}]]></GridEconomicUsefulLife>\r\n", "N/A");
			}
			else
			{
				builder.AppendFormat("\t\t\t<GridOrgUsefulLife><![CDATA[{0:F1}]]></GridOrgUsefulLife>\r\n", discipline.OrgUsefulLife);
				builder.AppendFormat("\t\t\t<GridLevelOfService><![CDATA[{0}]]></GridLevelOfService>\r\n", discipline.GetAverageLOS());
				builder.AppendFormat("\t\t\t<GridOverallCriticality><![CDATA[{0:F1}]]></GridOverallCriticality>\r\n", discipline.GetAverageCriticality());

				if (useNA)
				{
					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0}]]></GridEvaluatedRemainingUsefulLife>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0}]]></GridEconomicUsefulLife>\r\n", "N/A");
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCondition><![CDATA[{0}]]></GridCondition>\r\n", string.Format("{0:F1}", discipline.GetAverageCondition()));
					builder.AppendFormat("\t\t\t<GridEvaluatedRemainingUsefulLife><![CDATA[{0:F1}]]></GridEvaluatedRemainingUsefulLife>\r\n", discipline.GetEvaluatedRemainingUsefulLife());
					builder.AppendFormat("\t\t\t<GridEconomicUsefulLife><![CDATA[{0:F1}]]></GridEconomicUsefulLife>\r\n", discipline.GetEconomicUsefulLife());
				}

				if (GetAllERULZero(discipline) && !GetAnyVulnerabilityOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0}]]></GridVulnerability>\r\n", "N/A");
					builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0}]]></GridRisk>\r\n", "N/A");
				}
				else
				{
					//mam 090105 - round vuln to 4 decimals rather than 2
					//builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F2}]]></GridVulnerability>\r\n", discipline.GetAverageVulnerability());
					builder.AppendFormat("\t\t\t<GridVulnerability><![CDATA[{0:F4}]]></GridVulnerability>\r\n", discipline.GetAverageVulnerability());
					builder.AppendFormat("\t\t\t<GridRisk><![CDATA[{0:F2}]]></GridRisk>\r\n", discipline.GetAverageRisk());
				}

				builder.AppendFormat("\t\t<GridRemainingUsefulLife><![CDATA[{0:F1}]]></GridRemainingUsefulLife>\r\n", discipline.GetRemainingUsefulLife());
				
			}

			//mam 112806 - moved down
			//builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));

			builder.AppendFormat("\t\t\t<GridBookValue><![CDATA[{0:F0}]]></GridBookValue>\r\n", discipline.GetBookValue());
			builder.AppendFormat("\t\t\t<GridAnnualDepreciation><![CDATA[{0:F0}]]></GridAnnualDepreciation>\r\n", discipline.GetAnnualDepreciation());
			builder.AppendFormat("\t\t\t<GridCumulativeDepreciation><![CDATA[{0:F0}]]></GridCumulativeDepreciation>\r\n", discipline.GetCumulativeDepreciation());

			if (useNA == true)
			{
				//mam 112806 - check useNA and override
				if (GetAnyCurrentValueOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0}]]></GridCurrentValue>\r\n", "N/A");
				}

				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0}]]></GridEvaluatedValue>\r\n", "N/A");

				//mam 112806 - check override
				if (GetAnyRepairCostOverridden(discipline))
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
				}
				else
				{
					builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0}]]></GridRepairCost>\r\n", "N/A");
				}
			}
			else
			{
				//mam 112806
				builder.AppendFormat("\t\t\t<GridCurrentValue><![CDATA[{0:F0}]]></GridCurrentValue>\r\n", string.Format("{0:#,##0}", discipline.GetCurrentValue()));

				builder.AppendFormat("\t\t\t<GridEvaluatedValue><![CDATA[{0:F0}]]></GridEvaluatedValue>\r\n", string.Format("{0:#,##0}", discipline.GetEvaluatedValue()));
				builder.AppendFormat("\t\t\t<GridRepairCost><![CDATA[{0:F0}]]></GridRepairCost>\r\n", string.Format("{0:#,##0}", discipline.GetRepairCost()));
			}

			builder.AppendFormat("\t\t\t<GridDateOfInspection><![CDATA[{0}]]></GridDateOfInspection>\r\n", ((DisciplineNode)discipline).DateInspected.ToString("MM/dd/yyyy"));
			builder.AppendFormat("\t\t\t<GridEquipmentNum><![CDATA[{0}]]></GridEquipmentNum>\r\n", "");
			builder.AppendFormat("\t\t\t<GridManufacturer><![CDATA[{0}]]></GridManufacturer>\r\n", "");
			builder.AppendFormat("\t\t\t<GridAssessedBy><![CDATA[{0}]]></GridAssessedBy>\r\n", ((DisciplineNode)discipline).AssessedBy);
			//**********************

			builder.Append("\t\t</Discipline>\r\n");

			return builder.ToString();
		}

		//routine to check whether any Vulnerability value is overridden
		private bool GetAnyVulnerabilityOverridden(Discipline discipline)
		{
			if (discipline is DisciplinePipe)
			{
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < pipes.Length; pos++)
					if (pipes[pos].OverrideVulnerability)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}
			else if (discipline is DisciplineNode)
			{
				// Retrieve the node data for the current discipline
				NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < nodes.Length; pos++)
					if (nodes[pos].OverrideVulnerability)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}

			return false;
		}

		//mam 112806
		private bool GetAnyCurrentValueOverridden(Discipline discipline)
		{
			if (discipline is DisciplinePipe)
			{
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < pipes.Length; pos++)
					if (pipes[pos].OverrideCurrentValue)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}
			else if (discipline is DisciplineNode)
			{
				// Retrieve the node data for the current discipline
				NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < nodes.Length; pos++)
					if (nodes[pos].OverrideCurrentValue)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}

			return false;
		}

		//mam 112806
		private bool GetAnyRepairCostOverridden(Discipline discipline)
		{
			if (discipline is DisciplinePipe)
			{
				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < pipes.Length; pos++)
					if (pipes[pos].OverrideRepairCost)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}
			else if (discipline is DisciplineNode)
			{
				// Retrieve the node data for the current discipline
				NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = false;

				for (int pos = 0; pos < nodes.Length; pos++)
					if (nodes[pos].OverrideRepairCost)
					{
						AllNA = true;
						break;
					}

				return AllNA;
			}

			return false;
		}

		private decimal GetCurrentValue(Discipline discipline)
		{
			if (discipline is DisciplinePipe)
			{

				// Retrieve the pipe data for the current discipline
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				decimal		totalCurVal = 0m;

				// Retrieve the total current value from the pipe data
				for (int pos = 0; pos < pipes.Length; pos++)
					totalCurVal += pipes[pos].GetCurrentValue();

				return totalCurVal;
			}
			else if (discipline is DisciplineNode)
			{
				// Retrieve the node data for the current discipline
				NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				decimal		totalCurVal = 0m;
	
				// Retrieve the total current value from the node data
				for (int pos = 0; pos < nodes.Length; pos++)
					totalCurVal += nodes[pos].GetCurrentValue();
	
				return totalCurVal;
			}

			return 0m;
		}

		//routine to check whether ERUL for all nodes is zero
		private bool GetAllERULZero(Discipline discipline)
		{
			if (discipline is DisciplinePipe)
			{
				PipeData[]	pipes = CacheManager.GetPipeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = true;

				for (int pos = 0; pos < pipes.Length; pos++)
					if (pipes[pos].GetEvaluatedRemainingUsefulLife() != 0)
					{
						AllNA = false;
						break;
					}

				return AllNA;
			}
			else if (discipline is DisciplineNode)
			{
				NodeData[]	nodes = CacheManager.GetNodeDataForDiscipline(discipline.InfoSetID, discipline.ID);
				bool AllNA = true;

				for (int pos = 0; pos < nodes.Length; pos++)
					if (nodes[pos].GetEvaluatedRemainingUsefulLife() != 0)
					{
						AllNA = false;
						break;
					}

				return AllNA;
			}

			return false;
		}

		#endregion /***** GetXML Methods *****/

		#region /***** Overrides *****/
		
		public override ReportOptionsBase LoadReportSettingsMatrixFacility()
		{
			options.fileName = "MatrixReport" + reportType + ".XML";
			options.ReportTitle = "MatrixReport" + reportType;

			options.SubReports = new SubReportOptionsBase[4] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};

			options.SubReports[0].FieldName = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].SubReportTitle = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].RecordSource = reportType;

			options.SubReports[1].FieldName = "SubreportGeneralFilter";
			options.SubReports[1].SubReportTitle = "SubreportGeneralFilter3";
			options.SubReports[1].RecordSource = "Filters";

			options.SubReports[2].FieldName = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].SubReportTitle = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].RecordSource = reportType;

			options.SubReports[3].FieldName = "SubreportSortOrder";
			options.SubReports[3].SubReportTitle = "SubreportSortOrder";
			options.SubReports[3].RecordSource = "Filters";

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			//MessageBox.Show(options.ConnectionString);
			return options;
		}

		public override ReportOptionsBase LoadReportSettingsMatrixProcess()
		{
			options.fileName = "MatrixReport" + reportType + ".XML";
			options.ReportTitle = "MatrixReport" + reportType;

			options.SubReports = new SubReportOptionsBase[4] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};

			options.SubReports[0].FieldName = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].SubReportTitle = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].RecordSource = reportType;

			options.SubReports[1].FieldName = "SubreportGeneralFilter";
			options.SubReports[1].SubReportTitle = "SubreportGeneralFilter3";
			options.SubReports[1].RecordSource = "Filters";

			options.SubReports[2].FieldName = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].SubReportTitle = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].RecordSource = reportType;

			options.SubReports[3].FieldName = "SubreportSortOrder";
			options.SubReports[3].SubReportTitle = "SubreportSortOrder";
			options.SubReports[3].RecordSource = "Filters";

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

		public override ReportOptionsBase LoadReportSettingsMatrixComponent()
		{
			//options.fileName = "MatrixReportTest.XML";
			//options.ReportTitle = "MatrixReportTest";
			options.fileName = "MatrixReport" + reportType + ".XML";
			options.ReportTitle = "MatrixReport" + reportType;

			options.SubReports = new SubReportOptionsBase[7] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};

			options.SubReports[0].FieldName = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].SubReportTitle = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].RecordSource = reportType;

			options.SubReports[1].FieldName = "SubreportGeneralFilter";
			options.SubReports[1].SubReportTitle = "SubreportGeneralFilter3";
			options.SubReports[1].RecordSource = "Filters";

			options.SubReports[2].FieldName = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].SubReportTitle = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[2].RecordSource = reportType;

			options.SubReports[3].FieldName = "MatrixReport" + reportType + "Subreport3";
			options.SubReports[3].SubReportTitle = "MatrixReport" + reportType + "Subreport3";
			options.SubReports[3].RecordSource = reportType;

			options.SubReports[4].FieldName = "MatrixReport" + reportType + "Subreport4";
			options.SubReports[4].SubReportTitle = "MatrixReport" + reportType + "Subreport4";
			options.SubReports[4].RecordSource = reportType;

			options.SubReports[5].FieldName = "MatrixReport" + reportType + "Subreport5";
			options.SubReports[5].SubReportTitle = "MatrixReport" + reportType + "Subreport5";
			options.SubReports[5].RecordSource = reportType;

			options.SubReports[6].FieldName = "SubreportSortOrder";
			options.SubReports[6].SubReportTitle = "SubreportSortOrder";
			options.SubReports[6].RecordSource = "Filters";

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

		public override ReportOptionsBase LoadReportSettingsMatrixDiscipline()
		{
			//options.fileName = "MatrixReportTest.XML";
			//options.ReportTitle = "MatrixReportTest";
			options.fileName = "MatrixReport" + reportType + ".XML";
			options.ReportTitle = "MatrixReport" + reportType;

			options.SubReports = new SubReportOptionsBase[12] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};

			options.SubReports[0].FieldName = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].SubReportTitle = "MatrixReport" + reportType + "Subreport1";
			options.SubReports[0].RecordSource = reportType;

			//mam 050806 - new subreport
			options.SubReports[1].FieldName = "MatrixReport" + reportType + "Subreport1-1";
			options.SubReports[1].SubReportTitle = "MatrixReport" + reportType + "Subreport1-1";
			options.SubReports[1].RecordSource = reportType;

			//mam 01222012 - new subreport
			options.SubReports[2].FieldName = "MatrixReport" + reportType + "Subreport1-2";
			options.SubReports[2].SubReportTitle = "MatrixReport" + reportType + "Subreport1-2";
			options.SubReports[2].RecordSource = reportType;

			//mam 07072011 - new subreports
			options.SubReports[3].FieldName = "MatrixReport" + reportType + "Subreport1.4";
			options.SubReports[3].SubReportTitle = "MatrixReport" + reportType + "Subreport1.4";
			options.SubReports[3].RecordSource = reportType;
			options.SubReports[4].FieldName = "MatrixReport" + reportType + "Subreport1.5";
			options.SubReports[4].SubReportTitle = "MatrixReport" + reportType + "Subreport1.5";
			options.SubReports[4].RecordSource = reportType;

			options.SubReports[5].FieldName = "SubreportGeneralFilter";
			options.SubReports[5].SubReportTitle = "SubreportGeneralFilter3";
			options.SubReports[5].RecordSource = "Filters";

			options.SubReports[6].FieldName = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[6].SubReportTitle = "MatrixReport" + reportType + "Subreport2";
			options.SubReports[6].RecordSource = reportType;

			options.SubReports[7].FieldName = "MatrixReport" + reportType + "Subreport4";
			options.SubReports[7].SubReportTitle = "MatrixReport" + reportType + "Subreport4";
			options.SubReports[7].RecordSource = reportType;

			options.SubReports[8].FieldName = "MatrixReport" + reportType + "Subreport4-1";
			options.SubReports[8].SubReportTitle = "MatrixReport" + reportType + "Subreport4-1";
			options.SubReports[8].RecordSource = reportType;

			options.SubReports[9].FieldName = "MatrixReport" + reportType + "Subreport5";
			options.SubReports[9].SubReportTitle = "MatrixReport" + reportType + "Subreport5";
			options.SubReports[9].RecordSource = reportType;

			options.SubReports[10].FieldName = "MatrixReport" + reportType + "Subreport6";
			options.SubReports[10].SubReportTitle = "MatrixReport" + reportType + "Subreport6";
			options.SubReports[10].RecordSource = reportType;

			options.SubReports[11].FieldName = "SubreportSortOrder";
			options.SubReports[11].SubReportTitle = "SubreportSortOrder";
			options.SubReports[11].RecordSource = "Filters";

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{	
			StringBuilder builder = new StringBuilder();

			if (currentSelectedFilters == "")
				builder.Append("SubreportGeneralFilter.Visible = False :");
			else
				builder.Append("SubreportGeneralFilter.Visible = True :");

			if (currentSortOrder == "")
				builder.Append("SubreportSortOrder.Visible = False :");
			else
				builder.Append("SubreportSortOrder.Visible = True :");

			return builder.ToString();
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ReportOptionsBase MyOptions = options;

			if (SaveXMLFile(MyOptions.XML, MyOptions.fileName))
			{
				//return reportType;
				return "Filters";
			}
			else
				return null;
		}
		#endregion /***** Overrides *****/

	}
}

