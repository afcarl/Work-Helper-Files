using System;
using System.IO;
using System.Text;
using System.Configuration;
using System.Windows.Forms;
using System.Drawing.Printing;
using C1.Win.C1Report;
using Drive.Configuration;
using WAM.Reports.ReportOptions;


namespace WAM.Reports
{
	/// <summary>
	/// Summary description for ReportBase.
	/// </summary>
	public abstract class ReportBase
	{
		#region /***** Member Variables *****/
		private C1Report m_report = new C1Report();

		#endregion /***** Member Variables *****/

		#region /***** Constructors *****/
		protected ReportBase()
		{
		}
		#endregion /***** Constructors *****/

		#region /***** Virtual / Abstract Methods *****/
		
		/// <summary>Displays an option form and prepares the report 
		/// (sets up parameters / data source)</summary>
		public abstract ReportOptionsBase LoadReportSettings(Form owner);
		
		public virtual ReportOptionsBase LoadReportSettings(int id)
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettings(long id)
		{
			return null;
		}

		//mam
		public virtual ReportOptionsBase LoadReportSettingsMatrix(int id)
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettingsMatrix()
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettingsMatrixFacility()
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettingsMatrixProcess()
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettingsMatrixComponent()
		{
			return null;
		}

		public virtual ReportOptionsBase LoadReportSettingsMatrixDiscipline()
		{
			return null;
		}
		//</mam>

		public virtual string GetReportPrinterString()
		{
			return "GenericReportSettings";
		}

		public virtual bool	LoadPrinterSettings()
		{
			if (m_report == null)
				return false;

			string			settingsSource = GetReportPrinterString();
			string			printerName = AppSettings.Settings.GetSetting(settingsSource, "PrinterName");
			string			paperSourceName = AppSettings.Settings.GetSetting(settingsSource, "PaperSource");
			PrinterSettings settings = m_report.Document.PrinterSettings;
			int				pos;

			if (printerName.Length > 0)
			{
				string		currentPrinter = settings.PrinterName;

				// If the printer name has been initialized, chances are 
				// everything else has been, too.
				settings.PrinterName = printerName;

				// If the printer is invalid, set it back to what it was on 
				// entry and exit.
				if (!settings.IsValid)
				{
					settings.PrinterName = currentPrinter;
					return true;
				}
			}

			if (paperSourceName.Length > 0)
			{
				PrinterSettings.PaperSourceCollection paperSources = 
					settings.PaperSources;

				for (pos = 0; pos < paperSources.Count; pos++)
				{
					if (string.Compare(paperSources[pos].SourceName, paperSourceName) == 0)
					{
						settings.DefaultPageSettings.PaperSource = paperSources[pos];
						break;
					}
				}
			}
			return true;
		}

//		public void			LoadPaperSizeSettings()
//		{
//			string			settingsSource = GetReportPrinterString();
//			string			paperSize = AppSettings.Settings.GetSetting(settingsSource, "PaperSize");
//			int				customPaperID = AppSettings.Settings.GetSettingInt(settingsSource, "CustomPaperID", 0);
//			bool			printLandscape = AppSettings.Settings.GetSettingBool(settingsSource, "Landscape", false);
//			PrinterSettings settings = m_report.Document.PrinterSettings;
//			int				pos;
//
//			if (customPaperID != 0)
//			{
//				// Load custom paper
//				ReportCustomPaperSize custPaper = 
//					new ReportCustomPaperSize(customPaperID);
//				settings.DefaultPageSettings.PaperSize =
//					new PaperSize(custPaper.Name, 
//					custPaper.Width, custPaper.Height);
//
//				m_report.Layout.PaperSize = PaperKind.Custom;
//				m_report.Layout.CustomHeight = custPaper.Height * 10;
//				m_report.Layout.CustomWidth = custPaper.Width * 10;
//			}
//			else if (paperSize.Length > 0)
//			{
//				PrinterSettings.PaperSizeCollection paperSizes = 
//					settings.PaperSizes;
//
//				for (pos = 0; pos < paperSizes.Count; pos++)
//				{
//					if (string.Compare(paperSizes[pos].PaperName, paperSize) == 0)
//					{
//						settings.DefaultPageSettings.PaperSize = paperSizes[pos];
//						break;
//					}
//				}
//			}
//
//			// Load orientation
//			settings.DefaultPageSettings.Landscape = printLandscape;
//
//			// If the report is already set to landscape, let it override printer settings
//			if (m_report.Layout.Orientation != OrientationEnum.Landscape)
//			{
//				if (printLandscape)
//					m_report.Layout.Orientation = OrientationEnum.Landscape;
//				else
//					m_report.Layout.Orientation = OrientationEnum.Portrait;
//			}
//		}

		protected abstract string SetParameterFields(ReportOptionsBase options);

		protected abstract string SetQuery(ReportOptionsBase options);
		#endregion /****** Virtual / Abstract Methods ******/

		#region /***** Member Methods *****/

		//mam - added parameter isMatrix
		public bool RenderReport(ReportOptionsBase options, bool isMatrix)
		{
			try
			{
				StringBuilder ReportPath = new StringBuilder(60);
				System.IO.FileInfo fileInfo = new System.IO.FileInfo(Application.ExecutablePath);
				ReportPath.AppendFormat("{0}\\Reports.xml", fileInfo.DirectoryName.ToString());
				string EndString = "</Report>";

				string recordSource = SetQuery(options);

				if (m_report == null)
					m_report = new C1Report();

				if (options.ReportTitle.Length > 0)
				{
					// Initializes ReportDefinition
					m_report.Load(ReportPath.ToString(), options.ReportTitle);
				}
				else
				{
					// When ReportTitle is invalid, use the old way of generating the 
					// report (i.e., use our own XML reader method)
					StringBuilder reportBuilder = new StringBuilder(1024);

					reportBuilder.Append(XMLReader(
						ReportPath.ToString(), options.StartString, EndString));

					m_report.ReportDefinition = reportBuilder.ToString();
				}

			// Handle Subreports, if there are any
			if (options.SubReports != null)
				{
					for (int x = 0; x < options.SubReports.Length; x++)
					{
						C1Report subReport = new C1Report();

						subReport.Load(ReportPath.ToString(), options.SubReports[x].SubReportTitle);
						subReport.DataSource.ConnectionString = options.ConnectionString;
						subReport.DataSource.RecordSource = options.SubReports[x].RecordSource;
						if (options.SubReports[x].RecordSource.Length > 0)
						{
							m_report.DataSource.RecordSource = options.SubReports[x].RecordSource;
						}

						m_report.Fields[options.SubReports[x].FieldName].Subreport = subReport;
					}
				}

				//mam 07072011 - change the crit placeholder titles to the real crit names and hide unused crits
				string reportName = m_report.ReportName;
				string subReportName = "";
				switch (reportName)
				{
					case "CSS 1":
					case "CSS 1 No Photos":
					{
						subReportName = "CSS1 Record 1 Subreport";
						break;
					}
					case "MatrixReportComponent":
					{
						subReportName = "MatrixReportComponentSubreport3";
						break;
					}
					case "Discipline Pipes":
					case "Discipline Pipes No Photos":
					{
						subReportName = "Pipe Record 3 Subreport";
						break;
					}
					case "Discipline Node":
					case "Discipline Node No Photos":
					{
						subReportName = "Node Record 3 Subreport";
						break;
					}
				}

				int counter = 0;
				if (reportName == "CSS 1"
					|| reportName == "CSS 1 No Photos" 
					|| reportName == "MatrixReportComponent"
					|| reportName == "Discipline Pipes"
					|| reportName == "Discipline Pipes No Photos"
					|| reportName == "Discipline Node"
					|| reportName == "Discipline Node No Photos")
				{
					string critTitle = "";
					foreach (Common.Criticality crit in Common.CommonTasks.Criticalities)
					{
						counter++;
						critTitle = "FieldCrit" + crit.CriticalityNumber.ToString() + "Title";
						m_report.Fields[subReportName].Subreport.Fields[critTitle].Text = "Criticality - " + crit.CriticalityName;
					}

					//make unused crits invisible
					for (int i = Common.CommonTasks.Criticalities.Count + 1; i <= 6; i++)
					{
						critTitle = "FieldCrit" + i.ToString();
						m_report.Fields[subReportName].Subreport.Fields[critTitle].Visible = false;

						critTitle += "Title";
						m_report.Fields[subReportName].Subreport.Fields[critTitle].Visible = false;

						critTitle += "Underscore";
						m_report.Fields[subReportName].Subreport.Fields[critTitle].Visible = false;
					}

					//move overall crit field
					if (reportName.StartsWith("Discipline Pipes")
						|| reportName.StartsWith("Discipline Node"))
					{
						counter++;
						double posLeft = m_report.Fields[subReportName].Subreport.Fields["FieldCrit" + counter.ToString() + "Title"].Left;
						m_report.Fields[subReportName].Subreport.Fields["FieldOverallCritTitle"].Left = posLeft;
						m_report.Fields[subReportName].Subreport.Fields["FieldOverallCritTitleUnderscore"].Left = posLeft;
						m_report.Fields[subReportName].Subreport.Fields["FieldOverallCrit"].Left = posLeft;
					}
				}

				m_report.DataSource.RecordSource = recordSource;

				m_report.DataSource.ConnectionString = options.ConnectionString;

				LoadPrinterSettings();

				m_report.OnOpen = SetParameterFields(options);

				if (!options.PrintOnly)
				{
					//mam - comment the following lines of code because MyReportDisplayer
					//	is now being created in UI\ReportFilterForm
					//				Reports.UI.C1ReportDisplayerForm MyReportDisplayer = 
					//					new Reports.UI.C1ReportDisplayerForm(MainForm.AppForm);
					//				MyReportDisplayer.Show();
					//				Application.DoEvents();
					//
					//				MyReportDisplayer.Text = m_report.ReportName;
					//
					//				return MyReportDisplayer.LoadReport(m_report);
					//</mam>

					//mam - new code to load report
					//WAM.UI.ReportFilterForm reportFilterForm = new WAM.UI.ReportFilterForm();

					if (isMatrix)
						return WAM.UI.ReportFilterForm.MyReportDisplayer.LoadReportMatrix(m_report);
					else
						return WAM.UI.ReportFilterForm.MyReportDisplayer.LoadReport(m_report, options.ItemName);
				//</mam>
				}
				else
				{
					if (options.ReportTitle.IndexOf("Field Sheet") > -1)
					{
						//return WAM.UI.ReportFilterForm.LoadReport(m_report);
						return WAM.UI.FieldSheet.LoadReport(m_report);
					}
					else
					{
					{
						return WAM.UI.ReportFilterForm.LoadReport(m_report);
					}
					}
				}

				//mam - commented the following line because it prints each report as a separate print object
				//	and we want all the selected reports as one print object
				//m_report.Document.Print();
				//return true;
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
				string msg = "An error has occurred:" + Environment.NewLine + Environment.NewLine + ex.Message;
				//mam 101107 - changed error message
				//MessageBox.Show("An error has occurred in RenderReport: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				//MessageBox.Show("Unable to render report, or report was cancelled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
		}

		public string GetXMLConnectionString(string fileName)
		{
			StringBuilder ReportPath = new StringBuilder(60);

			ReportPath.AppendFormat("{0}\\{1}", Drive.IO.Directory.GetApplicationPath(), fileName);

			//MessageBox.Show("ReportPath = " + ReportPath.ToString());

			return ReportPath.ToString();
		}

		public bool SaveXMLFile(string XML, string fileName)
		{
			FileStream file = null;
			StreamWriter writer = null;
			string			filePath = string.Format("{0}\\{1}", 
				Drive.IO.Directory.GetApplicationPath(), 
				fileName);

			try
			{
				file = new FileStream(filePath, FileMode.Create, FileAccess.Write);

				writer = new StreamWriter(file);
				writer.Write(XML);
				writer.Close();
				file = null;
			}
			catch
			{
				return false;
			}
			finally
			{
				if (writer != null)
					writer.Close();
				else if (file != null)
					file.Close();
			}

			return true;
		}

		#endregion /***** Member Methods *****/

		#region /***** Static Methods *****/
		public static string XMLReader(string path, string startString, string endString)
		{
			string fromFile = "";
			string selectedText = "";
			StringBuilder builder;
			FileStream	file = new FileStream(path, FileMode.Open, FileAccess.Read);
			StreamReader reader = new StreamReader(file);
			string		readText = reader.ReadLine();

			builder = new StringBuilder((int)file.Length);

			while (readText != null)
			{
				builder.Append(readText);
				builder.Append("\r\n");
				readText = reader.ReadLine();
			}

			// Always close streams / readers
			reader.Close();
			try
			{
				fromFile = builder.ToString();
				selectedText = fromFile;
				fromFile = fromFile.Remove(0, fromFile.IndexOf(startString));
				int length = fromFile.IndexOf(endString) + endString.Length;

				if (length > 0)
					selectedText = fromFile.Substring(0, length);
				else
					selectedText = null;
			}
			catch 
			{
				selectedText = "";
			}
			finally
			{
			}
			
			return selectedText;
		}
		#endregion /****** Static Methods ******/
	}
}