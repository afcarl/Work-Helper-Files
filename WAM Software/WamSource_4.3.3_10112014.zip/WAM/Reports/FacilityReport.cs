using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for FacilityReport.
	/// </summary>
	public class FacilityReport : ReportBase
	{
		#region /***** Member Variables *****/
		public ReportOptionsBase options = new ReportOptionsBase ();

		//mam
		private static string currentSelectedFilters = "";
		//</mam>

		#endregion /***** Member Variables *****/
		
		#region /***** Member Methods *****/
//		public bool PrintReport(int certificateID)
//		{			
//			return RenderReport(LoadReportSettings(certificateID), true);
//		}

		//mam - add 'bool printOnly' and 'bool includePhotos' and 'string selectedFilters'
		public static bool Print(WAM.Data.Facility facility, bool printOnly, 
			bool includePhotos, string selectedFilters)
		{
			ReportBase		myReport = null;
			ReportOptionsBase options = null;

			myReport = new FacilityReport();
			options = myReport.LoadReportSettings(facility.ID);

			//mam changed from true to printOnly
			options.PrintOnly = printOnly;
			//</mam>

			//mam
			if (!includePhotos)
			{
				options.ReportTitle = "Facility Report No Photos";
			}
			//</mam>

			//mam - added parameters
			options.XML = facility.GetXML(includePhotos, selectedFilters);

			//mam - get facility name
			string tempString = options.XML;
			int start = tempString.IndexOf("<FacilityName>");
			int end = tempString.IndexOf("</FacilityName>");
			options.ItemName = "Facility " + @tempString.Substring(start + 14 + 9, end - (start + 14 + 9 + 3));
			//</mam>

			//mam
			currentSelectedFilters = selectedFilters;
			//</mam>
			
			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//</mam>
		}

		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/
		public override ReportOptionsBase LoadReportSettings(int id)
		{
			options.ReportTitle = "Facility Report";
			options.fileName = "FacilityReport.XML";

			//mam - change count from 1 to 2
			//options.SubReports = new SubReportOptionsBase[1] { new SubReportOptionsBase() };

			options.SubReports = new SubReportOptionsBase[3] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};
			//</mam>

			//*************

			//mam 050806 - commented this report code

//			options.SubReports[0].FieldName = "Facility Process Subreport";
//			options.SubReports[0].SubReportTitle = "Facility Process Subreport";
//
//			//mam  - set RecordSource
//			options.SubReports[0].RecordSource = "Process";
//			//</mam>
//
//			//mam - add new subreport
//			options.SubReports[1].FieldName = "SubreportGeneralFilter";
//			options.SubReports[1].SubReportTitle = "SubreportGeneralFilter2";
//			options.SubReports[1].RecordSource = "Facility";
//			//</mam>

			//*************

			//mam 050806 - new report code
			
			options.SubReports[0].FieldName = "Facility Process Subreport 1";
			options.SubReports[0].SubReportTitle = "Facility Process Subreport 1";

			options.SubReports[1].FieldName = "Facility Process Subreport 2";
			options.SubReports[1].SubReportTitle = "Facility Process Subreport 2";

			//mam  - set RecordSource
			options.SubReports[0].RecordSource = "Process";
			options.SubReports[1].RecordSource = "Process";
			//</mam>

			options.SubReports[2].FieldName = "SubreportGeneralFilter";
			options.SubReports[2].SubReportTitle = "SubreportGeneralFilter";
			options.SubReports[2].RecordSource = "Facility";

			//*************

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{	
			//mam - comment line
			//return "";

			//mam - add new parameters
			if (currentSelectedFilters == "")
				return "SubreportGeneralFilter.Visible = False :";
			else
				return "SubreportGeneralFilter.Visible = True :";
			//mam
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ReportOptionsBase MyOptions = options;

			if (SaveXMLFile(MyOptions.XML, MyOptions.fileName))
				return "facility";
			else
				return null;
		}
		#endregion /***** Overrides *****/

	}
}