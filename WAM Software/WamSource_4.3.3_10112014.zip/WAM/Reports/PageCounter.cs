using System;
using System.Collections;
using System.Drawing;
using C1.Win.C1Report;

namespace WAM.Reports
{
	//mam - added this class to store the pages of each report 
	//	so that all selected reports can be displayed in PrintPreview

	//THIS CLASS IS NOT BEING USED AT THIS TIME

	//</mam>

	/// <summary>
	/// Summary description for PageCounter.
	/// </summary>
	public class PageCounter
	{
//		private int reportPageCount;
		private ArrayList pages = new ArrayList();
		
		public PageCounter()
		{
			//
			// TODO: Add constructor logic here
			//
			pages = null;
		}

//		public int ReportPageCount
//		{
//			get { return reportPageCount; }
//			set { reportPageCount = value; }
//		}

		public ArrayList ReportPagesToDisplay
		{
			get { return pages; }
			//set { reportPageCount = value; }
		}

		public bool StoreReportPages(ref C1Report MyReport)
		{
			//System.Windows.Forms.MessageBox.Show("page count = " + MyReport.PageImages.Count.ToString());
			//System.Windows.Forms.MessageBox.Show("DocumentName = " + MyReport.Document.DocumentName);
			foreach (Image img in MyReport.PageImages) 
				pages.Add(img.Clone());

			return true;

			//foreach (object o in PageCounter.pages)
			//	c1PrintPreview.Pages.Add(o);	

		}
	}
}
