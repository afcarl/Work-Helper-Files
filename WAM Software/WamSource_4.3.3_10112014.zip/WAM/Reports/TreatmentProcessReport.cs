using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for TreatmentProcessReport.
	/// </summary>
	public class TreatmentProcessReport : ReportBase
	{
		#region /***** Member Variables *****/
		public ReportOptionsBase options = new ReportOptionsBase ();

		//mam
		private static string currentSelectedFilters = "";
		//</mam>

		#endregion /***** Member Variables *****/
		
		#region /***** Member Methods *****/
//		public bool PrintReport(int certificateID)
//		{			
//			return RenderReport(LoadReportSettings(certificateID), true);
//		}
		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/
		public override ReportOptionsBase LoadReportSettings(int id)
		{
			options.ReportTitle = "PBZ 1";
			options.fileName = "TreatmentProcessReport.XML";
			
			//mam - change count from 2 to 3
			//options.SubReports = new SubReportOptionsBase[2] { new SubReportOptionsBase(),
			//													 new SubReportOptionsBase()};
			
			options.SubReports = new SubReportOptionsBase[4] 
			{
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase(),
				new SubReportOptionsBase()
			};
			//</mam>

			options.SubReports[0].FieldName = "PBZ Record 1 Subreport";
			options.SubReports[0].SubReportTitle = "PBZ Record 1 Subreport";

			options.SubReports[1].FieldName = "PBZ Record 2 Subreport";
			options.SubReports[1].SubReportTitle = "PBZ Record 2 Subreport";

			//mam 050806 - add third subreport
			options.SubReports[2].FieldName = "PBZ Record 3 Subreport";
			options.SubReports[2].SubReportTitle = "PBZ Record 3 Subreport";

			//mam  - set RecordSource
			options.SubReports[0].RecordSource = "Component";
			options.SubReports[1].RecordSource = "Component";
			options.SubReports[2].RecordSource = "Component";
			//</mam>

			//mam - add new subreport
			options.SubReports[3].FieldName = "SubreportGeneralFilter";
			options.SubReports[3].SubReportTitle = "SubreportGeneralFilter";
			options.SubReports[3].RecordSource = "TreatmentProcess";
			//</mam>

			options.ConnectionString = GetXMLConnectionString(options.fileName);
			return options;
		}

//		//mam
//		public override ReportOptionsBase LoadReportSettingsMatrix(int id)
//		{
//			options.ReportTitle = "MatrixReportTest";
//			//options.fileName = "TreatmentProcessReport.XML";
//			//options.fileName = "FacilityReport.XML";
//			//options.fileName = "MatrixReportTest.XML";
//			
//			options.SubReports = new SubReportOptionsBase[2] 
//			{
//				new SubReportOptionsBase(),
//				new SubReportOptionsBase()
//			};
//
//			//options.SubReports[0].FieldName = "Facility Process Subreport";
//			//options.SubReports[0].SubReportTitle = "Facility Process Subreport";
//			options.SubReports[0].FieldName = "MatrixReportTestSubreport1";
//			options.SubReports[0].SubReportTitle = "MatrixReportTestSubreport1";
//
//			options.SubReports[0].RecordSource = "Process";
//
//			options.SubReports[1].FieldName = "SubreportGeneralFilter";
//			options.SubReports[1].SubReportTitle = "SubreportGeneralFilter2";
//			options.SubReports[1].RecordSource = "Facility";
//
//			options.ConnectionString = GetXMLConnectionString(options.fileName);
//			return options;
//		}
//		//</mam>

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{					
			//mam - comment	
			//return "";

			//mam - set new parameters
			if (currentSelectedFilters == "")
				return "SubreportGeneralFilter.Visible = False :";
			else
				return "SubreportGeneralFilter.Visible = True :";
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ReportOptionsBase MyOptions = options;

			if (SaveXMLFile(MyOptions.XML, MyOptions.fileName))
				return "TreatmentProcess";
			else
				return null;
		}
		#endregion /***** Overrides *****/

		//mam - add 'bool printOnly' and 'bool includePhotos'
		public static bool Print(WAM.Data.TreatmentProcess process, bool printOnly, 
			bool includePhotos, string selectedFilters)
		{
			ReportBase		myReport = null;
			ReportOptionsBase options = null;

			myReport = new TreatmentProcessReport();
			options = myReport.LoadReportSettings(process.ID);

			//mam changed from true to printOnly
			options.PrintOnly = printOnly;
			//</mam>

			//mam
			if (!includePhotos)
			{
				options.ReportTitle = "PBZ 1 No Photos";
			}
			//</mam>

			//mam - added parameters
			options.XML = process.GetXML(includePhotos, selectedFilters);

			//mam - get process name
			string tempString = options.XML;
			int start = tempString.IndexOf("<ProcessName>");
			int end = tempString.IndexOf("</ProcessName>");
			options.ItemName = "Treatment Process " + @tempString.Substring(start + 13 + 9, end - (start + 13 + 9 + 3));
			//</mam>

			//mam
			currentSelectedFilters = selectedFilters;
			//</mam>

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//</mam>
		}

	}
}