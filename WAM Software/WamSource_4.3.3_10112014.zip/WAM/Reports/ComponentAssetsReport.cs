using System;
using System.Text;
using System.Windows.Forms;
using WAM.Reports.ReportOptions;

//mam 102309
using WAM.Common;

namespace WAM.Reports
{
	/// <summary>
	/// Summary description for ComponentAssetsReport.
	/// </summary>
	public class ComponentAssetsReport : ReportBase
	{
		#region /***** Member Variables *****/
		public ComponentAssetOptions options = new ComponentAssetOptions();

		//mam
		private static string currentSelectedFilters = "";
		//</mam>

		#endregion /***** Member Variables *****/
		
		#region /***** Member Methods *****/
		public void SetOptions(string facility, string process, string component)
		{	
			options.FacilityName = facility;
			options.ProcessName = process;
			options.ComponentName = component;
		}
		#endregion /***** Member Methods *****/

		#region /***** Overrides *****/
		public override ReportOptionsBase LoadReportSettings(int id)
		{
			options.ReportTitle = "Component Assets Report";
			options.ID = id;

			//mam 102309
			//options.ConnectionString = WAM.Data.WAMSource.CurrentSource.ConnectionString;
			//mam 07072011 - the report needs a provider - has this report not worked since 102309?
			//options.ConnectionString = Globals.WamSqlConnectionString;
			options.ConnectionString = "Provider=SQLOLEDB.1;" + Globals.WamSqlConnectionString;

			return options;
		}

		public override ReportOptionsBase LoadReportSettings(Form owner)
		{
			return null;
		}

		protected override string SetParameterFields(ReportOptionsBase options)
		{											
			StringBuilder builder = new StringBuilder(100);	
			ComponentAssetOptions MyOptions = (ComponentAssetOptions)options;

			builder.AppendFormat("[FacilityName] = \"{0}\" : ", MyOptions.FacilityName);
			builder.AppendFormat("[ProcessName] = \"{0}\" : ", MyOptions.ProcessName);
			builder.AppendFormat("[ComponentName] = \"{0}\" : ", MyOptions.ComponentName);

			//mam - never show the filters because there are no filters for Component Assets
			builder.Append("SubreportGeneralFilter.Visible = False :");
			////mam - add parameter
			//if (currentSelectedFilters == "")
			//	builder.Append("SubreportGeneralFilter.Visible = False :");
			//else
			//	builder.Append("SubreportGeneralFilter.Visible = True :");
			////</mam>
            			
			return builder.ToString();
		}

		protected override string SetQuery(ReportOptionsBase options)
		{
			ComponentAssetOptions MyOptions = (ComponentAssetOptions)options;
			StringBuilder builder = new StringBuilder(100);

			//mam - changed query to include Facility, Process, and Component names because this query populates the report
			//builder.AppendFormat(@"SELECT ComponentAssets.compasset_name, ComponentAssets.compasset_description, 
			//	ComponentAssets.compasset_conditionRanking, ComponentAssets.compasset_replacementCost, 
			//	ComponentAssets.compasset_sortOrder, ComponentAssets.compasset_id FROM ComponentAssets WHERE 
			//	ComponentAssets.component_id={0}", MyOptions.ID);
			builder.Append("SELECT F.facility_name AS FacilityName, P.process_name AS ProcessName,"); 
			builder.Append(" M.component_name AS ComponentName, A.compasset_name, A.compasset_description,");
			builder.Append(" A.compasset_conditionRanking, A.compasset_replacementCost,");
			builder.Append(" A.compasset_sortOrder, A.compasset_id");
			//filters are not allowed for the component assets report
			//builder.AppendFormat("'" + @currentSelectedFilters + "'");
			//builder.Append(" AS SelectedFilters");
			builder.Append(" FROM ComponentAssets A INNER JOIN MajorComponents M ON A.component_id = M.component_id");
			builder.Append(" INNER JOIN TreatmentProcesses P ON M.process_id = P.process_id");
			builder.Append(" INNER JOIN Facilities F ON P.facility_id = F.facility_id");
			builder.AppendFormat(" WHERE A.component_id={0}", MyOptions.ID);
			//</mam>

			System.Diagnostics.Debug.WriteLine(builder.ToString());
			return builder.ToString();
		}
		#endregion /***** Overrides *****/

		//mam - add 'bool printOnly'
		public static bool Print(WAM.Data.MajorComponent component, bool printOnly, string selectedFilters)
		{
			if (component == null)
				return false;

			ComponentAssetsReport myReport = null;
			ReportOptionsBase options = null;

			//Print the asset list, based on ComponentAsset.ComponentID
			WAM.Data.TreatmentProcess process = component.GetTreatmentProcess();
			WAM.Data.Facility facility = component.GetFacility();

			myReport = new ComponentAssetsReport();
			myReport.SetOptions(facility.Name, process.Name, component.Name);
			options = myReport.LoadReportSettings(component.ID);

			//mam changed from true to printOnly
			options.PrintOnly = printOnly;
			//</mam>

			//mam
			currentSelectedFilters = selectedFilters;
			//</mam>

			//mam - added parameter - false
			return myReport.RenderReport(options, false);
			//mam
		}
	}
}